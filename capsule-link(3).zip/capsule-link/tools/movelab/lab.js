// Move lab: a Mew on the battle stage, every move one click (or one key) away, to check how each one looks.
// No battle behind it: just the effect, with controls for the things that change how a move plays out.
import { createBattleStage } from '../../shared/ui/battleStage.js';
import { SpriteBank } from '../../shared/ui/art.js';
import { indexDataset, createDefaultDataset, createCreature } from '../../shared/engine/index.js';
import { h } from '../../shared/ui/dom.js';
import { NOTES_KEY, SET_KEYS, LIST_KEYS, normOv, pickOv, withKinds, KIND_MODES } from '../../shared/ui/labNotes.js';

// ---------- slow motion: the whole page's clock runs slower (timers, animation frames, performance.now) ----------
// (only while the lab is open: closing it puts the page's own clock back)
function installClock() {
  const TW = { scale: 1, real0: performance.now(), virt0: performance.now() };
  const rNow = performance.now.bind(performance), rRaf = window.requestAnimationFrame, rST = window.setTimeout, rSI = window.setInterval, rDate = Date.now;
  const origNow = performance.now;
  const virt = () => TW.virt0 + (rNow() - TW.real0) * TW.scale;
  TW.set = (k) => { TW.virt0 = virt(); TW.real0 = rNow(); TW.scale = k; };
  performance.now = virt;
  const d0 = rDate(), p0 = rNow(); Date.now = () => d0 + (virt() - p0);
  window.requestAnimationFrame = (cb) => rRaf.call(window, () => cb(virt()));
  window.setTimeout = (fn, ms = 0, ...a) => rST.call(window, fn, (Number(ms) || 0) / TW.scale, ...a);
  window.setInterval = (fn, ms = 0, ...a) => rSI.call(window, fn, (Number(ms) || 0) / TW.scale, ...a);
  TW.uninstall = () => { performance.now = origNow; Date.now = rDate; window.requestAnimationFrame = rRaf; window.setTimeout = rST; window.setInterval = rSI; };
  return TW;
}

/**
 * The battle lab in a box (the app's Battle Lab, or the page on its own).
 *   mountBattleLab(host) → { destroy }
 */
export function mountBattleLab(host, { resolve = null } = {}) {
const TW = installClock();
const SD = globalThis.CapsuleShowdown;
const idx = indexDataset(createDefaultDataset());
// a training dummy to hit (no sprites needed): a straw-stuffed sack on a post, with a target on its chest
const DUMMY = (() => {
  const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d');
  const R = (x, y, w, hh, col) => { g.fillStyle = col; g.fillRect(x, y, w, hh); };
  R(30, 40, 4, 22, '#6b4a2b'); R(22, 60, 20, 3, '#4a321c'); // post and foot
  R(20, 22, 24, 22, '#c9a86a'); R(18, 24, 2, 18, '#a8884e'); R(44, 24, 2, 18, '#a8884e'); R(20, 42, 24, 2, '#a8884e'); // body
  R(12, 26, 8, 4, '#c9a86a'); R(44, 26, 8, 4, '#c9a86a'); R(10, 24, 3, 3, '#e8d49a'); R(51, 24, 3, 3, '#e8d49a'); // arms and straw
  R(24, 8, 16, 14, '#d8bb7e'); R(23, 9, 1, 12, '#a8884e'); R(40, 9, 1, 12, '#a8884e'); R(24, 7, 16, 1, '#a8884e'); // head
  R(27, 13, 3, 3, '#3a2a1a'); R(34, 13, 3, 3, '#3a2a1a'); R(29, 18, 6, 1, '#3a2a1a'); // face
  R(26, 4, 3, 4, '#e8d49a'); R(31, 3, 2, 5, '#e8d49a'); R(35, 4, 3, 4, '#e8d49a'); // straw on top
  g.fillStyle = '#d23a3a'; g.beginPath(); g.arc(32, 32, 7, 0, Math.PI * 2); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(32, 32, 4.5, 0, Math.PI * 2); g.fill(); g.fillStyle = '#d23a3a'; g.beginPath(); g.arc(32, 32, 2, 0, Math.PI * 2); g.fill();
  R(26, 22, 12, 1, '#8a6a3a'); R(31, 23, 2, 6, '#8a6a3a'); // stitches
  return c.toDataURL();
})();
const resolveTexture = (p) => (/creatures\/testdummy(-back)?\.png$/.test(String(p)) ? DUMMY : resolve?.(p) ?? null);
const bank = new SpriteBank({ idx, resolveTexture });
const anySp = idx.ds.species[0]?.id;
const mk = (seed) => createCreature(idx, anySp, { level: 50, seed, location: { kind: 'wild' } });
const mons = [mk(1), mk(2)];
const ALL = SD.allMoves();
let notes = {}; try { notes = JSON.parse(localStorage.getItem(NOTES_KEY) || '{}'); } catch { notes = {}; }
const saveNotes = () => { try { localStorage.setItem(NOTES_KEY, JSON.stringify(notes)); } catch { /* fine */ } };

const S = { i: 0, q: '', type: '', place: 'stadium', hits: 'auto', weather: '', mag: 7, miss: false, crit: false, quality: 'high', me: 'Mew', foe: 'Testdummy', status: '', tod: 'day', speed: 1, terrain: '', fieldSide: 'foe', room: '', gravity: false, hz: {} };
try { Object.assign(S, JSON.parse(localStorage.getItem('clMoveLabState') || '{}')); } catch { /* fine */ }
const keep = () => { try { localStorage.setItem('clMoveLabState', JSON.stringify(S)); } catch { /* fine */ } };

const PLACES = ['stadium', 'colosseum', 'meadow', 'forest', 'beach', 'skyline', 'spooky', 'volcano', 'cavern', 'seafloor', 'ruins', 'shrine', 'park', 'snowfield', 'desert', 'synth', 'crystal', 'prism', 'starfield'];
const WEATHERS = [['', 'None'], ['raindance', 'Rain'], ['sunnyday', 'Harsh sun'], ['sandstorm', 'Sandstorm'], ['snowscape', 'Snow'], ['hail', 'Hail'], ['primordialsea', 'Heavy rain'], ['desolateland', 'Extreme sun']];
const MAG = { 4: 10, 5: 30, 6: 50, 7: 70, 8: 90, 9: 110, 10: 150 };
const NOTE_MAX = 20000;
// what can be swapped in, from the battle stage's own lists
const CAMS = [['auto', 'By animation (the usual)', 'The camera this kind of move normally gets'], ['fixed', 'Fixed (stays still)', 'Stays exactly where it is for the whole move'], ['side', 'Side'], ['wideSide', 'Wide side'], ['shoulder', 'Over the shoulder (handheld)'], ['incoming', 'Incoming (at the target)'], ['ride', 'Ride along'], ['charge', 'Charge'], ['run', 'Run with it'], ['aerial', 'Aerial'], ['orbit', 'Orbit (round the user)'],
  ['dolly', 'Dolly in', 'Pushing in behind it all the way to the target'], ['crane', 'Crane up', 'Rising from the grass to high above'], ['whip', 'Whip pan', 'A fast pan from the user to the target'], ['lowAngle', 'Low angle', 'From the grass, looking up'], ['topDown', 'High overhead', 'Really high, from out to the side'], ['swing', 'Swing round', 'Swinging round the middle of the field'],
  ['pov', 'User’s eyes', 'Through the user’s eyes'], ['targetPov', 'Target’s eyes', 'Through the target’s eyes, the move coming at you'], ['tracking', 'Tracking', 'Side-on, sliding along with it'], ['spin360', 'Spin 360°', 'A full circle round the target'], ['skyDrop', 'Sky drop', 'Falling from the sky onto the target'],
  ['dollyZoom', 'Dolly zoom', 'The vertigo shot on the target'], ['stadium', 'From the stands', 'From high up in the crowd'], ['splitPan', 'Split pan', 'Side-on, panning from one to the other']];
const KINDS = ['contact', 'tackleSpin', 'punch', 'kick', 'bite', 'slash', 'horn', 'zigzag', 'wrap', 'dive', 'burrow', 'phantom', 'projectile', 'volley', 'beam', 'pulse', 'wave', 'sweep', 'freq', 'sound', 'drain', 'vortex', 'tornado', 'thunder', 'zap', 'psychic', 'rainDown', 'rockfall', 'spikes', 'quake', 'surge', 'explosion', 'web', 'powder', 'status', 'glare', 'debuff', 'swap', 'self', 'dance', 'heal', 'protect', 'screen', 'hazard', 'weather', 'terrain', 'field',
  ['meteor', 'meteor ✦'], ['boomerang', 'boomerang ✦'], ['chain', 'chain ✦'], ['geyser', 'geyser ✦'], ['shockwave', 'shockwave ✦'], ['helix', 'helix ✦'], ['blink', 'blink ✦'], ['slam', 'slam ✦'], ['nova', 'nova ✦'], ['barrage', 'barrage ✦'], ['lance', 'lance ✦'], ['implode', 'implode ✦'], ['bounce', 'bounce ✦'], ['homing', 'homing ✦'], ['drillRush', 'drill rush ✦'], ['afterimage', 'afterimage ✦'], ['ringShot', 'ring shot ✦'], ['crossfire', 'crossfire ✦'], ['fountain', 'fountain ✦'], ['arcBeam', 'arc beam ✦'],
  ['breath', 'fire breath ✦', 'Breathed out from its mouth: a rolling, widening cone (Flamethrower, Dragon Breath)'], ['jet', 'jet ✦', 'A jet streaming out at it (Scald, Water Gun, Flamethrower before)'], ['bubbleJet', 'bubble jet ✦', 'A jet of bubbles (Bubble Beam)'], ['glob', 'lobbed globs ✦', 'Globs of goo lobbed over (Sludge, Gunk Shot)'], ['swoop', 'swoop ✦', 'Up, a wide turn high above, then down onto it (Aerial Ace, Brave Bird)'], ['waterDive', 'dive into water ✦', 'Down out of sight in a splash, and up under it (Dive)'], ['gleam', 'gleam sweep ✦', 'A dazzling sweep with a flash (Dazzling Gleam)'], ['roar', 'roar ✦', 'Sound rings pounding out, shaking the screen (Hyper Voice, Uproar)'], ['buzz', 'buzz ✦', 'A buzzing roar (Bug Buzz)']];
const APPROACHES = ['run', 'leap', 'pounce', 'charge', 'blink', 'arc', 'flurry', 'spin', 'zigzag', ['slide', 'slide ✦'], ['hop3', 'three hops ✦'], ['circle', 'circle round ✦'], ['backflip', 'backflip away ✦'], ['sneak', 'sneak up ✦'], ['uppercut', 'uppercut ✦'], ['stomp', 'heavy stomp ✦'], ['tumble', 'tumble ✦']];
const VOLLEYS = ['sequence', 'fan', 'orbit', 'rain', ['wall', 'wall ✦'], ['spiral', 'spiral ✦'], ['scatter', 'scatter ✦'], ['zigzag', 'criss-cross ✦']];
const SHAPES = ['dot', 'spark', 'shard', 'rock', 'needle', 'drop', 'bubble', 'wisp', 'snow', 'flake', 'flame', 'ember', 'leaf', 'seed', 'note', 'star', 'heart', 'feather', 'orb', 'ring', 'blob', 'gear', 'fist', 'arrowUp', 'zzz',
  'star5', 'twinkle', 'bolt', 'crescent', 'petal', 'gem', 'spiral', 'smoke', 'ash', 'scale', 'bone', 'eye', 'shuriken', 'pollen', 'hex', 'triangle', 'rune', 'coin', 'pixel', 'ribbon', 'cross', 'icicle', 'mud', 'streak', 'comet', 'ripple', 'confetti', 'drip', 'flare', 'plasma', 'sword', 'snowball', 'dust', 'wave', 'droplet', 'spray', 'foam', 'curl', 'mist'].map((x, i) => (i >= 25 ? [x, `${x} ✦`] : x));
const TYPE_COL = { Normal: '#f2efe4', Fire: '#ff7a2a', Water: '#4aa8ff', Grass: '#4fd060', Electric: '#ffe03a', Ice: '#8ae8ff', Fighting: '#e0603a', Poison: '#b85ae0', Ground: '#c8a060', Flying: '#bcd8ff', Psychic: '#ff6ab8', Bug: '#a8c838', Rock: '#b8a070', Ghost: '#7a5ac8', Dragon: '#7a6aff', Dark: '#5a4a6a', Steel: '#b8c8d8', Fairy: '#ffa0d0' };
const INTROS = [['front', 'Close-up'], ['close', 'Very close'], ['hero', 'Low hero shot'], ['charge', 'Push-in (charge)'], ['shoulder', 'Over its shoulder'], ['side', 'Side-on'], ['wide', 'Wide'], ['overhead', 'Overhead'], ['team', 'With its trainer']];
const IMPACTS = [['front', 'Close-up on it'], ['close', 'Very close'], ['hero', 'Low angle on it'], ['side', 'Side-on'], ['shoulder', 'Over the user’s shoulder'], ['behind', 'From behind it'], ['wide', 'Wide'], ['overhead', 'Overhead']];
const REACTS = [['knock', 'Knocked back'], ['launch', 'Launched up (uppercut)'], ['flinch', 'Just a flinch']];
const HITFX = [['burst', 'Particle burst'], ['type', 'Type effect'], ['pop', 'Impact picture'], ['ring', 'Ring'], ['flash', 'Flash of light'], ['shake', 'Screen shake'], ['lens', 'On the lens'], ['splash', 'Splash', 'Water thrown up round it as it lands (on by itself for Water moves)']];
// colours used by the moves so far, to swap in
const PALETTE = ['#8a8078','#8c8c9c','#ffffff','#a04040','#d23a3a','#e0603a','#e05050','#ff3a3a','#ff5a4a','#3a2a1a','#4e361e','#5a4a40','#6e4e2e','#8a6a3a','#a8884e','#9a8468','#ff5a20','#c8a060','#b89a70','#ff7a2a','#ffb43a','#d8bb7e','#cdbb98','#d8c8a8','#e8d49a','#ffb08a','#e8dcc0','#a8b820','#a8c838','#e0c040','#ffe03a','#f2c84a','#fff36a','#e0f080','#ffe48a','#fff8a0','#ecebd8','#fffbd0','#78c850','#b8e070','#b8ff7a','#2a7a2a','#4fbf4a','#4fd060','#8aff6a','#50c080','#88aa99','#6ad08a','#7affd8','#7dffa0','#9dffb8','#bfffe0','#98d8d8','#8ae8ff','#a8f2ff','#3c7ae0','#4a8cff','#4ab8ff','#5ad0ff','#a8b0c0','#6aa0ff','#b8c8d8','#9ad0ff','#bcd8ff','#e8eef8','#7a6aff','#9a7aff','#d0d0e8','#1a1020','#30283a','#4a3a50','#5a4a6a','#7a5a8a','#9a4ad0','#7a5ac8','#b85ae0','#8a6ad8','#c070e8','#c0a8ff','#7a2a8a','#a040a0','#ff4fd8','#e8a0ff','#ff6ab8','#ff7ad8','#ffa0d0','#ffd0f0','#ff5a7a'];
const OV_OPTS_LATE = () => ({ cam: CAMS, intro: INTROS, kind: KINDS, appr: APPROACHES, vol: VOLLEYS, impact: IMPACTS, react: REACTS, shape: SHAPES, hitfx: HITFX });
// the Timing panel: extra time for each big moment, every move (ms)
const TIMING = [['intro', 'Introductions', 'Each shot of a battle’s introduction'], ['focus', 'Focus on the user', 'The opening close-up, before it goes'], ['charge', 'Big-move build-up', 'Extra for the powerful moves'], ['attack', 'The attack on its way', 'Projectiles, beams and the like crossing the field'],
  ['hit', 'Freeze as it lands', 'A freeze-frame the instant it hits'], ['impact', 'On the one hit', 'The shot on the target after it lands'], ['slide', 'Knocked back', 'The target being thrown back'], ['back', 'Before it bounces back', 'How long it stays back before hopping back'], ['glide', 'Camera moves', 'Every glide between shots (a long jump stays a cut)']];
const TERRAINS = [['', 'None'], ['electricterrain', 'Electric Terrain'], ['grassyterrain', 'Grassy Terrain'], ['mistyterrain', 'Misty Terrain'], ['psychicterrain', 'Psychic Terrain']];
const HAZARDS = [['spikes', 'Spikes', 3], ['toxicspikes', 'Toxic Spikes', 2], ['stealthrock', 'Stealth Rock'], ['stickyweb', 'Sticky Web'], ['reflect', 'Reflect'], ['lightscreen', 'Light Screen'], ['auroraveil', 'Aurora Veil'], ['tailwind', 'Tailwind'], ['safeguard', 'Safeguard'], ['mist', 'Mist']];

const stageBox = h('div', { class: 'lab-stage' });
const listEl = h('div', { class: 'lab-list' });
const info = h('div', { class: 'lab-info' });
const ovBox = h('div', { class: 'lab-ovbox' }); // (the part-by-part picks: beside the stage on a wide screen, under it on a narrow one)
let stage = null;
function build() {
  try { stage?.destroy(); } catch { /* fine */ }
  stage = createBattleStage({ idx, bank, place: S.place, creatureFor: (mon) => mons[mon.side] ?? mons[0], speciesFor: () => null, quality: S.quality, ambient: S.tod && S.tod !== 'day' ? { tod: S.tod } : null, resolveTexture });
  stageBox.replaceChildren(stage.el);
  stage.labTiming?.(S.timing ?? {});
  setTimeout(() => { stage.labStart(S.me, S.foe); drawInfo(); }, 60);
}
const list = () => ALL.filter((m) => (!S.q || m.name.toLowerCase().includes(S.q)) && (!S.type || m.type === S.type));
function cur() { const L = list(); if (!L.length) return null; S.i = Math.max(0, Math.min(L.length - 1, S.i)); return L[S.i]; }
function play() {
  const m = cur(); if (!m || !stage) return;
  let mv = SD.stageMove(m.id);
  if (m.id === 'magnitude') mv = { ...mv, bp: MAG[S.mag] ?? 70 };
  const multi = Array.isArray(m.multihit) ? m.multihit : m.multihit ? [m.multihit, m.multihit] : null;
  const hits = multi ? (S.hits === 'auto' ? Math.round((multi[0] + multi[1]) / 2) : Number(S.hits)) : 1;
  const n = notes[m.id] ?? {};
  const pickNow = pickOv(n.ov, n.ovDone ?? {}) ?? {};
  if (n.ovShort) pickNow.short = true;
  if (n.ovDuring) pickNow.during = true;
  if (n.ovPic) pickNow.pic = true;
  if (n.ov?.remap && Object.keys(n.ov.remap).length) pickNow.remap = n.ov.remap;
  withKinds(pickNow, n);
  LAST.id = m.id; LAST.pick = pickNow;
  stage.labTiming(S.timing ?? {});
  stage.labMove(mv, { hits, weather: S.weather || null, miss: S.miss, crit: S.crit, override: Object.keys(pickNow).length ? pickNow : null, terrain: S.terrain || null, field: fieldOf() });
  drawInfo();
  // (then the colours it drew with, to list them)
  const id = m.id, token = ++playTok;
  for (const ms of [1400, 3200]) setTimeout(() => { if (token !== playTok || !stage) return; const u = stage.labUsedColors?.() ?? []; if (u.length) { usedCols[id] = u; if (cur()?.id === id) drawColours(); } }, ms);
}
// overrides: each a list (older notes kept one value); one of each is picked at random for every play
const OPEN = new Set(['cam']);
const LAST = { id: null, pick: null };
// overrides kept per move: a list for each part (left out: the move's own; an empty list: that part taken out)
let playTok = 0; const usedCols = {};
const sameSet = (a, b) => a.length === b.length && a.every((x) => b.includes(x));
const labelOf = (opts, v) => { const o = opts.find((x) => (Array.isArray(x) ? x[0] : x) === v); return Array.isArray(o) ? o[1] : v; };
// field conditions for the stage, from the switches
function fieldOf() {
  const one = { ...S.hz };
  const sides = [S.fieldSide === 'foe' ? null : one, S.fieldSide === 'mine' ? null : one];
  const any = Object.values(one).some(Boolean) || S.room || S.gravity;
  return any ? { sides, trickroom: S.room === 'trickroom', wonderroom: S.room === 'wonderroom', magicroom: S.room === 'magicroom', gravity: !!S.gravity } : null;
}
function go(d) { S.i += d; keep(); drawList(); play(); }
function drawInfo() {
  const m = cur(); if (!m) { info.replaceChildren('No move matches.'); ovBox.replaceChildren(); return; }
  const mv = SD.stageMove(m.id), n = notes[m.id] ?? {};
  const ok = h('button', { class: `lab-mark ${n.mark === 'ok' ? 'on ok' : ''}`, onclick: () => { notes[m.id] = { ...n, mark: n.mark === 'ok' ? null : 'ok' }; saveNotes(); drawInfo(); drawList(); } }, '✓ Looks right');
  const bad = h('button', { class: `lab-mark ${n.mark === 'bad' ? 'on bad' : ''}`, onclick: () => { notes[m.id] = { ...n, mark: n.mark === 'bad' ? null : 'bad' }; saveNotes(); drawInfo(); drawList(); } }, '✗ Needs work');
  const count = h('span', { class: 'dim lab-count2' }, `${(n.text ?? '').length} / ${NOTE_MAX}`);
  const ta = h('textarea', { maxLength: NOTE_MAX, rows: 7, placeholder: 'What should change? (saved as you type)', value: n.text ?? '', oninput: (e) => { notes[m.id] = { ...(notes[m.id] ?? {}), text: e.target.value }; count.textContent = `${e.target.value.length} / ${NOTE_MAX}`; saveNotes(); } });
  ta.value = n.text ?? '';
  // try other cameras, animations, particles or colours for this move: pick as many of each as you like, and each
  // time it plays one of the ones picked is used (a move needn't look exactly the same every time). Kept with its
  // notes and exported.
  const ov = normOv(n.ov);
  // what the move does on its own (shown as picked until you change it), worked out with the other picks in mind
  const lastOf = (k) => { const L = ov[k]; return L?.length ? L[L.length - 1] : L ? 'none' : undefined; };
  const D = stage?.labDefaults?.(mv, { kind: lastOf('kind'), appr: lastOf('appr'), vol: lastOf('vol') }) ?? {};
  // (older notes: a colour or second colour picked becomes a swap of the move's own colour)
  if (ov.col || ov.col2) { const rm = { ...(ov.remap ?? {}) }; if (ov.col && D.col?.[0]) rm[D.col[0]] = ov.col[ov.col.length - 1]; if (ov.col2 && D.col?.[1]) rm[D.col[1]] = ov.col2[ov.col2.length - 1]; delete ov.col; delete ov.col2; if (Object.keys(rm).length) ov.remap = rm; notes[m.id] = { ...n, ov: Object.keys(ov).length ? ov : undefined }; saveNotes(); }
  const saveOv = (o2) => { const cur0 = notes[m.id] ?? {}; notes[m.id] = { ...cur0, ov: Object.keys(o2).length ? o2 : undefined }; saveNotes(); drawList(); play(); };
  const isDone = (k) => !!notes[m.id]?.ovDone?.[k];
  const setDoneQuiet = (k, on) => { const cur0 = notes[m.id] ?? {}; const d = { ...(cur0.ovDone ?? {}), [k]: on }; if (!on) delete d[k]; notes[m.id] = { ...cur0, ovDone: Object.keys(d).length ? d : undefined }; };
  const setDone = (k, on) => { setDoneQuiet(k, on); if (on) OPEN.delete(k); saveNotes(); drawList(); play(); };
  // clicking a chip: the first change starts from the move's own picks; back to exactly those, and it's the move's own again
  const toggle = (k, v) => {
    const o2 = normOv(notes[m.id]?.ov), base = o2[k] ?? [...(D[k] ?? [])], had = base.includes(v);
    const L = had ? base.filter((x) => x !== v) : [...base, v];
    if (!o2[k] && !SET_KEYS.includes(k)) setDoneQuiet(k, had && L.length > 1); // (taking one of several of its own away: the rest still take turns)
    if (!had && !SET_KEYS.includes(k)) setDoneQuiet(k, false); // (adding one: that's the one that plays, while choosing)
    if (D[k] && sameSet(L, D[k]) && D[k].length) { delete o2[k]; setDoneQuiet(k, false); } else o2[k] = L;
    saveOv(o2);
  };
  const reset = (k) => { const o2 = normOv(notes[m.id]?.ov); delete o2[k]; setDoneQuiet(k, false); saveOv(o2); };
  const clearAll = (k) => { const o2 = normOv(notes[m.id]?.ov); o2[k] = []; setDoneQuiet(k, false); saveOv(o2); };
  const doneBtn = (k, picked) => (!SET_KEYS.includes(k) && ov[k] && picked.length > 1 ? h('button', { class: `lab-chip done ${isDone(k) ? 'on' : ''}`, title: isDone(k) ? 'Done: each play uses any of these at random. Click to go back to choosing.' : 'While choosing, the one you clicked last is the one that plays. Done: any of them, at random.', onclick: () => setDone(k, !isDone(k)) }, isDone(k) ? '✓ Done (random)' : 'Done') : null);
  const names = (opts, L) => L.map((v) => labelOf(opts, v)).join(', ');
  const stateOf = (k, opts) => {
    const own = D[k] ?? [];
    if (!ov[k]) return !own.length ? ' — none for this move' : SET_KEYS.includes(k) ? ` — its own: ${names(opts, own)}` : own.length > 1 ? ` — its own: takes turns (${names(opts, own)})` : ` — its own: ${names(opts, own)}`;
    const L = ov[k];
    if (!L.length) return ' — none (taken out)';
    if (SET_KEYS.includes(k)) return ` — changed: ${names(opts, L)}`;
    if (k === 'kind' && L.length > 1 && (n.kindMode ?? 'chain') !== 'random') return (n.kindMode ?? 'chain') === 'chain' ? ` — one after another: ${L.map((v) => labelOf(opts, v)).join(' → ')}` : ` — all at once: ${names(opts, L)}`;
    return isDone(k) ? ` — ✓ done: any of ${L.length} (${names(opts, L)})` : ` — choosing: plays ${labelOf(opts, L[L.length - 1])}${L.length > 1 ? ` (${L.length} picked)` : ''}`;
  };
  const group = (label, key, opts, extra = null, hint = null) => {
    const picked = ov[key] ?? D[key] ?? [];
    return h('details', { class: `lab-ovg ${ov[key] ? 'set' : ''}`, open: OPEN.has(key), ontoggle: (e) => { if (e.target.open) OPEN.add(key); else OPEN.delete(key); } },
      h('summary', null, h('b', null, label), h('span', { class: 'dim' }, stateOf(key, opts))),
      hint ? h('div', { class: 'dim micro' }, hint) : null,
      h('div', { class: 'lab-chips' }, opts.map((o) => { const [v, l, tip] = Array.isArray(o) ? o : [o, o]; return h('button', { class: `lab-chip ${picked.includes(v) ? 'on' : ''} ${(D[key] ?? []).includes(v) ? 'own' : ''}`, title: tip ?? '', onclick: () => toggle(key, v) }, l); }),
        extra,
        ov[key] ? h('button', { class: 'lab-chip clear', title: 'Back to what the move does on its own', onclick: () => reset(key) }, '↺ Its own') : null,
        picked.length ? h('button', { class: 'lab-chip clear', title: 'Take all of these out: nothing for this part', onclick: () => clearAll(key) }, 'None') : null,
        doneBtn(key, picked)));
  };
  const flag = (k, on, offTxt, onTxt, tip) => h('button', { class: `lab-chip short ${on ? 'on' : ''}`, title: tip, onclick: () => { const cur0 = notes[m.id] ?? {}; notes[m.id] = { ...cur0, [k]: !cur0[k] || undefined }; saveNotes(); drawList(); play(); } }, on ? onTxt : offTxt);
  const apprExtra = [flag('ovShort', !!n.ovShort, '⟂ Stop short', '⟂ Stop short ✓', 'Stop a good way short of the target instead of running right into it (for shots fired from close by, too)'),
    flag('ovDuring', !!n.ovDuring, 'After Approach', 'During Approach', 'When the move itself starts, for a move that runs in first and isn’t a contact one: once it arrives (After), or as it sets off (During)')];
  const pvShapes = () => (ov.shape?.length ? ov.shape : D.shape?.length ? D.shape : [SHAPES[0]]);
  const pv = h('button', { class: 'lab-chip', title: 'Show the picked particles round the target, without the move', onclick: () => { pvShapes().forEach((sh, i) => setTimeout(() => stage?.labBurst?.(sh, Object.values(ov.remap ?? {})[0] ?? TYPE_COL[m.type] ?? '#ffffff'), i * 700)); } }, '👁 Preview particles');
  const lp = LAST.id === m.id ? LAST.pick : null;
  const lastPick = lp && Object.keys(lp).length ? h('div', { class: 'dim micro' }, `This play: ${Object.entries(lp).map(([k, v]) => (k === 'short' ? 'stopping short' : k === 'during' ? 'during the approach' : k === 'remap' ? `${Object.keys(v).length} colour swap(s)` : `${OV_NAMES[k === 'shapes' ? 'shape' : k] ?? k} ${v === 'none' ? 'none' : Array.isArray(v) ? `${v.length}` : labelOf(OV_OPTS_LATE()[k] ?? [], v)}`)).join(' · ')}`) : null;
  const anyOv = Object.keys(ov).length || n.ovShort || n.ovDuring;
  const ovPanel = h('div', { class: 'lab-ovs' },
    h('div', { class: 'lab-ovs-head' }, h('b', null, 'This move, part by part'), h('span', { class: 'dim' }, ' — everything it does on its own shows as picked (outlined = its own). Take one out and it’s gone; take them all out (None) and that part does nothing. Add others to try them: while choosing, the one clicked last plays; press Done and each play picks any of them at random. ✦ = new.'), anyOv ? h('button', { onclick: () => { const cur0 = notes[m.id] ?? {}; notes[m.id] = { ...cur0, ov: undefined, ovDone: undefined, ovShort: undefined, ovDuring: undefined }; saveNotes(); drawList(); play(); } }, 'Reset all') : null),
    lastPick,
    group('Opening shot (on the user)', 'intro', INTROS),
    group('Camera (the move on its way)', 'cam', CAMS),
    group('Animation', 'kind', KINDS, [apprExtra[1], (ov.kind?.length ?? 0) > 1 ? h('label', { class: 'lab-chip short', title: 'How the animations picked work together (in the order you picked them)' }, 'Several: ',
      h('select', { onchange: (e) => { const cur0 = notes[m.id] ?? {}; notes[m.id] = { ...cur0, kindMode: e.target.value === 'chain' ? undefined : e.target.value }; saveNotes(); drawList(); drawInfo(); play(); } },
        KIND_MODES.map(([v, l]) => h('option', { value: v, selected: (n.kindMode ?? 'chain') === v }, l)))) : null],
      'With an approach picked, a move that isn’t a contact one runs in first: After Approach starts it on arriving, During Approach as it sets off. With several animations picked they play one after another by default, in the order picked (a projectile, then a geyser where it lands); or all at once, or a different one each play.'),
    group('Approach', 'appr', APPROACHES, apprExtra, 'Contact animations run in with this. Any other move with one picked runs in first, then the move starts (After / During Approach).'),
    group('Volley pattern (volley animation)', 'vol', VOLLEYS),
    group('Closing shot (on the one hit)', 'impact', IMPACTS),
    group('How the one hit reacts', 'react', REACTS),
    group('Hit effects', 'hitfx', HITFX),
    group('Particles', 'shape', SHAPES, [pv, ov.shape ? flag('ovPic', !!n.ovPic, '🖼 Showdown’s picture: off', '🖼 Showdown’s picture: on', 'With particles picked here they take the place of Showdown’s picture for this move (in battles too). Turn this on to draw its picture as well.') : null]),
    colBox);
  drawColours();
  info.replaceChildren(
    h('div', { class: 'lab-title' }, h('b', null, m.name), h('span', { class: `lab-type t-${m.type}` }, m.type), h('span', { class: 'dim' }, `${mv.cat}${mv.bp ? ` · ${mv.bp} power` : ''}${m.multihit ? ` · hits ${Array.isArray(m.multihit) ? m.multihit.join('–') : m.multihit}×` : ''}${m.weather ? ` · sets ${m.weather}` : ''}`)),
    h('div', { class: 'lab-row' }, ok, bad, count), ta);
  ovBox.replaceChildren(ovPanel);
}
// colours: every colour the move draws with (noted as it plays), each one swappable for another
const colBox = h('div', { class: 'lab-ovg lab-cols' });
let activeCol = null;
function drawColours() {
  const m = cur(); if (!m) return;
  const n = notes[m.id] ?? {}, rm = { ...(normOv(n.ov).remap ?? {}) };
  const D = stage?.labDefaults?.(SD.stageMove(m.id), {}) ?? {};
  const own = [...new Set([...(usedCols[m.id] ?? []), ...(D.col ?? []).map((c) => c.toLowerCase())])];
  for (const k of Object.keys(rm)) if (!own.includes(k)) own.push(k);
  if (!own.includes(activeCol)) activeCol = own[0] ?? null;
  const setRm = (o2) => { const ov2 = normOv(notes[m.id]?.ov); if (Object.keys(o2).length) ov2.remap = o2; else delete ov2.remap; notes[m.id] = { ...(notes[m.id] ?? {}), ov: Object.keys(ov2).length ? ov2 : undefined }; saveNotes(); drawList(); play(); };
  const sw = (c) => h('span', { class: 'lab-swatch', style: { background: c } });
  const swap = (c) => { if (!activeCol) return; setRm({ ...rm, [activeCol]: c }); };
  const dropper = h('input', { type: 'color', value: /^#[0-9a-f]{6}$/i.test(rm[activeCol] ?? activeCol ?? '') ? (rm[activeCol] ?? activeCol) : '#ffffff' });
  colBox.replaceChildren(
    h('div', null, h('b', null, 'Colours'), h('span', { class: 'dim' }, own.length ? ` — the ${own.length} it uses${Object.keys(rm).length ? `, ${Object.keys(rm).length} swapped` : ''}. Pick one, then a colour to put in its place.` : ' — they show here once it has played.')),
    h('div', { class: 'lab-chips' }, ...own.map((c) => h('button', { class: `lab-chip ${c === activeCol ? 'on' : ''}`, title: rm[c] ? `${c} → ${rm[c]}` : c, onclick: () => { activeCol = c; drawColours(); } }, sw(c), rm[c] ? [' → ', sw(rm[c])] : null))),
    activeCol ? h('div', { class: 'dim micro' }, `Put in place of `, sw(activeCol), ` ${activeCol}:`) : null,
    activeCol ? h('div', { class: 'lab-palette' }, ...PALETTE.map((c) => h('button', { class: `lab-pal ${rm[activeCol] === c ? 'on' : ''}`, title: c, style: { background: c }, onclick: () => swap(c) }))) : null,
    activeCol ? h('div', { class: 'lab-chips' }, dropper, h('button', { class: 'lab-chip', onclick: () => swap(dropper.value) }, '+ Use this colour'),
      rm[activeCol] ? h('button', { class: 'lab-chip clear', onclick: () => { const o2 = { ...rm }; delete o2[activeCol]; setRm(o2); } }, '↺ This one back') : null,
      Object.keys(rm).length ? h('button', { class: 'lab-chip clear', onclick: () => setRm({}) }, '↺ All colours back') : null) : null);
}
function drawList() {
  const L = list(), c = cur();
  const done = Object.values(notes).filter((n) => n.mark).length;
  listEl.replaceChildren(h('div', { class: 'dim lab-count' }, `${L.length} moves · ${done} checked`), ...L.slice(Math.max(0, S.i - 60), S.i + 140).map((m) => {
    const i = L.indexOf(m), n = notes[m.id];
    const b = h('button', { class: `lab-item ${m === c ? 'cur' : ''} ${n?.mark ?? ''}`, onclick: () => { S.i = i; keep(); drawList(); play(); } }, h('span', { class: `lab-dot t-${m.type}` }), m.name, n?.mark === 'ok' ? ' ✓' : n?.mark === 'bad' ? ' ✗' : '', n?.ov || n?.ovShort || n?.ovDuring ? ' ⚙' : '');
    return b;
  }));
  // (only the list scrolls to it, not the page round it)
  const cu = listEl.querySelector('.cur');
  if (cu) { const lr = listEl.getBoundingClientRect(), cr = cu.getBoundingClientRect(); if (cr.top < lr.top) listEl.scrollTop += cr.top - lr.top; else if (cr.bottom > lr.bottom) listEl.scrollTop += cr.bottom - lr.bottom; }
}
const sel = (label, opts, key, after) => h('label', null, h('span', null, label), h('select', { onchange: (e) => { S[key] = e.target.value; keep(); after?.(); } }, opts.map(([v, l]) => h('option', { value: v, selected: String(S[key]) === String(v) }, l))));
const chk = (label, key, after) => h('label', { class: 'lab-chk' }, h('input', { type: 'checkbox', checked: !!S[key], onchange: (e) => { S[key] = e.target.checked; keep(); after?.(); } }), label);
const types = [...new Set(ALL.map((m) => m.type))].sort();
// notes out to a .txt file, and back in (each move: “## Name [ok|needs work]”, a “try:” line, then the notes)
const OV_KEYS = LIST_KEYS;
const OV_NAMES = { cam: 'camera', intro: 'opening shot', kind: 'animation', appr: 'approach', vol: 'volley', impact: 'closing shot', react: 'reaction', shape: 'particles', hitfx: 'hit effects' };
const hasNote = (n) => n && (n.mark || n.text || n.ov || n.ovShort || n.ovDuring);
function notesText() {
  const blocks = ALL.filter((m) => hasNote(notes[m.id])).map((m) => {
    const n = notes[m.id], o = normOv(n.ov), ov = [...OV_KEYS.filter((k) => o[k]).map((k) => `${k}=${o[k].length ? o[k].join('|') : 'none'}${n.ovDone?.[k] ? ' (done)' : ''}`),
      ...(o.remap ? [`colours=${Object.entries(o.remap).map(([a, b]) => `${a}>${b}`).join('|')}`] : []), ...(n.ovShort ? ['short=yes'] : []), ...(n.ovDuring ? ['during=yes'] : [])].join('; ');
    return [`## ${m.name}${n.mark === 'bad' ? ' [needs work]' : n.mark === 'ok' ? ' [ok]' : ''}`, ov ? `try: ${ov}` : null, n.text ? n.text.trim() : null].filter(Boolean).join('\n');
  });
  const tm = Object.entries(S.timing ?? {}).filter(([, v]) => Number(v) > 0).map(([k, v]) => `${k}=${Number(v)}`).join('; ');
  return `Capsule Link move lab notes (${new Date().toISOString().slice(0, 10)})\n${tm ? `timing (ms added, every move): ${tm}\n` : ''}\n${blocks.join('\n\n')}\n`;
}
function importText(txt) {
  const byName = new Map(ALL.map((m) => [m.name.toLowerCase(), m.id]));
  let n = 0;
  const tl = /^timing[^:]*:\s*(.+)$/im.exec(String(txt).split(/^## /m)[0] ?? '');
  if (tl) { const t = {}; for (const kv of tl[1].split(';')) { const [k, v] = kv.split('=').map((x) => x?.trim()); if (TIMING.some(([k2]) => k2 === k)) t[k] = Math.max(0, Number(v) || 0); } S.timing = t; keep(); drawTiming(); }
  for (const part of String(txt).split(/^## /m).slice(1)) {
    const lines = part.split(/\r?\n/), head = lines.shift() ?? '';
    const mk = /\[(ok|needs work)\]\s*$/i.exec(head), name = head.replace(/\[(ok|needs work)\]\s*$/i, '').trim().toLowerCase();
    const id = byName.get(name); if (!id) continue;
    let ov, shortOn = false, duringOn = false; const doneK = {};
    if (/^try:/i.test(lines[0] ?? '')) {
      ov = {};
      for (const kv of lines.shift().replace(/^try:\s*/i, '').split(';')) {
        const i = kv.indexOf('='); if (i < 0) continue; const k = kv.slice(0, i).trim(), v = kv.slice(i + 1).trim();
        if (k === 'short') { shortOn = /^y/i.test(v); continue; }
        if (k === 'during') { duringOn = /^y/i.test(v); continue; }
        if (k === 'colours' || k === 'colors') { const rm = {}; for (const pr of v.split('|')) { const [a, b] = pr.split('>').map((x) => x.trim()); if (a && b) rm[a.toLowerCase()] = b; } if (Object.keys(rm).length) ov.remap = rm; continue; }
        if (OV_KEYS.includes(k) || k === 'col' || k === 'col2') { if (/\(done\)\s*$/.test(v)) doneK[k] = true; const v2 = v.replace(/\(done\)\s*$/, '').trim(); ov[k] = /^none$/i.test(v2) ? [] : v2.split('|').map((x) => x.trim()).filter(Boolean); }
      }
      if (!Object.keys(ov).length) ov = undefined;
    }
    const text = lines.join('\n').trim().slice(0, NOTE_MAX);
    notes[id] = { mark: mk ? (/ok/i.test(mk[1]) ? 'ok' : 'bad') : null, text: text || undefined, ov, ovDone: Object.keys(doneK).length ? doneK : undefined, ovShort: shortOn || undefined, ovDuring: duringOn || undefined };
    n++;
  }
  saveNotes(); drawList(); drawInfo();
  return n;
}
const exportBtn = h('button', { onclick: () => {
  const blob = new Blob([notesText()], { type: 'text/plain' }), a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = `move-lab-notes-${new Date().toISOString().slice(0, 10)}.txt`; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
} }, '⬇ Export notes (.txt)');
const fileIn = h('input', { type: 'file', accept: '.txt,text/plain', style: { display: 'none' }, onchange: async (e) => {
  const f = e.target.files?.[0]; if (!f) return; const txt = await f.text(); e.target.value = '';
  if (Object.values(notes).some(hasNote) && !confirm('Importing replaces the notes of the moves in that file (others are kept). Go ahead?')) return;
  const n = importText(txt); importBtn.textContent = `Imported ${n} moves`; setTimeout(() => { importBtn.textContent = '⬆ Import notes (.txt)'; }, 2000);
} });
const importBtn = h('button', { onclick: () => fileIn.click() }, '⬆ Import notes (.txt)');
// timing: extra time on each big moment, for every move (and the introductions)
const timingBox = h('details', { class: 'lab-field lab-timing' });
function drawTiming() {
  const t = S.timing ?? {}, any = Object.values(t).some((v) => Number(v) > 0);
  timingBox.replaceChildren(h('summary', null, `Timing (every move)${any ? ' ✓' : ''}`),
    h('p', { class: 'dim micro' }, 'Extra time added to each big moment, in milliseconds, for every move. Try values here; export the notes and they’re in the file, to be built into the game.'),
    ...TIMING.map(([k, label, tip]) => h('label', { title: tip }, h('span', null, label), h('input', { type: 'number', min: 0, max: 5000, step: 50, value: Number(t[k]) || 0, onchange: (e) => { S.timing = { ...(S.timing ?? {}), [k]: Math.max(0, Math.min(5000, Number(e.target.value) || 0)) }; keep(); stage?.labTiming?.(S.timing); drawTiming(); } }))),
    h('div', { class: 'lab-row' }, h('button', { onclick: () => { stage?.labTiming?.(S.timing ?? {}); stage?.labIntro?.('wild'); } }, '▶ Wild intro'), h('button', { onclick: () => { stage?.labTiming?.(S.timing ?? {}); stage?.labIntro?.('trainer'); } }, '▶ Trainer intro'),
      any ? h('button', { onclick: () => { S.timing = {}; keep(); stage?.labTiming?.({}); drawTiming(); } }, 'Reset timing') : null));
}
drawTiming();
const controls = h('div', { class: 'lab-controls' },
  h('input', { type: 'search', placeholder: 'Find a move…', value: S.q, oninput: (e) => { S.q = e.target.value.trim().toLowerCase(); S.i = 0; keep(); drawList(); drawInfo(); } }),
  sel('Type', [['', 'All'], ...types.map((t) => [t, t])], 'type', () => { S.i = 0; drawList(); drawInfo(); }),
  sel('Place', PLACES.map((p) => [p, p]), 'place', build),
  sel('Weather', WEATHERS, 'weather', play),
  sel('Time of day', [['day', 'Day'], ['dusk', 'Dusk'], ['night', 'Night']], 'tod', build),
  sel('Hits (multi-hit moves)', [['auto', 'Average'], ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => [n, `${n}`])], 'hits'),
  sel('Magnitude', [4, 5, 6, 7, 8, 9, 10].map((n) => [n, `${n} (${MAG[n]} power)`]), 'mag'),
  sel('Graphics', [['potato', 'Potato'], ['low', 'Low'], ['medium', 'Medium'], ['high', 'High'], ['ultra', 'Ultra']], 'quality', build),
  sel('Target', [['Testdummy', 'Test dummy'], ...['Mew', 'Snorlax', 'Pikachu', 'Gyarados', 'Charizard', 'Onix', 'Wailord', 'Joltik'].map((n) => [n, n])], 'foe', build),
  h('div', { class: 'lab-row' }, chk('Miss', 'miss'), chk('Critical hit', 'crit')),
  h('div', { class: 'lab-row' }, h('button', { onclick: () => go(-1) }, '◀ Prev'), h('button', { class: 'primary', onclick: play }, '▶ Play again'), h('button', { onclick: () => go(1) }, 'Next ▶')),
  h('p', { class: 'dim' }, 'Keys: ← / → previous / next move (plays it), Space or Enter plays it again, 1 marks it right, 2 needs work.'),
  h('details', { class: 'lab-field' }, h('summary', null, 'Field: terrain, hazards, screens, rooms'),
    sel('Terrain', TERRAINS, 'terrain', play),
    sel('On which side', [['foe', 'Target’s side'], ['mine', 'Your side'], ['both', 'Both sides']], 'fieldSide', play),
    ...HAZARDS.map(([k, label, max]) => (max ? h('label', null, h('span', null, label), h('select', { onchange: (e) => { S.hz = { ...S.hz, [k]: Number(e.target.value) || 0 }; keep(); play(); } }, Array.from({ length: max + 1 }, (_, i) => h('option', { value: i, selected: (S.hz?.[k] ?? 0) === i }, i ? `${i} layer${i > 1 ? 's' : ''}` : 'None'))))
      : h('label', { class: 'lab-chk' }, h('input', { type: 'checkbox', checked: !!S.hz?.[k], onchange: (e) => { S.hz = { ...S.hz, [k]: e.target.checked }; keep(); play(); } }), label))),
    sel('Room', [['', 'None'], ['trickroom', 'Trick Room'], ['wonderroom', 'Wonder Room'], ['magicroom', 'Magic Room']], 'room', play),
    chk('Gravity', 'gravity', play)),
  timingBox,
  sel('Speed (slow motion)', [[1, 'Normal'], [0.5, '½ speed'], [0.25, '¼ speed'], [0.1, '1/10 speed']], 'speed', () => TW.set(Number(S.speed) || 1)),
  h('div', { class: 'lab-row' }, exportBtn, importBtn, fileIn));
host.append(h('div', { class: 'lab' }, h('div', { class: 'lab-side' }, h('h1', null, 'Battle Lab'), controls, listEl), h('div', { class: 'lab-main' }, h('div', { class: 'lab-left' }, stageBox, info), ovBox)));
const onKey = (e) => {
  if (!host.isConnected) return;
  if (/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName ?? '')) return;
  if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { e.preventDefault(); go(1); }
  else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { e.preventDefault(); go(-1); }
  else if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); play(); }
  else if (e.key === '1' || e.key === '2') { const m = cur(); if (!m) return; notes[m.id] = { ...(notes[m.id] ?? {}), mark: e.key === '1' ? 'ok' : 'bad' }; saveNotes(); drawInfo(); drawList(); }
};
addEventListener('keydown', onKey);
TW.set(Number(S.speed) || 1);
try { window.__labStage = () => stage; } catch { /* fine */ }
build(); drawList(); drawInfo();
const first = setTimeout(play, 1400);
return {
  destroy() {
    clearTimeout(first);
    removeEventListener('keydown', onKey);
    try { stage?.destroy(); } catch { /* fine */ }
    TW.uninstall();
  },
};
}
