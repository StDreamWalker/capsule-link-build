// The Battle Lab's picks for each move (camera, animation, approach, particles, colours…), kept on this device,
// and used by every battle too: what you see in the lab is what battles do.
//   labPick(moveId) → the override for one play of that move (one of each list picked at random), or null
//   labTimingSaved() → the lab's Timing panel (extra time for each moment)
export const NOTES_KEY = 'clMoveLabNotes';
export const SET_KEYS = ['shape', 'hitfx']; // (these are all used together; the rest, one each play)
export const LIST_KEYS = ['cam', 'intro', 'kind', 'appr', 'vol', 'impact', 'react', 'shape', 'hitfx'];
export function normOv(ov) {
  const o = {};
  for (const [k, v] of Object.entries(ov ?? {})) {
    if (k === 'remap') { if (v && typeof v === 'object' && Object.keys(v).length) o.remap = { ...v }; continue; }
    if (k === 'col' || k === 'col2') { const L = (Array.isArray(v) ? v : [v]).filter(Boolean); if (L.length) o[k] = L; continue; }
    const L = Array.isArray(v) ? v.filter(Boolean) : v ? [v] : [];
    o[k] = [...new Set(L.map((x) => (k === 'cam' && x === 'plain' ? 'fixed' : x)))];
  }
  return o;
}
// a group still being chosen plays the one clicked last; once marked Done, any of the ones picked, at random
export function pickOv(ov, done = {}) {
  const o = {};
  for (const [k, L] of Object.entries(normOv(ov))) {
    if (!LIST_KEYS.includes(k)) continue;
    if (SET_KEYS.includes(k)) { o[k === 'shape' ? 'shapes' : k] = L.length ? L : 'none'; continue; }
    o[k] = !L.length ? 'none' : done[k] ? L[Math.floor(Math.random() * L.length)] : L[L.length - 1];
  }
  return Object.keys(o).length ? o : null;
}
let cache = null, cacheAt = 0;
function notes() {
  // (read again at most every half second: the lab may have just changed them)
  const now = Date.now();
  if (cache && now - cacheAt < 500) return cache;
  try { cache = JSON.parse(localStorage.getItem(NOTES_KEY) || '{}') || {}; } catch { cache = {}; }
  cacheAt = now;
  return cache;
}
// several animations picked for one move: one after another (default: each starts where the last one lands —
// a projectile, then a geyser where it hits), all at once, or a different one each play
export const KIND_MODES = [['chain', 'One after another (each starts where the last lands)'], ['together', 'All at once'], ['random', 'A different one each play']];
export function withKinds(p, n) {
  const L = normOv(n?.ov).kind ?? [];
  const mode = n?.kindMode ?? 'chain';
  if (L.length > 1 && mode !== 'random') { p.kinds = L; p.kind = L[0]; p.kindMode = mode; }
  return p;
}
/** The full override for one play of a move (as the lab plays it), or null if the lab has nothing for it. */
export function labPick(moveId) {
  const id = String(moveId ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');
  const n = notes()[id];
  if (!n) return null;
  const p = pickOv(n.ov, n.ovDone ?? {}) ?? {};
  if (n.ovShort) p.short = true;
  if (n.ovDuring) p.during = true;
  if (n.ovPic) p.pic = true;
  if (n.ov?.remap && Object.keys(n.ov.remap).length) p.remap = n.ov.remap;
  withKinds(p, n);
  return Object.keys(p).length ? p : null;
}
export function labTimingSaved() {
  try { return JSON.parse(localStorage.getItem('clMoveLabState') || '{}')?.timing ?? {}; } catch { return {}; }
}
