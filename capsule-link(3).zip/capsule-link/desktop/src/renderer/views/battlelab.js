// The Battle Lab: the battle stage with every move a click away (to see how each one looks), sharing an app
// with the Data Lab — a big yellow button swaps back to it, and Home is always one click away.
import { h, toast } from '../../../../shared/ui/dom.js';
import { loadShowdown } from '../../../../shared/ui/showdownWild.js';
import { mountBattleLab } from '../../../../tools/movelab/lab.js';
import { labSwitch } from './datalab.js';

export function battleLabView(app) {
  const host = h('div', { class: 'blab blab-host' }, h('p', { class: 'dim', style: { padding: '16px' } }, 'Opening the Battle Lab…'));
  const el = h('div', { class: 'battlelab' }, labSwitch(app, 'battle'), host);
  let lab = null, gone = false;
  return {
    el,
    async mounted() {
      try {
        await loadShowdown(); // (Showdown's move data: every move the lab can play)
        if (gone) return;
        host.replaceChildren();
        lab = mountBattleLab(host, { resolve: (p) => app.textures?.[String(p).toLowerCase()] ?? null }); // (the app's pictures, as battles use them)
      } catch (e) { console.error(e); if (!gone) { host.replaceChildren(h('p', { class: 'dim', style: { padding: '16px' } }, `The Battle Lab couldn’t open: ${e.message}`)); toast(e.message, 'err'); } }
    },
    dispose() { gone = true; try { lab?.destroy(); } catch { /* fine */ } },
    update() {},
  };
}
