// Talking with them, properly: what you mean (understand.js) answered from what the game really knows about
// each one — its tastes, what it's done and how often, what it's good at, its friends, the songs you've played
// it, the deals and promises it's holding you to, and what happened today. Answers are their own, true to them,
// and they remember what they just said (so "why?" and "really?" work).
//
//   converseOne(idx, save, c, text, t, opts)  → a reply ({ note, bubble, emote, mood, yes, act, invite, exact }) or
//                                                null when it's something the older chat rules handle
//   groupAnswers(idx, save, uids, parse, t)   → [{ uid, text, pic, inv? }] for "who likes…", "who's the fastest"…,
//                                                or null when it isn't one of those
//   tasteOf(idx, save, c, what)               → { score -1…1, label, kind, why, known, n }
//   reasonsFor(idx, save, c, t)               → [{ w, text, pic }] what's making it feel the way it does
//   namesFor(idx, save, uids)                 → [{ uid, names }] for understand()
import { understand } from './understand.js';
import { activityIn, GENRE_LABEL, actById, ACTS } from './lexicon.js';
import { tasteFor, INVITES, volunteers } from './invite.js';
import { aptitude, activityOf } from './activities.js';
import { displayName, speciesOf, calcStats } from './creature.js';
import { topPrefs } from './memory.js';
import { friendsOf } from './bonds.js';
import { allFoods } from './shop.js';
import { isAsleep, mood, tickNeeds, favorites } from './care.js';
import { cravingOf } from './dayMemory.js';
import { temperStyle } from './personality.js';
import { genreTaste, hearMusic, favouriteGenres, heardSongs, songKey } from './music.js';
import { owedOf, makeDeal, promise, keenOn } from './promises.js';
import { petReply, loreReply, typeAnswer } from './chatter.js';

const DAY = 86400000;
const INV = Object.fromEntries(INVITES.map((i) => [i.id, i]));
const hash = (s) => { let x = 2166136261; for (let i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); } return ((x >>> 0) % 10007) / 10007; };
const pickOf = (seed, arr) => arr[Math.floor(hash(seed) * arr.length) % arr.length];
const cap = (s) => String(s).charAt(0).toUpperCase() + String(s).slice(1);
const an = (w) => (/^[aeiou]/i.test(String(w)) ? 'an' : 'a');
const listOf = (a) => (a.length < 2 ? a.join('') : `${a.slice(0, -1).join(', ')} and ${a.at(-1)}`);
export function ago(then, t = Date.now()) {
  const d = t - then;
  if (d < 10 * 60000) return 'just now';
  if (d < 3 * 3600000) return 'earlier';
  const a = new Date(then), b = new Date(t);
  if (a.toDateString() === b.toDateString()) return 'earlier today';
  const days = Math.round((new Date(b.toDateString()) - new Date(a.toDateString())) / DAY);
  if (days === 1) return 'yesterday';
  if (days < 7) return `${days} days ago`;
  if (days < 14) return 'last week';
  if (days < 60) return `${Math.round(days / 7)} weeks ago`;
  return 'a long time ago';
}
const styleOf = (idx, c) => { try { return temperStyle(idx, c); } catch { return 'calm'; } };

/** The names each one answers to (for understand). */
export function namesFor(idx, save, uids = null) {
  const list = uids ? uids.map((u) => save.creatures?.[u]).filter(Boolean) : Object.values(save.creatures ?? {}).filter((c) => !c.egg);
  return list.map((c) => ({ uid: c.uid, names: [displayName(idx, c), c.nickname, speciesOf(idx, c)?.name].filter(Boolean) }));
}

// ---------- tastes ----------
// words for things they come to like or dislike through what they experience (memory.js keys)
const PREF_WORDS = [
  [/\brain(?:y|s|ing)?\b/, 'weather:rain'], [/\bsun(?:ny|shine)?\b/, 'weather:sun'], [/\bsnow(?:y|ing)?\b/, 'weather:snow'], [/\bstorms?\b|\bthunder\w*/, 'weather:storm'], [/\bfog(?:gy)?\b|\bmist\b/, 'weather:fog'],
  [/\bwind(?:y)?\b/, 'weather:wind'], [/\bcold\b|\bwinter\b/, 'weather:cold'], [/\bhot\b|\bheat\b|\bsummer\b/, 'weather:hot'], [/\bclouds?\b|\bcloudy\b/, 'weather:clouds'],
  [/\bnights?\b|\bdark\b/, 'time:night'], [/\bmornings?\b|\bdawn\b|\bsunrise\b/, 'time:dawn'], [/\bsunsets?\b|\bdusk\b|\bevenings?\b/, 'time:dusk'], [/\bdaytime\b/, 'time:day'],
  [/\bbeach(?:es)?\b|\bseaside\b/, 'place:beach'], [/\bparks?\b/, 'place:park'], [/\bcity\b|\btown\b|\bstreets?\b/, 'env:urban'], [/\bwoods\b|\bforests?\b/, 'env:forest'],
  [/\bwater\b|\bsea\b|\bocean\b|\blakes?\b|\brivers?\b/, 'env:water'], [/\bmountains?\b|\bhills?\b/, 'env:mountain'], [/\bdesert\b/, 'env:desert'], [/\bcaves?\b|\bunderground\b/, 'env:cave'],
  [/\bcar rides?\b|\bcars?\b|\bdriving\b/, 'activity:car'], [/\bbeing brushed\b|\bbrushing\b/, 'activity:brush'], [/\bfields?\b|\bmeadows?\b/, 'env:plains'],
];
function foodIn(idx, obj) {
  const s = String(obj ?? '').toLowerCase();
  if (!s) return null;
  return allFoods(idx).find((f) => f.name && new RegExp(`\\b${String(f.name).toLowerCase().replace(/\s*berry$/, '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`).test(s)) ?? null;
}
const memWith = (c, test) => [...(c.memories ?? [])].reverse().find((m) => test(m));

/**
 * How it feels about something: a thing to do, a kind of music, a food, the weather, another creature here, or
 * anything at all (an opinion of its own, always the same for the same thing). what: { act, genre, obj, about }.
 * → { score -1…1, label, kind, why, known, n, since }
 */
export function tasteOf(idx, save, c, { act = null, genre = null, obj = '', about = null } = {}) {
  const nm = displayName(idx, c);
  // another creature
  if (about && save.creatures?.[about]) {
    const o = save.creatures[about];
    if (o.uid === c.uid) return { score: 0.6, label: 'itself', kind: 'self', known: true, why: null };
    const b = c.bonds?.[o.uid] ?? 0, fr = friendsOf(c).some((f) => f.uid === o.uid);
    return { score: Math.max(-1, Math.min(1, b / 70 - 0.15 + (fr ? 0.3 : 0))), label: displayName(idx, o), kind: 'creature', known: b > 0, why: fr ? `they're best friends` : b >= 30 ? `they spend a lot of time together` : b > 0 ? `they've played together a little` : `they haven't really met properly` };
  }
  // a kind of music
  if (genre) {
    const songs = heardSongs(c).filter((x) => x.genre === genre), fav = songs.filter((x) => x.op >= 1).sort((a, b) => b.op - a.op)[0];
    const sc = genreTaste(idx, c, genre);
    return { score: sc, label: GENRE_LABEL[genre] ?? genre, kind: 'music', known: songs.length > 0, n: songs.reduce((a, x) => a + (x.n ?? 1), 0), why: fav ? `it loves “${fav.title ?? GENRE_LABEL[genre]}”, the one you played it` : songs.length ? `it's heard some with you` : sc > 0.4 ? `it's just its kind of thing` : null };
  }
  // a food
  const food = foodIn(idx, obj);
  if (food) {
    const v = c.prefs?.[`food:${food.id}`] ?? 0, fav = favorites(idx, c).berry === food.id, crave = cravingOf(idx, c) === food.id;
    const sc = Math.max(-1, Math.min(1, v / 6 + (fav ? 0.7 : 0) + (crave ? 0.3 : 0) + (v === 0 && !fav ? (hash(`${c.uid}|food|${food.id}`) - 0.5) * 0.5 : 0)));
    return { score: sc, label: food.name, kind: 'food', item: food.id, known: v !== 0 || fav, why: fav ? `it's always been its favourite` : crave ? `it's been craving one all day` : v >= 3 ? `it's had plenty and loves them` : v <= -3 ? `it's had them before and didn't like them` : null };
  }
  // a thing to do
  const a = act ?? activityIn(obj);
  if (a) {
    const inv = a.inv ?? a.id;
    let tf = 0; try { tf = tasteFor(idx, c, inv); } catch { /* fine */ }
    const pref = a.pref ? (c.prefs?.[a.pref] ?? 0) : (c.prefs?.[`activity:${a.act ?? inv}`] ?? 0);
    const n = (c.didCount?.[inv] ?? 0) + (a.act ? (c.didCount?.[a.act] ?? 0) : 0) + (c.recentDid?.[inv]?.length && !c.didCount?.[inv] ? c.recentDid[inv].length : 0);
    const sc = Math.max(-1, Math.min(1, tf * 0.75 + (pref / 10) * 0.55));
    const m = memWith(c, (x) => (x.keys ?? []).some((k) => k === a.pref || k === `activity:${a.act ?? inv}`) || a.re.test(String(x.text ?? '').toLowerCase()));
    const why = m && sc > 0.2 ? `it has ever since ${String(m.text).replace(/\.\s*Ever since.*$/, '').replace(/\.$/, '').replace(/^[A-Z]/, (x) => x.toLowerCase())} (${ago(m.t)})`
      : n >= 3 ? `it's done it ${n} times with you` : sc > 0.45 ? `it's always been drawn to it` : sc < -0.3 && n ? `it's tried it and wasn't keen` : null;
    return { score: sc, label: a.ing ?? a.label, kind: 'act', act: a, known: n > 0 || pref !== 0, n, why, memory: m ?? null };
  }
  // the weather, places, times of day…
  const pw = PREF_WORDS.find(([re]) => re.test(String(obj ?? '').toLowerCase()));
  if (pw) {
    const v = c.prefs?.[pw[1]] ?? 0;
    const sc = Math.max(-1, Math.min(1, v / 6 + (hash(`${c.uid}|${pw[1]}`) - 0.5) * 0.6));
    const m = memWith(c, (x) => (x.keys ?? []).includes(pw[1]));
    return { score: sc, label: obj, kind: 'pref', key: pw[1], known: v !== 0, why: m ? `ever since ${String(m.text).replace(/\.\s*Ever since.*$/, '').replace(/\.$/, '').replace(/^[A-Z]/, (x) => x.toLowerCase())}` : v >= 3 ? `it's had some lovely times in it` : v <= -3 ? `it's had some bad times in it` : null };
  }
  // anything else: its own steady opinion (the same thing always gets the same answer), leaning on its temper
  const lean = { playful: 0.12, bold: 0.05, calm: 0, lazy: -0.02, shy: -0.08 }[styleOf(idx, c)] ?? 0;
  const sc = Math.max(-1, Math.min(1, (hash(`${c.uid}:op:${String(obj).toLowerCase()}`) - 0.45) * 1.6 + lean));
  return { score: sc, label: obj || 'that', kind: 'other', known: false, why: null, nm };
}
// how it feels about something, said its own way (and differently when it's never really tried it)
function feelPhrase(ts, style, seed) {
  const L = ts.label, sc = ts.score, tried = ts.known || ts.kind === 'other' || ts.kind === 'pref';
  const P = (a) => pickOf(seed, a);
  if (sc >= 0.6) return tried ? P([`loves ${L}`, `adores ${L}`, `can't get enough of ${L}`]) : P([`is itching to try ${L}`, `is sure it would love ${L}`]);
  if (sc >= 0.25) return tried ? P([`likes ${L}`, `enjoys ${L}`, `is quite into ${L}`]) : P([`thinks it'd like ${L}`, `is curious about ${L}`]);
  if (sc >= -0.15) return tried ? P([`can take ${L} or leave it`, `is so-so about ${L}`, `doesn't mind ${L}`]) : style === 'shy' ? `is a bit unsure about ${L}` : P([`isn't sure about ${L} yet`, `hasn't made its mind up about ${L}`]);
  if (sc >= -0.5) return tried ? P([`isn't keen on ${L}`, `doesn't really like ${L}`]) : P([`doesn't think ${L} is its thing`, `isn't drawn to ${L}`]);
  return tried ? P([`really dislikes ${L}`, `can't stand ${L}`]) : P([`wants nothing to do with ${L}`, `is pretty sure it'd hate ${L}`]);
}
const likeWord = (sc) => (sc >= 0.6 ? 'loves' : sc >= 0.25 ? 'likes' : sc >= -0.15 ? 'is so-so about' : sc >= -0.5 ? "isn't keen on" : 'really dislikes');

// ---------- skill and experience ----------
const SKILL_STAT = { race: 'spe', tag: 'spe', obstacle: 'spe', battle: null, tug: 'atk', fly: 'spe', swim: 'spe', climb: 'atk', hideseek: 'spe' };
/** How good it is at something: { score 0…1, note }. */
export function skillAt(idx, c, act) {
  if (!act) return { score: 0.5, note: '' };
  if (act.act) { let ap = null; try { ap = aptitude(idx, c, act.act); } catch { /* fine */ } if (ap) return { score: ap.score, note: ap.perks?.[0] ?? '' }; }
  const st = (() => { try { return calcStats(idx, c); } catch { return {}; } })();
  const sp = speciesOf(idx, c), types = (sp?.types ?? []).map((x) => String(idx.types?.get?.(x)?.name ?? x).toLowerCase()).join(' ');
  if (act.id === 'battle') { const lv = c.level ?? 1, tot = Object.values(st).reduce((a, b) => a + (b || 0), 0); return { score: Math.min(1, lv / 70 * 0.6 + Math.min(1, tot / 700) * 0.4), note: `level ${lv}, ${['hp', 'atk', 'def', 'spa', 'spd', 'spe'].sort((a, b) => (st[b] ?? 0) - (st[a] ?? 0)).slice(0, 1).map((k) => ({ hp: 'tough as anything', atk: 'hits hard', def: 'hard to hurt', spa: 'strong special moves', spd: 'shrugs off special moves', spe: 'very quick' })[k])[0]}` }; }
  if (act.id === 'swim') return { score: /water|ice/.test(types) ? 0.9 : /fire|rock|ground/.test(types) ? 0.15 : 0.45, note: /water/.test(types) ? 'born to swim' : /fire|rock|ground/.test(types) ? 'not one for water' : '' };
  if (act.id === 'fly') return { score: /flying|dragon/.test(types) ? 0.9 : /psychic|ghost/.test(types) ? 0.6 : 0.1, note: /flying/.test(types) ? 'has wings for it' : '' };
  const key = SKILL_STAT[act.id];
  if (key) { const v = st[key] ?? 50; return { score: Math.max(0, Math.min(1, v / ((c.level ?? 1) * 1.6 + 40))), note: key === 'spe' ? (v > (c.level ?? 1) * 1.2 + 25 ? 'quick on its feet' : 'not the quickest') : '' }; }
  return { score: 0.4 + (tasteForSafe(idx, c, act.inv) + 1) * 0.15, note: '' };
}
const tasteForSafe = (idx, c, k) => { try { return tasteFor(idx, c, k); } catch { return 0; } };
/** Whether (and how much) it's done something: { n, last }. */
export function doneOf(c, act) {
  if (!act) return { n: 0, last: null };
  const keys = [act.inv, act.act, act.id].filter(Boolean);
  const n = keys.reduce((a, k) => Math.max(a, c.didCount?.[k] ?? 0, c.recentDid?.[k]?.length ?? 0), 0) + (act.pref && (c.prefs?.[act.pref] ?? 0) !== 0 && !keys.some((k) => c.didCount?.[k]) ? 1 : 0);
  const last = keys.map((k) => c.recentDid?.[k]?.at(-1) ?? c.didLast?.[k] ?? null).filter(Boolean).sort((a, b) => b - a)[0] ?? null;
  const memHit = memWith(c, (m) => act.re.test(String(m.text ?? '').toLowerCase()));
  return { n: Math.max(n, memHit ? 1 : 0), last: last ?? memHit?.t ?? null, memory: memHit ?? null };
}

// ---------- why it feels the way it does ----------
/** What's on its mind: [{ w (+ happy / − unhappy), text, pic }], strongest first. */
export function reasonsFor(idx, save, c, t = Date.now()) {
  const out = [];
  const n = c.needs ?? {}, notes = (c.today?.notes ?? []).filter((x) => t - x.t < DAY);
  for (const o of owedOf(c)) out.push({ w: 1.6, pic: o.prize?.icon ?? '🏆', text: o.won ? `it won ${o.prize?.label ?? 'a prize'} in ${o.won} and can't wait for it` : `you promised it ${o.prize?.label ?? 'something'}, and it's been looking forward to it ever since`, key: `owed:${o.prize?.kind}` });
  if (c.lastKept && t - c.lastKept.t < DAY) out.push({ w: 1.5, pic: '🎉', text: c.lastKept.won ? `it finally got ${c.lastKept.what ?? 'the prize'} it won in ${c.lastKept.won}` : `it finally got ${c.lastKept.what ?? 'what'} you promised it`, key: 'kept' });
  if (c.lastBroken && t - c.lastBroken.t < 3 * DAY) out.push({ w: -1.4, pic: '💔', text: `you promised it ${c.lastBroken.label ?? 'something'} and it never happened`, key: 'broken' });
  const won = [...notes].reverse().find((x) => x.kind === 'won'), lost = [...notes].reverse().find((x) => x.kind === 'lost');
  if (won) out.push({ w: 1.1, pic: '🏆', text: `it won ${won.key} ${ago(won.t, t)}`, key: 'won' });
  if (lost && !won) out.push({ w: -0.5, pic: '😤', text: `it lost ${lost.key}${lost.to && save.creatures?.[lost.to] ? ` to ${displayName(idx, save.creatures[lost.to])}` : ''} ${ago(lost.t, t)}`, key: 'lost' });
  if ((c.upsetUntil ?? 0) > t) out.push({ w: -1.5, pic: '😠', text: `it's still cross about ${c.upsetReason ?? 'earlier'}`, key: 'upset' });
  const crave = cravingOf(idx, c, t), food = crave && idx.items?.get?.(crave)?.name;
  if (crave && c.today?.craving?.satisfied) out.push({ w: 0.9, pic: '🍓', text: `it got the ${food ?? 'treat'} it was craving`, key: 'craving-ok' });
  else if (crave && food) out.push({ w: -0.35, pic: '🍓', text: `it can't stop thinking about ${food}s`, key: 'craving' });
  const song = heardSongs(c).find((x) => t - x.last < DAY && x.op >= 1);
  if (song) out.push({ w: 0.8, pic: '🎵', text: `you played it ${song.title ? `“${song.title}”` : GENRE_LABEL[song.genre] ?? 'music it loves'} ${ago(song.last, t)}`, key: 'song' });
  const pal = notes.filter((x) => x.kind === 'played' && save.creatures?.[x.key]).map((x) => x.key);
  if (pal.length) { const top = [...new Set(pal)].sort((a, b) => pal.filter((x) => x === b).length - pal.filter((x) => x === a).length)[0]; out.push({ w: 0.6, pic: '🤝', text: `it's been playing with ${displayName(idx, save.creatures[top])}`, key: 'friend' }); }
  const core = [...(c.memories ?? [])].reverse().find((m) => m.core && t - m.t < DAY && !m.broken && m.from !== 'game' && !/^(?:Met |Arrived|Hatched|Got their first|Caught|Born)/.test(String(m.text)) && (m.t - (c.metAt ?? 0)) > 3600000);
  if (core && !c.lastKept) out.push({ w: 0.9, pic: '✨', text: String(core.text).replace(/\.$/, '').replace(/^[A-Z]/, (x) => x.toLowerCase()).replace(/^got /, 'it got ').replace(/^won /, 'it won ').replace(/^the first time/, 'the first time'), key: 'core' });
  if ((n.fullness ?? 60) < 30) out.push({ w: -1.0, pic: '🍽️', text: `it's starving`, key: 'hungry' });
  if ((n.energy ?? 60) < 25) out.push({ w: -0.9, pic: '💤', text: `it's worn out`, key: 'tired' });
  if ((n.hygiene ?? 60) < 25) out.push({ w: -0.6, pic: '🫧', text: `it feels grubby`, key: 'grubby' });
  if ((n.joy ?? 60) < 30) out.push({ w: -0.6, pic: '😐', text: `it's bored`, key: 'bored' });
  if ((n.fullness ?? 60) > 85 && (n.energy ?? 60) > 70 && (n.joy ?? 60) > 70) out.push({ w: 0.5, pic: '😊', text: `it's well fed, rested and having a good day`, key: 'well' });
  return out.sort((a, b) => Math.abs(b.w) - Math.abs(a.w));
}
const POSWORD = /happy|excited|cheer|bouncy|smil|glad|good mood|great mood|chipper|giddy|pleased|proud|hyper|energetic|pumped|thrilled/;
const NEGWORD = /sad|grump|upset|down|quiet|cross|mad|angry|tired|sulk|moody|blue|cranky|grouchy|mopey|lonely|bad mood|scared|nervous|worried|droopy|long face|frown|pout|glum|gloomy/;

// ---------- remembering ----------
const STOPW = new Set('the a an and or but to of in on at for with you your i me my we our is are was were be been it its this that these those do does did have has had so very just really like what when where who how why can could would should will not that time we when remember there about from up out get got go going went some any all more much too then than if as by again'.split(' '));
const stem = (w) => w.replace(/(?:ing|ed|es|s)$/, '');
function recallAbout(idx, save, c, obj, t) {
  const words = String(obj ?? '').toLowerCase().replace(/@n/g, ' ').match(/[a-z']{3,}/g)?.filter((w) => !STOPW.has(w)).map(stem) ?? [];
  const pool = [
    ...(c.memories ?? []).map((m) => ({ t: m.t, text: m.text, w: m.core ? 1.2 : 1 })),
    ...(c.journal ?? []).map((m) => ({ t: m.t, text: m.text, w: 0.8 })),
    ...heardSongs(c).map((x) => ({ t: x.last, text: `you played it ${x.title ? `“${x.title}”${x.artist ? ` by ${x.artist}` : ''}` : GENRE_LABEL[x.genre] ?? 'some music'}${x.n > 1 ? ` (${x.n} times now)` : ''} — it ${x.op >= 1 ? 'loved it' : x.op >= 0.3 ? 'liked it' : x.op > -0.3 ? "wasn't sure about it" : "didn't like it"}`, w: 1, extra: `${x.genre ?? ''} music song ${GENRE_LABEL[x.genre] ?? ''}` })),
    ...(c.chat?.facts ?? []).map((f) => ({ t: f.t, text: f.kind === 'plan' ? `you were going to ${f.obj}` : f.kind === 'done' ? `you ${f.verb} ${f.obj}` : f.kind === 'pref' ? `you ${f.sign > 0 ? 'love' : "can't stand"} ${f.obj}` : `you were feeling ${f.obj}`, w: 0.9 })),
    ...owedOf(c).map((o) => ({ t: o.t, text: o.won ? `it won ${o.prize?.label} in ${o.won} — and it's still waiting for it` : `you promised it ${o.prize?.label}`, w: 1.3, extra: 'promise won deal prize race' })),
    ...((c.today?.notes ?? []).filter((x) => x.kind === 'won' || x.kind === 'lost').map((x) => ({ t: x.t, text: x.kind === 'won' ? `it won ${x.key}` : `it lost ${x.key}${x.to && save.creatures?.[x.to] ? ` to ${displayName(idx, save.creatures[x.to])}` : ''}`, w: 1.1 }))),
  ].filter((m) => m.text);
  if (!words.length) return pool.filter((m) => m.w >= 1).sort((a, b) => b.t - a.t)[0] ?? null;
  let best = null, bs = 0;
  for (const m of pool) {
    const mw = new Set(`${m.text} ${m.extra ?? ''}`.toLowerCase().match(/[a-z']{3,}/g)?.map(stem) ?? []);
    const hit = words.filter((w) => mw.has(w)).length;
    if (!hit) continue;
    const sc = (hit / words.length) * m.w + Math.max(0, 0.2 - (t - m.t) / (60 * DAY));
    if (sc > bs) { bs = sc; best = m; }
  }
  return bs >= 0.34 ? best : null;
}

// ---------- the replies ----------
// "because…", in its own way
const because = (nm, why, seed) => pickOf(`${seed}:why`, [`${nm} thinks about it: ${why}.`, `${nm}'s reason? ${cap(why)}.`, `${nm} tries to tell you: ${why}.`, `Simple, as far as ${nm} is concerned: ${why}.`]);
const R = (note, extra = {}) => ({ note, exact: true, emote: 'note', mood: 'content', bubble: { kind: 'emoji', e: '💬' }, ...extra });
const E = (e) => ({ kind: 'emoji', e });
const stateCtx = (c, t, ctx) => { c.talkCtx = { t, ...ctx }; };

/** "Who likes…?", "who's the fastest?", "who's been fishing?": each one's real answer, or null. */
export function groupAnswers(idx, save, uids, parse, t = Date.now()) {
  const st = parse?.stance;
  if (!GROUP_STANCES.includes(st)) return null;
  const pool = parse.compare?.length ? parse.compare : uids;
  const rows = [];
  for (const uid of pool) {
    const c = save.creatures?.[uid];
    if (!c || c.egg) continue;
    try { tickNeeds(idx, c, t); } catch { /* fine */ }
    const row = answerFor(idx, save, c, parse, t);
    if (row) rows.push({ uid, ...row });
  }
  if (!rows.length) return null;
  rows.sort((a, b) => (parse.neg ? a.v - b.v : b.v - a.v) * (st === 'dislike' || (st === 'stat' && parse.low) ? -1 : 1));
  return rows;
}
export const GROUP_STANCES = ['like', 'dislike', 'skill', 'done', 'stat', 'weak', 'strong', 'knows', 'evolve', 'isType'];
/** One creature's own answer to a "who…?" question: { text, pic, v (to sort by), inv? }. */
function answerFor(idx, save, c, p, t) {
  const nm = displayName(idx, c), st = p.stance;
  if (['weak', 'strong', 'knows', 'evolve', 'isType'].includes(st)) return typeAnswer(idx, save, c, p);
  const what = { act: p.act, genre: p.genre, obj: p.obj, about: p.about?.[0] ?? null };
  if (st === 'like' || st === 'dislike') {
    const ts = tasteOf(idx, save, c, what);
    const why = ts.why ? ` (${ts.why})` : '';
    const text = ts.kind === 'creature' ? `${nm} ${ts.score >= 0.6 ? `adores ${ts.label}` : ts.score >= 0.25 ? `likes ${ts.label}` : ts.score >= -0.15 ? `doesn't know ${ts.label} that well` : `doesn't get on with ${ts.label}`}${why}.`
      : `${nm} ${feelPhrase(ts, styleOf(idx, c), `${c.uid}:${ts.label}`)}${why}.`;
    const inv = ts.act && ts.score > 0.45 ? INV[ts.act.inv] ?? null : null;
    return { text, pic: ts.score >= 0.6 ? '💕' : ts.score >= 0.25 ? '🙂' : ts.score >= -0.15 ? '😐' : '😖', v: ts.score, inv };
  }
  if (st === 'skill') {
    const a = p.act ?? activityIn(p.obj);
    const sk = skillAt(idx, c, a);
    const word = sk.score >= 0.8 ? 'is a natural at' : sk.score >= 0.6 ? 'is good at' : sk.score >= 0.4 ? 'is all right at' : 'isn’t much good at';
    return { text: `${nm} ${word} ${a?.ing ?? p.obj ?? 'it'}${sk.note ? ` (${sk.note})` : ''}.`, pic: sk.score >= 0.8 ? '🌟' : sk.score >= 0.6 ? '💪' : sk.score >= 0.4 ? '🙂' : '😅', v: sk.score };
  }
  if (st === 'done') {
    const a = p.act ?? activityIn(p.obj);
    const d = doneOf(c, a);
    const thing = a?.ing ?? p.obj ?? 'that';
    const text = d.n ? `${nm} has been ${thing}${d.n > 1 ? ` ${d.n} times` : ''}${d.last ? `, last ${ago(d.last, t)}` : ''}.` : `${nm} has never been ${thing}${(() => { const ts = tasteOf(idx, save, c, what); return ts.score > 0.4 ? ' — and would love to try' : ts.score < -0.3 ? ' — and doesn’t want to' : ''; })()}.`;
    return { text, pic: d.n ? '✅' : '🙅', v: d.n };
  }
  if (st === 'stat') {
    const v = statValue(idx, c, p.stat);
    return { text: `${nm}: ${v.label}.`, pic: v.pic, v: v.v };
  }
  return null;
}
function statValue(idx, c, stat) {
  const sp = speciesOf(idx, c), st = (() => { try { return calcStats(idx, c); } catch { return {}; } })();
  switch (stat) {
    case 'speed': return { v: st.spe ?? 0, label: `Speed ${st.spe ?? '?'}`, pic: '💨' };
    case 'size': { const h = sp?.height ?? sp?.heightm ?? null; return { v: (h ?? 0) * (c.sizeScale ?? 1), label: h ? `${Math.round(h * (c.sizeScale ?? 1) * 100) / 100} m tall` : 'size unknown', pic: '📏' }; }
    case 'weight': { const w = sp?.weight ?? sp?.weightkg ?? null; return { v: w ?? 0, label: w ? `${w} kg` : 'weight unknown', pic: '⚖️' }; }
    case 'age': { const at = c.metAt ?? c.memories?.[0]?.t ?? Date.now(); return { v: Date.now() - at, label: `with you since ${new Date(at).toLocaleDateString()}`, pic: '📅' }; }
    case 'friendship': return { v: c.friendship ?? 0, label: `friendship ${c.friendship ?? 0}`, pic: '💗' };
    case 'hunger': return { v: 100 - (c.needs?.fullness ?? 60), label: (c.needs?.fullness ?? 60) < 30 ? 'starving' : (c.needs?.fullness ?? 60) < 55 ? 'peckish' : 'not hungry', pic: '🍓' };
    case 'tired': return { v: 100 - (c.needs?.energy ?? 60), label: (c.needs?.energy ?? 60) < 25 ? 'worn out' : (c.needs?.energy ?? 60) < 50 ? 'getting sleepy' : 'full of energy', pic: '💤' };
    case 'joy': return { v: c.needs?.joy ?? 60, label: `${mood(c).label.toLowerCase()}`, pic: '😊' };
    case 'level': return { v: c.level ?? 1, label: `level ${c.level ?? 1}`, pic: '⭐' };
    case 'clever': return { v: (st.spa ?? 0) + (st.spd ?? 0) / 2, label: `Sp. Atk ${st.spa ?? '?'}`, pic: '🧠' };
    default: { const tot = (c.level ?? 1) * 4 + Math.max(st.atk ?? 0, st.spa ?? 0); return { v: tot, label: `level ${c.level ?? 1}, ${(st.atk ?? 0) >= (st.spa ?? 0) ? `Attack ${st.atk ?? '?'}` : `Sp. Atk ${st.spa ?? '?'}`}`, pic: '💪' }; }
  }
}

/**
 * Its reply to something said to it (or to everyone, with it listening). null: leave it to the older rules.
 * opts: { group, parse (if already worked out), names }
 */
export function converseOne(idx, save, c, text, t = Date.now(), opts = {}) {
  if (!c || c.egg) return null;
  const p = opts.parse ?? understand(text, { names: opts.names ?? namesFor(idx, save) });
  const nm = displayName(idx, c), seed = `${c.uid}:${p.s}:${Math.floor(t / 60000)}`, style = styleOf(idx, c);
  const asleep = isAsleep(c, t);
  if (asleep) return null; // (asleep: the old rules have their sleepy answers)
  // said to someone else by name? then it's not for this one
  if (p.addressees.length && !p.addressees.includes(c.uid) && !p.about.includes(c.uid) && opts.group) return null;
  const ctx = c.talkCtx && t - c.talkCtx.t < 5 * 60000 ? c.talkCtx : null;
  // "do you like it?", "play that again", "why do you love that?": it means what you were just talking about
  const ref = c.talkRef && t - c.talkRef.t < 10 * 60000 ? c.talkRef : null;
  const PRON = /^(?:it|that|this|them|those|that one|this one|that song|this song|the song|it again|that again|this again)$/;
  if (ref && PRON.test(String(p.obj ?? '').trim())) {
    p.obj = ref.obj ?? p.obj; if (ref.act) p.act = actById(ref.act); if (ref.genre) p.genre = ref.genre;
    if (ref.music) { p.songRef = ref.music; if (p.kind === 'share') Object.assign(p, ref.music); }
  }
  if (p.kind === 'share' && !p.title && !p.genre && ref?.music && /\b(?:again|it|that|this)\b/.test(p.s)) { Object.assign(p, ref.music); p.obj = ref.obj || 'it'; }
  const r = answerKind(idx, save, c, p, t, nm, seed, style, ctx, opts, text);
  // what it was about, for "it" next time
  if (r && (p.obj || p.title || p.genre) && !PRON.test(String(p.obj ?? '').trim())) c.talkRef = { t, obj: p.obj || p.title || '', act: p.act?.id ?? null, genre: p.genre ?? null, music: p.kind === 'share' ? { title: p.title, artist: p.artist, genre: p.genre } : (c.talkRef?.music ?? null) };
  return r;
}
function answerKind(idx, save, c, p, t, nm, seed, style, ctx, opts, text) {
  switch (p.kind) {
    case 'pet': return petReply(idx, save, c, p, t);
    case 'loreQ': return loreReply(idx, save, c, p, t);
    case 'eventQ': return eventReply(idx, save, c, p, t, nm);
    case 'dayQ': return dayReply(idx, save, c, t, nm, seed);
    case 'aboutMe': return aboutMeReply(idx, save, c, p, t, nm, seed);
    case 'thirdQ': return thirdReply(idx, save, c, p, t, nm, seed);
    case 'favQ': return favReply(idx, save, c, p, t, nm, seed);
    case 'preferQ': return preferReply(idx, save, c, p, t, nm, seed);
    case 'goodAtQ': return goodAtReply(idx, save, c, t, nm);
    case 'remark': return remark(idx, save, c, p, t, nm, seed, style);
    case 'share': return share(idx, save, c, p, t, nm, seed, style);
    case 'why': return why(idx, save, c, p, t, nm, seed, ctx);
    case 'followup': return followup(idx, save, c, p, t, nm, seed, ctx, opts);
    case 'remember': return recallReply(idx, save, c, p, t, nm, seed);
    case 'opinionOf': return opinionReply(idx, save, c, p, t, nm, seed);
    case 'tasteQ': return musicTasteReply(idx, save, c, t, nm);
    case 'ynQ': return ynReply(idx, save, c, p, t, nm, seed, style);
    case 'groupQ': {
      // asked of the group, but answered here one at a time (on the phone, or with just this one listening)
      const row = GROUP_STANCES.includes(p.stance) ? answerFor(idx, save, c, p, t) : null;
      if (!row) return null;
      stateCtx(c, t, { kind: 'groupQ', text, topic: p.obj, why: null });
      return R(row.text, { bubble: E(row.pic), mood: row.v > 0.3 ? 'happy' : 'content', yes: row.v > 0.3 });
    }
    case 'deal': {
      // (in the yard the scene makes the deal for everyone at once; this is one of them on its own, on the phone)
      if (opts.group) return null;
      const { reactions } = makeDeal(idx, save, p, [c.uid], t);
      const r = reactions[0];
      if (!r) return null;
      stateCtx(c, t, { kind: 'deal', text, topic: p.prize?.label, why: `it really wants ${p.prize?.label}` });
      return R(r.note, { bubble: E(r.pic), mood: r.keen > 0.5 ? 'happy' : 'content', emote: r.keen > 0.6 ? 'exclaim' : 'note', yes: r.keen > 0.4 });
    }
    case 'promise': {
      const o = promise(idx, save, c, p.prize, t, 'because you promised');
      const keen = keenOn(idx, save, c, p.prize), tr = (c.trust?.kept ?? 0) - (c.trust?.broken ?? 0) * 2;
      const note = tr <= -2 ? `${nm} looks at you sideways. It'll believe it when it sees it — last time you promised something, it never happened.`
        : keen > 0.7 ? pickOf(seed, [`${nm} lights up: ${p.prize.label}${p.when === 'later' ? ' later' : ''}! It can't wait — and it won't forget.`, `${nm} does a happy spin. ${cap(p.prize.label)} — it'll hold you to that!`])
          : keen > 0.4 ? `${nm} nods. ${cap(p.prize.label)} sounds good — it'll hold you to that.` : `${nm} isn't that bothered about ${p.prize.label}, but it'll hold you to it all the same.`;
      stateCtx(c, t, { kind: 'promise', text, topic: p.prize?.label, why: keen > 0.5 ? `it loves ${p.prize.kind === 'walk' ? 'walks' : p.prize.label}` : null });
      return R(note, { bubble: E(p.prize.icon ?? '✨'), mood: keen > 0.5 ? 'happy' : 'content', emote: keen > 0.6 ? 'hearts' : 'note', yes: true, promised: o?.id ?? null });
    }
    default: break;
  }
  // "are you happy?", "are you excited?", "how are you?" — answered with what's actually on its mind
  const fm = /^(?:are|is) (?:you|@n) (?:feeling |still |really )?(happy|excited|sad|okay|ok|alright|all right|good|tired|hungry|bored|upset|angry|mad|cross|scared|nervous|lonely|ready|proud|jealous)\b/.exec(p.body ?? '') ?? (/\bhow (?:are|is) (?:you|@n)(?: feeling| doing| today)?\b|\bhow do you feel\b|\bhow is it going\b/.test(p.body ?? '') ? [null, 'how'] : null);
  if (fm) {
    const rs = reasonsFor(idx, save, c, t), top = rs[0];
    if (!top || Math.abs(top.w) < 0.8) return null; // (nothing in particular: the older "how are you" answers)
    const pos = top.w > 0, w = fm[1];
    const askedPos = POSWORD.test(w) || /ok|alright|all right|good|ready|proud/.test(w), askedNeg = NEGWORD.test(w) || /tired|hungry|bored/.test(w);
    const note = w === 'how' ? `${nm} is ${pos ? 'in a great mood' : 'not having a great time'}: ${top.text}.`
      : askedPos && pos ? `${nm} nods hard. Yes! ${cap(top.text)}.` : askedPos && !pos ? `${nm} shakes its head: ${top.text}.`
        : askedNeg && !pos ? `${nm} nods slowly. ${cap(top.text)}.` : `${nm} isn't ${w} at all — ${top.text}!`;
    stateCtx(c, t, { kind: 'feel', text, topic: w, why: top.text });
    return R(note, { bubble: E(top.pic), mood: pos ? 'happy' : 'meh', emote: pos ? 'hearts' : 'sweat', yes: (askedPos && pos) || (askedNeg && !pos) });
  }
  return null;
}

function remark(idx, save, c, p, t, nm, seed, style) {
  if (p.songRef) { const r = songOpinion(idx, c, { ...p, stance: p.sign < 0 ? 'dislike' : 'like' }, t, nm); if (r) return r; }
  const ts = tasteOf(idx, save, c, { act: p.act, genre: p.genre, obj: p.obj, about: p.about?.[0] ?? null });
  const truth = ts.score * (p.sign ?? 1); // > 0: what you said is right
  const label = ts.kind === 'creature' ? ts.label : ts.label;
  const why = ts.why ? ` ${cap(ts.why)}.` : '';
  let note, pic, moodS = 'content', emote = 'note';
  if (p.sign > 0) {
    if (ts.score >= 0.45) {
      note = p.surprise ? pickOf(seed, [`${nm} gives you a look, as if to say: of course it ${ts.score >= 0.65 ? 'loves' : 'likes'} ${label}!${why}`, `${nm} puffs up, a little offended. It ${ts.score >= 0.65 ? 'loves' : 'likes'} ${label} — always has.${why}`, `${nm} seems pleased you noticed. Yes, it ${ts.score >= 0.65 ? 'really loves' : 'likes'} ${label}.${why}`])
        : pickOf(seed, [`${nm} nods happily: it really does ${ts.score >= 0.65 ? 'love' : 'like'} ${label}.${why}`, `${nm} beams. You know it well — ${label} is ${ts.score >= 0.65 ? 'one of its favourite things' : 'right up its street'}.${why}`]);
      pic = '💕'; moodS = 'happy'; emote = 'hearts';
      if (style === 'shy') note = note.replace(/^(\S+ )/, '$1goes a bit pink, then ');
    } else if (ts.score >= 0.1) {
      note = `${nm} tilts its head: it quite likes ${label}, sure — but it wouldn't call it a favourite.${why}`; pic = '🙂';
    } else if (ts.score > -0.15) {
      note = ts.known ? `${nm} shrugs. It can take ${label} or leave it.` : `${nm} isn't sure how it feels about ${label} — it hasn't really tried it yet.`; pic = '🤷';
    } else {
      note = p.surprise ? pickOf(seed, [`${nm} looks just as surprised as you: it doesn't like ${label} at all. You had it right the first time.${why}`, `${nm} shakes its head. Like ${label}? No — it really doesn't.${why}`])
        : `${nm} shakes its head firmly. It doesn't like ${label}.${why}`;
      pic = '🙅'; moodS = 'meh'; emote = 'sweat';
    }
  } else {
    // "you hate X, don't you?"
    if (ts.score <= -0.15) { note = `${nm} nods: ${label} is not its thing at all.${why}`; pic = '😖'; }
    else if (ts.score >= 0.4) { note = p.surprise ? `${nm} looks hurt that you'd think that. It loves ${label}!${why}` : `${nm} shakes its head: it actually ${ts.score >= 0.65 ? 'loves' : 'likes'} ${label}!${why}`; pic = '💕'; moodS = 'happy'; emote = 'hearts'; }
    else { note = `${nm} wobbles its head: it doesn't hate ${label}, it just isn't fussed.`; pic = '🤷'; }
  }
  stateCtx(c, t, { kind: 'remark', text: p.raw, topic: label, why: ts.why, since: ts.memory?.t ?? null, score: ts.score });
  // loving something it could do right here: it shows you
  const act = ts.score >= 0.65 && ts.act ? { dance: { kind: 'dance' }, sing: { kind: 'dance' }, music: { kind: 'dance' }, swim: { kind: 'jump' }, fly: { kind: 'spin' } }[ts.act.id] ?? null : ts.kind === 'music' && ts.score >= 0.65 ? { kind: 'dance' } : null;
  return R(note, { bubble: E(pic), mood: moodS, emote, yes: truth > 0.15, ...(act ? { act } : {}) });
}

function share(idx, save, c, p, t, nm, seed, style) {
  if (p.obj === 'it' && !p.title && !p.genre) return null; // ("play it again" with nothing played lately: the older rules)
  const m = { title: p.title, artist: p.artist, genre: p.genre };
  // "have you heard X?": it answers from memory, without hearing it now
  if (p.asked) {
    const known = findSong(c, m);
    if (!known) { stateCtx(c, t, { kind: 'shareQ', text: p.raw, topic: p.title ?? GENRE_LABEL[p.genre] }); return R(`${nm} hasn't heard ${p.title ? `“${p.title}”` : GENRE_LABEL[p.genre] ?? 'that'} yet. It looks at you expectantly: play it?`, { bubble: E('🎧'), mood: 'curious', emote: '?', yes: false }); }
    const op = known.op;
    stateCtx(c, t, { kind: 'shareQ', text: p.raw, topic: known.title, why: op >= 1 ? 'it loved it' : op < -0.3 ? "it didn't like it" : null });
    return R(`${nm} remembers ${known.title ? `“${known.title}”` : 'it'} — you played it ${known.n > 1 ? `${known.n} times, last ${ago(known.last, t)}` : ago(known.last, t)}. It ${op >= 1.2 ? 'loves that one' : op >= 0.3 ? 'liked it' : op > -0.3 ? "wasn't sure about it" : "didn't like it one bit"}.`, { bubble: E(op >= 0.3 ? '🎵' : '😐'), mood: op >= 0.3 ? 'happy' : 'content', yes: true });
  }
  const h = hearMusic(idx, c, m, t);
  const L = h.label;
  let note, pic = '🎵', moodS = 'content', emote = 'note', act = null;
  if (h.first) {
    if (h.op >= 1.2) { note = pickOf(seed, [`${nm}'s ears perk up at the first notes of ${L}… it loves it! It's dancing already.`, `${nm} goes completely still, listening to ${L} — then bounces along to every beat. A hit!`, `${nm} has never heard anything like ${L}, and it's thrilled. It wants it again!`]); moodS = 'happy'; emote = 'hearts'; act = { kind: 'dance' }; }
    else if (h.op >= 0.35) { note = pickOf(seed, [`${nm} listens closely to ${L}, then starts bobbing along. It likes it.`, `${nm} sways a little to ${L}. Not bad at all!`]); moodS = 'happy'; act = { kind: 'dance' }; }
    else if (h.op > -0.35) { note = pickOf(seed, [`${nm} listens to ${L} politely. It isn't sure what to make of it yet.`, `${nm} tilts its head through ${L}. Hmm. Maybe it needs another listen.`]); pic = '🤔'; moodS = 'curious'; }
    else { note = pickOf(seed, [`${nm} winces at ${L} and covers its ears. Not its thing at all.`, `${nm} lasts about ten seconds of ${L} before wandering off. Nope.`]); pic = '🙉'; moodS = 'meh'; emote = 'sweat'; }
    if (h.newGenre && h.genre) note += ` It's the first ${GENRE_LABEL[h.genre]} it's ever heard.`;
  } else {
    const was = h.before ?? 0;
    if (h.tired && h.op < 1.5) { note = `${nm} recognises ${L} straight away… but it's heard it a lot today, and its ears droop a little.`; pic = '😮‍💨'; moodS = 'meh'; }
    else if (h.op >= 1.2) { note = h.grew ? `${nm} recognises ${L} and lights up — it's really grown on it. It's one of its favourites now!` : pickOf(seed, [`${nm} knows ${L} from the first note and starts dancing. It loves this one!`, `${nm} squeals: ${L} again! (That's ${h.n} times now, and it still loves it.)`]); moodS = 'happy'; emote = 'hearts'; act = { kind: 'dance' }; }
    else if (h.op >= 0.35) { note = was < 0.35 ? `${nm} remembers ${L} — and this time it's actually enjoying it.` : `${nm} recognises ${L} and bobs along happily.`; moodS = 'happy'; act = { kind: 'dance' }; }
    else if (h.op > -0.35) { note = `${nm} remembers ${L}. Still not sure about it.`; pic = '🤔'; }
    else { note = pickOf(seed, [`${nm} groans: not ${L} again!`, `${nm} recognises ${L} and puts its paws over its ears.`]); pic = '🙉'; moodS = 'meh'; emote = 'sweat'; }
  }
  if (h.memory && style !== 'bold') note += ' It seems to want to remember this one.';
  stateCtx(c, t, { kind: 'share', text: p.raw, topic: L, score: h.op / 2, why: h.op >= 0.35 ? (h.genre && genreTaste(idx, c, h.genre) > 0.35 ? `it loves ${GENRE_LABEL[h.genre]}` : `it just liked the sound of it`) : h.genre && genreTaste(idx, c, h.genre) < -0.2 ? `${GENRE_LABEL[h.genre]} isn't its kind of music` : 'it just didn’t click', since: h.first ? null : c.music?.[h.key]?.first });
  return R(note, { bubble: E(pic), mood: moodS, emote, yes: h.op > 0.35, ...(act ? { act } : {}), music: { key: h.key, op: h.op, first: h.first } });
}

function why(idx, save, c, p, t, nm, seed, ctx) {
  const about = String(p.whyAbout ?? '');
  if (!about || /^(?:that|so|not|is that|do you|did you)\b/.test(about)) { if (ctx?.why) return R(because(nm, ctx.why, seed), { bubble: E('💭') }); }
  const rs = reasonsFor(idx, save, c, t);
  const pos = POSWORD.test(about), neg = NEGWORD.test(about);
  // "why do you like X?" / "why don't you like X?"
  const lk = /^(?:do|did) you (?:not )?(?:like|love|enjoy|hate)\s+(.+)$/.exec(about) ?? /^(?:you )?(?:like|love|enjoy|hate)\s+(.+)$/.exec(about);
  if (lk && /^(?:it|that|this|them|that one|this one)\b/.test(lk[1]) && ctx?.why) {
    const askNeg = /\b(?:not|hate)\b/.test(about), sc = ctx.score ?? 0;
    if (!askNeg && sc < 0.15) return R(`${nm} gives you a look: who said it likes it? ${cap(ctx.why)}.`, { bubble: E('🤨'), mood: 'curious', emote: '?' });
    if (askNeg && sc > 0.15) return R(`${nm} shakes its head: but it does like it! ${cap(ctx.why)}.`, { bubble: E('💕'), mood: 'happy' });
    return R(because(nm, ctx.why, seed), { bubble: E('💭') });
  }
  if (lk) { const ts = tasteOf(idx, save, c, { act: activityIn(lk[1]), obj: lk[1] }); return R(ts.why ? because(nm, ts.why, seed) : `${nm} doesn't really know why — it just ${likeWord(ts.score)} ${ts.label}.`, { bubble: E('💭') }); }
  let r = pos ? rs.find((x) => x.w > 0) : neg ? rs.find((x) => x.w < 0) : rs[0];
  if (!r && (pos || neg)) {
    const m = mood(c, t);
    return R(pos ? `${nm} isn't especially happy right now — it's ${m.label.toLowerCase()}.` : `${nm} isn't down at all — it's ${m.label.toLowerCase()}, really.`, { bubble: E('🤷'), mood: 'curious', emote: '?' });
  }
  if (!r) return R(`${nm} thinks about it, but doesn't know why.`, { bubble: E('🤷'), mood: 'curious', emote: '?' });
  stateCtx(c, t, { kind: 'why', text: p.raw, topic: about, why: r.text });
  return R(because(nm, r.text, seed), { bubble: E(r.pic), mood: r.w > 0 ? 'happy' : 'meh', emote: r.w > 0 ? 'hearts' : 'sweat' });
}

function followup(idx, save, c, p, t, nm, seed, ctx, opts) {
  if (!ctx) return null;
  if (p.what === 'why') {
    if (ctx.why) return R(because(nm, ctx.why, seed), { bubble: E('💭') });
    const rs = reasonsFor(idx, save, c, t)[0];
    return R(rs ? `${nm} isn't sure — though ${rs.text}.` : `${nm} doesn't really know why. It just does.`, { bubble: E('🤷'), mood: 'curious', emote: '?' });
  }
  if (p.what === 'really') {
    const sure = ctx.score == null || Math.abs(ctx.score) > 0.4;
    return R(sure ? pickOf(seed, [`${nm} nods firmly. Really.`, `${nm} stamps its foot: yes, really!`]) : `${nm} wavers… it's honestly not that sure.`, { bubble: E(sure ? '❗' : '🤔'), yes: sure });
  }
  if (p.what === 'since') {
    if (ctx.since) return R(`${nm} thinks back: since ${ago(ctx.since, t)}.`, { bubble: E('📅') });
    return R(`${nm} has always felt that way, as far as it can remember.`, { bubble: E('💭') });
  }
  if (p.what === 'you' && ctx.text && !opts.again) return converseOne(idx, save, c, ctx.text, t, { ...opts, again: true, parse: null });
  return null;
}

function recallReply(idx, save, c, p, t, nm, seed) {
  // a creature: what it remembers of them
  if (p.about?.length && save.creatures?.[p.about[0]] && p.about[0] !== c.uid) {
    const o = save.creatures[p.about[0]], on = displayName(idx, o), b = c.bonds?.[o.uid] ?? 0;
    const m = recallAbout(idx, save, c, on, t);
    return R(m ? `${nm} remembers ${on}: ${String(m.text).replace(/\.$/, '').replace(/^[A-Z]/, (x) => x.toLowerCase())} (${ago(m.t, t)}).` : b > 0 ? `Of course! ${nm} and ${on} ${b >= 30 ? 'are close' : 'have played together'}.` : `${nm} knows ${on}, but they haven't done much together yet.`, { bubble: { kind: 'creature', uid: o.uid, speciesId: o.formId ?? o.speciesId }, mood: 'happy' });
  }
  if (!String(p.obj ?? '').replace(/\b(?:that|this|it|what|me|anything|something)\b/g, '').trim()) return null; // (just "do you remember?": the older rules know what's on its mind today)
  const m = recallAbout(idx, save, c, p.obj, t);
  stateCtx(c, t, { kind: 'remember', text: p.raw, topic: p.obj, since: m?.t ?? null });
  if (!m) return R(pickOf(seed, [`${nm} thinks hard… but it can't remember${p.obj ? ` ${p.obj.replace(/^(?:when |that )/, '')}` : ' that'}.`, `${nm} looks blank. It doesn't remember${p.obj ? ` anything about ${p.obj}` : ' that'}.`]), { bubble: E('❓'), mood: 'curious', emote: '?', yes: false });
  const txt = String(m.text).replace(/\.$/, '');
  return R(`${nm} remembers! ${cap(txt.replace(/^(?:Got|Won|Had|Made|Went|Met|Saw|Learned|Played)\b/, (x) => `It ${x.toLowerCase()}`))} (${ago(m.t, t)}).`.replace(/remembers! (?=It )/, 'remembers! '), { bubble: E('💭'), mood: 'happy', emote: 'hearts', yes: true });
}

function opinionReply(idx, save, c, p, t, nm, seed) {
  const o = save.creatures?.[p.about?.[0]];
  if (!o) return null;
  if (o.uid === c.uid) return R(`${nm} points at itself, confused. That's it!`, { bubble: E('❓'), mood: 'curious', emote: '?' });
  const on = displayName(idx, o), b = c.bonds?.[o.uid] ?? 0, fr = friendsOf(c).some((f) => f.uid === o.uid), back = o.bonds?.[c.uid] ?? 0;
  const shared = recallAbout(idx, save, c, on, t);
  let note, pic;
  if (fr || b >= 60) { note = pickOf(seed, [`${on}? That's ${nm}'s best friend!`, `${nm} looks over at ${on} and its whole face softens. Best friends.`]); pic = '💕'; }
  else if (b >= 30) { note = `${nm} gets on really well with ${on}.${back < 20 ? ` (It wishes ${on} noticed it more.)` : ''}`; pic = '🙂'; }
  else if (b >= 8) { note = `${nm} likes ${on} fine — they've played together a bit, but they're not close yet.`; pic = '🙂'; }
  else { note = `${nm} doesn't really know ${on} yet. It peers at them curiously.`; pic = '👀'; }
  if (shared && b >= 8) note += ` It remembers: ${String(shared.text).replace(/\.$/, '').replace(/^[A-Z]/, (x) => x.toLowerCase())}.`;
  stateCtx(c, t, { kind: 'opinionOf', text: p.raw, topic: on, why: fr ? `they've spent so much time together` : b >= 8 ? `they've played together` : `they haven't met properly yet`, score: b / 60 - 0.2 });
  return R(note, { bubble: { kind: 'creature', uid: o.uid, speciesId: o.formId ?? o.speciesId }, mood: b >= 30 ? 'happy' : 'content', emote: b >= 60 ? 'hearts' : 'note', yes: b >= 20 });
}

/** The last race (or battle) someone here won: { uid, what, t } from what they remember. */
export function lastWin(idx, save, kind = null, lost = false, t = Date.now()) {
  let best = null;
  for (const c of Object.values(save.creatures ?? {})) {
    for (const n of c.today?.notes ?? []) if (n.kind === (lost ? 'lost' : 'won') && (!kind || String(n.key).includes(kind)) && (!best || n.t > best.t)) best = { uid: c.uid, what: n.key, t: n.t, to: n.to ?? null };
    if (!lost) for (const m of c.memories ?? []) if (/^Won (?:a |the )?race/.test(String(m.text)) && (!kind || kind === 'race') && (!best || m.t > best.t)) best = { uid: c.uid, what: String(m.text).replace(/^Won (?:a |the )?/, 'the ').replace(/ against .*$/, '').replace(/\.$/, ''), t: m.t };
  }
  return best;
}
function eventReply(idx, save, c, p, t, nm) {
  const kind = p.act?.id === 'battle' ? 'battle' : p.act?.id === 'race' || /race/.test(p.obj ?? '') ? 'race' : null;
  const w = lastWin(idx, save, kind, p.what === 'lost', t);
  if (!w || !save.creatures?.[w.uid]) return R(`${nm} tries to remember… it doesn't think there's been one lately.`, { bubble: E('🤷'), mood: 'curious', emote: '?' });
  const o = save.creatures[w.uid], on = displayName(idx, o), me = w.uid === c.uid;
  if (p.what === 'lost') return R(me ? `${nm} looks at its feet. It lost ${w.what} (${ago(w.t, t)}).` : `${nm} points at ${on}: it lost ${w.what} (${ago(w.t, t)}).`, { bubble: E(me ? '😔' : '👉'), mood: me ? 'meh' : 'content' });
  stateCtx(c, t, { kind: 'eventQ', text: p.raw, topic: w.what, why: me ? 'it ran faster than anyone' : null });
  return R(me ? `${nm} puffs out its chest: it won ${w.what}! (${cap(ago(w.t, t))}.)` : `${nm} points at ${on}: ${on} won ${w.what} (${ago(w.t, t)}).${(c.today?.notes ?? []).some((n) => n.kind === 'lost' && n.to === w.uid) ? ' It still wants a rematch.' : ''}`, { bubble: me ? E('🏆') : { kind: 'creature', uid: o.uid, speciesId: o.formId ?? o.speciesId }, mood: me ? 'happy' : 'content', emote: me ? 'hearts' : 'note' });
}
function dayReply(idx, save, c, t, nm, seed) {
  const notes = (c.today?.notes ?? []).filter((n) => new Date(n.t).toDateString() === new Date(t).toDateString());
  const bits = [];
  const won = notes.filter((n) => n.kind === 'won').at(-1), lost = notes.filter((n) => n.kind === 'lost').at(-1);
  if (won) bits.push(`won ${won.key}`);
  else if (lost) bits.push(`lost ${lost.key}${lost.to && save.creatures?.[lost.to] ? ` to ${displayName(idx, save.creatures[lost.to])}` : ''}`);
  const kept = notes.filter((n) => n.kind === 'kept').at(-1); if (kept) bits.push(`finally got ${kept.key === 'walk' ? 'its walk' : `what you promised`}`);
  const pals = [...new Set(notes.filter((n) => n.kind === 'played' && save.creatures?.[n.key]).map((n) => n.key))].slice(0, 2).map((u) => displayName(idx, save.creatures[u]));
  if (pals.length) bits.push(`played with ${listOf(pals)}`);
  const ate = notes.filter((n) => n.kind === 'ate').at(-1); if (ate) bits.push(`ate ${an(idx.items?.get?.(ate.key)?.name ?? 'treat')} ${idx.items?.get?.(ate.key)?.name ?? 'treat'}${ate.craved ? ' (the one it was craving!)' : ''}`);
  const song = heardSongs(c).find((x) => new Date(x.last).toDateString() === new Date(t).toDateString()); if (song) bits.push(`listened to ${song.title ? `“${song.title}”` : GENRE_LABEL[song.genre] ?? 'music'} with you`);
  const did = Object.entries(c.didLast ?? {}).filter(([k, v]) => new Date(v).toDateString() === new Date(t).toDateString() && k !== 'race' && actById(k)).map(([k]) => actById(k).ing).slice(0, 2);
  if (did.length) bits.push(`did some ${listOf(did)}`);
  const upset = notes.filter((n) => n.kind === 'upset').at(-1); if (upset) bits.push(`got upset about ${upset.key}`);
  const owed = owedOf(c)[0];
  const m = mood(c, t);
  if (!bits.length) return R(`${nm} has had a quiet day so far — mostly ${m.id === 'sleepy' ? 'dozing' : 'pottering about'}.${owed ? ` It's still looking forward to ${owed.prize?.label}.` : ''}`, { bubble: E('🍃'), mood: 'content' });
  stateCtx(c, t, { kind: 'dayQ', text: 'day', topic: 'today', why: bits[0] });
  return R(`${nm} tells you all about it: it ${listOf(bits)}.${owed ? ` And it's still waiting on ${owed.prize?.label}!` : ''}`, { bubble: E(won ? '🏆' : kept ? '🎉' : '💬'), mood: won || kept ? 'happy' : 'content', emote: 'note' });
}
function aboutMeReply(idx, save, c, p, t, nm, seed) {
  const f = c.friendship ?? 0, tr = c.trust ?? {}, max = idx.ds?.rules?.maxFriendship ?? 255;
  const fr = f / max;
  if (p.what === 'mad') {
    if ((c.upsetUntil ?? 0) > t) return R(`${nm} turns its back: yes. It's cross about ${c.upsetReason ?? 'earlier'}.`, { bubble: E('😤'), mood: 'meh', emote: 'sweat', yes: true });
    if (c.lastBroken && t - c.lastBroken.t < 3 * DAY) return R(`${nm} isn't mad, exactly — but it hasn't forgotten the ${c.lastBroken.label?.replace(/^an? /, '') ?? 'thing'} you promised and never gave it.`, { bubble: E('😕'), mood: 'meh' });
    return R(`${nm} shakes its head and nuzzles you. Not mad at all.`, { bubble: E('💗'), mood: 'happy', emote: 'hearts', yes: false });
  }
  if (p.what === 'trust' || p.what === 'believe') {
    const score = (tr.kept ?? 0) - (tr.broken ?? 0) * 2;
    const note = (tr.broken ?? 0) && score < 0 ? `${nm} hesitates. You've broken ${tr.broken === 1 ? 'a promise' : `${tr.broken} promises`} to it, and it remembers.` : (tr.kept ?? 0) >= 2 ? `${nm} nods without a second thought: you've kept every promise you made it.` : fr >= 0.6 ? `${nm} nods: of course it trusts you.` : `${nm} thinks about it. It's getting there.`;
    return R(note, { bubble: E(score < 0 ? '😕' : '🤝'), mood: score < 0 ? 'meh' : 'happy', yes: score >= 0 && fr >= 0.3 });
  }
  const note = fr >= 0.85 ? pickOf(seed, [`${nm} looks at you like you're the best thing in the world. You are, to it.`, `${nm} presses against you. You're its favourite person, easily.`])
    : fr >= 0.6 ? `${nm} nuzzles you. It really likes you.` : fr >= 0.3 ? `${nm} gives you a friendly look. It likes you, and it's warming up more every day.` : `${nm} isn't sure about you yet. Give it time.`;
  return R(note, { bubble: E(fr >= 0.6 ? '💗' : fr >= 0.3 ? '🙂' : '😶'), mood: fr >= 0.3 ? 'happy' : 'content', emote: fr >= 0.6 ? 'hearts' : 'note', yes: fr >= 0.3 });
}
function thirdReply(idx, save, c, p, t, nm, seed) {
  const o = save.creatures?.[p.subject];
  if (!o) return null;
  const on = displayName(idx, o), me = o.uid === c.uid;
  const close = me || (c.bonds?.[o.uid] ?? 0) >= 30;
  const q = { ...p, kind: 'groupQ', stance: p.stance === 'want' ? 'like' : p.stance, about: [] };
  const row = answerFor(idx, save, o, q, t);
  if (!row) return null;
  const said = row.text.replace(new RegExp(`^${on.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*`), '');
  if (me) return R(`${nm} answers for itself: it ${said}`, { bubble: E(row.pic), mood: row.v > 0.3 ? 'happy' : 'content', yes: row.v > 0.3 });
  return R(close ? `${nm} knows ${on} well: ${on} ${said}` : `${nm} isn't sure — it doesn't know ${on} that well. (${on} ${said.replace(/\.$/, '')}, as it happens.)`, { bubble: { kind: 'creature', uid: o.uid, speciesId: o.formId ?? o.speciesId }, mood: 'content', yes: row.v > 0.3 });
}
function favReply(idx, save, c, p, t, nm, seed) {
  const d = p.domain;
  if (d === 'food') {
    const fav = favorites(idx, c).berry, best = Object.entries(c.prefs ?? {}).filter(([k, v]) => k.startsWith('food:') && v >= 2).sort((a, b) => b[1] - a[1])[0]?.[0]?.slice(5);
    const id = best ?? fav;
    if (!id) return null;
    return R(`${nm}'s favourite: ${idx.items?.get?.(id)?.name ?? id}${best && fav && best !== fav ? ` (though it's always had a soft spot for ${idx.items?.get?.(fav)?.name ?? fav})` : ''}.`, { bubble: { kind: 'item', id }, mood: 'happy', emote: 'hearts', wantFood: id });
  }
  if (d === 'friend') {
    const f = friendsOf(c, 1)[0], o = f && save.creatures?.[f.uid];
    return R(o ? `${nm} looks over at ${displayName(idx, o)}. That's its favourite.` : `${nm} looks at you. You're its favourite.`, { bubble: o ? { kind: 'creature', uid: o.uid, speciesId: o.formId ?? o.speciesId } : E('💗'), mood: 'happy', emote: 'hearts' });
  }
  if (d === 'toy') { const toy = favorites(idx, c).toy; return R(`${nm}'s favourite toy is the ${toy ?? 'ball'}.`, { bubble: E('🧸'), mood: 'happy' }); }
  if (d === 'place' || d === 'weather' || d === 'time') {
    const kinds = { place: ['place', 'env'], weather: ['weather'], time: ['time'] }[d];
    const top = topPrefs(c, idx, 20).find((x) => kinds.includes(String(x.key).split(':')[0]));
    return R(top ? `${nm}'s favourite: ${top.label}.` : `${nm} hasn't picked a favourite ${p.obj || d} yet.`, { bubble: E(top ? '💕' : '🤔'), mood: 'happy' });
  }
  // a thing to do (or anything): what it'd pick, from its own tastes and what it's loved doing with you
  const pool = ACTS.filter((a) => !['snack', 'play', 'friends', 'music'].includes(a.id)).map((a) => ({ a, v: tasteOf(idx, save, c, { act: a }).score })).sort((x, y) => y.v - x.v);
  const top = pool[0], next = pool[1];
  const why = tasteOf(idx, save, c, { act: top.a }).why;
  stateCtx(c, t, { kind: 'favQ', text: p.raw, topic: top.a.ing, why, score: top.v });
  return R(`${nm}'s favourite thing to do is ${top.a.ing}${next && next.v > 0.4 ? `, then ${next.a.ing}` : ''}.${why ? ` ${cap(why)}.` : ''}`, { bubble: E('💕'), mood: 'happy', emote: 'hearts' });
}

function preferReply(idx, save, c, p, t, nm, seed) {
  const opts = (p.about ?? []).map((u) => save.creatures?.[u]).filter(Boolean);
  if (opts.length < 2) return null;
  if (opts.some((o) => o.uid === c.uid)) return R(`${nm} points at itself, then looks at you. Obviously.`, { bubble: E('😼'), mood: 'happy' });
  const sc = opts.map((o) => ({ o, b: c.bonds?.[o.uid] ?? 0 })).sort((a, b) => b.b - a.b);
  const [x, y] = sc;
  const note = x.b - y.b < 5 ? `${nm} looks from ${displayName(idx, x.o)} to ${displayName(idx, y.o)} and can't choose. ${x.b > 20 ? 'It likes them both.' : 'It doesn\'t know either of them that well yet.'}` : `${nm} goes and stands next to ${displayName(idx, x.o)}.${x.b >= 60 ? ' Its best friend.' : ''}`;
  stateCtx(c, t, { kind: 'preferQ', text: p.raw, topic: displayName(idx, x.o), why: x.b >= 30 ? `they've spent a lot of time together` : x.b > y.b ? `they've played together more` : null });
  return R(note, { bubble: x.b - y.b < 5 ? E('🤷') : { kind: 'creature', uid: x.o.uid, speciesId: x.o.formId ?? x.o.speciesId }, mood: 'happy', emote: 'note' });
}
function goodAtReply(idx, save, c, t, nm) {
  const pool = ACTS.filter((a) => a.act || ['battle', 'race', 'swim', 'fly', 'climb', 'tug'].includes(a.id)).map((a) => ({ a, s: skillAt(idx, c, a) })).sort((x, y) => y.s.score - x.s.score);
  const top = pool.slice(0, 2);
  stateCtx(c, t, { kind: 'goodAtQ', text: 'good at', topic: top[0].a.ing, why: top[0].s.note || null });
  return R(`${nm} shows off: it's best at ${top[0].a.ing}${top[0].s.note ? ` (${top[0].s.note})` : ''}${top[1] && top[1].s.score >= 0.6 ? `, and pretty good at ${top[1].a.ing}` : ''}.`, { bubble: E('💪'), mood: 'happy', emote: 'exclaim' });
}

function musicTasteReply(idx, save, c, t, nm) {
  const top = favouriteGenres(idx, c, 2), fav = heardSongs(c).filter((x) => x.op >= 1).sort((a, b) => b.op - a.op)[0];
  const note = `${nm}'s favourite kind of music is ${top[0].label}${top[1] && top[1].score > 0.2 ? ` (then ${top[1].label})` : ''}.${fav?.title ? ` Of everything you've played it, it loves “${fav.title}” most.` : ''}`;
  stateCtx(c, t, { kind: 'tasteQ', text: 'music', topic: top[0].label, why: `it's just its kind of sound` });
  return R(note, { bubble: E('🎵'), mood: 'happy', yes: true });
}

// a song it's heard: by its exact name and artist, or just by name
function findSong(c, m) {
  const exact = c.music?.[songKey(m)];
  if (exact || !m?.title) return exact ?? null;
  const t = String(m.title).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  return Object.values(c.music ?? {}).find((x) => String(x.title ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim() === t) ?? null;
}
function songOpinion(idx, c, p, t, nm) {
  const e = findSong(c, p.songRef);
  if (!e) return null;
  const L = e.title ? `“${e.title}”` : GENRE_LABEL[e.genre] ?? 'that';
  const yes = p.stance === 'dislike' ? e.op < -0.3 : e.op > 0.3;
  const note = e.op >= 1.2 ? `${nm} nods hard: it loves ${L}.` : e.op >= 0.35 ? `${nm} nods: it likes ${L}.` : e.op > -0.35 ? `${nm} wobbles its head: it's still making its mind up about ${L}.` : `${nm} shakes its head: ${L} isn't for it.`;
  return R(note, { bubble: E(e.op >= 0.35 ? '🎵' : e.op > -0.35 ? '🤔' : '🙉'), mood: e.op >= 0.35 ? 'happy' : 'content', yes });
}
function ynReply(idx, save, c, p, t, nm, seed, style) {
  if (p.songRef && (p.stance === 'like' || p.stance === 'dislike')) { const r = songOpinion(idx, c, p, t, nm); if (r) return r; }
  const a = p.act ?? activityIn(p.obj);
  if (p.stance === 'like' || p.stance === 'dislike') {
    const ts = tasteOf(idx, save, c, { act: a, genre: p.genre, obj: p.obj, about: p.about?.[0] ?? null });
    const yes = p.stance === 'like' ? ts.score > 0.15 : ts.score < -0.15;
    const why = ts.why ? ` ${cap(ts.why)}.` : '';
    const note = ts.kind === 'creature' ? null
      : p.opinion ? (ts.score >= 0.6 ? `${nm} loves ${ts.label}!${why}` : ts.score >= 0.15 ? `${nm} likes ${ts.label}.${why}` : ts.score > -0.15 ? `${nm} can take ${ts.label} or leave it.` : ts.score > -0.5 ? `${nm} isn't keen on ${ts.label}.${why}` : `${nm} really doesn't like ${ts.label}.${why}`)
      : ts.score >= 0.6 ? pickOf(seed, [`${nm} nods eagerly: it loves ${ts.label}!${why}`, `${nm} bounces. ${cap(ts.label)}? Yes! It loves ${ts.label}.${why}`])
        : ts.score >= 0.15 ? `${nm} nods: it likes ${ts.label}.${why}`
          : ts.score > -0.15 ? (ts.known ? `${nm} wobbles its head: ${ts.label} is all right, it supposes.` : `${nm} isn't sure — it hasn't tried ${ts.label} much.`)
            : ts.score > -0.5 ? `${nm} shakes its head: it's not keen on ${ts.label}.${why}` : `${nm} pulls a face. It really doesn't like ${ts.label}.${why}`;
    if (!note) return opinionReply(idx, save, c, { ...p, kind: 'opinionOf' }, t, nm, seed);
    if (ts.kind === 'food' && ts.item) { stateCtx(c, t, { kind: 'ynQ', text: p.raw, topic: ts.label, why: ts.why, score: ts.score }); return R(note, { bubble: { kind: 'item', id: ts.item }, mood: ts.score > 0.15 ? 'happy' : 'content', emote: ts.score >= 0.6 ? 'hearts' : 'note', yes, wantFood: ts.score > 0.15 ? ts.item : null }); }
    if (ts.kind === 'food' || (a && ['snack', 'berries'].includes(a.id) && ts.kind === 'act')) return null;
    stateCtx(c, t, { kind: 'ynQ', text: p.raw, topic: ts.label, why: ts.why, since: ts.memory?.t ?? null, score: ts.score });
    return R(note, { bubble: E(ts.score >= 0.6 ? '💕' : ts.score >= 0.15 ? '🙂' : ts.score > -0.15 ? '🤷' : '🙅'), mood: ts.score > 0.15 ? 'happy' : 'content', emote: ts.score >= 0.6 ? 'hearts' : 'note', yes });
  }
  if (p.stance === 'want' && a && ['snack', 'berries'].includes(a.id)) return null; // (food: the older rules know its cravings)
  if (p.stance === 'want' && a) {
    // right now: how it feels and how it is (a nap when it's wide awake, a race when it's worn out)
    const inv = INV[a.inv];
    if (!inv) return null;
    let res = { yes: [], no: [] }; try { res = volunteers(idx, save, [c.uid], inv, t); } catch { /* fine */ }
    const y = res.yes[0], n0 = res.no[0];
    const note = y ? (y.score > 0.85 ? pickOf(seed, [`${nm} is already on its feet: yes, ${a.label} now!`, `${nm} practically shouts yes: ${a.label}!`]) : `${nm} nods: it'd like to ${a.label} — ${y.why}.`)
      : `${nm} ${n0?.why ? n0.why.replace(new RegExp(`^${nm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*`), '') : "doesn't fancy it right now"}`.replace(/\s*$/, '.').replace(/\.\.$/, '.');
    stateCtx(c, t, { kind: 'ynQ', text: p.raw, topic: a.label, why: y?.why ?? n0?.why?.replace(new RegExp(`^${nm}\\s*`), '') ?? null });
    return R(note, { bubble: E(y ? '❗' : '😐'), mood: y ? 'happy' : 'meh', emote: y ? 'exclaim' : 'sweat', yes: !!y, invite: y ? inv.id : null });
  }
  if (p.stance === 'skill' && a) {
    const sk = skillAt(idx, c, a);
    const note = sk.score >= 0.8 ? `${nm} puffs out its chest: it's a natural at ${a.ing}${sk.note ? ` (${sk.note})` : ''}.` : sk.score >= 0.6 ? `${nm} nods: it's pretty good at ${a.ing}${sk.note ? ` (${sk.note})` : ''}.` : sk.score >= 0.4 ? `${nm} wobbles its head: it's all right at ${a.ing}.` : `${nm} looks sheepish. It's not much good at ${a.ing}${sk.note ? ` (${sk.note})` : ''}.`;
    stateCtx(c, t, { kind: 'ynQ', text: p.raw, topic: a.ing, why: sk.note || null, score: sk.score - 0.5 });
    return R(style === 'bold' && sk.score < 0.4 ? `${nm} insists it's great at ${a.ing}. (It isn't, really.)` : note, { bubble: E(sk.score >= 0.6 ? '💪' : '😅'), mood: 'content', yes: sk.score >= 0.5 });
  }
  if (p.stance === 'done' && a) {
    const d = doneOf(c, a), ts = tasteOf(idx, save, c, { act: a, obj: p.obj });
    const note = d.n ? `${nm} nods: it's been ${a.ing}${d.n > 1 ? ` ${d.n} times` : ''}${d.last ? `, last ${ago(d.last, t)}` : ''}. It ${likeWord(ts.score)} it.` : `${nm} shakes its head: it's never been ${a.ing}${ts.score > 0.4 ? ', and it really wants to' : ts.score < -0.3 ? ', and it would rather not' : ''}.`;
    stateCtx(c, t, { kind: 'ynQ', text: p.raw, topic: a.ing, why: ts.why, since: d.last ?? null });
    return R(note, { bubble: E(d.n ? '✅' : '🙅'), mood: 'content', yes: d.n > 0 });
  }
  return null;
}
