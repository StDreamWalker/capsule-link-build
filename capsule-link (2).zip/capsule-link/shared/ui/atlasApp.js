// The PokéEco Atlas as an app inside Capsule Link (PC and phone): the atlas page itself in a frame, with a bar
// saying which spot the app is using for wild creatures, and the atlas's "Use this spot" button wired to it.
import { h } from './dom.js';
import { ATLAS_PAGE } from '../atlas/atlasPage.js';

/**
 * opts: { current(): { label } | null — the spot the app uses now; onSpot(spot) — the atlas's button was pressed
 *   ({ lat, lon, radiusKm, label }); start(): { lat, lon } | null — where to open; onClear() — stop using a spot;
 *   note — a line under the title }
 */
export function atlasApp({ current, onSpot, start, onClear, note = '' }) {
  const frame = h('iframe', { class: 'atlas-frame', title: 'PokéEco Atlas', allow: 'geolocation', srcdoc: ATLAS_PAGE });
  const nowEl = h('span', { class: 'atlas-now' });
  const clearBtn = h('button', { class: 'btn small ghost', onclick: () => { onClear?.(); paint(); } }, 'Stop using it');
  const el = h('div', { class: 'atlas-app' },
    h('div', { class: 'atlas-head' },
      h('div', { class: 'grow col', style: { gap: '2px', minWidth: 0 } },
        h('strong', null, 'PokéEco Atlas'),
        h('span', { class: 'micro dim' }, note || 'Tap the map to scan a spot, then “Use this spot” to have wild creatures in walks and battles come from there.')),
      nowEl, clearBtn),
    frame);
  const post = (m) => { try { frame.contentWindow?.postMessage({ to: 'pokeeco', ...m }, '*'); } catch { /* fine */ } };
  function paint() {
    const c = current?.();
    nowEl.textContent = c?.label ? `📍 ${c.label}` : 'No spot chosen';
    clearBtn.style.display = c && onClear ? '' : 'none';
    post({ type: 'current', label: c?.label ?? '' });
  }
  let opened = false;
  const onMsg = async (e) => {
    if (e.source !== frame.contentWindow) return;
    const m = e.data || {};
    if (m.from !== 'pokeeco') return;
    if (m.type === 'ready') {
      paint();
      if (!opened) { opened = true; const s = start?.(); if (s && Number.isFinite(s.lat) && Number.isFinite(s.lon)) post({ type: 'go', lat: s.lat, lon: s.lon, zoom: 12 }); }
    }
    if (m.type === 'atlas-spot' && Number.isFinite(m.lat) && Number.isFinite(m.lon)) {
      nowEl.textContent = `📍 ${m.label || 'This spot'} (reading it…)`;
      try { await onSpot?.({ lat: m.lat, lon: m.lon, radiusKm: m.radiusKm, label: m.label }); } finally { paint(); }
    }
  };
  window.addEventListener('message', onMsg);
  paint();
  return { el, refresh: paint, dispose() { window.removeEventListener('message', onMsg); } };
}
