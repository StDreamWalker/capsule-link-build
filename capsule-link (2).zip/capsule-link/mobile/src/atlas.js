// The PokéEco Atlas on the phone: the whole atlas (map, encounters, fauna, legends…), and what it means for your
// walks and wild battles: where you are is read through it after each look around, or a spot picked here is used.
import { h, toast } from '../../shared/ui/dom.js';
import { atlasApp } from '../../shared/ui/atlasApp.js';
import { tableLine } from '../../shared/atlas/scan.js';

export function atlasView(app) {
  const A = atlasApp({
    current: () => {
      if (app.settings.useLocation && app.settings.atlasHere) return { label: `Where you are · ${app.settings.atlasHere.label}` };
      return app.settings.atlasSpot ?? null;
    },
    start: () => (app.settings.useLocation && app.settings.atlasHere) || app.settings.atlasSpot || null,
    onSpot: async (spot) => {
      try {
        const t = await app.setAtlasSpot(spot);
        toast(app.settings.useLocation ? `Picked ${t.label}. It's used when location is off (or for “Where you are” battles until your next look around).` : `Walks and “Where you are” battles now use ${tableLine(t)}.`, 'ok');
      } catch (e) { toast(`Couldn’t read that spot: ${e.message}`, 'err'); }
    },
    onClear: () => app.local((st) => { delete st.settings.atlasSpot; }),
    note: 'Tap the map to scan anywhere. With location on, walks use where you really are; “Use this spot” picks a place for when it’s off.',
  });
  const el = h('div', { class: 'm-atlas' }, A.el);
  const off = app.on((w) => { if (w === 'surroundings') A.refresh(); });
  return { el, dispose: () => { off(); A.dispose(); }, update: () => A.refresh() };
}
