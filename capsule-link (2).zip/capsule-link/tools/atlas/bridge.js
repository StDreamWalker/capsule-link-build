/* Capsule Link bridge (added to the atlas page by tools/atlas/extract.mjs): a button to make the scanned spot
   the app's "where you are", and messages to and from the app around it. */
(function () {
  var A = window.__atlas; if (!A || window.parent === window) return;
  var send = function (m) { try { window.parent.postMessage(Object.assign({ from: 'pokeeco' }, m), '*'); } catch (e) { } };
  var css = document.createElement('style');
  css.textContent = '.cl-bar{position:absolute;left:296px;bottom:18px;z-index:900;display:flex;gap:8px;align-items:center;flex-wrap:wrap;max-width:calc(100% - 310px);pointer-events:none}' +
    '.cl-bar>*{pointer-events:auto}.cl-use{background:#e9c46a;color:#1b1b1b;border:0;border-radius:10px;padding:9px 14px;font:600 13px system-ui,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.35);cursor:pointer}' +
    '.cl-use[disabled]{opacity:.55;cursor:default}.cl-now{background:rgba(16,22,26,.88);color:#e8eef0;border-radius:10px;padding:7px 11px;font:12px system-ui,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.3)}' +
    '.cl-now b{color:#e9c46a;font-weight:600}@media (max-width:820px){.cl-bar{left:12px;max-width:calc(100% - 24px);bottom:calc(var(--sheet-h,140px) + 10px)}.cl-now{display:none!important}.cl-use{padding:7px 11px;font-size:12px}}';
  document.head.appendChild(css);
  var bar = document.createElement('div'); bar.className = 'cl-bar';
  var use = document.createElement('button'); use.className = 'cl-use'; use.type = 'button'; use.textContent = '📍 Use this spot in Capsule Link';
  var now = document.createElement('div'); now.className = 'cl-now'; now.style.display = 'none';
  bar.appendChild(use); bar.appendChild(now);
  (document.getElementById('mapwrap') || document.body).appendChild(bar);
  function label() {
    var r = A.state.raw; if (!r) return '';
    var g = r.geo || {};
    if (g.ocean) return 'Open water';
    if (g.estimated) return g.country ? g.country + ' (estimated)' : 'Remote area ' + r.lat.toFixed(2) + '°, ' + r.lon.toFixed(2) + '°';
    var t = [g.place, g.state, g.country].filter(Boolean).slice(0, 2).join(', ');
    return t || (r.lat.toFixed(2) + '°, ' + r.lon.toFixed(2) + '°');
  }
  function sync() { use.disabled = !A.state.raw; }
  setInterval(sync, 700); sync();
  use.onclick = function () {
    var r = A.state.raw; if (!r) return;
    send({ type: 'atlas-spot', lat: r.lat, lon: r.lon, radiusKm: r.radiusKm, label: label() });
    use.textContent = '✓ Capsule Link is using this spot'; setTimeout(function () { use.textContent = '📍 Use this spot in Capsule Link'; }, 2600);
  };
  window.addEventListener('message', function (e) {
    var m = e.data || {}; if (m.to !== 'pokeeco') return;
    if (m.type === 'current') {
      now.style.display = m.label ? '' : 'none';
      now.innerHTML = m.label ? 'In the app: <b></b>' : '';
      if (m.label) now.querySelector('b').textContent = m.label;
    }
    if (m.type === 'go' && isFinite(m.lat) && isFinite(m.lon)) { A.map.setView([m.lat, m.lon], m.zoom || 12); A.analyze(m.lat, m.lon); }
  });
  send({ type: 'ready' });
})();
