// 1.0.2: wild encounters weighted like the games (common unevolved ones first, nothing too evolved for its
// level, legendaries very rare), and the battle stage's move classification.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

function world() {
  const ds = E.createDefaultDataset();
  const b = ds.species[0];
  const mk = (id, name, types, bst, extra = {}) => { const each = Math.round(bst / 6); return { ...JSON.parse(JSON.stringify(b)), id, name, no: 900 + ds.species.length, types, baseStats: { hp: each, atk: each, def: each, spa: each, spd: each, spe: each }, evolutions: [], habitats: ['outskirts'], ...extra }; };
  ds.species = [
    mk('rattata', 'Rattata', [ds.types[0].id], 253, { evolutions: [{ to: 'raticate', method: 'level', value: 20 }] }),
    mk('raticate', 'Raticate', [ds.types[0].id], 413),
    mk('pidgey', 'Pidgey', [ds.types[0].id], 251),
    mk('onix', 'Onix', [ds.types[0].id], 385, { evolutions: [{ to: 'steelix', method: 'trade', value: 'Metal Coat' }] }),
    mk('steelix', 'Steelix', [ds.types[0].id], 510),
    mk('mewtwo', 'Mewtwo', [ds.types[0].id], 680),
    mk('celebi', 'Celebi', [ds.types[0].id], 600, { habitats: ['forest'] }),
  ];
  const idx = E.indexDataset(ds);
  const save = E.createSave('K', 2);
  const c = E.createCreature(idx, 'pidgey', { level: 6 }); save.creatures[c.uid] = c; save.party = [c.uid];
  return { idx, save };
}

test('a level 6 walk in the park: commons first, never a Steelix (an Onix at most), legendaries almost never', () => {
  const { idx, save } = world();
  const n = {};
  for (let i = 0; i < 3000; i++) { const w = E.rollWild(idx, save, { biome: 'outskirts', seed: i * 7919 + 1 }); n[w.speciesId] = (n[w.speciesId] ?? 0) + 1; assert.ok(w.level <= 9); }
  assert.equal(n.steelix ?? 0, 0, 'too young to have evolved');
  assert.equal(n.raticate ?? 0, 0);
  assert.ok((n.rattata ?? 0) + (n.pidgey ?? 0) > 2100 && (n.onix ?? 0) < 800, JSON.stringify(n));
  assert.ok((n.mewtwo ?? 0) < 6, JSON.stringify(n));
  assert.ok(E.minWildLevel(idx, idx.species.get('steelix')) >= 20);
  assert.ok(E.isRareSpecies({ name: 'Landorus-Therian' }) && !E.isRareSpecies({ name: 'Ratatouille' }));
});

test('arenas draw from everyone, but still with the rarity rules', () => {
  const { idx, save } = world();
  const n = {};
  for (let i = 0; i < 2000; i++) { const w = E.rollWild(idx, save, { biome: null, seed: i * 104729 + 3 }); n[w.speciesId] = (n[w.speciesId] ?? 0) + 1; }
  assert.ok((n.celebi ?? 0) + (n.mewtwo ?? 0) < 8, JSON.stringify(n));
  assert.ok(Object.keys(n).length >= 3);
});

test('the stage gives moves their own looks: Quick Attack zig-zags, Dragon Darts fires twice, Whirlpool traps, Strength Sap drains', async () => {
  const { classifyMove, vanishOf } = await import('../shared/ui/stageMoves.js');
  const c = (m) => classifyMove({ type: 'Normal', cat: 'Physical', flags: {}, ...m });
  assert.equal(c({ name: 'Quick Attack', flags: { contact: 1 }, priority: 1 }).kind, 'zigzag');
  const dd = c({ name: 'Dragon Darts', type: 'Dragon', multihit: 2 }); assert.equal(dd.kind, 'volley'); assert.equal(dd.hits, 2);
  assert.equal(c({ name: 'Whirlpool', type: 'Water', cat: 'Special', volatile: 'partiallytrapped' }).kind, 'vortex');
  assert.equal(c({ name: 'Strength Sap', type: 'Grass', cat: 'Status', heal: true }).kind, 'drain');
  assert.equal(c({ name: 'Giga Drain', type: 'Grass', cat: 'Special', drain: true }).kind, 'drain');
  assert.equal(c({ name: 'Double Kick', type: 'Fighting', flags: { contact: 1 }, multihit: 2 }).hits, 2);
  assert.equal(c({ name: 'Earthquake', type: 'Ground', target: 'allAdjacent' }).kind, 'quake');
  assert.equal(c({ name: 'Protect', cat: 'Status', stalling: true, target: 'self' }).kind, 'protect');
  assert.equal(vanishOf({ name: 'Phantom Force' }), 'gone');
  assert.equal(vanishOf({ name: 'Fly' }), 'up');
  // every type has its own colours and particles
  const { TYPE_LOOK } = await import('../shared/ui/stageMoves.js');
  assert.ok(Object.keys(TYPE_LOOK).length >= 18);
});
