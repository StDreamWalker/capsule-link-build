// 1.0.8: bringing several creatures over (each its own id), and ROM hack saves (Unbound / Radical Red's
// CFRU layout, pokeemerald-expansion hacks like Emerald Seaglass, and ROWE's own records) read with the right
// species, and Pokémon written back into Unbound / Radical Red / expansion saves.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { openGameSave } from '../shared/engine/gameSaves.js';
import { romhackFromName } from '../shared/engine/romhackSaves.js';
import { CFRU_UNBOUND_SPECIES, EXPANSION_SPECIES, EXPANSION_MOVES, CFRU_UNBOUND_MOVES, CFRU_UNBOUND_GROWTH, SEAGLASS_NATIONAL } from '../shared/engine/romhackData.js';
import { readPkm, pkhexToCreature, identitySeed } from '../shared/engine/pkhex.js';
import * as E from '../shared/engine/index.js';

const w16 = (d, o, v) => { d[o] = v & 255; d[o + 1] = (v >> 8) & 255; };
const w32 = (d, o, v) => { d[o] = v & 255; d[o + 1] = (v >>> 8) & 255; d[o + 2] = (v >>> 16) & 255; d[o + 3] = (v >>> 24) & 255; };
const u16 = (d, o) => d[o] | (d[o + 1] << 8);
const text = (d, o, s, n) => { for (let i = 0; i < n; i++) d[o + i] = i < s.length ? 0xbb + s.charCodeAt(i) - 65 : 0xff; };
const ORDER = ['GAEM', 'GAME', 'GEAM', 'GEMA', 'GMAE', 'GMEA', 'AGEM', 'AGME', 'AEGM', 'AEMG', 'AMGE', 'AMEG', 'EGAM', 'EGMA', 'EAGM', 'EAMG', 'EMGA', 'EMAG', 'MGAE', 'MGEA', 'MAGE', 'MAEG', 'MEGA', 'MEAG'];
const idx = (n) => [...EXPANSION_SPECIES.entries()].find(([, v]) => v === n)?.[0];

/** A blank 128 KB flash with one save slot of 14 sectors (ids 0–13) signed `sig`. */
function flash(sig = 0x08012025) {
  const d = new Uint8Array(0x20000).fill(0);
  for (let i = 0; i < 14; i++) { const o = i * 0x1000; w16(d, o + 0xff4, i); w32(d, o + 0xff8, sig); w32(d, o + 0xffc, 7); }
  for (let i = 14; i < 28; i++) { const o = i * 0x1000; w16(d, o + 0xff4, 0xffff); w32(d, o + 0xff8, 0xffffffff); }
  text(d, 0, 'AAAAAAA', 7); w16(d, 0x0a, 4242);
  return d;
}
/** An expansion BoxPokemon (80) or Pokemon (100), encrypted the Gen 3 way, new field packing. */
function expMon({ pid = 0x1234567, otid = 0x99887766, species, moves = [33, 45], level = 0, exp = 1000, ball = 4, nick = 'AAAAAAAAAA' }, size = 80) {
  const r = new Uint8Array(size);
  w32(r, 0, pid); w32(r, 4, otid); text(r, 8, nick, 10); r[0x12] = 2; r[0x13] = 2; text(r, 0x14, 'AAAAAAA', 7);
  const G = new Uint8Array(12), A = new Uint8Array(12), E = new Uint8Array(12), M = new Uint8Array(12);
  w16(G, 0, species & 0x7ff | (5 << 11)); w16(G, 2, 0); w32(G, 4, exp | (0xff << 21)); G[9] = 70; G[10] = ball;
  moves.forEach((m, i) => w16(A, i * 2, m)); moves.forEach((m, i) => { A[8 + i] = 20; });
  E[0] = 4; w32(M, 4, (31 | (31 << 5) | (20 << 10) | (10 << 15) | (5 << 20) | (1 << 25)) >>> 0);
  const plain = { G, A, E, M };
  let sum = 0; for (const b of [G, A, E, M]) for (let i = 0; i < 12; i += 2) sum = (sum + u16(b, i)) & 0xffff;
  w16(r, 0x1c, sum);
  const order = ORDER[pid % 24], key = (pid ^ otid) >>> 0;
  for (let i = 0; i < 4; i++) { const blk = plain[order[i]]; for (let j = 0; j < 12; j += 4) { const v = ((blk[j] | (blk[j + 1] << 8) | (blk[j + 2] << 16) | (blk[j + 3] << 24)) ^ key) >>> 0; w32(r, 32 + i * 12 + j, v); } }
  if (size === 100) { r[0x54] = level; w16(r, 0x56, 30); w16(r, 0x58, 30); }
  return r;
}
/** CFRU's 58-byte compact PC record. */
function compact({ pid = 0xabcdef01, species, moves = [1, 2], exp = 500, hidden = false }) {
  const r = new Uint8Array(58);
  w32(r, 0, pid); w32(r, 4, 0x11112222); text(r, 8, 'AAAAAAAAAA', 10); r[18] = 2; text(r, 20, 'AAAAAAA', 7);
  w16(r, 28, species); w32(r, 32, exp); r[37] = 70; r[38] = 3;
  let p = 0n; moves.forEach((m, i) => { p |= BigInt(m) << BigInt(i * 10); }); for (let i = 0; i < 5; i++) r[39 + i] = Number((p >> BigInt(8 * i)) & 0xffn);
  w32(r, 54, ((31) | (hidden ? 1 << 31 : 0)) >>> 0);
  return r;
}
/** A CFRU party record: 100 bytes, unencrypted, blocks G A E M, checksum 0. */
function cfruParty({ species, moves = [33], level = 9, exp = 600 }) {
  const r = new Uint8Array(100);
  w32(r, 0, 0x55667788); w32(r, 4, 0x11112222); text(r, 8, 'AAAAAAAAAA', 10); text(r, 0x14, 'AAAAAAA', 7);
  w16(r, 32, species); w32(r, 36, exp); r[41] = 70; moves.forEach((m, i) => w16(r, 44 + i * 2, m)); r[52] = 35; w32(r, 72, 31);
  r[0x54] = level; w16(r, 0x56, 25); w16(r, 0x58, 25);
  return r;
}
// where a CFRU compact record (box b, slot s) lives in the flash
const CFRU_REGIONS = [[5, 4, 4080], [6, 0, 4080], [7, 0, 4080], [8, 0, 4080], [9, 0, 4080], [10, 0, 4080], [11, 0, 4080], [12, 0, 4080], [13, 0, 424], [30, 2828, 4080], [31, 0, 3968], [2, 3864, 4080], [3, 0, 3264]];
function putCompact(d, b, s, rec) {
  let off = (b * 30 + s) * 58;
  for (let i = 0; i < 58; i++, off++) {
    let o = off;
    for (const [sec, a, z] of CFRU_REGIONS) { if (o < z - a) { d[sec * 0x1000 + a + o] = rec[i]; break; } o -= z - a; }
  }
}

test('several creatures from one game come over: each gets its own id (Gen 3–5 keep EC = PID, Gen 1/2 have none)', () => {
  const idx = E.indexDataset(E.createDefaultDataset());
  const a = readPkm(expMonVanilla(0x11111111), 'a.pk3'), b = readPkm(expMonVanilla(0x22222222), 'b.pk3');
  assert.ok(a.ok && b.ok);
  assert.equal(a.pid ^ a.ec, 0); // the old seed: the same for everyone
  assert.notEqual(identitySeed(a), identitySeed(b));
  const sp = idx.ds.species[0];
  const c1 = pkhexToCreature(idx, a, { species: sp }).creature, c2 = pkhexToCreature(idx, b, { species: sp }).creature;
  assert.notEqual(c1.uid, c2.uid);
  // brought over twice, the same creature looks the same (its quirks follow from who it is), with a new id
  const c1b = pkhexToCreature(idx, a, { species: sp }).creature;
  assert.notEqual(c1.uid, c1b.uid);
  assert.deepEqual(c1.genes, c1b.genes);
  const boxes = fs.readFileSync(new URL('../desktop/src/renderer/views/boxes.js', import.meta.url), 'utf8');
  assert.match(boxes, /while \(s\.creatures\[creature\.uid\]\) creature\.uid = randomId\(8\)/);
  assert.doesNotMatch(boxes, /if \(s\.creatures\[creature\.uid\]\) return;/);
});
// a vanilla-format pk3 (species 25 in the official numbering)
function expMonVanilla(pid) {
  const r = new Uint8Array(80); w32(r, 0, pid); w32(r, 4, 0x01020304); text(r, 8, 'PIKA', 10); r[0x12] = 2; text(r, 0x14, 'ASH', 7);
  const d = new Uint8Array(48); w16(d, 0, 25); w32(d, 4, 500); w16(d, 12, 84);
  let sum = 0; for (let i = 0; i < 48; i += 2) sum = (sum + u16(d, i)) & 0xffff; w16(r, 0x1c, sum); r.set(d, 32);
  return r;
}

test('the tables: Unbound and expansion numbers become national numbers and forms', () => {
  assert.equal(CFRU_UNBOUND_SPECIES[25], 25);
  assert.equal(CFRU_UNBOUND_SPECIES[277], 252); // Treecko after CFRU's 25 empty slots
  assert.equal(CFRU_UNBOUND_SPECIES[1020], '19-Alola');
  assert.equal(CFRU_UNBOUND_SPECIES[900], '323-Mega');
  assert.equal(EXPANSION_SPECIES[252], 252);
  assert.equal(EXPANSION_SPECIES[906], '3-Mega');
  assert.equal(EXPANSION_SPECIES[956], '19-Alola');
  assert.equal(EXPANSION_SPECIES[1434], 1025); // Gen 9 comes after the forms
  assert.equal(EXPANSION_MOVES[33], 33);
  assert.equal(CFRU_UNBOUND_MOVES[466], 605); // "Dazzle Gleam" → Dazzling Gleam
  assert.equal(romhackFromName('Pokemon_Unbound.sav'), 'unbound');
  assert.equal(romhackFromName('Pokemon - Emerald Seaglass Version.sav'), 'seaglass');
  assert.equal(romhackFromName('Pokemon_ROWE.sav'), 'rowe');
  assert.equal(romhackFromName('Pokemon Emerald.sav'), null);
});

test('an expansion hack (Emerald Seaglass): boxes and a party found wherever it is, species the expansion way', () => {
  const d = flash();
  const sb1 = 1 * 0x1000, pc = 5 * 0x1000;
  // the party moved (the hack's SaveBlock1 is laid out differently)
  w32(d, sb1 + 0x6a0 - 4, 2);
  d.set(expMon({ species: idx(1025), level: 30, exp: 27000, moves: [33, 45] }, 100), sb1 + 0x6a0);
  d.set(expMon({ pid: 0x0badf00d, species: 956, level: 12, exp: 1728, moves: [33] }, 100), sb1 + 0x6a0 + 100);
  // box 1 slot 1, and box 1 slot 3
  d.set(expMon({ species: 252, moves: [1] }), pc + 4);
  d.set(expMon({ pid: 0x77777777, species: 906, moves: [22, 75] }), pc + 4 + 2 * 80);
  for (const name of ['Pokemon - Emerald Seaglass Version.sav', 'game.sav']) {
    const s = openGameSave(d, name);
    assert.ok(s.ok, name);
    assert.equal(s.canWrite, true);
    const party = s.party.filter(Boolean).map((e) => [e.pk.national, e.pk.formName, e.pk.statLevel]);
    assert.deepEqual(party, [[1025, '', 30], [19, 'Alola', 12]], name);
    const box = s.boxes[0].slots.filter(Boolean).map((e) => [e.pk.national, e.pk.formName, e.pk.moves.filter(Boolean)]);
    assert.deepEqual(box, [[252, '', [1]], [3, 'Mega', [22, 75]]], name);
    assert.equal(s.party[0].pk.nickname, 'AAAAAAAAAA');
    assert.equal(s.trainer.name, 'AAAAAAA');
  }
  assert.match(openGameSave(d, 'x - Emerald Seaglass.sav').game, /Seaglass/);
});

test('Pokémon Unbound (CFRU): compact PC records across the odd sectors, unencrypted party, Unbound numbering', () => {
  const d = flash(0x01121999);
  const sb1 = 1 * 0x1000;
  w32(d, sb1 + 0x34, 1);
  d.set(cfruParty({ species: 1020, moves: [33, 39], level: 9 }), sb1 + 0x38);
  putCompact(d, 0, 0, compact({ species: 277, moves: [1, 43] }));
  putCompact(d, 18, 29, compact({ species: 900, moves: [33] }));   // in the spare physical sector 30
  putCompact(d, 23, 0, compact({ species: 25, moves: [84], hidden: true })); // in sector 3
  // the preset box in sector 0
  d.set(compact({ species: 1260, moves: [22] }), 0 * 0x1000 + 176);
  for (const name of ['Pokemon_Unbound.sav', 'save.sav']) {
    const s = openGameSave(d, name);
    assert.ok(s.ok, name);
    assert.match(s.game, /Unbound/);
    assert.equal(s.boxes.length, 25);
    assert.deepEqual(s.party.filter(Boolean).map((e) => [e.pk.national, e.pk.formName, e.pk.statLevel, e.pk.moves.filter(Boolean)]), [[19, 'Alola', 9, [33, 39]]]);
    const at = (b, sl) => { const e = s.boxes[b].slots[sl]; return e && [e.pk.national, e.pk.formName, e.pk.moves.filter(Boolean)]; };
    assert.deepEqual(at(0, 0), [252, '', [1, 43]]);
    assert.deepEqual(at(18, 29), [323, 'Mega', [33]]);
    assert.deepEqual(at(23, 0), [25, '', [84]]);
    assert.equal(s.boxes[23].slots[0].pk.abilityNumber, 4); // hidden ability
    assert.deepEqual(at(24, 0), [3, 'Gmax', [22]]);
    assert.equal(s.boxes.flatMap((b) => b.slots).filter(Boolean).length, 4);
  }
});

test('Radical Red (CFRU layout, ordinary signature) is told apart from an official FireRed/Emerald save', () => {
  const d = flash(0x08012025);
  w32(d, 0x1000 + 0x34, 1); d.set(cfruParty({ species: 6, level: 36, exp: 40000 }), 0x1000 + 0x38);
  putCompact(d, 2, 4, compact({ species: 151, moves: [1] }));
  const s = openGameSave(d, 'game.sav');
  assert.ok(s.ok);
  assert.match(s.game, /Radical Red/);
  assert.equal(s.boxes[2].slots[4].pk.national, 151);
});

test('an official Emerald save with only a party stays an official save', () => {
  const d = flash();
  const sb1 = 0x1000;
  w32(d, sb1 + 0x234, 1);
  // official numbering: 277 = Treecko inside the files
  const r = new Uint8Array(100); r.set(expMonVanillaSpecies(277), 0); r[0x54] = 5;
  d.set(r, sb1 + 0x238);
  w32(d, 0xac, 0); d[0x890 + 5] = 1; // looks like Emerald
  const s = openGameSave(d, 'Pokemon Emerald.sav');
  assert.ok(s.ok);
  assert.doesNotMatch(s.game, /hack|Radical|Unbound/i);
  assert.equal(s.party[0].pk.national, 252);
});
function expMonVanillaSpecies(internal) {
  const r = new Uint8Array(80); w32(r, 0, 48); w32(r, 4, 48); text(r, 8, 'TREECKO', 10); r[0x12] = 2;
  const dd = new Uint8Array(48); w16(dd, 0, internal); w32(dd, 4, 135); w16(dd, 12, 1);
  let sum = 0; for (let i = 0; i < 48; i += 2) sum = (sum + u16(dd, i)) & 0xffff; w16(r, 0x1c, sum);
  r.set(dd, 32); // PID = OT id = 48: key 0 and order G A E M, so "encrypted" equals plain
  return r;
}

test('the save browser lets you say which game a save is from (and re-reads it)', () => {
  const src = fs.readFileSync(new URL('../desktop/src/renderer/views/saveBrowser.js', import.meta.url), 'utf8');
  assert.match(src, /ROMHACKS/);
  assert.match(src, /reopen/);
});

// ROWE's 76-byte party record (as in a real ROWE save: Rhyhorn, Lv. 10)
function roweMon() {
  const hex = '86 73 f9 c7 db 37 e1 c7 cc dc ed dc e3 e6 e2 ff c9 9c f6 18 1e a0 0f 00 1c 7c 80 11 6f 00 be 6b 00 00 00 00 00 00 00 58 0a 02 00 bb d5 d5 d5 d5 d5 d5 00 00 19 0f 14 0f 00 00 00 00 0a ff 24 00 24 00 16 00 18 00 09 00 0b 00 0c 00';
  return Uint8Array.from(hex.split(' ').map((x) => parseInt(x, 16)));
}
test('ROWE: its own packed records (species, experience and 10-bit moves, move 4 apart, PP, level)', () => {
  const d = flash();
  w32(d, 0x1000 + 0x234, 1); d.set(roweMon(), 0x1000 + 0x238);
  const s = openGameSave(d, 'pkmn_rowe_experimental.sav');
  assert.ok(s.ok);
  assert.match(s.game, /ROWE/);
  const p = s.party[0].pk;
  assert.deepEqual([p.national, p.nickname, p.otName, p.statLevel, p.exp, p.moves, p.pp, p.nature], [111, 'Rhyhorn', 'Aaaaaaa', 10, 1000, [30, 28, 31, 479], [25, 15, 20, 15], 22]); // Horn Attack, Sand Attack, Fury Attack, Smack Down
  assert.equal(s.canWrite, true);
});

test('putting Pokémon into Unbound and Seaglass saves: written their way, read back the same, checksums right', async () => {
  const { hackRecord, gen3Exp } = await import('../shared/engine/romhackSaves.js');
  const u32 = (dd, o) => (dd[o] | (dd[o + 1] << 8) | (dd[o + 2] << 16) | (dd[o + 3] << 24)) >>> 0;
  const sum = (dd, o, len) => { let t = 0; for (let i = 0; i < len; i += 4) t = (t + u32(dd, o + i)) >>> 0; return ((t >>> 16) + (t & 0xffff)) & 0xffff; };
  const info = { national: 445, formName: '', name: 'Garchomp', nickname: 'CHOMPY', otName: 'ZIGGY', pid: 0x12345678, otid: 0x0badcafe, exp: 125000, level: 50, moves: [89, 337, 14, 444], pp: [10, 15, 20, 10], ivs: { hp: 31, atk: 30, def: 29, spe: 28, spa: 27, spd: 26 }, evs: { hp: 4, atk: 252, def: 0, spe: 252, spa: 0, spd: 0 }, friendship: 200, ball: 4, abilityNumber: 4, metLevel: 50 };
  for (const [name, sig, alola] of [['Pokemon Unbound.sav', 0x01121999, false], ['Pokemon - Emerald Seaglass Version.sav', 0x08012025, true]]) {
    const d = flash(sig);
    const lenOf = (id) => (sig === 0x08012025 ? 0xf80 : id === 0 ? 0xf24 : id === 13 ? 0x450 : id === 4 ? 0 : 0xff0);
    for (let i = 0; i < 14; i++) { const o = i * 0x1000, len = lenOf(d[o + 0xff4]); if (len) w16(d, o + 0xff6, sum(d, o, len)); }
    const s = openGameSave(d, name);
    assert.ok(s.ok && s.canWrite, name);
    const r = hackRecord(s, alola ? { ...info, national: 19, formName: 'Alola', name: 'Rattata' } : info);
    assert.ok(r.ok, r.reason);
    for (const [b, sl] of [[0, 0], [5, 7], [13, 29]]) assert.ok(s.put(b, sl, r.bytes, s.format).ok);
    const out = s.toBytes();
    const s2 = openGameSave(out, name);
    for (const [b, sl] of [[0, 0], [5, 7], [13, 29]]) {
      const p = s2.boxes[b].slots[sl].pk;
      assert.deepEqual([p.national, p.formName, p.nickname, p.otName, p.moves, Object.values(p.ivs), Object.values(p.evs), p.ball, p.abilityNumber, p.otFriendship],
        [alola ? 19 : 445, alola ? 'Alola' : '', 'CHOMPY', 'ZIGGY', [89, 337, 14, 444], [31, 30, 29, 28, 27, 26], [4, 252, 0, 252, 0, 0], 4, 4, 200], `${name} ${b}:${sl}`);
    }
    // Unbound: experience on its own curve (its Gible line is medium slow, as in the real save); Seaglass: as given
    assert.equal(s2.boxes[0].slots[0].pk.exp, alola ? 125000 : gen3Exp(3, 50));
    for (let i = 0; i < 14; i++) { const o = i * 0x1000, id = out[o + 0xff4]; const len = lenOf(id); if (len) assert.equal(sum(out, o, len), out[o + 0xff6] | (out[o + 0xff7] << 8), `${name} sector ${id}`); }
    // and out again
    assert.ok(s2.take(5, 7).ok);
    assert.equal(openGameSave(s2.toBytes(), name).boxes[5].slots[7], null);
  }
  // one that came from Unbound goes back exactly as it came
  const d = flash(0x01121999); putCompact(d, 0, 0, compact({ species: 277, moves: [1, 43] }));
  const s = openGameSave(d, 'Pokemon Unbound.sav');
  const raw = s.boxes[0].slots[0].pk.hackRaw;
  // nothing changed here: byte for byte
  const same = hackRecord(s, { national: 252, name: 'Treecko', raw, rawHack: 'unbound', moves: [1, 43], evs: {}, friendship: 70, level: 5, importLevel: 5 });
  assert.deepEqual([...same.bytes], [...raw]);
  // trained here: new level, moves and effort written in; everything else as it was
  const trained = hackRecord(s, { national: 252, name: 'Treecko', raw, rawHack: 'unbound', moves: [1, 43, 71, 98], evs: { spe: 100, spa: 40 }, friendship: 150, level: 20, importLevel: 5, nickname: 'Leafy' });
  s.put(1, 0, trained.bytes, s.format);
  const t = openGameSave(s.toBytes(), 'Pokemon Unbound.sav').boxes[1].slots[0].pk;
  assert.deepEqual([t.national, t.moves, t.evs.spe, t.evs.spa, t.otFriendship, t.nickname, t.pid], [252, [1, 43, 71, 98], 100, 40, 150, 'Leafy', s.boxes[0].slots[0].pk.pid]);
  assert.equal(t.exp, gen3Exp(CFRU_UNBOUND_GROWTH[277] ?? 3, 20));
  // a species the hack doesn't have
  assert.equal(hackRecord(s, { ...info, national: 9999, name: 'Nobody' }).ok, false);
});

test('a creature here becomes hack info: national number and form, nature kept in the PID, genes and effort scaled', async () => {
  const { hackInfoFor, pidFor } = await import('../shared/engine/hackTransfer.js');
  const idx = E.indexDataset(E.createDefaultDataset());
  const sp = idx.ds.species.find((x) => Number(x.no) > 0);
  const c = E.createCreature(idx, sp.id, { level: 20 });
  const r = hackInfoFor(idx, c, { trainer: 'AAAAAAA', trainerId: 0x12345678 });
  assert.ok(r.ok, r.reason);
  assert.equal(r.info.national, Number(sp.no));
  assert.equal(r.info.otName, 'AAAAAAA');
  assert.ok(r.info.exp > 0 && r.info.moves.length <= 4);
  const pid = pidFor(13, true, 0x12345678, 99);
  assert.equal(pid % 25, 13);
  assert.ok(((0x5678 ^ 0x1234 ^ (pid >>> 16) ^ (pid & 0xffff)) >>> 0) < 8);
});

test('only species a hack has can go into it: Seaglass (Gens 1–3 and their families) vs ROWE and Unbound', async () => {
  const { hackRecord, hackHas } = await import('../shared/engine/romhackSaves.js');
  const g = { national: 445, name: 'Garchomp', nickname: 'Garchomp', otName: 'A', pid: 1, otid: 2, exp: 33750, level: 30, moves: [89], pp: [10] };
  const sea = openGameSave(flash(), 'Pokemon - Emerald Seaglass Version.sav');
  assert.equal(hackRecord(sea, g).ok, false); // the Gible line isn't in Seaglass (it came out as an empty "???" there)
  assert.match(hackRecord(sea, g).reason, /doesn't have Garchomp/);
  assert.ok(hackRecord(sea, { ...g, national: 25, name: 'Pikachu' }).ok);
  assert.ok(hackHas('seaglass', 'expansion', 466).ok); // Electivire: a later evolution of a Gen 1 family
  assert.ok(hackHas('seaglass', 'expansion', 446).ok); // Munchlax: a later pre-evolution
  assert.ok(hackHas('seaglass', 'expansion', 959).ok); // Tinkaton: one of the easter eggs
  assert.equal(hackHas('seaglass', 'expansion', 887).ok, false); // Dragapult isn't
  assert.equal(hackHas('seaglass', 'expansion', 52, 'Galar').form, ''); // Galarian Meowth arrives as Meowth
  assert.equal(hackHas('seaglass', 'expansion', 19, 'Alola').form, 'Alola');
  assert.ok(SEAGLASS_NATIONAL.length > 400);
  // ROWE has everyone (Dragapult included)
  const d = flash(); w32(d, 0x1000 + 0x234, 1); d.set(roweMon(), 0x1000 + 0x238);
  const rowe = openGameSave(d, 'pkmn_rowe_experimental.sav');
  assert.ok(hackRecord(rowe, { ...g, national: 887, name: 'Dragapult' }).ok);
  // Unbound has no Gen 9
  const unb = openGameSave(flash(0x01121999), 'Pokemon Unbound.sav');
  assert.equal(hackRecord(unb, { ...g, national: 1000, name: 'Gholdengo' }).ok, false);
});

test('ROWE: writing into its 21-box PC (whole-sector checksums), reading back, and a Rhyhorn that levelled up here', async () => {
  const { hackRecord } = await import('../shared/engine/romhackSaves.js');
  const u32 = (dd, o) => (dd[o] | (dd[o + 1] << 8) | (dd[o + 2] << 16) | (dd[o + 3] << 24)) >>> 0;
  const sum = (dd, o, len) => { let t = 0; for (let i = 0; i < len; i += 4) t = (t + u32(dd, o + i)) >>> 0; return ((t >>> 16) + (t & 0xffff)) & 0xffff; };
  const d = flash(); w32(d, 0x1000 + 0x234, 1); d.set(roweMon(), 0x1000 + 0x238);
  const s = openGameSave(d, 'pkmn_rowe_experimental.sav');
  assert.equal(s.boxes.length, 21);
  const r = hackRecord(s, { national: 887, name: 'Dragapult', nickname: 'Dragapult', otName: 'Aaaaaaa', pid: 0x13572468, otid: 0xc7e137db, exp: 300000, level: 60, moves: [751, 89, 434, 506], pp: [10, 10, 5, 10], ball: 4, metLevel: 60 });
  assert.ok(r.ok, r.reason);
  assert.ok(s.put(20, 29, r.bytes, s.format).ok);
  const rh = s.party[0].pk;
  const up = hackRecord(s, { national: 111, name: 'Rhyhorn', raw: rh.hackRaw, rawHack: 'rowe', nickname: 'Rhyhorn', moves: [30, 28, 31, 479], level: 12, importLevel: 10, exp: 1728 });
  assert.ok(s.put(0, 0, up.bytes, s.format).ok);
  const out = s.toBytes();
  const s2 = openGameSave(out, 'pkmn_rowe_experimental.sav');
  const dg = s2.boxes[20].slots[29].pk;
  assert.deepEqual([dg.national, dg.moves, dg.exp, dg.nickname, dg.ball], [887, [751, 89, 434, 506], 300000, 'Dragapult', 4]);
  const r2 = s2.boxes[0].slots[0].pk;
  assert.deepEqual([r2.national, r2.moves, r2.exp, r2.pid], [111, [30, 28, 31, 479], 1728, rh.pid]);
  for (let i = 0; i < 14; i++) { const o = i * 0x1000, id = out[o + 0xff4]; if (id >= 5) assert.equal(sum(out, o, 0xff4), out[o + 0xff6] | (out[o + 0xff7] << 8), `sector ${id}`); }
});

test('a marker warns when training here won’t go back with a creature to its game', async () => {
  const { homeTransferNote } = await import('../shared/engine/hackTransfer.js');
  assert.match(homeTransferNote({ pk: { romhack: 'unbound', hackRaw: 'AA==' } }), /ROM hack.*backup.*effort, friendship/s);
  assert.match(homeTransferNote({ pk: { romhack: 'seaglass' } }), /may not go back exactly/);
  assert.match(homeTransferNote({ pk: { romhack: 'rowe', hackRaw: 'AA==' }, origin: { game: 'Pokémon ROWE' } }), /effort \(EV\) training doesn’t/);
  assert.match(homeTransferNote({ pk: { raw: 'AA==' }, origin: { game: 'Pokémon Emerald' } }), /exactly as it came/);
  assert.equal(homeTransferNote({}), null);
  const ui = fs.readFileSync(new URL('../shared/ui/summary.js', import.meta.url), 'utf8');
  assert.match(ui, /class: 'home-mark'/);
});
