import test from 'node:test';
import assert from 'node:assert/strict';
import { createDefaultDataset, indexDataset, battlePackage, battleKnows, parseAbilities, normalizeDataset } from '../shared/engine/index.js';
import { hitbox, meshArrays } from '../shared/ui/m3d/meshdata.js';
import { modelFor } from '../shared/ui/m3d/catalog.js';

test('a data set’s own creatures, moves, types and abilities go into the battle package', () => {
  const ds = createDefaultDataset();
  ds.abilities = [{ id: 'sun-soak', name: 'Sun Soak', desc: 'Sprout moves hit harder.', kind: 'typeBoost', type: 'sprout' }];
  ds.species[0].abilities = ['Sun Soak'];
  const idx = indexDataset(ds), pkg = battlePackage(idx);
  assert.equal(pkg.species.length, ds.species.length);
  assert.deepEqual(pkg.species[0].types, ['Sprout']);
  assert.deepEqual(pkg.species[0].abilities, ['Sun Soak']);
  assert.equal(pkg.abilities[0].type, 'Sprout');
  assert.equal(pkg.types.find((t) => t.name === 'Ember').against.Sprout, 2);
  // what can battle: Showdown's, plus the data set's own
  const SD = { custom: true, knows: (k, n) => n === 'Pikachu' };
  const can = battleKnows(SD, idx);
  assert.ok(can('species', 'Pikachu')); assert.ok(can('species', 'Sproutle')); assert.ok(can('move', 'Leaf Flick')); assert.ok(can('ability', 'Sun Soak'));
  assert.ok(!can('species', 'Nobody'));
});

test('abilities upload from CSV or JSON', () => {
  const types = createDefaultDataset().types;
  const csv = parseAbilities('name,description,kind,like,type,stat,amount\nSun Soak,Sprout moves hit harder,typeBoost,,Sprout,,\n"Cloud Hop","Floats, like Levitate",like,Levitate,,,\nWarm Up,Speed up,turnBoost,,,spe,2', types);
  assert.equal(csv.length, 3);
  assert.equal(csv[0].type, 'sprout'); assert.equal(csv[1].desc, 'Floats, like Levitate'); assert.equal(csv[1].like, 'Levitate'); assert.equal(csv[2].stat, 'spe'); assert.equal(csv[2].amount, 2);
  const js = parseAbilities(JSON.stringify([{ name: 'Thick Moss', desc: 'Shrugs off frost', kind: 'immune', type: 'Frost' }, { name: 'Odd' }]), types);
  assert.equal(js[0].kind, 'immune'); assert.equal(js[0].type, 'frost'); assert.equal(js[1].kind, 'none');
  // kept by the data set
  const ds = normalizeDataset({ ...createDefaultDataset(), abilities: js });
  assert.equal(ds.abilities.length, 2); assert.ok(ds.abilities[0].id);
});

test('3D models: solid spans (a rock is solid to the ground, the gazebo has room under its roof)', () => {
  const rock = modelFor('rock', { seed: 1 }), hb = hitbox(rock);
  const mid = (H) => { const i = Math.floor((0 - H.x0) / H.cs), k = Math.floor((0 - H.z0) / H.cs), c = k * H.nx + i; return [...H.iv.slice(H.off[c], H.off[c + 1])]; };
  const r = mid(hb);
  assert.ok(r.length >= 2 && r[0] <= rock.lo[1] + 0.01 && r[r.length - 1] > 0.3, `rock spans ${r}`);
  const gz = modelFor('gazebo', {}), g = mid(hitbox(gz));
  assert.ok(g.length >= 4, `gazebo spans ${g}`);
  assert.ok(g[2] - g[1] > 1.2, 'room under the roof');
  const a = meshArrays(gz);
  assert.equal(a.data.length % 20, 0); assert.equal(a.idx.length % 3, 0); assert.ok(a.nOpaque > 0);
});

test('forms go into battle linked to their usual form, and the ability file reads a stance form', () => {
  const ds = createDefaultDataset(), sp = ds.species[0];
  sp.baseForme = 'Meteor';
  ds.species.push({ ...JSON.parse(JSON.stringify(sp)), id: 'sproutle-awakened', no: 10001, name: 'Sproutle-Awakened', forme: 'Awakened', baseSpecies: sp.id, battleOnly: true });
  const pkg = battlePackage(indexDataset(ds));
  const base = pkg.species.find((x) => x.name === 'Sproutle'), form = pkg.species.find((x) => x.name === 'Sproutle-Awakened');
  assert.equal(base.baseForme, 'Meteor');
  assert.deepEqual([form.baseSpecies, form.forme, form.battleOnly], ['Sproutle', 'Awakened', true]);
  const [d] = parseAbilities(JSON.stringify([{ name: 'Dormancy', desc: 'Stance Change, but…', kind: 'stance', form: 'Awakened' }]), ds.types);
  assert.equal(d.kind, 'stance'); assert.equal(d.form, 'Awakened');
});
