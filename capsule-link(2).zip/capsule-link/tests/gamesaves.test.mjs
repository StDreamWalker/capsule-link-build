// Game saves: a made-up FireRed save and a made-up Red save (the layouts the games use), opened, read,
// changed (creatures taken out and put back) and written with the games' checksums.
// (Checked against real saves from every supported game while writing this; those can't be shipped here.)
import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const w16 = (d, o, v) => { d[o] = v & 255; d[o + 1] = (v >> 8) & 255; };
const w32 = (d, o, v) => { w16(d, o, v & 0xffff); w16(d, o + 2, (v >>> 16) & 0xffff); };
const u16 = (d, o) => d[o] | (d[o + 1] << 8);

/** A Gen 3 creature as PKHeX saves it (decrypted, blocks in order). */
function pk3({ species = 25, pid = 0x12345678, otid = 0x0000abcd, nick = 'PIKA', version = 4 } = {}) {
  const d = new Uint8Array(80);
  w32(d, 0, pid); w32(d, 4, otid);
  const enc = (s) => [...s].map((ch) => (ch >= 'A' && ch <= 'Z' ? 0xbb + ch.charCodeAt(0) - 65 : 0));
  d.fill(0xff, 8, 18); enc(nick).forEach((b, i) => { d[8 + i] = b; });
  d[0x12] = 2; d[0x13] = 2; d.fill(0xff, 0x14, 0x1b); enc('ASH').forEach((b, i) => { d[0x14 + i] = b; });
  w16(d, 0x20, species); w32(d, 0x24, 1000); w16(d, 0x2c, 84); d[0x34] = 30;
  w16(d, 0x44 + 2, 5 | (version << 7) | (4 << 11)); // met at 5, game, Poké Ball
  let sum = 0; for (let i = 32; i < 80; i += 2) sum = (sum + u16(d, i)) & 0xffff;
  w16(d, 0x1c, sum);
  return d;
}
function blankGen3() {
  const d = new Uint8Array(0x20000);
  for (let i = 0; i < 14; i++) { const o = i * 0x1000; w16(d, o + 0xff4, i); w32(d, o + 0xff8, 0x08012025); w32(d, o + 0xffc, 1); }
  w32(d, 0xac, 1); // FireRed/LeafGreen keep a fixed 1 here
  [0xc0, 0xbb, 0xc8].forEach((b, i) => { d[i] = b; }); d[3] = 0xff; // trainer "FAN"
  return d;
}

test('a Gen 3 save: put a creature in, write it, read it back; the game’s sector checksums are right', () => {
  const sav = E.openGameSave(blankGen3(), 'FireRed.sav');
  assert.ok(sav.ok, sav.error);
  assert.equal(sav.gen, 3); assert.equal(sav.game, 'FireRed or LeafGreen'); assert.equal(sav.boxes.length, 14);
  assert.equal(sav.boxes.flatMap((b) => b.slots).filter(Boolean).length, 0);
  const r = sav.put(2, 7, pk3(), 'pk3');
  assert.ok(r.ok, r.reason);
  const out = sav.toBytes();
  // every sector's checksum: 32-bit sum of the first 0xF80 bytes, folded
  for (let i = 0; i < 14; i++) {
    let c = 0; for (let k = 0; k < 0xf80; k += 4) c = (c + (out[i * 0x1000 + k] | (out[i * 0x1000 + k + 1] << 8) | (out[i * 0x1000 + k + 2] << 16) | (out[i * 0x1000 + k + 3] << 24))) >>> 0;
    assert.equal(u16(out, i * 0x1000 + 0xff6), (c + (c >>> 16)) & 0xffff, `sector ${i}`);
  }
  const again = E.openGameSave(out, 'FireRed.sav');
  const e = again.boxes[2].slots[7];
  assert.ok(e); assert.equal(e.pk.national, 25); assert.equal(e.pk.nickname, 'PIKA'); assert.equal(e.pk.version, 4);
  // stored encrypted in the save (not as the plain file)
  assert.notDeepEqual([...e.bytes.slice(32, 40)], [...pk3().slice(32, 40)]);
  // and out again
  assert.ok(again.take(2, 7).ok);
  assert.equal(E.openGameSave(again.toBytes(), 'x.sav').boxes[2].slots[7], null);
});

test('Hoenn creatures keep their National number (Gen 3 numbers them differently): Treecko is #252', () => {
  const sav = E.openGameSave(blankGen3(), 'x.sav');
  sav.put(0, 0, pk3({ species: 277, nick: 'TREECKO', pid: 99 }), 'pk3');
  assert.equal(E.openGameSave(sav.toBytes(), 'x.sav').boxes[0].slots[0].pk.national, 252);
});

/** A Red/Blue save with an empty party and an empty current box. */
function blankGen1() {
  const d = new Uint8Array(0x8000);
  d[0x2f2c] = 0; d[0x2f2d] = 0xff; // party
  d[0x30c0] = 0; d[0x30c1] = 0xff; // current box
  d[0x284c] = 0; // box 1, the others not set up yet
  [0x80, 0x92].forEach((b, i) => { d[0x2598 + i] = b; }); d[0x259a] = 0x50; // "AS"
  return d;
}
function pk1List({ internal = 0x54, nick = 'PIKACHU', level = 12 } = {}) {
  const enc = (s) => { const a = new Array(11).fill(0x50); [...s].forEach((ch, i) => { a[i] = 0x80 + ch.charCodeAt(0) - 65; }); return a; };
  const d = new Uint8Array(69);
  d[0] = 1; d[1] = internal; d[2] = 0xff;
  d[3] = internal; d[3 + 3] = level; d[3 + 8] = 84; d[3 + 0x0c] = 0x12; d[3 + 0x0d] = 0x34; d[3 + 0x10] = 0x0f; d[3 + 0x1b] = 0xff; d[3 + 0x1c] = 0xff; d[3 + 0x21] = level;
  d.set(enc('ASH'), 47); d.set(enc(nick), 58);
  return d;
}

test('a Red/Blue save: boxes are packed lists; creatures go in and out and the checksum is right', () => {
  const sav = E.openGameSave(blankGen1(), 'Red.sav');
  assert.ok(sav.ok, sav.error); assert.equal(sav.gen, 1); assert.equal(sav.trainer.name, 'AS');
  assert.ok(sav.put(0, 0, pk1List(), 'pk1').ok);
  assert.ok(sav.put(0, 1, pk1List({ internal: 0x99, nick: 'BULBASAUR' }), 'pk1').ok);
  assert.ok(sav.put(4, 0, pk1List({ internal: 0xb0, nick: 'CHARMANDER' }), 'pk1').ok, 'another box (the game sets the boxes up)');
  let out = sav.toBytes();
  let x = 0; for (let i = 0x2598; i < 0x3523; i++) x = (x + out[i]) & 255;
  assert.equal(out[0x3523], (~x) & 255);
  const s2 = E.openGameSave(out, 'Red.sav');
  assert.equal(s2.boxes[0].slots[0].pk.national, 25); assert.equal(s2.boxes[0].slots[1].pk.national, 1);
  assert.equal(s2.boxes[4].slots[0].pk.national, 4);
  assert.equal(s2.boxes[0].slots[0].pk.nickname, 'PIKACHU');
  // taking the first one out moves the next one up
  assert.ok(s2.take(0, 0).ok);
  const s3 = E.openGameSave(s2.toBytes(), 'Red.sav');
  assert.equal(s3.boxes[0].slots[0].pk.national, 1); assert.equal(s3.boxes[0].slots[1], null);
  // and it comes over as a creature with its old game remembered
  const idx = E.indexDataset(E.createDefaultDataset());
  const r = E.pkhexToCreature(idx, s3.boxes[0].slots[0].pk, { species: idx.ds.species[0] });
  assert.equal(r.creature.origin.game, 'Red, Blue or Yellow');
});

test('wrong generation or a signed game is refused politely', () => {
  const sav = E.openGameSave(blankGen3(), 'x.sav');
  assert.equal(sav.put(0, 0, pk1List(), 'pk1').ok, false);
  assert.equal(E.openGameSave(new Uint8Array(1234), 'x.sav').ok, false);
});
