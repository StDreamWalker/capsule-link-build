// 0.9.8: doing what you ask (nap, wake, weather, mega…), less food-focused replies, the bigger berry farm.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const base = () => { const idx = E.indexDataset(E.createDefaultDataset()); const save = E.createSave('Kim', 2); E.tickAll(idx, save); return { idx, save }; };
const fluent = (idx, save, sp = 1) => { const c = E.createCreature(idx, idx.ds.species[sp].id, { level: 70 }); c.origin = { from: 'pkhex' }; c.friendship = 220; save.creatures[c.uid] = c; return c; };

test('commands: they nap, wake up, come, dance and move when they understand you', () => {
  const { idx, save } = base();
  const c = fluent(idx, save);
  const t = Date.now();
  c.needs.energy = 40;
  const nap = E.talkTo(idx, save, c, 'time to sleep, take a nap', t);
  assert.equal(nap.act?.kind, 'nap');
  assert.ok(c.sleep && c.sleep.until > t, 'they really fell asleep');
  const other = E.talkTo(idx, save, c, 'do you like this song?', t + 60000);
  assert.match(other.note, /asleep|sleep|snores/);
  const wake = E.talkTo(idx, save, c, 'wake up!', t + 120000);
  assert.equal(wake.act?.kind, 'wake');
  assert.ok(!(c.sleep && c.sleep.until > t + 120000), 'awake again');
  assert.equal(E.talkTo(idx, save, c, 'come here!', t + 200000).act?.kind, 'come');
  assert.equal(E.talkTo(idx, save, c, 'go left', t + 300000).act?.dir, 'left');
  assert.equal(E.talkTo(idx, save, c, 'dance!', t + 400000).act?.kind, 'dance');
});

test('weather: only creatures with a weather move or ability can change it, and it lasts a while', () => {
  const { idx, save } = base();
  const c = fluent(idx, save);
  const t = Date.now();
  const no = E.talkTo(idx, save, c, 'make it rain', t);
  assert.ok(!no.act, 'no weather power: they can’t');
  assert.match(no.note, /doesn't know how|can't/);
  idx.moves.set('rain-dance', { id: 'rain-dance', name: 'Rain Dance', type: idx.ds.moves[0].type, category: 'status' });
  c.moves = [...c.moves, { id: 'rain-dance', pp: 5 }];
  assert.ok(E.weatherPowers(idx, c).has('rain'));
  const yes = E.talkTo(idx, save, c, 'shift to rain please', t + 60000);
  assert.equal(yes.act?.weather, 'rain');
  assert.equal(E.yardWeatherSetting(save, t + 120000), 'rain');
  assert.notEqual(E.yardWeatherSetting(save, t + 60000 + E.WEATHER_CALL_MINUTES * 60000 + 1000), 'rain');
});

test('what they want: activities and plans, not just berries', () => {
  const { idx, save } = base();
  const c = fluent(idx, save);
  c.needs.fullness = 90;
  const seen = new Set();
  for (let d = 0; d < 12; d++) {
    const t = new Date(2026, 10, 1 + d, 12).getTime();
    const r = E.talkTo(idx, save, c, 'what do you want to do today?', t);
    seen.add(r.wish ?? (r.bubble?.kind === 'item' ? 'food' : 'other'));
  }
  assert.ok(seen.size >= 3, `varied plans: ${[...seen]}`);
  assert.ok(![...seen].every((w) => w === 'food'));
});

test('berry farm: expansions add planters, tools speed it up and add more, mulch works for one planting', () => {
  const { idx, save } = base();
  const seed = E.plantable(idx)[0];
  save.inventory[seed.id] = 10;
  assert.equal(E.farmPlots(save), 6);
  assert.equal(E.expandFarm(save).ok, false);
  save.inventory['bp-farm-expand'] = 2;
  assert.equal(E.expandFarm(save).plots, 9);
  assert.equal(E.farmState(save).plots.length, 9);
  // a tool is bought once
  save.wallet = 99999;
  assert.ok(E.buyBlueprint(save, 'wailmer-pail').ok);
  assert.equal(E.buyBlueprint(save, 'wailmer-pail').ok, false);
  assert.equal(E.toolSpeed(save), 1.3);
  assert.ok(E.buyBlueprint(save, 'gooey-mulch').ok);
  assert.ok(E.buyBlueprint(save, 'golden-shears').ok);
  const t = Date.now();
  assert.ok(E.plant(idx, save, 8, seed.id, t, 'gooey-mulch').ok);
  assert.equal(save.inventory['bp-gooey-mulch'], 0);
  const hours = E.growInfo(seed).hours;
  assert.equal(E.plotStatus(idx, E.farmState(save).plots[8], t + (hours / 1.3) * 3600000 + 1000).ready, true, 'grows 30% faster');
  const r = E.harvest(idx, save, 8, t + hours * 3600000);
  assert.ok(r.ok && r.count >= E.growInfo(seed).yield + 1, 'shears add one');
  assert.ok(r.regrew && E.farmState(save).plots[8], 'gooey mulch grows it back once');
  const r2 = E.harvest(idx, save, 8, t + hours * 7200000);
  assert.ok(r2.ok && !r2.regrew && !E.farmState(save).plots[8]);
});
