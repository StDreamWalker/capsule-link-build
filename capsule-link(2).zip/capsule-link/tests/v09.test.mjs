// 0.9.0: gradual naps, type incenses, clothes per form, the real sky, memory imports and PKHeX exports,
// power items, wild battles and healing over time.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const base = () => {
  const idx = E.indexDataset(E.createDefaultDataset());
  const save = E.createSave('Kim', 2);
  E.tickAll(idx, save);
  return { idx, save };
};
const add = (idx, save, loc = { kind: 'box', box: 0, slot: 0 }, sp = 0) => { const c = E.createCreature(idx, idx.ds.species[sp].id, { level: 12, location: loc }); save.creatures[c.uid] = c; return c; };

test('naps fill energy bit by bit (0 to 100 in 90 minutes; twice as fast in a Dream Ball) and waking keeps what they got', () => {
  const { idx, save } = base();
  const c = add(idx, save);
  const t0 = Date.now();
  c.quirks = []; c.needs.energy = 0; c.needsAt = t0;
  assert.equal(E.applyCare(idx, c, 'rest', { at: t0 }).reaction, 'sleep');
  assert.ok(Math.abs((c.sleep.until - t0) / 60000 - 90) < 1, 'a 90-minute nap from empty');
  E.tickNeeds(idx, c, t0 + 45 * 60000);
  assert.ok(c.needs.energy > 40 && c.needs.energy < 60, `half way: ${c.needs.energy}`);
  const d = add(idx, save, { kind: 'box', box: 0, slot: 1 });
  d.ball = '25'; d.quirks = []; d.needs.energy = 0; d.needsAt = t0;
  E.applyCare(idx, d, 'rest', { at: t0 });
  assert.ok(Math.abs((d.sleep.until - t0) / 60000 - 45) < 1, 'Dream Ball: 45 minutes');
  const e0 = c.needs.energy;
  E.applyCare(idx, c, 'wake', { at: t0 + 45 * 60000 });
  assert.ok(!E.isAsleep(c, t0 + 45 * 60000));
  assert.ok(c.needs.energy >= e0 - 0.01, 'kept the energy');
});

test('every type has an incense: held it is 1.2× (Showdown gets the matching booster), lit it draws that type', () => {
  const { idx, save } = base();
  const list = E.incenseItems(idx);
  assert.equal(list.length, idx.types.size);
  const fire = { name: 'Fire' };
  assert.equal(E.TYPE_BOOSTER[fire.name.toLowerCase()], 'Charcoal');
  const sea = { id: 'sea-incense', name: 'Sea Incense', kind: 'held' };
  assert.ok(E.isIncense(sea));
  assert.ok(E.itemUses(sea).includes('light') && E.itemUses(sea).includes('hold'));
  const it = list[0];
  save.inventory[it.id] = 1;
  assert.ok(E.lightIncense(idx, save, it.id).ok);
  assert.equal(E.activeIncense(save).type, it.type);
});

test('clothes keep a placement per form, and the first placement for forms without one', () => {
  const save = { creatures: { a: { uid: 'a', speciesId: 'x', clothes: [] } }, inventory: { 'clothes-bow': 1 } };
  assert.ok(E.wear(save, 'a', 'clothes-bow', 0.5, 0.2, 1).ok);
  assert.ok(E.wear(save, 'a', 'clothes-bow', 0.3, 0.6, 1.4, 'x-mega').ok);
  const w = save.creatures.a.clothes[0];
  assert.deepEqual(E.wornAt(w, 'x'), { fx: 0.5, fy: 0.2, s: 1, r: 0 });
  assert.deepEqual(E.wornAt(w, 'x-mega'), { fx: 0.3, fy: 0.6, s: 1.4, r: 0 });
  assert.deepEqual(E.wornAt(w, 'x-gmax'), { fx: 0.5, fy: 0.2, s: 1, r: 0 });
  assert.ok(E.CLOTHES.length > 60, 'more clothes and colours');
});

test('the real sky: sun times from a rough location decide night and day; fog from visibility', () => {
  const s = E.sunTimes(Date.UTC(2026, 9, 31, 12), 40.7, -74.0);
  const rise = new Date(s.sunrise), set = new Date(s.sunset);
  assert.equal(rise.getUTCHours(), 11); // 7:2x in New York
  assert.ok(set.getUTCHours() === 21 || set.getUTCHours() === 22);
  E.setSky({ lat: 40.7, lon: -74.0, at: Date.now(), weather: 'clouds', visibility: 400 });
  assert.equal(E.yardWeather(), 'fog');
  assert.equal(E.timeOfDay(Date.UTC(2026, 9, 31, 3)), 'night');
  E.setSky(null);
});

test('import from memory, then send to PKHeX and back: the same creature, memories kept', () => {
  const { idx, save } = base();
  const n = E.narrow(idx, { types: [idx.types.values().next().value.name] });
  assert.ok(n.list.length >= 1 && n.list.length < n.total);
  const sp = idx.ds.species[3];
  const { creature: c } = E.creatureFromMemory(idx, { speciesId: sp.id, pid: '1A2B3C4D', nickname: 'Pip', met: 'caught', game: 50, place: 'Asado Desert', ball: 25, otName: 'Kim', otId: '123456', nature: 'Timid', level: 30, evs: { spe: 252 }, memories: ['won our first gym together'] }, { trainer: 'Kim', location: { kind: 'box', box: 0, slot: 0 } });
  save.creatures[c.uid] = c;
  assert.equal(c.level, 30);
  assert.ok(c.memories.some((m) => /Asado Desert/.test(m.text)));
  const r = E.exportPkm(idx, c);
  assert.ok(r.ok, r.error);
  const pk = E.readPkm(r.bytes, r.name);
  assert.ok(pk.ok);
  assert.equal(pk.pid, 0x1a2b3c4d);
  assert.equal(pk.nickname, 'Pip');
  assert.equal(pk.evs.spe, 252);
  assert.equal(pk.ball, 25);
  assert.equal(pk.trainerId, 123456);
  // back from PKHeX: recognised, updated, memories still there
  c.pk.exported = r.ident;
  assert.equal(E.alreadyImported(save, pk)?.uid, c.uid);
  const mems = c.memories.length;
  E.refreshFromPkm(idx, c, pk);
  assert.ok(c.memories.length >= mems);
});

test('wild battles: Showdown teams carry the damage and PP; winners get experience and effort; healing over time and medicine', () => {
  const { idx, save } = base();
  const c = add(idx, save, { kind: 'party', slot: 0 });
  c.level = 40; c.exp = E.expForLevel(idx, E.speciesOf(idx, c).growthRate, 40);
  c.hp = 30; c.moves[0].pp = 3;
  const w = E.rollWild(idx, save, { seed: 5 });
  assert.ok(w);
  const t = E.wildTeams(idx, save, w);
  assert.equal(t.team.length, 1);
  assert.equal(t.team[0].hpLeft, 30, 'starts hurt');
  assert.equal(t.team[0].ppLeft[0], 3, 'with the PP it has left');
  assert.ok(t.foe.species && t.foe.moves.length);
  assert.equal(E.rollWild(idx, save, { seed: 5, known: () => false }), null, 'nothing Showdown knows: no wild battle');
  const name = t.team[0].name;
  const res = { won: true, ran: false, out: [name], team: { [name]: { hp: 12, status: 'tox', pp: [1, 10, 10, 10], fainted: false } } };
  const exp0 = c.exp;
  const r = E.wildOutcome(idx, w, res, t.map);
  E.applyEvent(idx, save, E.makeEvent('wild', { result: r }));
  assert.ok(c.exp > exp0, 'experience');
  assert.equal(c.status, 'psn');
  assert.equal(c.moves[0].pp, 1);
  assert.ok(c.hp != null && c.hp < E.calcStats(idx, c).hp, 'still hurt');
  save.inventory['med-potion'] = 1;
  const hp0 = c.hp;
  assert.ok(E.useMedicine(idx, save, c.uid, 'med-potion').ok);
  assert.ok(c.hp == null || c.hp > hp0);
  c.hp = 1; c.healAt = Date.now();
  E.healTick(idx, c, Date.now() + 25 * 60000);
  assert.equal(c.hp, null, 'healed by itself');
});

test('the satchel: packed at the PC, used on the phone, and the PC takes it out of the satchel (not the bag)', () => {
  const { idx, save } = base();
  const c = add(idx, save, { kind: 'phone', device: 'p1' });
  const berry = idx.ds.items.find((i) => i.kind === 'food' && !i.unlimited);
  save.inventory[berry.id] = 3;
  assert.equal(E.packSatchel(save, berry.id, 2), 2);
  assert.equal(save.inventory[berry.id], 1);
  assert.equal(save.satchel[berry.id], 2);
  c.needs.fullness = 10;
  const r = E.applyEvent(idx, save, E.makeEvent('care', { uid: c.uid, action: 'feed', item: berry.id, satchel: true }));
  assert.ok(r.ok);
  assert.equal(save.satchel[berry.id], 1, 'eaten from the satchel');
  assert.equal(save.inventory[berry.id], 1, 'the bag at home is untouched');
  E.unpackSatchel(save);
  assert.equal(save.inventory[berry.id], 2);
  // naps on the phone too
  c.needs.energy = 20;
  assert.equal(E.applyEvent(idx, save, E.makeEvent('care', { uid: c.uid, action: 'rest', satchel: true })).outcome.reaction, 'sleep');
});
