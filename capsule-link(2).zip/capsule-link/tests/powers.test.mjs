import test from 'node:test';
import assert from 'node:assert/strict';
import { powerOf, canUse, elementOf, POWER_BY_ID } from '../shared/engine/powers.js';

test('powers: asking for a move or a power finds it', () => {
  const cases = { 'Charmander, light the campfire': 'fire', 'Pikachu, make some sparks!': 'spark', 'Ditto, turn into Pikachu': 'transform', 'Abra, teleport!': 'teleport',
    'Squirtle, water the plants': 'water', 'show me a trick': 'trick', 'use Thunderbolt': 'spark', 'Mew, levitate that rock': 'levitate', 'dig a hole': 'dig', 'Magikarp, use splash': 'splash' };
  for (const [t, want] of Object.entries(cases)) assert.equal(powerOf(t)?.id, want, t);
  assert.equal(powerOf('[power:heal] whatever')?.id, 'heal');
});

test('powers: who can do it (a move, their type, or what they are)', () => {
  const idx = { species: new Map([['flarepup', { id: 'flarepup', name: 'Flarepup', types: ['cinder'] }], ['ditto', { id: 'ditto', name: 'Ditto', types: ['normal'] }], ['plainy', { id: 'plainy', name: 'Plainy', types: ['normal'] }]]),
    types: new Map([['cinder', { name: 'Cinder' }]]), moves: new Map([['tp', { id: 'tp', name: 'Teleport', type: 'psychic' }]]) };
  assert.equal(elementOf('Cinder'), 'fire');
  assert.ok(canUse(idx, { speciesId: 'flarepup', moves: [] }, POWER_BY_ID.fire).ok);
  assert.ok(canUse(idx, { speciesId: 'ditto', moves: [] }, POWER_BY_ID.transform).ok);
  assert.ok(canUse(idx, { speciesId: 'plainy', moves: [{ id: 'tp' }] }, POWER_BY_ID.teleport).ok);
  const no = canUse(idx, { speciesId: 'plainy', moves: [] }, POWER_BY_ID.fire);
  assert.equal(no.ok, false); assert.equal(no.example, 'Ember');
});
