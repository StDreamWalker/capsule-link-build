// 1.0.7: Showdown stays exactly Showdown (the vendored files are checked against upstream on every build),
// forced switches and form changes in the simulator, and the settings for battle volume.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { checkShowdown, verifyShowdown, VENDOR } from '../shared/sdbattle/verify.mjs';

test('every vendored Showdown file matches the upstream manifest (simulator, data, battle screen, styles)', () => {
  const r = checkShowdown();
  assert.ok(r.ok, JSON.stringify(r));
  assert.ok(r.checked >= 60, `only ${r.checked} files in the manifest`);
  const m = fs.readFileSync(path.join(VENDOR, 'MANIFEST.sha256'), 'utf8');
  for (const f of ['sim/battle.ts', 'sim/battle-actions.ts', 'data/moves.ts', 'data/abilities.ts', 'data/conditions.ts', 'client/battle.ts', 'client/battle-animations.ts']) assert.match(m, new RegExp(`  ${f.replace('.', '\\.')}\\n`), f);
});

test('an edited, missing or extra Showdown file stops the build', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clsdv-'));
  fs.cpSync(VENDOR, tmp, { recursive: true });
  assert.ok(checkShowdown(tmp).ok);
  // a "simplified" move: Dive no longer hides its user
  const mv = path.join(tmp, 'data', 'moves.ts');
  fs.writeFileSync(mv, fs.readFileSync(mv, 'utf8').replace('dive: {', 'dive: { // simpler\n'));
  assert.deepEqual(checkShowdown(tmp).changed, ['data/moves.ts']);
  assert.throws(() => verifyShowdown(tmp), /don't match upstream[\s\S]*changed: data\/moves\.ts/);
  fs.rmSync(path.join(tmp, 'sim', 'field.ts'));
  fs.writeFileSync(path.join(tmp, 'sim', 'shortcut.ts'), 'export {}');
  const r = checkShowdown(tmp);
  assert.deepEqual([r.missing, r.extra], [['sim/field.ts'], ['sim/shortcut.ts']]);
  fs.rmSync(tmp, { recursive: true, force: true });
});

test('both Showdown bundles check the vendored files first, and each bundling swap must match exactly', () => {
  const src = fs.readFileSync(new URL('../shared/sdbattle/build.mjs', import.meta.url), 'utf8');
  assert.match(src, /buildShowdownBattle[^]*?\{\s*verifyShowdown\(\);/);
  assert.match(src, /buildShowdownSim[^]*?\{\s*verifyShowdown\(\);/);
  assert.doesNotMatch(src, /readFileSync\(a\.path, 'utf8'\)\.replace\(/, 'a loose replace that could silently do nothing');
  const wild = fs.readFileSync(new URL('../shared/sdbattle/wild.js', import.meta.url), 'utf8');
  assert.match(wild, /checkSimIntact\(\);/);
  assert.match(wild, /showdownIntact: intact/);
});

async function esbuild() {
  try { return await import('esbuild'); } catch { /* not here */ }
  if (process.env.ESBUILD_PATH) return import(pathToFileURL(process.env.ESBUILD_PATH).href);
  for (const p of ['../desktop/node_modules/esbuild/lib/main.js', '/opt/npm-tools/node_modules/esbuild/lib/main.js']) { const f = p.startsWith('/') ? pathToFileURL(p) : new URL(p, import.meta.url); if (fs.existsSync(f)) return import(f.href); }
  return null;
}
let SIM = null;
async function sim(t) {
  if (SIM) return SIM;
  const eb = await esbuild();
  if (!eb) { t.skip('esbuild not installed'); return null; }
  const { buildShowdownSim } = await import('../shared/sdbattle/build.mjs');
  const out = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'clsd-')), 'sim.mjs');
  await buildShowdownSim(eb, out);
  SIM = await import(pathToFileURL(out).href);
  return SIM;
}
async function battle(S, a, b, choicesA, choicesB) {
  const stream = new S.BattleStream();
  const ps = S.getPlayerStreams(stream);
  const log = [];
  const drive = async (s, choices) => { let i = 0; for await (const chunk of s) { const m = /\|request\|(.+)/.exec(chunk); if (m) { const r = JSON.parse(m[1]); if (r.active || r.forceSwitch) s.write(r.forceSwitch ? 'default' : choices[Math.min(i++, choices.length - 1)]); } } };
  drive(ps.p1, choicesA); drive(ps.p2, choicesB);
  (async () => { for await (const chunk of ps.omniscient) log.push(chunk); })();
  ps.omniscient.write(`>start ${JSON.stringify({ formatid: 'gen9capsulewild', seed: [1, 2, 3, 4] })}\n>player p1 ${JSON.stringify({ name: 'A', team: a })}\n>player p2 ${JSON.stringify({ name: 'B', team: b })}`);
  for (let i = 0; i < 200 && !(stream.battle?.ended || stream.battle?.turn > choicesA.length + 1); i++) await new Promise((r) => setTimeout(r, 10));
  return log.join('\n');
}
const mon = (species, moves, extra = {}) => ({ name: species, species, moves, level: 50, evs: { hp: 0, atk: 0, def: 0, spa: 0, spd: 0, spe: 0 }, ...extra });

test('Whirlwind drags the next one in (the screen gets |drag| and shows it)', async (t) => {
  const S = await sim(t); if (!S) return;
  const text = await battle(S, [mon('Pidgeot', ['Whirlwind'])], [mon('Rattata', ['Tackle']), mon('Pikachu', ['Tackle'])], ['move 1'], ['move 1']);
  assert.match(text, /\|move\|p1a: Pidgeot\|Whirlwind\|p2a: Rattata/);
  assert.match(text, /\|drag\|p2a: Pikachu\|Pikachu/);
});

test('Castform changes form with the weather it sets up, and back when it ends (Forecast)', async (t) => {
  const S = await sim(t); if (!S) return;
  const text = await battle(S, [mon('Castform', ['Sunny Day', 'Rain Dance', 'Splash'], { ability: 'Forecast' })], [mon('Snorlax', ['Rest'])], ['move 1', 'move 2', 'move 3'], ['move 1']);
  assert.match(text, /\|-formechange\|p1a: Castform\|Castform-Sunny/);
  assert.match(text, /\|-formechange\|p1a: Castform\|Castform-Rainy/);
});

test('ground detail: every battle place gets its own little things, never on the two battle spots', async () => {
  const { buildScatter } = await import('../shared/ui/groundScatter.js');
  const spots = [[-2.3, 1.7], [2.3, 8.3]];
  const kinds = {};
  for (const [biome, arena] of [['meadow', null], ['forest', null], ['cavern', null], ['volcano', null], ['shoreline', null], ['tundra', null], ['crystal', null], ['ruins', 'ruins'], ['shrine', 'shrine'], ['prism', 'prism'], ['synth', 'neon']]) {
    const { items, lights } = buildScatter({ biome, arena, seed: 3, spots, center: [0, 5], radius: arena ? 15 : 30 });
    assert.ok(items.length > (arena ? 150 : 400), `${biome}: ${items.length}`);
    for (const g of items) for (const [sx, sz] of spots) assert.ok(Math.hypot((g.x - sx) / 1.25, (g.z - sz) / 0.85) >= 1, `${biome} on a spot`);
    kinds[biome] = new Set(items.map((g) => g.k));
    if (['volcano', 'crystal'].includes(biome)) assert.ok(lights.length > 0, `${biome} glows`);
  }
  assert.ok(kinds.meadow.has('grass') && kinds.meadow.has('flower'));
  assert.ok(kinds.forest.has('leaf') && kinds.forest.has('shroom'));
  assert.ok(kinds.volcano.has('ember') && kinds.cavern.has('pebble') && kinds.shoreline.has('shell') && kinds.tundra.has('snow'));
  assert.ok(kinds.shrine.has('petal') && kinds.synth.has('stud') && kinds.prism.has('shard'));
});

test('lighting: lamps, arena lights, fire creatures and moves are gathered; faces turned to a light brighten, others don\'t', async () => {
  const L = await import('../shared/ui/lighting.js');
  const yard = { time: 0, light: 'night', biome: 'meadow', L: {}, cx: 0, cz: -3, ys: 0, yc: 1,
    props: [{ kind: 'lamppost', x: 2, z: 4, h: 3.4 }, { kind: 'arena3d', x: -5, z: 5, h: 19, glow: 2.2, lightY: 18, light: { r: 30, i: 1.1, c: [255, 246, 226] } }, { kind: 'tree', x: 0, z: 0, h: 3 }],
    actors: new Map([['a', { x: 1, z: 1, fire: true, appear: 1 }]]), heightOf: () => 1,
    dynLights: [{ x: 0, y: 1, z: 2, r: 5, c: [255, 120, 40], i: 1.5, dyn: true }] };
  const lights = L.gatherLights(yard);
  assert.equal(lights.length, 4);
  assert.ok(lights.some((l) => l.r === 30) && lights.some((l) => l.c[0] === 255 && l.c[1] === 140));
  yard.lit = lights;
  const near = [lights.find((l) => l.dyn)];
  const toward = L.faceLight(yard, near, 0, 1, 4, [0, 0, -1]), away = L.faceLight(yard, near, 0, 1, 4, [0, 0, 1]);
  assert.ok(toward && toward[0] > toward[2], 'lit warm');
  assert.equal(away, null);
  assert.ok(L.darkness({ light: 'night', L: {} }) > L.darkness({ light: 'day', L: {} }));
});

test('battle volume: its own setting on the PC and the phone, a slider in the battle, kept when changed', () => {
  const read = (p) => fs.readFileSync(new URL(p, import.meta.url), 'utf8');
  assert.match(read('../desktop/src/renderer/views/settings.js'), /Battle volume[^]*battleVolume/);
  assert.match(read('../mobile/src/views.js'), /Battle volume[^]*battleVolume/);
  assert.match(read('../desktop/src/renderer/views/battle.js'), /volume: st\.battleVolume \?\? st\.volume[^]*onVolume/);
  const wild = read('../shared/sdbattle/wild.js');
  assert.match(wild, /class="cl-sd-vol" type="range"/);
  assert.match(wild, /BattleSound\.setEffectVolume\(/);
  assert.match(wild, /opts\.onVolume\?\.\(volume\)/);
});
