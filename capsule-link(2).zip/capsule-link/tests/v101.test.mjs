// 1.0.1: your trainer picture from your Showdown account is picked up and kept for battles.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

test('the Showdown bridge reports the avatar picked on your account', () => {
  const src = E.bridgeScript({});
  assert.match(src, /type: 'user', name: name, named: S\.named, avatar: String\(p\[4\] \|\| ''\)/);
});
