// PKHeX import: a synthetic Scarlet/Violet file round-trips through encryption and maps onto a creature.
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const w16 = (d, o, v) => { d[o] = v & 255; d[o + 1] = (v >> 8) & 255; };
const w32 = (d, o, v) => { w16(d, o, v & 0xffff); w16(d, o + 2, v >>> 16); };
const wstr = (d, o, s) => { for (let i = 0; i < s.length; i++) w16(d, o + i * 2, s.charCodeAt(i)); };

function makePk9({ species = 7, nick = 'Sproutle', nicknamed = false } = {}) {
  const d = new Uint8Array(0x158);
  w32(d, 0x00, 0x9e3779b9); // encryption constant
  w16(d, 0x08, species);
  w16(d, 0x0c, 12345); w16(d, 0x0e, 54321);
  w32(d, 0x10, 1000);
  d[0x16] = 4; // hidden ability
  w32(d, 0x1c, 0x12345678);
  d[0x20] = 3; d[0x21] = 3; // Adamant
  d[0x22] = 1 | (1 << 1); // fateful, female
  d[0x26] = 4; d[0x27] = 252; d[0x29] = 252; // EVs hp atk spe
  wstr(d, 0x58, nick);
  w16(d, 0x72, 1); w16(d, 0x74, 9999); d[0x7a] = 30;
  const iv = 31 | (31 << 5) | (20 << 10) | (31 << 15) | (0 << 20) | (31 << 25) | (nicknamed ? 1 << 31 : 0);
  w32(d, 0x8c, iv >>> 0);
  wstr(d, 0xa8, 'Kim'); d[0xc4] = 1; d[0xc8] = 180; d[0xc9] = 5; d[0xca] = 12;
  d[0xce] = 50; d[0xd5] = 2;
  wstr(d, 0xf8, 'Ziggy'); d[0x112] = 120; d[0x113] = 3; d[0x114] = 7;
  d[0x11c] = 23; d[0x11d] = 4; d[0x11e] = 9;
  d[0x124] = 4; d[0x125] = 5;
  d[0x148] = 32;
  let sum = 0;
  for (let i = 8; i < 0x148; i += 2) sum = (sum + (d[i] | (d[i + 1] << 8))) & 0xffff;
  w16(d, 0x06, sum);
  return d;
}

const idx = E.indexDataset(E.createDefaultDataset());
const plain = makePk9();
const enc = E.encryptPkm(plain);
assert.notDeepEqual([...enc.slice(8, 40)], [...plain.slice(8, 40)], 'encryption changes the data');
assert.deepEqual([...E.decryptPkm(enc)], [...plain], 'decrypt(encrypt(x)) = x');

for (const [label, bytes] of [['decrypted', plain], ['encrypted', enc]]) {
  const pk = E.readPkm(bytes, 'test.pk9');
  assert.equal(pk.ok, true, label);
  assert.equal(pk.gen, 9);
  assert.equal(pk.national, 7);
  assert.equal(pk.nickname, 'Sproutle');
  assert.equal(pk.otName, 'Ziggy');
  assert.equal(pk.htName, 'Kim');
  assert.equal(pk.ivs.def, 20);
  assert.equal(pk.evs.spe, 252);
  assert.equal(pk.statLevel, 32);
  assert.equal(pk.version, 50);
  assert.equal(pk.fateful, true);
  assert.deepEqual(pk.metDate, { y: 2023, m: 4, d: 9 });
}

const pk = E.readPkm(plain, 'test.pk9');
const m = E.matchSpecies(idx, pk);
assert.ok(m.species, 'species found by national number');
const { creature: c, notes } = E.pkhexToCreature(idx, pk, { trainer: 'Ziggy', location: { kind: 'box', box: 0, slot: 0 } });
assert.equal(c.level, 32);
assert.equal(c.genes.def, 20);
assert.equal(c.effort.atk, 252);
assert.equal(c.friendship, 180, 'current handler is the second trainer');
const temper = idx.ds.temperaments.find((t) => t.id === c.temper);
assert.equal(temper.up, 'atk'); assert.equal(temper.down, 'spa');
assert.ok(c.memories.some((x) => /Scarlet/.test(x.text)), 'remembers where it came from');
assert.ok(c.memories.some((x) => /special event/.test(x.text)));
assert.ok(c.memories.some((x) => /Kim/.test(x.text)));
assert.ok(notes.some((x) => /#9999/.test(x)), 'unknown moves are reported');

// Scarlet/Violet number their own new species differently: mapped to the National number (PKHeX's table),
// and a species this data set doesn't have by number falls back to the name it carries
const late = E.readPkm(makePk9({ species: 1000, nick: 'Mindle' }), 'late.pk9');
assert.equal(late.national, E.gen9National(1000));
assert.notEqual(late.national, 1000);
assert.equal(E.matchSpecies(idx, late).species?.id, 'mindle');

// wrong size / bad checksum
assert.equal(E.readPkm(new Uint8Array(100), 'x.pk9').ok, false);
const bad = plain.slice(); bad[0x40] ^= 0xff;
assert.equal(E.readPkm(bad, 'x.pk9').ok, false);

// Showdown sets do not come back
assert.equal(E.looksLikeShowdownSet('Sproutle @ Leftovers\nAbility: Overgrow\nEVs: 252 Atk\n- Nudge'), true);
assert.equal(E.looksLikeShowdownSet('name\tbaseExp\nSproutle\t64'), false);
console.log('pkhex: ok');
