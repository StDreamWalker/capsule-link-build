import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

test('shared bag: a phone on the PC network uses the satchel first, then the bag', () => {
  const idx = E.indexDataset(E.createDefaultDataset());
  const save = E.createSave('T');
  const c = E.addCreature(save, E.createCreature(idx, 'zapkit', { level: 12, seed: 1 }), { kind: 'party', slot: 0 });
  const [a, b] = [...idx.items.values()].filter((i) => /berr/i.test(i.name)).slice(0, 2).map((i) => i.id);
  save.inventory = { [a]: 2, [b]: 1 }; save.satchel = { [a]: 1 };
  E.applyEvent(idx, save, { id: 'e1', type: 'care', uid: c.uid ?? c, action: 'feed', item: a, shared: true });
  assert.equal(save.satchel[a], 0); assert.equal(save.inventory[a], 2);
  E.applyEvent(idx, save, { id: 'e2', type: 'care', uid: c.uid ?? c, action: 'feed', item: b, shared: true });
  assert.equal(save.inventory[b], 0);
});
