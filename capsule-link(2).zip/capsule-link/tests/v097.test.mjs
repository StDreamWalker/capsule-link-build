// 0.9.7: forms again, smarter talking, short- and long-term memory, cravings, guest friendships, journal upset,
// hovering, food numbers, no battle claims for our own items.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const base = () => { const idx = E.indexDataset(E.createDefaultDataset()); const save = E.createSave('Kim', 2); E.tickAll(idx, save); return { idx, save }; };

test('form changes: ordinary forms are free to pick, held-item forms need the item, Mega lasts 15 minutes, and back again', () => {
  const ds = E.createDefaultDataset();
  const b = ds.species[0];
  const mk = (forme, extra = {}) => ({ ...JSON.parse(JSON.stringify(b)), id: `${b.id}${forme.toLowerCase()}`, name: `${b.name}-${forme}`, forme, baseSpecies: b.name, evolutions: [], ...extra });
  ds.species.push(mk('Wash'), mk('Sunny', { battleOnly: b.name }), mk('Origin', { requiredItem: 'Griseous Orb' }), mk('Mega', { requiredItem: 'Testite', battleOnly: b.name }));
  const idx = E.indexDataset(ds); const save = E.createSave('K', 2);
  const c = E.createCreature(idx, b.id, { level: 5 }); save.creatures[c.uid] = c;
  const opts = E.changeOptions(idx, save, c);
  assert.ok(opts.find((o) => o.label.includes('Wash')).ok);
  assert.ok(opts.find((o) => o.label.includes('Sunny')).ok, 'battle-only forms are just for looks at home');
  assert.equal(opts.find((o) => o.label.includes('Origin')).ok, false);
  assert.equal(E.MEGA_MINUTES, 15);
  assert.ok(E.applyChange(idx, save, c.uid, opts.find((o) => o.label.includes('Wash')).key).ok);
  assert.equal(E.currentFormId(idx, c), `${b.id}wash`);
  const back = E.changeOptions(idx, save, c).find((o) => /usual/.test(o.label));
  assert.ok(E.applyChange(idx, save, c.uid, back.key).ok);
  assert.equal(E.currentFormId(idx, c), b.id);
  // a creature whose own species is a form can go to the base form too
  const w = E.createCreature(idx, `${b.id}wash`, { level: 5 }); save.creatures[w.uid] = w;
  assert.ok(E.changeOptions(idx, save, w).some((o) => /usual/.test(o.label)));
});

test('talking: trained creatures from game saves follow far more than fresh ones; they answer questions about themselves', () => {
  const { idx, save } = base();
  const low = E.createCreature(idx, idx.ds.species[0].id, { level: 3 }); save.creatures[low.uid] = low;
  const vet = E.createCreature(idx, idx.ds.species[1].id, { level: 72 }); vet.origin = { from: 'pkhex' }; vet.friendship = 200; save.creatures[vet.uid] = vet;
  assert.ok(E.fluencyOf(idx, vet) > 0.7 && E.fluencyOf(idx, low) < 0.15);
  const t = Date.now();
  const a = E.chatReply(idx, save, low, 'how are you feeling?', t);
  const b = E.chatReply(idx, save, vet, 'how are you feeling?', t);
  if (!a.intent) assert.match(a.note, /tilts|tone|follow|watches|work out/); // (a fresh one now and then guesses right)
  assert.equal(b.intent, 'howAreYou');
  // fluent ones learn words sooner
  for (let i = 0; i < 2; i++) E.chatReply(idx, save, vet, 'want to go for a walk?', t + 60000 * (i + 2));
  assert.ok(vet.chat.known.walk, 'a fluent creature learns "walk" in a couple of goes');
  // naming someone talks to just them
  assert.deepEqual(E.chatTargets(idx, save, [low.uid, vet.uid], `hey ${E.displayName(idx, vet)}, hungry?`), [vet.uid]);
  assert.equal(E.chatTargets(idx, save, [low.uid, vet.uid], 'hi everyone').length, 2);
});

test('memory: a craving lasts the day, is remembered across chats, is satisfied by feeding it, and turns into a liking after several days', () => {
  const { idx, save } = base();
  const c = E.createCreature(idx, idx.ds.species[0].id, { level: 70 }); c.origin = { from: 'pkhex' }; save.creatures[c.uid] = c;
  const berry = E.allFoods(idx).find((f) => !f.unlimited && f.kind === 'food');
  const day0 = new Date(2026, 9, 1, 12).getTime();
  E.setCraving(c, berry.id, day0);
  assert.equal(E.cravingOf(idx, c, day0 + 3600000), berry.id);
  const r = E.chatReply(idx, save, c, 'do you remember?', day0 + 7200000);
  assert.match(r.note, /thinking about/);
  save.inventory[berry.id] = 1; c.needs.fullness = 20;
  const fed = E.applyCare(idx, c, 'feed', { item: berry.id, inventory: save.inventory, at: day0 + 7300000 });
  assert.ok(fed.craved);
  // next day: the craving is gone (unless they crave again), and yesterday was slept on
  E.sleepOnIt(idx, save, c, day0 + 86400000);
  assert.ok(c.yesterday?.lines?.some((l) => /craving/.test(l)));
  // craving the same thing on three different days makes it a favourite for good
  c.prefs[`food:${berry.id}`] = 0; // (from nothing, so a liking it was born with can't hit the ceiling)
  const before = 0;
  for (let d = 1; d <= 3; d++) { E.setCraving(c, berry.id, day0 + d * 86400000 + 3600000); E.sleepOnIt(idx, save, c, day0 + (d + 1) * 86400000 + 1000); }
  assert.ok((c.prefs[`food:${berry.id}`] ?? 0) >= before + 3);
  assert.ok(c.memories.some((m) => /day after day/.test(m.text)));
});

test('friends from other ranches are remembered and grow closer over visits; the journal shows them, today, and the last upset', () => {
  const { idx, save } = base();
  const c = E.createCreature(idx, idx.ds.species[0].id, { level: 10 }); save.creatures[c.uid] = c;
  const g = { uid: 'g1', name: 'Pip', speciesId: idx.ds.species[1].id };
  let r;
  for (let i = 0; i < 25; i++) r = E.meetGuest(c, g, { name: 'Sam', code: '1234' }, 3, Date.now() + i * 1000);
  assert.ok(r.friends);
  E.noteUpset(c, 'woken up while still tired');
  const j = E.journalOf(idx, save, c);
  assert.ok(j.bonds.some((b) => b.guest && b.name === 'Pip' && /friends/.test(b.label)));
  assert.match(j.lastUpset.reason, /woken/);
  assert.ok(j.lastUpset.help.length > 10);
  assert.ok(j.today && typeof j.understands === 'string');
});

test('asleep: no scary wake-up warnings, and only a tired creature risks being grumpy', () => {
  const { idx } = base();
  const c = E.createCreature(idx, idx.ds.species[0].id, { level: 10 });
  c.sleep = { since: Date.now(), until: Date.now() + 3600000 };
  const r = E.applyCare(idx, c, 'play', {});
  assert.equal(r.ok, false); assert.doesNotMatch(r.reason, /love it|upset|grumpy/);
  c.needs.energy = 90; assert.equal(E.wakeRisk(c), false);
  c.needs.energy = 30; assert.equal(E.wakeRisk(c), true);
});

test('hovering creatures (Levitate, no wings) hover; food shows its numbers; our own berries don’t claim to work in battle', () => {
  const { idx } = base();
  const sp = { ...idx.ds.species[0], types: ['normal'], abilities: ['Levitate'], movement: {} };
  assert.equal(E.movementOf(idx, sp).def, 'hover');
  assert.equal(E.movementOf(idx, { ...sp, types: ['flying'] }).def, 'fly');
  const berry = E.allFoods(idx).find((f) => !f.unlimited && f.kind === 'food');
  assert.match(E.foodStats(berry), /Fullness \+\d+/);
  assert.doesNotMatch(E.foodStats(berry), /Tidiness/);
  assert.match(E.foodStats({ id: 'mint-leaf', name: 'Mint Leaf', kind: 'food' }), /Tidiness/);
  assert.doesNotMatch(E.itemDesc(berry), /battle/);
  assert.match(E.itemDesc({ ...berry, showdownName: 'Oran Berry' }), /battle/);
});
