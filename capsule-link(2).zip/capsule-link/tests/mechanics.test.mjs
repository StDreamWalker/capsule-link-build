// The battle rules are Showdown's own simulator (bundled into the app with the Capsule Wild format): these
// check, through that same bundle, that moves really behave as they should — hit counts, critical-hit
// ratios, abilities that block or ignore things, Protect and what gets through it, two-turn moves, screens,
// STAB and type matchups. Needs esbuild (npm install in desktop/, or ESBUILD_PATH).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

async function esbuild() {
  try { return await import('esbuild'); } catch { /* not here */ }
  if (process.env.ESBUILD_PATH) return import(pathToFileURL(process.env.ESBUILD_PATH).href);
  for (const p of ['../desktop/node_modules/esbuild/lib/main.js', '/opt/npm-tools/node_modules/esbuild/lib/main.js']) { const f = p.startsWith('/') ? pathToFileURL(p) : new URL(p, import.meta.url); if (fs.existsSync(f)) return import(f.href); }
  return null;
}
let SIM = null;
async function sim(t) {
  if (SIM) return SIM;
  const eb = await esbuild();
  if (!eb) { t.skip('esbuild not installed'); return null; }
  const { buildShowdownSim } = await import('../shared/sdbattle/build.mjs');
  const out = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'clsd-')), 'sim.mjs');
  await buildShowdownSim(eb, out);
  SIM = await import(pathToFileURL(out).href);
  return SIM;
}
/** One battle: each side's team and the choices it makes, turn by turn ('move 1', …). → the whole log. */
async function battle(S, a, b, choicesA, choicesB, seed = [1, 2, 3, 4]) {
  const stream = new S.BattleStream();
  const ps = S.getPlayerStreams(stream);
  const log = [];
  const drive = async (s, choices) => { let i = 0; for await (const chunk of s) { const m = /\|request\|(.+)/.exec(chunk); if (m) { const r = JSON.parse(m[1]); if (r.active || r.forceSwitch) s.write(r.forceSwitch ? 'default' : choices[Math.min(i++, choices.length - 1)]); } } };
  drive(ps.p1, choicesA); drive(ps.p2, choicesB);
  (async () => { for await (const chunk of ps.omniscient) log.push(chunk); })();
  ps.omniscient.write(`>start ${JSON.stringify({ formatid: 'gen9capsulewild', seed })}\n>player p1 ${JSON.stringify({ name: 'A', team: a })}\n>player p2 ${JSON.stringify({ name: 'B', team: b })}`);
  for (let i = 0; i < 200 && !(stream.battle?.ended || stream.battle?.turn > choicesA.length + 1); i++) await new Promise((r) => setTimeout(r, 10));
  return { text: log.join('\n'), battle: stream.battle };
}
const mon = (species, moves, extra = {}) => ({ name: species, species, moves, level: 50, evs: { hp: 0, atk: 0, def: 0, spa: 0, spd: 0, spe: 0 }, ...extra });

test('multi-hit moves: Dragon Darts hits twice, Skill Link makes Icicle Spear hit five times', async (t) => {
  const S = await sim(t); if (!S) return;
  let r = await battle(S, [mon('Dragapult', ['Dragon Darts'])], [mon('Snorlax', ['Rest'], { evs: { hp: 252, def: 252 } })], ['move 1'], ['move 1']);
  // Dragon Darts: two darts, the second shown as its own animation (Showdown's -anim line)
  const t1 = r.text.split('|turn|2')[0].split('|move|p2a')[0];
  assert.equal((t1.match(/\|-damage\|p2a: Snorlax/g) ?? []).length, 2);
  assert.match(t1, /\|-anim\|p1a: Dragapult\|Dragon Darts/);
  r = await battle(S, [mon('Cloyster', ['Icicle Spear'], { ability: 'Skill Link' })], [mon('Snorlax', ['Rest'], { evs: { hp: 252, def: 252 } })], ['move 1'], ['move 1']);
  assert.match(r.text, /\|-hitcount\|p2a: Snorlax\|5/);
});

test('critical hits: high-crit moves with Focus Energy and Scope Lens always land critical hits', async (t) => {
  const S = await sim(t); if (!S) return;
  const r = await battle(S, [mon('Sneasel', ['Focus Energy', 'Night Slash'], { item: 'Scope Lens' })], [mon('Blissey', ['Soft-Boiled'], { evs: { hp: 252, def: 252 } })], ['move 1', 'move 2', 'move 2', 'move 2'], ['move 1']);
  const slashes = r.text.split('\n').filter((l) => /\|move\|p1a: Sneasel\|Night Slash/.test(l)).length;
  const crits = r.text.split('\n').filter((l) => /\|-crit\|p2a: Blissey/.test(l)).length;
  assert.ok(slashes >= 3 && crits === slashes, `${crits} critical hits from ${slashes} Night Slashes`);
});

test('abilities: Levitate dodges Earthquake but not with Mold Breaker; Soundproof blocks sound moves; Volt Absorb heals', async (t) => {
  const S = await sim(t); if (!S) return;
  let r = await battle(S, [mon('Garchomp', ['Earthquake'], { ability: 'Rough Skin' })], [mon('Bronzong', ['Rest'], { ability: 'Levitate' })], ['move 1'], ['move 1']);
  assert.match(r.text, /\|-immune\|p2a: Bronzong\|\[from\] ability: Levitate/);
  r = await battle(S, [mon('Excadrill', ['Earthquake'], { ability: 'Mold Breaker' })], [mon('Bronzong', ['Rest'], { ability: 'Levitate' })], ['move 1'], ['move 1']);
  assert.match(r.text, /\|-damage\|p2a: Bronzong\|/);
  r = await battle(S, [mon('Exploud', ['Hyper Voice'], { ability: 'Scrappy' })], [mon('Mr. Mime', ['Rest'], { ability: 'Soundproof' })], ['move 1'], ['move 1']);
  assert.match(r.text, /\|-immune\|p2a: Mr\. Mime\|\[from\] ability: Soundproof/);
  r = await battle(S, [mon('Pikachu', ['Thunderbolt'])], [mon('Lanturn', ['Rest'], { ability: 'Volt Absorb' })], ['move 1'], ['move 1']);
  assert.match(r.text, /\|-immune\|p2a: Lanturn\|\[from\] ability: Volt Absorb|\|-heal\|p2a: Lanturn\|.*\[from\] ability: Volt Absorb/);
});

test('Protect blocks a move; Feint breaks through it; Phantom Force can’t be hit while it’s gone and goes through Protect', async (t) => {
  const S = await sim(t); if (!S) return;
  let r = await battle(S, [mon('Machamp', ['Close Combat'], { evs: { spe: 0 } })], [mon('Jolteon', ['Protect'])], ['move 1'], ['move 1']);
  assert.match(r.text, /\|-activate\|p2a: Jolteon\|move: Protect/);
  assert.doesNotMatch(r.text.split('|turn|2')[0], /\|-damage\|p2a: Jolteon/);
  r = await battle(S, [mon('Weavile', ['Feint'])], [mon('Slowbro', ['Protect'])], ['move 1'], ['move 1']);
  assert.match(r.text, /\|-activate\|p2a: Slowbro\|move: Feint/);
  // turn 1: Gengar (faster) vanishes and Snorlax's move misses; turn 2: Snorlax protects, the strike lands anyway
  r = await battle(S, [mon('Gengar', ['Phantom Force'])], [mon('Snorlax', ['Body Slam', 'Protect'], { ability: 'Thick Fat' })], ['move 1', 'move 1'], ['move 1', 'move 2']);
  const t1 = r.text.split('|turn|2')[0];
  assert.match(t1, /\|-prepare\|p1a: Gengar\|Phantom Force/);
  assert.match(t1, /\|-miss\|p2a: Snorlax\|p1a: Gengar|\|move\|p2a: Snorlax\|Body Slam\|p1a: Gengar\|\[miss\]/);
  assert.match(r.text, /\|move\|p1a: Gengar\|Phantom Force\|p2a: Snorlax/);
});

test('type matchups and STAB: Ghost can’t touch Normal, a same-type move hits harder than an off-type one of the same power', async (t) => {
  const S = await sim(t); if (!S) return;
  let r = await battle(S, [mon('Gengar', ['Shadow Ball'])], [mon('Snorlax', ['Rest'])], ['move 1'], ['move 1']);
  assert.match(r.text, /\|-immune\|p2a: Snorlax/);
  // Raichu: Thunderbolt (Electric, STAB) vs Psychic (90, no STAB) into a neutral target, same seed
  const dmg = async (move) => { const x = await battle(S, [mon('Raichu', [move])], [mon('Snorlax', ['Rest'], { evs: { hp: 252, spd: 252 } })], ['move 1'], ['move 1'], [7, 7, 7, 7]); return x.battle.p2.pokemon[0].maxhp - x.battle.p2.pokemon[0].hp; };
  const stab = await dmg('Thunderbolt'), off = await dmg('Psychic');
  assert.ok(stab > off * 1.3, `STAB ${stab} vs ${off}`);
});

test('screens and what breaks them: Reflect halves physical damage; Brick Break shatters it', async (t) => {
  const S = await sim(t); if (!S) return;
  const r = await battle(S, [mon('Machamp', ['Brick Break'])], [mon('Alakazam', ['Reflect'])], ['move 1', 'move 1'], ['move 1', 'move 1']);
  assert.match(r.text, /\|-sidestart\|p2: B\|(move: )?Reflect/);
  assert.match(r.text, /\|move\|p1a: Machamp\|Brick Break\|p2a: Alakazam\n\|-sideend\|p2: B\|(move: )?Reflect/);
});

test('the battle screen has its own copies of the data tables (it overwrites entries as it looks them up, which once wiped moves’ effects in the simulator)', async () => {
  const src = fs.readFileSync(new URL('../shared/sdbattle/globals.js', import.meta.url), 'utf8');
  for (const t of ['Pokedex', 'Moves', 'Items', 'Abilities']) assert.match(src, new RegExp(`= copy\\(d\\.${t}\\)`), t);
  assert.doesNotMatch(src, /g\.BattleMovedex = d\.Moves;/);
});

// Side effects happen as often as they should (Scald burns 30% of the time, Ice Beam freezes 10%, Charge Beam
// raises Sp. Atk 70%, Flame Charge always raises Speed): counted over the first hit of many battles, each with
// its own seed, the way the app seeds them.
test('move side effects happen at their real chances', async (t) => {
  const S = await sim(t); if (!S) return;
  const r16 = (n) => (Math.abs(Math.imul(n | 0, 2654435761)) >>> 0) % 65536;
  const mk = (sp, mv) => ({ name: sp, species: sp, level: 50, moves: [mv], ability: '', item: '', evs: { hp: 0, atk: 0, def: 0, spa: 0, spd: 0, spe: 0 }, ivs: { hp: 31, atk: 31, def: 31, spa: 31, spd: 31, spe: 31 } });
  const firstTurn = async (move, n) => {
    const { text } = await battle(S, [mk('Snorlax', move)], [mk('Blissey', 'Splash')], ['move 1'], ['move 1'], [r16(n), r16(n + 1), r16(n + 2), r16(n + 3)]);
    const i = text.indexOf('|turn|2'); return i > 0 ? text.slice(0, i) : text;
  };
  const rate = async (move, re, N = 160) => { let k = 0; for (let i = 0; i < N; i++) if (re.test(await firstTurn(move, 1000 + i * 7919))) k++; return k / N; };
  const scald = await rate('Scald', /-status\|p2a: Blissey\|brn/);
  assert.ok(scald > 0.18 && scald < 0.42, `Scald burned ${scald}`);
  const ice = await rate('Ice Beam', /-status\|p2a: Blissey\|frz/);
  assert.ok(ice > 0.03 && ice < 0.2, `Ice Beam froze ${ice}`);
  const cb = await rate('Charge Beam', /-boost\|p1a: Snorlax\|spa/, 80);
  assert.ok(cb > 0.5 && cb < 0.88, `Charge Beam raised Sp. Atk ${cb}`);
  assert.equal(await rate('Flame Charge', /-boost\|p1a: Snorlax\|spe/, 20), 1);
});
