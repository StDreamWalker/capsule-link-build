package com.capsulelink.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import java.util.Calendar;
import java.util.Random;

/**
 * Wild creatures finding you while the app is closed (Battle → "Wild creatures can find you"): every so often
 * (a random time between the minimum and maximum the player chose) a notification says one has appeared; tapping
 * it opens the app straight into the battle. Never during the night (22:00 to 08:00): those wait for the morning.
 * Inexact alarms only, so the phone can bundle them with others and save battery. Rescheduled after a restart.
 */
public class WildAlarm extends BroadcastReceiver {
    static final String PREFS = "capsule_wild";
    static final String EXTRA = "capsuleWild";
    private static final int REQ = 7311;

    @Override
    public void onReceive(Context ctx, Intent intent) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!p.getBoolean("enabled", false)) return;
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) { schedule(ctx); return; }
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour >= 8 && hour < 22) post(ctx, p.getString("title", "A wild creature appeared!"), p.getString("body", "Tap to battle it."));
        schedule(ctx);
    }

    static void post(Context ctx, String title, String body) {
        Intent open = new Intent(ctx, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra(EXTRA, true);
        PendingIntent pi = PendingIntent.getActivity(ctx, REQ, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, "alerts")
            .setSmallIcon(R.drawable.ic_stat_capsule)
            .setContentTitle(title).setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi);
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        try { NotificationManagerCompat.from(ctx).notify(2301, b.build()); } catch (SecurityException ignored) { }
    }

    /** The next one, a random time from now within the chosen range (moved to the morning if it would land at night). */
    static void schedule(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, REQ, new Intent(ctx, WildAlarm.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        if (am == null) return;
        am.cancel(pi);
        if (!p.getBoolean("enabled", false)) return;
        int min = Math.max(15, p.getInt("min", 60)), max = Math.max(min + 1, p.getInt("max", 180));
        long at = System.currentTimeMillis() + (long) (min + new Random().nextInt(max - min)) * 60000L;
        Calendar c = Calendar.getInstance(); c.setTimeInMillis(at);
        int h = c.get(Calendar.HOUR_OF_DAY);
        if (h >= 22 || h < 8) { if (h >= 22) c.add(Calendar.DAY_OF_YEAR, 1); c.set(Calendar.HOUR_OF_DAY, 8); c.set(Calendar.MINUTE, new Random().nextInt(50)); at = c.getTimeInMillis(); }
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); else am.set(AlarmManager.RTC_WAKEUP, at, pi);
    }
}
