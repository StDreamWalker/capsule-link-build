package com.capsulelink.app;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** Every 15 minutes or so: look at the phone's step counter and keep what was walked (see StepTracker). */
public class StepJob extends JobService {
    @Override
    public boolean onStartJob(JobParameters params) {
        StepTracker.sync(getApplicationContext(), added -> jobFinished(params, false));
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) { return true; }
}
