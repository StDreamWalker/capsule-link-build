package com.capsulelink.app;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

/**
 * Steps counted while the app is closed. The phone's step counter keeps a running total since it was
 * switched on, whether or not any app is open; this remembers the last total it saw and adds the
 * difference to the same "pending" steps a walk uses (the app turns them into friendship when it opens).
 * A job reads the counter every 15 minutes or so, so a restart of the phone loses at most that much.
 */
public final class StepTracker {
    private static final String KEY_ON = "bg_on", KEY_LAST = "bg_last", KEY_BOOT = "bg_boot";
    private static final int JOB_ID = 4711;

    private StepTracker() { }

    static SharedPreferences prefs(Context ctx) { return WalkService.prefs(ctx); }
    public static boolean enabled(Context ctx) { return prefs(ctx).getBoolean(KEY_ON, false); }
    private static long bootTime() { return System.currentTimeMillis() - SystemClock.elapsedRealtime(); }

    /** Turn background counting on or off (and schedule the job that keeps it going). */
    public static void setEnabled(Context ctx, boolean on) {
        prefs(ctx).edit().putBoolean(KEY_ON, on).apply();
        JobScheduler js = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        if (!on) { js.cancel(JOB_ID); return; }
        JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(ctx, StepJob.class))
            .setPeriodic(15 * 60 * 1000L)
            .setPersisted(true) // survives a restart (needs RECEIVE_BOOT_COMPLETED)
            .build();
        js.schedule(job);
        // start from now: steps before turning it on aren't counted
        read(ctx, total -> { if (total >= 0) setBaseline(ctx, total); });
    }

    /** What the counter says now, as a baseline (a walk's own counting uses this so nothing counts twice). */
    public static synchronized void setBaseline(Context ctx, long total) {
        prefs(ctx).edit().putLong(KEY_LAST, total).putLong(KEY_BOOT, bootTime()).apply();
    }

    public interface Done { void run(long added); }
    interface Total { void got(long total); }

    /** Read the counter once (or -1 if this phone has none / it doesn't answer). */
    static void read(Context ctx, Total cb) {
        SensorManager sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
        Sensor counter = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (counter == null) { cb.got(-1); return; }
        final Handler h = new Handler(Looper.getMainLooper());
        final boolean[] done = { false };
        final SensorEventListener l = new SensorEventListener() {
            @Override public void onSensorChanged(SensorEvent e) {
                if (done[0]) return;
                done[0] = true;
                sm.unregisterListener(this);
                cb.got((long) e.values[0]);
            }
            @Override public void onAccuracyChanged(Sensor s, int a) { }
        };
        sm.registerListener(l, counter, SensorManager.SENSOR_DELAY_NORMAL);
        h.postDelayed(() -> { if (!done[0]) { done[0] = true; sm.unregisterListener(l); cb.got(-1); } }, 2500);
    }

    /** Add the steps taken since the last look to "pending". While a walk is on, the walk counts them itself. */
    public static void sync(Context ctx, Done done) {
        if (!enabled(ctx) && !WalkService.running) { done.run(0); return; }
        read(ctx, total -> {
            if (total < 0) { done.run(0); return; }
            long added = 0;
            synchronized (StepTracker.class) {
                SharedPreferences p = prefs(ctx);
                long last = p.getLong(KEY_LAST, -1);
                long boot = p.getLong(KEY_BOOT, 0);
                boolean restarted = Math.abs(bootTime() - boot) > 60_000 || total < last;
                if (last >= 0 && !WalkService.running && enabled(ctx)) {
                    added = restarted ? total : total - last; // after a restart the counter starts again from 0
                    if (added < 0 || added > 60_000) added = 0;
                }
                p.edit().putLong(KEY_LAST, total).putLong(KEY_BOOT, bootTime())
                    .putLong("pending", p.getLong("pending", 0) + added).apply();
            }
            done.run(added);
        });
    }
}
