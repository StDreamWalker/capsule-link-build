import { brandText } from '../../shared/ui/dom.js';
// Phone capabilities. On Android the native CapsuleLink plugin (mobile/native) provides NFC,
// the step counter service, capsule Bluetooth beacons, notifications and PC discovery.
// In a desktop browser everything is simulated so the app can be tried without a phone.
import { makeVirtualTag, fromBase64, toBase64, toHex, fromHex } from '../../shared/engine/index.js';

const cap = typeof window !== 'undefined' ? window.Capacitor : null;
export const isNative = !!cap?.isNativePlatform?.();

function nativePlatform() {
  const P = cap.registerPlugin('CapsuleLink');
  const listeners = {};
  const on = (ev, fn) => {
    const handle = P.addListener(ev, fn);
    return () => Promise.resolve(handle).then((h) => h.remove());
  };
  return {
    native: true,
    async permissions(opts) { try { return await P.ensurePermissions(opts); } catch (e) { return { error: e.message }; } },
    // ---- NFC ----
    async startNfc() { return P.startNfc(); },
    async stopNfc() { return P.stopNfc().catch(() => {}); },
    onTag(fn) {
      return on('nfcTag', (t) => {
        if (t.error) { fn(null, t.error); return; }
        const mem = fromBase64(t.data);
        fn({
          uid: String(t.uid).toUpperCase(),
          size: t.size,
          readUser: async () => mem,
          writePages: async (page, bytes) => {
            await P.writeTag({ uid: t.uid, page, data: toBase64(bytes) });
            mem.set(bytes, (page - 4) * 4);
          },
        });
      });
    },
    // ---- walking ----
    async startWalk(title, text) { return P.startWalk({ title, text }); },
    async stopWalk() { return P.stopWalk(); },
    async walkStatus() { return P.getWalk(); },
    async ackSteps(count) { return P.ackSteps({ count }); },
    /** Keep counting steps while the app is closed (the phone's own step counter, read now and then). */
    async setBackgroundSteps(enabled) { return P.setBackgroundSteps({ enabled }); },
    onSteps(fn) { return on('steps', fn); },
    // ---- capsule beacons (bumps) ----
    async startBeacons() { return P.startBleScan(); },
    async stopBeacons() { return P.stopBleScan().catch(() => {}); },
    onBeacon(fn) { return on('capsuleBeacon', fn); },
    // ---- misc ----
    // ---- Showdown ----
    canEmbedShowdown: true,
    openShowdown(url, script) { return P.openShowdown({ url, script }); },
    onShowdown(fn) { return on('showdown', fn); },
    async takeShowdownEvents() {
      const r = await P.takeShowdownEvents();
      return (r.events ?? []).map((j) => { try { return JSON.parse(j); } catch { return null; } }).filter(Boolean);
    },
    setCapsuleWatch(mine) { return P.setCapsuleWatch({ mine }).catch(() => {}); },
    // CapacitorHttp makes fetch native, so replay sites need no CORS headers
    async fetchText(url) { const r = await fetch(url); if (!r.ok) throw new Error(`The server answered ${r.status}.`); return r.text(); },
    notify(title, body) { return P.showNotification({ title: brandText(title), body: brandText(body) }).catch(() => {}); },
    // wild creatures finding you by notification, even with the app closed
    canWildAlerts: true,
    setWildAlerts(o) { return P.setWildAlerts({ ...o, title: brandText(o.title ?? ''), body: brandText(o.body ?? '') }).catch(() => {}); },
    async takeWildTap() { try { return !!(await P.takeWildTap()).tapped; } catch { return false; } },
    onWildTap(fn) { return on('wildTap', fn); },
    vibrate(pattern = [40]) { return P.vibrate({ pattern }).catch(() => {}); },
    async discover(ms = 3500) { try { return (await P.discoverPc({ timeout: ms })).found ?? []; } catch { return []; } },
    canPinShortcut: true,
    canUpdate: true,
    async appInfo() { try { return await P.appInfo(); } catch { return {}; } },
    installWebBundle(version, files) { return P.installWebBundle({ version, files }); },
    installApk(url) { return P.installApk({ url }); },
    useBuiltIn() { return P.useBuiltIn(); },
    async pinShortcut(label, iconBase64) { return P.pinShortcut({ label, icon: iconBase64 }); },
    listeners,
  };
}

/** Browser stand-in: virtual capsules you "tap" from the Capsule screen, steps from motion or buttons. */
const PENDING = 'capsule-link-mobile:pending';
const getPending = () => { try { return Number(localStorage.getItem(PENDING) || 0); } catch { return 0; } };
const setPending = (n) => { try { localStorage.setItem(PENDING, String(n)); } catch { /* storage blocked */ } };

function webPlatform() {
  const KEY = 'capsule-link-mobile:vtags';
  const tags = new Map();
  try { for (const [uid, hex] of Object.entries(JSON.parse(localStorage.getItem(KEY) || '{}'))) tags.set(uid, makeVirtualTag(uid, fromHex(hex))); } catch { /* fresh */ }
  const store = () => { const o = {}; for (const [uid, t] of tags) o[uid] = toHex(t.mem); try { localStorage.setItem(KEY, JSON.stringify(o)); } catch { /* full */ } };
  const tagSubs = new Set(), stepSubs = new Set();
  let walking = null;
  let motion = null;
  return {
    native: false,
    async permissions() { return { activity: 'granted', notifications: 'granted' }; },
    async startNfc() {}, async stopNfc() {},
    onTag(fn) { tagSubs.add(fn); return () => tagSubs.delete(fn); },
    // simulation helpers used by the dev panel
    virtualTags: () => [...tags.values()],
    newVirtualTag() {
      const uid = '04' + Array.from({ length: 6 }, () => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join('').toUpperCase();
      const t = makeVirtualTag(uid); t.mem.set([0x03, 0x00, 0xfe], 0); tags.set(uid, t); store(); return uid;
    },
    walkVirtual(uid, n, opts) { tags.get(uid)?.addSteps(n, opts); store(); },
    tapVirtual(uid) {
      const t = tags.get(uid);
      if (!t) return;
      const wrapped = { uid, readUser: () => t.readUser(), writePages: async (p, b) => { await t.writePages(p, b); store(); } };
      for (const fn of tagSubs) fn(wrapped);
    },
    async startWalk() {
      walking = { session: 0, pending: getPending() };
      // step detection from the accelerometer (when the phone's own step counter isn't available): the
      // movement with gravity taken out, smoothed, its peaks found against a level that adapts to how you
      // walk — and only counted once there's a steady rhythm of steps (six in a row, evenly spaced, at walking
      // pace), so sitting down, picking the phone up or a shake doesn't count
      const ST = { g: null, s: 0, prev: 0, rising: false, lastPeak: 0, level: 1.2, run: [], confirmed: false };
      motion = (e) => {
        const a = e.accelerationIncludingGravity; if (!a) return;
        const v = [a.x || 0, a.y || 0, a.z || 0];
        if (!ST.g) ST.g = v.slice();
        for (let i = 0; i < 3; i++) ST.g[i] = ST.g[i] * 0.9 + v[i] * 0.1; // gravity (slow)
        const gm = Math.hypot(...ST.g) || 9.8;
        const lin = (v[0] * ST.g[0] + v[1] * ST.g[1] + v[2] * ST.g[2]) / gm - gm; // up-and-down movement
        ST.s = ST.s * 0.7 + lin * 0.3; // smoothed
        const now = performance.now();
        if (ST.s > ST.prev) ST.rising = true;
        else if (ST.rising && ST.prev > ST.level) {
          ST.rising = false;
          const dt = now - ST.lastPeak;
          ST.level = Math.max(0.9, Math.min(4, ST.level * 0.85 + ST.prev * 0.6 * 0.15)); // adapt to the walk
          if (dt > 280) {
            if (dt > 1400) { ST.run = []; ST.confirmed = false; } // a pause: the rhythm starts again
            ST.lastPeak = now; ST.run.push(dt);
            if (ST.run.length > 8) ST.run.shift();
            if (ST.confirmed) this.addSteps(1);
            else if (ST.run.length >= 6) {
              const iv = ST.run.slice(-5), mean = iv.reduce((x, y) => x + y, 0) / iv.length, sd = Math.sqrt(iv.reduce((x, y) => x + (y - mean) ** 2, 0) / iv.length);
              if (mean > 300 && mean < 1300 && sd / mean < 0.3) { ST.confirmed = true; this.addSteps(6); } // (the steps that made the rhythm count too)
            }
          }
        } else if (!ST.rising) { /* falling */ }
        ST.prev = ST.s;
      };
      window.addEventListener('devicemotion', motion);
      return { ok: true };
    },
    async stopWalk() { window.removeEventListener('devicemotion', motion); const s = walking?.session ?? 0; walking = null; return { steps: s }; },
    async walkStatus() { return { walking: !!walking, sessionSteps: walking?.session ?? 0, pending: getPending() }; },
    async ackSteps(n) { setPending(Math.max(0, getPending() - n)); },
    async setBackgroundSteps() { return { background: false }; },
    addSteps(n) {
      if (!walking) return;
      walking.session += n;
      const p = getPending() + n;
      setPending(p);
      for (const fn of stepSubs) fn({ sessionSteps: walking.session, pending: p });
    },
    onSteps(fn) { stepSubs.add(fn); return () => stepSubs.delete(fn); },
    async startBeacons() {}, async stopBeacons() {},
    onBeacon() { return () => {}; },
    canEmbedShowdown: false,
    openShowdown: null,
    onShowdown() { return () => {}; },
    async takeShowdownEvents() { return []; },
    setCapsuleWatch() {},
    async fetchText(url) { const r = await fetch(url); if (!r.ok) throw new Error(`The server answered ${r.status}.`); return r.text(); },
    notify(title, body) {
      title = brandText(title); body = brandText(body);
      if ('Notification' in window && Notification.permission === 'granted') new Notification(title, { body });
    },
    vibrate(pattern = [40]) { navigator.vibrate?.(pattern); },
    async discover() { try { return (await globalThis.__clWebHost?.discover?.()) ?? []; } catch { return []; } }, // (the single-page web copy: the PC app in the same page)
    canPinShortcut: false,
    canUpdate: false,
    async installWebBundle() { throw new Error('This copy of the app is running without its Android parts, so it can’t update itself. Install the newest APK (from your GitHub build) instead; it already includes this version.'); },
    useBuiltIn() { return Promise.resolve(); },
    async installApk(url) { window.open(url, '_blank'); },
    async appInfo() { return {}; },
  };
}

// if the phone's own code can't be reached, run with simulated parts rather than not at all
function pick() {
  if (!isNative) return webPlatform();
  try { return nativePlatform(); } catch (e) { console.error('Native parts unavailable, simulating them', e); return webPlatform(); }
}
export const platform = pick();
