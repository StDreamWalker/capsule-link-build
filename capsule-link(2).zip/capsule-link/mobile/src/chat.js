// Texting your buddy, right on the monitor: type what you're up to; what you said floats up and fades,
// and they answer the only way they can — a picture in a speech bubble over their head (happy, sad,
// a music note, the berry they want…), a cry (or a word they've learned, said their own way), and a
// line underneath ("Lileep is ready to go!") that fades away. What you typed isn't shown (it would
// cover them), and they never "say" words in text: their words are sounds, cut from their own cry.
import { h, mount, toast, confirmDialog, dialog } from '../../shared/ui/dom.js';
import { spriteCanvas } from '../../shared/ui/art.js';
import { llmIntent } from '../../shared/ui/localLlm.js';
import { togetherView } from './together.js';
import { bubblePic, reactLine, llmChip } from '../../shared/ui/talkOverlay.js';
import { warmLlm, llmStatus } from '../../shared/ui/localLlm.js';
import { creatureCry, sfx } from '../../shared/ui/audio.js';
import { displayName, speciesOf, makeEvent, itemInfo, wordLabel, inviteOf, directInvite, volunteers, INVITES, changeOptions, isAsleep } from '../../shared/engine/index.js';
import { POWERS, powerOf } from '../../shared/engine/powers.js';

const REQUESTY = /\?|\b(let'?s|wanna|want to|who|anyone|any ?body|everyone|fancy|up for|come (on|with)|shall we|how about)\b/i;
const ASKS_DO = /\b(can you|could you|would you|will you|please|show (me|us)|let'?s see|use|try|make|do (a|some|your|that|the)|go on|time to)\b|!\s*$/i;

const MOOD_ICON = { happy: '😊', meh: '😕', sleepy: '💤', worried: '🥺', curious: '❔', content: '🙂' };

/** The talk layer over the monitor and the box to type in. Returns { layer, bar }. */
export function talkParts(app) {
  const layer = h('div', { class: 'talk-layer', 'aria-live': 'polite' });
  const input = h('input', { type: 'text', class: 'talk-input', maxLength: 200, enterkeyhint: 'send', placeholder: 'Tell them what you’re up to…' });
  const bar = h('form', { class: 'talk-bar', onsubmit: (e) => { e.preventDefault(); send(input.value); input.value = ''; } },
    input, h('button', { class: 'btn primary', type: 'submit', 'aria-label': 'Say it' }, 'Say'), llmChip());
  warmLlm(); // (start loading the language model as soon as you can talk to them)
  const fade = (node, ms) => { layer.append(node); setTimeout(() => node.classList.add('out'), ms); setTimeout(() => node.remove(), ms + 900); };
  // “who wants to …?”: asked of everyone with you; the ones who'd like to step forward, and what you can do
  // together from here (activities and quality time on the Together tab, a walk, a battle)
  function inviteSheet(inv, said) {
    const team = app.team().filter((c) => !c.egg);
    const res = volunteers(app.idx, app.save, team.map((c) => c.uid).filter((u) => !isAsleep(app.save.creatures[u]) || inv.id === 'nap'), inv);
    const nm = (u) => displayName(app.idx, app.save.creatures[u]);
    const kind = inv.like ?? inv.id;
    const goTogether = (u, act) => { togetherView.pick = u; togetherView.autoStart = { uid: u, act }; app.go('together'); };
    const doIt = (u, close) => {
      close();
      if (inv.act) return goTogether(u, inv.act);
      if (['groom', 'snack', 'nap'].includes(kind) || inv.seq) return goTogether(u, 'quality');
      if (kind === 'walk') { app.local((s) => { s.settings.buddyUid = u; }); toast(`${nm(u)} comes along on your walk: every step counts for them.`, 'ok'); return; }
      if (kind === 'battle' || kind === 'race' || kind === 'tug') return app.go('battle');
      if (kind === 'desktop' || kind === 'movie') return toast('That one needs your PC: ask them there.', 'err');
      return goTogether(u, 'quality');
    };
    dialog(`“${said.length > 60 ? `${said.slice(0, 58)}…` : said}”`, (close) => h('div', { class: 'col', style: { gap: '8px' } },
      h('p', { class: 'dim' }, res.yes.length ? `${res.yes.length === 1 ? `${nm(res.yes[0].uid)} wants` : `${res.yes.length} of them want`} to ${inv.label}!` : `Nobody feels like it right now.`),
      ...res.yes.slice(0, 6).map((v) => h('div', { class: 'row', style: { alignItems: 'center', gap: '8px' } }, spriteCanvas(app.bank, app.save.creatures[v.uid], { scale: 1 }), h('span', { class: 'grow' }, h('b', null, nm(v.uid)), h('span', { class: 'micro dim' }, ` · ${v.why}`)), h('button', { class: 'btn small primary', onclick: () => doIt(v.uid, close) }, inv.verb))),
      ...res.no.slice(0, 6).map((v) => h('p', { class: 'micro dim' }, v.why)),
      h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close() }, 'Close'))));
  }
  async function send(text) {
    text = String(text || '').trim();
    const b = app.buddy();
    if (!text || !b) return;
    // asking everyone (“who wants to…?”), with the language model placing what the rules can't
    let inv = inviteOf(text) ?? directInvite(text);
    if ((!inv || inv.id === 'any') && llmStatus().state === 'ready' && REQUESTY.test(text)) { const id = await llmIntent(text, INVITES.map((i) => ({ id: i.id, label: i.label }))).catch(() => null); if (id) inv = INVITES.find((i) => i.id === id); }
    if (inv && inv.id !== 'any' && app.team().length) { sfx('blip'); inviteSheet(inv, text); return; }
    // asking the buddy to use a move or a power the rules can't place
    if (llmStatus().state === 'ready' && ASKS_DO.test(text) && !powerOf(text, app.idx)) { const pid = await llmIntent(text, POWERS.map((p) => ({ id: p.id, label: p.label }))).catch(() => null); if (pid) text = `${text} [power:${pid}]`; }
    input.placeholder = `Tell ${displayName(app.idx, b)} what you’re up to…`;
    // what you said floats up and fades
    layer.querySelectorAll('.talk-bubble, .talk-line').forEach((n) => n.remove());
    sfx('blip');
    const out = app.record(makeEvent('chat', { uid: b.uid, text }))?.outcome;
    if (!out) return;
    warmLlm();
    const line = reactLine(app, b.uid, text, out); // (in the on-device model's words, once it's ready)
    const dots = llmStatus().state === 'ready' ? h('div', { class: 'talk-bubble thinking' }, h('span', { class: 'talk-emoji' }, '…')) : null;
    if (dots) layer.append(dots);
    line.finally?.(() => dots?.remove());
    setTimeout(async () => {
      const note = (await line) ?? out.note;
      const c = app.save.creatures[b.uid];
      if (!c) return;
      // their answer: a picture over their head, a word if they have one, and a line that fades
      const pic = out.bubble?.kind === 'item' || out.bubble?.kind === 'creature' ? bubblePic(app, out) : h('span', { class: 'talk-emoji' }, out.bubble?.e ?? MOOD_ICON[out.mood] ?? '❔');
      if (pic.tagName === 'CANVAS') { pic.style.width = '44px'; pic.style.height = '44px'; pic.style.imageRendering = 'pixelated'; }
      fade(h('div', { class: `talk-bubble mood-${out.mood ?? 'content'}` }, pic), 4200);
      if (note) fade(h('div', { class: 'talk-line' }, out.learned ? `${displayName(app.idx, c)} seems to know what “${wordLabel(app.idx, out.learned)}” means now.` : note), 4200);
      try { creatureCry(speciesOf(app.idx, c), c, out.pieces ? { chop: out.pieces } : { talk: true, mood: out.mood === 'happy' ? 'happy' : out.mood === 'sleepy' ? 'sleepy' : undefined }); } catch { /* no sound */ }
      app.platform.vibrate?.([12]);
      // it wants to evolve: only with your say-so
      if (out.act?.kind === 'evolveAsk') {
        const to = app.idx.species.get(out.act.to)?.name ?? 'something new';
        setTimeout(async () => {
          const yes = await confirmDialog(`${displayName(app.idx, c)} wants to evolve!`, `Let ${displayName(app.idx, c)} evolve into ${to}?`, { ok: 'Evolve', cancel: 'Not yet' });
          if (!yes) { toast(`${displayName(app.idx, c)} stays as they are for now.`); return; }
          const opt = changeOptions(app.idx, app.save, app.save.creatures[b.uid]).find((o) => o.key === out.act.key);
          if (!opt?.ok) { toast(opt?.why ?? 'They can’t evolve right now.', 'err'); return; }
          app.record(makeEvent('change', { uid: b.uid, key: out.act.key })); sfx('level');
          toast(`${displayName(app.idx, c)} evolved into ${to}!`, 'ok');
        }, 900);
      }
      if (out.learned) { sfx('level'); toast(`${displayName(app.idx, c)} learned a word: “${wordLabel(app.idx, out.learned)}” — listen for their own sound for it.`, 'ok'); }
    }, 550);
  }
  void mount;
  return { layer, bar, focus: () => input.focus() };
}
