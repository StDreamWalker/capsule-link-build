// The battle lab as a page of its own (move-lab.html): the same lab the app's Battle Lab shows.
import { mountBattleLab } from './lab.js';
document.body.classList.add('blab');
mountBattleLab(document.body);
