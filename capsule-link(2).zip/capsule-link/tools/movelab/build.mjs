// Builds the move lab: one self-contained HTML file (the battle stage, Showdown's move data, and the page).
//   ESBUILD_PATH=… node tools/movelab/build.mjs [--out dir]
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url)), root = path.join(here, '..', '..'), shared = path.join(root, 'shared');
const esbuild = await import(process.env.ESBUILD_PATH ? pathToFileURL(process.env.ESBUILD_PATH).href : 'esbuild');
const outDir = process.argv.includes('--out') ? process.argv[process.argv.indexOf('--out') + 1] : here;
const tmp = path.join(here, '.sd.js');
const sd = await import(pathToFileURL(path.join(shared, 'sdbattle', 'build.mjs')).href);
await sd.buildShowdownBattle(esbuild, tmp);
const sdJs = fs.readFileSync(tmp, 'utf8'); fs.rmSync(tmp, { force: true });
const { m3dDefine } = await import(pathToFileURL(path.join(here, '..', 'm3dworker.mjs')).href);
const r = await esbuild.build({ entryPoints: [path.join(here, 'standalone.js')], bundle: true, write: false, platform: 'browser', format: 'iife', target: 'chrome110', minify: true, charset: 'ascii', logLevel: 'warning', legalComments: 'none', define: { __BUILD__: '{"version":"lab"}', ...(await m3dDefine(esbuild)) } });
const css = [fs.readFileSync(path.join(shared, 'ui/font/font.css'), 'utf8'), fs.readFileSync(path.join(shared, 'ui/base.css'), 'utf8'), sd.showdownCss(), fs.readFileSync(path.join(here, 'lab.css'), 'utf8')].join('\n');
const esc = (s) => s.replace(/<\/script/gi, '<\\/script');
const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Capsule Link · Battle Lab</title><style>${css}</style></head><body class="dark"><script>${esc(sdJs)}</script><script>${esc(r.outputFiles[0].text)}</script></body></html>`;
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'move-lab.html'), html);
console.log(`Built ${path.join(outDir, 'move-lab.html')} (${Math.round(html.length / 1024)} KB)`);
