// The 3D models' worker (shared/ui/m3d/worker.js) bundled into one piece of text, which the apps start as a
// worker from a blob: so the models render off the page's own thread in every build (PC, phone, web page).
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
export async function m3dWorkerSource(esbuild) {
  const r = await esbuild.build({ entryPoints: [path.join(root, 'shared/ui/m3d/worker.js')], bundle: true, write: false, format: 'iife', platform: 'browser', target: 'chrome80', minify: true, charset: 'ascii', logLevel: 'warning', legalComments: 'none' });
  return r.outputFiles[0].text;
}
/** The esbuild `define` entry that hands it to the app. */
export async function m3dDefine(esbuild) { return { __M3D_WORKER__: JSON.stringify(await m3dWorkerSource(esbuild)) }; }
