// Builds shared/engine/romhackData.js: how ROM hacks number their species and moves, turned into national
// numbers (and forms) the rest of the app understands.
//
//   node tools/gen-romhack-data.mjs <PUSE backend/data dir> <pokeemerald-expansion dir>
//
// Sources (lists of names/constants only):
//   CFRU (Pokémon Unbound, Radical Red): PUSE — Pokémon Unbound Save Editor, MIT licence,
//     github.com/Zannael/PUSE (backend/data: species_constants.json, pokemon.txt, moves.txt,
//     games/radical-red-4.1/{pokemon,moves}.txt)
//   pokeemerald-expansion (Emerald Seaglass, ROWE and most modern Emerald hacks): the Species and
//     Move enums in include/constants/{species,moves}.h, github.com/rh-hideout/pokeemerald-expansion
// Names are matched to Pokémon Showdown's Pokédex and move list (vendor/showdown/data).
import fs from 'node:fs';
import path from 'node:path';

const [puse, pex] = process.argv.slice(2);
if (!puse || !pex) { console.error('usage: node tools/gen-romhack-data.mjs <PUSE backend/data> <pokeemerald-expansion>'); process.exit(1); }
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const sd = (f) => fs.readFileSync(path.join(root, 'vendor/showdown/data', f), 'utf8');
const id = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');

// ---- Showdown: species id → { num, name, forme }, and move id → num ----
const dex = new Map();
{
  const src = sd('pokedex.ts');
  const re = /^\t([a-z0-9]+): \{\n([\s\S]*?)\n\t\},?$/gm;
  for (let m; (m = re.exec(src));) {
    const body = m[2];
    const num = Number(/\bnum: (-?\d+)/.exec(body)?.[1]);
    const name = /\bname: "([^"]+)"/.exec(body)?.[1];
    const forme = /\bforme: "([^"]+)"/.exec(body)?.[1] ?? '';
    const prevo = /\bprevo: "([^"]+)"/.exec(body)?.[1] ?? '';
    const evos = [...(/\bevos: \[([^\]]*)\]/.exec(body)?.[1] ?? '').matchAll(/"([^"]+)"/g)].map((x) => x[1]);
    if (num > 0 && name) dex.set(m[1], { num, name, forme, prevo, evos });
  }
}
const moveNum = new Map();
{
  const src = sd('moves.ts');
  const re = /^\t([a-z0-9]+): \{\n([\s\S]*?)\n\t\},?$/gm;
  for (let m; (m = re.exec(src));) { const num = Number(/\bnum: (-?\d+)/.exec(m[2])?.[1]); if (num > 0) moveNum.set(m[1], num); }
}
const baseByNum = new Map(); for (const [k, v] of dex) if (!v.forme && !baseByNum.has(v.num)) baseByNum.set(v.num, k);

// a constant like SPECIES_RATTATA_A / SPECIES_RATTATA_ALOLA / SPECIES_VENUSAUR_GIGA → a Showdown species id
const SUFFIX = [
  [/_(A|ALOLA|ALOLAN)$/, 'alola'], [/_(G|GALAR|GALARIAN)$/, 'galar'], [/_(H|HISUI|HISUIAN)$/, 'hisui'], [/_(P|PALDEA|PALDEAN)$/, 'paldea'],
  [/_MEGA_X$/, 'megax'], [/_MEGA_Y$/, 'megay'], [/_MEGA$/, 'mega'], [/_(GIGA|GMAX|GIGANTAMAX)$/, 'gmax'], [/_PRIMAL$/, 'primal'],
  [/_F$/, 'f'], [/_FEMALE$/, 'f'], [/_M$/, ''], [/_MALE$/, ''],
];
function fromConstant(tok) {
  let t = String(tok).replace(/^SPECIES_/, '');
  if (/^(NONE|EGG|UNOWN_EMPTY|MISSINGNO)/.test(t)) return null;
  const whole = id(t);
  if (dex.has(whole)) return whole;
  for (const [re, suf] of SUFFIX) {
    if (!re.test(t)) continue;
    const base = id(t.replace(re, ''));
    if (dex.has(base + suf)) return base + suf;
    if (dex.has(base)) return base;
  }
  // SPECIES_PIKACHU_COSPLAY, SPECIES_UNOWN_B…: try ever shorter prefixes
  const parts = t.split('_');
  for (let n = parts.length; n > 0; n--) {
    const both = id(parts.slice(0, n).join('')) + id(parts.slice(n).join(''));
    if (dex.has(both)) return both;
  }
  for (let n = parts.length - 1; n > 0; n--) { const base = id(parts.slice(0, n).join('')); if (dex.has(base)) return base; }
  return null;
}
const enc = (key) => { if (!key) return 0; const e = dex.get(key); return e.forme ? `${e.num}-${e.forme}` : e.num; };

// ---- CFRU: Unbound (constants) and Radical Red (names; forms borrowed from Unbound where the numbers agree) ----
const lines = (f) => fs.readFileSync(f, 'utf8').split(/\r?\n/).map((l) => /^(\d+):(.*)$/.exec(l)).filter(Boolean).map((m) => [Number(m[1]), m[2].trim()]);
const unboundConst = JSON.parse(fs.readFileSync(path.join(puse, 'species_constants.json'), 'utf8'));
const unboundNames = new Map(lines(path.join(puse, 'pokemon.txt')));
const cfruUnbound = [];
for (const [k, tok] of Object.entries(unboundConst)) cfruUnbound[Number(k)] = enc(fromConstant(tok));
const rrNames = lines(path.join(puse, 'games/radical-red-4.1/pokemon.txt'));
const cfruRR = [];
for (const [n, name] of rrNames) {
  if (unboundNames.get(n) === name && cfruUnbound[n]) { cfruRR[n] = cfruUnbound[n]; continue; }
  const k = id(name);
  cfruRR[n] = dex.has(k) ? enc(k) : 0;
}
// CFRU's move names are cut to 12 letters ("Dazzle Gleam", "SmellingSalt", "Baneful Bunk"): exact, then a few
// spelled-out ones, then the closest Showdown name (most of the short name's letters, in order)
const MOVE_ALIAS = { '1000arrows': 'thousandarrows', '1000waves': 'thousandwaves', dmaxcannon: 'dynamaxcannon', lightoruin: 'lightofruin', trickotreat: 'trickortreat', naturesmad: 'naturesmadness', hihorsepower: 'highhorsepower', electerrain: 'electricterrain', mistterrain: 'mistyterrain', psycterrain: 'psychicterrain', grassterrain: 'grassyterrain', hijumpkick: 'highjumpkick', spaceHole: 'hyperspacehole', spacehole: 'hyperspacehole', spacefury: 'hyperspacefury', doll: 'babydolleyes', dolleyes: 'babydolleyes', powerUpHit: 'poweruppunch', poweruphit: 'poweruppunch', spectthief: 'spectralthief', badtantrum: 'stompingtantrum', geistbeam: 'moongeistbeam', revelDance: 'revelationdance', reveldance: 'revelationdance', weirdsteam: 'steameruption', corrodegas: 'corrosivegas', endlessedge: 'stoneaxe', springwind: 'springtidestorm', astralstorm: 'astralbarrage', freezeglare: 'freezingglare', jealousburn: 'burningjealousy', wildboltwind: 'wildboltstorm', sandsearwind: 'sandsearstorm', bleakicewind: 'bleakwindstorm', lunarbless: 'lunarblessing', mysticpower: 'mysticalpower', surgestrikes: 'surgingstrikes', psyshieldram: 'psyshieldbash', disarmcry: 'disarmingvoice', flowerguard: 'flowershield', petalstorm: 'petalblizzard', cliffblades: 'precipiceblades', waterstar: 'watershuriken', spiritlock: 'spiritshackle', sunsteelram: 'sunsteelstrike', craftyguard: 'craftyshield', woodscurse: 'forestscurse', falseyield: 'falsesurrender', meteorrush: 'meteorassault', giantblade: 'behemothblade', giantbash: 'behemothbash', steampump: 'steameruption', infernalrage: 'ragingfury' };
const lcs = (a, b) => { const m = Array(b.length + 1).fill(0); for (let i = 1; i <= a.length; i++) { let prev = 0; for (let j = 1; j <= b.length; j++) { const t = m[j]; m[j] = a[i - 1] === b[j - 1] ? prev + 1 : Math.max(m[j], m[j - 1]); prev = t; } } return m[b.length]; };
function moveByName(name) {
  const k = id(name);
  if (!k || /^zmove/.test(k)) return 0;
  if (moveNum.has(k)) return moveNum.get(k);
  if (MOVE_ALIAS[k] && moveNum.has(MOVE_ALIAS[k])) return moveNum.get(MOVE_ALIAS[k]);
  let best = null, score = 0;
  for (const [mk, num] of moveNum) {
    if (mk[0] !== k[0]) continue;
    const s = lcs(k, mk) / k.length - Math.abs(mk.length - k.length) * 0.01;
    if (s > score) { score = s; best = num; }
  }
  return score >= 0.8 ? best : 0;
}
const cfruMoves = (f) => { const out = []; for (const [n, name] of lines(f)) out[n] = moveByName(name); return out; };

// ---- pokeemerald-expansion: the Species and Move enums ----
function readEnum(file, prefix) {
  const src = fs.readFileSync(file, 'utf8');
  const out = new Map(); // token → number
  let next = 0;
  const body = src.slice(src.indexOf('{'), src.lastIndexOf('}'));
  for (const raw of body.split('\n')) {
    const line = raw.replace(/\/\/.*$/, '').trim().replace(/,$/, '');
    const m = new RegExp(`^(${prefix}[A-Z0-9_]+|[A-Z0-9_]+)\\s*(?:=\\s*(.+))?$`).exec(line);
    if (!m) continue;
    let v;
    if (m[2] == null) v = next;
    else if (/^\d+$/.test(m[2])) v = Number(m[2]);
    else if (out.has(m[2])) { out.set(m[1], out.get(m[2])); continue; } // an alias: doesn't move the counter
    else continue;
    out.set(m[1], v); next = v + 1;
  }
  return out;
}
const pexSpecies = readEnum(path.join(pex, 'include/constants/species.h'), 'SPECIES_');
const expSpecies = [];
for (const [tok, n] of pexSpecies) { if (!tok.startsWith('SPECIES_') || expSpecies[n]) continue; const key = fromConstant(tok); if (key) expSpecies[n] = enc(key); }
const pexMoves = readEnum(path.join(pex, 'include/constants/moves.h'), 'MOVE_');
const expMoves = [];
for (const [tok, n] of pexMoves) { if (!tok.startsWith('MOVE_') || expMoves[n]) continue; expMoves[n] = moveNum.get(id(tok.replace(/^MOVE_/, ''))) ?? 0; }

// CFRU growth rates (0 medium fast, 1 erratic, 2 fluctuating, 3 medium slow, 4 fast, 5 slow): the hack's own,
// so a Pokémon put in arrives at the level it should
const growth = (f) => { const out = []; try { for (const [k, v] of Object.entries(JSON.parse(fs.readFileSync(f, 'utf8')))) { const r = typeof v === 'object' ? v?.growth_rate : v; if (Number.isFinite(Number(r))) out[Number(k)] = Number(r); } } catch { /* none */ } return out; };
// Emerald Seaglass: every Pokémon of Gens 1–3, the later evolutions and pre-evolutions of those families,
// and a few later "easter egg" lines (Tinkatink's, Applin's) — pokemonemeraldseaglass.com/features
function seaglassSet() {
  const byName = new Map([...dex.values()].map((v) => [id(v.name), v]));
  const family = (start) => { const seen = new Set(), todo = [start]; while (todo.length) { const e = todo.pop(); if (!e || seen.has(e.num)) continue; seen.add(e.num); todo.push(byName.get(id(e.prevo)), ...e.evos.map((n) => byName.get(id(n)))); } return seen; };
  const out = new Set();
  for (const e of dex.values()) {
    if (e.forme) continue;
    const fam = family(e);
    if ([...fam].some((n) => n <= 386)) fam.forEach((n) => out.add(n));
  }
  for (const n of [957, 958, 959, 840, 841, 842, 1011, 1019]) out.add(n); // Tinkatink, Tinkatuff, Tinkaton; Applin, Flapple, Appletun, Dipplin, Hydrapple
  return [...out].sort((a, b) => a - b);
}
const pack = (a) => JSON.stringify(Array.from({ length: a.length }, (_, i) => a[i] ?? 0));
const stats = (a) => `${a.filter(Boolean).length}/${a.length}`;
const out = `// Generated by tools/gen-romhack-data.mjs — do not edit by hand.
// How ROM hacks number their species and moves, as national numbers ("num" or "num-Forme") and national move numbers.
// Index = the hack's own number; 0 = unknown/unused.
// CFRU tables: from PUSE (Pokémon Unbound Save Editor, MIT, github.com/Zannael/PUSE). Expansion tables: from the
// Species/Move enums of pokeemerald-expansion (github.com/rh-hideout/pokeemerald-expansion). Matched to Showdown names.
export const CFRU_UNBOUND_SPECIES = ${pack(cfruUnbound)};
export const CFRU_RR_SPECIES = ${pack(cfruRR)};
export const CFRU_UNBOUND_MOVES = ${pack(cfruMoves(path.join(puse, 'moves.txt')))};
export const CFRU_RR_MOVES = ${pack(cfruMoves(path.join(puse, 'games/radical-red-4.1/moves.txt')))};
export const CFRU_UNBOUND_GROWTH = ${pack(growth(path.join(puse, 'species_growth_rates.json')))};
export const CFRU_RR_GROWTH = ${pack(growth(path.join(puse, 'games/radical-red-4.1/species_growth_rates.json')))};
// national numbers Emerald Seaglass has (forms: only Alolan ones)
export const SEAGLASS_NATIONAL = ${JSON.stringify(seaglassSet())};
export const EXPANSION_SPECIES = ${pack(expSpecies)};
export const EXPANSION_MOVES = ${pack(expMoves)};
`;
fs.writeFileSync(path.join(root, 'shared/engine/romhackData.js'), out);
console.log('unbound', stats(cfruUnbound), 'rr', stats(cfruRR), 'expansion', stats(expSpecies), 'moves exp', stats(expMoves));
