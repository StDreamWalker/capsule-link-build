// Builds Capsule Link as one web page: the PC app, the phone app, the desktop buddies and the move lab in a
// single self-contained HTML file that runs in a browser with nothing installed.
//   ESBUILD_PATH=… node web/build.mjs [--out dir]      -> capsule-link.html
// The page's own part (web/src) stands in for what Electron and Android do in the real apps; the apps' code is
// bundled as it is.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url)), root = path.join(here, '..'), shared = path.join(root, 'shared');
const esbuild = await import(process.env.ESBUILD_PATH ? pathToFileURL(process.env.ESBUILD_PATH).href : 'esbuild');
const outDir = process.argv.includes('--out') ? process.argv[process.argv.indexOf('--out') + 1] : path.join(here, 'dist');
const LIMIT = 25 * 1024 * 1024;

const { buildInfo } = await import(pathToFileURL(path.join(root, 'tools', 'buildinfo.mjs')).href);
const info = buildInfo();
const read = (...p) => fs.readFileSync(path.join(...p), 'utf8');
const common = { bundle: true, write: false, charset: 'ascii', logLevel: 'warning', sourcemap: false, legalComments: 'none', platform: 'browser', format: 'iife', minify: true };
const { m3dDefine } = await import(pathToFileURL(path.join(root, 'tools', 'm3dworker.mjs')).href);
const M3D = await m3dDefine(esbuild);
const bundle = async (entry, extra = {}) => (await esbuild.build({ ...common, target: 'chrome110', ...extra, define: { __BUILD__: JSON.stringify(info), ...M3D, ...(extra.define ?? {}) }, entryPoints: [entry] })).outputFiles[0].text;
const esc = (s) => s.replace(/<\/script/gi, '<\\/script'); // (safe inside a script tag; the same program either way)

// the apps, each exactly as its own build makes it
const pcJs = await bundle(path.join(root, 'desktop/src/renderer/app.js'));
const phoneJs = await bundle(path.join(root, 'mobile/src/main.js'), { target: ['chrome80'] });
const petJs = await bundle(path.join(root, 'desktop/src/pet/pet.js'));
const labJs = await bundle(path.join(root, 'tools/movelab/standalone.js'), { define: { __BUILD__: '{"version":"lab"}' } });
const hostJs = await bundle(path.join(here, 'src/host.js'));
// wild battles: Showdown's simulator and battle screen (one copy, shared by every part of the page)
const sd = await import(pathToFileURL(path.join(shared, 'sdbattle', 'build.mjs')).href);
const tmp = path.join(here, '.sd.js');
await sd.buildShowdownBattle(esbuild, tmp);
const sdJs = fs.readFileSync(tmp, 'utf8'); fs.rmSync(tmp, { force: true });

const font = read(shared, 'ui/font/font.css'), base = read(shared, 'ui/base.css');
const petHtml = read(root, 'desktop/src/pet/pet.html');
const petCss = /<style>([\s\S]*?)<\/style>/.exec(petHtml)?.[1];
if (!petCss) throw new Error('web build: the buddy window\'s styles were not found in pet.html');
const assets = {
  'pc-css': [font, base, read(root, 'desktop/src/renderer/styles.css')].join('\n'),
  'pc-js': pcJs,
  'phone-css': [font, base, read(root, 'mobile/src/styles.css')].join('\n'),
  'phone-js': esc(phoneJs),
  'pet-css': `${font}\n${petCss}`,
  'pet-js': esc(petJs),
  'lab-css': [font, base, sd.showdownCss(), read(root, 'tools/movelab/lab.css')].join('\n'),
  'lab-js': esc(labJs),
  'sd-css': sd.showdownCss(),
  'sd-js': esc(sdJs),
};
// each built-in file as a piece of JSON text the page reads when it needs it (no "<" left in it, so nothing
// in a file can be mistaken for the page's own tags)
const block = (id, text) => `<script type="application/json" id="cl-${id}">${JSON.stringify(text).replace(/</g, '\\u003c')}</script>`;
const icon = fs.readFileSync(path.join(root, 'desktop/assets/icon.png')).toString('base64');
const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><title>Capsule Link</title><link rel="icon" href="data:image/png;base64,${icon}"><meta name="generator" content="Capsule Link ${info.version} (single page)">
${Object.entries(assets).map(([id, text]) => block(id, text)).join('\n')}
</head><body><script>${esc(hostJs)}</script></body></html>`; // (the built-in files sit in the head: the app fills the body itself)

const bytes = Buffer.byteLength(html);
if (bytes > LIMIT) throw new Error(`web build: ${(bytes / 1048576).toFixed(1)} MB is over the 25 MB limit`);
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'capsule-link.html'), html);
const kb = (s) => `${Math.round(Buffer.byteLength(s) / 1024)} KB`;
console.log(`Built ${path.join(outDir, 'capsule-link.html')} (${(bytes / 1048576).toFixed(2)} MB, version ${info.version}): PC ${kb(pcJs)}, phone ${kb(phoneJs)}, buddies ${kb(petJs)}, move lab ${kb(labJs)}, battles ${kb(sdJs)}, page ${kb(hostJs)}`);
