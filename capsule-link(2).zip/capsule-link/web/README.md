# Capsule Link in one web page

`capsule-link.html` is the whole app in one file that runs in a browser with nothing installed: the PC app, the phone app (in a panel beside it, linked to it for real), the desktop buddies (walking over the page) and the move lab.

Build it:

    ESBUILD_PATH=… node web/build.mjs [--out dir]

The apps' own code is bundled as it is. `web/src/host.js` stands in for what Electron (the PC app's main process) and Android do in the real apps; `web/src/store.js` keeps the save, data set, pictures and backups in the browser (IndexedDB) instead of in files.

Open it on a wide screen for the PC app (the ◈ button opens the phone, the move lab and "About this copy"); on a phone-sized screen it opens the phone app. `?pc`, `?phone` and `?lab` at the end of the address pick one.

Keeping everything in the file: the page can write itself back out with everything inside it (saves, data set, pictures, sounds). In Chrome and Edge, ◈ → "Save into this file…" picks the file once and then saves into it as you go (one click to allow it each time it opens); in any browser, "Download a copy with everything inside" makes a new file that carries it all. When a file carries data that's newer than what the browser has (or the browser has nothing), the file's is used. The first file is about 8 MB; it grows with your pictures and sounds.

What a web page can't do: install update files, host the home server, link a real phone by Wi-Fi or USB, show the real Showdown site inside the app (it opens in a tab), read real NFC capsules or count steps in the background. Some picture sources refuse to be read from a web page.
