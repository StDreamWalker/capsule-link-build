// The PC app's data folder, in a browser: what desktop/src/main/storage.js keeps in files, kept in IndexedDB
// instead (trainer profiles, the data set, textures, backups). Everything is also held in memory, so the
// phone hub can read it at once, the way it reads the files' contents on a PC.
import * as E from '../../shared/engine/index.js';
import { starterSave } from '../../desktop/src/main/storage-starter.js';
import { makeBackup, backupFileName, readBackup, summarize } from '../../shared/engine/backup.js';

export const TEXTURE_DIRS = ['creatures', 'ranch', 'boxes', 'battle', 'ui', 'trainers', 'cries', 'items', 'fx'];
const fileOk = (dir, f) => (dir === 'cries' ? /\.(mp3|ogg|wav)$/i : /\.png$/i).test(f);
const typeOf = (p) => (/\.ogg$/i.test(p) ? 'audio/ogg' : /\.wav$/i.test(p) ? 'audio/wav' : /\.mp3$/i.test(p) ? 'audio/mpeg' : 'image/png');
const DB = 'capsule-link-web', KV = 'kv', TEX = 'textures', BK = 'backups';

function b64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}
export function unb64(text) {
  const s = atob(text), out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

/** IndexedDB, small and promise-shaped. If the browser has none (or blocks it), everything stays in memory. */
class Idb {
  open() {
    this.dbp ??= new Promise((resolve) => {
      try {
        const r = indexedDB.open(DB, 1);
        r.onupgradeneeded = () => { for (const s of [KV, TEX, BK]) if (!r.result.objectStoreNames.contains(s)) r.result.createObjectStore(s); };
        r.onsuccess = () => resolve(r.result);
        r.onerror = () => resolve(null);
        r.onblocked = () => resolve(null);
      } catch { resolve(null); }
    });
    return this.dbp;
  }
  async all(store) {
    const db = await this.open(); if (!db) return [];
    return new Promise((resolve) => {
      const out = [], q = db.transaction(store).objectStore(store).openCursor();
      q.onsuccess = () => { const c = q.result; if (c) { out.push([c.key, c.value]); c.continue(); } else resolve(out); };
      q.onerror = () => resolve(out);
    });
  }
  async put(store, entries) {
    const db = await this.open(); if (!db) return false;
    return new Promise((resolve) => {
      const tx = db.transaction(store, 'readwrite'), os = tx.objectStore(store);
      for (const [k, v] of entries) { if (v === undefined) os.delete(k); else os.put(v, k); }
      tx.oncomplete = () => resolve(true);
      tx.onerror = tx.onabort = () => { this.lastError = tx.error; resolve(false); };
    });
  }
  async clear(store) {
    const db = await this.open(); if (!db) return;
    return new Promise((resolve) => { const tx = db.transaction(store, 'readwrite'); tx.objectStore(store).clear(); tx.oncomplete = tx.onerror = tx.onabort = () => resolve(); });
  }
}

export class WebStore {
  constructor() {
    this.db = new Idb();
    this.kv = new Map(); // 'profiles', 'dataset', 'save:<id>', 'preset:<name>', 'phoneUpdate'
    this.tex = new Map(); // 'creatures/x.png' → { bytes, at, url }
    this.bk = new Map(); // file → { text, at }
    this.rev = 1;
    this.timer = null;
    this.profiles = { active: null, order: [] };
    this.persistent = false;
  }

  put(key, value) { this.kv.set(key, value); return this.db.put(KV, [[key, value]]); }
  del(key) { this.kv.delete(key); return this.db.put(KV, [[key, undefined]]); }
  saveKey(id) { return `save:${String(id).replace(/[^\w-]/g, '')}`; }

  async load() {
    this.persistent = !!(await this.db.open());
    for (const [k, v] of await this.db.all(KV)) this.kv.set(k, v);
    for (const [k, v] of await this.db.all(TEX)) this.tex.set(k, { bytes: v.bytes, at: v.at, url: null });
    for (const [k, v] of await this.db.all(BK)) this.bk.set(k, v);
    try { navigator.storage?.persist?.(); } catch { /* fine */ } // (ask the browser not to clear it on its own)
    if (!this.kv.get('profiles')) this.adoptPreview();
    // everything kept inside the file itself (saved into it, or a copy downloaded with everything inside):
    // used when it's newer than what this browser has (or this browser has nothing yet)
    const inFile = this.embedded();
    if (inFile && (!this.kv.get('profiles') || (inFile.savedAt ?? 0) > (this.kv.get('dataAt') ?? 0))) {
      try { this.restoreBackup(inFile, { version: inFile.version, safety: !!this.kv.get('profiles') }); this.put('dataAt', inFile.savedAt ?? Date.now()); this.fromFile = inFile.savedAt ?? true; return this; } catch (e) { console.warn('[store] what is inside the file could not be read:', e); }
    }
    this.open();
    return this;
  }
  embedded() {
    const el = document.getElementById('cl-data');
    if (!el) return null;
    try { const j = JSON.parse(el.textContent); return j?.profiles ? j : null; } catch { return null; }
  }
  changed() { this.kv.set('dataAt', Date.now()); this.db.put(KV, [['dataAt', this.kv.get('dataAt')]]); this.onChange?.(); }

  /** What the older browser preview kept in localStorage (profiles, data set, pictures) carries over, once. */
  adoptPreview() {
    const read = (k) => { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } };
    const index = read('capsule-link:profiles');
    if (!index?.order?.length) return;
    const order = [];
    for (const id of index.order) { const sv = read(`capsule-link:save:${id}`); if (sv) { this.put(this.saveKey(id), sv); order.push(id); } }
    if (!order.length) return;
    this.put('profiles', { active: order.includes(index.active) ? index.active : order[0], order });
    const ds = read('capsule-link:dataset'); if (ds?.species?.length) this.put('dataset', ds);
    const tex = read('capsule-link:textures') ?? {};
    const entries = [];
    for (const [p, url] of Object.entries(tex)) { const m = /^data:[^;]+;base64,(.*)$/.exec(String(url)); if (!m) continue; try { const v = { bytes: unb64(m[1]), at: Date.now() }; this.tex.set(p.toLowerCase(), { ...v, url: null }); entries.push([p.toLowerCase(), v]); } catch { /* skip */ } }
    if (entries.length) this.db.put(TEX, entries);
  }

  /** Reads what's stored into the working state (the data set, who can log on, the active trainer's save). */
  open() {
    this.dataset = this.kv.get('dataset') ?? E.createDefaultDataset();
    this.idx = E.indexDataset(this.dataset);
    this.dataset = this.idx.ds;
    this.profiles = this.kv.get('profiles') ?? { active: null, order: [] };
    this.profiles.order = (this.profiles.order ?? []).filter((id) => this.kv.has(this.saveKey(id)));
    if (!this.profiles.order.length) this.createProfile({ name: 'Trainer' }, { open: true });
    if (!this.profiles.order.includes(this.profiles.active)) this.profiles.active = this.profiles.order[0];
    this.writeIndex();
    this.save = null;
    this.openProfile(this.profiles.active);
  }

  get activeId() { return this.profiles.active; }
  writeIndex() { this.put('profiles', { active: this.profiles.active, order: [...this.profiles.order] }); }

  listProfiles() {
    return this.profiles.order.map((id) => {
      const sv = id === this.profiles.active && this.save ? this.save : this.kv.get(this.saveKey(id));
      if (!sv) return null;
      const creatures = Object.values(sv.creatures ?? {});
      return {
        id, trainer: sv.trainer, creatures: creatures.length,
        steps: sv.stats?.totalSteps ?? 0, lastUsed: sv.settings?.lastLogin ?? null, active: id === this.profiles.active,
        party: creatures.filter((c) => c.location?.kind === 'party').sort((a, b) => a.location.slot - b.location.slot).slice(0, 6).map((c) => c.speciesId),
      };
    }).filter(Boolean);
  }

  createProfile({ name = 'Trainer', card = null } = {}, { open = false } = {}) {
    const id = E.randomId(8);
    const save = starterSave(this.idx, String(name).slice(0, 12) || 'Trainer');
    if (card) save.trainer.card = card;
    this.put(this.saveKey(id), save);
    this.profiles.order.push(id);
    if (open) this.profiles.active = id;
    this.writeIndex();
    if (this.save) this.changed();
    return id;
  }

  openProfile(id) {
    if (this.save && this.profiles.active && this.profiles.active !== id) this.writeNow();
    const stored = this.kv.get(this.saveKey(id));
    if (!stored) throw new Error('That profile could not be read.');
    this.profiles.active = id;
    this.save = structuredClone(stored);
    migrate(this.save);
    E.tickAll(this.idx, this.save);
    this.save.settings.lastLogin = Date.now();
    this.rev++;
    this.writeIndex();
    this.writeNow();
    this.dailyBackup();
    return this.save;
  }

  deleteProfile(id) {
    if (this.profiles.order.length <= 1) throw new Error('The last profile cannot be deleted.');
    const sv = this.kv.get(this.saveKey(id));
    if (sv) this.keepFile(`deleted-${id}-${Date.now()}.json`, JSON.stringify(sv));
    this.del(this.saveKey(id));
    this.profiles.order = this.profiles.order.filter((x) => x !== id);
    if (this.profiles.active === id) { this.save = null; this.openProfile(this.profiles.order[0]); }
    this.writeIndex();
  }

  setDataset(ds) {
    this.idx = E.indexDataset(ds);
    this.dataset = this.idx.ds;
    this.put('dataset', this.dataset);
    this.changed();
  }

  setSave(save) { this.save = save; this.rev++; this.persist(); }
  persist() { this.dirty = true; clearTimeout(this.timer); this.timer = setTimeout(() => this.writeNow(), 250); }
  writeNow() {
    clearTimeout(this.timer);
    if (this.save && this.profiles.active) { const p = this.put(this.saveKey(this.profiles.active), this.save); if (this.dirty) { this.dirty = false; this.changed(); } return p; }
    return Promise.resolve(true);
  }

  // ---------- backups (the backups folder) ----------
  keepFile(name, text) { const v = { text, at: Date.now() }; this.bk.set(name, v); this.db.put(BK, [[name, v]]); return name; }
  dropFile(name) { this.bk.delete(name); this.db.put(BK, [[name, undefined]]); }
  dailyBackup() {
    const day = new Date().toISOString().slice(0, 10), id = this.profiles.active;
    const target = `save-${id}-${day}.json`;
    if (!this.bk.has(target) && this.save) this.keepFile(target, JSON.stringify(this.save));
    const old = [...this.bk.keys()].filter((f) => f.startsWith(`save-${id}-`)).sort();
    for (const f of old.slice(0, Math.max(0, old.length - 14))) this.dropFile(f);
  }

  /** Everything in one object: every trainer profile, the data set and (optionally) textures. */
  fullBackup({ textures = true, version, reason } = {}) {
    this.writeNow();
    const saves = {};
    for (const id of this.profiles.order) { const sv = id === this.profiles.active ? this.save : this.kv.get(this.saveKey(id)); if (sv) saves[id] = sv; }
    const parts = { profiles: { active: this.profiles.active, order: [...this.profiles.order], saves }, dataset: this.dataset };
    if (textures) {
      parts.textures = {};
      for (const [p, t] of this.tex) if (/\.png$/i.test(p)) parts.textures[p] = b64(t.bytes);
      // (the web copy also keeps the cries, and friends' Data Labs saved as presets)
      parts.cries = {};
      for (const [p, t] of this.tex) if (p.startsWith('cries/')) parts.cries[p] = b64(t.bytes);
      parts.presets = Object.fromEntries([...this.kv.entries()].filter(([k]) => k.startsWith('preset:')));
    }
    return makeBackup('pc', version, parts, { reason });
  }

  keepBackup(label, opts = {}) {
    const file = backupFileName('pc', label);
    this.keepFile(file, JSON.stringify(this.fullBackup({ textures: false, ...opts, reason: label })));
    const kept = [...this.bk.entries()].filter(([f]) => f.startsWith('capsule-link-pc-backup-')).sort((a, b) => a[1].at - b[1].at).map(([f]) => f);
    for (const f of kept.slice(0, Math.max(0, kept.length - 12))) this.dropFile(f);
    return file;
  }

  keepPhoneBackup(device, backup) {
    const r = readBackup(backup);
    if (!r.ok || r.kind !== 'phone') throw new Error(r.error ?? 'That is not a phone backup.');
    const who = String(device || 'phone').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24) || 'phone';
    const name = backupFileName('phone', who);
    this.keepFile(name, JSON.stringify(backup));
    const mine = [...this.bk.keys()].filter((f) => f.startsWith(`capsule-link-phone-backup-${who}-`)).sort();
    for (const f of mine.slice(0, Math.max(0, mine.length - 10))) this.dropFile(f);
    return name;
  }

  listBackups() {
    const out = [];
    for (const [f, v] of this.bk) {
      if (!/\.json$/i.test(f)) continue;
      let kind = 'save', summary = '';
      if (f.startsWith('capsule-link-pc-backup-')) kind = 'pc';
      else if (f.startsWith('capsule-link-phone-backup-')) kind = 'phone';
      if (kind !== 'save' || v.text.length < 4e6) {
        let j = null; try { j = JSON.parse(v.text); } catch { /* not readable */ }
        const r = readBackup(j);
        if (!r.ok) continue;
        kind = r.kind; summary = r.summary;
        if (kind === 'pc' && r.backup.reason && r.backup.reason !== 'by hand') summary += ` — kept automatically (${r.backup.reason.replace(/-/g, ' ')})`;
      }
      out.push({ file: f, kind, size: v.text.length, at: v.at, summary: summary || 'One trainer\'s daily save' });
    }
    return out.sort((a, b) => b.at - a.at);
  }

  readBackupFile(file) {
    const v = this.bk.get(String(file).split(/[\\/]/).pop());
    if (!v) throw new Error('That backup is not there any more.');
    return v.text;
  }

  restoreBackup(input, { version, safety = true } = {}) {
    const r = readBackup(input);
    if (!r.ok) throw new Error(r.error);
    if (r.kind !== 'pc') throw new Error(r.kind === 'phone' ? 'That is a phone backup: restore it on the phone (Link → Backups).' : 'That is a single save: use Import save instead.');
    const b = r.backup;
    const kept = safety ? this.keepBackup('before-restore', { version }) : null;
    clearTimeout(this.timer);
    const ids = Object.keys(b.profiles.saves).map((id) => String(id).replace(/[^\w-]/g, '')).filter(Boolean);
    for (const k of [...this.kv.keys()]) if (k.startsWith('save:')) this.del(k);
    for (const [id, sv] of Object.entries(b.profiles.saves)) this.put(this.saveKey(id), sv);
    const order = [...(b.profiles.order ?? []).filter((id) => ids.includes(id)), ...ids.filter((id) => !(b.profiles.order ?? []).includes(id))];
    this.put('profiles', { active: ids.includes(b.profiles.active) ? b.profiles.active : order[0], order });
    if (b.dataset?.species) this.put('dataset', b.dataset);
    let textures = 0;
    for (const [rel, data] of Object.entries({ ...(b.textures ?? {}), ...(b.cries ?? {}) })) { try { this.importTexture(rel, unb64(data), { list: false }); textures++; } catch { /* skip odd paths */ } }
    for (const [k, v] of Object.entries(b.presets ?? {})) if (k.startsWith('preset:') && v) this.put(k, v);
    this.open();
    return { safety: kept, profiles: ids.length, textures, summary: summarize(b) };
  }

  // ---------- textures (the textures folder) ----------
  /** { "creatures/sproutle.png": "blob:…" } */
  listTextures() {
    const out = {};
    for (const [p, t] of this.tex) {
      t.url ??= URL.createObjectURL(new Blob([t.bytes], { type: typeOf(p) }));
      out[p] = t.url;
    }
    return out;
  }

  bundle(pick, cap) {
    const files = {}; let sig = '';
    for (const p of [...this.tex.keys()].sort()) {
      const t = this.tex.get(p);
      if (!pick(p) || t.bytes.length > cap) continue;
      sig += `${p}:${t.bytes.length}:${Math.floor(t.at)};`;
      files[p] = `data:${typeOf(p)};base64,${b64(t.bytes)}`;
    }
    let hash = 0;
    for (let i = 0; i < sig.length; i++) hash = (Math.imul(hash, 31) + sig.charCodeAt(i)) >>> 0;
    return { hash: String(hash), files };
  }
  /** Textures as data URLs plus a fingerprint, so phones can mirror the PC's art. */
  textureBundle() { return this.bundle((p) => !p.startsWith('cries/') && /\.png$/i.test(p), 512 * 1024); }
  /** Cries as data URLs plus a fingerprint, so phones play the same sounds. */
  cryBundle() { return this.bundle((p) => p.startsWith('cries/'), 400 * 1024); }

  importTexture(rel, bytes, { list = true } = {}) {
    const clean = String(rel).replace(/\\/g, '/').split('/').filter((p) => p && p !== '..');
    if (clean.length !== 2 || !TEXTURE_DIRS.includes(clean[0]) || !fileOk(clean[0], clean[1])) throw new Error(`Textures go in ${TEXTURE_DIRS.map((d) => `${d}/`).join(', ')} as .png files.`);
    const key = `${clean[0]}/${clean[1].toLowerCase()}`;
    const old = this.tex.get(key);
    if (old?.url) { const u = old.url; setTimeout(() => URL.revokeObjectURL(u), 30000); }
    const v = { bytes: bytes instanceof Uint8Array ? new Uint8Array(bytes) : new Uint8Array(bytes), at: Date.now() };
    this.tex.set(key, { ...v, url: null });
    (this.texWrites ??= []).push([key, v]);
    clearTimeout(this.texTimer);
    this.texTimer = setTimeout(() => this.flushTextures(), 60);
    return list ? this.listTextures() : null;
  }
  flushTextures() { const w = this.texWrites ?? []; this.texWrites = []; if (w.length) this.changed(); return w.length ? this.db.put(TEX, w) : Promise.resolve(true); }

  importTextures(files) {
    const failed = [];
    for (const f of files) { try { this.importTexture(f.path, f.data, { list: false }); } catch (e) { failed.push({ path: f.path, error: e.message }); } }
    return { list: this.listTextures(), failed };
  }

  /** How much is kept, for the “about this copy” panel. */
  async usage() {
    let est = null; try { est = await navigator.storage?.estimate?.(); } catch { /* fine */ }
    let tex = 0; for (const t of this.tex.values()) tex += t.bytes.length;
    return { persistent: this.persistent, textures: this.tex.size, textureBytes: tex, backups: this.bk.size, used: est?.usage ?? null, quota: est?.quota ?? null };
  }

  /** Everything gone: the next start is a brand new copy. */
  async wipe() { clearTimeout(this.timer); clearTimeout(this.texTimer); for (const s of [KV, TEX, BK]) await this.db.clear(s); }
}

function migrate(save) {
  save.devices = save.devices || {};
  save.capsules = save.capsules || {};
  save.settings = Object.assign({ petUid: null, petEnabled: false, sound: true, volume: 0.6, autoSync: true, askLetOut: true }, save.settings);
  save.stats = Object.assign({ battlesWon: 0, battlesLost: 0, totalSteps: 0 }, save.stats);
  save.virtualTags = save.virtualTags || {};
  E.ensureTrainerCard(save);
}
