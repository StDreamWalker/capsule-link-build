// Capsule Link in one web page. This is the part that, in the PC app, is Electron's main process: it keeps
// the save, runs the phone hub, opens the other windows. Here it does the same inside the page:
//   - the save, data set, textures and backups live in this browser (IndexedDB), see store.js
//   - the PC app itself runs unchanged on top of a stand-in for the app's own bridge (window.capsule)
//   - the phone hub runs right here, and the phone app (in a panel beside the PC app) links to it for real,
//     over a stand-in for the network socket
//   - desktop buddies walk about over the page instead of over the desktop
// What a web page can't do stays out: installing updates, hosting the home server, the USB cable, the real
// Showdown site inside the app, real capsules over NFC.
import * as E from '../../shared/engine/index.js';
import { Hub } from '../../shared/net/hub.js';
import { backupFileName, summarize } from '../../shared/engine/backup.js';
import { WebStore } from './store.js';

// (the page's own source, as it was opened: to write it back out with everything kept inside it)
const SELF_JS = document.currentScript?.textContent ?? '';
const HEAD0 = [...document.head.children].filter((e) => e.id !== 'cl-data').map((e) => e.outerHTML).join('\n');
const BUILD = typeof __BUILD__ !== 'undefined' ? __BUILD__ : { version: '0.0.0' };
const HUB_PORT = E.HUB_PORT ?? 47820;
const CLOSE = '\u0000close';
const params = new URLSearchParams(location.search);
const assetCache = new Map();
/** One of the page's built-in files (the phone app, the battle files…), read the first time it's needed. */
function asset(id) {
  if (!assetCache.has(id)) { const el = document.getElementById(`cl-${id}`); assetCache.set(id, el ? JSON.parse(el.textContent) : ''); }
  return assetCache.get(id);
}
window.__clAsset = asset;
const narrow = Math.min(window.innerWidth || 9999, window.screen?.width || 9999) < 720;
const MODE = params.has('phone') ? 'phone' : params.has('lab') ? 'lab' : params.has('pc') ? 'pc' : narrow ? 'phone' : 'pc';
const urlFor = (mode) => `${location.pathname}${mode === 'pc' ? '?pc' : `?${mode}`}`;
const clone = (v) => structuredClone(v);
// (what the phone's window may use; "*" because a page opened from a file has no address of its own to name)
const ALLOW = ['accelerometer', 'gyroscope', 'magnetometer', 'geolocation', 'microphone', 'camera', 'fullscreen', 'clipboard-write', 'autoplay'].map((f) => `${f} *`).join('; ');
const h = (tag, props = {}, ...kids) => {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props ?? {})) { if (k === 'style') Object.assign(el.style, v); else if (k.startsWith('on')) el.addEventListener(k.slice(2), v); else if (v !== null && v !== undefined && v !== false) el.setAttribute(k, v === true ? '' : v); }
  for (const k of kids.flat()) if (k !== null && k !== undefined && k !== false) el.append(k);
  return el;
};

// ---------- what runs inside every window of the page (this one, the phone's, the buddies') ----------
// (kept self-contained: it's also handed to the other windows as text)
function clShim(cfg) {
  const host = cfg.top ? window : window.parent;
  const Real = window.WebSocket;
  const isLocal = (url) => { try { const u = new URL(url); return /^wss?:$/.test(u.protocol) && ['127.0.0.1', 'localhost', 'this-page'].includes(u.hostname) && String(u.port || '') === String(cfg.port); } catch { return false; } };
  const open = new Set();
  // a socket to the hub in this page: looks like a WebSocket to the app
  function LocalSocket(url) {
    const self = this, ch = new MessageChannel(), subs = {};
    this.url = url; this.readyState = 0; this.binaryType = 'blob'; this.protocol = ''; this.extensions = ''; this.bufferedAmount = 0;
    this.onopen = this.onmessage = this.onclose = this.onerror = null;
    const fire = (type, ev) => { ev.type = type; ev.target = self; try { self[`on${type}`]?.(ev); } catch (e) { console.error(e); } for (const fn of subs[type] ?? []) { try { fn(ev); } catch (e) { console.error(e); } } };
    const finish = () => { if (self.readyState === 3) return; self.readyState = 3; open.delete(self); try { ch.port1.close(); } catch { /* fine */ } setTimeout(() => fire('close', { code: 1000, reason: '', wasClean: true }), 0); };
    ch.port1.onmessage = (e) => { if (e.data === cfg.close) { finish(); return; } if (self.readyState === 1) fire('message', { data: e.data }); };
    this.addEventListener = (t, fn) => { (subs[t] ??= []).push(fn); };
    this.removeEventListener = (t, fn) => { subs[t] = (subs[t] ?? []).filter((x) => x !== fn); };
    this.send = (text) => { if (self.readyState !== 1) throw new Error('The link is not open.'); ch.port1.postMessage(String(text)); };
    this.close = () => { if (self.readyState >= 2) return; try { ch.port1.postMessage(cfg.close); } catch { /* fine */ } finish(); };
    setTimeout(() => {
      if (self.readyState !== 0) return;
      try { host.__clHubConnect(ch.port2, cfg.who); } catch (e) { fire('error', {}); finish(); return; }
      self.readyState = 1; open.add(self); fire('open', {});
    }, 0);
  }
  function Socket(url, protocols) {
    let local = false; try { local = isLocal(url) && typeof host.__clHubConnect === 'function'; } catch { local = false; }
    if (local) return new LocalSocket(url);
    return protocols === undefined ? new Real(url) : new Real(url, protocols);
  }
  Socket.prototype = Real.prototype;
  Socket.CONNECTING = 0; Socket.OPEN = 1; Socket.CLOSING = 2; Socket.CLOSED = 3;
  window.WebSocket = Socket;
  window.addEventListener('pagehide', () => { for (const s of [...open]) s.close(); });
  // wild battles: the battle files are inside the page (one copy, shared by every window)
  let sd = null;
  window.__clInlineShowdown = () => (sd ??= new Promise((resolve, reject) => {
    try {
      const st = document.createElement('style'); st.textContent = host.__clAsset('sd-css'); document.head.append(st);
      const s = document.createElement('script'); s.textContent = host.__clAsset('sd-js'); document.head.append(s);
      if (globalThis.CapsuleShowdown) resolve(globalThis.CapsuleShowdown); else reject(new Error('The battle files didn’t start.'));
    } catch (e) { reject(e); }
  }));
  // the phone app: "Find my PC" finds the PC app in this page
  window.__clWebHost = { version: cfg.version, discover: () => { let on = false; try { on = typeof host.__clHubConnect === 'function'; } catch { on = false; } return on ? [{ name: 'The PC app in this page', address: '127.0.0.1', port: cfg.port }] : []; } };
  if (cfg.pet) window.capsule = host.__clPetApi;
}
const shimText = (cfg) => `(${clShim.toString()})(${JSON.stringify({ port: HUB_PORT, close: CLOSE, version: BUILD.version, ...cfg })});`;
/** A whole page for one of the other windows, from the page's built-in files. */
function pageOf({ title, css, bodyClass = '', body = '', scripts, shim }) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><title>${title}</title><style>${css}</style></head><body class="${bodyClass}">${body}<script>${shimText(shim)}</script>${scripts.map((s) => `<script>${s}</script>`).join('')}</body></html>`;
}

// ---------- the launcher: a small button to reach the other parts, and what this copy keeps ----------
const ui = { root: null, shadow: null };
function mountUi() {
  if (ui.root) return;
  ui.root = h('div', { id: 'cl-webhost', style: { position: 'fixed', inset: '0', pointerEvents: 'none', zIndex: '2147483600' } });
  ui.shadow = ui.root.attachShadow({ mode: 'open' });
  ui.shadow.append(h('style', null, `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }
    .chip { position: fixed; pointer-events: auto; width: 34px; height: 34px; border-radius: 17px; border: 2px solid #1b1838; background: #ffc93c; color: #1b1838; font-size: 17px; line-height: 28px; text-align: center; cursor: pointer; opacity: .6; touch-action: none; user-select: none; box-shadow: 0 2px 6px rgba(0,0,0,.35); padding: 0; }
    .chip:hover, .chip.open { opacity: 1; }
    .menu { position: fixed; pointer-events: auto; min-width: 250px; max-width: min(340px, calc(100vw - 16px)); background: #1b1838; color: #f3f1ff; border: 2px solid #ffc93c; border-radius: 10px; padding: 6px; font-size: 14px; box-shadow: 0 8px 24px rgba(0,0,0,.5); }
    .menu button { display: block; width: 100%; text-align: left; background: none; border: 0; color: inherit; font-size: 14px; padding: 8px 10px; border-radius: 6px; cursor: pointer; }
    .menu button:hover { background: #3a2a8a; }
    .menu button small { display: block; color: #b9b4dc; font-size: 12px; margin-top: 1px; }
    .menu hr { border: 0; border-top: 1px solid #3a2a8a; margin: 4px 0; }
    .menu .foot { color: #b9b4dc; font-size: 12px; padding: 4px 10px 2px; }
    .phone { position: fixed; pointer-events: auto; display: flex; flex-direction: column; background: #0f0d22; border: 3px solid #1b1838; border-radius: 22px; box-shadow: 0 10px 34px rgba(0,0,0,.55), 0 0 0 1px #5b45c4; overflow: hidden; }
    .phone .bar { display: flex; align-items: center; gap: 6px; padding: 5px 10px; color: #f3f1ff; font-size: 12.5px; cursor: move; user-select: none; touch-action: none; background: #1b1838; }
    .phone .bar .grow { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .phone .bar code { background: #3a2a8a; border-radius: 4px; padding: 1px 6px; letter-spacing: 1.5px; font-size: 13px; }
    .phone .bar button { background: none; border: 0; color: #f3f1ff; font-size: 15px; cursor: pointer; padding: 0 5px; line-height: 20px; }
    .phone .bar button:hover { color: #ffc93c; }
    .phone iframe { flex: 1; border: 0; width: 100%; background: #14122b; }
    .sheet-bg { position: fixed; inset: 0; pointer-events: auto; background: rgba(8,6,24,.6); display: flex; align-items: center; justify-content: center; padding: 14px; }
    .sheet { background: #1b1838; color: #f3f1ff; border: 2px solid #ffc93c; border-radius: 12px; padding: 16px 18px; max-width: 520px; width: 100%; max-height: calc(100vh - 28px); overflow: auto; font-size: 14px; line-height: 1.45; }
    .sheet h2 { margin: 0 0 8px; font-size: 18px; }
    .sheet h3 { margin: 14px 0 4px; font-size: 14px; color: #ffc93c; }
    .sheet p { margin: 6px 0; }
    .sheet ul { margin: 4px 0; padding-left: 20px; }
    .sheet .dim { color: #b9b4dc; }
    .sheet .row { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px; }
    .sheet button { background: #ffc93c; color: #1b1838; border: 0; border-radius: 6px; padding: 8px 12px; font-size: 14px; cursor: pointer; font-weight: 600; }
    .sheet button.plain { background: #3a2a8a; color: #f3f1ff; }
    .sheet button.danger { background: #c4455b; color: #fff; }
    @media (max-width: 520px) { .phone { border-radius: 0; border: 0; } }
  `));
  document.documentElement.append(ui.root); // (beside the body, not in it: the app fills the body itself)
}
const lsGet = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v ?? d; } catch { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* blocked */ } };
/** Lets something be dragged about by a handle, staying on the screen; a plain click still clicks. */
function draggable(el, handle, key, onClick) {
  let d = null;
  const place = (x, y) => { const r = el.getBoundingClientRect(); x = Math.max(4, Math.min(window.innerWidth - r.width - 4, x)); y = Math.max(4, Math.min(window.innerHeight - Math.min(r.height, 40) - 4, y)); el.style.left = `${x}px`; el.style.top = `${y}px`; el.style.right = 'auto'; el.style.bottom = 'auto'; };
  handle.addEventListener('pointerdown', (e) => { if (e.button !== 0 || e.target.closest?.('button') && e.target !== handle) return; const r = el.getBoundingClientRect(); d = { dx: e.clientX - r.left, dy: e.clientY - r.top, x: e.clientX, y: e.clientY, moved: false }; handle.setPointerCapture?.(e.pointerId); });
  handle.addEventListener('pointermove', (e) => { if (!d) return; if (Math.abs(e.clientX - d.x) + Math.abs(e.clientY - d.y) > 5) d.moved = true; if (d.moved) place(e.clientX - d.dx, e.clientY - d.dy); });
  const up = (e) => { if (!d) return; const was = d; d = null; try { handle.releasePointerCapture?.(e.pointerId); } catch { /* fine */ } if (was.moved) { const r = el.getBoundingClientRect(); if (key) lsSet(key, { x: r.left, y: r.top }); } else onClick?.(e); };
  handle.addEventListener('pointerup', up); handle.addEventListener('pointercancel', up);
  const at = key ? lsGet(key, null) : null;
  if (at) requestAnimationFrame(() => place(at.x, at.y));
  window.addEventListener('resize', () => { const r = el.getBoundingClientRect(); if (r.width) place(r.left, r.top); });
}
let menuEl = null, chip = null;
function closeMenu() { menuEl?.remove(); menuEl = null; chip?.classList.remove('open'); }
function launcher(items) {
  mountUi();
  chip = h('button', { class: 'chip', title: 'Capsule Link: phone, move lab, about this copy (drag to move)', style: MODE === 'phone' ? { left: '4px', top: '45%' } : MODE === 'lab' ? { left: '10px', bottom: '10px' } : { right: '10px', bottom: '10px' } }, '◈');
  ui.shadow.append(chip);
  draggable(chip, chip, `clweb:chip:${MODE}`, () => {
    if (menuEl) { closeMenu(); return; }
    const r = chip.getBoundingClientRect();
    menuEl = h('div', { class: 'menu' }, items().filter(Boolean).map((it) => (it === '-' ? h('hr') : it.foot ? h('div', { class: 'foot' }, it.foot) : h('button', { onclick: () => { closeMenu(); it.run(); } }, it.label, it.detail ? h('small', null, it.detail) : null))));
    ui.shadow.append(menuEl);
    const m = menuEl.getBoundingClientRect();
    menuEl.style.left = `${Math.max(6, Math.min(window.innerWidth - m.width - 6, r.right - m.width))}px`;
    menuEl.style.top = `${r.bottom + m.height + 8 > window.innerHeight ? Math.max(6, r.top - m.height - 6) : r.bottom + 6}px`;
    chip.classList.add('open');
  });
  window.addEventListener('pointerdown', (e) => { if (!e.composedPath().includes(ui.root)) closeMenu(); }, true);
  window.addEventListener('blur', () => closeMenu()); // (a click inside the phone's panel, too)
}
function sheet(...kids) {
  mountUi();
  const bg = h('div', { class: 'sheet-bg', onclick: (e) => { if (e.target === bg) bg.remove(); } }, h('div', { class: 'sheet' }, ...kids));
  ui.shadow.append(bg);
  return bg;
}
const download = (name, text, type = 'application/json') => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; document.documentElement.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 20000); };
const mb = (n) => (n == null ? '?' : n < 1048576 ? `${Math.max(1, Math.round(n / 1024))} KB` : `${(n / 1048576).toFixed(1)} MB`);

const CANT = ['Installing update files (to update, open a newer copy of this page; everything you have stays in the browser).', 'Hosting the home server, and linking a phone by USB cable or over Wi-Fi (a web page can’t listen on the network). The phone app in this page links to it directly instead.', 'The real Showdown site inside the app: it opens in a new tab, and finished battles come in by replay link.', 'Real capsules over NFC and counting steps in the background (those need the Android app). The simulated capsule and step buttons work.', 'Some downloads: a browser can only read sites that allow it. If a picture source is refused, try the other one in the list.'];

// =====================================================================================================
// The phone app or the move lab, on their own (a small screen, or ?phone / ?lab in the address)
// =====================================================================================================
function soloFrame(html, title) {
  document.title = title;
  document.documentElement.style.cssText = 'height:100%;background:#14122b';
  document.body.style.cssText = 'margin:0;height:100%;overflow:hidden;background:#14122b';
  const f = h('iframe', { title, allow: ALLOW, style: { position: 'fixed', inset: '0', width: '100%', height: '100%', border: '0' } });
  f.srcdoc = html;
  document.body.append(f);
  return f;
}
const phonePage = (who = 'phone') => pageOf({ title: 'Capsule Link phone', css: asset('phone-css'), scripts: [asset('phone-js')], shim: { who } });
const labPage = () => pageOf({ title: 'Capsule Link · Move lab', css: asset('lab-css'), bodyClass: 'dark', scripts: [asset('sd-js'), asset('lab-js')], shim: { who: 'lab' } });

function aboutSolo() {
  sheet(h('h2', null, `Capsule Link ${BUILD.version}, in one web page`),
    h('p', null, MODE === 'phone' ? 'This is the phone app, with its Android parts simulated (capsules you tap from the Capsule screen, steps from the buttons or the phone’s motion sensor).' : 'This is the move lab.'),
    h('p', { class: 'dim' }, 'Everything is kept in this browser, for this file’s address. Clearing the browser’s site data erases it, so keep a backup (Link → Backups in the phone app).'),
    h('div', { class: 'row' }, h('button', { onclick: () => { location.href = urlFor('pc'); } }, 'Open the PC app'), h('button', { class: 'plain', onclick: (e) => e.target.closest('.sheet-bg').remove() }, 'Close')));
}

if (MODE === 'phone') {
  soloFrame(phonePage(), 'Capsule Link phone');
  launcher(() => [
    { label: '🖥️ PC app', detail: 'The full app, with this phone in a panel beside it (needs a wide screen)', run: () => { location.href = urlFor('pc'); } },
    { label: '🎬 Move lab', detail: 'Every move’s animation, to try and tune', run: () => { location.href = urlFor('lab'); } },
    '-', { label: 'ℹ️ About this copy', run: aboutSolo }, { foot: `Capsule Link ${BUILD.version} · web copy` },
  ]);
} else if (MODE === 'lab') {
  soloFrame(labPage(), 'Capsule Link · Move lab');
  launcher(() => [
    { label: '🖥️ PC app', run: () => { location.href = urlFor('pc'); } },
    { label: '📱 Phone app', run: () => { location.href = urlFor('phone'); } },
    '-', { label: 'ℹ️ About this copy', run: aboutSolo }, { foot: `Capsule Link ${BUILD.version} · web copy` },
  ]);
} else startPc();

// =====================================================================================================
// The PC app, with everything round it
// =====================================================================================================
function startPc() {
  const store = new WebStore();
  let hub = null, dockState = null, cryCache = null, textureCache = null, hostState = null;
  // ---------- the app's windows (the app itself, and the buddies' overlay) and what's sent to them ----------
  const wins = { main: {}, pet: {} };
  const on = (win, channel) => (fn) => { (wins[win][channel] ??= new Set()).add(fn); return () => wins[win][channel]?.delete(fn); };
  const send = (win, channel, payload) => { for (const fn of wins[win][channel] ?? []) { try { fn(payload); } catch (e) { console.error(e); } } };
  const broadcast = (channel, make, except = null) => { for (const w of Object.keys(wins)) if (w !== except && wins[w][channel]?.size) send(w, channel, make()); };
  const saveMsg = (reason) => () => ({ save: clone(store.save), rev: store.rev, reason });

  function saveChanged(reason) {
    store.rev++;
    store.persist();
    broadcast('save:changed', saveMsg(reason));
    refreshPet();
    paintPhoneBar();
  }
  const hubInfo = () => ({ port: HUB_PORT, pairCode: hub?.pairCode, localToken: hub?.localToken, ips: [{ name: 'This page (the phone panel)', address: '127.0.0.1' }], status: hub?.status() });

  function startHub() {
    hub = new Hub({
      mode: 'home',
      name: 'The PC app in this page',
      getIdx: () => store.idx,
      getSave: () => store.save,
      onSaveChanged: (reason) => saveChanged(reason),
      getPhoneUpdate: () => null,
      getDock: () => dockState,
      getCries: () => { if (!cryCache || Date.now() - cryCache.at > 15000) cryCache = { at: Date.now(), ...store.cryBundle() }; return cryCache; },
      backups: {
        put: (device, backup) => store.keepPhoneBackup(device, backup),
        list: () => store.listBackups().filter((b) => b.kind === 'phone').slice(0, 30),
        get: (file) => { if (!/^capsule-link-phone-backup-/.test(String(file).split(/[\\/]/).pop())) throw new Error('Only phone backups can be sent to a phone.'); return store.readBackupFile(file); },
      },
      getTextures: () => { if (!textureCache || Date.now() - textureCache.at > 5000) textureCache = { at: Date.now(), ...store.textureBundle() }; return textureCache; },
      log: (...a) => console.log('[hub]', ...a),
    });
    const origBroadcast = hub.broadcastChanged.bind(hub);
    hub.broadcastChanged = (reason, except) => { origBroadcast(reason, except); broadcast('hub:changed', hubInfo); paintPhoneBar(); };
    // a window of this page connecting: a stand-in for a network connection (text both ways, like a socket)
    let seq = 0;
    window.__clHubConnect = (port, who = '') => {
      const handlers = { message: [], close: [] };
      let open = true;
      const emit = (evt, ...a) => { for (const fn of handlers[evt]) { try { fn(...a); } catch (e) { console.error('[hub]', e); } } };
      const conn = {
        id: `web-${++seq}`, remote: `this page${who ? ` (${who})` : ''}`,
        on(evt, fn) { handlers[evt]?.push(fn); },
        send(obj) { if (open) port.postMessage(typeof obj === 'string' ? obj : JSON.stringify(obj)); },
        close() { if (!open) return; open = false; try { port.postMessage(CLOSE); port.close(); } catch { /* fine */ } emit('close'); },
      };
      port.onmessage = (e) => {
        if (!open) return;
        if (e.data === CLOSE) { open = false; emit('close'); broadcast('hub:changed', hubInfo); paintPhoneBar(); return; }
        let msg; try { msg = JSON.parse(e.data); } catch { conn.send({ type: 'error', message: 'Messages must be JSON.' }); return; }
        emit('message', msg);
      };
      hub.attach(conn);
      setTimeout(() => { broadcast('hub:changed', hubInfo); paintPhoneBar(); }, 300);
      return conn;
    };
  }
  const ready = store.load().then(() => { startHub(); });

  // ---------- desktop buddies: over the page ----------
  const petBusy = new Set();
  let petFrame = null, petPass = true, petDataset = null;
  const buddyUids = () => E.desktopBuddies(store.save);
  function petPayload() {
    const creatures = buddyUids().filter((uid) => !petBusy.has(uid)).map((uid) => store.save.creatures[uid]).filter(Boolean);
    if (petDataset?.of !== store.dataset) petDataset = { of: store.dataset, copy: clone(store.dataset) };
    return { creature: clone(creatures[0] ?? null), creatures: clone(creatures), dataset: petDataset.copy, textures: store.listTextures(), settings: clone(store.save.settings) };
  }
  function openPet() {
    if (petFrame) { refreshPet(); return; }
    petFrame = h('iframe', { title: 'Buddies', tabindex: '-1', style: { position: 'fixed', inset: '0', width: '100%', height: '100%', border: '0', background: 'transparent', pointerEvents: 'none', zIndex: '2147483000', colorScheme: 'normal' } });
    petFrame.srcdoc = pageOf({ title: 'Capsule Link buddy', css: asset('pet-css'), body: '<canvas id="stage"></canvas>', scripts: [asset('pet-js')], shim: { who: 'buddies', pet: true } });
    petPass = true;
    document.documentElement.append(petFrame);
  }
  function closePet() { if (!petFrame) return; petFrame.remove(); petFrame = null; wins.pet = {}; }
  function refreshPet() {
    if (!petFrame) return;
    const s = store.save.settings;
    if (!s.petEnabled || !buddyUids().length) { closePet(); return; }
    send('pet', 'pet:data', petPayload());
  }
  function syncPetWindow() { const s = store.save.settings; if (s.petEnabled && buddyUids().length) openPet(); else closePet(); }
  // (the overlay lets the mouse through to the app, except over a buddy: it's told where the mouse is)
  window.addEventListener('pointermove', (e) => {
    if (!petFrame || !petPass) return;
    try { const w = petFrame.contentWindow; w.dispatchEvent(new w.PointerEvent('pointermove', { clientX: e.clientX, clientY: e.clientY, bubbles: true, pointerType: e.pointerType })); } catch { /* still loading */ }
  }, { capture: true, passive: true });

  const petApi = {
    petData: async () => { await ready; return petPayload(); },
    onPetData: on('pet', 'pet:data'),
    onPetHost: () => {},
    petMouse: (over) => { if (!petFrame) return; petPass = !over; petFrame.style.pointerEvents = over ? 'auto' : 'none'; },
    petFocus: (onNow) => { try { if (onNow) petFrame?.contentWindow?.focus(); else window.focus(); } catch { /* fine */ } },
    petCare: async (action, item, uid) => {
      const c = store.save.creatures[uid ?? store.save.settings.petUid];
      if (!c) return null;
      const out = E.applyCare(store.idx, c, action, { item, inventory: store.save.inventory });
      saveChanged('pet-care');
      return clone(out ?? null);
    },
    petTalk: async (uid, text, mode) => {
      const c = store.save.creatures[uid]; if (!c || !text) return null;
      const out = E.talkTo(store.idx, store.save, c, String(text).slice(0, 300), Date.now(), { where: 'desktop' });
      try {
        const s = String(text).toLowerCase(), t = Date.now(), nm = E.displayName(store.idx, c);
        const GENRES = ['lo-fi', 'lofi', 'rock', 'pop', 'jazz', 'classical', 'hip hop', 'hip-hop', 'rap', 'metal', 'country', 'edm', 'techno', 'house', 'r&b', 'soul', 'funk', 'indie', 'punk', 'folk', 'reggae', 'k-pop', 'kpop', 'j-pop', 'jpop', 'ambient', 'soundtrack', 'blues', 'disco', 'synthwave', 'video game music'];
        if (mode === 'music' || hostState?.music) { const g = GENRES.find((x) => s.includes(x)); if (g) { c.prefs = { ...(c.prefs ?? {}) }; c.prefs[`music:${g}`] = (c.prefs[`music:${g}`] ?? 0) + 1; if (c.prefs[`music:${g}`] === 1 || c.prefs[`music:${g}`] === 5) E.addMemory(c, c.prefs[`music:${g}`] >= 5 ? `${nm} has really come to love ${g} music with you.` : `${nm} listened to some ${g} with you.`, t, { core: c.prefs[`music:${g}`] >= 5 }); } }
        if (mode === 'movie') { const m = s.match(/(?:watching|playing|it'?s|this is)\s+([a-z0-9][a-z0-9 :'&!-]{2,40})/i); if (m) { const what = m[1].trim().replace(/[.!?]+$/, ''); c.prefs = { ...(c.prefs ?? {}) }; c.prefs[`watch:${what}`] = (c.prefs[`watch:${what}`] ?? 0) + 1; if (c.prefs[`watch:${what}`] === 1) E.addMemory(c, `${nm} watched ${what} with you on the screen.`, t, { core: false }); } }
      } catch { /* fine */ }
      saveChanged('pet-talk');
      return { note: out?.note ?? null, bubble: out?.bubble ?? null, mood: out?.mood ?? null, name: E.displayName(store.idx, c) };
    },
    petAsk: async (uid, ask, answer) => {
      const c = store.save.creatures[uid]; if (!c || !ask) return null;
      const nm = E.displayName(store.idx, c), t = Date.now();
      if (answer === 'task') { const tk = E.addTask(store.save, { id: `task-${uid}-${t.toString(36)}`, uid, made: t, due: t + 2 * 86400000, kind: 'wish', key: `wish:${ask.act ?? ask.kind}`, icon: ask.icon ?? '❗', text: `${nm} asked: ${ask.text}` }); saveChanged('pet-ask'); return { ok: !!tk }; }
      if (answer === 'start') { setTimeout(() => send('main', 'app:go', { route: ask.kind === 'battle' ? 'battle' : 'activities', act: ask.act ?? null, uid }), 400); return { ok: true }; }
      if (answer === 'no') { c.needs = { ...(c.needs ?? {}) }; return { ok: true }; }
      return null;
    },
    petGift: async (uid, found) => {
      if (found) {
        const f = E.walkFind(store.idx, Math.random);
        const c = uid && store.save.creatures[uid];
        let name;
        if (f.coins) { E.earn(store.save, f.coins); name = `${f.coins} coins`; }
        else { store.save.inventory[f.item] = (store.save.inventory[f.item] ?? 0) + 1; name = E.itemInfo(store.idx, f.item)?.name ?? 'something'; }
        if (c && !c.firsts?.deskTrip) { c.firsts = { ...(c.firsts || {}), deskTrip: Date.now() }; E.addMemory(c, `Went exploring off the edge of the desktop and came back with ${name}.`, Date.now(), { core: false }); }
        saveChanged('pet-gift');
        return { name, color: null };
      }
      const foods = (store.dataset.items ?? []).filter((i) => i.kind === 'food' && !i.unlimited);
      const pool = [...foods, ...foods.filter((i) => i.grow)];
      const it = pool[Math.floor(Math.random() * pool.length)];
      if (!it) return null;
      store.save.inventory[it.id] = (store.save.inventory[it.id] ?? 0) + 1;
      E.earn(store.save, 5);
      const c = uid && store.save.creatures[uid];
      if (c && !c.firsts?.deskFind) { c.firsts = { ...(c.firsts || {}), deskFind: Date.now() }; E.addMemory(c, `Found a ${it.name} lying around on the desktop.`, Date.now(), { core: false }); }
      saveChanged('pet-gift');
      return { item: it.id, name: it.name, color: it.color ?? null };
    },
    petForm: async (uid, form) => { const c = store.save.creatures[uid]; if (!c) return { ok: false }; const r = E.setForm(store.idx, c, form); saveChanged('pet-form'); return clone(r); },
    petChanges: async (uid) => { const c = store.save.creatures[uid]; return c ? clone(E.changeOptions(store.idx, store.save, c)) : []; },
    petChange: async (uid, key) => { const r = E.applyChange(store.idx, store.save, uid, key); if (r.ok) saveChanged('pet-change'); return { ok: r.ok, reason: r.reason, text: r.text, kind: r.kind }; },
    petOpenApp: () => { try { window.focus(); } catch { /* fine */ } },
    petAway: (uid) => {
      if (uid) E.toggleBuddy(store.save, uid, false); else store.save.settings.petEnabled = false;
      saveChanged('pet');
      if (!store.save.settings.petEnabled) closePet(); else refreshPet();
    },
    petBusy: (uid, onNow) => { if (!uid) return; if (onNow) petBusy.add(uid); else petBusy.delete(uid); refreshPet(); },
  };
  window.__clPetApi = petApi;

  // ---------- the app's bridge (what the PC app calls its main process through) ----------
  const pickFile = (accept) => new Promise((resolve) => {
    const input = h('input', { type: 'file', accept: accept || null, style: { display: 'none' } });
    let done = false;
    const end = (v) => { if (done) return; done = true; input.remove(); resolve(v); };
    input.onchange = async () => { const f = input.files[0]; end(f ? { name: f.name, text: await f.text() } : null); };
    input.addEventListener('cancel', () => end(null));
    document.documentElement.append(input); input.click();
  });
  const notHere = (what) => { throw new Error(`${what} needs the PC app: this is the copy that runs in a web page.`); };
  window.capsule = {
    web: true, canEmbedShowdown: false,
    load: async () => {
      await ready;
      setTimeout(syncPetWindow, 1200);
      return { save: clone(store.save), rev: store.rev, dataset: clone(store.dataset), textures: store.listTextures(), profiles: clone(store.listProfiles()), activeProfile: store.activeId,
        hub: hubInfo(), paths: { data: 'this browser', textures: 'this browser' }, version: BUILD.version, platform: 'web' };
    },
    commit: async (save, baseRev, reason) => {
      if (baseRev !== store.rev) return { conflict: true, save: clone(store.save), rev: store.rev };
      store.setSave(clone(save));
      broadcast('save:changed', saveMsg(reason), 'main');
      syncPetWindow(); refreshPet();
      return { ok: true, rev: store.rev };
    },
    saveDataset: async (ds) => {
      store.setDataset(clone(ds));
      broadcast('dataset:changed', () => ({ dataset: clone(store.dataset), hash: store.idx.hash }));
      refreshPet();
      return { ok: true, hash: store.idx.hash };
    },
    listTextures: async () => store.listTextures(),
    openTextures: async () => about(),
    openData: async () => about(),
    importTexture: async (rel, data) => { const list = store.importTexture(rel, data); textureCache = null; cryCache = null; broadcast('textures:changed', () => ({ ...list })); return list; },
    importTextures: async (files) => { const r = store.importTextures(Array.isArray(files) ? files : []); textureCache = null; cryCache = null; broadcast('textures:changed', () => ({ ...r.list })); return r; },
    listProfiles: async () => clone(store.listProfiles()),
    createProfile: async ({ name, card } = {}) => { const id = store.createProfile({ name, card: card ? clone(card) : null }); return { id, profiles: clone(store.listProfiles()) }; },
    openProfile: async (id) => {
      if (id !== store.activeId) {
        store.openProfile(id);
        hub?.dropPhones();
        broadcast('save:changed', saveMsg('profile'), 'main');
        syncPetWindow(); refreshPet();
        broadcast('hub:changed', hubInfo);
      } else { store.save.settings.lastLogin = Date.now(); store.persist(); }
      return { save: clone(store.save), rev: store.rev, id: store.activeId };
    },
    deleteProfile: async (id) => { store.deleteProfile(id); return { profiles: clone(store.listProfiles()), active: store.activeId, save: clone(store.save), rev: store.rev }; },
    hubInfo: async () => hubInfo(),
    usbSetup: async () => ({ ok: false, reason: null, devices: [{ serial: 'The phone in this page', state: 'device', linked: false, error: 'needs no cable: open it with the ◈ button, then Link → Find my PC' }] }),
    newPairCode: async () => { hub.pairCode = String(Math.floor(100000 + Math.random() * 900000)); paintPhoneBar(); return hubInfo(); },
    forgetDevice: async (deviceId) => { delete store.save.devices[deviceId]; saveChanged('devices'); return hubInfo(); },
    exportFile: async (name, text) => { download(name, text, /\.txt$/i.test(name) ? 'text/plain' : 'application/json'); return { ok: true, path: `your downloads folder (${name})` }; },
    importFile: async (filters) => pickFile((filters ?? []).flatMap((f) => f.extensions ?? []).filter((x) => x && x !== '*').map((x) => `.${x}`).join(',')),
    reportDock: (d) => { dockState = d ? clone(d) : null; hub?.broadcastChanged?.('dock'); },
    backupExport: async ({ textures = true } = {}) => { const b = store.fullBackup({ textures, version: BUILD.version }); const name = backupFileName('pc'); download(name, JSON.stringify(b)); return { ok: true, path: `your downloads folder (${name})`, summary: summarize(b) }; },
    backupList: async () => store.listBackups(),
    backupCopy: async (file) => { const name = String(file).split(/[\\/]/).pop(); download(name, store.readBackupFile(file)); return { ok: true, path: `your downloads folder (${name})` }; },
    backupRead: async (file) => store.readBackupFile(file),
    backupRestore: async (text) => {
      const r = store.restoreBackup(text, { version: BUILD.version });
      await store.writeNow(); await store.flushTextures();
      hub?.broadcastChanged?.('restore');
      setTimeout(() => location.reload(), 150);
      return r;
    },
    fetchUrl: async (url, as = 'text') => {
      if (!/^https?:\/\//i.test(String(url))) throw new Error('Only web addresses can be downloaded.');
      let r;
      try { r = await fetch(url, { redirect: 'follow' }); } catch { throw new Error(`couldn’t read ${new URL(url).host} from a web page (the site doesn’t allow it, or there’s no internet): try another source, or the PC app`); }
      const out = { ok: r.ok, status: r.status, type: r.headers.get('content-type') ?? '', url: r.url };
      if (!r.ok) return out;
      if (as === 'bytes') out.bytes = new Uint8Array(await r.arrayBuffer()); else out.text = await r.text();
      return out;
    },
    updateInfo: async () => ({ running: BUILD, builtIn: BUILD, active: null, failed: null, phone: null, phones: hub ? [...hub.phoneApps.values()] : [], preview: true, web: true }),
    installUpdate: async () => notHere('Installing an update file'),
    revertUpdate: async () => ({ running: BUILD, builtIn: BUILD, active: null }),
    restart: async () => { await store.writeNow(); location.reload(); },
    onSaveChanged: on('main', 'save:changed'), onDatasetChanged: on('main', 'dataset:changed'), onTexturesChanged: on('main', 'textures:changed'), onHubChanged: on('main', 'hub:changed'),
    onSerialChoose: () => () => {}, chooseSerial: () => {},
    openShowdown: async (url) => { window.open(/^https?:\/\//i.test(url || '') ? url : E.SHOWDOWN_DEFAULTS.server, '_blank', 'noopener'); return true; },
    fetchText: async (url) => { if (!/^https?:\/\//i.test(String(url))) throw new Error('Only web links can be loaded.'); const r = await fetch(url); if (!r.ok) throw new Error(`The replay server answered ${r.status}.`); return r.text(); },
    onShowdown: () => () => {},
    onAppGo: on('main', 'app:go'),
    onPetHost: () => {},
    ...petApi,
    onPetData: on('main', 'pet:data'),
    presetsList: async () => [...store.kv.entries()].filter(([k]) => k.startsWith('preset:')).map(([, j]) => ({ name: j.name, label: j.label, hash: j.hash, at: j.at, species: j.dataset?.species?.length ?? 0 })),
    presetsSave: async (p) => { await store.put(`preset:${String(p.name).toLowerCase().replace(/[^a-z0-9._-]+/g, '-').slice(0, 60)}`, { ...clone(p), at: Date.now() }); return { ok: true }; },
    presetsLoad: async (name) => clone(store.kv.get(`preset:${String(name).toLowerCase().replace(/[^a-z0-9._-]+/g, '-').slice(0, 60)}`) ?? null),
    presetsDelete: async (name) => { await store.del(`preset:${String(name).toLowerCase().replace(/[^a-z0-9._-]+/g, '-').slice(0, 60)}`); return { ok: true }; },
  };
  // (what's kept is written before the page goes away)
  const flush = () => { try { store.writeNow(); store.flushTextures(); } catch { /* fine */ } };
  window.addEventListener('pagehide', flush);
  document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); });

  // ---------- everything kept inside the file itself ----------
  // The page writes itself back out with a copy of everything inside it (saves, data set, pictures, sounds,
  // presets). Chrome and Edge can save that straight into the file you opened (you pick it once; each time
  // the page opens, one click lets it carry on); any browser can download it as a new file.
  const canWrite = typeof window.showSaveFilePicker === 'function';
  const fileState = { handle: null, on: false, busy: false, again: false, at: null, error: null };
  const fileName = () => decodeURIComponent(location.pathname.split('/').pop() || 'capsule-link.html');
  function pageWithData() {
    const data = store.fullBackup({ textures: true, version: BUILD.version, reason: 'kept in the file' });
    data.savedAt = Date.now();
    const block = `<script type="application/json" id="cl-data">${JSON.stringify(data).replace(/</g, '\\u003c')}</` + 'script>';
    return { html: `<!doctype html><html lang="en"><head>${HEAD0}\n${block}\n</head><body><script>${SELF_JS}</` + 'script></body></html>', savedAt: data.savedAt };
  }
  async function writeFile() {
    if (!fileState.on || !fileState.handle) return;
    if (fileState.busy) { fileState.again = true; return; }
    fileState.busy = true; fileTimer = null;
    try {
      await store.writeNow(); await store.flushTextures();
      const { html, savedAt } = pageWithData();
      const w = await fileState.handle.createWritable(); // (written to the side and swapped in at the end: a crash halfway leaves the old file as it was)
      await w.write(new Blob([html], { type: 'text/html' })); await w.close();
      fileState.at = savedAt; fileState.error = null; store.put('dataAt', savedAt);
    } catch (e) { fileState.error = e.message; if (/permission|not allowed/i.test(e.message)) fileState.on = false; console.warn('[file]', e); }
    fileState.busy = false;
    if (fileState.again) { fileState.again = false; setTimeout(writeFile, 1500); }
  }
  let fileTimer = null;
  store.onChange = () => { if (!fileState.on) return; clearTimeout(fileTimer); fileTimer = setTimeout(writeFile, 4000); };
  async function chooseFile() {
    if (!canWrite) { downloadWithData(); return; }
    try {
      const handle = await window.showSaveFilePicker({ suggestedName: fileName(), types: [{ description: 'Capsule Link page', accept: { 'text/html': ['.html'] } }] });
      fileState.handle = handle; fileState.on = true;
      store.put('fileHandle', handle);
      await writeFile();
      sheet(h('h2', null, 'Saving into the file'), h('p', null, `Everything is now saved into ${handle.name} as you go. Copy that file anywhere and open it: your trainers, pictures and sounds come with it.`),
        h('p', { class: 'dim' }, 'Open that file from now on (not the original, if you picked a different one). Each time it opens, the browser asks once whether it may carry on saving into it.'), h('div', { class: 'row' }, h('button', { onclick: (e) => e.target.closest('.sheet-bg').remove() }, 'OK')));
    } catch (e) { if (e.name !== 'AbortError') sheet(h('h2', null, 'Couldn’t save into a file'), h('p', null, e.message), h('div', { class: 'row' }, h('button', { onclick: (ev) => ev.target.closest('.sheet-bg').remove() }, 'OK'))); }
  }
  async function downloadWithData() { await store.writeNow(); await store.flushTextures(); const { html } = pageWithData(); download(fileName(), html, 'text/html'); }
  window.__clFile = { pageWithData, writeFile, fileState };
  let fileBar = null;
  function askToCarryOn() {
    mountUi();
    fileBar = h('div', { class: 'menu', style: { left: '50%', top: '10px', transform: 'translateX(-50%)', display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 10px', minWidth: '0' } },
      h('span', null, `Keep saving into ${fileState.handle?.name ?? 'the file'}?`),
      h('button', { style: { width: 'auto', background: '#ffc93c', color: '#1b1838', fontWeight: '600' }, onclick: async () => { try { if ((await fileState.handle.requestPermission({ mode: 'readwrite' })) === 'granted') { fileState.on = true; fileBar.remove(); writeFile(); } } catch (e) { console.warn(e); } } }, 'Yes'),
      h('button', { style: { width: 'auto' }, onclick: () => fileBar.remove() }, 'Not now'));
    ui.shadow.append(fileBar);
  }
  ready.then(async () => {
    const handle = store.kv.get('fileHandle');
    if (!handle || !canWrite) return;
    fileState.handle = handle;
    try { const st = await handle.queryPermission({ mode: 'readwrite' }); if (st === 'granted') fileState.on = true; else askToCarryOn(); } catch { /* the file's gone */ }
  });
  window.addEventListener('beforeunload', (e) => { if (fileState.on && (fileTimer || fileState.busy)) { clearTimeout(fileTimer); writeFile(); e.preventDefault(); } });

  // ---------- the phone, in a panel beside the app ----------
  let phone = null;
  function paintPhoneBar() {
    if (!phone) return;
    const paired = Object.keys(store.save?.devices ?? {}).length > 0;
    phone.info.replaceChildren(...(paired ? ['Phone · paired with this page’s PC app'] : ['Phone · pairing code ', h('code', null, hub?.pairCode ?? '------')]));
  }
  function togglePhone(show) {
    mountUi();
    if (!phone && show === undefined) show = true;
    if (!phone) {
      const frame = h('iframe', { title: 'Capsule Link phone', allow: ALLOW });
      const info = h('span', { class: 'grow' });
      const bar = h('div', { class: 'bar' }, info,
        h('button', { title: 'Start the phone app again', onclick: () => { frame.srcdoc = phonePage(); } }, '↻'),
        h('button', { title: 'Hide (it keeps running)', onclick: () => togglePhone(false) }, '–'));
      const el = h('div', { class: 'phone', style: { right: '14px', bottom: '54px', width: 'min(392px, 100vw)', height: 'min(780px, calc(100vh - 68px))' } }, bar, frame);
      ui.shadow.append(el);
      draggable(el, bar, 'clweb:phone');
      phone = { el, frame, info };
      frame.srcdoc = phonePage();
    }
    const on2 = show ?? phone.el.style.display === 'none';
    phone.el.style.display = on2 ? 'flex' : 'none';
    lsSet('clweb:phoneOpen', on2);
    paintPhoneBar();
  }

  async function about() {
    await ready;
    const u = await store.usage();
    const bg = sheet(h('h2', null, `Capsule Link ${BUILD.version}, in one web page`),
      h('p', null, 'The PC app, the phone app, the desktop buddies and the move lab, all in this one file. Nothing is installed and nothing leaves this computer.'),
      h('h3', null, 'Where everything is kept'),
      h('p', null, u.persistent ? `In this browser, for this file’s address: ${store.profiles.order.length} trainer profile${store.profiles.order.length === 1 ? '' : 's'}, ${u.textures} picture and sound file${u.textures === 1 ? '' : 's'} (${mb(u.textureBytes)}), ${u.backups} automatic backup${u.backups === 1 ? '' : 's'}.${u.used != null ? ` The browser says this site uses ${mb(u.used)} of ${mb(u.quota)} it may use.` : ''}` : 'This browser is not letting the page keep anything (a private window, or storage is blocked): everything will be gone when the page closes.'),
      h('p', { class: 'dim' }, `Clearing the browser’s site data, or opening the file from another folder or in another browser, starts a new empty copy, unless the file carries everything inside it: ${canWrite ? '“Save into this file” keeps it saved inside the file as you go; ' : ''}“Download a copy with everything inside” makes a new file that does. A full backup file carries everything too, and works in the PC app.`),
      h('h3', null, 'What a web page can’t do'),
      h('ul', null, CANT.map((t) => h('li', null, t))),
      h('div', { class: 'row' },
        h('button', { onclick: () => window.capsule.backupExport({ textures: true }) }, 'Download a full backup'),
        h('button', { class: 'plain', onclick: () => bg.remove() }, 'Close'),
        h('button', { class: 'danger', onclick: async () => { if (!confirm('Erase every trainer, picture and backup this page keeps in this browser? (The phone app’s own data stays.) This can’t be undone.')) return; await store.wipe(); location.reload(); } }, 'Erase everything…')));
  }

  // ---------- start: the PC app's own page, from the built-in files ----------
  clShim({ top: true, port: HUB_PORT, close: CLOSE, version: BUILD.version, who: 'pc' });
  document.head.append(h('style', { id: 'cl-pc-style' }, asset('pc-css')));
  const s = document.createElement('script'); s.textContent = asset('pc-js'); document.body.append(s);
  launcher(() => [
    { label: phone && phone.el.style.display !== 'none' ? '📱 Hide the phone' : '📱 Phone', detail: 'The phone app, in a panel: link it with Link → Find my PC and the code on Phone Link', run: () => togglePhone() },
    { label: '↗️ Phone app in its own tab', detail: 'On its own (not linked to this page’s PC app)', run: () => window.open(urlFor('phone'), '_blank') },
    { label: '🎬 Move lab', detail: 'Every move’s animation, to try and tune (opens in a new tab)', run: () => window.open(urlFor('lab'), '_blank') },
    '-', canWrite ? { label: fileState.on ? `💾 Saving into ${fileState.handle?.name} ✓` : '💾 Save into this file…', detail: fileState.on ? `Last saved ${fileState.at ? new Date(fileState.at).toLocaleTimeString() : 'soon'}${fileState.error ? ` · problem: ${fileState.error}` : ''}. Click to pick another file.` : 'Pick this page’s file once: everything is then saved inside it as you go, so it travels with the file', run: chooseFile } : null,
    { label: '⬇️ Download a copy with everything inside', detail: 'A new copy of this page carrying all your trainers, pictures and sounds (works in any browser)', run: downloadWithData },
    { label: 'ℹ️ About this copy', detail: 'What’s kept in this browser, backups, what a web page can’t do', run: about },
    { foot: `Capsule Link ${BUILD.version} · web copy` },
  ]);
  ready.then(() => { if (lsGet('clweb:phoneOpen', false)) togglePhone(true); });
  window.__clWeb = { store, get hub() { return hub; }, about, togglePhone, get petFrame() { return petFrame; } };
}
