// The look shared by every activity and training drill (see activityGames.js, trainingGames.js).
// ---------- drawing helpers ----------
// One look for every activity: chunky outlined lettering, glossy bevelled panels with a soft drop shadow, a ribbon
// across the top for instructions, banners that pop in, and meters with glowing markers.
const FONT = '"Segoe UI Variable Display", "Segoe UI", system-ui, sans-serif';
export function text(ctx, s, x, y, { size = 18, color = '#fff', align = 'center', weight = 800 } = {}) {
  ctx.save();
  ctx.font = `${weight} ${size}px ${FONT}`; ctx.textAlign = align; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  ctx.lineWidth = Math.max(3, size * 0.22); ctx.strokeStyle = 'rgba(12,10,36,.92)'; ctx.strokeText(s, x, y + size * 0.06);
  const g = ctx.createLinearGradient(0, y - size * 0.5, 0, y + size * 0.5); g.addColorStop(0, '#ffffff'); g.addColorStop(0.45, color); g.addColorStop(1, shadeHex(color, -0.18));
  ctx.fillStyle = g; ctx.fillText(s, x, y);
  ctx.restore();
}
export function shadeHex(c, k) {
  const m = /^#([0-9a-f]{6})$/i.exec(c); if (!m) return c;
  const n = parseInt(m[1], 16), f = (v) => Math.max(0, Math.min(255, Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k)));
  return `rgb(${f(n >> 16)},${f((n >> 8) & 255)},${f(n & 255)})`;
}
export function rr(ctx, x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
export function panel(ctx, x, y, w, h, { fill = null, stroke = 'rgba(125,255,207,.7)', r = 12 } = {}) {
  ctx.save();
  rr(ctx, x + 1, y + 4, w, h, r); ctx.fillStyle = 'rgba(0,0,0,.32)'; ctx.fill(); // drop shadow
  rr(ctx, x, y, w, h, r);
  if (fill) ctx.fillStyle = fill; else { const g = ctx.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, 'rgba(46,44,96,.94)'); g.addColorStop(1, 'rgba(14,12,38,.94)'); ctx.fillStyle = g; }
  ctx.fill();
  ctx.lineWidth = 2; ctx.strokeStyle = stroke; ctx.stroke();
  rr(ctx, x + 3, y + 3, w - 6, Math.min(h - 6, Math.max(6, h * 0.42)), Math.max(2, r - 3)); ctx.fillStyle = 'rgba(255,255,255,.08)'; ctx.fill(); // gloss
  ctx.restore();
}
/** The instructions, on a ribbon across the top; long ones shrink to fit narrow (phone) screens. */
export function hint(ctx, W, s) {
  ctx.save(); ctx.font = `700 15px ${FONT}`;
  const w = ctx.measureText(s).width; ctx.restore();
  const size = w > W - 40 ? Math.max(9, Math.floor(15 * (W - 40) / w)) : 15;
  const bw = Math.min(W - 12, Math.max(220, (w * size) / 15 + 48));
  ctx.save();
  const g = ctx.createLinearGradient(0, 6, 0, 38); g.addColorStop(0, 'rgba(255,255,255,.18)'); g.addColorStop(0.5, 'rgba(26,24,64,.88)'); g.addColorStop(1, 'rgba(12,10,36,.92)');
  rr(ctx, W / 2 - bw / 2, 6, bw, 32, 16); ctx.fillStyle = g; ctx.fill(); ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(125,255,207,.55)'; ctx.stroke();
  ctx.restore();
  text(ctx, s, W / 2, 22, { size, weight: 700, color: '#e9fff8' });
}
export function banner(ctx, W, H, s, t) {
  if (t <= 0 || !s) return;
  // pops in big and settles, then fades out
  const k = Math.min(1, t * 2), pop = 1 + Math.max(0, 0.25 - (1.2 - Math.min(1.2, t)) * 1.2) * 0;
  ctx.save(); ctx.globalAlpha = k;
  ctx.translate(W / 2, H * 0.32); ctx.scale(pop, pop);
  const bw = Math.min(W - 20, 40 + s.length * 22);
  const g = ctx.createLinearGradient(-bw / 2, 0, bw / 2, 0); g.addColorStop(0, 'rgba(255,214,90,0)'); g.addColorStop(0.2, 'rgba(255,214,90,.25)'); g.addColorStop(0.8, 'rgba(255,214,90,.25)'); g.addColorStop(1, 'rgba(255,214,90,0)');
  ctx.fillStyle = g; ctx.fillRect(-bw / 2, -26, bw, 52);
  ctx.restore();
  ctx.save(); ctx.globalAlpha = k; text(ctx, s, W / 2, H * 0.32, { size: Math.min(40, (W - 30) / Math.max(4, s.length) * 1.7), color: '#ffd84a', weight: 900 }); ctx.restore();
}
/** A thought bubble above someone's head (b: their screen box), drawing `inside(cx, cy)` in it. */
export function thought(ctx, b, w, h, inside) {
  if (!b) return;
  const cx = Math.max(w / 2 + 6, (b.x0 + b.x1) / 2 + 30), cy = Math.max(h / 2 + 34, b.y0 - h / 2 - 22);
  ctx.save();
  ctx.fillStyle = 'rgba(0,0,0,.18)'; rr(ctx, cx - w / 2 + 2, cy - h / 2 + 4, w, h, h / 2); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,.97)'; ctx.strokeStyle = '#2a2448'; ctx.lineWidth = 2.5;
  for (const [dx, dy, r] of [[-22, h / 2 + 12, 4], [-14, h / 2 + 4, 6]]) { ctx.beginPath(); ctx.arc(cx + dx, cy + dy, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); }
  rr(ctx, cx - w / 2, cy - h / 2, w, h, h / 2); ctx.fill(); ctx.stroke();
  ctx.restore();
  inside(cx, cy);
}
/** A moving marker on a bar with a target zone. Returns the bar's box. */
export function slider(ctx, x, y, w, pos, center, zone, { h = 20 } = {}) {
  panel(ctx, x - 8, y - 8, w + 16, h + 16, { r: 10 });
  ctx.save();
  rr(ctx, x, y, w, h, h / 2); ctx.clip();
  const tr = ctx.createLinearGradient(0, y, 0, y + h); tr.addColorStop(0, '#2a2650'); tr.addColorStop(1, '#16142e'); ctx.fillStyle = tr; ctx.fillRect(x, y, w, h);
  const zx = x + (center - zone / 2) * w, zw = zone * w;
  const zg = ctx.createLinearGradient(0, y, 0, y + h); zg.addColorStop(0, '#6fe39a'); zg.addColorStop(1, '#2f9a58'); ctx.fillStyle = zg; ctx.fillRect(zx, y, zw, h);
  const pg = ctx.createLinearGradient(0, y, 0, y + h); pg.addColorStop(0, '#e6ffd8'); pg.addColorStop(1, '#9ff0b8'); ctx.fillStyle = pg; ctx.fillRect(x + (center - zone / 6) * w, y, (zone / 3) * w, h);
  ctx.fillStyle = 'rgba(255,255,255,.14)'; ctx.fillRect(x, y, w, h * 0.4);
  ctx.fillStyle = 'rgba(255,255,255,.18)'; for (let i = 1; i < 10; i++) ctx.fillRect(x + (w * i) / 10, y + h * 0.6, 1, h * 0.4);
  ctx.restore();
  // the marker: a bright needle with a glow and a pointer on top
  const mx = x + pos * w;
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; const gl = ctx.createRadialGradient(mx, y + h / 2, 0, mx, y + h / 2, h * 1.4); gl.addColorStop(0, 'rgba(255,255,255,.5)'); gl.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = gl; ctx.fillRect(mx - h * 1.4, y - h, h * 2.8, h * 3); ctx.restore();
  ctx.fillStyle = '#ffffff'; ctx.fillRect(mx - 2.5, y - 6, 5, h + 12);
  ctx.beginPath(); ctx.moveTo(mx - 8, y - 14); ctx.lineTo(mx + 8, y - 14); ctx.lineTo(mx, y - 5); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#1a1838'; ctx.lineWidth = 1.5; ctx.stroke();
}
// the frame round every activity: a soft vignette, the title card sweeping in at the start, and a result stamp
let vigCv = null;
export function frameFx(ctx, W, H, { title, t, end, perf }) {
  if (!vigCv || vigCv.width !== W || vigCv.height !== H) {
    vigCv = document.createElement('canvas'); vigCv.width = W; vigCv.height = H; const v = vigCv.getContext('2d');
    const g = v.createRadialGradient(W / 2, H * 0.55, Math.min(W, H) * 0.35, W / 2, H * 0.55, Math.hypot(W, H) * 0.62); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(6,4,24,.42)');
    v.fillStyle = g; v.fillRect(0, 0, W, H);
  }
  ctx.drawImage(vigCv, 0, 0);
  if (t < 1.9 && title) { // title card: a band sweeps across with the activity's name, then slides away
    const inK = Math.min(1, t / 0.25), outK = t > 1.5 ? (t - 1.5) / 0.4 : 0, a = inK * (1 - outK);
    ctx.save(); ctx.globalAlpha = a;
    const by = H * 0.44, bh = Math.min(84, H * 0.16), sweep = (1 - inK) * -W + outK * W;
    ctx.translate(sweep, 0);
    const g = ctx.createLinearGradient(0, by - bh / 2, 0, by + bh / 2); g.addColorStop(0, 'rgba(255,214,90,.95)'); g.addColorStop(0.08, 'rgba(30,26,74,.92)'); g.addColorStop(0.92, 'rgba(14,12,40,.92)'); g.addColorStop(1, 'rgba(255,214,90,.95)');
    ctx.fillStyle = g; ctx.fillRect(0, by - bh / 2, W, bh);
    // a light glint running along it
    const gx = ((t * 1.4) % 1.4) * W; const lg = ctx.createLinearGradient(gx - 80, 0, gx + 80, 0); lg.addColorStop(0, 'rgba(255,255,255,0)'); lg.addColorStop(0.5, 'rgba(255,255,255,.22)'); lg.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = lg; ctx.fillRect(0, by - bh / 2, W, bh);
    ctx.restore();
    ctx.save(); ctx.globalAlpha = a; ctx.translate(sweep, 0); text(ctx, title.toUpperCase(), W / 2, by, { size: Math.min(44, bh * 0.52, (W - 40) / Math.max(5, title.length) * 1.6), color: '#ffe680', weight: 900 }); ctx.restore();
  }
  if (end > 0) { // how it went: a stamp that thumps down, with stars
    const word = perf >= 0.9 ? 'PERFECT!' : perf >= 0.7 ? 'GREAT!' : perf >= 0.45 ? 'GOOD!' : perf > 0.15 ? 'NICE TRY' : 'TOUGH ONE';
    const stars = perf >= 0.9 ? 3 : perf >= 0.6 ? 2 : perf >= 0.3 ? 1 : 0;
    const k = Math.min(1, end / 0.22), sc = 1 + (1 - k) * 1.4;
    ctx.save(); ctx.fillStyle = `rgba(6,4,24,${0.45 * k})`; ctx.fillRect(0, 0, W, H); ctx.restore();
    ctx.save(); ctx.globalAlpha = k; ctx.translate(W / 2, H * 0.42); ctx.scale(sc, sc); ctx.rotate(-0.06);
    text(ctx, word, 0, 0, { size: Math.min(64, (W - 40) / 6), color: perf >= 0.7 ? '#ffd84a' : '#bfe8ff', weight: 900 });
    ctx.restore();
    for (let i = 0; i < 3; i++) {
      const sk = Math.max(0, Math.min(1, (end - 0.3 - i * 0.18) / 0.2)); if (sk <= 0) continue;
      const sx = W / 2 + (i - 1) * 54, sy = H * 0.42 + 64, r = 20 * (1 + (1 - sk) * 0.8);
      ctx.save(); ctx.globalAlpha = sk; ctx.translate(sx, sy);
      ctx.beginPath(); for (let j = 0; j < 10; j++) { const ang = -Math.PI / 2 + j * Math.PI / 5, rad = j % 2 ? r * 0.45 : r; ctx.lineTo(Math.cos(ang) * rad, Math.sin(ang) * rad); } ctx.closePath();
      ctx.fillStyle = i < stars ? '#ffd84a' : 'rgba(255,255,255,.18)'; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = '#1a1838'; ctx.stroke();
      ctx.restore();
    }
  }
}
