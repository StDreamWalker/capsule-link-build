// The place dropper: a world map (OpenStreetMap's tiles) to drop a pin on, for anyone who'd rather not share
// their location. Drag to move, + and − (or the mouse wheel, or two fingers) to zoom, tap to drop the pin.
// Where it lands is named (country, region, continent, or the ocean) by BigDataCloud's free lookup, and only
// that rounded spot is kept. Resolves to { lat, lon, label, country, continent, ocean } or null.
import { h } from './dom.js';

const TILE = 256;
const tileUrl = (z, x, y) => `https://tile.openstreetmap.org/${z}/${x}/${y}.png`;
const lonToX = (lon, z) => ((lon + 180) / 360) * TILE * 2 ** z;
const latToY = (lat, z) => { const r = (Math.max(-85, Math.min(85, lat)) * Math.PI) / 180; return ((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2) * TILE * 2 ** z; };
const xToLon = (x, z) => (x / (TILE * 2 ** z)) * 360 - 180;
const yToLat = (y, z) => { const n = Math.PI - (2 * Math.PI * y) / (TILE * 2 ** z); return (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))); };

/** What's at a spot: country, region, continent, or the ocean. getJson(url) → parsed JSON. */
export async function nameSpot(lat, lon, getJson) {
  const j = await getJson(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat.toFixed(3)}&longitude=${lon.toFixed(3)}&localityLanguage=en`);
  const info = [...(j?.localityInfo?.informative ?? []), ...(j?.localityInfo?.administrative ?? [])];
  const ocean = info.find((x) => /ocean|sea\b|gulf|bay\b/i.test(x.name ?? ''))?.name ?? null;
  const continent = j?.continent || info.find((x) => /continent/i.test(x.description ?? ''))?.name || null;
  const country = j?.countryName || null;
  const local = j?.city || j?.locality || null;
  const label = country ? [local, j?.principalSubdivision, country].filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(', ') : ocean || continent || 'Open water';
  return { country, continent, ocean: country ? null : ocean ?? 'Open water', region: j?.principalSubdivision || null, label };
}

export function dropPlace({ getJson, start = null, dialog }) {
  return new Promise((resolve) => {
    let z = start ? 5 : 2, cx = lonToX(start?.lon ?? 10, z), cy = latToY(start?.lat ?? 25, z), pin = start ? { lat: start.lat, lon: start.lon } : null;
    const view = h('div', { class: 'pd-view', tabindex: '0', 'aria-label': 'World map. Drag to move, tap to drop a pin.' });
    const tiles = h('div', { class: 'pd-tiles' });
    const pinEl = h('div', { class: 'pd-pin', 'aria-hidden': 'true' });
    const label = h('p', { class: 'pd-label' }, pin ? 'Your pin' : 'Tap the map where you are.');
    view.append(tiles, pinEl, h('span', { class: 'pd-attr' }, '© OpenStreetMap contributors'));
    let named = null;
    const paint = () => {
      const W = view.clientWidth || 340, H = view.clientHeight || 300, n = 2 ** z;
      const x0 = cx - W / 2, y0 = cy - H / 2;
      const kids = [];
      for (let ty = Math.floor(y0 / TILE); ty <= Math.floor((y0 + H) / TILE); ty++) {
        if (ty < 0 || ty >= n) continue;
        for (let tx = Math.floor(x0 / TILE); tx <= Math.floor((x0 + W) / TILE); tx++) {
          const wx = ((tx % n) + n) % n;
          const img = new Image(); img.src = tileUrl(z, wx, ty); img.alt = ''; img.draggable = false;
          img.style.left = `${tx * TILE - x0}px`; img.style.top = `${ty * TILE - y0}px`;
          kids.push(img);
        }
      }
      tiles.replaceChildren(...kids);
      if (pin) { pinEl.style.display = 'block'; pinEl.style.left = `${lonToX(pin.lon, z) - x0}px`; pinEl.style.top = `${latToY(pin.lat, z) - y0}px`; } else pinEl.style.display = 'none';
    };
    const zoom = (dz, ax = null, ay = null) => {
      const nz = Math.max(1, Math.min(12, z + dz)); if (nz === z) return;
      const W = view.clientWidth, H = view.clientHeight, px = ax ?? W / 2, py = ay ?? H / 2;
      const lon = xToLon(cx - W / 2 + px, z), lat = yToLat(cy - H / 2 + py, z);
      z = nz; cx = lonToX(lon, z) - px + W / 2; cy = latToY(lat, z) - py + H / 2; paint();
    };
    // drag to move; a tap (no real movement) drops the pin
    let drag = null; const pts = new Map(); let pinch = null;
    view.addEventListener('pointerdown', (e) => { view.setPointerCapture(e.pointerId); pts.set(e.pointerId, { x: e.clientX, y: e.clientY }); if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = Math.hypot(a.x - b.x, a.y - b.y); drag = null; } else drag = { x: e.clientX, y: e.clientY, cx, cy, moved: false }; });
    view.addEventListener('pointermove', (e) => {
      if (!pts.has(e.pointerId)) return; pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pinch && pts.size === 2) { const [a, b] = [...pts.values()], d = Math.hypot(a.x - b.x, a.y - b.y); if (d / pinch > 1.35) { zoom(1); pinch = d; } else if (d / pinch < 0.74) { zoom(-1); pinch = d; } return; }
      if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; if (Math.hypot(dx, dy) > 6) drag.moved = true; cx = drag.cx - dx; cy = Math.max(0, Math.min(TILE * 2 ** z, drag.cy - dy)); paint();
    });
    const up = async (e) => {
      pts.delete(e.pointerId); if (pts.size < 2) pinch = null;
      if (!drag || drag.moved) { drag = null; return; }
      drag = null;
      const r = view.getBoundingClientRect(), W = view.clientWidth, H = view.clientHeight;
      pin = { lat: yToLat(cy - H / 2 + (e.clientY - r.top), z), lon: ((xToLon(cx - W / 2 + (e.clientX - r.left), z) + 540) % 360) - 180 };
      paint(); named = null; label.textContent = 'Looking that up…'; useBtn.disabled = true;
      try { named = await nameSpot(pin.lat, pin.lon, getJson); label.textContent = `📍 ${named.label}${named.continent && named.country ? ` · ${named.continent}` : ''}`; }
      catch { named = { label: `${pin.lat.toFixed(1)}°, ${pin.lon.toFixed(1)}°`, country: null, continent: null, ocean: null }; label.textContent = `📍 ${named.label} (couldn’t name it offline)`; }
      useBtn.disabled = false;
    };
    view.addEventListener('pointerup', up); view.addEventListener('pointercancel', (e) => { pts.delete(e.pointerId); drag = null; });
    view.addEventListener('wheel', (e) => { e.preventDefault(); const r = view.getBoundingClientRect(); zoom(e.deltaY < 0 ? 1 : -1, e.clientX - r.left, e.clientY - r.top); }, { passive: false });
    view.addEventListener('keydown', (e) => { const s = 80; if (e.key === 'ArrowLeft') cx -= s; else if (e.key === 'ArrowRight') cx += s; else if (e.key === 'ArrowUp') cy -= s; else if (e.key === 'ArrowDown') cy += s; else if (e.key === '+' || e.key === '=') zoom(1); else if (e.key === '-') zoom(-1); else return; e.preventDefault(); paint(); });
    const useBtn = h('button', { class: 'btn primary', disabled: !pin }, 'Use this spot');
    dialog('Drop a pin where you are', (close) => {
      useBtn.onclick = () => close(pin ? { lat: Math.round(pin.lat * 10) / 10, lon: Math.round(pin.lon * 10) / 10, ...(named ?? { label: start?.label ?? 'Your pin' }) } : null);
      requestAnimationFrame(paint);
      return h('div', { class: 'col pd' },
        h('div', { class: 'pd-wrap' }, view, h('div', { class: 'pd-zoom' }, h('button', { class: 'btn small', 'aria-label': 'Zoom in', onclick: () => zoom(1) }, '+'), h('button', { class: 'btn small', 'aria-label': 'Zoom out', onclick: () => zoom(-1) }, '−'))),
        label,
        h('p', { class: 'micro dim' }, 'Anywhere works: a country, a continent, or out at sea. Only the rough spot (about 10 km) is kept.'),
        h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(null) }, 'Cancel'), useBtn));
    }, { wide: true }).then((v) => resolve(v ?? null));
  });
}
