// Menu entries for evolving / Mega Evolving / changing form (R.A.N.C.H. right-click, the boxes summary).
// Only what a creature could do is listed; what it can't do yet is greyed out and says why on hover.
import { h, dialog, toast } from './dom.js';
import { spriteCanvas } from './art.js';
import { sfx, creatureCry } from './audio.js';
import { changeOptions, applyChange, displayName, speciesOf } from '../engine/index.js';

/** Buttons for a menu. item(label, fn, cls) is the menu's own button maker (so it closes the menu). */
export function changeItems(app, c, item, onDone) {
  const opts = changeOptions(app.idx, app.save, c);
  return opts.map((o) => {
    const b = item(o.ok ? `${o.kind === 'evolve' ? '✨ ' : o.kind === 'mega' ? '💠 ' : ''}${o.label}` : o.label, () => (o.ok ? runChange(app, c.uid, o.key).then(onDone) : toast(o.why, 'err')));
    // greyed out (still hoverable, so the reason shows; clicking it says why too)
    if (!o.ok) { b.setAttribute('aria-disabled', 'true'); b.classList.add('qm-off'); }
    if (o.why) b.title = o.why;
    return b;
  });
}

/** Do it, with a little ceremony for evolution and Mega Evolution. */
export async function runChange(app, uid, key) {
  const c = app.save.creatures[uid];
  const opt = changeOptions(app.idx, app.save, c).find((o) => o.key === key);
  if (!opt) return null;
  if (!opt.ok) { toast(opt.why, 'err'); return null; }
  const name = displayName(app.idx, c);
  if (opt.kind === 'evolve') {
    const target = app.idx.species.get(opt.to);
    const yes = await dialog(`${name} is changing!`, (close) => h('div', { class: 'col' },
      h('div', { class: 'evolve-stage' }, spriteCanvas(app.bank, c, { scale: 4, animate: true })),
      h('p', null, `Let ${name} evolve into ${target?.name}?${opt.why ? ` ${opt.why}` : ''}`),
      h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(false) }, 'Not yet'), h('button', { class: 'btn primary', onclick: () => close(true) }, 'Evolve'))));
    if (!yes) return null;
  }
  let r;
  app.commit((s) => { r = applyChange(app.idx, s, uid, key); }, 'evolve');
  if (!r?.ok) { toast(r?.reason ?? 'That didn’t work.', 'err'); return null; }
  const after = app.save.creatures[uid];
  sfx(opt.kind === 'evolve' ? 'level' : 'warp');
  try { creatureCry(speciesOf(app.idx, after), after); } catch { /* no voice */ }
  if (opt.kind === 'evolve') {
    await dialog('Congratulations!', (close) => h('div', { class: 'col' },
      h('div', { class: 'evolve-stage' }, spriteCanvas(app.bank, after, { scale: 4, animate: true, anim: 'happy' })),
      h('p', null, r.text),
      h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: () => close() }, 'Great'))));
  } else toast(r.text, 'ok');
  return r;
}
