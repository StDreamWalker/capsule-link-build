// Talking to creatures in a yard (the R.A.N.C.H., Quality time): press T, type, Enter. Only the creatures
// you name answer (or everyone listening, if you don't name anyone). They answer like on the phone: a
// picture in a thought bubble over their head, their cry (or a word they know, cut from it), and a line
// at the bottom that fades. What you typed isn't shown over them.
import { h, toast, confirmDialog } from './dom.js';
import { runChange } from './changeUi.js';
import { itemIcon } from './itemIcon.js';
import { spriteCanvas } from './art.js';
import { creatureCry, sfx } from './audio.js';
import { displayName, speciesOf, itemInfo, wordLabel, mood, topPrefs, inviteOf, directInvite, isAsleep, INVITES, makeEvent } from '../engine/index.js';
const REQUESTY = /\?|\b(let'?s|wanna|want to|who|anyone|any ?body|everyone|fancy|up for|come (on|with)|shall we|how about)\b/i;
import { warmLlm, llmStatus, llmReact, onLlmStatus, retryLlm, llmIntent } from './localLlm.js';
import { POWERS, powerOf } from '../engine/powers.js';
const ASKS_DO = /\b(can you|could you|would you|will you|please|show (me|us)|let'?s see|use|try|make|do (a|some|your|that|the)|go on|time to)\b|!\s*$|^\s*[a-z][\w' -]{1,20}\s*,/i;

/** How they react, in the on-device language model's words (or the rules' own line until it's ready). */
export function reactLine(app, uid, text, out) {
  const c = app.save.creatures[uid];
  if (!c || !out?.note || out.learned || llmStatus().state !== 'ready') return Promise.resolve(out?.note ?? null);
  let likes = ''; try { likes = topPrefs(c, app.idx, 2).map((p) => p.label).join(' and '); } catch { /* fine */ }
  return llmReact(text, { name: displayName(app.idx, c), species: speciesOf(app.idx, c)?.name, mood: mood(c)?.label?.toLowerCase(), likes, rule: out.note }).then((l) => {
    if (!l) return out.note;
    // the picture follows what they actually made of it: no berry in the bubble unless food came into it
    if (out.bubble?.kind === 'item' && !FOODISH.test(l) && !FOODISH.test(text)) out.bubble = { kind: 'emoji', e: MOOD_ICON[out.mood] ?? '😊' };
    out.llm = true;
    return l;
  }).catch(() => out.note);
}
const FOODISH = /\b(food|berr(y|ies)|snack|eat|ate|hungry|treat|lunch|dinner|breakfast|lick|munch|tast|yum|delicious|cook|feed)/i;

/** A little chip saying how well they understand you: the on-device model loading, ready, or not available. */
export function llmChip() {
  const el = h('span', { class: 'llm-chip', role: 'status' });
  let seen = false, off = null;
  const draw = (st) => {
    if (el.isConnected) seen = true; else if (seen) { off?.(); return; } // (gone from the page: stop listening)
    el.className = `llm-chip ${st.state}`;
    if (st.state === 'ready') { el.textContent = '🧠 Understands you'; el.title = 'The on-device language model is running: they take in what you actually say.'; }
    else if (st.state === 'loading') { el.textContent = `🧠 Learning to understand… ${Math.round((st.progress ?? 0) * 100)}%`; el.title = 'Downloading the on-device language model (about 120 MB, once). Until then they go by key words.'; }
    else if (st.state === 'failed') { el.replaceChildren('🧠 Key words only · ', h('button', { class: 'linkish', onclick: () => { retryLlm(); } }, 'retry')); el.title = `The language model couldn't load here (${st.error ?? 'unknown'}). They still go by key words.`; }
    else { el.textContent = '🧠 Key words only (offline)'; el.title = 'Connect to the internet once to download the language model.'; }
  };
  draw(llmStatus());
  off = onLlmStatus(draw);
  return el;
}

const MOOD_ICON = { happy: '😊', meh: '😕', sleepy: '💤', worried: '🥺', curious: '❔', content: '🙂', hungry: '🍽️' };

/** A canvas picture for a reply's bubble. */
export function bubblePic(app, out) {
  const b = out?.bubble;
  try {
    if (b?.kind === 'item') return itemIcon(itemInfo(app.idx, b.id) ?? { id: b.id, name: b.id, kind: 'food' }, 32, { idx: app.idx });
    if (b?.kind === 'creature' && app.bank) return spriteCanvas(app.bank, b.speciesId, { scale: 1 });
  } catch { /* fall back to an emoji */ }
  const e = b?.e ?? MOOD_ICON[out?.mood] ?? '❔';
  const cv = document.createElement('canvas'); cv.width = 48; cv.height = 48;
  const x = cv.getContext('2d');
  x.font = '36px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText([...e].slice(0, 2).join(''), 24, 27);
  return cv;
}

/**
 * The talk bar. opts: { app, host (element to put it in), yard, listeners: () => [uid], ask(uid, text, group) → outcome,
 *   onReply(uid, out) }. Returns { open, close, toggle, isOpen, el }.
 */
export function talkOverlay({ app, host, yard, listeners, ask, onReply = null, pick = null, inline = false, invite = null, onEvolve = null }) {
  const input = h('input', { type: 'text', class: 'talk-input', maxLength: 200, placeholder: 'Say something… (name someone to talk to just them)' });
  const lines = h('div', { class: 'yard-talk-lines', 'aria-live': 'polite' });
  const el = h('form', { class: 'yard-talk-bar', onsubmit: (e) => { e.preventDefault(); send(input.value); input.value = ''; } },
    h('span', { class: 'yard-talk-key' }, 'T'),
    input,
    h('button', { class: 'btn primary small', type: 'submit' }, 'Say'),
    h('button', { class: 'btn small', type: 'button', title: 'Close (Esc)', onclick: () => close() }, '✕'),
    llmChip());
  let open = false;
  if (inline) { const w0 = listeners(); if (w0.length === 1) input.placeholder = `Say something to ${displayName(app.idx, app.save.creatures[w0[0]])}… (try “come here”, “take a nap”, “what do you want to do?”)`; el.classList.add('inline'); el.querySelector('button[title^="Close"]')?.remove(); host.append(el); open = true; }
  input.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); } e.stopPropagation(); });
  host.append(lines);
  function show() {
    if (!open) { host.append(el); open = true; }
    warmLlm();
    const who = listeners();
    input.placeholder = who.length === 1 ? `Say something to ${displayName(app.idx, app.save.creatures[who[0]])}…` : 'Say something… (name someone to talk to just them)';
    setTimeout(() => input.focus(), 0);
  }
  function close() { if (inline) { input.blur(); return; } if (open) { el.remove(); open = false; } }
  const fade = (node, ms) => { lines.append(node); setTimeout(() => node.classList.add('out'), ms); setTimeout(() => node.remove(), ms + 900); };
  async function send(text) {
    text = String(text || '').trim();
    if (!text) return;
    const all = listeners();
    // "who wants to …?": asked of the group; the ones who'd like to step forward (the scene handles it). When
    // the rules can't tell what it's for, the language model (if it's running) is asked to place it.
    if (invite && all.length) {
      let inv = inviteOf(text) ?? directInvite(text);
      if ((!inv || inv.id === 'any') && llmStatus().state === 'ready' && REQUESTY.test(text)) {
        for (const u of all.slice(0, 6)) { try { yard?.think(u, '…', 8); } catch { /* fine */ } }
        const id = await llmIntent(text, INVITES.map((i) => ({ id: i.id, label: i.label })));
        if (id) inv = INVITES.find((i) => i.id === id);
      }
      if (inv) {
        // named someone (“Munna, help the others sleep”, “Cogsy and Mindle, race to the tree”)? then just them
        const named = pick ? pick(all, text) : all, pool = named.length && named.length < all.length ? named : all;
        sfx('blip'); lines.replaceChildren(); if (invite(pool.filter((u) => !isAsleep(app.save.creatures[u]) || inv.id === 'nap'), inv, text) !== false) return;
      }
    }
    const who = pick ? pick(all, text) : all;
    if (!who.length) { toast('Nobody here to hear you.', 'err'); return; }
    // asking them to do something the rules can't place (“could you make it feel like a sauna in here?”): the
    // language model (if it's running) picks which of their moves or powers it means
    let heard = text;
    if (llmStatus().state === 'ready' && ASKS_DO.test(text) && !powerOf(text, app.idx) && who.length <= 3) {
      for (const u of who) { try { yard?.think(u, '…', 8); } catch { /* fine */ } }
      const pid = await llmIntent(text, POWERS.map((p) => ({ id: p.id, label: p.label })), { kind: 'power' }).catch(() => null);
      if (pid) heard = `${text} [power:${pid}]`;
    }
    sfx('blip');
    lines.replaceChildren();
    const replies = [];
    for (const uid of who.slice(0, 8)) {
      const out = ask(uid, heard, who.length > 1);
      if (out) replies.push([uid, out]);
    }
    // (the first few put into the language model's words, while they get ready to answer)
    // while they think it over (in the background), “…” over the head of each one who heard
    const thinking = llmStatus().state === 'ready';
    if (thinking) replies.forEach(([uid], i) => { if (i < 3) try { yard?.think(uid, '…', 20); } catch { /* fine */ } });
    const said = replies.map(([uid, out], i) => (i < 3 ? reactLine(app, uid, text, out) : Promise.resolve(out.note)));
    // one after another, so the cries don't all land at once
    replies.forEach(([uid, out], i) => setTimeout(async () => {
      out = { ...out, note: (await said[i]) ?? out.note };
      const c = app.save.creatures[uid];
      if (!c) return;
      yard?.think(uid, bubblePic(app, out), 4.2);
      if (out.emote === 'hearts') yard?.react(uid, 'hearts', 2);
      else if (out.emote === 'note') yard?.react(uid, 'note', 2);
      if (out.note && (replies.length <= 3 || i < 3)) fade(h('div', { class: 'talk-line' }, out.learned ? `${displayName(app.idx, c)} seems to know what “${wordLabel(app.idx, out.learned)}” means now.` : out.note), 4200);
      try { creatureCry(speciesOf(app.idx, c), c, out.pieces ? { chop: out.pieces } : { talk: true, mood: out.mood === 'happy' ? 'happy' : out.mood === 'sleepy' ? 'sleepy' : undefined }); } catch { /* no sound */ }
      if (out.learned) sfx('level');
      if (out.act?.kind === 'evolveAsk') { // (it wants to evolve: you say yes or no)
        const key = out.act.key;
        if (onEvolve) onEvolve(uid, key);
        else if (app.commit) setTimeout(() => runChange(app, uid, key).catch(() => {}), 700);
        else if (app.record) setTimeout(async () => { const nm = displayName(app.idx, c), to = app.idx.species.get(out.act.to)?.name ?? 'something new'; if (await confirmDialog(`${nm} wants to evolve!`, `Let ${nm} evolve into ${to}?`, { ok: 'Evolve', cancel: 'Not yet' })) { app.record(makeEvent('change', { uid, key })); sfx('level'); toast(`${nm} evolved into ${to}!`, 'ok'); } }, 700);
      }
      else if (out.act && yard?.command) yard.command(uid, out.act);
      onReply?.(uid, out);
    }, 450 + i * 520));
    if (replies.length > 3) setTimeout(() => fade(h('div', { class: 'talk-line dim' }, `…and ${replies.length - 3} more of them reacted.`), 4200), 450 + 3 * 520);
  }
  return { open: show, close, toggle: () => (open ? close() : show()), isOpen: () => open, el, destroy: () => { el.remove(); open = false; lines.remove(); } };
}
