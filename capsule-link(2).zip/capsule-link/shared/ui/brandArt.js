// Interface art that can be replaced by textures: textures/ui/logo.png (the app mark) and
// textures/ui/ball.png (the ball creatures travel in). Both apps point this at their texture list.
import { setItemArt } from './itemIcon.js';
let resolve = () => null;
let keys = () => [];
const imgs = new Map();
const listeners = new Set();

export function setUiArt(fn, list) {
  resolve = typeof fn === 'function' ? fn : () => null;
  keys = typeof list === 'function' ? list : () => [];
  imgs.clear();
  setItemArt(resolve); // downloaded item sprites (items/<id>.png) come from the same textures
  for (const l of listeners) l();
}
export function onUiArt(fn) { listeners.add(fn); return () => listeners.delete(fn); }

/** URL of a replacement ('logo', 'ball', 'ball-open'…) or null. */
export function uiArtUrl(name) {
  try { return resolve(`ui/${name}.png`) ?? null; } catch { return null; }
}

/** Texture paths under a folder, e.g. listArt('trainers/') → ['trainers/ace.png', …]. */
export function listArt(prefix) {
  try { return keys().filter((k) => k.startsWith(prefix)).sort(); } catch { return []; }
}
export function artUrl(path) { try { return resolve(String(path).toLowerCase()) ?? null; } catch { return null; } }

/** A loaded image for canvas drawing, or null while missing or still loading. */
export function uiArtImage(name) { return artImage(`ui/${name}.png`); }
export function artImage(path) {
  const name = String(path).toLowerCase();
  const url = artUrl(name);
  if (!url) return null;
  let rec = imgs.get(name);
  if (!rec || rec.url !== url) {
    const img = new Image();
    rec = { url, img, ok: false };
    img.onload = () => { rec.ok = true; for (const l of listeners) l(); };
    img.src = url;
    imgs.set(name, rec);
  }
  return rec.ok ? rec.img : null;
}

// ---------- ball skins ----------
// Every ball the apps draw can come from textures. One PNG per ball type holds all its poses side
// by side (square frames, in this order); a file for a single pose overrides that frame:
//   ui/ball.png                 the default ball (a strip, or a single picture used for every pose)
//   ui/ball-<pose>.png          one pose of the default ball   (ui/ball-off.png = empty, as before)
//   ui/ball-<type>.png          another ball type, e.g. ui/ball-4.png or ui/ball-great.png
//   ui/ball-<type>-<pose>.png   one pose of that type
// <type> is a creature's ball: the number PKHeX stores, or any name you pick for it in storage.
export const BALL_POSES = ['closed', 'empty', 'open', 'shake1', 'shake2', 'shake3', 'icon'];
const POSE_ALIAS = { off: 'empty', shake: 'shake1' };
const isPose = (s) => BALL_POSES.includes(s) || s in POSE_ALIAS;
const cleanType = (t) => String(t ?? '').toLowerCase().replace(/[^a-z0-9_]+/g, '') || 'default';

/** Ball types that have art: ['default', '4', 'great', …] */
export function ballTypes() {
  const out = new Set();
  for (const k of listArt('ui/ball')) {
    const m = /^ui\/ball(?:-([a-z0-9_]+))?(?:-([a-z0-9_]+))?\.png$/.exec(k);
    if (!m) continue;
    if (!m[1] || (isPose(m[1]) && !m[2])) out.add('default');
    else out.add(m[1]);
  }
  return [...out].sort((a, b) => (a === 'default' ? -1 : b === 'default' ? 1 : a.localeCompare(b, undefined, { numeric: true })));
}

/**
 * The picture for a ball type in a pose: { img, sx, sy, sw, sh, turn } or null (use the built-in
 * drawing). `turn` is set when a shake pose had to be made by tilting the closed picture.
 */
export function ballFrame(type, pose = 'closed') {
  pose = POSE_ALIAS[pose] ?? pose;
  const idx = Math.max(0, BALL_POSES.indexOf(pose));
  const tilt = { shake1: -0.28, shake2: 0, shake3: 0.28 }[pose] ?? 0;
  const t = cleanType(type);
  // (a skin made for this ball type first; then the real ball's sprite once downloaded, which replaces the
  // capsule picture; the capsule picture only when there's no sprite)
  const itemFor = () => { const it = artImage(`items/${BALL_ITEM[t] ?? t.replace(/_/g, '-')}.png`) ?? (BALL_FALLBACK[t] ? artImage(`items/${BALL_ITEM[BALL_FALLBACK[t]]}.png`) : null); return it && pose !== 'open' ? { img: it, sx: 0, sy: 0, sw: it.width, sh: it.height, turn: tilt } : null; };
  for (const k of t === 'default' ? ['item', 'default'] : [t, 'item', 'default']) {
    if (k === 'item') { const it = itemFor(); if (it) return it; continue; }
    const base = k === 'default' ? 'ui/ball' : `ui/ball-${k}`;
    const one = artImage(`${base}-${pose}.png`) ?? (k === 'default' && pose === 'empty' ? artImage('ui/ball-off.png') : null);
    if (one) return { img: one, sx: 0, sy: 0, sw: one.width, sh: one.height, turn: 0 };
    const sheet = artImage(`${base}.png`);
    if (sheet) {
      const frames = sheet.width >= sheet.height * 1.5 ? Math.round(sheet.width / sheet.height) : 1;
      const fw = sheet.width / frames;
      const i = idx < frames ? idx : 0;
      return { img: sheet, sx: i * fw, sy: 0, sw: fw, sh: sheet.height, turn: idx < frames ? 0 : tilt };
    }
  }
  // no ball skin made for it: the ball's own item picture (items/poke-ball.png, items/great-ball.png… from
  // "Download everything"), tilted for the shake poses; the standard ball is the Poké Ball
  return itemFor();
}
// the ball numbers PKHeX stores → their item pictures
export const BALL_ITEM = { 1: 'master-ball', 2: 'ultra-ball', 3: 'great-ball', 4: 'poke-ball', 5: 'safari-ball', 6: 'net-ball', 7: 'dive-ball', 8: 'nest-ball', 9: 'repeat-ball', 10: 'timer-ball', 11: 'luxury-ball', 12: 'premier-ball', 13: 'dusk-ball', 14: 'heal-ball', 15: 'quick-ball', 16: 'cherish-ball', 17: 'fast-ball', 18: 'level-ball', 19: 'lure-ball', 20: 'heavy-ball', 21: 'love-ball', 22: 'friend-ball', 23: 'moon-ball', 24: 'sport-ball', 25: 'dream-ball', 26: 'beast-ball', 27: 'strange-ball', 28: 'hisuian-poke-ball', 29: 'hisuian-great-ball', 30: 'hisuian-ultra-ball', 31: 'feather-ball', 32: 'wing-ball', 33: 'jet-ball', 34: 'hisuian-heavy-ball', 35: 'leaden-ball', 36: 'gigaton-ball', 37: 'origin-ball', nexus: 'poke-ball', default: 'poke-ball', poke: 'poke-ball', great: 'great-ball', ultra: 'ultra-ball', master: 'master-ball' };
export const BALL_NAMES = { 1: 'Master Ball', 2: 'Ultra Ball', 3: 'Great Ball', 4: 'Poké Ball', 5: 'Safari Ball', 6: 'Net Ball', 7: 'Dive Ball', 8: 'Nest Ball', 9: 'Repeat Ball', 10: 'Timer Ball', 11: 'Luxury Ball', 12: 'Premier Ball', 13: 'Dusk Ball', 14: 'Heal Ball', 15: 'Quick Ball', 16: 'Cherish Ball', 17: 'Fast Ball', 18: 'Level Ball', 19: 'Lure Ball', 20: 'Heavy Ball', 21: 'Love Ball', 22: 'Friend Ball', 23: 'Moon Ball', 24: 'Sport Ball', 25: 'Dream Ball', 26: 'Beast Ball', 27: 'Strange Ball', 28: 'Poké Ball (Hisui)', 29: 'Great Ball (Hisui)', 30: 'Ultra Ball (Hisui)', 31: 'Feather Ball', 32: 'Wing Ball', 33: 'Jet Ball', 34: 'Heavy Ball (Hisui)', 35: 'Leaden Ball', 36: 'Gigaton Ball', 37: 'Origin Ball' };
// the Hisuian balls, when their own sprite couldn't be found: the nearest ball of today
export const BALL_FALLBACK = { 28: 4, 29: 3, 30: 2, 31: 15, 32: 15, 33: 17, 34: 20, 35: 20, 36: 20, 37: 1 };

/** Draw a ball picture into a box (keeps its shape). Returns false when there is no art for it. */
export function drawBallArt(ctx, x, y, w, h, type, pose, { glow = null } = {}) {
  const f = ballFrame(type, pose);
  if (!f) return false;
  const k = Math.min(w / f.sw, h / f.sh);
  const dw = f.sw * k, dh = f.sh * k;
  ctx.save();
  if (glow) { ctx.shadowColor = glow; ctx.shadowBlur = Math.max(4, w * 0.15); }
  ctx.imageSmoothingEnabled = f.sw > w;
  ctx.translate(x + w / 2, y + h / 2 + dh / 2);
  if (f.turn) ctx.rotate(f.turn);
  ctx.drawImage(f.img, f.sx, f.sy, f.sw, f.sh, -dw / 2, -dh, dw, dh);
  ctx.restore();
  return true;
}
