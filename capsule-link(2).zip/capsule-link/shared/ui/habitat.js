// Looks, colours and pixel-art props for each biome, shared by the R.A.N.C.H. yard.


// ---------- colour ----------
export const pack = (r, g, b) => (255 << 24) | ((b > 255 ? 255 : b) << 16) | ((g > 255 ? 255 : g) << 8) | (r > 255 ? 255 : r);
export const hexRgb = (h) => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
export const P = (h) => { const [r, g, b] = hexRgb(h); return pack(r, g, b); };
export function mixRgb(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
export const packA = (c) => pack(c[0] | 0, c[1] | 0, c[2] | 0);
export const shadeHex = (h, f) => { const c = hexRgb(h); return `#${c.map((v) => Math.max(0, Math.min(255, Math.round(f < 0 ? v * (1 + f) : v + (255 - v) * f))).toString(16).padStart(2, '0')).join('')}`; };

export function rngFrom(seed) {
  let s = (seed >>> 0) || 1;
  return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
}
export const hash2 = (x, y) => { let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
export function vnoise(x, y) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi), b = hash2(xi + 1, yi), c = hash2(xi, yi + 1), d = hash2(xi + 1, yi + 1);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

// ---------- biome looks ----------
// sky: [zenith, horizon]; sun: [azimuth, elevation, top, bottom] or null; mount: ridge colour;
// ground: palette; cliff: strata; water/lava: animated materials; props: [kind, count]; fx: particles
export const HABITAT_LOOKS = {
  // battle-only places (the wild battle's "Where")
  colosseum: { sky: ['#4f96e0', '#ffe4bc'], sun: [0.7, 0.2, '#fff6c8', '#ffb070'], mount: '#b98c5e', ground: ['#e2c48e', '#d8b880', '#ecd29e', '#ccaa72'], cliff: ['#b49a7a', '#9c8466', '#846e54'], rim: '#fff1d0', grid: '#ffd27a', void: '#1a1008', water: '#3d9be0', decals: [], dots: ['#c9a46a', '#ffffff'], props: [], fx: 'dust' },
  ruins: { sky: ['#5f9cc0', '#e8f0de'], sun: [1.3, 0.14, '#fffbe0', '#ffd27a'], mount: '#6f8a7a', ground: ['#8f9a86', '#7f8a76', '#a0a894', '#6f7a68'], cliff: ['#8c8a80', '#76746c', '#605e58'], rim: '#e8ffd8', grid: '#9dffb8', void: '#0b140f', water: '#3a8ab0', decals: [], dots: ['#ffffff', '#ffd45e'], props: [], fx: 'pollen' },
  stadium: { sky: ['#24356e', '#f2a27a'], sun: [2.6, 0.06, '#ffe0b0', '#ff7a5c'], mount: '#3a3f6a', ground: ['#4e9a54', '#46904c', '#58a85e', '#3f8646'], cliff: ['#6a7088', '#585e74', '#464b5e'], rim: '#ffffff', grid: '#7de8ff', void: '#0b1022', water: '#4a9ad8', decals: [], dots: ['#ffffff'], props: [], fx: 'dust', town: true },
  shrine: { sky: ['#86aee6', '#ffe8f0'], sun: [1.1, 0.16, '#fff8e0', '#ffc0a0'], mount: '#8a9cc8', ground: ['#d6d0c6', '#c8c2b8', '#e0dad0', '#bcb6ac'], cliff: ['#a8a49c', '#949088', '#7e7a72'], rim: '#ffffff', grid: '#ffb6d9', void: '#14101a', water: '#5aa8e0', decals: [], dots: ['#ffb6d9', '#ffffff'], props: [], fx: 'pollen' },
  meadow: { sky: ['#4aa3f0', '#c9f1ff'], sun: [0.9, 0.16, '#fff6a8', '#ff9f5c'], mount: '#5d8fc4', ground: ['#5cbf4a', '#53b343', '#69cc55', '#4aa83d'], cliff: ['#7a5232', '#694529', '#5a3a22'], rim: '#b6ffcf', grid: '#7dffcf', void: '#0b1430', water: '#3d9be0', decals: ['pond'], dots: ['#ffffff', '#ffd45e', '#ff8fb6'], props: [['tree', 4], ['bush', 5], ['flower', 14], ['tuft', 16], ['rock', 3]], fx: 'pollen' },
  forest: { sky: ['#1f5e5a', '#a7d9b8'], sun: [2.2, 0.1, '#fff1c0', '#ffb36a'], mount: '#1d4a3c', ground: ['#3b8a3a', '#327a33', '#2f6e2f', '#45973f'], cliff: ['#5e3d24', '#4f321d', '#3f2716'], rim: '#9dffb8', grid: '#5effa0', void: '#06140f', water: '#2f7fa8', decals: ['pond'], dots: ['#c9a05a', '#e2d27a', '#7a4a2a'], props: [['pine', 7], ['tree', 4], ['mushroom', 6], ['log', 2], ['tuft', 12], ['bush', 4]], fx: 'firefly' },
  shoreline: { sky: ['#3fb3ff', '#e3f8ff'], sun: [0.4, 0.22, '#fffbe0', '#ffd27a'], mount: '#7fb7d9', ground: ['#f1d99a', '#e8cf8c', '#f6e2ac', '#e2c682'], cliff: ['#c99f62', '#b48a50', '#9c7540'], rim: '#ffffff', grid: '#7de8ff', void: '#071a2e', water: '#2fa6e8', decals: ['sea'], dots: ['#ffffff', '#ffb6c9', '#c9a46a'], props: [['palm', 4], ['rock', 3], ['shell', 8], ['tuft', 4]], fx: 'spray' },
  volcano: { sky: ['#2a0f1f', '#c4422c'], sun: [3.6, 0.08, '#ffd45e', '#ff3d2e'], mount: '#3a1418', ground: ['#3b3036', '#463940', '#2f262b', '#51424a'], cliff: ['#2a2024', '#221a1d', '#1a1316'], rim: '#ff8a3d', grid: '#ff5d3d', void: '#140508', lava: true, decals: ['lava'], dots: ['#ff6a3d', '#7a6a70'], props: [['lavarock', 6], ['rock', 5], ['spire', 3]], fx: 'ember' },
  cavern: { sky: ['#07060f', '#231d38'], sun: null, cave: true, mount: '#151225', ground: ['#5a5470', '#4e4863', '#655e7c', '#47415a'], cliff: ['#3a3550', '#302b44', '#262236'], rim: '#b49bff', grid: '#9b7dff', void: '#05040c', water: '#3a6bd0', decals: ['pond'], dots: ['#8a83a8', '#3a3550'], props: [['stalagmite', 7], ['glowshroom', 6], ['rock', 6], ['mushroom', 2]], fx: 'dust' },
  tundra: { sky: ['#8fb9e8', '#eef6ff'], sun: [1.6, 0.12, '#ffffff', '#cfe6ff'], mount: '#b9d2ef', ground: ['#eef5ff', '#e2ecf9', '#f7fbff', '#d6e3f4'], cliff: ['#9fb6d4', '#8aa2c2', '#738bab'], rim: '#ffffff', grid: '#a8e6ff', void: '#0b1630', water: '#8fd3ff', ice: true, decals: ['ice'], dots: ['#c3d6ee', '#ffffff'], props: [['snowpine', 6], ['icespike', 4], ['rock', 3], ['snowman', 1]], fx: 'snow' },
  desert: { sky: ['#f59a4a', '#ffe7b0'], sun: [0.2, 0.2, '#fff2b0', '#ff7a3a'], mount: '#d98a52', ground: ['#efc27a', '#e6b56a', '#f4cd8a', '#ddaa5e'], cliff: ['#c98a4a', '#b5773a', '#9e652e'], rim: '#fff0c8', grid: '#ffd27a', void: '#2a1408', water: '#4ac0d0', decals: ['oasis'], dots: ['#d39a52', '#fff0c8'], props: [['cactus', 6], ['rock', 4], ['bones', 2], ['tuft', 3]], fx: 'sand' },
  // the mountaintop: a high alpine meadow above an ocean of forest canopy (id kept as "skyline" for old saves)
  skyline: { sky: ['#2f78d8', '#d8efff'], sun: [2.8, 0.18, '#fffbe0', '#ffd27a'], mount: '#8aa0c4', ground: ['#86a864', '#7a9c58', '#93b470', '#6f9050'], cliff: ['#9a98a6', '#84828f', '#6c6a78'], rim: '#ffffff', grid: '#a8e6ff', void: '#0b1630', water: '#6ac0f0', decals: ['pond'], dots: ['#ffffff', '#c8b6ff', '#ffe27a'], props: [['rock', 7], ['pine', 3], ['tuft', 14], ['flower', 8]], fx: 'feather' },
  outskirts: { sky: ['#5b8fd9', '#ffdcb8'], sun: [1.2, 0.2, '#fff4d0', '#ffb070'], mount: '#7a8cb0', ground: ['#6aa84f', '#5e9a45', '#77b45a', '#548c3d'], cliff: ['#8a8a96', '#74747f', '#5e5e68'], rim: '#ffffff', grid: '#7dffcf', void: '#0b1430', water: '#4a9ad8', decals: ['pond'], dots: ['#ffffff', '#ffd45e'], props: [['tree', 6], ['lamppost', 4], ['bench', 3], ['bush', 6], ['flower', 10], ['tuft', 12]], fx: 'pollen', town: true },
  spooky: { sky: ['#0d0820', '#45305e'], sun: null, moon: true, night: true, mount: '#1d1530', ground: ['#3a4a3a', '#334233', '#405040', '#2c3a2c'], cliff: ['#3a3440', '#2e2a34', '#231f28'], rim: '#c6a8ff', grid: '#9b7dff', void: '#06030c', water: '#2e3c5a', decals: ['bog'], dots: ['#6a5a7a', '#8a7aa0'], props: [['deadtree', 5], ['grave', 6], ['pumpkin', 3], ['mushroom', 3], ['tuft', 8]], fx: 'wisp', fog: true },
  prism: { sky: ['#ff9ad5', '#a6f6ff'], sun: null, mount: '#c8a0ff', ground: ['#fdf0ff', '#f0e6ff', '#e6f7ff', '#fff6e0'], cliff: ['#c8b8ff', '#b0a0f0', '#9888e0'], rim: '#ffffff', grid: '#ff7de8', void: '#2a1a4a', water: '#7dd6ff', decals: [], dots: ['#ff7ac8', '#7ad6ff', '#ffe27a'], props: [['cube', 4], ['orb', 4], ['pyramid', 3], ['ring', 2]], fx: 'sparkle', checker: true },
  synth: { sky: ['#0a0220', '#ff3d9a'], sun: [2.2, 0.22, '#ffe27a', '#ff3d9a'], striped: true, night: true, mount: '#2a0a4a', ground: ['#1a0a3a', '#160832', '#200c44', '#12062a'], cliff: ['#3a1a6a', '#2a1050', '#1a0838'], rim: '#ff7de8', grid: '#ff3dd0', void: '#05010f', glowgrid: true, decals: [], dots: ['#ff7de8', '#7de8ff'], props: [['monolith', 3], ['orb', 3], ['pyramid', 3]], fx: 'sparkle' },
  seafloor: { sky: ['#06244a', '#1f7fb0'], sun: null, underwater: true, mount: '#0b3a62', ground: ['#d9c79a', '#cdb98a', '#e3d3a8', '#c2ae80'], cliff: ['#8c7a58', '#7a6a4c', '#665840'], rim: '#7de8ff', grid: '#3dd6ff', void: '#020d1c', water: '#2a7fb8', decals: [], caustics: true, dots: ['#ff8fb6', '#ffffff', '#b8a070'], props: [['kelp', 7], ['coral', 6], ['rock', 3], ['shell', 6]], fx: 'bubble' },
  marsh: { sky: ['#4a6b5a', '#c6d8b0'], sun: [4.2, 0.07, '#f4f0c0', '#d0b070'], mount: '#3a5a48', ground: ['#5f7a3a', '#536c33', '#6b8642', '#4a612e'], cliff: ['#4a3a24', '#3d2f1d', '#302416'], rim: '#d8ffb0', grid: '#b0ff7d', void: '#0a140a', water: '#4d7a6a', decals: ['bog'], dots: ['#8aa05a', '#c9d78a'], props: [['reed', 10], ['lily', 6], ['log', 2], ['mushroom', 3], ['tuft', 8]], fx: 'firefly' },
  starfield: { sky: ['#05030f', '#2a1650'], sun: null, night: true, nebula: true, mount: '#1a1036', ground: ['#2a1f4a', '#241a40', '#30245a', '#1f1738'], cliff: ['#1a1230', '#150f28', '#100b20'], rim: '#c89bff', grid: '#c89bff', void: '#030110', glowlines: true, decals: [], dots: ['#ffffff', '#c89bff', '#7db8ff'], props: [['crystal', 6], ['pillar', 3], ['star', 4]], fx: 'sparkle' },
  crystal: { sky: ['#140a2a', '#4a2a7a'], sun: null, cave: true, mount: '#2a1650', ground: ['#6a4fa0', '#5d4590', '#7a5cb4', '#523d80'], cliff: ['#3d2a66', '#33235a', '#2a1c4a'], rim: '#ff9aff', grid: '#ff7de8', void: '#08031a', glowlines: true, decals: [], dots: ['#e0c8ff', '#ff9aff'], props: [['crystal', 10], ['stalagmite', 3], ['glowshroom', 3]], fx: 'sparkle' },
};
export const habitatLook = (biome) => HABITAT_LOOKS[biome] ?? HABITAT_LOOKS.meadow;

// ---------- props: little pixel-art billboards ----------
export function canvasOf(w, h, draw) { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); draw((px, py, pw, ph, col) => { x.fillStyle = col; x.fillRect(px, py, pw, ph); }, x); return c; }
export function blob(f, cx, cy, rx, ry, col, edge) {
  for (let y = -ry; y <= ry; y++) for (let x = -rx; x <= rx; x++) {
    const d = (x * x) / (rx * rx) + (y * y) / (ry * ry);
    if (d <= 1) f(cx + x, cy + y, 1, 1, edge && d > 0.72 ? edge : col);
  }
}
export const PROPS = {
  tree: (r, L) => canvasOf(26, 34, (f) => { f(11, 20, 4, 14, '#6b4423'); f(12, 20, 1, 14, '#875a30'); const g = L.ground[3] ?? '#3f8a3a'; blob(f, 13, 12, 12, 10, shadeHex(g, -0.15), shadeHex(g, -0.4)); blob(f, 10, 9, 6, 5, shadeHex(g, 0.05)); f(8, 7, 2, 1, shadeHex(g, 0.35)); if (r() < 0.4) for (let i = 0; i < 4; i++) f(4 + Math.floor(r() * 18), 6 + Math.floor(r() * 12), 2, 2, '#ff6a6a'); }),
  pine: (r, L) => canvasOf(20, 36, (f) => { f(9, 28, 3, 8, '#5a3a20'); const g = '#24603a'; for (let k = 0; k < 4; k++) { const y = 3 + k * 7, w = 3 + k * 2.2; for (let yy = 0; yy < 9; yy++) { const ww = Math.round(w * (yy / 9) + 1); f(10 - ww, y + yy, ww * 2, 1, yy === 8 ? '#1a4a2c' : g); } f(10 - 1, y, 2, 1, '#3d8a52'); } }),
  snowpine: (r) => canvasOf(20, 36, (f) => { f(9, 28, 3, 8, '#5a3a20'); for (let k = 0; k < 4; k++) { const y = 3 + k * 7, w = 3 + k * 2.2; for (let yy = 0; yy < 9; yy++) { const ww = Math.round(w * (yy / 9) + 1); f(10 - ww, y + yy, ww * 2, 1, yy < 3 ? '#ffffff' : yy === 8 ? '#1f5040' : '#2e6a54'); } } }),
  palm: (r) => canvasOf(30, 40, (f) => { for (let y = 12; y < 40; y++) { const x = 14 + Math.round(Math.sin(y / 9) * 2); f(x, y, 3, 1, y % 4 === 0 ? '#8a6234' : '#a87a42'); } const leaf = (dx, dy) => { for (let i = 0; i < 12; i++) f(15 + Math.round(dx * i), 11 + Math.round(dy * i + i * i * 0.05), 2, 2, i > 8 ? '#2f8a3a' : '#3fae4a'); }; leaf(1, -0.2); leaf(-1, -0.2); leaf(0.8, 0.3); leaf(-0.8, 0.3); leaf(0.3, -0.7); f(13, 12, 4, 3, '#6b4423'); }),
  bush: (r, L) => canvasOf(18, 12, (f) => { const g = L.ground[2] ?? '#5cbf4a'; blob(f, 9, 7, 8, 5, shadeHex(g, -0.2), shadeHex(g, -0.45)); f(5, 4, 2, 1, shadeHex(g, 0.3)); if (r() < 0.5) { f(4, 6, 1, 1, '#ff8fb6'); f(12, 5, 1, 1, '#ff8fb6'); } }),
  flower: (r, L) => canvasOf(8, 7, (f) => { const c = L.dots[Math.floor(r() * L.dots.length)]; for (const [x, y] of [[1, 2], [5, 1], [3, 3]]) { f(x, y + 2, 1, 2, '#2f7a2f'); f(x - 1, y, 3, 1, c); f(x, y - 1, 1, 3, c); f(x, y, 1, 1, '#ffd45e'); } }),
  tuft: (r, L) => canvasOf(8, 6, (f) => { const g = shadeHex(L.ground[1] ?? '#4fae40', -0.15); for (const x of [1, 3, 4, 6]) f(x, 1 + (x % 2), 1, 5 - (x % 2), g); }),
  rock: (r, L) => canvasOf(16, 11, (f) => { const c = L.cliff[0]; blob(f, 8, 7, 7, 4, shadeHex(c, 0.15), shadeHex(c, -0.3)); f(5, 4, 3, 1, shadeHex(c, 0.45)); }),
  mushroom: (r) => canvasOf(12, 12, (f) => { f(5, 6, 2, 6, '#f0e2c8'); blob(f, 6, 5, 5, 3, '#e5484d', '#9a2a2e'); f(3, 3, 1, 1, '#ffffff'); f(7, 4, 1, 1, '#ffffff'); }),
  glowshroom: (r) => canvasOf(12, 14, (f) => { f(5, 7, 2, 7, '#d8e8ff'); blob(f, 6, 6, 5, 3, '#4ad0ff', '#1a7ab8'); f(4, 4, 2, 1, '#c8f6ff'); }),
  log: (r) => canvasOf(24, 9, (f) => { f(1, 2, 21, 6, '#7a4a28'); f(1, 2, 21, 1, '#9a6234'); f(1, 7, 21, 1, '#5a3418'); blob(f, 21, 5, 2, 3, '#c89a6a', '#7a4a28'); f(21, 5, 1, 1, '#9a6a3a'); f(6, 1, 3, 1, '#4f9a3f'); }),
  shell: (r) => canvasOf(7, 5, (f) => { blob(f, 3, 3, 3, 2, r() < 0.5 ? '#ffd0dc' : '#fff0d0', '#c98a8a'); f(3, 1, 1, 3, '#c98a8a'); }),
  lavarock: (r) => canvasOf(16, 13, (f) => { blob(f, 8, 8, 7, 5, '#2a2024', '#120c0e'); f(4, 7, 3, 1, '#ff6a2a'); f(7, 8, 1, 3, '#ffb23d'); f(10, 6, 2, 1, '#ff6a2a'); f(5, 5, 2, 1, '#4a3a40'); }),
  spire: (r) => canvasOf(14, 30, (f) => { for (let y = 0; y < 30; y++) { const w = Math.round(1 + y / 5); f(7 - w, y, w * 2, 1, y % 6 === 0 ? '#1a1316' : '#2f262b'); } f(6, 12, 1, 6, '#ff6a2a'); }),
  stalagmite: (r, L) => canvasOf(12, 24, (f) => { const c = L.cliff[0]; for (let y = 0; y < 24; y++) { const w = Math.max(1, Math.round(y / 4)); f(6 - w, y, w * 2, 1, y % 5 === 0 ? shadeHex(c, -0.25) : shadeHex(c, 0.1)); } f(5, 6, 1, 8, shadeHex(c, 0.4)); }),
  crystal: (r, L) => canvasOf(16, 24, (f) => { const hues = ['#ff9aff', '#9ad9ff', '#c89bff', '#7dffcf']; const c = hues[Math.floor(r() * hues.length)]; const shard = (x, h, w) => { for (let y = 0; y < h; y++) { const ww = y < w ? y + 1 : w; f(x - Math.floor(ww / 2), 24 - h + y, ww, 1, y < 2 ? '#ffffff' : c); } f(x, 24 - h + 2, 1, h - 3, shadeHex(c, 0.5)); }; shard(8, 22, 4); shard(4, 12, 3); shard(12, 15, 3); }),
  icespike: (r) => canvasOf(12, 22, (f) => { for (let y = 0; y < 22; y++) { const w = Math.max(1, Math.round(y / 4)); f(6 - w, y, w * 2, 1, '#bfe8ff'); f(6 - w, y, 1, 1, '#ffffff'); } }),
  snowman: (r) => canvasOf(14, 22, (f) => { blob(f, 7, 16, 6, 5, '#ffffff', '#cfe0f4'); blob(f, 7, 7, 4, 4, '#ffffff', '#cfe0f4'); f(5, 6, 1, 1, '#1b1838'); f(8, 6, 1, 1, '#1b1838'); f(6, 8, 3, 1, '#ff8a3d'); f(3, 11, 8, 2, '#e5484d'); f(4, 1, 6, 3, '#1b1838'); f(3, 3, 8, 1, '#1b1838'); }),
  cactus: (r) => canvasOf(16, 26, (f) => { const g = '#3f9a4a', d = '#2a6a32'; f(6, 2, 4, 24, g); f(6, 2, 1, 24, '#5cbf5a'); f(9, 2, 1, 24, d); f(1, 9, 3, 2, g); f(1, 5, 2, 6, g); f(12, 12, 3, 2, g); f(13, 7, 2, 7, g); f(7, 1, 2, 1, '#ff8fb6'); }),
  bones: (r) => canvasOf(16, 8, (f) => { f(2, 4, 10, 2, '#f4ecd6'); f(1, 3, 2, 4, '#f4ecd6'); f(11, 3, 2, 4, '#f4ecd6'); blob(f, 13, 3, 3, 2, '#f4ecd6', '#c9b890'); }),
  cloud: (r) => canvasOf(30, 14, (f) => { blob(f, 10, 9, 8, 5, '#ffffff', '#e6dcff'); blob(f, 19, 7, 9, 6, '#ffffff', '#e6dcff'); blob(f, 15, 10, 10, 4, '#ffffff'); f(12, 4, 4, 1, '#ffffff'); }),
  pillar: (r, L) => canvasOf(14, 34, (f) => { const c = L.cliff[0]; f(2, 0, 10, 4, shadeHex(c, 0.3)); f(3, 4, 8, 26, shadeHex(c, 0.15)); for (let x = 4; x < 11; x += 2) f(x, 5, 1, 24, shadeHex(c, -0.15)); f(2, 30, 10, 4, shadeHex(c, 0.3)); if (r() < 0.6) f(3, 12 + Math.floor(r() * 10), 8, 3, shadeHex(c, -0.4)); }),
  star: (r) => canvasOf(12, 18, (f) => { f(5, 6, 2, 12, '#7a5cb4'); const c = '#ffe27a'; f(5, 0, 2, 7, c); f(2, 3, 8, 2, c); f(3, 2, 6, 4, c); f(5, 2, 2, 2, '#ffffff'); }),
  kelp: (r) => canvasOf(10, 30, (f) => { for (let y = 0; y < 30; y++) { const x = 4 + Math.round(Math.sin(y / 4 + r() * 0.2) * 2); f(x, y, 2, 1, '#2f8a4a'); if (y % 5 === 2) f(x + 2, y, 2, 2, '#3fae5a'); } }),
  coral: (r) => canvasOf(18, 16, (f) => { const c = ['#ff7a9a', '#ffb23d', '#c89bff'][Math.floor(r() * 3)]; const br = (x, h) => { f(x, 16 - h, 2, h, c); f(x - 2, 16 - h, 2, 2, c); f(x + 2, 16 - h + 2, 2, 2, c); }; br(4, 10); br(9, 14); br(14, 9); }),
  reed: (r) => canvasOf(10, 22, (f) => { for (const [x, h] of [[2, 18], [5, 22], [7, 15]]) { f(x, 22 - h, 1, h, '#6b8a3a'); f(x, 22 - h, 1, 4, '#7a4a28'); } }),
  lily: (r) => canvasOf(12, 6, (f) => { blob(f, 6, 3, 5, 2, '#4fae40', '#2f7a2f'); f(6, 2, 2, 1, '#ff8fb6'); }),
  // (painted at high detail in paint.js; these small ones are only a fallback)
  lamppost: () => canvasOf(8, 30, (f) => { f(3, 4, 2, 26, '#4a5068'); f(2, 2, 5, 3, '#fff3c4'); }),
  bench: () => canvasOf(24, 10, (f) => { f(1, 2, 22, 2, '#a0683a'); f(1, 5, 22, 2, '#8a5a30'); f(3, 7, 2, 3, '#3a3f52'); f(19, 7, 2, 3, '#3a3f52'); }),
  beacon: () => canvasOf(12, 30, (f) => { f(4, 8, 4, 20, '#2a2850'); f(5, 8, 1, 20, '#4a4680'); f(2, 26, 8, 4, '#1b1838'); f(3, 4, 6, 5, '#7dffcf'); f(4, 5, 4, 3, '#ffffff'); f(5, 0, 2, 4, '#7dffcf'); }),
};
export const FLOATS = new Set(['cloud', 'star']);
export const AQUATIC = new Set(['lily']);

