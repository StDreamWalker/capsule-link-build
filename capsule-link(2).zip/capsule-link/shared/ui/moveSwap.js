// Swapping one of a creature's moves for another it could use: one it knew before, one its kind learns by its
// level, or a TM in your bag. Used from the Box summary (click a move) — Battle Link has the full editor.
import { h, dialog, toast } from './dom.js';
import { moveChoices, setMoves, displayName } from '../engine/index.js';
import { sfx } from './audio.js';

const WHY = { known: 'Knows it', past: 'Learned before', level: 'Learns by its level', tm: 'TM in your bag' };
export async function openMoveSwap(app, c, slot) {
  const name = displayName(app.idx, c), cur = c.moves?.[slot]?.id ?? null;
  const all = moveChoices(app.idx, app.save, c).filter((m) => m.why !== 'known' || m.id === cur);
  const known = new Set((c.moves ?? []).map((m) => m.id));
  const opts = all.filter((m) => !known.has(m.id));
  let q = '';
  const listEl = h('div', { class: 'col', style: { gap: '4px', maxHeight: '52vh', overflow: 'auto' } });
  const pick = await dialog(cur ? `Swap ${app.idx.moves.get(cur)?.name ?? 'move'}` : `Teach ${name} a move`, (close) => {
    const draw = () => {
      const groups = ['past', 'level', 'tm'].map((g) => [g, opts.filter((m) => m.why === g && (!q || m.name.toLowerCase().includes(q)))]).filter(([, l]) => l.length);
      listEl.replaceChildren(...(groups.length ? groups.flatMap(([g, l]) => [h('div', { class: 'btn-group-head' }, `${WHY[g]} · ${l.length}`), ...l.map((m) => {
        const mv = app.idx.moves.get(m.id), ty = app.idx.types.get(mv?.type);
        return h('button', { class: 'btn choose-row', style: { justifyContent: 'flex-start', borderLeft: `4px solid ${ty?.color ?? '#888'}` }, onclick: () => close(m.id) },
          h('span', { class: 'grow', style: { textAlign: 'left' } }, m.name, m.level ? h('span', { class: 'micro dim' }, `  Lv. ${m.level}`) : null),
          h('span', { class: 'micro dim' }, `${ty?.name ?? ''} · ${mv?.category === 'status' ? 'status' : `${mv?.power || '—'} pow`} · PP ${mv?.pp ?? '?'}`));
      })]) : [h('p', { class: 'dim' }, q ? 'No move by that name.' : `${name} doesn’t have any other moves to pick from yet. Level it up, or buy a TM at the Market.`)]));
    };
    draw();
    return h('div', { class: 'col', style: { gap: '8px', minWidth: 'min(420px, 86vw)' } },
      h('input', { type: 'search', placeholder: 'Type a move…', oninput: (e) => { q = e.target.value.trim().toLowerCase(); draw(); } }),
      listEl,
      h('div', { class: 'actions' }, cur && (c.moves?.length ?? 0) > 1 ? h('button', { class: 'btn', onclick: () => close('__forget') }, 'Forget this move') : null, h('button', { class: 'btn', onclick: () => close(null) }, 'Cancel')));
  });
  if (!pick) return false;
  const ids = (c.moves ?? []).map((m) => m.id);
  if (pick === '__forget') ids.splice(slot, 1); else if (slot < ids.length) ids[slot] = pick; else ids.push(pick);
  let r; app.commit((s) => { r = setMoves(app.idx, s, c.uid, ids); }, 'moves');
  if (!r?.ok) { toast(r?.reason ?? 'Couldn’t change that.', 'err'); return false; }
  sfx('heal'); toast(pick === '__forget' ? `${name} forgot it (it can relearn it later).` : `${name} learned ${app.idx.moves.get(pick)?.name ?? 'it'}!`, 'ok');
  return true;
}
