// The little things on the ground of a battle place, so it feels lived-in: grass tufts and wild flowers in
// meadows and forests, fallen leaves and twigs, mushrooms, pebbles and stones, shells and seaweed on the beach,
// snow clumps and ice, embers glowing in the cracks of a volcano, glowing crystals and mushrooms in caves,
// rubble and moss in the ruins, petals on the shrine's gravel, glass glints on the prism plaza and lit studs on
// the neon grid. Hundreds of small, cheap shapes drawn in the scene's depth order (so a creature stands
// among them), swaying in the wind, never on the two battle spots.
//
//   buildScatter({ biome, arena, L, seed, ok(x, z) }) → { items: [...], lights: [...] }
//   drawScatter(ctx, yard, g, q)                     one of them (q = its base, projected)

import { hexRgb, mixRgb, rngFrom } from './habitat.js';

const rgb = (c) => (Array.isArray(c) ? c : hexRgb(c));
const css = (c, a = 1) => (a >= 1 ? `rgb(${c[0] | 0},${c[1] | 0},${c[2] | 0})` : `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`);

// what each place has on its ground: [kind, share, size, colours…]
function recipe(biome, arena, L) {
  const g = (L?.ground ?? ['#5cbf4a', '#4aa83d']).map(rgb);
  const dark = mixRgb(g[0], [10, 30, 10], 0.35), light = mixRgb(g[2] ?? g[0], [255, 255, 200], 0.25);
  const grass = (n = 1) => [['grass', 40 * n, 0.26, dark, light], ['grass', 14 * n, 0.4, mixRgb(dark, [0, 0, 0], 0.15), g[0]]];
  const flowers = (cols, n = 1) => cols.map((c) => ['flower', (10 / cols.length) * n, 0.22, dark, rgb(c)]);
  const stones = (col = [130, 124, 116], n = 1) => [['pebble', 14 * n, 0.07, rgb(col), mixRgb(rgb(col), [255, 255, 255], 0.35)], ['stone', 4 * n, 0.16, mixRgb(rgb(col), [0, 0, 0], 0.15), mixRgb(rgb(col), [255, 255, 255], 0.25)]];
  if (arena === 'colosseum') return { n: 360, list: [...stones([196, 168, 120], 2), ['pebble', 10, 0.05, [170, 140, 96], [230, 210, 170]], ['rubble', 4, 0.14, [176, 160, 132], [214, 200, 172]]] };
  if (arena === 'ruins') return { n: 520, list: [...stones([150, 146, 134], 1.5), ['rubble', 14, 0.18, [140, 136, 124], [190, 186, 172]], ['grass', 20, 0.22, [70, 110, 50], [130, 170, 80]], ['moss', 12, 0.2, [80, 128, 58], [120, 170, 80]], ['flower', 3, 0.18, [70, 110, 50], [255, 230, 120]]] };
  if (arena === 'shrine') return { n: 480, list: [['petal', 34, 0.06, [255, 176, 206], [255, 222, 236]], ...stones([170, 164, 154], 1.4), ['moss', 6, 0.2, [96, 130, 70], [140, 170, 96]], ['leaf', 6, 0.08, [200, 120, 60], [240, 170, 90]]] };
  if (arena === 'prism') return { n: 260, list: [['shard', 30, 0.1, [200, 230, 255], [255, 255, 255]], ['shard', 12, 0.08, [255, 200, 240], [255, 255, 255]], ['pebble', 8, 0.05, [230, 220, 255], [255, 255, 255]]] };
  if (arena === 'neon') return { n: 300, list: [['stud', 24, 0.07, [255, 61, 208], [255, 200, 240]], ['stud', 24, 0.07, [61, 232, 255], [200, 250, 255]], ['cable', 6, 0.5, [40, 20, 70], [255, 61, 208]], ['pebble', 6, 0.05, [40, 26, 70], [90, 70, 130]]] };
  if (arena === 'stadium') return { n: 120, list: [['grass', 30, 0.12, [50, 120, 56], [96, 170, 96]], ['pebble', 6, 0.04, [120, 120, 130], [200, 200, 210]]] };
  if (arena) return { n: 0, list: [] };
  switch (biome) {
    case 'meadow': return { n: 1100, list: [...grass(1.3), ...flowers(['#ffffff', '#ffd45e', '#ff8fb6', '#b48cff', '#ff6a5a']), ['clover', 8, 0.12, mixRgb(dark, [0, 40, 0], 0.2), g[1] ?? g[0]], ...stones([150, 146, 140], 0.6)] };
    case 'forest': return { n: 1100, list: [...grass(1), ['leaf', 18, 0.09, [176, 110, 50], [220, 160, 80]], ['leaf', 8, 0.09, [120, 140, 50], [170, 190, 80]], ['twig', 7, 0.35, [96, 64, 36], [140, 100, 60]], ['shroom', 5, 0.14, [230, 230, 220], [210, 70, 60]], ['shroom', 3, 0.12, [230, 230, 220], [200, 160, 100]], ['fern', 8, 0.35, [40, 100, 40], [90, 160, 70]], ...stones([120, 116, 104], 0.6)] };
    case 'spooky': return { n: 900, list: [['grass', 30, 0.26, [46, 60, 50], [80, 100, 80]], ['leaf', 22, 0.09, [110, 70, 50], [150, 100, 70]], ['twig', 10, 0.4, [60, 46, 40], [90, 70, 60]], ['shroom', 6, 0.12, [200, 200, 210], [120, 220, 160], 'glow'], ...stones([90, 90, 100], 0.6)] };
    case 'marsh': return { n: 1000, list: [...grass(1.2), ['reed', 14, 0.6, [80, 110, 50], [150, 170, 90]], ['clover', 8, 0.12, [60, 110, 50], [110, 160, 80]], ['flower', 4, 0.2, dark, [255, 255, 255]], ...stones([110, 110, 96], 0.5)] };
    case 'outskirts': return { n: 700, list: [...grass(1), ...flowers(['#ffffff', '#ffd45e', '#ff8fb6']), ['leaf', 4, 0.08, [190, 140, 70], [230, 180, 100]], ...stones([150, 150, 150], 0.5)] };
    case 'skyline': return { n: 1000, list: [['grass', 40, 0.22, [70, 120, 60], [140, 180, 100]], ...flowers(['#ffffff', '#b48cff', '#ffd45e'], 1.2), ...stones([160, 160, 168], 1.4)] };
    case 'shoreline': return { n: 700, list: [['shell', 12, 0.1, [255, 220, 210], [255, 250, 245]], ['shell', 6, 0.09, [250, 190, 150], [255, 236, 210]], ['seaweed', 8, 0.35, [60, 110, 70], [110, 160, 100]], ['starfish', 3, 0.12, [255, 120, 80], [255, 190, 140]], ...stones([196, 180, 150], 1.4), ['grass', 6, 0.3, [150, 160, 90], [210, 210, 140]]] };
    case 'desert': return { n: 700, list: [...stones([200, 160, 110], 2), ['grass', 10, 0.24, [170, 150, 90], [220, 200, 130]], ['twig', 6, 0.3, [150, 120, 80], [200, 170, 120]], ['bone', 2, 0.18, [236, 226, 206], [255, 250, 240]]] };
    case 'tundra': return { n: 800, list: [['snow', 24, 0.16, [236, 244, 255], [255, 255, 255]], ['ice', 10, 0.14, [170, 220, 255], [240, 252, 255]], ['grass', 10, 0.22, [140, 160, 150], [200, 220, 215]], ...stones([150, 160, 176], 1)] };
    case 'volcano': return { n: 700, list: [...stones([70, 60, 66], 2), ['ember', 12, 0.18, [255, 90, 30], [255, 210, 110], 'glow'], ['obsidian', 8, 0.14, [24, 18, 26], [90, 80, 110]], ['ash', 8, 0.18, [90, 84, 88], [130, 124, 128]]] };
    case 'cavern': return { n: 700, list: [...stones([100, 94, 120], 2.4), ['stub', 6, 0.3, [80, 74, 100], [130, 124, 150]], ['shroom', 6, 0.12, [140, 220, 255], [70, 190, 255], 'glow'], ['crystal', 3, 0.22, [150, 110, 230], [220, 200, 255], 'glow']] };
    case 'crystal': return { n: 700, list: [...stones([96, 86, 120], 1.6), ['crystal', 14, 0.24, [150, 110, 230], [230, 210, 255], 'glow'], ['crystal', 8, 0.2, [90, 160, 230], [210, 240, 255], 'glow'], ['shard', 10, 0.08, [200, 180, 255], [255, 255, 255]]] };
    case 'seafloor': return { n: 800, list: [['seaweed', 24, 0.5, [40, 120, 90], [90, 180, 130]], ['coral', 10, 0.25, [255, 120, 150], [255, 190, 200]], ['coral', 6, 0.22, [255, 170, 80], [255, 220, 150]], ['shell', 8, 0.1, [240, 220, 210], [255, 255, 250]], ...stones([120, 140, 150], 1)] };
    case 'starfield': return { n: 400, list: [['stud', 20, 0.06, [200, 210, 255], [255, 255, 255]], ['shard', 12, 0.08, [180, 160, 255], [255, 255, 255]], ...stones([80, 80, 110], 1)] };
    default: return { n: 800, list: [...grass(1), ...stones()] };
  }
}

/**
 * Lay out the little things. ok(x, z) → false where nothing may go (water, a wall…).
 * Returns { items, lights } (lights: the glowing ones that light their surroundings).
 */
export function buildScatter({ biome, arena = null, L = null, seed = 1, ok = () => true, spots = [], center = [0, 5], radius = 30 }) {
  const R = recipe(biome, arena, L);
  const items = [], lights = [];
  if (!R.n) return { items, lights };
  const total = R.list.reduce((s, e) => s + e[1], 0);
  const r = rngFrom(seed * 977 + 31);
  const pick = () => { let t = r() * total; for (const e of R.list) { t -= e[1]; if (t <= 0) return e; } return R.list[0]; };
  for (let i = 0, tries = 0; i < R.n && tries < R.n * 4; tries++) {
    // denser near the field (where the camera looks), thinning out with distance; clumped like real growth
    const a = r() * Math.PI * 2, d = 1.5 + Math.pow(r(), 0.75) * radius;
    let x = center[0] + Math.cos(a) * d * 1.12, z = center[1] + Math.sin(a) * d * 0.95;
    const e = pick();
    if (items.length && r() < 0.35 && ['grass', 'flower', 'clover', 'pebble', 'petal', 'leaf', 'snow', 'stud', 'moss'].includes(e[0])) { const o = items[Math.floor(r() * items.length)]; x = o.x + (r() - 0.5) * 0.9; z = o.z + (r() - 0.5) * 0.7; }
    if (spots.some(([sx, sz]) => Math.hypot((x - sx) / 1.25, (z - sz) / 0.85) < 1)) continue;
    if (!ok(x, z)) continue;
    const s = e[2] * (0.7 + r() * 0.6);
    const g = { x, z, k: e[0], s, c1: e[3], c2: e[4], glow: e[5] === 'glow', ph: r() * 6.283, rot: r() * 6.283, v: [r(), r(), r(), r(), r(), r()] };
    items.push(g);
    if (g.glow && lights.length < 14 && r() < 0.5) lights.push({ x, y: s * 0.6, z, r: g.k === 'ember' ? 2.4 : 1.8, c: g.c2, i: g.k === 'ember' ? 0.9 : 0.7, flicker: g.k === 'ember' ? 3 : 1, glow: true });
    i++;
  }
  return { items, lights };
}

/** Draw one (q: where its base is on screen, from yard.project). */
export function drawScatter(ctx, yard, g, q) {
  const px = q.k * g.s; // its size on screen
  if (px < 1.1 || q.z < 2.4) return; // too small to see, or right against the camera
  const t = yard.time ?? 0, lw = Math.max(1, Math.round(q.k * 0.03));
  const wind = Math.sin(t * 1.7 + g.ph + g.x * 0.4) * 0.22 + Math.sin(t * 4.1 + g.ph * 2) * 0.05;
  ctx.lineCap = 'butt';
  switch (g.k) {
    case 'grass': case 'reed': case 'seaweed': case 'fern': {
      const n = g.k === 'reed' ? 3 : g.k === 'fern' ? 6 : g.k === 'seaweed' ? 3 : 4 + Math.floor(g.v[0] * 3);
      const sway = g.k === 'seaweed' ? wind * 2.4 : wind;
      // each blade a thin tapering leaf (wider at its root), bending in the wind; darker ones behind, lit ones in front
      const bw = Math.max(1, px * (g.k === 'reed' ? 0.07 : 0.055));
      for (const pass of [0, 1]) {
        ctx.fillStyle = css(pass ? g.c2 : g.c1);
        ctx.beginPath();
        for (let b = pass; b < n; b += pass ? 2 : 1) {
          const off = ((b + 0.5) / n - 0.5) * px * 0.9, hgt = px * (0.6 + g.v[(b + 1) % 6] * 0.6) * (g.k === 'fern' ? 0.8 : 1);
          const lean = (off / Math.max(1, px)) * 0.8 + sway, x0 = q.x + off, tipX = x0 + lean * hgt + (g.k === 'seaweed' ? Math.sin(t * 2 + b) * px * 0.15 : 0), tipY = q.y - hgt;
          const midX = x0 + lean * hgt * (g.k === 'seaweed' ? 0.8 : 0.35), midY = q.y - hgt * 0.5;
          ctx.moveTo(x0 - bw, q.y);
          ctx.quadraticCurveTo(midX - bw * 0.6, midY, tipX, tipY);
          ctx.quadraticCurveTo(midX + bw * 0.6, midY, x0 + bw, q.y);
          ctx.closePath();
        }
        ctx.fill();
      }
      if (g.k === 'reed') { ctx.fillStyle = css([120, 80, 40]); const hgt = px * 1.1; ctx.fillRect(Math.round(q.x + wind * hgt - lw), Math.round(q.y - hgt - px * 0.2), lw * 2 + 1, Math.max(2, Math.round(px * 0.28))); }
      break;
    }
    case 'flower': {
      const hgt = px * (0.7 + g.v[1] * 0.5), tx = q.x + wind * hgt, ty = q.y - hgt;
      ctx.strokeStyle = css(g.c1); ctx.lineWidth = lw; ctx.beginPath(); ctx.moveTo(q.x, q.y); ctx.lineTo(tx, ty); ctx.moveTo(q.x, q.y); ctx.lineTo(q.x - px * 0.25, q.y - hgt * 0.4); ctx.stroke();
      const sz = Math.max(2, Math.round(px * 0.28));
      ctx.fillStyle = css(g.c2); ctx.fillRect(Math.round(tx - sz / 2), Math.round(ty - sz / 2), sz, sz);
      if (sz >= 4) { ctx.fillStyle = css([255, 220, 90]); const c = Math.max(1, Math.round(sz / 3)); ctx.fillRect(Math.round(tx - c / 2), Math.round(ty - c / 2), c, c); }
      break;
    }
    case 'clover': case 'moss': case 'ash': {
      const rx = px * 0.9, ry = flatY(yard, g, q, rx);
      ctx.fillStyle = css(g.c1); ctx.beginPath(); ctx.ellipse(q.x, q.y, rx, ry, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = css(g.c2, 0.8);
      for (let k = 0; k < 3; k++) { const a = g.rot + k * 2.1; ctx.beginPath(); ctx.ellipse(q.x + Math.cos(a) * rx * 0.4, q.y + Math.sin(a) * ry * 0.4, rx * 0.35, ry * 0.35, 0, 0, Math.PI * 2); ctx.fill(); }
      break;
    }
    case 'pebble': case 'snow': {
      const rx = Math.max(1, px), ry = flatY(yard, g, q, rx) * (g.k === 'snow' ? 1.3 : 1);
      ctx.fillStyle = css(mixRgb(g.c1, [0, 0, 0], 0.35), 0.5); ctx.beginPath(); ctx.ellipse(q.x + rx * 0.25, q.y + ry * 0.35, rx, ry, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = css(g.c1); ctx.beginPath(); ctx.ellipse(q.x, q.y - ry * 0.3, rx, ry, 0, 0, Math.PI * 2); ctx.fill();
      if (rx >= 2.5) { ctx.fillStyle = css(g.c2); ctx.beginPath(); ctx.ellipse(q.x - rx * 0.3, q.y - ry * 0.6, rx * 0.4, ry * 0.35, 0, 0, Math.PI * 2); ctx.fill(); }
      break;
    }
    case 'stone': case 'rubble': case 'obsidian': case 'stub': case 'ice': {
      const w = px * (g.k === 'stub' ? 0.7 : 1.1), hgt = px * (g.k === 'stub' ? 1.6 : g.k === 'ice' ? 1.1 : 0.75 + g.v[2] * 0.4), v = g.v;
      const pts = g.k === 'stub' ? [[-1, 0], [-0.6, -0.5], [-0.15, -1], [0.3, -0.55], [1, 0]] : [[-1, 0], [-0.85, -0.55 - v[0] * 0.2], [-0.2 - v[1] * 0.2, -1], [0.45, -0.85 - v[2] * 0.15], [1, -0.3 - v[3] * 0.2], [0.9, 0]];
      ctx.fillStyle = css(mixRgb(g.c1, [0, 0, 0], 0.4), 0.45); ctx.beginPath(); ctx.ellipse(q.x + w * 0.2, q.y, w * 1.1, Math.max(1, w * 0.3), 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = css(g.c1, g.k === 'ice' ? 0.85 : 1); ctx.beginPath(); pts.forEach(([a, b], i) => (i ? ctx.lineTo(q.x + a * w, q.y + b * hgt) : ctx.moveTo(q.x + a * w, q.y + b * hgt))); ctx.closePath(); ctx.fill();
      // the lit top-left face
      ctx.fillStyle = css(g.c2, g.k === 'ice' ? 0.9 : 1); ctx.beginPath(); ctx.moveTo(q.x + pts[1][0] * w, q.y + pts[1][1] * hgt); ctx.lineTo(q.x + pts[2][0] * w, q.y + pts[2][1] * hgt); ctx.lineTo(q.x + pts[3][0] * w * 0.6, q.y + pts[3][1] * hgt * 0.75); ctx.lineTo(q.x - w * 0.2, q.y - hgt * 0.35); ctx.closePath(); ctx.fill();
      break;
    }
    case 'leaf': case 'petal': {
      const rx = px * (g.k === 'petal' ? 0.9 : 1), ry = Math.max(1, flatY(yard, g, q, rx) * 0.6);
      ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(g.rot * 0.3 - 0.5); ctx.fillStyle = css(g.c1); ctx.beginPath(); ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2); ctx.fill();
      if (rx > 3) { ctx.strokeStyle = css(g.c2); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-rx, 0); ctx.lineTo(rx, 0); ctx.stroke(); }
      ctx.restore();
      break;
    }
    case 'twig': case 'cable': case 'bone': {
      const a = g.rot, e1 = yard.project(g.x + Math.cos(a) * g.s, 0.02, g.z + Math.sin(a) * g.s * 0.6);
      if (!e1) break;
      ctx.strokeStyle = css(g.c1); ctx.lineWidth = g.k === 'bone' ? lw + 2 : lw + (g.k === 'cable' ? 1 : 0); ctx.beginPath(); ctx.moveTo(q.x, q.y);
      if (g.k === 'cable') ctx.quadraticCurveTo((q.x + e1.x) / 2 + px * 0.3, (q.y + e1.y) / 2 + px * 0.1, e1.x, e1.y); else ctx.lineTo(e1.x, e1.y);
      ctx.stroke();
      if (g.k === 'cable' && Math.sin(t * 3 + g.ph) > 0.6) { ctx.fillStyle = css(g.c2); ctx.fillRect(Math.round(e1.x) - 1, Math.round(e1.y) - 1, 3, 3); }
      if (g.k === 'twig' && px > 6) { ctx.beginPath(); ctx.moveTo((q.x + e1.x) / 2, (q.y + e1.y) / 2); ctx.lineTo((q.x + e1.x) / 2 + px * 0.15, (q.y + e1.y) / 2 - px * 0.12); ctx.stroke(); }
      break;
    }
    case 'shroom': {
      const hgt = px * 0.9, cw = px * 0.7;
      ctx.fillStyle = css(g.c1); ctx.fillRect(Math.round(q.x - Math.max(1, cw * 0.18)), Math.round(q.y - hgt), Math.max(2, Math.round(cw * 0.36)), Math.round(hgt));
      ctx.fillStyle = css(g.c2); ctx.beginPath(); ctx.ellipse(q.x, q.y - hgt, cw, cw * 0.55, 0, Math.PI, 0); ctx.fill();
      if (g.glow) softGlow(ctx, q.x, q.y - hgt, cw * 1.6, g.c2, 0.28 + 0.12 * Math.sin(t * 2 + g.ph));
      else if (cw > 3) { ctx.fillStyle = '#ffffff'; ctx.fillRect(Math.round(q.x - cw * 0.4), Math.round(q.y - hgt - cw * 0.3), Math.max(1, Math.round(cw * 0.2)), Math.max(1, Math.round(cw * 0.2))); }
      break;
    }
    case 'crystal': case 'shard': {
      const w = px * (g.k === 'shard' ? 0.5 : 0.45), hgt = px * (g.k === 'shard' ? 0.9 : 1.6), lean = (g.v[0] - 0.5) * 0.6;
      ctx.fillStyle = css(g.c1, 0.9); ctx.beginPath(); ctx.moveTo(q.x - w, q.y); ctx.lineTo(q.x + lean * hgt, q.y - hgt); ctx.lineTo(q.x + w, q.y); ctx.closePath(); ctx.fill();
      ctx.fillStyle = css(g.c2, 0.95); ctx.beginPath(); ctx.moveTo(q.x - w * 0.9, q.y); ctx.lineTo(q.x + lean * hgt, q.y - hgt); ctx.lineTo(q.x - w * 0.05, q.y); ctx.closePath(); ctx.fill();
      // a glint now and then
      if (Math.sin(t * 1.3 + g.ph * 3) > 0.94) { ctx.fillStyle = '#ffffff'; const s2 = Math.max(1, Math.round(px * 0.18)); ctx.fillRect(Math.round(q.x + lean * hgt * 0.7 - s2), Math.round(q.y - hgt * 0.75), s2 * 2 + 1, 1); ctx.fillRect(Math.round(q.x + lean * hgt * 0.7), Math.round(q.y - hgt * 0.75 - s2), 1, s2 * 2 + 1); }
      if (g.glow) softGlow(ctx, q.x, q.y - hgt * 0.5, hgt * 0.8, g.c2, 0.2 + 0.08 * Math.sin(t * 1.7 + g.ph));
      break;
    }
    case 'ember': {
      const rx = px * 1.1, ry = flatY(yard, g, q, rx) * 0.7, pulse = 0.6 + 0.4 * Math.sin(t * 2.3 + g.ph);
      ctx.fillStyle = css([40, 20, 20]); ctx.beginPath(); ctx.ellipse(q.x, q.y, rx, ry, g.rot * 0.2, 0, Math.PI * 2); ctx.fill();
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = css(g.c1, 0.6 * pulse); ctx.beginPath(); ctx.ellipse(q.x, q.y, rx * 0.75, ry * 0.6, g.rot * 0.2, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = css(g.c2, 0.7 * pulse); ctx.beginPath(); ctx.ellipse(q.x, q.y, rx * 0.35, ry * 0.3, g.rot * 0.2, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      break;
    }
    case 'stud': {
      const rx = px * 0.8, ry = flatY(yard, g, q, rx), on = 0.55 + 0.45 * Math.sin(t * 2 + g.ph);
      ctx.fillStyle = css(mixRgb(g.c1, [0, 0, 0], 0.5)); ctx.fillRect(Math.round(q.x - rx), Math.round(q.y - ry), Math.max(2, Math.round(rx * 2)), Math.max(1, Math.round(ry * 2)));
      ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = css(g.c1, on); ctx.fillRect(Math.round(q.x - rx * 0.6), Math.round(q.y - ry * 0.6), Math.max(1, Math.round(rx * 1.2)), Math.max(1, Math.round(ry * 1.2)));
      ctx.fillStyle = css(g.c1, on * 0.25); ctx.beginPath(); ctx.ellipse(q.x, q.y, rx * 3, ry * 3, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore();
      break;
    }
    case 'shell': case 'starfish': case 'coral': {
      if (g.k === 'coral') {
        const hgt = px * 1.1; ctx.strokeStyle = css(g.c1); ctx.lineWidth = lw + 1; ctx.beginPath();
        for (let b = 0; b < 4; b++) { const a = -Math.PI / 2 + (b - 1.5) * 0.45 + wind * 0.3; ctx.moveTo(q.x, q.y); ctx.lineTo(q.x + Math.cos(a) * hgt * (0.6 + g.v[b] * 0.4), q.y + Math.sin(a) * hgt * (0.6 + g.v[b] * 0.4)); }
        ctx.stroke(); ctx.fillStyle = css(g.c2); for (let b = 0; b < 4; b++) { const a = -Math.PI / 2 + (b - 1.5) * 0.45 + wind * 0.3, l = hgt * (0.6 + g.v[b] * 0.4); ctx.fillRect(Math.round(q.x + Math.cos(a) * l) - 1, Math.round(q.y + Math.sin(a) * l) - 1, 3, 3); }
        break;
      }
      const rx = px, ry = flatY(yard, g, q, rx);
      ctx.fillStyle = css(g.c1);
      if (g.k === 'starfish') { ctx.beginPath(); for (let k = 0; k < 10; k++) { const a = g.rot + (k * Math.PI) / 5, rr = k % 2 ? 0.4 : 1; ctx.lineTo(q.x + Math.cos(a) * rx * rr, q.y + Math.sin(a) * ry * rr); } ctx.closePath(); ctx.fill(); }
      else { ctx.beginPath(); ctx.ellipse(q.x, q.y - ry * 0.4, rx, ry * 1.1, 0, Math.PI, 0); ctx.lineTo(q.x + rx * 0.2, q.y); ctx.lineTo(q.x - rx * 0.2, q.y); ctx.closePath(); ctx.fill(); if (rx > 3) { ctx.strokeStyle = css(g.c2); ctx.lineWidth = 1; ctx.beginPath(); for (let k = -2; k <= 2; k++) { ctx.moveTo(q.x, q.y); ctx.lineTo(q.x + k * rx * 0.4, q.y - ry * 1.3); } ctx.stroke(); } }
      break;
    }
    default: break;
  }
}
// a soft glow (fading out from the middle), never bigger than a small part of the picture
function softGlow(ctx, x, y, r, c, a) {
  r = Math.min(r, 70);
  if (r < 2 || a <= 0.01) return;
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, css(c, a)); g.addColorStop(1, css(c, 0));
  ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2); ctx.restore();
}
// how tall a flat thing of width rx looks from here (squashed by the camera's angle)
function flatY(yard, g, q, rx) {
  const p = yard.project(g.x, 0, g.z + g.s);
  if (!p) return rx * 0.4;
  return Math.max(rx * 0.22, Math.min(rx, Math.abs(p.y - q.y)));
}
