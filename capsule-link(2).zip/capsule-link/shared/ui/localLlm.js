// A small open-source language model running on this device (SmolLM2, 135 million parameters, through
// transformers.js), so creatures really take in what you say to them: "Hello" → "Lileep acknowledged your hello.",
// "Sorry, we can't go outside today" → "Porygon is saddened but understands." They still can't talk: it only
// writes the one line saying how they react. It's part of talking to them, not an option: it downloads once in
// the background (about 120 MB) the first time the app runs online, then works offline. Until it's ready, or if
// it can't load, or if what it writes doesn't make sense, the built-in rules answer as before.
const LIB = 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.5.1/dist/transformers.min.js';
const MODELS = [['HuggingFaceTB/SmolLM2-135M-Instruct', 'q4'], ['onnx-community/SmolLM2-135M-Instruct-ONNX', 'q4'], ['HuggingFaceTB/SmolLM2-135M-Instruct', 'fp32']];

const status = { state: 'idle', progress: 0, error: null };
let gen = null, loading = null;
const listeners = new Set();
const tell = () => { for (const f of listeners) { try { f({ ...status }); } catch { /* fine */ } } };

/** Where the model is: { state: 'idle'|'loading'|'ready'|'failed', progress 0..1, error }. */
export function llmStatus() { return { ...status }; }
export function onLlmStatus(fn) { listeners.add(fn); return () => listeners.delete(fn); }

// It runs in a background worker, so the app never freezes while it thinks (the creatures show “…” meanwhile).
const WORKER_SRC = `let gen = null;
self.onmessage = async (e) => { const m = e.data;
  if (m.type === 'load') {
    try {
      const T = await import(m.lib);
      try { T.env.allowLocalModels = false; T.env.useBrowserCache = true; } catch (_) {}
      const files = new Map();
      const progress_callback = (p) => { if (p && p.status === 'progress' && p.file) { files.set(p.file, [p.loaded || 0, p.total || 0]); let a = 0, b = 0; for (const [l, t] of files.values()) { a += l; b += t; } self.postMessage({ type: 'progress', progress: b ? a / b : 0 }); } };
      let last = null;
      for (const [model, dtype] of m.models) { try { gen = await T.pipeline('text-generation', model, { dtype, device: 'wasm', progress_callback }); break; } catch (err) { last = err; } }
      if (!gen) throw last || new Error('no model');
      self.postMessage({ type: 'ready' });
    } catch (err) { self.postMessage({ type: 'failed', error: String((err && err.message) || err) }); }
  } else if (m.type === 'gen') {
    try { const out = await gen(m.messages, m.opts); self.postMessage({ type: 'out', id: m.id, out: JSON.parse(JSON.stringify(out)) }); }
    catch (err) { self.postMessage({ type: 'out', id: m.id, error: String((err && err.message) || err) }); }
  }
};`;
function workerGen() {
  if (typeof Worker === 'undefined' || typeof Blob === 'undefined' || typeof URL?.createObjectURL !== 'function') return null;
  let w;
  try { w = new Worker(URL.createObjectURL(new Blob([WORKER_SRC], { type: 'text/javascript' })), { type: 'module' }); } catch { return null; }
  const waiting = new Map(); let n = 0;
  const ready = new Promise((resolve, reject) => {
    w.onmessage = (e) => { const m = e.data;
      if (m.type === 'progress') { status.progress = m.progress; tell(); }
      else if (m.type === 'ready') resolve();
      else if (m.type === 'failed') reject(new Error(m.error));
      else if (m.type === 'out') { const p = waiting.get(m.id); waiting.delete(m.id); if (p) (m.error ? p.reject(new Error(m.error)) : p.resolve(m.out)); }
    };
    w.onerror = (e) => reject(new Error(e?.message || 'worker failed'));
  });
  w.postMessage({ type: 'load', lib: LIB, models: MODELS });
  const run = (messages, opts) => new Promise((resolve, reject) => { const id = ++n; waiting.set(id, { resolve, reject }); w.postMessage({ type: 'gen', id, messages, opts }); });
  return ready.then(() => run, (e) => { try { w.terminate(); } catch { /* gone */ } throw e; });
}

/** Start loading it (in the background; safe to call often). importer: for tests (then it runs here, not in a worker). */
export function warmLlm({ importer = null } = {}) {
  if (gen || loading) return loading ?? Promise.resolve(gen);
  if (typeof navigator !== 'undefined' && navigator.onLine === false && !hasCache()) return Promise.resolve(null);
  status.state = 'loading'; status.progress = 0; status.error = null; tell();
  loading = (async () => {
    // in a worker first (no freezing); if that can't start here, on this thread as before
    if (!importer) {
      const wg = workerGen();
      if (wg) { try { gen = await wg; try { localStorage.setItem('clLlmCached', '1'); } catch { /* fine */ } status.state = 'ready'; status.progress = 1; tell(); return gen; } catch (e) { console.warn('language model worker', e); } }
    }
    importer ??= (u) => import(/* @vite-ignore */ u);
    const T = await importer(LIB);
    try { T.env.allowLocalModels = false; T.env.useBrowserCache = true; } catch { /* older versions */ }
    const files = new Map();
    const progress_callback = (p) => {
      if (p?.status === 'progress' && p.file) { files.set(p.file, [p.loaded ?? 0, p.total ?? 0]); let a = 0, b = 0; for (const [l, t] of files.values()) { a += l; b += t; } status.progress = b ? a / b : 0; tell(); }
    };
    let lastErr = null;
    for (const [model, dtype] of MODELS) {
      try { gen = await T.pipeline('text-generation', model, { dtype, device: 'wasm', progress_callback }); break; } catch (e) { lastErr = e; }
    }
    if (!gen) throw lastErr ?? new Error('no model');
    try { localStorage.setItem('clLlmCached', '1'); } catch { /* fine */ }
    status.state = 'ready'; status.progress = 1; tell();
    return gen;
  })().catch((e) => { console.warn('language model', e); status.state = 'failed'; status.error = String(e?.message ?? e); loading = null; tell(); return null; });
  return loading;
}
/** Try loading again after it failed. */
export function retryLlm() { if (status.state === 'failed' || status.state === 'idle') { gen = null; loading = null; return warmLlm(); } return loading; }
function hasCache() { try { return localStorage.getItem('clLlmCached') === '1'; } catch { return false; } }

// a few examples teach it the job: one sentence, third person, how the creature reacts (it can't speak)
const EXAMPLES = [
  ['Hello!', 'Lileep', 'Lileep acknowledged your hello.'],
  ['Sorry, we can’t go outside today.', 'Porygon', 'Porygon is saddened but understands.'],
  ['You did great in that battle!', 'Pikachu', 'Pikachu puffs up proudly at the praise.'],
  ['Want to go to the beach tomorrow?', 'Squirtle', 'Squirtle bounces with excitement at the idea.'],
  ['I had a really bad day.', 'Eevee', 'Eevee nuzzles up to you to cheer you up.'],
];

/**
 * One line saying how the creature reacts to what was said, or null (then use the rules' own line).
 * c: { name, species, mood, likes, rule } (rule: what the built-in rules made of it, as a hint).
 */
export async function llmReact(text, c, { timeoutMs = 6000 } = {}) {
  if (!gen) return null;
  const name = String(c.name || c.species || 'It');
  const sys = `You narrate how ${name}${c.species && c.species !== name ? `, a ${c.species},` : ''} reacts when its trainer talks to it. ${name} is a Pokémon: it cannot talk, but it understands the gist. Answer with ONE short sentence in the third person that starts with "${name}" and describes its reaction to what was said. ${name} is feeling ${c.mood || 'fine'}.${c.likes ? ` It loves ${c.likes}.` : ''} Don't mention food unless the trainer did.`;
  const messages = [{ role: 'system', content: sys }];
  for (const [said, who, line] of EXAMPLES) { messages.push({ role: 'user', content: `Trainer says to ${who}: "${said}"` }, { role: 'assistant', content: line }); }
  messages.push({ role: 'user', content: `Trainer says to ${name}: "${String(text).slice(0, 200)}"` });
  try {
    const run = gen(messages, { max_new_tokens: 32, do_sample: true, temperature: 0.6, top_p: 0.9, repetition_penalty: 1.1 });
    const out = await Promise.race([run, new Promise((r) => setTimeout(() => r(null), timeoutMs))]);
    if (!out) return null;
    const g = out?.[0]?.generated_text;
    const raw = Array.isArray(g) ? g[g.length - 1]?.content : String(g ?? '');
    return cleanLine(raw, name);
  } catch (e) { console.warn('language model', e); return null; }
}

/** What it wrote, tidied, or null when it doesn't make sense as a reaction. */
export function cleanLine(raw, name) {
  let s = String(raw ?? '').replace(/^["'\s]+|["'\s]+$/g, '').split(/\n/)[0].trim();
  const m = s.match(/^[^.!?]*[.!?]/); if (m) s = m[0];
  if (!s || s.length < 6 || s.length > 140) return null;
  if (!s.toLowerCase().startsWith(String(name).toLowerCase())) return null; // it has to be about them
  if (/\b(I|I'm|I am|my|me)\b/.test(s.slice(String(name).length))) return null; // they can't speak
  if (/[<>{}[\]]|https?:/i.test(s)) return null;
  return /[.!?]$/.test(s) ? s : `${s}.`;
}

/**
 * What the trainer is asking for, as one of `choices` (ids) or null: "Anyone up for a swim in the pond?" →
 * 'fishing'? no — 'walk'… It's only asked when the built-in rules didn't recognise the request, and only an
 * answer that's exactly one of the choices counts.
 */
export async function llmIntent(text, choices, { timeoutMs = 7000 } = {}) {
  if (!gen || !choices?.length) return null;
  // choices: ids, or { id, label } (the label helps a small model tell them apart)
  const ids = choices.map((c) => (typeof c === 'string' ? c : c.id));
  const list = choices.map((c) => (typeof c === 'string' ? c : `${c.id} (${c.label})`)).join(', ');
  const sys = `You sort a Pokémon trainer's requests into app actions. Reply with exactly one word, an id from this list, and nothing else: ${list}, none. Use none if the trainer isn't asking the Pokémon to do something.`;
  const ex = [['Who fancies digging for treasure?', 'scavenging'], ['Anyone want to help me make dinner?', 'cooking'], ['Who wants to come sit with me while I study?', 'desktop'], ['Who wants to see a film?', 'movie'], ['Who can get to the big tree first?', 'race'], ['Munna, could you help the others sleep better?', 'dreamhelp'],
    ['Anyone want to run the obstacle course?', 'obstacle'], ['Who wants to go for a dip in the pond?', 'swim'], ['Who wants a big squeeze?', 'hug'], ['Who wants to look for shooting stars tonight?', 'stargaze'], ['Anyone fancy a game where you hide and I find you?', 'hideseek'], ['Who will chase the frisbee?', 'fetch'],
    ['Who wants to do some stretches with me?', 'stretch'], ['Who wants a story before bed?', 'story'], ['Who wants to help me clean up the yard?', 'tidy'], ['Who wants to show off their best tricks?', 'contest'], ['Who wants to sing with me?', 'sing'], ['Anyone want to sit by the fire and toast marshmallows?', 'campfire'],
    ['Could you make it feel like a sauna in here?', 'fire'], ['Can you charge my phone?', 'spark'], ['The flowers look thirsty, can you help?', 'water'], ['Can you pretend to be Pikachu?', 'transform'], ['Make it snow for us!', 'ice'], ['Move that rock without touching it', 'levitate'],
    ['Can you get over there in a blink?', 'teleport'], ['It is so dark, help me see', 'flash'], ['Could you keep us safe?', 'protect'], ['Everyone is hurt, please help them', 'heal'], ['Show me your coolest move', 'trick'], ['Can you get really big?', 'grow'], ['Give us a cool breeze', 'wind'], ['Can you scare the others a bit?', 'ghost'],
    ['I like your hat.', 'none']]
    .filter(([, a]) => a === 'none' || ids.includes(a));
  const messages = [{ role: 'system', content: sys }];
  for (const [q, a] of ex) messages.push({ role: 'user', content: q }, { role: 'assistant', content: a });
  messages.push({ role: 'user', content: String(text).slice(0, 200) });
  try {
    const run = gen(messages, { max_new_tokens: 6, do_sample: false });
    const out = await Promise.race([run, new Promise((r) => setTimeout(() => r(null), timeoutMs))]);
    const g = out?.[0]?.generated_text;
    const raw = String(Array.isArray(g) ? g[g.length - 1]?.content : g ?? '').toLowerCase();
    const word = raw.match(/[a-z]+/)?.[0];
    return word && ids.includes(word) ? word : null;
  } catch { return null; }
}
