// Extra time (in milliseconds) added to each big moment of a battle's camera and animation, on top of the
// built-in timing. All 0 here; the move lab's Timing panel tries values out live, and whatever is settled on
// there gets written in here so the real battles use it too.
//   intro   each shot of a battle's introduction (the wild one's reveal, the trainers with their creatures)
//   focus   the opening close-up on the one using the move, before it goes
//   charge  extra build-up for the big moves (on top of focus)
//   attack  the move on its way across (projectiles, beams, the run in)
//   hit     a freeze-frame the instant the move lands
//   impact  the shot on the one hit, after it lands
//   slide   the one hit being knocked back
//   back    how long it stays back before hopping back to its spot
//   glide   every camera move between shots (glides take longer; a long jump is still a cut)
export const TIMING_KEYS = ['intro', 'focus', 'charge', 'attack', 'hit', 'impact', 'slide', 'back', 'glide'];
export const TIM = { intro: 0, focus: 0, charge: 0, attack: 0, hit: 0, impact: 0, slide: 0, back: 0, glide: 0 };
