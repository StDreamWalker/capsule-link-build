// The 3D models: every prop in the scenes (trees, rocks, crystals, cacti, lampposts…) and everything you can
// build in the R.A.N.C.H. (the hammock, toy chest, slide, berry blender, fossil machine…). Each is built from
// smooth shapes with real materials, and varies a little from one to the next (seed).
//
//   modelFor(kind, { seed, leaf, stone, accent, snow, moss }) → { mesh, mats, foot, footprint } or null
//   MODELS: the kinds there are models for
import { Mesh, merge, lathe, cylinder, cone, sphere, blob, box, tube, rod, curve, sheet, gem, surface, rng, noise3 } from './geo.js';
import { hexLin } from './render.js';

// ---------- colours ----------
const hexRgb = (h) => { const x = String(h).replace('#', ''); const n = parseInt(x.length === 3 ? x.split('').map((c) => c + c).join('') : x.slice(0, 6), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const rgbHex = (r, g, b) => `#${[r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('')}`;
/** Lighter (k > 0) or darker (k < 0). */
export const shade = (hex, k) => { const [r, g, b] = hexRgb(hex); return k >= 0 ? rgbHex(r + (255 - r) * k, g + (255 - g) * k, b + (255 - b) * k) : rgbHex(r * (1 + k), g * (1 + k), b * (1 + k)); };
const hue = (hex, dh = 0, ds = 1) => { const [r, g, b] = hexRgb(hex).map((v) => v / 255), mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; let h = 0, s = 0; if (mx !== mn) { const d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; } h = (h + dh + 1) % 1; s = Math.min(1, s * ds); const f = (p, q, t) => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; }; const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q; return rgbHex(f(p, q, h + 1 / 3) * 255, f(p, q, h) * 255, f(p, q, h - 1 / 3) * 255); };
/** A vertex-colour multiplier that turns base into target (moss on a rock, snow on a branch). */
const toward = (base, target, k) => { const a = hexLin(base), b = hexLin(target); return a.map((v, i) => 1 + ((b[i] / Math.max(0.004, v)) - 1) * k); };

// ---------- materials ----------
const M = {
  wood: (col = '#9a6a3c', o = {}) => ({ col, col2: shade(col, -0.32), tex: 'wood', rough: 0.72, spec: 0.12, bump: 0.6, ...o }),
  bark: (col = '#6b4a2e', o = {}) => ({ col, col2: shade(col, -0.5), tex: 'bark', rough: 0.9, spec: 0.05, bump: 1, texS: 1.2, ...o }),
  leaf: (col = '#4f9a3f', o = {}) => ({ col, col2: shade(hue(col, 0.02, 1.15), -0.38), tex: 'leaf', rough: 0.75, spec: 0.18, sss: 0.45, bump: 0.9, ...o }),
  stone: (col = '#8a8296', o = {}) => ({ col, col2: shade(col, -0.28), tex: 'stone', rough: 0.85, spec: 0.1, bump: 1, ...o }),
  metal: (col = '#a9b2c0', o = {}) => ({ col, col2: shade(col, -0.2), tex: 'metal', rough: 0.32, spec: 0.9, metal: 1, ...o }),
  paint: (col, o = {}) => ({ col, rough: 0.42, spec: 0.45, vary: 0.04, ...o }),
  plastic: (col, o = {}) => ({ col, col2: shade(col, -0.1), tex: 'plastic', rough: 0.25, spec: 0.7, ...o }),
  fabric: (col, o = {}) => ({ col, col2: shade(col, -0.18), tex: 'fabric', rough: 0.95, spec: 0.04, sss: 0.15, rim: 1.4, ...o }),
  ceramic: (col, o = {}) => ({ col, col2: shade(col, -0.15), tex: 'ceramic', rough: 0.55, spec: 0.35, ...o }),
  glass: (col = '#cfe8ff', o = {}) => ({ col, rough: 0.05, spec: 1.2, alpha: 0.28, rim: 2, ...o }),
  water: (col = '#3a9ad6', o = {}) => ({ col, col2: shade(col, 0.25), tex: 'water', rough: 0.08, spec: 1.3, alpha: 0.82, ...o }),
  glow: (col, k = 1, o = {}) => ({ col, em: col, emK: k, rough: 0.4, spec: 0.3, ...o }),
  crystal: (col, o = {}) => ({ col: shade(col, -0.25), col2: shade(col, 0.45), tex: 'crystal', em: shade(col, -0.35), emK: 0.55, rough: 0.06, spec: 1.6, rim: 2.2, ...o }),
  soil: (col = '#5a3a20') => ({ col, col2: shade(col, -0.35), tex: 'soil', rough: 1, spec: 0.02, bump: 1 }),
  grass: (col = '#4f9a3f') => ({ col, col2: shade(col, -0.35), tex: 'grass', rough: 0.9, spec: 0.08, sss: 0.3 }),
};

// a model under construction: its materials, and the parts made of each
function build() {
  const mats = [], parts = [];
  const api = {
    mat(def) { mats.push(def); return mats.length - 1; },
    put(mesh, m) { if (m != null) mesh.mat(m); parts.push(mesh); return mesh; },
    done(extra = {}) { return { mesh: merge(parts), mats, ...extra }; },
  };
  return api;
}

// ---------- shared pieces ----------
/** A trunk or branch that curves and tapers. */
function limb(a, b, ctrl, r0, r1, m, segs = 10, steps = 10) { return tube(curve(a, ctrl, b), (t) => r0 + (r1 - r0) * t, { steps, segs, m }); }
/** A clump of foliage: several blobs round a centre. */
function canopy(B, mLeaf, cx, cy, cz, rx, ry, rz, seed, n = 6) {
  const r = rng(seed);
  B.put(blob(rx * 0.85, ry * 0.8, rz * 0.85, seed, { amp: 0.16, freq: 1.4, segs: 20, rings: 14 }).translate(cx, cy, cz), mLeaf);
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + r() * 0.6, up = r() * 0.8 - 0.2, d = 0.55 + r() * 0.25;
    const s = 0.45 + r() * 0.25;
    B.put(blob(rx * s, ry * s * 0.9, rz * s, seed + i * 7, { amp: 0.2, freq: 1.8, segs: 14, rings: 10 }).translate(cx + Math.cos(a) * rx * d, cy + up * ry * 0.6, cz + Math.sin(a) * rz * d), mLeaf);
  }
}
/** Darker underneath, lighter on top (sky light in a canopy). */
const topLit = (k = 0.35) => (p, n) => 1 + n[1] * k;

// ---------- the models ----------
const DEF = {};

// ===== trees and plants =====
DEF.tree = ({ seed, leaf = '#4f9a3f', fruit }) => {
  const B = build(), r = rng(seed * 7 + 1), bark = B.mat(M.bark('#6b4a2e')), lf = B.mat(M.leaf(leaf)), lean = (r() - 0.5) * 0.45, leanZ = (r() - 0.5) * 0.3;
  // (each one its own shape: round, tall or spreading, a taller or shorter trunk, more or fewer boughs)
  const shape = seed % 3, th = 1.8 + r() * 0.6, nb = 3 + Math.floor(r() * 3);
  const [rx, ry, rz] = shape === 0 ? [1.25, 0.95, 1.15] : shape === 1 ? [0.95, 1.25, 0.9] : [1.5, 0.8, 1.35];
  B.put(lathe([[0.34, 0], [0.24, 0.12], [0.2, 0.35], [0, 0.36]], 14), bark); // (the root flare)
  B.put(limb([0, 0, 0], [lean, th, leanZ], [lean * 0.3 + (r() - 0.5) * 0.3, th * 0.5, (r() - 0.5) * 0.3], 0.2, 0.12, bark, 12, 12), bark);
  for (let i = 0; i < nb; i++) {
    const a = (i / nb) * Math.PI * 2 + r(), h = th * 0.65 + r() * 0.5;
    B.put(limb([lean * 0.6, h, leanZ * 0.6], [lean + Math.cos(a) * rx * 0.6, h + 0.6, leanZ + Math.sin(a) * rz * 0.55], [Math.cos(a) * 0.3, h + 0.15, Math.sin(a) * 0.25], 0.08, 0.035, bark, 8, 6), bark);
  }
  canopy(B, lf, lean, th + 0.45 + ry * 0.1, leanZ, rx, ry, rz, seed * 13, 5 + Math.floor(r() * 4));
  if (fruit) { const fr = B.mat(M.plastic(fruit, { rough: 0.2 })); for (let i = 0; i < 6; i++) { const a = r() * Math.PI * 2, y = th + r() * 1; B.put(sphere(0.09, 0.1, 0.09, { segs: 10, rings: 7 }).translate(lean + Math.cos(a) * rx * 0.85, y, leanZ + Math.sin(a) * rz * 0.85), fr); } }
  return B.done({ foot: 0.42 });
};
DEF.pine = ({ seed, leaf = '#2f6b48', snow }) => {
  const B = build(), r = rng(seed), bark = B.mat(M.bark('#5a3f2a')), nd = B.mat(M.leaf(leaf, { sss: 0.25, texS: 2 })), sn = snow ? B.mat({ col: '#f4f8ff', rough: 0.6, spec: 0.35, sss: 0.4, vary: 0.05 }) : null;
  B.put(cylinder(0.16, 1.2, 12, { r2: 0.1 }), bark);
  // (four to six tiers, fuller or slimmer, each a little off-centre)
  const tiers = 4 + (seed % 3), wide = 0.85 + r() * 0.35, step = 3.1 / tiers;
  for (let i = 0; i < tiers; i++) {
    const y = 0.55 + i * step, rad = (1.15 * (1 - i / (tiers + 0.6)) + 0.12) * wide, hh = (1.05 - i * 0.05) * (step / 0.62) * 0.9;
    const ox = (r() - 0.5) * 0.1, oz = (r() - 0.5) * 0.1;
    const jag = (u) => 1 + 0.12 * Math.sin(u * Math.PI * 2 * 9 + seed + i) + 0.05 * Math.sin(u * 37);
    const tier = surface(36, 6, (u, v) => { const a = u * Math.PI * 2, rr = (v < 0.2 ? rad * (0.85 + v * 0.75) * jag(u) : rad * (1 - (v - 0.2) / 0.8) * jag(u)), yy = v < 0.2 ? -v * 0.6 * 0.4 : (v - 0.2) / 0.8 * hh; return [Math.cos(a) * rr, y + yy + (v < 0.2 ? 0 : 0) - (v < 0.2 ? 0.05 : 0) + (1 - v) * -0.08 * (jag(u) - 1) * 4, Math.sin(a) * rr]; }, { wrapU: true });
    tier.tint(topLit(0.3));
    B.put(tier.translate(ox, 0, oz), nd);
    if (sn) B.put(surface(36, 4, (u, v) => { const a = u * Math.PI * 2, rr = rad * 0.92 * (1 - v) * jag(u), yy = 0.12 + v * hh * 0.98; return [Math.cos(a) * rr + ox, y + yy, Math.sin(a) * rr + oz]; }, { wrapU: true }), sn);
  }
  void r;
  return B.done({ foot: 0.35 });
};
DEF.snowpine = (o) => DEF.pine({ ...o, leaf: o.leaf ?? '#2e6a54', snow: true });
DEF.palm = ({ seed, leaf = '#3f9a3a' }) => {
  const B = build(), r = rng(seed), bark = B.mat(M.bark('#8a6a44', { texS: 2.5 })), lf = B.mat(M.leaf(leaf, { sss: 0.55 })), nut = B.mat(M.wood('#6a4424', { tex: null, rough: 0.6 }));
  const bend = 0.6 + r() * 0.4, top = [bend, 3.4, 0.1];
  B.put(tube(curve([0, 0, 0], [0.05, 1.8, 0], top), (t) => (0.17 - t * 0.06) * (1 + 0.12 * Math.abs(Math.sin(t * 40))), { steps: 40, segs: 12 }), bark);
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * Math.PI * 2 + r() * 0.3, droop = 0.5 + r() * 0.5, len = 1.5 + r() * 0.4;
    const ca = Math.cos(a), sa = Math.sin(a);
    B.put(sheet(10, 3, (u, v) => { const t = u, w = Math.sin(t * Math.PI) * 0.28 * (1 - t * 0.3), side = (v - 0.5) * 2 * w, out = t * len, y = Math.sin(t * Math.PI * 0.75) * 0.5 - t * t * droop * 1.3 + Math.abs(side) * 0.25; return [top[0] + ca * out - sa * side, top[1] + y, top[2] + sa * out + ca * side]; }), lf);
  }
  for (let i = 0; i < 3; i++) B.put(sphere(0.12, 0.13, 0.12, { segs: 10, rings: 8 }).translate(top[0] + Math.cos(i * 2.1) * 0.15, top[1] - 0.15, top[2] + Math.sin(i * 2.1) * 0.15), nut);
  return B.done({ foot: 0.3 });
};
DEF.bush = ({ seed, leaf = '#4f9a3f', flowers }) => {
  const B = build(), r = rng(seed * 5 + 3), lf = B.mat(M.leaf(leaf)), nB = 3 + (seed % 3);
  for (let i = 0; i < nB; i++) { const a = (i / nB) * Math.PI * 2 + r(), d = i ? 0.3 + r() * 0.15 : 0; B.put(blob(0.5 - d * 0.3, 0.42, 0.45, seed + i * 3, { amp: 0.2, freq: 2, flatBottom: 0.4 }).translate(Math.cos(a) * d, 0.38, Math.sin(a) * d * 0.8).tint(topLit(0.3)), lf); }
  if (flowers) { const fl = B.mat(M.plastic(flowers, { rough: 0.5, sss: 0.4 })), ct = B.mat(M.paint('#ffe27a')); for (let i = 0; i < 9; i++) { const a = r() * Math.PI * 2, y = 0.45 + r() * 0.35, d = 0.45 + r() * 0.15; const x = Math.cos(a) * d, z = Math.sin(a) * d * 0.85; B.put(sphere(0.07, 0.035, 0.07, { segs: 8, rings: 5 }).translate(x, y + 0.04, z), fl); B.put(sphere(0.025, 0.02, 0.025, { segs: 6, rings: 4 }).translate(x, y + 0.07, z), ct); } }
  return B.done({ foot: 0.6 });
};
DEF.cactus = ({ seed }) => {
  const B = build(), r = rng(seed * 11 + 5), g = B.mat({ col: '#4f9a4a', col2: '#2f6a32', tex: 'grass', rough: 0.55, spec: 0.3, bump: 0.4, texS: 3 }), fl = B.mat(M.plastic(['#ff6fa0', '#ffd23f', '#ff8a3d'][seed % 3], { rough: 0.5, sss: 0.4 }));
  const ribbed = (rad, h, top = 0.35, ribs = 8) => surface(28, 14, (u, v) => { const a = u * Math.PI * 2, rr = rad * (1 + 0.1 * Math.cos(a * ribs)) * (v > 1 - top ? Math.sqrt(Math.max(0, 1 - ((v - (1 - top)) / top) ** 2)) : 1); return [Math.cos(a) * rr, v * h, Math.sin(a) * rr]; }, { wrapU: true });
  if (seed % 4 === 3) {
    // a round barrel cactus, flowering on top
    B.put(ribbed(0.42, 0.85, 0.55, 14).displace((p) => [p[0] * 0.08 * Math.sin(p[1] * 3), 0, p[2] * 0.08 * Math.sin(p[1] * 3)]), g);
    for (let i = 0; i < 3; i++) B.put(sphere(0.07, 0.05, 0.07, { segs: 8, rings: 6 }).translate(Math.cos(i * 2.1) * 0.1, 0.84, Math.sin(i * 2.1) * 0.1), fl);
    return B.done({ foot: 0.42 });
  }
  const H = 1.6 + r() * 0.6;
  B.put(ribbed(0.26, H), g);
  const arms = seed % 4; // (none, one, two or three arms, at different heights and sides)
  for (let i = 0; i < arms; i++) {
    const ang = (i / Math.max(1, arms)) * Math.PI * 2 + r() * 1.2, y0 = 0.55 + r() * (H - 1.1), len = 0.35 + r() * 0.35, out = 0.45 + r() * 0.15;
    const ca = Math.cos(ang), sa = Math.sin(ang);
    B.put(tube(curve([0, y0, 0], [ca * out, y0 - 0.05, sa * out], [ca * out, y0 + len, sa * out]), 0.13, { steps: 12, segs: 12 }), g);
    B.put(ribbed(0.13, 0.28, 1).translate(ca * out, y0 + len - 0.05, sa * out), g);
  }
  B.put(sphere(0.1, 0.06, 0.1, { segs: 10, rings: 6 }).translate(0, H + 0.02, 0), fl);
  return B.done({ foot: 0.3 });
};
DEF.deadtree = ({ seed }) => {
  const B = build(), r = rng(seed), bark = B.mat(M.bark('#5a5048', { col2: '#2a2420' }));
  B.put(lathe([[0.32, 0], [0.22, 0.15], [0.18, 0.4], [0, 0.41]], 12), bark);
  B.put(limb([0, 0, 0], [0.15, 2.6, 0], [-0.2, 1.3, 0.1], 0.18, 0.06, bark, 10, 12), bark);
  const branch = (p, dir, len, rad, depth) => {
    const end = [p[0] + dir[0] * len, p[1] + dir[1] * len, p[2] + dir[2] * len];
    B.put(limb(p, end, [p[0] + dir[0] * len * 0.5 + (r() - 0.5) * 0.2, p[1] + dir[1] * len * 0.6, p[2] + dir[2] * len * 0.5], rad, rad * 0.5, bark, 7, 6), bark);
    if (depth > 0) for (let k = 0; k < 2; k++) { const a = r() * Math.PI * 2, d = [dir[0] * 0.6 + Math.cos(a) * 0.5, dir[1] * 0.5 + 0.35, dir[2] * 0.6 + Math.sin(a) * 0.5]; const m = Math.hypot(...d); branch(end, d.map((x) => x / m), len * 0.6, rad * 0.5, depth - 1); }
  };
  for (let i = 0; i < 4; i++) { const a = (i / 4) * Math.PI * 2 + r(), h = 1.4 + i * 0.3; branch([0.05, h, 0], [Math.cos(a) * 0.8, 0.6, Math.sin(a) * 0.8], 0.9, 0.07, 2); }
  return B.done({ foot: 0.4 });
};
DEF.mushroom = ({ seed, cap = '#e5484d', glow }) => {
  const B = build(), r = rng(seed), stem = B.mat({ col: '#f2ead8', rough: 0.7, spec: 0.15, sss: 0.3, vary: 0.08 });
  const cp = B.mat(glow ? { col: cap, col2: '#d8fbff', em: cap, emK: 0.9, rough: 0.35, spec: 0.6, sss: 0.5 } : { col: cap, col2: '#fff6ea', rough: 0.35, spec: 0.5, sss: 0.2 });
  const n = glow ? 3 : 1 + (seed % 2);
  for (let i = 0; i < n; i++) {
    const s = i ? 0.55 + r() * 0.2 : 1, a = r() * Math.PI * 2, d = i ? 0.22 : 0, x = Math.cos(a) * d, z = Math.sin(a) * d;
    B.put(lathe([[0.09 * s, 0], [0.07 * s, 0.2 * s], [0.06 * s, 0.38 * s], [0, 0.39 * s]], 12).translate(x, 0, z), stem);
    const capM = lathe([[0.05 * s, 0.36 * s], [0.25 * s, 0.33 * s], [0.27 * s, 0.38 * s], [0.22 * s, 0.5 * s], [0.12 * s, 0.57 * s], [0, 0.59 * s]], 18, { capBottom: true });
    // white spots on a red cap (as vertex colour, lighter where the noise peaks)
    if (!glow) capM.tint((p) => (noise3(p[0] * 22 + seed, p[1] * 22, p[2] * 22) > 0.72 && p[1] > 0.4 * s ? toward(cap, '#fff8ee', 1) : 1));
    B.put(capM.translate(x, 0, z), cp);
  }
  return B.done({ foot: 0.22 });
};
DEF.glowshroom = (o) => DEF.mushroom({ ...o, cap: '#4ad0ff', glow: true });
DEF.log = ({ seed }) => {
  const B = build(), bark = B.mat(M.bark('#6b4a2e')), end = B.mat(M.wood('#c79a62', { axis: 0, col2: '#8a5a34' }));
  const len = 1.5 + (seed % 3) * 0.15;
  const body = tube(curve([-len / 2, 0.2, 0], [0, 0.21, 0.04], [len / 2, 0.2, 0]), (t) => 0.2 - 0.02 * Math.sin(t * Math.PI), { steps: 10, segs: 14, caps: false });
  B.put(body, bark);
  for (const sd of [-1, 1]) B.put(cylinder(0.19, 0.02, 14, { bevel: 0 }).rotateZ(Math.PI / 2).translate(sd * len / 2 + (sd < 0 ? 0.01 : -0.01), 0.2, 0), end);
  return B.done({ foot: 0.5, footprint: [[-len / 3, 0, 0.3], [len / 3, 0, 0.3]] });
};
DEF.reed = ({ seed }) => {
  const B = build(), r = rng(seed), st = B.mat(M.leaf('#6a8a3a', { tex: null, vary: 0.15 })), hd = B.mat({ col: '#6a4428', col2: '#4a2c18', tex: 'fabric', rough: 0.9, bump: 1, texS: 2 });
  for (let i = 0; i < 7; i++) {
    const x = (r() - 0.5) * 0.4, z = (r() - 0.5) * 0.3, h = 1.1 + r() * 0.5, lean = (r() - 0.5) * 0.25;
    B.put(tube(curve([x, 0, z], [x + lean * 0.3, h * 0.5, z], [x + lean, h, z]), (t) => 0.025 - t * 0.012, { steps: 6, segs: 6 }), st);
    if (i % 2 === 0) B.put(lathe([[0, 0], [0.045, 0.03], [0.05, 0.18], [0.04, 0.24], [0, 0.26]], 8).translate(x + lean * 0.85, h * 0.78, z), hd);
  }
  return B.done({ foot: 0.3 });
};
DEF.kelp = ({ seed }) => {
  const B = build(), r = rng(seed), k = B.mat(M.leaf('#4a7a3a', { col2: '#2a4a24', sss: 0.6 }));
  for (let i = 0; i < 4; i++) {
    const x = (r() - 0.5) * 0.4, z = (r() - 0.5) * 0.3, h = 2 + r() * 0.8, ph = r() * 6;
    B.put(sheet(3, 18, (u, v) => { const y = v * h, w = 0.1 + 0.05 * Math.sin(v * 9 + ph), sw = Math.sin(v * 4 + ph) * 0.25 * v; return [x + sw + (u - 0.5) * w * 2, y, z + Math.cos(v * 5 + ph) * 0.08 * v]; }), k);
  }
  return B.done({ foot: 0.3 });
};
DEF.coral = ({ seed, hue: c = '#ff7a9a' }) => {
  const B = build(), r = rng(seed), m = B.mat({ col: c, col2: shade(c, -0.3), tex: 'stone', bump: 0.5, rough: 0.6, spec: 0.25, sss: 0.3, texS: 3 });
  const grow = (p, dir, len, rad, depth) => {
    const end = [p[0] + dir[0] * len, p[1] + dir[1] * len, p[2] + dir[2] * len];
    B.put(tube(curve(p, [p[0] + dir[0] * len * 0.5, p[1] + dir[1] * len * 0.6, p[2] + dir[2] * len * 0.5], end), (t) => rad * (1 - t * 0.3), { steps: 5, segs: 8 }), m);
    if (depth > 0) for (let i = 0; i < 2; i++) { const a = r() * Math.PI * 2, d = [dir[0] * 0.4 + Math.cos(a) * 0.55, 0.7, dir[2] * 0.4 + Math.sin(a) * 0.55]; const mm = Math.hypot(...d); grow(end, d.map((v) => v / mm), len * 0.75, rad * 0.75, depth - 1); }
    else B.put(sphere(rad * 1.3, rad * 1.3, rad * 1.3, { segs: 8, rings: 6 }).translate(...end), m);
  };
  for (let i = 0; i < 3; i++) { const a = (i / 3) * Math.PI * 2 + r(); grow([0, 0, 0], [Math.cos(a) * 0.4, 0.9, Math.sin(a) * 0.4], 0.38, 0.07, 2); }
  return B.done({ foot: 0.3 });
};
DEF.pumpkin = ({ seed }) => {
  const B = build(), p = B.mat({ col: '#e8781e', col2: '#b0480e', rough: 0.45, spec: 0.4, vary: 0.08 }), st = B.mat(M.leaf('#5a7a2a', { tex: null, sss: 0 })), eye = B.mat(M.glow('#ffc04a', 2.2));
  B.put(surface(32, 14, (u, v) => { const a = u * Math.PI * 2, b = v * Math.PI - Math.PI / 2, rib = 1 - 0.09 * Math.abs(Math.sin(a * 5)) ** 0.6; return [Math.cos(a) * Math.cos(b) * 0.32 * rib, 0.26 + Math.sin(b) * 0.24 * (1 - 0.15 * Math.cos(b * 2) ** 8), Math.sin(a) * Math.cos(b) * 0.32 * rib]; }, { wrapU: true }), p);
  B.put(tube(curve([0, 0.47, 0], [0.02, 0.56, 0], [0.08, 0.6, 0.02]), (t) => 0.04 - t * 0.015, { steps: 6, segs: 8 }), st);
  // the carved face, glowing from inside
  if (seed % 2 === 0) for (const [x, y, sx, sy] of [[-0.11, 0.3, 0.045, 0.05], [0.11, 0.3, 0.045, 0.05], [0, 0.17, 0.12, 0.035]]) B.put(sphere(sx, sy, 0.02, { segs: 10, rings: 6 }).translate(x, y, -0.3), eye);
  return B.done({ foot: 0.33 });
};

// ===== rocks and crystals =====
DEF.rock = ({ seed, stone = '#8a8296', moss, snow }) => {
  const B = build(), r = rng(seed), st = B.mat(M.stone(stone));
  // (a boulder, a flat slab, a pair, or a little cluster)
  const kind = seed % 4, n = kind === 2 ? 2 : kind === 3 ? 3 : 1;
  for (let i = 0; i < n; i++) {
    const s = i ? 0.45 + r() * 0.2 : 1, flat = kind === 1 ? 0.55 : 1;
    const rk = blob(0.55 * s * (kind === 1 ? 1.25 : 1), 0.4 * s * flat, 0.45 * s, seed * 3 + i * 11, { amp: 0.22, freq: 1.3, segs: 18, rings: 12, flatBottom: 0.35 });
    // a few flat facets, like broken stone
    rk.displace((p) => { const f = noise3(p[0] * 3 + seed, p[1] * 3, p[2] * 3); return [0, 0, 0].map((_, k) => -p[k] * Math.max(0, f - 0.62) * 0.5); });
    const ang = i * 2.3 + r(); rk.translate(i ? Math.cos(ang) * 0.55 : 0, 0.28 * s * flat, i ? Math.sin(ang) * 0.45 : 0);
    if (moss) rk.tint((p, nn) => (nn[1] > 0.35 ? toward(stone, moss, Math.min(1, (nn[1] - 0.35) * 2.2) * (0.6 + noise3(p[0] * 5, p[1] * 5, p[2] * 5) * 0.6)) : 1));
    if (snow) rk.tint((p, nn) => (nn[1] > 0.5 ? toward(stone, '#f4f8ff', Math.min(1, (nn[1] - 0.5) * 3)) : 1));
    B.put(rk, st);
  }
  void r;
  return B.done({ foot: 0.55 });
};
DEF.lavarock = ({ seed }) => {
  const m = DEF.rock({ seed, stone: '#3a3036' });
  m.mats[0] = { ...m.mats[0], lava: true, em: '#ff6a1a', emK: 0 };
  // (glowing cracks: brighter where the noise makes narrow ridges)
  m.mesh.tint((p) => { const f = Math.abs(noise3(p[0] * 4, p[1] * 4, p[2] * 4) - 0.5); return f < 0.05 ? [6, 2.2, 0.6] : 1; });
  return m;
};
DEF.crystal = ({ seed, hue: c }) => {
  const r = rng(seed), col = c ?? ['#ff9aff', '#9ad9ff', '#c89bff', '#7dffcf'][seed % 4];
  const B = build(), cr = B.mat({ ...M.crystal(col), h: 1.7 }), base = B.mat(M.stone('#4a4058'));
  B.put(blob(0.42, 0.18, 0.36, seed, { amp: 0.25, flatBottom: 0.3 }).translate(0, 0.08, 0), base);
  const n = 4 + (seed % 3);
  for (let i = 0; i < n; i++) {
    const big = i === 0, h = big ? 1.55 + r() * 0.25 : 0.5 + r() * 0.6, rad = big ? 0.2 : 0.08 + r() * 0.07;
    const g = gem(rad, h, { sides: 6, tip: 0.28, taper: 0.9, twist: r() });
    const tilt = big ? (r() - 0.5) * 0.15 : 0.35 + r() * 0.5, a = (i / n) * Math.PI * 2 + r();
    g.rotateZ(tilt).rotateY(a).translate(big ? 0 : Math.cos(a) * 0.18, 0.05, big ? 0 : Math.sin(a) * 0.15);
    B.put(g, cr);
  }
  return B.done({ foot: 0.42 });
};
DEF.icespike = ({ seed }) => DEF.crystal({ seed, hue: '#bfe8ff' });
DEF.stalagmite = ({ seed, stone = '#5a5470', tall = 2, wide = 0.42 }) => {
  const B = build(), st = B.mat(M.stone(stone, { spec: 0.35, rough: 0.5 }));
  const s = lathe([[wide, 0], [wide * 0.8, tall * 0.18], [wide * 0.52, tall * 0.45], [wide * 0.28, tall * 0.75], [wide * 0.08, tall * 0.97], [0, tall]], 16);
  s.displace((p) => { const k = (noise3(p[0] * 3 + seed, p[1] * 2, p[2] * 3) - 0.5) * 0.35 * (1 - p[1] / tall * 0.6); return [p[0] * k, 0, p[2] * k]; });
  // drips: rings of slightly wider stone
  s.tint((p) => 0.9 + 0.2 * Math.sin(p[1] * 14 + noise3(p[0] * 4, p[1], p[2] * 4) * 4));
  B.put(s, st);
  return B.done({ foot: wide });
};
DEF.spire = ({ seed }) => DEF.stalagmite({ seed, stone: '#3b3036', tall: 2.8, wide: 0.5 });
DEF.pillar = ({ seed, stone }) => {
  const B = build(), st = B.mat(M.stone(stone ?? '#8a8296'));
  B.put(box(0.7, 0.18, 0.7, 0.04), st);
  B.put(surface(24, 8, (u, v) => { const a = u * Math.PI * 2, rr = 0.24 * (1 + 0.04 * Math.cos(a * 12)); return [Math.cos(a) * rr, 0.18 + v * 1.8, Math.sin(a) * rr]; }, { wrapU: true }), st);
  B.put(box(0.62, 0.16, 0.62, 0.04).translate(0, 1.98, 0), st);
  void seed;
  return B.done({ foot: 0.42 });
};

// ===== town things =====
DEF.lamppost = () => {
  const B = build(), mt = B.mat(M.metal('#3a4048', { rough: 0.45 })), gl = B.mat(M.glow('#ffe3a6', 2.4, { rough: 0.1, spec: 1 }));
  B.put(lathe([[0.16, 0], [0.16, 0.08], [0.1, 0.14], [0.07, 0.3], [0.05, 2.8], [0.07, 2.85], [0, 2.86]], 14), mt);
  B.put(lathe([[0.04, 2.84], [0.16, 2.92], [0.17, 3.2], [0.22, 3.24], [0.12, 3.38], [0, 3.42]], 6), mt);
  B.put(lathe([[0.11, 2.94], [0.14, 3.0], [0.14, 3.18], [0.1, 3.22], [0, 3.22]], 6), gl);
  return B.done({ foot: 0.2 });
};
DEF.lantern = () => {
  const B = build(), wd = B.mat(M.wood('#5a3a20')), mt = B.mat(M.metal('#2a2a30', { rough: 0.5 })), gl = B.mat(M.glow('#ffcf7a', 2.2, { rough: 0.15 }));
  B.put(box(0.1, 1.5, 0.1, 0.02), wd);
  B.put(rod([0, 1.45, 0], [0.28, 1.45, 0], 0.025), mt);
  B.put(lathe([[0.1, 1.08], [0.12, 1.12], [0.12, 1.32], [0.08, 1.36], [0, 1.37]], 6).translate(0.28, -0.06, 0), gl);
  B.put(cone(0.13, 0.1, 6).translate(0.28, 1.3, 0), mt);
  return B.done({ foot: 0.15 });
};
DEF.bench = ({ wood = '#a0703c' } = {}) => {
  const B = build(), wd = B.mat(M.wood(wood, { axis: 0 })), mt = B.mat(M.metal('#2f3238', { rough: 0.5 }));
  for (let i = 0; i < 3; i++) B.put(box(1.5, 0.05, 0.12, 0.02).translate(0, 0.42, -0.14 + i * 0.14), wd);
  for (let i = 0; i < 2; i++) B.put(box(1.5, 0.11, 0.04, 0.02).rotateX(-0.2).translate(0, 0.62 + i * 0.16, 0.25 + i * 0.03), wd);
  for (const sx of [-0.62, 0.62]) {
    B.put(tube(curve([sx, 0, -0.22], [sx, 0.5, -0.2], [sx, 0.42, 0.2]), 0.025, { steps: 8, segs: 8 }), mt);
    B.put(tube(curve([sx, 0, 0.2], [sx, 0.6, 0.25], [sx, 0.95, 0.32]), 0.025, { steps: 8, segs: 8 }), mt);
  }
  return B.done({ foot: 0.6, footprint: [[-0.5, 0, 0.35], [0.5, 0, 0.35]] });
};
DEF.hydrant = () => {
  const B = build(), red = B.mat(M.paint('#d8342c', { rough: 0.35, spec: 0.6 })), mt = B.mat(M.metal('#c8c8d0'));
  B.put(lathe([[0.2, 0], [0.2, 0.06], [0.13, 0.08], [0.13, 0.5], [0.16, 0.52], [0.15, 0.58], [0.1, 0.66], [0.04, 0.7], [0, 0.71]], 16), red);
  for (const a of [0, Math.PI]) B.put(cylinder(0.06, 0.12, 10).rotateZ(Math.PI / 2).translate(Math.cos(a) * 0.12 + (a ? 0 : 0.12), 0.38, 0), red);
  B.put(cylinder(0.035, 0.05, 6).translate(0, 0.7, 0), mt);
  return B.done({ foot: 0.2 });
};
DEF.grave = ({ seed, stone = '#8a8a92' }) => {
  const B = build(), st = B.mat(M.stone(stone, { texS: 1.5 })), dirt = B.mat(M.soil());
  const s = box(0.55, 0.75, 0.14, 0.05);
  s.each((p) => { if (p[1] > 0.55) { const t = (p[1] - 0.55) / 0.2; p[0] *= Math.sqrt(Math.max(0.05, 1 - t * t * 0.85)); } });
  s.smooth().rotateZ((seed % 5 - 2) * 0.03).rotateX(0.05);
  B.put(s, st);
  B.put(blob(0.4, 0.06, 0.5, seed, { amp: 0.15, flatBottom: 0.5 }).translate(0, 0.02, -0.35), dirt);
  return B.done({ foot: 0.35 });
};

// ===== shapes (the dream places) =====
for (const kind of ['cube', 'orb', 'pyramid', 'ring', 'monolith']) {
  DEF[kind] = ({ seed, hue: c = '#ff7ac8' }) => {
    const B = build(), m = B.mat({ col: c, col2: shade(c, 0.4), rough: 0.12, spec: 1.1, em: shade(c, -0.5), emK: 0.6, rim: 2 });
    let g;
    if (kind === 'cube') g = box(0.9, 0.9, 0.9, 0.08).translate(0, 0.35, 0).rotateY(seed * 0.7);
    else if (kind === 'orb') g = sphere(0.5, 0.5, 0.5, { segs: 24, rings: 16 }).translate(0, 0.85, 0);
    else if (kind === 'pyramid') g = gem(0.6, 1.3, { sides: 4, tip: 1, taper: 1, base: 0.001 });
    else if (kind === 'ring') g = tube((t) => [Math.cos(t * Math.PI * 2) * 0.75, 1.05 + Math.sin(t * Math.PI * 2) * 0.75, 0], 0.12, { steps: 40, segs: 12, caps: false });
    else g = box(0.7, 3.1, 0.25, 0.05);
    B.put(g, m);
    return B.done({ foot: 0.5 });
  };
}

// ===== things you build =====
DEF.hammock = ({ accent = '#e5484d' }) => {
  const B = build(), wd = B.mat(M.wood('#8a5a34')), rope = B.mat({ col: '#d8c8a0', col2: '#a89870', tex: 'fabric', rough: 0.9, texS: 3, bump: 1 });
  const cloth = B.mat(M.fabric(accent, { stripes: { axis: 0, freq: 6, col: '#f4ead8' } })), pil = B.mat(M.fabric('#f4ead8'));
  const span = 1.9, top = 1.25;
  for (const sx of [-1, 1]) {
    B.put(tube(curve([sx * span / 2, 0, 0], [sx * span / 2, 0.6, 0], [sx * (span / 2 - 0.08), top + 0.1, 0]), (t) => 0.07 - t * 0.015, { steps: 6, segs: 10 }), wd);
    B.put(lathe([[0.13, 0], [0.12, 0.05], [0.08, 0.08], [0, 0.09]], 10).translate(sx * span / 2, 0, 0), wd);
  }
  // the cloth: a sagging curve between the bars, curled up at the sides
  const sag = (u) => 0.88 - Math.sin(u * Math.PI) * 0.42, half = 0.3;
  const cl = sheet(26, 8, (u, v) => { const x = (u - 0.5) * span * 0.62, side = (v - 0.5) * 2, w = half * (0.82 + Math.sin(u * Math.PI) * 0.2); return [x, sag(u) + side * side * 0.12 * Math.sin(u * Math.PI) + 0.02, side * w * (1 - 0.15 * side * side)]; });
  B.put(cl, cloth);
  for (const sx of [-1, 1]) {
    const bx = sx * span * 0.31;
    B.put(rod([bx, sag(sx < 0 ? 0 : 1) + 0.03, -half * 0.85], [bx, sag(sx < 0 ? 0 : 1) + 0.03, half * 0.85], 0.025), wd);
    for (const z of [-half * 0.8, 0, half * 0.8]) B.put(rod([bx, sag(sx < 0 ? 0 : 1) + 0.04, z], [sx * (span / 2 - 0.1), top, 0], 0.012, { segs: 6 }), rope);
  }
  B.put(blob(0.2, 0.08, 0.24, 7, { amp: 0.06 }).translate(-span * 0.22, sag(0.2) + 0.12, 0), pil);
  return B.done({ foot: 0.4, footprint: [[-span / 2, 0, 0.18], [span / 2, 0, 0.18], [0, 0, 0.35]] });
};
DEF.chest = ({ accent = '#e5484d' }) => {
  const B = build(), body = B.mat(M.paint(accent, { rough: 0.5 })), trim = B.mat(M.wood('#e8d4a8', { col2: '#c0a070', axis: 0 })), gold = B.mat(M.metal('#e8b84a', { rough: 0.25 }));
  B.put(box(1, 0.55, 0.62, 0.05), body);
  // the lid: rounded on top
  const lid = surface(20, 10, (u, v) => { const a = u * Math.PI, x = (v - 0.5) * 1.02; return [x, 0.55 + Math.sin(a) * 0.2, -Math.cos(a) * 0.32]; });
  B.put(lid, body);
  for (const x of [-0.505, 0.505]) B.put(sheet(14, 1, (u, v) => { const a = u * Math.PI; return [x, 0.55 + Math.sin(a) * 0.2 * v, -Math.cos(a) * 0.32 * v]; }), body);
  for (const x of [-0.36, 0.36]) { B.put(box(0.1, 0.57, 0.64, 0.02).translate(x, 0, 0), trim); B.put(tube((t) => { const a = t * Math.PI; return [x, 0.55 + Math.sin(a) * 0.21, -Math.cos(a) * 0.33]; }, 0.04, { steps: 12, segs: 6 }), trim); }
  B.put(box(1.04, 0.08, 0.66, 0.02).translate(0, 0.5, 0), trim);
  B.put(box(0.14, 0.18, 0.04, 0.02).translate(0, 0.42, -0.33), gold);
  // stars on the front
  const star = B.mat(M.paint('#fff2c8'));
  for (const x of [-0.18, 0.18]) B.put(gem(0.06, 0.02, { sides: 5, tip: 0.5, base: 0.001 }).rotateX(-Math.PI / 2).translate(x, 0.25, -0.315), star);
  return B.done({ foot: 0.55 });
};
DEF.post = ({ accent = '#e5484d' }) => {
  const B = build(), carpet = B.mat(M.fabric(accent, { bump: 1, texS: 0.6 })), rope = B.mat({ col: '#d8c090', col2: '#9a7a48', tex: 'fabric', texS: 0.5, rough: 0.95, bump: 1.2, stripes: { axis: 1, freq: 22, col: '#b89a68' } }), ball = B.mat(M.fabric('#ffe27a'));
  B.put(box(0.7, 0.1, 0.7, 0.04), carpet);
  B.put(cylinder(0.11, 1.15, 14, { bevel: 0 }).translate(0, 0.1, 0), rope);
  B.put(box(0.48, 0.07, 0.48, 0.03).translate(0, 1.25, 0), carpet);
  B.put(rod([0.2, 1.25, 0], [0.22, 0.95, 0], 0.008, { segs: 5 }), rope);
  B.put(sphere(0.06, 0.06, 0.06, { segs: 10, rings: 7 }).translate(0.22, 0.9, 0), ball);
  return B.done({ foot: 0.42 });
};
DEF.slide = ({ accent = '#e5484d' }) => {
  const B = build(), mt = B.mat(M.metal('#a8b4c4')), pl = B.mat(M.plastic(accent)), plat = B.mat(M.plastic('#ffd23f'));
  const lx = -0.7, top = 1.35;
  for (const z of [-0.22, 0.22]) B.put(rod([lx, 0, z], [lx + 0.05, top + 0.35, z], 0.035), mt);
  for (let i = 1; i <= 5; i++) { const y = (i / 6) * top; B.put(rod([lx + 0.04 * (y / top), y, -0.22], [lx + 0.04 * (y / top), y, 0.22], 0.022), mt); }
  B.put(box(0.42, 0.06, 0.5, 0.02).translate(lx + 0.2, top, 0), plat);
  for (const z of [-0.24, 0.24]) B.put(rod([lx + 0.38, top, z], [lx + 0.4, 0, z], 0.035), mt);
  // the chute: a U-shaped channel curving down to the ground
  const path = curve([lx + 0.4, top + 0.02, 0], [0.2, top - 0.1, 0], [0.4, 0.3, 0], [1.05, 0.12, 0]);
  const chute = surface(10, 24, (u, v) => { const p = path(v), q = path(Math.min(1, v + 0.01)), p0 = path(Math.max(0, v - 0.01)); const tx = q[0] - p0[0], ty = q[1] - p0[1], tm = Math.hypot(tx, ty) || 1; const nx = -ty / tm, ny = tx / tm; const a = (u - 0.5) * Math.PI * 1.15, w = 0.24; return [p[0] + nx * (1 - Math.cos(a)) * 0.12, p[1] + ny * (1 - Math.cos(a)) * 0.12 + 0.02, Math.sin(a) * w]; });
  B.put(chute, pl);
  return B.done({ foot: 0.5, footprint: [[-0.5, 0, 0.35], [0.8, 0, 0.3]] });
};
DEF.swing = ({ accent = '#e5484d' }) => {
  const B = build(), wd = B.mat(M.wood('#8a5a34')), ch = B.mat(M.metal('#c8c2d6', { rough: 0.4 })), seat = B.mat(M.plastic(accent));
  const sp = 0.85, h = 1.9;
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) B.put(rod([sx * sp * 1.05, 0, sz * 0.5], [sx * sp, h, 0], 0.06, { segs: 10 }), wd);
  B.put(rod([-sp - 0.12, h, 0], [sp + 0.12, h, 0], 0.07, { segs: 12 }), wd);
  for (const x of [-0.24, 0.24]) B.put(rod([x, h - 0.05, 0], [x, 0.52, 0.03], 0.012, { segs: 5 }), ch);
  B.put(box(0.62, 0.05, 0.22, 0.025).translate(0, 0.48, 0.03), seat);
  return B.done({ foot: 0.5, footprint: [[-0.9, 0, 0.3], [0.9, 0, 0.3], [0, 0, 0.25]] });
};
DEF.climber = ({ accent = '#e5484d' }) => {
  const B = build(), bars = [B.mat(M.paint(accent, { spec: 0.6, rough: 0.3 })), B.mat(M.paint('#ffd23f', { spec: 0.6, rough: 0.3 })), B.mat(M.paint('#3fa0ff', { spec: 0.6, rough: 0.3 }))];
  const R = 0.95, n = 8;
  for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2; B.put(tube((t) => { const b = t * Math.PI / 2; return [Math.cos(a) * Math.cos(b) * R, Math.sin(b) * R, Math.sin(a) * Math.cos(b) * R]; }, 0.03, { steps: 14, segs: 6 }), bars[i % 3]); }
  for (const b of [0.35, 0.7, 1.05]) B.put(tube((t) => [Math.cos(t * Math.PI * 2) * Math.cos(b) * R, Math.sin(b) * R, Math.sin(t * Math.PI * 2) * Math.cos(b) * R], 0.03, { steps: 32, segs: 6, caps: false }), bars[1]);
  return B.done({ foot: 0.9 });
};
DEF.tunnel = ({ accent = '#e5484d' }) => {
  const B = build(), fab = B.mat(M.fabric(accent, { stripes: { axis: 0, freq: 3, col: '#ffe27a' } }));
  const len = 1.6, R = 0.42;
  B.put(surface(24, 14, (u, v) => { const a = Math.PI * 0.08 + u * Math.PI * 0.84, x = (v - 0.5) * len, rr = R * (1 + 0.04 * Math.sin(v * 40)); return [x, Math.sin(a) * rr, Math.cos(a) * rr]; }), fab);
  for (const sx of [-1, 1]) B.put(tube((t) => { const a = Math.PI * 0.08 + t * Math.PI * 0.84; return [sx * len / 2, Math.sin(a) * R, Math.cos(a) * R]; }, 0.035, { steps: 16, segs: 6 }), fab);
  return B.done({ foot: 0.5, footprint: [[-0.5, 0, 0.35], [0.5, 0, 0.35]] });
};
DEF.fountain = () => {
  const B = build(), st = B.mat(M.stone('#c8c0b4', { texS: 1.5, spec: 0.25 })), wa = B.mat(M.water('#4aa8e8')), spray = B.mat({ col: '#dff4ff', rough: 0.1, spec: 1, alpha: 0.55, rim: 2 });
  B.put(lathe([[0.95, 0], [0.98, 0.05], [0.98, 0.32], [0.9, 0.36], [0.86, 0.12], [0, 0.12]], 28), st);
  B.put(cylinder(0.87, 0.26, 28, { bevel: 0 }), wa);
  B.put(lathe([[0.16, 0.1], [0.12, 0.3], [0.09, 0.75], [0.12, 0.8]], 14, { capTop: false }), st);
  B.put(lathe([[0.1, 0.78], [0.42, 0.82], [0.46, 0.92], [0.4, 0.93], [0.36, 0.86], [0, 0.86]], 22), st);
  B.put(cylinder(0.37, 0.06, 20, { bevel: 0 }).translate(0, 0.85, 0), wa);
  B.put(lathe([[0.04, 0.9], [0.06, 1.1], [0.03, 1.25], [0, 1.3]], 10), st);
  // the water arching out of the top
  for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; B.put(tube(curve([0, 1.25, 0], [Math.cos(a) * 0.2, 1.42, Math.sin(a) * 0.2], [Math.cos(a) * 0.38, 0.92, Math.sin(a) * 0.38]), (t) => 0.02 + t * 0.012, { steps: 10, segs: 6 }), spray); }
  return B.done({ foot: 0.98 });
};
DEF.birdbath = () => {
  const B = build(), st = B.mat(M.stone('#c8c0b4', { texS: 1.5 })), wa = B.mat(M.water('#5ab0e8'));
  B.put(lathe([[0.25, 0], [0.25, 0.06], [0.12, 0.12], [0.08, 0.5], [0.1, 0.7], [0.34, 0.76], [0.38, 0.84], [0.33, 0.85], [0.28, 0.8], [0, 0.8]], 20), st);
  B.put(cylinder(0.3, 0.03, 18, { bevel: 0 }).translate(0, 0.8, 0), wa);
  return B.done({ foot: 0.3 });
};
DEF.statue = ({ accent }) => {
  void accent;
  const B = build(), st = B.mat(M.stone('#d8d4cc', { texS: 1.5 })), br = B.mat(M.metal('#b8864a', { rough: 0.38, col2: '#6a8a5a' }));
  B.put(box(0.62, 0.42, 0.62, 0.04), st);
  B.put(box(0.7, 0.07, 0.7, 0.03).translate(0, 0.42, 0), st);
  // a proud little round creature on top, in bronze
  B.put(blob(0.22, 0.24, 0.2, 3, { amp: 0.03 }).translate(0, 0.73, 0), br);
  B.put(sphere(0.17, 0.16, 0.16, { segs: 18, rings: 12 }).translate(0, 1.05, -0.03), br);
  for (const sx of [-1, 1]) { B.put(cone(0.06, 0.2, 10).rotateZ(-sx * 0.35).translate(sx * 0.1, 1.15, -0.02), br); B.put(sphere(0.06, 0.08, 0.06, { segs: 8, rings: 6 }).translate(sx * 0.14, 0.52, -0.06), br); }
  B.put(tube(curve([0, 0.62, 0.15], [0.05, 0.6, 0.35], [0.12, 0.85, 0.3]), (t) => 0.05 - t * 0.03, { steps: 8, segs: 8 }), br);
  return B.done({ foot: 0.42 });
};
DEF.flag = ({ accent = '#e5484d' }) => {
  const B = build(), mt = B.mat(M.metal('#c8ccd4')), gold = B.mat(M.metal('#e8b84a', { rough: 0.2 })), fl = B.mat(M.fabric(accent, { stripes: { axis: 1, freq: 9, col: '#ffffff' }, sss: 0.4 }));
  B.put(lathe([[0.14, 0], [0.12, 0.08], [0.035, 0.12], [0.025, 2.45], [0, 2.46]], 12), mt);
  B.put(sphere(0.05, 0.05, 0.05, { segs: 10, rings: 7 }).translate(0, 2.48, 0), gold);
  B.put(sheet(14, 5, (u, v) => [0.03 + u * 0.85, 2.38 - v * 0.52 - u * 0.05, Math.sin(u * 5.5 + v) * 0.07 * u]), fl);
  return B.done({ foot: 0.15 });
};
DEF.perch = () => {
  const B = build(), wd = B.mat(M.bark('#7a5432', { texS: 2 })), plat = B.mat(M.wood('#a07040'));
  B.put(lathe([[0.25, 0], [0.12, 0.08], [0.08, 0.2], [0.07, 2.2], [0, 2.21]], 12), wd);
  for (const [y, a] of [[1.4, 0.4], [1.85, 2.6]]) B.put(tube(curve([0, y, 0], [Math.cos(a) * 0.3, y + 0.05, Math.sin(a) * 0.3], [Math.cos(a) * 0.55, y + 0.18, Math.sin(a) * 0.55]), (t) => 0.045 - t * 0.02, { steps: 8, segs: 8 }), wd);
  B.put(cylinder(0.3, 0.06, 16).translate(0, 2.2, 0), plat);
  return B.done({ foot: 0.25 });
};
DEF.gate = ({ accent = '#7dffcf' }) => {
  const B = build(), body = B.mat(M.plastic('#eef2f8', { rough: 0.3 })), mt = B.mat(M.metal('#8a96a8')), glow = B.mat({ col: accent, em: accent, emK: 1.5, alpha: 0.55, rough: 0.1, spec: 0.5 }), led = B.mat(M.glow(accent, 2.5));
  for (const sx of [-1, 1]) { B.put(box(0.42, 2.3, 0.5, 0.1).translate(sx * 1.15, 0, 0), body); B.put(box(0.06, 1.9, 0.52, 0.02).translate(sx * 0.95, 0.2, 0), led); B.put(box(0.52, 0.16, 0.6, 0.05).translate(sx * 1.15, 0, 0), mt); }
  B.put(tube((t) => [Math.cos(Math.PI - t * Math.PI) * 1.15, 2.3 + Math.sin(t * Math.PI) * 0.55, 0], 0.16, { steps: 24, segs: 12 }), body);
  B.put(sheet(18, 12, (u, v) => { const x = (u - 0.5) * 1.9, top = 2.3 + Math.sqrt(Math.max(0, 1 - (x / 1.15) ** 2)) * 0.5; return [x, v * top, Math.sin(u * 10 + v * 6) * 0.03]; }), glow);
  return B.done({ foot: 0.5, footprint: [[-1.15, 0, 0.35], [1.15, 0, 0.35]] });
};
DEF.lily = () => {
  const B = build(), pad = B.mat(M.leaf('#3f8a3a', { sss: 0.3 })), pet = B.mat({ col: '#ffb8d8', col2: '#ffffff', rough: 0.5, spec: 0.3, sss: 0.6 }), ct = B.mat(M.paint('#ffd23f'));
  B.put(sheet(24, 4, (u, v) => { const a = 0.25 + u * (Math.PI * 2 - 0.5), r = v * 0.45; return [Math.cos(a) * r, 0.02 + v * (1 - v) * 0.04, Math.sin(a) * r]; }), pad);
  for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2; B.put(sheet(4, 4, (u, v) => { const w = Math.sin(u * Math.PI) * 0.06, d = v * 0.16; return [0.05 + Math.cos(a) * d - Math.sin(a) * (u - 0.5) * w * 2, 0.06 + v * v * 0.1, 0.05 + Math.sin(a) * d + Math.cos(a) * (u - 0.5) * w * 2]; }), pet); }
  B.put(sphere(0.035, 0.03, 0.035, { segs: 8, rings: 6 }).translate(0.05, 0.08, 0.05), ct);
  return B.done({ foot: 0.01 });
};
DEF.campfire = () => {
  const B = build(), st = B.mat(M.stone('#7a7480')), lg = B.mat(M.bark('#5a3a20')), ch = B.mat({ col: '#2a1a12', em: '#ff5a10', emK: 0.4, rough: 1 });
  const f1 = B.mat(M.glow('#ff6a1a', 2.6, { sss: 1 })), f2 = B.mat(M.glow('#ffd04a', 3.2));
  for (let i = 0; i < 9; i++) { const a = (i / 9) * Math.PI * 2; B.put(blob(0.11, 0.08, 0.1, i, { amp: 0.2, flatBottom: 0.3 }).translate(Math.cos(a) * 0.42, 0.05, Math.sin(a) * 0.42), st); }
  for (let i = 0; i < 4; i++) { const a = (i / 4) * Math.PI * 2 + 0.3; B.put(rod([Math.cos(a) * 0.32, 0.03, Math.sin(a) * 0.32], [Math.cos(a) * 0.02, 0.38, Math.sin(a) * 0.02], 0.045), lg); }
  B.put(blob(0.25, 0.04, 0.25, 4, { amp: 0.2 }).translate(0, 0.02, 0), ch);
  B.put(lathe([[0.17, 0.05], [0.15, 0.25], [0.06, 0.55], [0, 0.72]], 10).displace((p) => [Math.sin(p[1] * 9) * 0.03, 0, Math.cos(p[1] * 7) * 0.03]), f1);
  B.put(lathe([[0.09, 0.05], [0.08, 0.2], [0.03, 0.4], [0, 0.48]], 8), f2);
  return B.done({ foot: 0.5 });
};
DEF.pot = ({ leaf = '#4f9a3f' } = {}) => {
  const B = build(), tc = B.mat(M.ceramic('#c46a3c')), dirt = B.mat(M.soil()), lf = B.mat(M.leaf(leaf));
  B.put(lathe([[0.16, 0], [0.22, 0.32], [0.26, 0.34], [0.26, 0.4], [0.22, 0.4], [0.2, 0.36], [0, 0.36]], 18), tc);
  B.put(cylinder(0.205, 0.02, 16, { bevel: 0 }).translate(0, 0.34, 0), dirt);
  B.put(blob(0.26, 0.2, 0.24, 5, { amp: 0.2 }).translate(0, 0.52, 0).tint(topLit(0.3)), lf);
  return B.done({ foot: 0.24 });
};
DEF.table = () => {
  const B = build(), wd = B.mat(M.wood('#a0703c', { axis: 0 }));
  B.put(cylinder(0.6, 0.06, 24).translate(0, 0.62, 0), wd);
  B.put(lathe([[0.3, 0], [0.28, 0.04], [0.07, 0.08], [0.05, 0.6], [0.12, 0.62]], 14, { capTop: false }), wd);
  return B.done({ foot: 0.35 });
};
DEF.jar = () => {
  const B = build(), gl = B.mat(M.glass('#e8f4ff')), hn = B.mat({ col: '#e89a20', em: '#7a3a00', emK: 0.3, rough: 0.1, spec: 1, sss: 0.7 }), lid = B.mat(M.paint('#e5484d'));
  B.put(lathe([[0.15, 0.01], [0.16, 0.25], [0, 0.25]], 16), hn);
  B.put(lathe([[0.17, 0], [0.18, 0.05], [0.18, 0.36], [0.13, 0.42], [0.13, 0.46], [0, 0.46]], 18, { capTop: false }), gl);
  B.put(cylinder(0.15, 0.06, 16).translate(0, 0.44, 0), lid);
  return B.done({ foot: 0.18 });
};
DEF.arch = () => {
  const B = build(), wd = B.mat(M.wood('#8a5a34')), lf = B.mat(M.leaf('#4f9a3f')), fl = B.mat(M.plastic('#ff8fb6', { rough: 0.5 }));
  for (const sx of [-1, 1]) B.put(box(0.12, 1.6, 0.12, 0.02).translate(sx * 0.65, 0, 0), wd);
  B.put(tube((t) => [Math.cos(Math.PI - t * Math.PI) * 0.65, 1.6 + Math.sin(t * Math.PI) * 0.45, 0], 0.06, { steps: 20, segs: 8 }), wd);
  const r = rng(9);
  for (let i = 0; i < 10; i++) { const t = i / 9, a = Math.PI - t * Math.PI; const x = Math.cos(a) * 0.65, y = 1.6 + Math.sin(a) * 0.45; B.put(blob(0.14, 0.12, 0.12, i, { amp: 0.25, segs: 10, rings: 8 }).translate(x, y, 0), lf); if (r() < 0.5) B.put(sphere(0.045, 0.045, 0.045, { segs: 6, rings: 5 }).translate(x, y + 0.08, -0.1), fl); }
  return B.done({ foot: 0.3, footprint: [[-0.65, 0, 0.18], [0.65, 0, 0.18]] });
};
DEF.hurdle = ({ w = 1.3 } = {}) => {
  const B = build(), wh = B.mat(M.paint('#f4f4f4')), red = B.mat(M.paint('#e5484d', { stripes: { axis: 0, freq: 5 / (w / 1.3), col: '#f4f4f4' } }));
  const hw = w / 2 - 0.05, posts = w > 1.8 ? [-hw, 0, hw] : [-hw, hw];
  for (const x of posts) { B.put(box(0.06, 0.6, 0.06, 0.015).translate(x, 0, 0), wh); B.put(box(0.06, 0.04, 0.4, 0.015).translate(x, 0, 0), wh); }
  B.put(box(w, 0.12, 0.04, 0.02).translate(0, 0.48, 0), red);
  return B.done({ foot: 0.3, footprint: posts.map((x) => [x, 0, 0.2]) });
};
DEF.lowbar = ({ w = 1.44 } = {}) => {
  const B = build(), wh = B.mat(M.paint('#f4f4f4')), bar = B.mat(M.paint('#3fa0ff', { stripes: { axis: 0, freq: 5 / (w / 1.44), col: '#f4f4f4' } })), hgt = w > 1.8 ? 0.62 : 0.36;
  for (const sx of [-1, 1]) B.put(lathe([[0.12, 0], [0.12, 0.03], [0.035, 0.05], [0.03, hgt + 0.06], [0, hgt + 0.07]], 10).translate(sx * w / 2, 0, 0), wh);
  B.put(rod([-w / 2 - 0.02, hgt, 0], [w / 2 + 0.02, hgt, 0], 0.035), bar);
  return B.done({ foot: 0.3, footprint: [[-w / 2, 0, 0.15], [w / 2, 0, 0.15]] });
};
// ----- the obstacle course's other obstacles (made to the track's width, w) -----
DEF.logjump = ({ w = 2.6, seed = 1 } = {}) => {
  const B = build(), bark = B.mat(M.bark('#6b4a2e')), end = B.mat(M.wood('#c79a62', { axis: 0, col2: '#8a5a34' })), moss = B.mat(M.leaf('#5a8a3a', { tex: 'grass' }));
  B.put(tube(curve([-w / 2, 0.24, 0], [0, 0.27, 0.06], [w / 2, 0.23, 0]), (t) => 0.24 - 0.03 * Math.sin(t * Math.PI), { steps: 14, segs: 16, caps: false }), bark);
  for (const sd of [-1, 1]) B.put(cylinder(0.22, 0.02, 16, { bevel: 0 }).rotateZ(Math.PI / 2).translate(sd * w / 2 + (sd < 0 ? 0.01 : -0.01), 0.24, 0), end);
  B.put(blob(0.3, 0.08, 0.18, seed, { amp: 0.3 }).translate(w * 0.15, 0.46, 0), moss);
  return B.done({ foot: 0.4, footprint: [[-w / 3, 0, 0.3], [0, 0, 0.3], [w / 3, 0, 0.3]] });
};
DEF.hay = ({ w = 2.6 } = {}) => {
  const B = build(), hay = B.mat({ col: '#e0c070', col2: '#a88a40', tex: 'grass', texS: 1.5, rough: 1, spec: 0.05, bump: 1.4 }), twine = B.mat(M.fabric('#8a5a34'));
  const n = Math.max(2, Math.round(w / 0.85)), bw = w / n;
  for (let i = 0; i < n; i++) { const x = -w / 2 + bw * (i + 0.5); B.put(box(bw - 0.04, 0.42, 0.5, 0.06).translate(x, 0, 0).rotateY((i % 2 ? 1 : -1) * 0.03), hay); for (const dx of [-0.2, 0.2]) B.put(box(0.03, 0.44, 0.52, 0.01).translate(x + dx * bw, 0, 0), twine); }
  return B.done({ foot: 0.4, footprint: [[-w / 3, 0, 0.35], [0, 0, 0.35], [w / 3, 0, 0.35]] });
};
DEF.bunting = ({ w = 2.6 } = {}) => {
  const B = build(), wd = B.mat(M.wood('#8a5a34')), rope = B.mat(M.fabric('#f4ead8'));
  const flags = ['#e5484d', '#ffd23f', '#3fa0ff', '#3fb26a', '#ff8fb6'].map((c) => B.mat(M.fabric(c, { sss: 0.5 })));
  const hgt = 0.66;
  for (const sx of [-1, 1]) B.put(lathe([[0.1, 0], [0.06, 0.05], [0.05, hgt + 0.25], [0, hgt + 0.27]], 10).translate(sx * w / 2, 0, 0), wd);
  const sag = (t) => hgt + 0.18 - Math.sin(t * Math.PI) * 0.12;
  B.put(tube((t) => [-w / 2 + w * t, sag(t), 0], 0.012, { steps: 20, segs: 5 }), rope);
  const n = Math.round(w / 0.2);
  for (let i = 1; i < n; i++) { const t = i / n, x = -w / 2 + w * t, y = sag(t); B.put(sheet(2, 2, (u, v) => [x + (u - 0.5) * 0.14 * (1 - v), y - v * 0.17, Math.sin(i + v) * 0.02]), flags[i % flags.length]); }
  return B.done({ foot: 0.3, footprint: [[-w / 2, 0, 0.15], [w / 2, 0, 0.15]] });
};
// a gap across the track, too long to jump: a single plank bridges it, in one lane (plank: its place across, -1…1)
DEF.pit = ({ w = 2.6, len = 3.4, plank = 0 } = {}) => {
  const B = build(), dirt = B.mat({ ...M.soil('#6a4428'), cull: true }), deep = B.mat({ col: '#1a1008', rough: 1, spec: 0 }), lip = B.mat(M.grass('#4f9a3f')), wd = B.mat(M.wood('#a0703c', { axis: 2 }));
  const hw = w / 2, hl = len / 2, D = 0.9;
  // the inside walls (facing in, so only the far ones show from above) and the dark bottom
  const wall = (a, b, n) => { const m = sheet(2, 3, (u, v) => [a[0] + (b[0] - a[0]) * u, -v * D, a[1] + (b[1] - a[1]) * u]); m.each((p, nn) => { nn[0] = n[0]; nn[1] = 0; nn[2] = n[1]; }); m.tint((p) => 1 - Math.min(0.85, -p[1] * 0.9)); return m; };
  B.put(wall([-hw, -hl], [hw, -hl], [0, 1]), dirt); B.put(wall([hw, hl], [-hw, hl], [0, -1]), dirt);
  B.put(wall([-hw, hl], [-hw, -hl], [1, 0]), dirt); B.put(wall([hw, -hl], [hw, hl], [-1, 0]), dirt);
  B.put(sheet(1, 1, (u, v) => [-hw + w * u, -D, -hl + len * v]), deep);
  // the ground round it (not drawn: it hides the inside of the hole wherever the ground is in front of it)
  const G = 4.5, hole = B.mat({ col: '#000000', hole: true });
  for (const [x0, z0, x1, z1] of [[-hw - G, -hl - G, hw + G, -hl], [-hw - G, hl, hw + G, hl + G], [-hw - G, -hl, -hw, hl], [hw, -hl, hw + G, hl]]) B.put(sheet(1, 1, (u, v) => [x0 + (x1 - x0) * u, -0.004, z0 + (z1 - z0) * v]), hole);
  // a ragged grass edge round the hole
  for (const [a, b] of [[[-hw, -hl], [hw, -hl]], [[hw, -hl], [hw, hl]], [[hw, hl], [-hw, hl]], [[-hw, hl], [-hw, -hl]]]) B.put(tube((t) => [a[0] + (b[0] - a[0]) * t, 0.0, a[1] + (b[1] - a[1]) * t], (t) => 0.05 + 0.02 * Math.sin(t * 23), { steps: 12, segs: 6 }), lip);
  // the plank (no rails: a wobble and you're in)
  const px = plank * (hw - 0.35);
  B.put(box(0.5, 0.06, len + 0.5, 0.015).translate(px, 0.01, 0), wd);
  // (its ends dug into the ground, a board across each)
  for (const z of [-hl - 0.12, hl + 0.12]) B.put(box(0.62, 0.05, 0.12, 0.01).translate(px, 0.005, z), wd);
  return B.done({ foot: 0.01, footprint: [] });
};
// the shelter in every yard: a deck, four posts, a bench at the back and a peaked, shingled roof
// (drawn in two halves round whoever's inside: the floor, bench and back posts behind them, the roof and front posts in front)
DEF.gazebo = ({ snow = false, r = 1 } = {}) => {
  const B = build(), wd = B.mat({ ...M.wood('#a07850', { axis: 0 }), layer: 'back' }), post = B.mat(M.wood('#7a5434', { axis: 1 }));
  const roof = B.mat({ ...(snow ? { col: '#eef4ff', rough: 0.6, spec: 0.3, sss: 0.3, vary: 0.05 } : { col: '#b0473a', col2: '#7c2c24', tex: 'stone', texS: 5, rough: 0.7, spec: 0.2 }), layer: 'front' });
  const trimF = B.mat({ ...M.wood('#6e4e32', { axis: 0 }), layer: 'front' }), gold = B.mat({ ...M.metal('#ffd23f', { rough: 0.25 }), layer: 'front' }), bench = B.mat({ ...M.wood('#8a6440', { axis: 0 }), layer: 'back' });
  const rz = r * 0.8, hP = 1.6, hR = 2.35;
  for (let i = 0; i < 6; i++) B.put(box(2 * r + 0.1, 0.07, (2 * rz + 0.1) / 6 - 0.02, 0.012).translate(0, 0, -rz - 0.05 + (2 * rz + 0.1) * (i + 0.5) / 6), wd);
  for (const [sx, sz] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) B.put(box(0.11, hP, 0.11, 0.02).translate(sx * r * 0.92, 0.07, sz * rz * 0.92), post);
  // the bench at the back
  B.put(box(r * 1.4, 0.05, 0.28, 0.015).translate(0, 0.45, rz * 0.68), bench);
  for (const sx of [-0.6, 0.6]) B.put(box(0.05, 0.4, 0.25, 0.01).translate(sx * r, 0.07, rz * 0.68), bench);
  // the beams under the roof, and the roof: four sloping faces with shingle rows
  for (const [a, b] of [[[-r, -rz], [r, -rz]], [[r, -rz], [r, rz]], [[r, rz], [-r, rz]], [[-r, rz], [-r, -rz]]]) B.put(rod([a[0] * 0.95, hP + 0.04, a[1] * 0.95], [b[0] * 0.95, hP + 0.04, b[1] * 0.95], 0.045, { segs: 6 }), trimF);
  const e = 1.12, apex = [0, hR, 0];
  const corners = [[-r * e, -rz * e], [r * e, -rz * e], [r * e, rz * e], [-r * e, rz * e]];
  for (let i = 0; i < 4; i++) {
    const [a, b] = [corners[i], corners[(i + 1) % 4]];
    const face = sheet(8, 6, (u, v) => { const x = a[0] + (b[0] - a[0]) * u, z = a[1] + (b[1] - a[1]) * u; const y = hP + 0.05 + (hR - hP) * v; return [x * (1 - v) + apex[0] * v, y - (Math.floor(v * 6) % 2 ? 0.0 : 0.012) - Math.sin(u * Math.PI) * 0.03 * (1 - v), z * (1 - v) + apex[2] * v]; });
    face.tint((p) => 0.92 + 0.1 * ((Math.floor((p[1] - hP) * 14) % 2)));
    B.put(face, roof);
    B.put(rod([a[0], hP + 0.05, a[1]], [0, hR, 0], 0.03, { segs: 6 }), trimF);
  }
  B.put(sphere(0.08, 0.08, 0.08, { segs: 10, rings: 7 }).translate(0, hR + 0.08, 0), gold);
  return B.done({ foot: 1.1, footprint: [[0, 0, 1.1]] });
};
DEF.stump = ({ seed }) => {
  const B = build(), bark = B.mat(M.bark('#6b4a2e')), top = B.mat(M.wood('#c79a62', { axis: 1, col2: '#8a5a34' }));
  const s = lathe([[0.36, 0], [0.3, 0.06], [0.27, 0.15], [0.26, 0.38]], 16, { capBottom: false, capTop: false });
  s.displace((p) => { const k = (noise3(p[0] * 4 + seed, p[1] * 3, p[2] * 4) - 0.5) * 0.12; return [p[0] * k, 0, p[2] * k]; });
  B.put(s, bark);
  B.put(cylinder(0.26, 0.02, 16, { bevel: 0 }).translate(0, 0.37, 0), top);
  for (let i = 0; i < 4; i++) { const a = (i / 4) * Math.PI * 2 + 0.4; B.put(tube(curve([Math.cos(a) * 0.22, 0.12, Math.sin(a) * 0.22], [Math.cos(a) * 0.4, 0.06, Math.sin(a) * 0.4], [Math.cos(a) * 0.5, 0, Math.sin(a) * 0.5]), (t) => 0.07 - t * 0.05, { steps: 6, segs: 8 }), bark); }
  return B.done({ foot: 0.4 });
};
DEF.pier = () => {
  const B = build(), wd = B.mat(M.wood('#8a6a44', { axis: 2 })), post = B.mat(M.wood('#5a4028'));
  for (let i = 0; i < 6; i++) B.put(box(0.2, 0.05, 1.6, 0.015).translate(-0.55 + i * 0.22, 0.32, 0), wd);
  for (const sx of [-0.6, 0.6]) for (const sz of [-0.7, 0.7]) B.put(cylinder(0.07, 0.42, 10).translate(sx, 0, sz), post);
  return B.done({ foot: 0.6, footprint: [[0, -0.5, 0.45], [0, 0.5, 0.45]] });
};
DEF.cone = () => {
  const B = build(), or = B.mat(M.plastic('#ff7a1a', { stripes: { axis: 1, freq: 9, col: '#f4f4f4' } })), base = B.mat(M.plastic('#ff7a1a'));
  B.put(box(0.42, 0.04, 0.42, 0.04), base);
  B.put(lathe([[0.16, 0.04], [0.025, 0.6], [0, 0.61]], 16, { capBottom: false }), or);
  return B.done({ foot: 0.22 });
};
DEF.dummy = ({ accent = '#e5484d' }) => {
  const B = build(), wd = B.mat(M.wood('#8a5a34')), sack = B.mat({ col: '#c8a878', col2: '#9a7a48', tex: 'fabric', texS: 0.5, rough: 1, bump: 1.2 }), tg = B.mat(M.paint(accent));
  B.put(cylinder(0.05, 1.2, 10), wd);
  B.put(box(0.5, 0.05, 0.5, 0.02), wd);
  B.put(blob(0.22, 0.32, 0.2, 2, { amp: 0.06 }).translate(0, 0.85, 0), sack);
  B.put(sphere(0.15, 0.15, 0.15, { segs: 14, rings: 10 }).translate(0, 1.3, 0), sack);
  B.put(rod([-0.4, 0.98, 0], [0.4, 0.98, 0], 0.035), wd);
  for (const r of [0.13, 0.08, 0.035]) B.put(cylinder(r, 0.012 + (0.13 - r) * 0.05, 18, { bevel: 0 }).rotateX(Math.PI / 2).translate(0, 0.85, -0.2 - (0.13 - r) * 0.05), r === 0.08 ? sack : tg);
  return B.done({ foot: 0.3 });
};
DEF.can = () => {
  const B = build(), mt = B.mat(M.metal('#c8ccd4', { axis: 1 })), lab = B.mat(M.paint('#e5484d', { stripes: { axis: 1, freq: 20, col: '#ffffff' } }));
  B.put(lathe([[0.13, 0], [0.14, 0.02], [0.14, 0.05]], 18, { capBottom: true, capTop: false }), mt);
  B.put(cylinder(0.142, 0.22, 18, { bevel: 0 }).translate(0, 0.05, 0), lab);
  B.put(lathe([[0.14, 0.27], [0.14, 0.3], [0.13, 0.32], [0, 0.31]], 18, { capBottom: false }), mt);
  return B.done({ foot: 0.15 });
};
DEF.target = ({ accent = '#e5484d' }) => {
  const B = build(), wd = B.mat(M.wood('#8a5a34')), cols = [B.mat(M.paint('#f4f4f4')), B.mat(M.paint(accent)), B.mat(M.paint('#ffd23f'))];
  for (const sx of [-1, 1]) B.put(rod([sx * 0.35, 0, 0.15], [sx * 0.12, 1.0, 0], 0.035), wd);
  B.put(rod([0, 0, 0.45], [0, 0.95, 0.03], 0.035), wd);
  const rings = [0.5, 0.4, 0.3, 0.2, 0.1];
  rings.forEach((r, i) => B.put(cylinder(r, 0.05 + i * 0.006, 28, { bevel: i ? 0 : 0.3 }).rotateX(Math.PI / 2).translate(0, 0.85, -0.02 - i * 0.006), cols[i === 4 ? 2 : i % 2]));
  return B.done({ foot: 0.35 });
};
DEF.bed = ({ accent = '#e5484d' }) => {
  const B = build(), cush = B.mat(M.fabric(accent)), pad = B.mat(M.fabric('#f4ead8'));
  B.put(tube((t) => [Math.cos(t * Math.PI * 2) * 0.45, 0.13, Math.sin(t * Math.PI * 2) * 0.36], 0.13, { steps: 36, segs: 14, caps: false }), cush);
  B.put(blob(0.42, 0.06, 0.33, 3, { amp: 0.04, flatBottom: 0.5 }).translate(0, 0.05, 0), pad);
  return B.done({ foot: 0.55 });
};
DEF.fossilmachine = ({ accent = '#3fb26a' }) => {
  const B = build(), body = B.mat(M.plastic('#e8ecf2', { rough: 0.3 })), dark = B.mat(M.metal('#3a4250', { rough: 0.4 })), gl = B.mat(M.glass('#bff4e0', { alpha: 0.25 })), fl = B.mat({ col: '#7affc8', em: '#2aa070', emK: 0.6, alpha: 0.4, rough: 0.1 });
  const fos = B.mat(M.stone('#b8a080', { texS: 3 })), led = B.mat(M.glow(accent, 2.4)), red = B.mat(M.glow('#ff5a5a', 2)), scr = B.mat(M.glow('#5ae0ff', 1.3, { rough: 0.1 }));
  B.put(box(1.3, 0.35, 0.8, 0.08), body);
  B.put(box(0.5, 1.1, 0.7, 0.08).translate(0.42, 0.33, 0), body);
  B.put(box(0.36, 0.26, 0.04, 0.02).rotateX(0.2).translate(0.42, 1.0, -0.36), scr);
  for (let i = 0; i < 3; i++) B.put(cylinder(0.035, 0.03, 10).rotateX(Math.PI / 2).translate(0.3 + i * 0.12, 0.62, -0.36), i === 1 ? red : led);
  // the revival capsule: a glass tube of glowing liquid with a fossil inside
  B.put(cylinder(0.28, 0.1, 20).translate(-0.3, 0.35, 0), dark);
  B.put(cylinder(0.24, 0.85, 20, { bevel: 0 }).translate(-0.3, 0.45, 0), fl);
  B.put(lathe([[0.26, 0.45], [0.26, 1.3], [0, 1.3]], 22, { capBottom: false }), gl);
  B.put(cylinder(0.29, 0.12, 20).translate(-0.3, 1.3, 0), dark);
  B.put(blob(0.12, 0.09, 0.08, 4, { amp: 0.2 }).rotateZ(0.4).translate(-0.3, 0.85, 0), fos);
  B.put(tube(curve([-0.3, 1.42, 0], [-0.1, 1.6, 0], [0.3, 1.5, 0.1], [0.42, 1.42, 0.1]), 0.05, { steps: 12, segs: 8 }), dark);
  return B.done({ foot: 0.7 });
};
DEF.incubator = ({ accent = '#ff8fb6' }) => {
  const B = build(), base = B.mat(M.plastic('#f4f0e8', { rough: 0.3 })), trim = B.mat(M.plastic(accent)), gl = B.mat(M.glass('#fff4e8', { alpha: 0.22 })), egg = B.mat({ col: '#f8f2e4', rough: 0.35, spec: 0.5, sss: 0.4 }), warm = B.mat(M.glow('#ffb060', 1.6)), nest = B.mat(M.fabric('#e8d0a0', { bump: 1.2 }));
  B.put(lathe([[0.42, 0], [0.44, 0.05], [0.44, 0.28], [0.4, 0.32], [0, 0.32]], 24), base);
  B.put(tube((t) => [Math.cos(t * Math.PI * 2) * 0.43, 0.18, Math.sin(t * Math.PI * 2) * 0.43], 0.025, { steps: 32, segs: 6, caps: false }), trim);
  B.put(tube((t) => [Math.cos(t * Math.PI * 2) * 0.36, 0.33, Math.sin(t * Math.PI * 2) * 0.36], 0.03, { steps: 32, segs: 6, caps: false }), warm);
  B.put(blob(0.3, 0.06, 0.3, 2, { amp: 0.15 }).translate(0, 0.35, 0), nest);
  // the egg, with a few spots, under a glass dome
  const e = lathe([[0, 0], [0.12, 0.04], [0.16, 0.14], [0.14, 0.27], [0.08, 0.35], [0, 0.37]], 18).translate(0, 0.36, 0);
  e.tint((p) => (noise3(p[0] * 18, p[1] * 18, p[2] * 18) > 0.7 ? toward('#f8f2e4', accent, 0.9) : 1));
  B.put(e, egg);
  B.put(sphere(0.38, 0.42, 0.38, { segs: 24, rings: 14 }).each((p) => { if (p[1] < 0) p[1] *= 0.02; }).translate(0, 0.33, 0), gl);
  return B.done({ foot: 0.44 });
};
DEF.blender = ({ accent = '#e5484d' }) => {
  const B = build(), stl = B.mat(M.metal('#b8c0cc', { rough: 0.45, spec: 0.55 })), dark = B.mat(M.metal('#3a4048', { rough: 0.45 })), body = B.mat(M.plastic(accent));
  const cols = ['#e5484d', '#3fa0ff', '#ffd23f', '#3fb26a'].map((c) => B.mat(M.plastic(c)));
  B.put(lathe([[0.42, 0], [0.42, 0.05], [0.3, 0.1], [0.24, 0.42], [0.3, 0.46]], 24, { capTop: false }), body);
  // the steel bowl the berries spin round in
  B.put(lathe([[0.12, 0.44], [0.4, 0.5], [0.62, 0.64], [0.66, 0.72], [0.62, 0.72], [0.56, 0.66], [0.36, 0.56], [0.1, 0.52], [0, 0.52]], 32), stl);
  // (a few berries waiting in the bowl)
  for (let i = 0; i < 5; i++) { const a = i * 1.3; B.put(sphere(0.045, 0.045, 0.045, { segs: 8, rings: 6 }).translate(Math.cos(a) * 0.3, 0.6 + 0.02 * (i % 2), Math.sin(a) * 0.3), cols[i % 4]); }
  B.put(tube((t) => [Math.cos(t * Math.PI * 2) * 0.65, 0.72, Math.sin(t * Math.PI * 2) * 0.65], 0.03, { steps: 48, segs: 8, caps: false }), dark);
  B.put(lathe([[0.06, 0.5], [0.05, 0.68], [0.08, 0.72], [0, 0.76]], 12), dark);
  B.put(box(0.36, 0.02, 0.06, 0.01).translate(0.16, 0.7, 0), body);
  // the four stations, each with its own colour
  for (let i = 0; i < 4; i++) { const a = (i / 4) * Math.PI * 2 + Math.PI / 4; B.put(box(0.16, 0.06, 0.1, 0.02).rotateY(-a).translate(Math.cos(a) * 0.68, 0.69, Math.sin(a) * 0.68), cols[i]); }
  return B.done({ foot: 0.45 });
};

// the farm and the shop's own things (a few)
DEF.crate = ({ accent = '#c0306a' }) => {
  const B = build(), wd = B.mat(M.wood('#b08050', { axis: 0 })), fr = B.mat(M.plastic(accent, { rough: 0.3 }));
  B.put(box(0.7, 0.42, 0.5, 0.02), wd);
  for (let i = 0; i < 9; i++) B.put(sphere(0.08, 0.08, 0.08, { segs: 10, rings: 7 }).translate(-0.22 + (i % 3) * 0.22, 0.45, -0.13 + Math.floor(i / 3) * 0.13), fr);
  return B.done({ foot: 0.45 });
};
DEF.scarecrow = ({ accent = '#e5484d' }) => {
  const B = build(), wd = B.mat(M.wood('#8a5a34')), sack = B.mat({ col: '#d8b878', col2: '#9a7a48', tex: 'fabric', texS: 0.5, rough: 1, bump: 1.2 }), shirt = B.mat(M.fabric(accent)), hat = B.mat(M.fabric('#6a4a2a'));
  B.put(cylinder(0.05, 1.9, 10), wd);
  B.put(rod([-0.6, 1.3, 0], [0.6, 1.3, 0], 0.04), wd);
  B.put(blob(0.25, 0.32, 0.18, 4, { amp: 0.06 }).translate(0, 1.15, 0), shirt);
  B.put(sphere(0.17, 0.18, 0.16, { segs: 16, rings: 12 }).translate(0, 1.65, 0), sack);
  B.put(lathe([[0.3, 1.78], [0.3, 1.8], [0.13, 1.82], [0.12, 2.0], [0, 2.02]], 16), hat);
  return B.done({ foot: 0.2 });
};

// how tall each stands in the scenes, in yard units (as the pictures were)
const HEIGHT = { tree: 3.6, pine: 4, snowpine: 3.8, palm: 3.8, bush: 0.95, rock: 0.95, lavarock: 0.95, mushroom: 0.6, glowshroom: 0.75, log: 0.55, cactus: 2, crystal: 1.7, stalagmite: 2, icespike: 1.5, spire: 2.8, kelp: 2.6, coral: 1.1, reed: 1.5, pillar: 2.2, lamppost: 3.4, bench: 0.95, hydrant: 0.75, deadtree: 4, grave: 0.8, pumpkin: 0.6, monolith: 3.2, ring: 2, cube: 1.4, orb: 1.4, pyramid: 1.4, lantern: 1.8, sunflower: 2.1, barn: 3.6, house: 4.4, stall: 3.2,
  // (the things you build are made at their own size: a small creature is about 1 tall)
};
DEF.sunflower = ({ seed }) => {
  const B = build(), r = rng(seed), st = B.mat(M.leaf('#4f8a2a', { tex: null, sss: 0.2 })), lf = B.mat(M.leaf('#4f9a3a')), pet = B.mat({ col: '#ffc21a', col2: '#ff9a10', rough: 0.55, spec: 0.2, sss: 0.5, vary: 0.1 }), ctr = B.mat({ col: '#5a3418', col2: '#2a1808', tex: 'soil', rough: 0.9, bump: 1.4, texS: 3 });
  const lean = (r() - 0.5) * 0.2, top = [lean, 1.95, 0.05];
  B.put(tube(curve([0, 0, 0], [0, 1, 0], top), (t) => 0.04 - t * 0.012, { steps: 10, segs: 8 }), st);
  for (const [y, sd] of [[0.7, 1], [1.15, -1]]) B.put(sheet(8, 4, (u, v) => { const w = Math.sin(u * Math.PI) * 0.14, out = u * 0.42; return [sd * out, y + Math.sin(u * Math.PI) * 0.12 - u * u * 0.08, (v - 0.5) * w * 2]; }), lf);
  // the head, facing the sun (and the camera, a little)
  const head = new Mesh();
  head.add(cylinder(0.17, 0.06, 20, { bevel: 0.3 }).rotateX(-Math.PI / 2 + 0.25));
  B.put(head.translate(...top), ctr);
  for (let i = 0; i < 18; i++) { const a = (i / 18) * Math.PI * 2, rr = 0.17; B.put(sheet(3, 4, (u, v) => { const w = Math.sin(u * Math.PI) * 0.055, d = rr + v * 0.16; const x = Math.cos(a) * d - Math.sin(a) * (u - 0.5) * w * 2, y = Math.sin(a) * d + Math.cos(a) * (u - 0.5) * w * 2; return [top[0] + x, top[1] + y * 0.97, top[2] - 0.05 - v * 0.03 + y * 0.24]; }), pet); }
  return B.done({ foot: 0.12 });
};
DEF.barn = () => {
  const B = build(), wall = B.mat(M.wood('#b8402c', { axis: 1, col2: '#8a2a1a', bump: 0.8 })), trim = B.mat(M.paint('#f4ece0')), roof = B.mat({ col: '#5a4a48', col2: '#3a2e2c', tex: 'stone', texS: 3, rough: 0.8, spec: 0.15 }), door = B.mat(M.wood('#8a2a1a', { axis: 1 })), win = B.mat(M.glow('#ffd48a', 0.4, { rough: 0.1, spec: 1 }));
  const W2 = 1.6, D2 = 1.3, H1 = 1.7, H2 = 2.9;
  // the walls with a gambrel (barn) roof line
  const prof = [[-W2, 0], [W2, 0], [W2, H1], [W2 * 0.62, H1 + 0.75], [0, H2], [-W2 * 0.62, H1 + 0.75], [-W2, H1]];
  for (const sz of [-1, 1]) { const m = new Mesh(); const c0 = m.vert([0, H1 * 0.6, sz * D2]); const ids = prof.map(([x, y]) => m.vert([x, y, sz * D2])); for (let i = 0; i < ids.length; i++) m.tri(c0, ids[i], ids[(i + 1) % ids.length]); B.put(m.flat(), wall); }
  B.put(box(W2 * 2, H1, D2 * 2 - 0.02, 0.01), wall);
  // the roof: four slopes, overhanging a little
  const slope = (a, b) => sheet(1, 1, (u, v) => { const p = a.map((x, i) => x + (b[i] - x) * u); return [p[0], p[1], (v - 0.5) * (D2 * 2 + 0.3)]; });
  B.put(slope([-W2 - 0.12, H1 - 0.08], [-W2 * 0.62, H1 + 0.75]), roof); B.put(slope([-W2 * 0.62, H1 + 0.75], [0, H2 + 0.04]), roof); B.put(slope([0, H2 + 0.04], [W2 * 0.62, H1 + 0.75]), roof); B.put(slope([W2 * 0.62, H1 + 0.75], [W2 + 0.12, H1 - 0.08]), roof);
  B.put(box(1.1, 1.3, 0.06, 0.02).translate(0, 0, -D2 - 0.02), door);
  for (const [a, b] of [[[-0.55, 0, -D2 - 0.06], [0.55, 1.3, -D2 - 0.06]], [[0.55, 0, -D2 - 0.06], [-0.55, 1.3, -D2 - 0.06]]]) B.put(rod(a, b, 0.035, { segs: 6 }), trim);
  B.put(box(1.2, 0.08, 0.08, 0.02).translate(0, 1.3, -D2 - 0.05), trim);
  B.put(box(0.5, 0.42, 0.06, 0.02).translate(0, 1.95, -D2 - 0.02), win);
  for (const x of [-W2, W2]) B.put(box(0.08, H1, 0.08, 0.02).translate(x, 0, -D2), trim);
  return B.done({ foot: 1.6, footprint: [[-1, 0, 1.1], [1, 0, 1.1]] });
};
DEF.house = ({ seed }) => {
  const B = build(), wallCol = ['#f0e4cc', '#d8e8f4', '#f4d8d0'][seed % 3], roofCol = ['#b84a3a', '#3a6aa0', '#5a7a3a'][seed % 3];
  const wall = B.mat(M.paint(wallCol, { rough: 0.8, spec: 0.1, vary: 0.06 })), roof = B.mat({ col: roofCol, col2: shade(roofCol, -0.35), tex: 'stone', texS: 4, rough: 0.7, spec: 0.2 }), wd = B.mat(M.wood('#7a5032')), win = B.mat(M.glow('#ffe0a0', 0.35, { rough: 0.05, spec: 1.2 })), st = B.mat(M.stone('#9a9090'));
  B.put(box(2.4, 1.8, 1.8, 0.03), wall);
  for (const sz of [-1, 1]) { const m = new Mesh(); const a = m.vert([-1.2, 1.8, sz * 0.9]), b = m.vert([1.2, 1.8, sz * 0.9]), c = m.vert([0, 2.9, sz * 0.9]); m.tri(a, b, c); B.put(m.flat(), wall); }
  for (const sd of [-1, 1]) B.put(box(1.62, 0.08, 2.1, 0.02).rotateZ(sd * 0.74).translate(sd * 0.62, 2.3, 0), roof);
  B.put(box(0.32, 0.9, 0.32, 0.02).translate(0.7, 2.2, 0.3), st);
  B.put(box(0.6, 1.1, 0.06, 0.02).translate(0, 0, -0.92), wd);
  for (const x of [-0.8, 0.8]) { B.put(box(0.5, 0.5, 0.05, 0.01).translate(x, 0.75, -0.92), win); B.put(box(0.6, 0.06, 0.1, 0.01).translate(x, 0.72, -0.94), wd); }
  return B.done({ foot: 1.4, footprint: [[0, 0, 1.4]] });
};
DEF.stall = ({ accent = '#e5484d' }) => {
  const B = build(), wd = B.mat(M.wood('#a0703c', { axis: 0 })), awn = B.mat(M.fabric(accent, { stripes: { axis: 0, freq: 4, col: '#f8f2e4' }, sss: 0.3 })), top = B.mat(M.wood('#c89a62', { axis: 0 }));
  const fr = ['#e5484d', '#ffd23f', '#3fb26a', '#ff8a2a', '#c0306a'].map((c) => B.mat(M.plastic(c, { rough: 0.35 })));
  B.put(box(2.6, 0.95, 0.9, 0.03), wd);
  B.put(box(2.7, 0.06, 1, 0.02).translate(0, 0.95, 0), top);
  for (const x of [-1.25, 1.25]) for (const z of [-0.4, 0.4]) B.put(box(0.1, 2.2, 0.1, 0.02).translate(x, 0, z), wd);
  // the striped awning, scalloped at the front
  B.put(sheet(24, 6, (u, v) => { const x = (u - 0.5) * 2.9, z = -0.75 + v * 1.25, y = 2.2 + v * 0.35 - (v < 0.08 ? Math.abs(Math.sin(u * Math.PI * 8)) * 0.12 * (1 - v / 0.08) : 0); return [x, y, z]; }), awn);
  // fruit piled on the counter
  const r = rng(5);
  for (let i = 0; i < 24; i++) { const x = -1.1 + (i % 12) * 0.2, z = -0.25 + Math.floor(i / 12) * 0.25; B.put(sphere(0.09, 0.09, 0.09, { segs: 10, rings: 7 }).translate(x + (r() - 0.5) * 0.05, 1.07 + r() * 0.03, z), fr[Math.floor(i / 5) % fr.length]); }
  return B.done({ foot: 1.3, footprint: [[0, 0, 1.3]] });
};
export const MODELS = new Set(Object.keys(DEF));
const built = new Map(), refs = new Map();
function refHeight(kind, f, opts) {
  const key = `${kind}|${JSON.stringify({ ...opts, seed: 1 })}`;
  if (!refs.has(key)) { let h = 0; try { h = f({ ...opts, seed: 1 }).mesh.bounds().hi[1]; } catch { h = 0; } refs.set(key, h); }
  return refs.get(key);
}
/** The model for a kind of thing (cached: the same kind with the same look is only built once). */
export function modelFor(kind, opts = {}) {
  const f = DEF[kind];
  if (!f) return null;
  const key = `${kind}|${JSON.stringify(opts)}`;
  if (built.has(key)) return built.get(key);
  let m = null;
  try { m = f({ seed: 1, ...opts }); } catch (e) { console.warn('[m3d]', kind, e); m = null; }
  if (m) {
    // scenery is turned a different way each time (by its seed), so no two look copied and pasted
    if (HEIGHT[kind] && !opts.fixed) { const a = ((opts.seed ?? 1) * 2.39996) % (Math.PI * 2); m.mesh.rotateY(a); if (m.footprint) m.footprint = m.footprint.map(([x, z, r]) => [x * Math.cos(a) + z * Math.sin(a), -x * Math.sin(a) + z * Math.cos(a), r]); }
    // the same size as the pictures they replace (so creatures still fit the slide, the hammock, the bed…)
    const tgt = HEIGHT[kind];
    // (one size for the whole kind, from its first look, so the others keep their own heights: a taller tree, a squat cactus)
    if (tgt && !opts.natural) { const refH = refHeight(kind, f, opts); if (refH > 0.05) { const k = (tgt * 0.92) / refH; m.mesh.scale(k); m.foot = (m.foot ?? 0.3) * k; if (m.footprint) m.footprint = m.footprint.map(([x, z, r]) => [x * k, z * k, r * k]); } }
    const { lo, hi } = m.mesh.bounds();
    m.h = hi[1]; m.lo = lo; m.hi = hi;
    // a few of its points for the shadow it casts on the ground (the yard works that out from the sun)
    const step = Math.max(1, Math.floor(m.mesh.p.length / 90));
    m.shadowV = m.mesh.p.filter((_, i) => i % step === 0).map((p) => p.slice());
  }
  built.set(key, m);
  if (built.size > 300) built.delete(built.keys().next().value);
  return m;
}
