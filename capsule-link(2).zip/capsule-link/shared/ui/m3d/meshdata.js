// A model turned into what the graphics card draws (gl.js) and what the creatures bump into (yard.js):
//   meshArrays(model) → { data: Float32Array (interleaved vertices), idx: Uint32Array, nOpaque, nGlass, nHole }
//   hitbox(model)     → { x0, z0, cs, nx, nz, off: Int32Array, iv: Float32Array } — solid spans [y0, y1] per column
// Runs in the models' worker, so building these never stutters the scene.
import { prep, surfaceOf } from './render.js';

// one vertex: position 3, normal 3, colour 3 (linear, the surface's own, with its pattern), material 4 (spec,
// shininess, metal, light through), glow 4 (rgb, opacity), extra 3 (rim light, which half, one-sided)
export const STRIDE = 20;
export function meshArrays(model) {
  const mesh = model.mesh, mats = model.mats.map(prep);
  const out = [], idxO = [], idxG = [], idxH = [];
  const vmap = new Map(); // `${vertex}|${material}` → new index
  const col = [0, 0, 0];
  const vert = (v, mi) => {
    const key = v * 64 + mi;
    let i = vmap.get(key);
    if (i != null) return i;
    const M = mats[mi] ?? mats[0], p = mesh.p[v], n = mesh.n[v], vc = mesh.c[v] ?? [1, 1, 1];
    surfaceOf(M, p, n, vc, col);
    const e = M.e ?? [0, 0, 0];
    const layer = M.layer === 'back' ? -1 : M.layer === 'front' ? 1 : 0;
    i = out.length / STRIDE;
    out.push(p[0], p[1], p[2], n[0], n[1], n[2], col[0], col[1], col[2],
      M.spec, M.shin, M.metal, M.sss, e[0], e[1], e[2], M.alpha, M.rim, layer, M.cull ? 1 : 0);
    vmap.set(key, i);
    return i;
  };
  for (let t = 0; t < mesh.t.length; t++) {
    const mi = mesh.m[t], M = mats[mi] ?? mats[0], [a, b, c] = mesh.t[t];
    const list = M.hole ? idxH : (M.alpha ?? 1) < 0.99 ? idxG : idxO;
    list.push(vert(a, mi), vert(b, mi), vert(c, mi));
  }
  const idx = new Uint32Array(idxH.length + idxO.length + idxG.length);
  idx.set(idxH, 0); idx.set(idxO, idxH.length); idx.set(idxG, idxH.length + idxO.length);
  return { data: new Float32Array(out), idx, nHole: idxH.length, nOpaque: idxO.length, nGlass: idxG.length };
}

// ---------- the solid parts, as spans up each little column of the model ----------
// A vertical line through each column meets the surfaces: going in where a surface faces down, out where one
// faces up (the parts are closed shapes, so this finds their insides even where two overlap). A lone sheet
// (a roof, a hammock, a flag) becomes a thin solid layer. The gaps (under the gazebo's roof, a swing's frame,
// between a bench's legs) stay open, so small creatures can go under and bigger ones climb over.
export function hitbox(model) {
  const mesh = model.mesh, mats = model.mats;
  const { lo, hi } = mesh.bounds();
  const ext = Math.max(hi[0] - lo[0], hi[2] - lo[2]);
  const cs = Math.max(0.06, Math.min(0.14, ext / 36));
  const x0 = lo[0] - cs, z0 = lo[2] - cs;
  const nx = Math.max(1, Math.ceil((hi[0] - x0) / cs) + 1), nz = Math.max(1, Math.ceil((hi[2] - z0) / cs) + 1);
  // the triangles over each column (by their outline from above)
  const bins = Array.from({ length: nx * nz }, () => []);
  for (let t = 0; t < mesh.t.length; t++) {
    const M = mats[mesh.m[t]];
    if (M?.hole || (M?.alpha ?? 1) < 0.35 || M?.noHit) continue; // (water, glass bubbles and the ground round a hole aren't solid)
    const [a, b, c] = mesh.t[t], A = mesh.p[a], B = mesh.p[b], C = mesh.p[c];
    const i0 = Math.max(0, Math.floor((Math.min(A[0], B[0], C[0]) - x0) / cs)), i1 = Math.min(nx - 1, Math.floor((Math.max(A[0], B[0], C[0]) - x0) / cs));
    const k0 = Math.max(0, Math.floor((Math.min(A[2], B[2], C[2]) - z0) / cs)), k1 = Math.min(nz - 1, Math.floor((Math.max(A[2], B[2], C[2]) - z0) / cs));
    for (let k = k0; k <= k1; k++) for (let i = i0; i <= i1; i++) bins[k * nx + i].push(t);
  }
  const off = new Int32Array(nx * nz + 1), spans = [];
  const THIN = Math.max(0.05, cs * 0.8);
  for (let k = 0; k < nz; k++) for (let i = 0; i < nx; i++) {
    const c = k * nx + i; off[c] = spans.length;
    const list = bins[c]; if (!list.length) continue;
    // (a few lines through the column, so thin parts — posts, ropes — aren't missed)
    const hits = [];
    for (const [ox, oz] of [[0.5, 0.5], [0.2, 0.2], [0.8, 0.8], [0.2, 0.8], [0.8, 0.2]]) {
      const px = x0 + (i + ox) * cs, pz = z0 + (k + oz) * cs;
      for (const t of list) {
        const [a, b, cc] = mesh.t[t], A = mesh.p[a], B = mesh.p[b], C = mesh.p[cc];
        const d = (B[2] - C[2]) * (A[0] - C[0]) + (C[0] - B[0]) * (A[2] - C[2]);
        if (Math.abs(d) < 1e-12) continue;
        const w0 = ((B[2] - C[2]) * (px - C[0]) + (C[0] - B[0]) * (pz - C[2])) / d, w1 = ((C[2] - A[2]) * (px - C[0]) + (A[0] - C[0]) * (pz - C[2])) / d, w2 = 1 - w0 - w1;
        if (w0 < -1e-6 || w1 < -1e-6 || w2 < -1e-6) continue;
        const y = w0 * A[1] + w1 * B[1] + w2 * C[1];
        const ny = w0 * mesh.n[a][1] + w1 * mesh.n[b][1] + w2 * mesh.n[cc][1];
        hits.push([y, ny]);
      }
    }
    if (!hits.length) continue;
    hits.sort((p, q) => p[0] - q[0]);
    // walk up the column: in and out of the solid parts
    const sp = [];
    let depth = 0, start = 0;
    for (const [y, ny] of hits) {
      if (ny < -0.05) { if (depth === 0) start = y; depth++; }
      else if (ny > 0.05) { if (depth > 0) { depth--; if (depth === 0) sp.push([start, y]); } else sp.push([y - THIN, y]); }
      else sp.push([y - THIN / 2, y + THIN / 2]); // (a wall seen edge-on: a little solid)
    }
    // (a part left open at the top — a trunk running up into its leaves: solid up to the last surface met)
    if (depth > 0) sp.push([start, Math.max(start + THIN, hits[hits.length - 1][0])]);
    // merge spans that touch (or almost)
    sp.sort((p, q) => p[0] - q[0]);
    const m = [];
    for (const s of sp) { const l = m[m.length - 1]; if (l && s[0] <= l[1] + cs * 0.5) l[1] = Math.max(l[1], s[1]); else m.push([s[0] < lo[1] + 0.25 ? lo[1] : s[0], s[1]]); } // (nearly on the ground: down to the ground, so nothing slips under a rock)
    for (const s of m) spans.push(s[0], s[1]);
  }
  off[nx * nz] = spans.length;
  return { x0, z0, cs, nx, nz, off, iv: new Float32Array(spans), top: hi[1] };
}
