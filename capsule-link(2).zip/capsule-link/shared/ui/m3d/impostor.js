// The 3D models in the yard's scenes: each is rendered (in a worker, off the page's own thread) as seen from
// the camera, and drawn where it stands. A new view is made when the camera has turned far enough round it
// (every 15°) or looks from higher or lower; while a view is being made the nearest one already made is shown,
// and turning blends smoothly from one view to the next. Lit by the scene's own sun and sky.
//
//   modelView(ctx, yard, spec, p, q) → true if the model was drawn (false: draw the old picture instead)
//   spec: { kind, opts } — the model, and its look (colours, seed)
import { MODELS, modelFor } from './catalog.js';
import { renderModel, hexLin } from './render.js';
import { darkness, afterDark } from '../lighting.js';
import { voxelize } from './voxel.js';
import { glModelView, glAvailable, glBegin, glQueue, glFlush } from './gl.js';
const voxels = new Map();
export function voxelOf(spec, m) { const k = `${spec.kind}|${JSON.stringify(spec.opts ?? {})}`; if (!voxels.has(k)) { voxels.set(k, voxelize(m)); if (voxels.size > 120) voxels.delete(voxels.keys().next().value); } return voxels.get(k); }

export const hasModel = (kind) => MODELS.has(kind);
const YAW_STEPS = 24, PITCH_STEP = 0.08;
const TIERS = [14, 20, 28, 40, 56, 80, 112];
const MAX_CACHE = 560;
let enabled = true, forced = null;
/** The models' look (a setting, saved per device in quality.js): 'smooth', 'voxel' (little cubes) or 'pixel' (fewer colours, outlined). */
export function setModelStyle(s) { forced = ['smooth', 'voxel', 'pixel'].includes(s) ? s : null; }
export const modelStyle = () => forced ?? 'pixel'; // (the pixel look is the only one now)
/** Graphics settings: the models can be turned off (the old pictures come back). */
export function setModels(on) { enabled = on !== false; }

// ---------- the workers ----------
const pending = new Map(); // id → { key, spec, view }
let workers = null, nextId = 1, rr = 0, workerFailed = false;
function startWorkers() {
  if (workers || workerFailed) return workers;
  try {
    const src = typeof __M3D_WORKER__ !== 'undefined' ? __M3D_WORKER__ : null;
    if (!src || typeof Worker === 'undefined') throw new Error('no worker');
    const url = URL.createObjectURL(new Blob([src], { type: 'text/javascript' }));
    const n = Math.max(1, Math.min(3, Math.floor((navigator.hardwareConcurrency || 2) / 2)));
    workers = [];
    for (let i = 0; i < n; i++) { const w = new Worker(url); w.onmessage = onResult; w.onerror = () => { workerFailed = true; }; w.busy = 0; workers.push(w); }
  } catch { workerFailed = true; workers = null; }
  return workers;
}
const cache = new Map(); // key → { canvas, fx, fy, ppu, used }
const looks = new Map(); // look key → { shadowV, h, views: Set(key) }
function onResult(e) {
  const d = e.data, job = pending.get(d.id);
  pending.delete(d.id);
  if (job?.w) job.w.busy--;
  if (!job) return;
  if (d.error) { cache.set(job.key, { failed: true, used: performance.now() }); return; }
  const c = document.createElement('canvas'); c.width = d.w; c.height = d.hgt;
  c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(d.buf), d.w, d.hgt), 0, 0);
  store(job, { canvas: c, fx: d.fx, fy: d.fy, ppu: d.ppu }, d.shadowV, d.h);
}
function store(job, entry, shadowV, h) {
  entry.used = performance.now(); entry.yaw = job.view.yb; entry.pitch = job.view.pb; entry.tier = job.view.ppu;
  cache.set(job.key, entry);
  const L = looks.get(job.look) ?? { views: new Set() };
  if (shadowV) L.shadowV = shadowV;
  if (h) L.h = h;
  L.views.add(job.key); looks.set(job.look, L);
  if (cache.size > MAX_CACHE) {
    // forget the views used longest ago
    const old = [...cache.entries()].sort((a, b) => a[1].used - b[1].used).slice(0, cache.size - MAX_CACHE + 20);
    for (const [k] of old) { cache.delete(k); for (const l of looks.values()) l.views.delete(k); }
  }
}
// no workers (an older build, or a browser without them): render on the page, a little each frame
const queue = [];
let budgetFrame = -1, spent = 0;
function request(job) {
  if (pending.has(job.key) || [...pending.values()].some((j) => j.key === job.key) || queue.some((j) => j.key === job.key)) return;
  const ws = startWorkers();
  if (ws) {
    const w = ws.reduce((a, b) => (a.busy <= b.busy ? a : b));
    if (w.busy > 6) return; // (it'll be asked again next frame)
    const id = nextId++;
    w.busy++; pending.set(id, { ...job, w });
    w.postMessage({ id, kind: job.spec.kind, opts: job.spec.opts, view: job.view });
    return;
  }
  if (queue.length < 40) queue.push(job);
}
function runQueue(frame) {
  if (budgetFrame !== frame) { budgetFrame = frame; spent = 0; }
  while (queue.length && spent < 6) {
    const job = queue.shift(), t0 = performance.now();
    try {
      let m = modelFor(job.spec.kind, job.spec.opts);
      if (!m) { cache.set(job.key, { failed: true, used: t0 }); continue; }
      if (job.view.style === 'voxel') m = voxelOf(job.spec, m);
      const r = renderModel(m, job.view);
      store(job, { canvas: r.canvas, fx: r.fx, fy: r.fy, ppu: r.ppu }, m.shadowV, m.h);
    } catch (e) { cache.set(job.key, { failed: true, used: t0 }); console.warn('[m3d]', e); }
    spent += performance.now() - t0;
  }
}

// ---------- light: the scene's sun and sky, rounded so views are only made again when it changes visibly ----------
const lightCache = new WeakMap();
function lightOf(yard) {
  const sun = yard.sun, t = yard.light ?? 'day';
  const skyHex = yard.c?.sky1 ?? '#9ad0ff', gHex = yard.L?.ground?.[0] ?? '#6a8a4a';
  const az = sun ? Math.round(Math.atan2(sun.dir[2], sun.dir[0]) / (Math.PI / 8)) : 0, el = sun ? Math.round(sun.el / 0.15) : 9;
  const key = `${sun ? 'sun' : 'none'}|${az}|${el}|${t}|${sun ? Math.round(sun.k * 10) : 0}|${sun ? Math.round(sun.soft * 4) : 0}|${skyHex}|${gHex}`;
  const prev = lightCache.get(yard);
  if (prev?.key === key) return prev;
  // (the sky's and ground's colour, at a steady brightness: a pale sky mustn't wash the models out, a dark one blacken them)
  const steady = (c, lum, keep) => { const l = 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; const k = lum / Math.max(0.02, l); return c.map((v) => lum + (Math.min(1.5, v * k) - lum) * keep); };
  const sky = steady(hexLin(skyHex), 0.5, 0.55), gnd = steady(hexLin(gHex), 0.3, 0.5);
  let L;
  if (sun) {
    const a = az * (Math.PI / 8), e = el * 0.15;
    const soft = sun.soft ?? 0;
    L = { sun: [Math.cos(a) * Math.cos(e), Math.max(0.12, Math.sin(e)), Math.sin(a) * Math.cos(e)], sunCol: sun.c.map((v) => (v / 255) ** 2.2), sunK: (0.9 + sun.k * 3.4) * (1 - soft * 0.55),
      sky, ground: gnd, ambK: 0.7 + soft * 0.3 };
  } else {
    // caves, the sea floor, space: soft light from above, coloured by the place
    L = { sun: [0.3, 0.9, -0.3], sunCol: sky.map((v) => v * 0.6 + 0.4), sunK: 1.3, sky, ground: gnd, ambK: 0.95 };
  }
  const out = { key, L };
  lightCache.set(yard, out);
  return out;
}

// ---------- which view ----------
function viewFor(yard, p, h) {
  const wx = p.x - yard.cx, wz = p.z - yard.cz;
  const dx = wx * yard.yc - wz * yard.ys, dz = wx * yard.ys + wz * yard.yc;
  const yaw = Math.atan2(yard.ys, yard.yc) + Math.atan2(dx, dz);
  const pitch = Math.atan2(yard.camY - h * 0.45 - (p.y ?? 0), Math.max(0.5, Math.hypot(dx, dz)));
  return { yaw, pitch: Math.max(-0.1, Math.min(1.35, pitch)) };
}
const lookKey = (spec) => `${spec.kind}|${JSON.stringify(spec.opts ?? {})}`;
const wrapB = (b) => ((b % YAW_STEPS) + YAW_STEPS) % YAW_STEPS;

/** The model's picture from this view (made now if it isn't yet: then the nearest there is, or null). */
function viewImage(spec, look, yb, pb, ppu, light, frame, ex = {}) {
  const style = modelStyle();
  const key = `${look}|${yb}|${pb}|${ppu}|${light.key}|${style}|${ex.part ?? ''}|${ex.rb ?? 0}`;
  const hit = cache.get(key);
  if (hit && !hit.failed) { hit.used = performance.now(); return hit; }
  if (hit?.failed) return null;
  request({ key, look: `${look}|${style}|${ex.part ?? ''}|${ex.rb ?? 0}`, spec, view: { yaw: yb * (Math.PI * 2 / YAW_STEPS), pitch: pb * PITCH_STEP, ppu, light: light.L, yb, pb, style, part: ex.part, rot: (ex.rb ?? 0) * (Math.PI * 2 / YAW_STEPS) } });
  void frame;
  return null;
}
function nearest(look, yb, pb, ppu) {
  const L = looks.get(look); if (!L) return null;
  let best = null, bs = Infinity;
  for (const k of L.views) {
    const e = cache.get(k); if (!e || e.failed) continue;
    const dy = Math.min(Math.abs(e.yaw - yb), YAW_STEPS - Math.abs(e.yaw - yb)), score = dy * 4 + Math.abs(e.pitch - pb) * 2 + Math.abs(Math.log(e.tier / ppu)) * 3 + (k.includes(curLight) ? 0 : 6);
    if (score < bs) { bs = score; best = e; }
  }
  return best;
}
let curLight = '';

// ---------- the graphics card's batch: each frame, the yard lists its models first, then draws ----------
function glOpts(yard, p, o) {
  const nl = nearLight(yard, p, p.h ?? 1);
  return { ...o, light: lightOf(yard).L, lit: nl ? [...nl.col.split(',').map((v) => Number(v) / 255), nl.amt] : null };
}
/** Before a frame's drawing: true if the graphics card is drawing the models. */
export function beginModels(yard) { return enabled && glBegin(yard); }
/** A model the frame will draw (the same arguments as modelView). */
export function queueModel(yard, spec, p, o = {}) { if (enabled && spec && MODELS.has(spec.kind)) glQueue(spec, p, glOpts(yard, p, o)); }
/** All the frame's models, drawn (before the scene is). */
export function flushModels() { glFlush(); }

/** Draws the model where it stands (q: the yard's projection of its foot). False if there's nothing to draw yet. */
export function modelView(ctx, yard, spec, p, q, { sway = 0, part = null, scale = 1 } = {}) {
  if (!enabled || !spec || !MODELS.has(spec.kind)) return false;
  // drawn by the graphics card, exactly as the camera sees it (the pictures below are only for when it can't)
  if (glModelView(ctx, yard, spec, p, q, glOpts(yard, p, { sway, part, scale }))) return true;
  if (glAvailable()) return false; // (not built yet: the old picture for now)
  // (turned where it stands: its own turn, in the same steps as the views)
  const style = modelStyle();
  const rb = p.rot ? Math.round(p.rot / (Math.PI * 2 / YAW_STEPS)) : 0, ex = { part, rb };
  const look = lookKey(spec), lk = `${look}|${style}|${part ?? ''}|${rb}`, info = looks.get(lk);
  const h = info?.h ?? p.h ?? 1;
  const light = lightOf(yard); curLight = light.key;
  const v = viewFor(yard, p, h);
  const fy = (v.yaw / (Math.PI * 2)) * YAW_STEPS, y0 = Math.floor(fy), frac = fy - y0;
  const pb = Math.round(v.pitch / PITCH_STEP);
  const want = (q.kTier ?? q.k) * (style === 'pixel' ? 0.5 : 1) * scale;
  const ppu = TIERS.find((t) => t >= want * 0.92) ?? TIERS[TIERS.length - 1];
  const frame = Math.floor(performance.now() / 16);
  const a = viewImage(spec, look, wrapB(y0), pb, ppu, light, frame, ex), b = frac > 0.04 ? viewImage(spec, look, wrapB(y0 + 1), pb, ppu, light, frame, ex) : null;
  runQueue(frame);
  let img = a ?? b, img2 = a && b ? b : null;
  if (!img) img = nearest(lk, wrapB(Math.round(fy)), pb, ppu);
  if (!img) return false;
  if (info?.shadowV && !p.shadowMesh) {
    // (its shadow turned and sized the same way it's drawn)
    const r = p.rot ?? 0, c = Math.cos(r), sn = Math.sin(r), sc = scale;
    p.shadowMesh = { v: r || sc !== 1 ? info.shadowV.map(([x, y, z]) => [(x * c + z * sn) * sc, y * sc, (-x * sn + z * c) * sc]) : info.shadowV };
  }
  const base = ctx.globalAlpha, smooth0 = ctx.imageSmoothingEnabled;
  if (style === 'pixel') ctx.imageSmoothingEnabled = false;
  const draw = (e, al) => {
    const s = (q.k * scale) / e.ppu, w = e.canvas.width * s, hh = e.canvas.height * s;
    if (w < 1 || hh < 1) return;
    const x = q.x - e.fx * s, y = q.y - e.fy * s;
    ctx.globalAlpha = base * al;
    if (sway) { const c = ctx; c.save(); c.translate(q.x, q.y); c.transform(1, 0, sway, 1, 0, 0); c.drawImage(e.canvas, x - q.x, y - q.y, w, hh); c.restore(); }
    else ctx.drawImage(e.canvas, x, y, w, hh);
  };
  draw(img, 1);
  // (between two views: the next one blended in, so turning round it is smooth)
  if (img2) draw(img2, frac);
  // lamps, fires and glowing things nearby light it up (most of all at night)
  const lit = nearLight(yard, p, h);
  if (lit) {
    const s = (q.k * scale) / img.ppu, sil = silhouette(img, lit.col);
    ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = base * lit.amt;
    if (sway) { ctx.translate(q.x, q.y); ctx.transform(1, 0, sway, 1, 0, 0); ctx.drawImage(sil, -img.fx * s, -img.fy * s, img.canvas.width * s, img.canvas.height * s); }
    else ctx.drawImage(sil, q.x - img.fx * s, q.y - img.fy * s, img.canvas.width * s, img.canvas.height * s);
    ctx.restore();
  }
  ctx.globalAlpha = base; ctx.imageSmoothingEnabled = smooth0;
  return true;
}

// ---------- a picture of a model for menus (the shop's blueprints) ----------
const icons = new Map();
/** A size × size canvas of the model, seen from a three-quarter view (null if there's no model). */
export function modelIcon(kind, opts = {}, size = 64) {
  if (!enabled || !MODELS.has(kind)) return null;
  const style = modelStyle();
  const key = `${kind}|${JSON.stringify(opts)}|${size}|${style}`;
  if (icons.has(key)) return icons.get(key);
  let out = null;
  try {
    const m = modelFor(kind, opts);
    if (m) {
      const ext = Math.max(m.hi[0] - m.lo[0], m.hi[1] - m.lo[1], m.hi[2] - m.lo[2], 0.3);
      const r = renderModel(style === 'voxel' ? voxelOf({ kind, opts }, m) : m, { yaw: -0.65, pitch: 0.42, ppu: (size * 1.6) / ext * (style === 'pixel' ? 0.5 : 1), ss: style === 'pixel' ? 1 : 2, style });
      out = document.createElement('canvas'); out.width = size; out.height = size;
      const x = out.getContext('2d'), k = Math.min(size / r.canvas.width, size / r.canvas.height) * 0.98;
      x.imageSmoothingEnabled = style !== 'pixel'; x.imageSmoothingQuality = 'high';
      x.drawImage(r.canvas, (size - r.canvas.width * k) / 2, (size - r.canvas.height * k) / 2, r.canvas.width * k, r.canvas.height * k);
    }
  } catch (e) { console.warn('[m3d] icon', kind, e); out = null; }
  icons.set(key, out);
  if (icons.size > 200) icons.delete(icons.keys().next().value);
  return out;
}

// the lights near a model, summed: { col: 'r,g,b' (rounded), amt } or null
function nearLight(yard, p, h) {
  const lights = yard.lit; if (!lights?.length) return null;
  let r = 0, g = 0, b = 0, tot = 0;
  const D = darkness(yard) * afterDark(yard), cy = (p.y ?? 0) + h * 0.5;
  for (const l of lights) {
    if (Math.abs(l.x - p.x) < 0.05 && Math.abs(l.z - p.z) < 0.05) continue; // (not its own light)
    const d = Math.hypot(l.x - p.x, l.y - cy, l.z - p.z), reach = l.r * 1.7 + h * 0.3;
    if (d > reach) continue;
    const k = l.i * (1 - d / reach) ** 2 * (l.dyn ? Math.max(D, 1.3) : D);
    if (k < 0.01) continue;
    r += l.c[0] * k; g += l.c[1] * k; b += l.c[2] * k; tot += k;
  }
  if (tot < 0.03) return null;
  const q8 = (v) => Math.min(255, Math.round(v / tot / 24) * 24);
  return { col: `${q8(r)},${q8(g)},${q8(b)}`, amt: Math.min(0.5, tot * 0.38) };
}
// the model's shape filled with a colour (kept with the view)
function silhouette(e, col) {
  e.sil ??= new Map();
  let c = e.sil.get(col);
  if (!c) {
    c = document.createElement('canvas'); c.width = e.canvas.width; c.height = e.canvas.height;
    const x = c.getContext('2d'); x.drawImage(e.canvas, 0, 0); x.globalCompositeOperation = 'source-in'; x.fillStyle = `rgb(${col})`; x.fillRect(0, 0, c.width, c.height);
    if (e.sil.size > 6) e.sil.delete(e.sil.keys().next().value);
    e.sil.set(col, c);
  }
  return c;
}
