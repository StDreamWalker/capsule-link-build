// The voxel look (a setting): a model rebuilt out of little cubes, each the colour of the surface it came
// from, so the models match the app's chunky pixel style while still being solid, lit 3D objects.
//   voxelize(model) → a new model (same materials, so metal still shines and lights still glow)
import { Mesh } from './geo.js';
import { prep, surfaceOf } from './render.js';

const FACES = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
export function voxelize(model, { res = 46, min = 0.045 } = {}) {
  const mesh = model.mesh, mats = model.mats.map(prep);
  const { lo, hi } = mesh.bounds();
  const ext = Math.max(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]);
  const vs = Math.max(min, ext / res);
  // which cubes the surfaces pass through, and their colour (averaged over the samples in each)
  const cells = new Map(), col = [0, 0, 0];
  const key = (i, j, k) => `${i},${j},${k}`;
  for (let t = 0; t < mesh.t.length; t++) {
    const [a, b, c] = mesh.t[t], mi = mesh.m[t], M = mats[mi] ?? mats[0];
    if (M.hole) continue;
    const pa = mesh.p[a], pb = mesh.p[b], pc = mesh.p[c];
    const len = Math.max(Math.hypot(pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2]), Math.hypot(pc[0] - pa[0], pc[1] - pa[1], pc[2] - pa[2]), Math.hypot(pc[0] - pb[0], pc[1] - pb[1], pc[2] - pb[2]));
    const n = Math.max(1, Math.ceil(len / (vs * 0.5)));
    for (let u = 0; u <= n; u++) for (let v = 0; v <= n - u; v++) {
      const w1 = u / n, w2 = v / n, w0 = 1 - w1 - w2;
      const p = [w0 * pa[0] + w1 * pb[0] + w2 * pc[0], w0 * pa[1] + w1 * pb[1] + w2 * pc[1], w0 * pa[2] + w1 * pb[2] + w2 * pc[2]];
      const nn = [0, 1, 2].map((q) => w0 * mesh.n[a][q] + w1 * mesh.n[b][q] + w2 * mesh.n[c][q]);
      const vc = [0, 1, 2].map((q) => w0 * mesh.c[a][q] + w1 * mesh.c[b][q] + w2 * mesh.c[c][q]);
      surfaceOf(M, p, nn, vc, col);
      const i = Math.floor(p[0] / vs), j = Math.floor(p[1] / vs), k = Math.floor(p[2] / vs), kk = key(i, j, k);
      let e = cells.get(kk);
      if (!e) { e = { i, j, k, r: 0, g: 0, b: 0, n: 0, m: new Map() }; cells.set(kk, e); }
      e.r += col[0]; e.g += col[1]; e.b += col[2]; e.n++; e.m.set(mi, (e.m.get(mi) ?? 0) + 1);
    }
  }
  // the materials, without their own patterns (the cubes carry the colour)
  const vm = model.mats.map((m) => ({ ...m, col: '#ffffff', col2: null, tex: null, stripes: null, vary: 0, bump: 0 }));
  const out = new Mesh();
  for (const e of cells.values()) {
    let mi = 0, best = -1; for (const [m, c] of e.m) if (c > best) { best = c; mi = m; }
    // (a touch of variety between cubes, like hand-placed voxels)
    const jit = 1 + (((e.i * 73856093) ^ (e.j * 19349663) ^ (e.k * 83492791)) % 9) / 160;
    const c = [e.r / e.n * jit, e.g / e.n * jit, e.b / e.n * jit];
    for (const f of FACES) {
      if (cells.has(key(e.i + f[0], e.j + f[1], e.k + f[2]))) continue;
      // a square on this side of the cube
      const fa = f[0] ? 0 : f[1] ? 1 : 2, ua = (fa + 1) % 3, va = (fa + 2) % 3;
      const base = [e.i * vs, e.j * vs, e.k * vs];
      const corner = (s2, t2) => { const q = base.slice(); q[fa] += f[fa] > 0 ? vs : 0; q[ua] += s2 * vs; q[va] += t2 * vs; return q; };
      const nrm = f.slice();
      const v0 = out.vert(corner(0, 0), nrm, c), v1 = out.vert(corner(1, 0), nrm, c), v2 = out.vert(corner(1, 1), nrm, c), v3 = out.vert(corner(0, 1), nrm, c);
      out.tri(v0, v1, v2, mi); out.tri(v0, v2, v3, mi);
    }
  }
  // (the invisible ground round a hole, kept as it was)
  for (let t = 0; t < mesh.t.length; t++) {
    const mi = mesh.m[t]; if (!mats[mi]?.hole) continue;
    const [a, b, c] = mesh.t[t].map((i) => out.vert(mesh.p[i].slice(), [0, 1, 0], [1, 1, 1]));
    out.tri(a, b, c, mi);
  }
  return { ...model, mesh: out, mats: vm, voxel: vs, _sm: null, _smKey: null };
}
