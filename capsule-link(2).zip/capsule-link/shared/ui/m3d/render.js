// Renders one of the 3D models to a picture, seen from a given direction, the way a game engine would:
// per-pixel lighting (sun, sky and bounce light, highlights that move with the view), soft self-shadows (a
// shadow map from the sun), ambient occlusion in the creases and where things meet the ground, surface detail
// (bark, wood grain, stone, cloth, brushed metal, leaves, water) and smooth, anti-aliased edges.
// The yard draws the picture where the model stands; a new picture is made when the view turns far enough
// (impostor.js), so it always looks like a solid object from wherever the camera is.
//
//   renderModel(model, { yaw, pitch, ppu, light }) → { canvas, fx, fy, ppu } — fx, fy: where the foot is
//   model: { mesh, mats: [material…] }, a material: see MAT below.
import { noise3, fbm } from './geo.js';

const srgbToLin = (v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4);
const linToSrgb = (v) => (v <= 0.0031308 ? v * 12.92 : 1.055 * v ** (1 / 2.4) - 0.055);
export function hexLin(h) {
  if (Array.isArray(h)) return h;
  const x = String(h).replace('#', ''), n = parseInt(x.length === 3 ? x.split('').map((c) => c + c).join('') : x.slice(0, 6), 16);
  return [srgbToLin(((n >> 16) & 255) / 255), srgbToLin(((n >> 8) & 255) / 255), srgbToLin((n & 255) / 255)];
}
const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
// filmic tone curve (ACES fitted): bright light rolls off instead of clipping
const aces = (x) => clamp01((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14));

// a material's defaults
const MAT = { col: '#9a9a9a', col2: null, rough: 0.6, spec: 0.3, metal: 0, em: null, emK: 1, tex: null, texS: 1, bump: 0.5, sss: 0, alpha: 1, axis: 1, vary: 0.12, stripes: null, rim: 1 };
export function prep(m) {
  const o = { ...MAT, ...m };
  o.c1 = hexLin(o.col); o.c2 = o.col2 ? hexLin(o.col2) : o.c1.map((v) => v * 0.6);
  o.e = o.em ? hexLin(o.em).map((v) => v * o.emK) : null;
  o.shin = 2 + (1 - o.rough) ** 2 * 220;
  if (o.stripes) o.sc = hexLin(o.stripes.col ?? '#ffffff');
  return o;
}

// working buffers, kept between renders (and grown when needed)
let BUF = null;
function buffers(n) {
  if (BUF && BUF.n >= n) return BUF;
  const N = Math.ceil(n * 1.25);
  BUF = { n: N, depth: new Float32Array(N), nx: new Float32Array(N), ny: new Float32Array(N), nz: new Float32Array(N), px: new Float32Array(N), py: new Float32Array(N), pz: new Float32Array(N), cr: new Float32Array(N), cg: new Float32Array(N), cb: new Float32Array(N), mat: new Int16Array(N) };
  return BUF;
}

/**
 * view: { yaw, pitch (radians, looking down), ppu (pixels per yard unit), ss (supersampling, 1–3),
 *         light: { sun: [x, y, z] towards the sun, sunCol: [r, g, b] linear, sunK, sky: [r, g, b], ground: [r, g, b], ambK } }
 */
export function renderModel(model, view) {
  const mesh = model.mesh, mats = model.mats.map(prep);
  // (a model turned where it stands: seen from the other way round, and the sun coming from the other way round too)
  const rot = view.rot ?? 0;
  const yaw = (view.yaw ?? 0) - rot, pitch = view.pitch ?? 0.4, ppu = view.ppu ?? 64;
  let lt = view.light ?? defaultLight();
  if (rot && lt.sun) { const c = Math.cos(rot), s2 = Math.sin(rot), [lx, ly, lz] = lt.sun; lt = { ...lt, sun: [lx * c - lz * s2, ly, lx * s2 + lz * c] }; }
  const cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
  const V = [-cp * sy, sp, -cp * cy]; // towards the camera, in the model's own space
  // ---------- 1. where every vertex lands on screen ----------
  const nv = mesh.p.length, SX = new Float32Array(nv), SY = new Float32Array(nv), SD = new Float32Array(nv);
  let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
  for (let i = 0; i < nv; i++) {
    const [x, y, z] = mesh.p[i], xr = x * cy - z * sy, zr = x * sy + z * cy;
    const ys = y * cp + zr * sp, d = -y * sp + zr * cp;
    SX[i] = xr; SY[i] = ys; SD[i] = d;
    if (xr < x0) x0 = xr; if (xr > x1) x1 = xr; if (ys < y0) y0 = ys; if (ys > y1) y1 = ys;
  }
  // (the ground under the foot is always in the picture, for the contact shade)
  const footR = model.foot ?? 0.3;
  x0 = Math.min(x0, -footR); x1 = Math.max(x1, footR); y0 = Math.min(y0, -footR * sp - 0.02);
  // supersampled while drawing (smooth edges), as long as the picture isn't huge
  const pad = 3;
  const area = (x1 - x0) * (y1 - y0) * ppu * ppu;
  const ss = view.ss ?? (area < 30000 ? 3 : area < 160000 ? 2 : 1);
  const S = ppu * ss;
  const W = Math.ceil((x1 - x0) * S) + pad * 2 * ss, H = Math.ceil((y1 - y0) * S) + pad * 2 * ss;
  const toPx = (i) => [(SX[i] - x0) * S + pad * ss, (y1 - SY[i]) * S + pad * ss];
  const B = buffers(W * H);
  const { depth, nx, ny, nz, px, py, pz, cr, cg, cb, mat } = B;
  depth.fill(Infinity, 0, W * H); mat.fill(-1, 0, W * H);
  const glass = [], part = view.part ?? null;
  // ---------- 2. the triangles, nearest wins ----------
  const PX = new Float32Array(nv), PY = new Float32Array(nv);
  for (let i = 0; i < nv; i++) { const q = toPx(i); PX[i] = q[0]; PY[i] = q[1]; }
  for (let t = 0; t < mesh.t.length; t++) {
    const [a, b, c] = mesh.t[t], mi = mesh.m[t], M = mats[mi] ?? mats[0];
    const ax = PX[a], ay = PY[a], bx = PX[b], by = PY[b], cx = PX[c], cyy = PY[c];
    const area2 = (bx - ax) * (cyy - ay) - (by - ay) * (cx - ax);
    if (Math.abs(area2) < 1e-9) continue;
    const minX = Math.max(0, Math.floor(Math.min(ax, bx, cx))), maxX = Math.min(W - 1, Math.ceil(Math.max(ax, bx, cx)));
    const minY = Math.max(0, Math.floor(Math.min(ay, by, cyy))), maxY = Math.min(H - 1, Math.ceil(Math.max(ay, by, cyy)));
    const inv = 1 / area2, pa = mesh.p[a], pb = mesh.p[b], pc = mesh.p[c], na = mesh.n[a], nb = mesh.n[b], nc = mesh.n[c], ca = mesh.c[a], cb2 = mesh.c[b], cc = mesh.c[c];
    const da = SD[a], db = SD[b], dc = SD[c];
    const isGlass = M.alpha < 1;
    // (one-sided surfaces, like the inside walls of a hole: not seen from behind)
    if (M.cull) { const fx2 = na[0] + nb[0] + nc[0], fy2 = na[1] + nb[1] + nc[1], fz2 = na[2] + nb[2] + nc[2]; if (fx2 * V[0] + fy2 * V[1] + fz2 * V[2] < 0) continue; }
    // (a model drawn in two halves, so creatures can stand inside it: the half behind them, or in front)
    let split = false;
    if (part) { const ly2 = M.layer ?? 'split'; if ((ly2 === 'front' && part === 'back') || (ly2 === 'back' && part === 'front')) continue; split = ly2 === 'split'; }
    for (let yy = minY; yy <= maxY; yy++) {
      const fy = yy + 0.5;
      for (let xx = minX; xx <= maxX; xx++) {
        const fx = xx + 0.5;
        let w0 = ((bx - fx) * (cyy - fy) - (by - fy) * (cx - fx)) * inv, w1 = ((cx - fx) * (ay - fy) - (cyy - fy) * (ax - fx)) * inv;
        const w2 = 1 - w0 - w1;
        if (w0 < -1e-6 || w1 < -1e-6 || w2 < -1e-6) continue;
        const d = w0 * da + w1 * db + w2 * dc, k = yy * W + xx;
        if (d >= depth[k]) continue;
        if (split) { const zx = w0 * pa[0] + w1 * pb[0] + w2 * pc[0], zz = w0 * pa[2] + w1 * pb[2] + w2 * pc[2], zr = zx * sy + zz * cy; if ((part === 'back') !== (zr > 0)) continue; }
        if (isGlass) { glass.push({ k, d, w0, w1, w2, t }); continue; }
        // (the ground round a hole: unseen itself, but hides what's under the ground beyond the hole's edge)
        if (M.hole) { depth[k] = d; mat[k] = -2; continue; }
        depth[k] = d; mat[k] = mi;
        px[k] = w0 * pa[0] + w1 * pb[0] + w2 * pc[0]; py[k] = w0 * pa[1] + w1 * pb[1] + w2 * pc[1]; pz[k] = w0 * pa[2] + w1 * pb[2] + w2 * pc[2];
        nx[k] = w0 * na[0] + w1 * nb[0] + w2 * nc[0]; ny[k] = w0 * na[1] + w1 * nb[1] + w2 * nc[1]; nz[k] = w0 * na[2] + w1 * nb[2] + w2 * nc[2];
        cr[k] = w0 * ca[0] + w1 * cb2[0] + w2 * cc[0]; cg[k] = w0 * ca[1] + w1 * cb2[1] + w2 * cc[1]; cb[k] = w0 * ca[2] + w1 * cb2[2] + w2 * cc[2];
        void w1;
      }
    }
  }
  // ---------- 3. a shadow map from the sun (soft self-shadows) ----------
  const L = norm3(lt.sun ?? [0.4, 0.8, -0.45]);
  // (the same for every view of this model under this sun: made once)
  const smKey = L.map((v) => v.toFixed(3)).join(',');
  if (model._smKey !== smKey) { model._sm = shadowMap(mesh, mats, L); model._smKey = smKey; }
  const sm = model._sm;
  // ---------- 4. light every pixel (one sample per final pixel; the edges anti-aliased by coverage) ----------
  const FW = Math.ceil(W / ss), FH = Math.ceil(H / ss);
  const out = new ImageData(FW, FH), O = out.data;
  const aoR = Math.max(2, 0.16 * S), aoR2 = aoR * 0.5, dRange = 0.5;
  const sunCol = lt.sunCol ?? [1, 0.96, 0.9], sunK = lt.sunK ?? 2.4, sky = lt.sky ?? [0.55, 0.7, 1], gnd = lt.ground ?? [0.35, 0.3, 0.22], ambK = lt.ambK ?? 0.75;
  const DIRS = [[1, 0], [0.7, 0.7], [0, 1], [-0.7, 0.7], [-1, 0], [-0.7, -0.7], [0, -1], [0.7, -0.7]];
  const col = [0, 0, 0];
  const shadeAt = (k, M, n, pos, vc) => {
    // the surface: colour and the bumps that catch the light
    surfaceOf(M, pos, n, vc, col);
    let [Nx, Ny, Nz] = n;
    // two-sided: always lit on the side the camera sees
    if (Nx * V[0] + Ny * V[1] + Nz * V[2] < 0) { Nx = -Nx; Ny = -Ny; Nz = -Nz; }
    if (BUMP[0] || BUMP[1] || BUMP[2]) { Nx += BUMP[0]; Ny += BUMP[1]; Nz += BUMP[2]; const m = Math.hypot(Nx, Ny, Nz) || 1; Nx /= m; Ny /= m; Nz /= m; }
    // ambient occlusion: from the depth around it on screen, and close to the ground
    let ao = 1;
    if (k >= 0) {
      let occ = 0, cnt = 0; const d0 = depth[k], kx = k % W, ky = (k / W) | 0;
      for (let di = 0; di < 8; di++) { const [dx, dy] = DIRS[di], r = di & 1 ? aoR2 : aoR;
        const sx = Math.round(kx + dx * r), syy = Math.round(ky + dy * r);
        cnt++;
        if (sx < 0 || syy < 0 || sx >= W || syy >= H) continue;
        const d1 = depth[syy * W + sx];
        if (d1 === Infinity) continue;
        const dd = (d0 - d1) / (r / S);
        if (dd > 0.08 && d0 - d1 < dRange) occ += Math.min(1, dd * 0.9);
      }
      ao = 1 - Math.min(0.75, (occ / cnt) * 1.15);
    }
    ao *= 1 - 0.5 * Math.exp(-Math.max(0, pos[1]) / 0.16) * (1 - Math.max(0, Ny) * 0.7);
    // the sun, through the shadow map, plus the sky and the light bounced off the ground
    const NL = Nx * L[0] + Ny * L[1] + Nz * L[2];
    const wrap = M.sss, diff = Math.max(0, (NL + wrap) / (1 + wrap));
    const sh = diff > 0 ? lit(sm, pos, L, NL) : 0;
    const hemi = Ny * 0.5 + 0.5;
    const NV = Math.max(0, Nx * V[0] + Ny * V[1] + Nz * V[2]);
    // highlight (Blinn-Phong, energy-normalised) with a Fresnel boost at grazing angles
    let Hx = L[0] + V[0], Hy = L[1] + V[1], Hz = L[2] + V[2]; const hm = Math.hypot(Hx, Hy, Hz) || 1; Hx /= hm; Hy /= hm; Hz /= hm;
    const NH = Math.max(0, Nx * Hx + Ny * Hy + Nz * Hz);
    const fres = (1 - NV) ** 5;
    const specK = sh * M.spec * NH ** M.shin * ((M.shin + 8) / 70) * (diff > 0 ? 1 : 0);
    const kd = 1 - M.metal * 0.85;
    for (let c = 0; c < 3; c++) {
      const alb = col[c];
      const amb = (gnd[c] + (sky[c] - gnd[c]) * hemi) * ambK * ao;
      let v = alb * kd * (sunCol[c] * sunK * diff * sh + amb);
      // light passing through leaves and petals when the sun is behind them
      if (M.sss > 0 && NL < 0) v += alb * sunCol[c] * sunK * M.sss * 0.35 * -NL * ao;
      const f0 = M.metal ? alb : 0.04;
      v += specK * sunCol[c] * sunK * (f0 + (1 - f0) * fres) * 0.6;
      // a soft rim of sky light round the edges (reads as a solid object against the scene)
      v += sky[c] * 0.16 * M.rim * (1 - NV) ** 3 * ao;
      if (M.e) v += M.e[c];
      col[c] = v;
    }
  };
  const tone = (v) => Math.round(linToSrgb(aces(v * (view.exposure ?? 0.62))) * 255);
  for (let fy = 0; fy < FH; fy++) for (let fx = 0; fx < FW; fx++) {
    // which subsamples are covered, and the nearest one (it's the one lit)
    let cov = 0, best = -1, bd = Infinity;
    for (let j = 0; j < ss; j++) for (let i = 0; i < ss; i++) {
      const xx = fx * ss + i, yy = fy * ss + j; if (xx >= W || yy >= H) continue;
      const k = yy * W + xx;
      if (mat[k] >= 0) { cov++; if (depth[k] < bd) { bd = depth[k]; best = k; } }
    }
    if (!cov) continue;
    const M = mats[mat[best]] ?? mats[0];
    const n = norm3([nx[best], ny[best], nz[best]]);
    shadeAt(best, M, n, [px[best], py[best], pz[best]], [cr[best], cg[best], cb[best]]);
    // the outline: a touch darker where the shape meets the background or something further back
    let edge = 0; const bx = best % W, by = (best / W) | 0;
    for (const [dx, dy] of [[ss, 0], [-ss, 0], [0, ss], [0, -ss]]) { const sx = bx + dx, syy = by + dy; if (sx < 0 || syy < 0 || sx >= W || syy >= H) { edge++; continue; } const d1 = depth[syy * W + sx]; if (d1 === Infinity || d1 - bd > 0.35) edge++; }
    const ek = edge ? 0.86 : 1;
    const o = (fy * FW + fx) * 4;
    O[o] = tone(col[0] * ek); O[o + 1] = tone(col[1] * ek); O[o + 2] = tone(col[2] * ek); O[o + 3] = Math.round((cov / (ss * ss)) * 255);
  }
  // ---------- 5. see-through parts (glass, a water surface): over what's behind them, far to near ----------
  if (glass.length) {
    glass.sort((a, b) => b.d - a.d);
    for (const g of glass) {
      if (g.d >= depth[g.k]) continue;
      const [a, b, c] = mesh.t[g.t], M = mats[mesh.m[g.t]];
      const pa = mesh.p[a], pb = mesh.p[b], pc = mesh.p[c], na = mesh.n[a], nb = mesh.n[b], nc = mesh.n[c];
      const pos = [g.w0 * pa[0] + g.w1 * pb[0] + g.w2 * pc[0], g.w0 * pa[1] + g.w1 * pb[1] + g.w2 * pc[1], g.w0 * pa[2] + g.w1 * pb[2] + g.w2 * pc[2]];
      const n = norm3([g.w0 * na[0] + g.w1 * nb[0] + g.w2 * nc[0], g.w0 * na[1] + g.w1 * nb[1] + g.w2 * nc[1], g.w0 * na[2] + g.w1 * nb[2] + g.w2 * nc[2]]);
      shadeAt(-1, M, n, pos, mesh.c[a]);
      const NV = Math.abs(n[0] * V[0] + n[1] * V[1] + n[2] * V[2]), al = Math.min(1, M.alpha + (1 - NV) ** 3 * 0.5) / (ss * ss);
      const fx = Math.floor((g.k % W) / ss), fy = Math.floor(g.k / W / ss), o = (fy * FW + fx) * 4;
      const A = O[o + 3] / 255;
      for (let c2 = 0; c2 < 3; c2++) { const v = tone(col[c2]); O[o + c2] = Math.round(A > 0 ? (O[o + c2] * A * (1 - al) + v * al) / Math.max(1e-3, A * (1 - al) + al) : v); }
      O[o + 3] = Math.min(255, Math.round((A + al * (1 - A)) * 255));
    }
  }
  // the pixel look (a setting): fewer colours, and a dark outline round the shape
  if (view.style === 'pixel') pixelate(O, FW, FH);
  // ---------- 6. a soft contact shade on the ground right under it ----------
  contactShade(O, FW, FH, model, { x0, y1, ppu, pad, sp, cy, sy });
  const meta = { fx: (0 - x0) * ppu + pad, fy: (y1 - 0) * ppu + pad, ppu };
  // (in a worker: the pixels themselves, to be sent back; on the page: a canvas)
  if (view.raw || typeof document === 'undefined') return { image: out, ...meta };
  const canvas = mkCanvas(FW, FH);
  canvas.getContext('2d').putImageData(out, 0, 0);
  return { canvas, ...meta };
}

function mkCanvas(w, h) {
  if (typeof document !== 'undefined') { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
  return new OffscreenCanvas(w, h);
}
const norm3 = (v) => { const m = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / m, v[1] / m, v[2] / m]; };
export function defaultLight() { return { sun: [0.45, 0.78, -0.43], sunCol: [1, 0.95, 0.86], sunK: 2.5, sky: [0.5, 0.64, 0.95], ground: [0.32, 0.28, 0.2], ambK: 0.72 }; }

// ---------- the shadow map ----------
function shadowMap(mesh, mats, L) {
  const a = norm3(Math.abs(L[1]) > 0.95 ? [1, 0, 0] : [L[2], 0, -L[0]]);
  const b = [L[1] * a[2] - L[2] * a[1], L[2] * a[0] - L[0] * a[2], L[0] * a[1] - L[1] * a[0]];
  let u0 = Infinity, u1 = -Infinity, v0 = Infinity, v1 = -Infinity;
  const n = mesh.p.length, U = new Float32Array(n), Vv = new Float32Array(n), D = new Float32Array(n);
  for (let i = 0; i < n; i++) { const p = mesh.p[i]; U[i] = p[0] * a[0] + p[1] * a[1] + p[2] * a[2]; Vv[i] = p[0] * b[0] + p[1] * b[1] + p[2] * b[2]; D[i] = p[0] * L[0] + p[1] * L[1] + p[2] * L[2]; if (U[i] < u0) u0 = U[i]; if (U[i] > u1) u1 = U[i]; if (Vv[i] < v0) v0 = Vv[i]; if (Vv[i] > v1) v1 = Vv[i]; }
  const R = 320, sc = (R - 4) / Math.max(1e-3, u1 - u0, v1 - v0);
  const Z = new Float32Array(R * R).fill(-Infinity);
  for (let t = 0; t < mesh.t.length; t++) {
    if ((mats[mesh.m[t]]?.alpha ?? 1) < 0.5) continue; // (glass lets the light through)
    const [i, j, k] = mesh.t[t];
    const ax = (U[i] - u0) * sc + 2, ay = (Vv[i] - v0) * sc + 2, bx = (U[j] - u0) * sc + 2, by = (Vv[j] - v0) * sc + 2, cx = (U[k] - u0) * sc + 2, cy = (Vv[k] - v0) * sc + 2;
    const ar = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax); if (Math.abs(ar) < 1e-9) continue;
    const inv = 1 / ar;
    const mnx = Math.max(0, Math.floor(Math.min(ax, bx, cx))), mxx = Math.min(R - 1, Math.ceil(Math.max(ax, bx, cx))), mny = Math.max(0, Math.floor(Math.min(ay, by, cy))), mxy = Math.min(R - 1, Math.ceil(Math.max(ay, by, cy)));
    for (let y = mny; y <= mxy; y++) for (let x = mnx; x <= mxx; x++) {
      const fx = x + 0.5, fy = y + 0.5;
      const w0 = ((bx - fx) * (cy - fy) - (by - fy) * (cx - fx)) * inv, w1 = ((cx - fx) * (ay - fy) - (cy - fy) * (ax - fx)) * inv, w2 = 1 - w0 - w1;
      if (w0 < -0.02 || w1 < -0.02 || w2 < -0.02) continue; // (a little generous: no light leaking between triangles)
      const d = w0 * D[i] + w1 * D[j] + w2 * D[k], q = y * R + x;
      if (d > Z[q]) Z[q] = d;
    }
  }
  return { a, b, u0, v0, sc, R, Z };
}
// how much sun reaches a point (soft: a few samples round it)
function lit(sm, p, L, NL) {
  const u = (p[0] * sm.a[0] + p[1] * sm.a[1] + p[2] * sm.a[2] - sm.u0) * sm.sc + 2, v = (p[0] * sm.b[0] + p[1] * sm.b[1] + p[2] * sm.b[2] - sm.v0) * sm.sc + 2;
  const d = p[0] * L[0] + p[1] * L[1] + p[2] * L[2];
  const bias = (0.02 + 0.05 * (1 - Math.min(1, Math.abs(NL)))) * 1;
  let litN = 0, tot = 0;
  for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) {
    const x = Math.round(u + i * 1.5), y = Math.round(v + j * 1.5); tot++;
    if (x < 0 || y < 0 || x >= sm.R || y >= sm.R) { litN++; continue; }
    if (sm.Z[y * sm.R + x] <= d + bias) litN++;
  }
  return litN / tot;
}

// ---------- the surfaces ----------
const BUMP = [0, 0, 0];
export function surfaceOf(M, p, n, vc, out) {
  const s = M.texS;
  let r = M.c1[0], g = M.c1[1], b = M.c1[2], mix = 0, bh = 0;
  BUMP[0] = BUMP[1] = BUMP[2] = 0;
  const x = p[0] * s, y = p[1] * s, z = p[2] * s;
  // a height field h(p) whose slope tilts the normal (only for textured surfaces)
  let H = null;
  switch (M.tex) {
    case 'bark': { const ang = Math.atan2(p[2], p[0]); const ridge = Math.abs(Math.sin(ang * 9 + noise3(x * 2, y * 0.6, z * 2) * 5 + y * 0.8)); mix = 1 - ridge ** 0.6; H = (q) => Math.abs(Math.sin(Math.atan2(q[2], q[0]) * 9 + noise3(q[0] * s * 2, q[1] * s * 0.6, q[2] * s * 2) * 5 + q[1] * s * 0.8)) * 0.6 + noise3(q[0] * s * 6, q[1] * s * 2, q[2] * s * 6) * 0.4; bh = 0.9; break; }
    case 'wood': { const ax = M.axis; const a1 = ax === 0 ? y : x, a2 = ax === 2 ? y : z, al = [x, y, z][ax]; const ring = Math.sin(Math.hypot(a1, a2) * 18 + noise3(x * 1.5, y * 1.5, z * 1.5) * 6 + al * 0.6); mix = ring * 0.5 + 0.5; mix = mix * 0.55 + noise3(x * 20, y * 20, z * 20) * 0.2; H = (q) => Math.sin(Math.hypot(ax === 0 ? q[1] * s : q[0] * s, ax === 2 ? q[1] * s : q[2] * s) * 18) * 0.5; bh = 0.25; break; }
    case 'stone': { const f = fbm(x * 2.2, y * 2.2, z * 2.2, 3); mix = f; H = (q) => fbm(q[0] * s * 4, q[1] * s * 4, q[2] * s * 4, 2); bh = 1.1; break; }
    case 'leaf': { const f = noise3(x * 7, y * 7, z * 7), f2 = noise3(x * 2, y * 2, z * 2); mix = f * 0.55 + f2 * 0.45; H = (q) => noise3(q[0] * s * 9, q[1] * s * 9, q[2] * s * 9); bh = 1.4; break; }
    case 'fabric': { const w = Math.sin(x * 90) * Math.sin(y * 90 + z * 90); mix = 0.5 + w * 0.15 + noise3(x * 5, y * 5, z * 5) * 0.2; H = (q) => Math.sin(q[0] * s * 90) * Math.sin(q[1] * s * 90 + q[2] * s * 90) * 0.4; bh = 0.25; break; }
    case 'metal': { const al = [x, y, z][M.axis]; mix = noise3(al * 40, (M.axis ? x : y) * 1.5, z * 1.5) * 0.5; H = (q) => noise3([q[0], q[1], q[2]][M.axis] * s * 40, 0, 0) * 0.3; bh = 0.15; break; }
    case 'plastic': mix = noise3(x * 3, y * 3, z * 3) * 0.25; break;
    case 'crystal': { mix = clamp01(p[1] / (M.h ?? 1.5)); break; }
    case 'grass': { mix = noise3(x * 12, y * 4, z * 12); H = (q) => noise3(q[0] * s * 14, q[1] * s * 5, q[2] * s * 14); bh = 1; break; }
    case 'water': { mix = noise3(x * 3, y * 3, z * 3) * 0.4; H = (q) => Math.sin(q[0] * s * 9 + noise3(q[0] * s * 2, 0, q[2] * s * 2) * 4) * Math.sin(q[2] * s * 8) * 0.5; bh = 0.6; break; }
    case 'ceramic': mix = noise3(x * 4, y * 4, z * 4) * 0.2; break;
    case 'soil': { mix = fbm(x * 6, y * 6, z * 6, 2); H = (q) => noise3(q[0] * s * 12, q[1] * s * 12, q[2] * s * 12); bh = 1.2; break; }
    default: mix = M.vary ? noise3(x * 2.5, y * 2.5, z * 2.5) : 0;
  }
  if (M.tex) { r += (M.c2[0] - r) * mix; g += (M.c2[1] - g) * mix; b += (M.c2[2] - b) * mix; }
  else if (M.vary) { const k = 1 + (mix - 0.5) * M.vary * 2; r *= k; g *= k; b *= k; }
  if (M.stripes) { const st = M.stripes, v = [p[0], p[1], p[2]][st.axis ?? 0] * st.freq; if (((Math.floor(v) % 2) + 2) % 2 === 1) { r = M.sc[0]; g = M.sc[1]; b = M.sc[2]; } }
  out[0] = r * vc[0]; out[1] = g * vc[1]; out[2] = b * vc[2];
  if (H && bh * M.bump > 0) {
    const e = 0.012, h0 = H(p), k = bh * M.bump * 0.06 / e;
    const gx = (H([p[0] + e, p[1], p[2]]) - h0) * k, gy = (H([p[0], p[1] + e, p[2]]) - h0) * k, gz = (H([p[0], p[1], p[2] + e]) - h0) * k;
    // (only the part of the slope along the surface tilts it)
    const d = gx * n[0] + gy * n[1] + gz * n[2];
    BUMP[0] = -(gx - d * n[0]); BUMP[1] = -(gy - d * n[1]); BUMP[2] = -(gz - d * n[2]);
  }
}

// a soft dark patch on the ground under the model (where its footprint is), so it sits on the ground
function contactShade(O, W, H, model, { x0, y1, ppu, pad, sp, cy, sy }) {
  const fp = model.footprint ?? [[0, 0, model.foot ?? 0.3]];
  for (const [fx, fz, r] of fp) {
    const X = fx * cy - fz * sy, Z = fx * sy + fz * cy;
    const cxp = (X - x0) * ppu + pad, cyp = (y1 - Z * sp) * ppu + pad;
    const rx = r * ppu * 1.15, ry = Math.max(1.5, r * ppu * sp * 1.15);
    for (let y = Math.max(0, Math.floor(cyp - ry)); y <= Math.min(H - 1, Math.ceil(cyp + ry)); y++) for (let x = Math.max(0, Math.floor(cxp - rx)); x <= Math.min(W - 1, Math.ceil(cxp + rx)); x++) {
      const d = ((x + 0.5 - cxp) / rx) ** 2 + ((y + 0.5 - cyp) / ry) ** 2; if (d >= 1) continue;
      const a = (1 - d) ** 1.6 * 0.42, o = (y * W + x) * 4, A = O[o + 3] / 255;
      if (A >= 0.999) continue;
      // under the model: behind what's drawn (only where the model doesn't cover)
      const na = A + a * (1 - A);
      O[o] = Math.round((O[o] * A + 12 * a * (1 - A)) / na); O[o + 1] = Math.round((O[o + 1] * A + 10 * a * (1 - A)) / na); O[o + 2] = Math.round((O[o + 2] * A + 24 * a * (1 - A)) / na); O[o + 3] = Math.round(na * 255);
    }
  }
}

// fewer colours (a few shades of each, with a little dithering) and a one-pixel dark outline
function pixelate(O, W, H) {
  const lv = 7, BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
  const A = new Uint8Array(W * H);
  for (let i = 0; i < W * H; i++) A[i] = O[i * 4 + 3] > 110 ? 1 : 0;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = y * W + x, o = i * 4;
    if (!A[i]) { O[o + 3] = O[o + 3] > 40 ? Math.min(O[o + 3], 90) : O[o + 3]; continue; }
    const t = (BAYER[(y & 3) * 4 + (x & 3)] / 16 - 0.5) * (255 / lv);
    for (let c = 0; c < 3; c++) O[o + c] = Math.max(0, Math.min(255, Math.round((O[o + c] + t) / (255 / lv)) * (255 / lv)));
    O[o + 3] = 255;
    // the outline: the edge of the shape
    const edge = x === 0 || y === 0 || x === W - 1 || y === H - 1 || !A[i - 1] || !A[i + 1] || !A[i - W] || !A[i + W];
    if (edge) { O[o] = O[o] * 0.35 + 6; O[o + 1] = O[o + 1] * 0.35 + 4; O[o + 2] = O[o + 2] * 0.35 + 18; }
  }
}
