// The 3D models, drawn by the graphics card every frame, exactly as the camera sees them: no pictures made
// ahead from a few angles, so nothing jumps, blurs or doubles up as the camera turns, slides or zooms.
// Each model is drawn into a little patch of an off-screen canvas the size of the scene (with the scene's own
// camera), then that patch is copied into the scene in its place among everything else (so creatures still
// walk in front of and behind it). Lit like the old pictures: the sun (with soft self-shadows), sky and ground
// light, highlights, a rim of sky light; then the app's pixel look (a few shades per colour, a dark outline).
//
//   glModelView(ctx, yard, spec, p, q, { sway, part, scale }) → true when drawn (false: not ready yet / no WebGL)
//   meshEntry(spec) → { hit, h, lo, hi, … } once the model's built (asks for it otherwise), or null
import { modelFor } from './catalog.js';
import { meshArrays, hitbox, STRIDE } from './meshdata.js';

// ---------- the models, built in a worker ----------
const meshes = new Map(); // look → { state: 'wait'|'ready'|'failed', … }
const lookKey = (spec) => `${spec.kind}|${JSON.stringify(spec.opts ?? {})}`;
let workers = null, workerFailed = false, nextId = 1;
const jobs = new Map();
function pool() {
  if (workers || workerFailed) return workers;
  try {
    const src = typeof __M3D_WORKER__ !== 'undefined' ? __M3D_WORKER__ : null;
    if (!src || typeof Worker === 'undefined') throw new Error('no worker');
    const url = URL.createObjectURL(new Blob([src], { type: 'text/javascript' }));
    const n = Math.max(1, Math.min(3, Math.floor((navigator.hardwareConcurrency || 2) / 2)));
    workers = [];
    for (let i = 0; i < n; i++) {
      const w = new Worker(url); w.busy = 0;
      w.onmessage = (e) => { const d = e.data, look = jobs.get(d.id); jobs.delete(d.id); w.busy--; if (look) arrived(look, d); };
      w.onerror = () => { workerFailed = true; };
      workers.push(w);
    }
  } catch { workerFailed = true; workers = null; }
  return workers;
}
const queue = []; // (no workers: built on the page, a little at a time)
function request(look, spec) {
  meshes.set(look, { state: 'wait', t: performance.now() });
  const ws = pool();
  if (ws) {
    const w = ws.reduce((a, b) => (a.busy <= b.busy ? a : b));
    const id = nextId++; w.busy++; jobs.set(id, look);
    w.postMessage({ id, job: 'mesh', kind: spec.kind, opts: spec.opts ?? {} });
  } else queue.push({ look, spec });
}
function runQueue() {
  const t0 = performance.now();
  while (queue.length && performance.now() - t0 < 8) {
    const { look, spec } = queue.shift();
    try {
      const m = modelFor(spec.kind, spec.opts ?? {});
      if (!m) { arrived(look, { error: 'no model' }); continue; }
      arrived(look, { mesh: meshArrays(m), hit: hitbox(m), h: m.h, lo: m.lo, hi: m.hi, foot: m.foot ?? 0.3, footprint: m.footprint ?? null, shadowV: m.shadowV });
    } catch (e) { arrived(look, { error: String(e) }); }
  }
}
const listeners = new Set();
/** fn() whenever a model finishes building (the yard redoes its hitboxes). */
export function onMeshReady(fn) { listeners.add(fn); return () => listeners.delete(fn); }
function arrived(look, d) {
  if (d.error) { meshes.set(look, { state: 'failed' }); return; }
  const e = { state: 'ready', h: d.h, lo: d.lo, hi: d.hi, foot: d.foot, footprint: d.footprint, shadowV: d.shadowV, hit: d.hit, arrays: d.mesh, used: performance.now() };
  // (the bounding sphere, for the shadow's camera)
  e.cx = (d.lo[0] + d.hi[0]) / 2; e.cy = (d.lo[1] + d.hi[1]) / 2; e.cz = (d.lo[2] + d.hi[2]) / 2;
  e.rad = Math.hypot(d.hi[0] - d.lo[0], d.hi[1] - d.lo[1], d.hi[2] - d.lo[2]) / 2 + 0.02;
  meshes.set(look, e);
  for (const f of listeners) { try { f(look); } catch { /* fine */ } }
}
/** The built model (its hitbox, size…), or null while it's being built (it's asked for). */
export function meshEntry(spec) {
  if (!spec) return null;
  const look = lookKey(spec), e = meshes.get(look);
  if (!e) { request(look, spec); return null; }
  return e.state === 'ready' ? e : null;
}

// ---------- the graphics card ----------
let gl = null, cv = null, glFailed = false, ext32 = null;
const P = {};
let fbo = null, sfbo = null, quad = null;
const SM = 384;
const VS = `attribute vec3 aP,aN,aC,aX;attribute vec4 aM,aE;
uniform mat4 uVP,uW,uSM;uniform vec3 uRight;uniform float uSway,uFoot;
varying vec3 vW,vN,vC,vX;varying vec4 vM,vE,vS;varying float vY;
void main(){vec4 w=uW*vec4(aP,1.);float hy=w.y-uFoot;w.xyz+=uRight*(-uSway*max(0.,hy));
vW=w.xyz;vN=mat3(uW[0].xyz,uW[1].xyz,uW[2].xyz)*aN;vC=aC;vM=aM;vE=aE;vX=aX;vY=hy;vS=uSM*w;gl_Position=uVP*w;}`;
const FS = `precision highp float;
varying vec3 vW,vN,vC,vX;varying vec4 vM,vE,vS;varying float vY;
uniform vec3 uEye,uSun,uSunC,uSky,uGnd,uCenter;uniform float uAmb,uExp,uPart,uUseSh;uniform vec2 uFwd;uniform vec4 uLit;uniform sampler2D uShadow;
float unpack(vec4 c){return dot(c,vec4(1.,1./255.,1./65025.,1./16581375.));}
float shadowAt(float NL){vec3 s=vS.xyz/vS.w*.5+.5;if(s.x<0.||s.y<0.||s.x>1.||s.y>1.)return 1.;
float bias=.0025+.006*(1.-min(1.,abs(NL)));float l=0.;
for(int j=-1;j<=1;j++)for(int i=-1;i<=1;i++){float d=unpack(texture2D(uShadow,s.xy+vec2(float(i),float(j))*(1.5/${SM}.)));l+=d+bias>=s.z?1.:0.;}
return l/9.;}
vec3 aces(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
void main(){
vec3 V=normalize(uEye-vW);vec3 N=normalize(vN);
if(vX.z>.5&&dot(N,V)<0.)discard;
if(uPart!=0.){float lay=vX.y;float rel=dot(vW.xz-uCenter.xz,uFwd);bool back=lay<-.5||(abs(lay)<.5&&rel>0.);if(uPart<0.?!back:back)discard;}
if(dot(N,V)<0.)N=-N;
float NL=dot(N,uSun);float wrap=vM.w;float diff=max(0.,(NL+wrap)/(1.+wrap));
float sh=diff>0.?(uUseSh>.5?shadowAt(NL):1.):0.;
float hemi=N.y*.5+.5;float NV=max(0.,dot(N,V));vec3 H=normalize(uSun+V);float NH=max(0.,dot(N,H));float fres=pow(1.-NV,5.);
float ao=1.-.5*exp(-max(0.,vY)/.16)*(1.-max(0.,N.y)*.7);
float shin=vM.y;float specK=sh*vM.x*pow(NH,shin)*((shin+8.)/70.)*(diff>0.?1.:0.);
float kd=1.-vM.z*.85;vec3 alb=vC;vec3 amb=mix(uGnd,uSky,hemi)*uAmb*ao;
vec3 col=alb*kd*(uSunC*diff*sh+amb);
if(wrap>0.&&NL<0.)col+=alb*uSunC*wrap*.35*(-NL)*ao;
vec3 f0=mix(vec3(.04),alb,vM.z);
col+=specK*uSunC*(f0+(1.-f0)*fres)*.6;
col+=uSky*.16*vX.x*pow(1.-NV,3.)*ao;
col+=vE.rgb;
vec3 c=pow(aces(col*uExp),vec3(1./2.2));
c+=uLit.rgb*uLit.a;
float a=min(1.,vE.a+(vE.a<.99?pow(1.-NV,3.)*.5:0.));
gl_FragColor=vec4(c*a,a);}`;
const SVS = `attribute vec3 aP;uniform mat4 uW,uSM;uniform vec3 uRight;uniform float uSway,uFoot;varying float vZ;
void main(){vec4 w=uW*vec4(aP,1.);float hy=w.y-uFoot;w.xyz+=uRight*(-uSway*max(0.,hy));gl_Position=uSM*w;}`;
const SFS = `precision highp float;
vec4 pack(float d){vec4 e=vec4(1.,255.,65025.,16581375.)*d;e=fract(e);e-=e.yzww*vec4(1./255.,1./255.,1./255.,0.);return e;}
void main(){gl_FragColor=pack(gl_FragCoord.z);}`;
// the pixel look, as the patch is copied out: a few shades per colour, and a dark outline round the shape
const CVS = 'attribute vec2 aQ;void main(){gl_Position=vec4(aQ,0.,1.);}';
const CFS = `precision highp float;uniform sampler2D uT;uniform vec2 uSz;uniform float uLv;
vec4 at(vec2 o){return texture2D(uT,(gl_FragCoord.xy+o)/uSz);}
void main(){vec4 t=at(vec2(0.));float a=t.a;
if(a<.06){gl_FragColor=vec4(0.);return;}
vec3 c=t.rgb/a;
if(a<.43){gl_FragColor=vec4(c*min(a,.4),min(a,.4));return;}
c=floor(c*uLv+.5)/uLv;
float e=0.;if(at(vec2(1.,0.)).a<.43)e=1.;if(at(vec2(-1.,0.)).a<.43)e=1.;if(at(vec2(0.,1.)).a<.43)e=1.;if(at(vec2(0.,-1.)).a<.43)e=1.;
if(e>0.)c=c*.35+vec3(.024,.016,.07);
gl_FragColor=vec4(c,1.);}`;

function compile(vs, fs, attrs) {
  const sh = (t, src) => { const s = gl.createShader(t); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
  const p = gl.createProgram();
  gl.attachShader(p, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fs));
  attrs.forEach((a, i) => gl.bindAttribLocation(p, i, a));
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  const loc = {}; const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) { const inf = gl.getActiveUniform(p, i); loc[inf.name] = gl.getUniformLocation(p, inf.name); }
  // (a uniform the compiler left out: setting it does nothing)
  return { p, u: new Proxy(loc, { get: (o, k) => o[k] ?? null }) };
}
function target(w, h, depth) {
  const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
  for (const [k, v] of [[gl.TEXTURE_MIN_FILTER, gl.NEAREST], [gl.TEXTURE_MAG_FILTER, gl.NEAREST], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]]) gl.texParameteri(gl.TEXTURE_2D, k, v);
  const f = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, f);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
  let rb = null;
  if (depth) { rb = gl.createRenderbuffer(); gl.bindRenderbuffer(gl.RENDERBUFFER, rb); gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, w, h); gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, rb); }
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  return { t, f, rb, w, h };
}
function drop(T) { if (!T) return; gl.deleteTexture(T.t); gl.deleteFramebuffer(T.f); if (T.rb) gl.deleteRenderbuffer(T.rb); }
function init() {
  if (gl || glFailed) return !!gl;
  try {
    if (typeof document === 'undefined') throw new Error('no page');
    cv = document.createElement('canvas'); cv.width = cv.height = 16;
    const o = { alpha: true, premultipliedAlpha: true, antialias: false, depth: true, stencil: false, preserveDrawingBuffer: false };
    gl = cv.getContext('webgl', o) || cv.getContext('experimental-webgl', o);
    if (!gl) throw new Error('no webgl');
    ext32 = gl.getExtension('OES_element_index_uint');
    const A = ['aP', 'aN', 'aC', 'aM', 'aE', 'aX'];
    P.main = compile(VS, FS, A); P.shadow = compile(SVS, SFS, ['aP']); P.comp = compile(CVS, CFS, ['aQ']);
    quad = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, quad); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    sfbo = target(SM, SM, true);
    cv.addEventListener('webglcontextlost', (e) => { e.preventDefault(); gl = null; glFailed = true; for (const m of meshes.values()) { m.vbo = m.ibo = null; } });
  } catch (e) { console.warn('[m3d] no graphics card drawing:', e?.message ?? e); gl = null; glFailed = true; }
  return !!gl;
}
export const glAvailable = () => init();
function upload(e) {
  if (e.vbo) return true;
  const a = e.arrays; if (!a) return false;
  const big = a.data.length / STRIDE > 65535;
  if (big && !ext32) { e.state = 'failed'; return false; }
  e.vbo = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, e.vbo); gl.bufferData(gl.ARRAY_BUFFER, a.data, gl.STATIC_DRAW);
  e.ibo = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, e.ibo); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, big ? a.idx : new Uint16Array(a.idx), gl.STATIC_DRAW);
  e.itype = big ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT; e.isz = big ? 4 : 2;
  e.nHole = a.nHole; e.nOpaque = a.nOpaque; e.nGlass = a.nGlass;
  return true;
}
function bindMesh(e, full) {
  gl.bindBuffer(gl.ARRAY_BUFFER, e.vbo); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, e.ibo);
  const F = 4 * STRIDE;
  const at = (i, n, off) => { gl.enableVertexAttribArray(i); gl.vertexAttribPointer(i, n, gl.FLOAT, false, F, off * 4); };
  at(0, 3, 0);
  if (full) { at(1, 3, 3); at(2, 3, 6); at(3, 4, 9); at(4, 4, 13); at(5, 3, 17); } else for (let i = 1; i < 6; i++) gl.disableVertexAttribArray(i);
}

// ---------- matrices (column-major, as the graphics card wants them) ----------
function viewProj(y) {
  const F = y.F ?? y.H * 1.05, W = y.W, H = y.H, s = y.ps, c = y.pc, yc = y.yc, ys = y.ys;
  const r0 = [yc, 0, -ys], r1 = [ys * s, c, yc * s], r2 = [ys * c, -s, yc * c];
  const e = [y.cx, y.camY, y.cz], t = (r) => -(r[0] * e[0] + r[1] * e[1] + r[2] * e[2]);
  const n = 0.3, f = 400, A = (f + n) / (f - n), B = (-2 * n * f) / (f - n);
  const kx = (2 * F) / W, ky = (2 * F) / H;
  const R = [[kx * r0[0], kx * r0[1], kx * r0[2], kx * t(r0)], [ky * r1[0], ky * r1[1], ky * r1[2], ky * t(r1)], [A * r2[0], A * r2[1], A * r2[2], A * t(r2) + B], [r2[0], r2[1], r2[2], t(r2)]];
  const m = new Float32Array(16);
  for (let row = 0; row < 4; row++) for (let col = 0; col < 4; col++) m[col * 4 + row] = R[row][col];
  return m;
}
function worldMat(x, y, z, rot, sc) {
  const c = Math.cos(rot) * sc, s = Math.sin(rot) * sc;
  // (x, z) of the model → (x c + z s, −x s + z c): the turn the old pictures used
  return new Float32Array([c, 0, -s, 0, 0, sc, 0, 0, s, 0, c, 0, x, y, z, 1]);
}
function sunMat(L, c, R) {
  // looking down the sunlight at the model (a box round it, depth along the light)
  const z = L, up = Math.abs(L[1]) > 0.95 ? [1, 0, 0] : [0, 1, 0];
  let x = [up[1] * z[2] - up[2] * z[1], up[2] * z[0] - up[0] * z[2], up[0] * z[1] - up[1] * z[0]]; const xm = Math.hypot(...x) || 1; x = x.map((v) => v / xm);
  const yv = [z[1] * x[2] - z[2] * x[1], z[2] * x[0] - z[0] * x[2], z[0] * x[1] - z[1] * x[0]];
  const d = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  // view: (p − c)·x / R, (p − c)·y / R, depth: −(p − c)·L / R  (towards the sun is nearer)
  const k = 1 / R;
  const rows = [[x[0] * k, x[1] * k, x[2] * k, -d(x, c) * k], [yv[0] * k, yv[1] * k, yv[2] * k, -d(yv, c) * k], [-z[0] * k, -z[1] * k, -z[2] * k, d(z, c) * k], [0, 0, 0, 1]];
  const m = new Float32Array(16);
  for (let r = 0; r < 4; r++) for (let col = 0; col < 4; col++) m[col * 4 + r] = rows[r][col];
  return m;
}

// ---------- one frame's models, drawn together ----------
// The yard says which models it'll draw this frame (glQueue), they're all drawn side by side into one
// off-screen canvas (glFlush), and each is then copied into the scene in its turn (glModelView). Copying
// from one canvas that doesn't change in between is quick everywhere (one hand-over from the graphics card).
let frame = null; // { yard, items: Map(key → job), list: [] }
const jobKey = (p, part) => (part ? `${part}` : '');
/** Starts a frame's batch for this yard. */
// (a computer without a graphics card draws all this slowly: then the self-shadows are left out)
const slow = { t: 0, n: 0, sum: 0, noShadows: false };
export function glBegin(yard) {
  if (!init()) { frame = null; return false; }
  const now = performance.now();
  if (slow.t && now - slow.t < 1000) { slow.sum += now - slow.t; slow.n++; if (slow.n >= 90) { if (slow.sum / slow.n > 55 && !slow.noShadows) { slow.noShadows = true; console.info('[m3d] slow drawing: self-shadows off'); } slow.n = 0; slow.sum = 0; } }
  slow.t = now;
  runQueue();
  frame = { yard, items: new Map(), list: [] };
  return true;
}
/** One model this frame (the same arguments as glModelView). */
export function glQueue(spec, p, opts) {
  if (!frame) return;
  const e = meshEntry(spec);
  if (!e || !upload(e)) return;
  const job = layout(frame.yard, e, p, opts);
  if (!job) return;
  let m = frame.items.get(p); if (!m) { m = new Map(); frame.items.set(p, m); }
  m.set(jobKey(p, opts.part), job);
  if (!job.empty) frame.list.push(job);
}
/** Draws everything queued, side by side, into the off-screen canvas. */
export function glFlush() {
  if (!frame || !frame.list.length || !gl) return;
  const yard = frame.yard, W = yard.W | 0, H = yard.H | 0;
  // shelves of patches, tallest first, 2 pixels apart
  const list = frame.list.slice().sort((a, b) => b.rh - a.rh);
  const AW = Math.max(256, Math.ceil(W / 64) * 64);
  let x = 1, y = 1, shelf = 0;
  for (const j of list) {
    if (x + j.rw + 1 > AW) { x = 1; y += shelf + 2; shelf = 0; }
    j.ax = x; j.ay = y; x += j.rw + 2; shelf = Math.max(shelf, j.rh);
  }
  let AH = Math.ceil((y + shelf + 2) / 64) * 64;
  const MAXH = Math.min(4096, gl.getParameter(gl.MAX_RENDERBUFFER_SIZE) || 4096);
  if (AH > MAXH) { for (const j of list) if (j.ay + j.rh + 1 > MAXH) j.ax = -1; AH = MAXH; }
  size(AW, Math.max(AH, cv.height === AH ? AH : AH));
  gl.bindFramebuffer(gl.FRAMEBUFFER, fbo.f); gl.disable(gl.SCISSOR_TEST); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  for (const j of list) if (j.ax >= 0) renderJob(j, yard);
  composite(0, 0, cv.width, cv.height);
  frame.ready = true;
}
function size(w, h) {
  if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
  if (!fbo || fbo.w !== w || fbo.h !== h) { drop(fbo); fbo = target(w, h, true); }
}
// where a model will be on screen this frame, and everything needed to draw it
function layout(yard, e, p, { sway = 0, part = null, scale = 1, light, lit = null }) {
  const W = yard.W | 0, H = yard.H | 0;
  if (W < 2 || H < 2) return null;
  const rot = p.rot ?? 0, py = p.y ?? 0;
  const Wm = worldMat(p.x, py, p.z, rot, scale);
  // (its shadow on the ground, turned and sized the way it's drawn: the yard works that out from the sun)
  if (e.shadowV && part !== 'front' && (!p.shadowMesh || p.shadowMesh.rot !== rot || p.shadowMesh.sc !== scale || p.shadowMesh.e !== e)) {
    const c = Math.cos(rot), sn = Math.sin(rot);
    p.shadowMesh = { v: e.shadowV.map(([x, y, z]) => [(x * c + z * sn) * scale, y * scale, (-x * sn + z * c) * scale]), rot, sc: scale, e };
  }
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, full = false;
  const lo = e.lo, hi = e.hi, swayPad = Math.abs(sway) * e.h * scale;
  for (let i = 0; i < 8; i++) {
    const mx = i & 1 ? hi[0] : lo[0], my = i & 2 ? hi[1] : lo[1], mz = i & 4 ? hi[2] : lo[2];
    const wx = Wm[0] * mx + Wm[8] * mz + Wm[12], wy = Wm[5] * my + Wm[13], wz = Wm[2] * mx + Wm[10] * mz + Wm[14];
    const s = yard.project(wx, wy, wz);
    if (!s) { full = true; break; }
    const pad = swayPad * s.k;
    x0 = Math.min(x0, s.x - pad); x1 = Math.max(x1, s.x + pad); y0 = Math.min(y0, s.y); y1 = Math.max(y1, s.y);
  }
  if (full) { x0 = 0; y0 = 0; x1 = W; y1 = H; }
  x0 = Math.max(0, Math.floor(x0) - 2); y0 = Math.max(0, Math.floor(y0) - 2); x1 = Math.min(W, Math.ceil(x1) + 2); y1 = Math.min(H, Math.ceil(y1) + 2);
  const rw = x1 - x0, rh = y1 - y0;
  if (rw < 1 || rh < 1) return { empty: true, e, Wm, scale, part, rw: 0, rh: 0 };
  return { e, p, Wm, sway, part, scale, light, lit, py, x0, y0, rw, rh, W, H, VP: viewProj(yard), eye: [yard.cx, yard.camY, yard.cz], right: [yard.yc, 0, -yard.ys], fwd: (() => { const fx = p.x - yard.cx, fz = p.z - yard.cz, m = Math.hypot(fx, fz) || 1; return [fx / m, fz / m]; })() };
}
// draws one model into its patch (ax, ay: top-left in the off-screen canvas) of the off-screen target
function renderJob(j, yard) {
  const { e, Wm, sway, part, scale, light, py, x0, y0, rw, rh, W, H } = j;
  const AH = fbo.h, L = light.sun;
  const c = [Wm[0] * e.cx + Wm[8] * e.cz + Wm[12], Wm[5] * e.cy + Wm[13], Wm[2] * e.cx + Wm[10] * e.cz + Wm[14]];
  const R = e.rad * scale + Math.abs(sway) * e.h * scale, SMx = sunMat(L, c, R);
  gl.disable(gl.BLEND); gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.depthMask(true); gl.disable(gl.CULL_FACE);
  const useSh = light.shadows !== false && !slow.noShadows;
  if (useSh) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, sfbo.f); gl.viewport(0, 0, SM, SM); gl.disable(gl.SCISSOR_TEST);
    gl.clearColor(1, 1, 1, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    const S = P.shadow; gl.useProgram(S.p);
    gl.uniformMatrix4fv(S.u.uW, false, Wm); gl.uniformMatrix4fv(S.u.uSM, false, SMx); gl.uniform3fv(S.u.uRight, j.right); gl.uniform1f(S.u.uSway, sway); gl.uniform1f(S.u.uFoot, py);
    bindMesh(e, false);
    if (e.nOpaque) gl.drawElements(gl.TRIANGLES, e.nOpaque, e.itype, e.nHole * e.isz);
  }
  // the scene's whole view, shifted so this model's patch of it lands on (ax, ay)
  gl.bindFramebuffer(gl.FRAMEBUFFER, fbo.f);
  const gy = AH - j.ay - rh; // (the graphics card counts up from the bottom)
  gl.viewport(j.ax - x0, gy - (H - y0 - rh), W, H);
  gl.enable(gl.SCISSOR_TEST); gl.scissor(j.ax, gy, rw, rh);
  const M = P.main; gl.useProgram(M.p);
  gl.uniformMatrix4fv(M.u.uVP, false, j.VP); gl.uniformMatrix4fv(M.u.uW, false, Wm); gl.uniformMatrix4fv(M.u.uSM, false, SMx);
  gl.uniform3fv(M.u.uRight, j.right); gl.uniform1f(M.u.uSway, sway); gl.uniform1f(M.u.uFoot, py);
  gl.uniform3fv(M.u.uEye, j.eye);
  gl.uniform3fv(M.u.uSun, L); gl.uniform3fv(M.u.uSunC, light.sunCol.map((v) => v * light.sunK)); gl.uniform3fv(M.u.uSky, light.sky); gl.uniform3fv(M.u.uGnd, light.ground);
  gl.uniform1f(M.u.uAmb, light.ambK); gl.uniform1f(M.u.uExp, light.exposure ?? 0.62); gl.uniform1f(M.u.uUseSh, useSh ? 1 : 0);
  gl.uniform1f(M.u.uPart, part === 'back' ? -1 : part === 'front' ? 1 : 0); gl.uniform3f(M.u.uCenter, j.p.x, py, j.p.z); gl.uniform2fv(M.u.uFwd, j.fwd);
  gl.uniform4fv(M.u.uLit, j.lit ?? [0, 0, 0, 0]);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, sfbo.t); gl.uniform1i(M.u.uShadow, 0);
  bindMesh(e, true);
  if (e.nHole) { gl.colorMask(false, false, false, false); gl.drawElements(gl.TRIANGLES, e.nHole, e.itype, 0); gl.colorMask(true, true, true, true); }
  if (e.nOpaque) gl.drawElements(gl.TRIANGLES, e.nOpaque, e.itype, e.nHole * e.isz);
  if (e.nGlass) {
    gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
    gl.drawElements(gl.TRIANGLES, e.nGlass, e.itype, (e.nHole + e.nOpaque) * e.isz);
    gl.depthMask(true); gl.disable(gl.BLEND);
  }
  gl.disable(gl.SCISSOR_TEST);
  void yard;
}
// the pixel look, from the off-screen target onto the off-screen canvas (a region of it)
function composite(x, y, w, h) {
  gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.disable(gl.DEPTH_TEST); gl.disable(gl.BLEND);
  gl.viewport(0, 0, cv.width, cv.height); gl.enable(gl.SCISSOR_TEST); gl.scissor(x, cv.height - y - h, w, h);
  gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
  const C = P.comp; gl.useProgram(C.p);
  for (let i = 1; i < 6; i++) gl.disableVertexAttribArray(i);
  gl.bindBuffer(gl.ARRAY_BUFFER, quad); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, fbo.t); gl.uniform1i(C.u.uT, 0); gl.uniform2f(C.u.uSz, fbo.w, fbo.h); gl.uniform1f(C.u.uLv, 9);
  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  gl.disable(gl.SCISSOR_TEST);
}

/** Draws the model where it stands, into the scene's canvas (from this frame's batch, or on its own). */
export function glModelView(ctx, yard, spec, p, q, opts = {}) {
  if (!init()) return false;
  let job = frame?.yard === yard && frame.ready ? frame.items.get(p)?.get(jobKey(p, opts.part)) : null;
  if (!job || job.ax < 0) {
    // (not in the batch: drawn on its own, after the batch's patches)
    runQueue();
    const e = meshEntry(spec);
    if (!e || !upload(e)) return false;
    job = layout(yard, e, p, opts);
    if (!job) return false;
    if (!job.empty) {
      // (drawn over the batch's canvas: what's left of the batch is drawn this way too, from now on)
      const AW = Math.max(cv.width, Math.ceil((yard.W | 0) / 64) * 64), need = job.rh + 2;
      size(AW, Math.max(cv.height, Math.ceil(need / 64) * 64));
      job.ax = 1; job.ay = Math.max(0, cv.height - need);
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo.f); gl.enable(gl.SCISSOR_TEST); gl.scissor(0, 0, cv.width, need + 1); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); gl.disable(gl.SCISSOR_TEST);
      renderJob(job, yard);
      composite(0, job.ay - 1, cv.width, need + 1);
      if (frame) frame.ready = false; // (the batch's canvas was drawn over)
    }
  }
  job.e.used = performance.now();
  if (job.empty) return true;
  if (job.part !== 'front') contactShade(ctx, yard, job.e, job.Wm, job.scale);
  ctx.drawImage(cv, job.ax, job.ay, job.rw, job.rh, job.x0, job.y0, job.rw, job.rh);
  return true;
}
// a soft dark patch on the ground under it (where its feet are), so it sits on the ground
function contactShade(ctx, yard, e, Wm, sc) {
  const fp = e.footprint ?? [[0, 0, e.foot ?? 0.3]];
  for (const [fx, fz, r] of fp) {
    const wx = Wm[0] * fx + Wm[8] * fz + Wm[12], wz = Wm[2] * fx + Wm[10] * fz + Wm[14];
    const s = yard.project(wx, Wm[13], wz); if (!s) continue;
    const rx = r * sc * s.k * 1.15; if (rx < 1) continue;
    const ry = Math.max(1.5, rx * Math.max(0.2, yard.ps));
    ctx.save(); ctx.translate(s.x, s.y); ctx.scale(1, ry / rx);
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, rx);
    g.addColorStop(0, 'rgba(12,10,24,.4)'); g.addColorStop(0.6, 'rgba(12,10,24,.16)'); g.addColorStop(1, 'rgba(12,10,24,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, rx, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
}
