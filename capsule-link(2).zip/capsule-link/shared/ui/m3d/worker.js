// Builds the 3D models off the page's own thread, so the scene never stutters while one is made.
//   { id, job: 'mesh', kind, opts } → { id, mesh: meshArrays, hit: hitbox, h, lo, hi, foot, footprint, shadowV }
//   { id, kind, opts, view }       → { id, w, hgt, buf, fx, fy, ppu, h, shadowV } (a picture: no graphics card)
import { modelFor } from './catalog.js';
import { renderModel } from './render.js';
import { meshArrays, hitbox } from './meshdata.js';

const sent = new Set();
self.onmessage = (e) => {
  const { id, kind, opts, view, job } = e.data;
  try {
    const m = modelFor(kind, opts);
    if (!m) { self.postMessage({ id, error: 'no model' }); return; }
    if (job === 'mesh') {
      const a = meshArrays(m), hb = hitbox(m);
      self.postMessage({ id, mesh: a, hit: hb, h: m.h, lo: m.lo, hi: m.hi, foot: m.foot ?? 0.3, footprint: m.footprint ?? null, shadowV: m.shadowV },
        [a.data.buffer, a.idx.buffer, hb.off.buffer, hb.iv.buffer]);
      return;
    }
    const r = renderModel(m, { ...view, raw: true });
    const key = `${kind}|${JSON.stringify(opts)}`, first = !sent.has(key);
    sent.add(key);
    const buf = r.image.data.buffer;
    self.postMessage({ id, w: r.image.width, hgt: r.image.height, buf, fx: r.fx, fy: r.fy, ppu: r.ppu, h: m.h, shadowV: first ? m.shadowV : null }, [buf]);
  } catch (err) { self.postMessage({ id, error: String(err?.message ?? err) }); }
};
