// Geometry for the scene's 3D models: smooth, properly shaded meshes (not voxels or flat facets), built from a
// handful of shapes: surfaces of revolution (posts, pots, trunks), tubes along curves (branches, ropes, bent
// metal), rounded boxes (planks, crates, machines), blobs (canopies, rocks, bushes), cloth (the hammock), faceted
// gems (crystals). Units are the yard's (a small creature is about 1 tall); y is up; the foot is at the origin.
//
// A Mesh holds vertices (p, smooth normal n, colour c as a multiplier) and triangles (t) with a material each (m).

export class Mesh {
  constructor() { this.p = []; this.n = []; this.c = []; this.t = []; this.m = []; }
  get count() { return this.p.length; }
  vert(p, n = [0, 1, 0], c = [1, 1, 1]) { this.p.push(p); this.n.push(n); this.c.push(c); return this.p.length - 1; }
  tri(a, b, c, m = 0) { this.t.push([a, b, c]); this.m.push(m); }
  /** Another mesh's vertices and triangles added to this one. */
  add(o) {
    const base = this.p.length;
    for (let i = 0; i < o.p.length; i++) { this.p.push(o.p[i].slice()); this.n.push(o.n[i].slice()); this.c.push(o.c[i].slice()); }
    for (let i = 0; i < o.t.length; i++) { const [a, b, c] = o.t[i]; this.t.push([a + base, b + base, c + base]); this.m.push(o.m[i]); }
    return this;
  }
  mat(id) { for (let i = 0; i < this.m.length; i++) this.m[i] = id; return this; }
  each(fn) { for (let i = 0; i < this.p.length; i++) fn(this.p[i], this.n[i], i); return this; }
  translate(x, y, z) { return this.each((p) => { p[0] += x; p[1] += y; p[2] += z; }); }
  scale(sx, sy = sx, sz = sx) {
    return this.each((p, n) => {
      p[0] *= sx; p[1] *= sy; p[2] *= sz;
      n[0] /= sx; n[1] /= sy; n[2] /= sz; norm(n);
    });
  }
  rotate(axis, a) {
    const c = Math.cos(a), s = Math.sin(a);
    const r = axis === 'x' ? (v) => { const y = v[1] * c - v[2] * s, z = v[1] * s + v[2] * c; v[1] = y; v[2] = z; }
      : axis === 'y' ? (v) => { const x = v[0] * c + v[2] * s, z = -v[0] * s + v[2] * c; v[0] = x; v[2] = z; }
        : (v) => { const x = v[0] * c - v[1] * s, y = v[0] * s + v[1] * c; v[0] = x; v[1] = y; };
    return this.each((p, n) => { r(p); r(n); });
  }
  rotateX(a) { return this.rotate('x', a); }
  rotateY(a) { return this.rotate('y', a); }
  rotateZ(a) { return this.rotate('z', a); }
  /** Every vertex's colour multiplied by fn(position, normal) → [r, g, b] (or one number). */
  tint(fn) { return this.each((p, n, i) => { const k = fn(p, n); const c = this.c[i]; if (typeof k === 'number') { c[0] *= k; c[1] *= k; c[2] *= k; } else { c[0] *= k[0]; c[1] *= k[1]; c[2] *= k[2]; } }); }
  /** Moves every vertex by fn(position, normal) → [dx, dy, dz]; then the normals are worked out again. */
  displace(fn) { this.each((p, n) => { const d = fn(p, n); p[0] += d[0]; p[1] += d[1]; p[2] += d[2]; }); return this.smooth(); }
  /** Smooth normals from the triangles round each vertex (weighted by their area). */
  smooth() {
    const acc = this.p.map(() => [0, 0, 0]);
    for (const [a, b, c] of this.t) {
      const f = faceN(this.p[a], this.p[b], this.p[c]);
      for (const i of [a, b, c]) { acc[i][0] += f[0]; acc[i][1] += f[1]; acc[i][2] += f[2]; }
    }
    for (let i = 0; i < acc.length; i++) { if (acc[i][0] || acc[i][1] || acc[i][2]) this.n[i] = norm(acc[i]); }
    return this;
  }
  /** Every triangle its own vertices with its own normal: crisp facets (gems, cut stone). */
  flat() {
    const o = new Mesh();
    for (let i = 0; i < this.t.length; i++) {
      const [a, b, c] = this.t[i], f = norm(faceN(this.p[a], this.p[b], this.p[c]));
      o.tri(o.vert(this.p[a].slice(), f.slice(), this.c[a].slice()), o.vert(this.p[b].slice(), f.slice(), this.c[b].slice()), o.vert(this.p[c].slice(), f.slice(), this.c[c].slice()), this.m[i]);
    }
    return o;
  }
  clone() { return new Mesh().add(this); }
  bounds() {
    const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
    for (const p of this.p) for (let k = 0; k < 3; k++) { if (p[k] < lo[k]) lo[k] = p[k]; if (p[k] > hi[k]) hi[k] = p[k]; }
    return { lo, hi };
  }
}

export function norm(v) { const m = Math.hypot(v[0], v[1], v[2]) || 1; v[0] /= m; v[1] /= m; v[2] /= m; return v; }
function faceN(a, b, c) {
  const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
  return [uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx];
}
export const merge = (...ms) => { const o = new Mesh(); for (const m of ms.flat()) if (m) o.add(m); return o; };

// ---------- the shapes ----------
/** A surface over (u, v) in [0, 1]²: fn(u, v) → [x, y, z]. wrapU joins the u edges (round things). */
export function surface(nu, nv, fn, { wrapU = false, m = 0, flipped = false } = {}) {
  const o = new Mesh(), cols = wrapU ? nu : nu + 1;
  for (let j = 0; j <= nv; j++) for (let i = 0; i < cols; i++) o.vert(fn(i / nu, j / nv));
  for (let j = 0; j < nv; j++) for (let i = 0; i < nu; i++) {
    const i2 = wrapU ? (i + 1) % nu : i + 1;
    const a = j * cols + i, b = j * cols + i2, c = (j + 1) * cols + i2, d = (j + 1) * cols + i;
    if (flipped) { o.tri(a, b, c, m); o.tri(a, c, d, m); } else { o.tri(a, c, b, m); o.tri(a, d, c, m); }
  }
  return o.smooth();
}

/** Turned on a lathe: profile [[radius, y], …] from bottom to top, round the y axis. Ends closed if the radius there is 0. */
export function lathe(profile, segs = 16, { m = 0, capBottom = true, capTop = true } = {}) {
  const pts = profile.slice();
  if (capBottom && pts[0][0] > 0) pts.unshift([0, pts[0][1]], [pts[0][0] * 0.999, pts[0][1]]);
  if (capTop && pts[pts.length - 1][0] > 0) { const t = pts[pts.length - 1]; pts.push([t[0] * 0.999, t[1]], [0, t[1]]); }
  // (a crease where the profile turns sharply, so a flat lid stays flat)
  const o = surface(segs, pts.length - 1, (u, v) => { const k = v * (pts.length - 1), i = Math.min(pts.length - 2, Math.floor(k)), f = k - i; const r = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * f, y = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * f; const a = u * Math.PI * 2; return [Math.cos(a) * r, y, Math.sin(a) * r]; }, { wrapU: true, m });
  return o;
}
/** A cylinder (with the edges rounded a little, so light catches them). */
export function cylinder(r, h, segs = 14, { m = 0, bevel = 0.08, r2 = r } = {}) {
  const b = Math.min(bevel * Math.min(r, r2), h * 0.25);
  return lathe([[0, 0], [r - b, 0], [r, b], [r2, h - b], [r2 - b, h], [0, h]], segs, { m, capBottom: false, capTop: false });
}
export function cone(r, h, segs = 14, { m = 0 } = {}) { return lathe([[0, 0], [r, 0.001], [0, h]], segs, { m, capBottom: false, capTop: false }); }
/** An ellipsoid. */
export function sphere(rx, ry = rx, rz = rx, { segs = 16, rings = 10, m = 0 } = {}) {
  return surface(segs, rings, (u, v) => { const a = u * Math.PI * 2, b = v * Math.PI - Math.PI / 2; return [Math.cos(a) * Math.cos(b) * rx, Math.sin(b) * ry, Math.sin(a) * Math.cos(b) * rz]; }, { wrapU: true, m });
}
/** A lumpy blob: an ellipsoid pushed in and out by smooth noise (canopies, bushes, rocks, clouds). */
export function blob(rx, ry, rz, seed = 1, { amp = 0.18, freq = 1.6, segs = 18, rings = 12, m = 0, flatBottom = 0 } = {}) {
  const s = sphere(rx, ry, rz, { segs, rings, m });
  return s.displace((p, n) => {
    const k = 1 + amp * (noise3(p[0] * freq / rx + seed, p[1] * freq / ry, p[2] * freq / rz) * 2 - 1) + amp * 0.5 * (noise3(p[0] * freq * 2.3 / rx, p[1] * freq * 2.3 / ry + seed * 3, p[2] * freq * 2.3 / rz) * 2 - 1);
    let dy = 0;
    if (flatBottom && p[1] < -ry * flatBottom) dy = (-ry * flatBottom - p[1]) * 0.85;
    return [p[0] * (k - 1), p[1] * (k - 1) + dy, p[2] * (k - 1)];
  });
}
/** A rounded box (w × h × d), its foot at y = 0. r: how round the edges are. */
export function box(w, h, d, r = 0.04, { m = 0 } = {}) {
  r = Math.max(1e-4, Math.min(r, w / 2 - 1e-4, h / 2 - 1e-4, d / 2 - 1e-4));
  const E = [w / 2 - r, h / 2 - r, d / 2 - r];
  // the positions along one side of a face: the flat middle, then the rounding (evenly by angle)
  const R = 3;
  const along = (e) => { const out = [], inner = Math.max(1, Math.ceil((2 * e) / 0.35)); for (let k = R; k >= 1; k--) out.push(-e - r * Math.tan((k / R) * Math.PI / 4)); for (let i = 0; i <= inner; i++) out.push(-e + (2 * e * i) / inner); for (let k = 1; k <= R; k++) out.push(e + r * Math.tan((k / R) * Math.PI / 4)); return out; };
  const o = new Mesh();
  const faces = [[0, 1, 2, 1], [0, 2, 1, -1], [1, 2, 0, 1], [1, 0, 2, -1], [2, 0, 1, 1], [2, 1, 0, -1]]; // [normal axis, u axis, v axis, sign]
  for (const [fa, ua, va, sg] of faces) {
    const U = along(E[ua]), V = along(E[va]), base = o.p.length;
    for (const v of V) for (const u of U) {
      const q = [0, 0, 0]; q[fa] = sg * (E[fa] + r); q[ua] = u; q[va] = v;
      const cl = q.map((x, k) => Math.max(-E[k], Math.min(E[k], x)));
      const dir = norm([q[0] - cl[0], q[1] - cl[1], q[2] - cl[2]]);
      o.vert([cl[0] + dir[0] * r, cl[1] + dir[1] * r + h / 2, cl[2] + dir[2] * r], dir);
    }
    const nu = U.length;
    // (winding so the faces point outwards, whichever way the axes run)
    const t = [0, 0, 0]; t[ua] = 1; const bb = [0, 0, 0]; bb[va] = 1; const nn = [0, 0, 0]; nn[fa] = sg;
    const out = (t[1] * bb[2] - t[2] * bb[1]) * nn[0] + (t[2] * bb[0] - t[0] * bb[2]) * nn[1] + (t[0] * bb[1] - t[1] * bb[0]) * nn[2] > 0;
    for (let j = 0; j < V.length - 1; j++) for (let i = 0; i < nu - 1; i++) {
      const a2 = base + j * nu + i, b2 = a2 + 1, c2 = a2 + nu + 1, d2 = a2 + nu;
      if (out) { o.tri(a2, b2, c2, m); o.tri(a2, c2, d2, m); } else { o.tri(a2, c2, b2, m); o.tri(a2, d2, c2, m); }
    }
  }
  return o;
}

/** A tube along a path: path(t) → [x, y, z] for t in [0, 1], radius(t). Ends closed. */
export function tube(path, radius, { steps = 16, segs = 10, m = 0, caps = true } = {}) {
  const P = [], T = [];
  for (let i = 0; i <= steps; i++) P.push(path(i / steps));
  for (let i = 0; i <= steps; i++) { const a = P[Math.max(0, i - 1)], b = P[Math.min(steps, i + 1)]; T.push(norm([b[0] - a[0], b[1] - a[1], b[2] - a[2]])); }
  // a frame carried along the path without twisting
  let N0 = Math.abs(T[0][1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
  let Nn = norm(cross(cross(T[0], N0), T[0]));
  const frames = [];
  for (let i = 0; i <= steps; i++) {
    if (i) { const b = cross(T[i - 1], T[i]), s = Math.hypot(...b); if (s > 1e-6) { const ax = b.map((x) => x / s), ang = Math.asin(Math.min(1, s)); Nn = rotAxis(Nn, ax, ang); } }
    frames.push([Nn.slice(), norm(cross(T[i], Nn))]);
  }
  const rad = typeof radius === 'number' ? () => radius : radius;
  const o = surface(segs, steps, (u, v) => { const i = Math.round(v * steps), a = u * Math.PI * 2, [n1, n2] = frames[i], r = rad(v), c = Math.cos(a) * r, s = Math.sin(a) * r, p = P[i]; return [p[0] + n1[0] * c + n2[0] * s, p[1] + n1[1] * c + n2[1] * s, p[2] + n1[2] * c + n2[2] * s]; }, { wrapU: true, m });
  if (caps) {
    for (const end of [0, 1]) {
      const p = P[end ? steps : 0], r = rad(end), [n1, n2] = frames[end ? steps : 0], tN = T[end ? steps : 0].map((x) => (end ? x : -x));
      if (r < 1e-3) continue;
      const c0 = o.vert(p.slice(), tN.slice()), ring = [];
      for (let k = 0; k < segs; k++) { const a = (k / segs) * Math.PI * 2, c = Math.cos(a) * r, s = Math.sin(a) * r; ring.push(o.vert([p[0] + n1[0] * c + n2[0] * s, p[1] + n1[1] * c + n2[1] * s, p[2] + n1[2] * c + n2[2] * s], tN.slice())); }
      for (let k = 0; k < segs; k++) { if (end) o.tri(c0, ring[k], ring[(k + 1) % segs], m); else o.tri(c0, ring[(k + 1) % segs], ring[k], m); }
    }
  }
  return o;
}
/** A straight tube from a to b (a post, a rung, a strut). */
export function rod(a, b, r, { segs = 10, m = 0, r2 = r } = {}) { return tube((t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t], (t) => r + (r2 - r) * t, { steps: 1, segs, m }); }
/** A bezier through control points (for tubes). */
export const curve = (...pts) => (t) => { let q = pts.map((p) => p.slice()); while (q.length > 1) { const n = []; for (let i = 0; i < q.length - 1; i++) n.push([q[i][0] + (q[i + 1][0] - q[i][0]) * t, q[i][1] + (q[i + 1][1] - q[i][1]) * t, q[i][2] + (q[i + 1][2] - q[i][2]) * t]); q = n; } return q[0]; };
/** A sheet (cloth, a leaf, a sail): fn(u, v) → [x, y, z], two-sided. */
export function sheet(nu, nv, fn, { m = 0 } = {}) { return surface(nu, nv, fn, { m }); }
/** A faceted crystal: a prism of `sides`, pointed at the top; crisp facets. */
export function gem(r, h, { sides = 6, tip = 0.32, m = 0, twist = 0, taper = 0.85, base = 0.12 } = {}) {
  const o = new Mesh(), ring = (y, rr, tw) => { const out = []; for (let i = 0; i < sides; i++) { const a = (i / sides) * Math.PI * 2 + tw; out.push(o.vert([Math.cos(a) * rr, y, Math.sin(a) * rr])); } return out; };
  const b0 = ring(0, r * (1 - base), 0), b1 = ring(h * base, r, twist * 0.2), b2 = ring(h * (1 - tip), r * taper, twist), top = o.vert([0, h, 0]), bot = o.vert([0, 0, 0]);
  const quad = (A, B) => { for (let i = 0; i < sides; i++) { const j = (i + 1) % sides; o.tri(A[i], B[j], A[j], m); o.tri(A[i], B[i], B[j], m); } };
  quad(b0, b1); quad(b1, b2);
  for (let i = 0; i < sides; i++) { const j = (i + 1) % sides; o.tri(b2[i], top, b2[j], m); o.tri(b0[j], bot, b0[i], m); }
  return o.flat();
}

function cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
function rotAxis(v, k, a) {
  const c = Math.cos(a), s = Math.sin(a), d = v[0] * k[0] + v[1] * k[1] + v[2] * k[2], x = cross(k, v);
  return [v[0] * c + x[0] * s + k[0] * d * (1 - c), v[1] * c + x[1] * s + k[1] * d * (1 - c), v[2] * c + x[2] * s + k[2] * d * (1 - c)];
}

// ---------- smooth noise (also used for the surfaces' texture) ----------
const PERM = (() => { const p = []; let s = 1234567; for (let i = 0; i < 256; i++) p.push(i); for (let i = 255; i > 0; i--) { s = (Math.imul(s, 1103515245) + 12345) >>> 0; const j = s % (i + 1); [p[i], p[j]] = [p[j], p[i]]; } return Uint8Array.from([...p, ...p]); })();
const fade = (t) => t * t * t * (t * (t * 6 - 15) + 10);
const lerp = (a, b, t) => a + (b - a) * t;
function grad(h, x, y, z) { const u = h & 8 ? y : x, v = h & 4 ? (h & 2 ? x : z) : h & 2 ? z : y; return (h & 1 ? -u : u) + (h & 2 ? -v : v) * 0.5; }
/** Perlin-style noise, 0…1. */
export function noise3(x, y, z) {
  const X = Math.floor(x) & 255, Y = Math.floor(y) & 255, Z = Math.floor(z) & 255;
  x -= Math.floor(x); y -= Math.floor(y); z -= Math.floor(z);
  const u = fade(x), v = fade(y), w = fade(z), P = PERM;
  const A = P[X] + Y, AA = P[A] + Z, AB = P[A + 1] + Z, B = P[X + 1] + Y, BA = P[B] + Z, BB = P[B + 1] + Z;
  const r = lerp(lerp(lerp(grad(P[AA], x, y, z), grad(P[BA], x - 1, y, z), u), lerp(grad(P[AB], x, y - 1, z), grad(P[BB], x - 1, y - 1, z), u), v),
    lerp(lerp(grad(P[AA + 1], x, y, z - 1), grad(P[BA + 1], x - 1, y, z - 1), u), lerp(grad(P[AB + 1], x, y - 1, z - 1), grad(P[BB + 1], x - 1, y - 1, z - 1), u), v), w);
  return Math.max(0, Math.min(1, r * 0.75 + 0.5));
}
export function fbm(x, y, z, oct = 3) { let a = 0, s = 0.5, f = 1, t = 0; for (let i = 0; i < oct; i++) { a += noise3(x * f, y * f, z * f) * s; t += s; s *= 0.5; f *= 2.03; } return a / t; }
export function rng(seed) { let s = (seed >>> 0) || 1; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; }
