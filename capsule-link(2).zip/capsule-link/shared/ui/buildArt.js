// Pixel art for things you build in the R.A.N.C.H.: play structures, built-in toys, decorations and
// the Link gate. Same style as paint.js: hard pixels, lit from the upper left, a soft ground shadow.
// Each returns { img, h } where h is how tall it stands, in yard units (a small creature is 1).
import { mk, dab, line, ramp } from './paint.js';
import { shadeHex } from './habitat.js';

const rect = (x, px, py, w, h, col) => { x.fillStyle = col; x.fillRect(Math.round(px), Math.round(py), Math.max(1, Math.round(w)), Math.max(1, Math.round(h))); };
const shadow = (x, cx, cy, rx, ry, a = 0.22) => { x.save(); x.globalAlpha = a; for (let yy = -ry; yy <= ry; yy++) { const half = Math.floor(rx * Math.sqrt(Math.max(0, 1 - (yy * yy) / (ry * ry)))); x.fillStyle = '#10142a'; x.fillRect(Math.round(cx - half), Math.round(cy + yy), half * 2 + 1, 1); } x.restore(); };

const cache = new Map();
export function buildArt(kind, accent = '#e5484d') {
  const key = `${kind}:${accent}`;
  if (!cache.has(key)) cache.set(key, paint(kind, accent));
  return cache.get(key);
}

function paint(kind, accent) {
  switch (kind) {
    case 'slide': {
      const w = 150, h = 120, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 5, w * 0.45, 5);
      const metal = ramp('#9aa6b8', 4, 0.4), sl = ramp(accent, 5, 0.45);
      for (const px of [22, 44]) rect(x, px, 20, 5, h - 26, metal[1]);
      for (let y = 30; y < h - 10; y += 12) rect(x, 22, y, 27, 3, metal[2]);
      rect(x, 18, 18, 34, 6, sl[3]);
      for (let i = 0; i < 90; i++) { const px = 50 + i, py = 22 + i * 0.85 + Math.sin(i / 30) * 4; rect(x, px, py, 2, 8, i < 6 ? sl[4] : sl[2]); rect(x, px, py, 2, 2, sl[4]); }
      return { img: c, h: 2.1 };
    }
    case 'swing': {
      // an A-frame with a wooden seat on two chains
      const w = 130, h = 130, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 5, w * 0.44, 5);
      const wood = ramp('#8a5a34', 5, 0.45);
      for (const [x0, x1] of [[8, 26], [28, 26], [w - 8, w - 26], [w - 28, w - 26]]) line(x, x0, h - 4, x1, 10, x0 < w / 2 ? wood[1] : wood[2], 5);
      rect(x, 18, 6, w - 36, 7, wood[3]); rect(x, 18, 6, w - 36, 2, wood[4]); rect(x, 18, 11, w - 36, 2, wood[0]);
      const sway = 3;
      for (const cx of [46, 84]) for (let y = 13; y < 92; y += 4) { rect(x, cx + (y / 92) * sway - 1, y, 3, 3, '#c8c2d6'); rect(x, cx + (y / 92) * sway, y + 1, 1, 1, '#6a6478'); }
      rect(x, 40 + sway, 92, 52, 6, wood[3]); rect(x, 40 + sway, 92, 52, 2, wood[4]); rect(x, 40 + sway, 97, 52, 2, wood[1]);
      return { img: c, h: 2.3 };
    }

    case 'climber': {
      const w = 140, h = 110, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 5, w * 0.45, 5);
      const bars = ramp(accent, 4, 0.4);
      for (let i = 0; i < 6; i++) { const px = 10 + i * 24; line(x, px, h - 6, px + 4, 20, bars[1], 3); }
      for (let y = 26; y < h - 8; y += 16) line(x, 10, y + 4, w - 10, y, bars[2], 3);
      for (let i = 0; i < 5; i++) dab(x, 22 + i * 24, 22, 3, bars[3]);
      return { img: c, h: 1.8 };
    }
    case 'tunnel': {
      // a ribbed play tunnel lying on its side, with a dark opening facing you
      const w = 160, h = 80, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 5, w * 0.46, 6);
      const col = ramp(accent, 6, 0.5);
      const cy = h - 36, R = 30;
      // the body: a cylinder seen at an angle, ribs every few pixels
      for (let px = 34; px < w - 12; px++) {
        const rib = (px % 12) < 3;
        for (let yy = -R; yy <= R; yy++) {
          const t = (yy + R) / (2 * R);
          const k = Math.max(0, Math.min(5, Math.round((1 - t) * 4 + (rib ? 1 : 0))));
          rect(x, px, cy + yy, 1, 1, col[k]);
        }
      }
      // the far end, lit
      for (let yy = -R; yy <= R; yy++) { const half = Math.sqrt(1 - (yy / R) ** 2) * 9; rect(x, w - 12 - half, cy + yy, half * 2, 1, col[2]); }
      // the near opening: rim, then the dark inside fading back
      for (let yy = -R; yy <= R; yy++) { const half = Math.sqrt(1 - (yy / R) ** 2) * 13; rect(x, 34 - half, cy + yy, half * 2 + 1, 1, col[5]); }
      for (let yy = -R + 4; yy <= R - 4; yy++) { const half = Math.sqrt(1 - (yy / (R - 4)) ** 2) * 9; rect(x, 34 - half, cy + yy, half * 2 + 1, 1, yy > 6 ? '#2a1d3a' : '#140e20'); }
      rect(x, 40, cy - R, w - 52, 2, shadeHex(accent, 0.45));
      return { img: c, h: 1.25 };
    }

    case 'chest': {
      const w = 70, h = 56, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, w * 0.44, 4);
      const wood = ramp('#a0683a', 5, 0.45);
      rect(x, 6, 18, w - 12, h - 24, wood[2]); for (let y = 22; y < h - 6; y += 8) rect(x, 6, y, w - 12, 2, wood[1]);
      rect(x, 4, 8, w - 8, 12, wood[3]); rect(x, 4, 8, w - 8, 3, wood[4]);
      rect(x, w / 2 - 5, 16, 10, 9, '#ffd23f'); rect(x, w / 2 - 2, 19, 4, 4, '#8a5a10');
      dab(x, 18, 8, 5, '#e5484d'); dab(x, w - 20, 7, 4, '#4ad0ff');
      return { img: c, h: 0.8 };
    }
    case 'post': {
      const w = 40, h = 110, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, 16, 4);
      rect(x, 4, h - 12, w - 8, 8, '#8a5a34');
      for (let y = 12; y < h - 12; y++) rect(x, 12, y, 16, 1, y % 4 ? '#d8b77a' : '#b8955a');
      rect(x, 8, 6, 24, 8, accent);
      return { img: c, h: 1.5 };
    }
    case 'hammock': {
      // two posts, ropes, and a striped hammock with a soft pillow
      const w = 180, h = 100, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 5, w * 0.45, 6);
      const wood = ramp('#7a5232', 5, 0.45);
      for (const px of [10, w - 18]) { rect(x, px, 8, 8, h - 12, wood[2]); rect(x, px, 8, 2, h - 12, wood[4]); rect(x, px - 2, 6, 12, 4, wood[1]); }
      for (const [x0, x1] of [[18, 34], [w - 18, w - 34]]) for (let i = 0; i < 3; i++) line(x, x0, 16 + i * 3, x1, 30, '#d8c8a0', 1);
      for (let i = 0; i <= 140; i++) {
        const t = i / 140, px = 32 + t * (w - 64), sag = Math.sin(t * Math.PI) * 26;
        const stripe = Math.floor(i / 9) % 3;
        const colr = stripe === 0 ? accent : stripe === 1 ? '#fff6e0' : shadeHex(accent, 0.35);
        for (let k = 0; k < 14; k++) rect(x, px, 28 + sag + k * 0.9, 1, 1, k < 2 ? shadeHex(colr, 0.25) : k > 11 ? shadeHex(colr, -0.25) : colr);
      }
      dab(x, 58, 44, 8, '#ffffff'); dab(x, 58, 46, 7, '#ece6f6');
      for (let i = 0; i < 9; i++) rect(x, 34 + i * 14, 40 + Math.sin(((34 + i * 14 - 32) / (w - 64)) * Math.PI) * 26, 1, 4, '#d8c8a0');
      return { img: c, h: 1.4 };
    }

    case 'fountain': {
      const w = 110, h = 110, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 5, w * 0.46, 6);
      const stone = ramp('#b9b2c8', 5, 0.4);
      for (let yy = 0; yy < 20; yy++) rect(x, 8, h - 26 + yy, w - 16, 1, yy < 4 ? stone[4] : stone[2]);
      rect(x, 14, h - 30, w - 28, 6, '#4aa8ff');
      rect(x, w / 2 - 6, 40, 12, h - 66, stone[3]);
      rect(x, w / 2 - 20, 36, 40, 8, stone[4]);
      for (let i = 0; i < 9; i++) { const a = -Math.PI / 2 + (i - 4) * 0.28; line(x, w / 2, 30, w / 2 + Math.cos(a) * 30, 20 + Math.sin(a) * -4 + Math.abs(i - 4) * 6, '#bfe6ff', 2); }
      return { img: c, h: 1.6 };
    }
    case 'birdbath': {
      const w = 60, h = 80, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, 18, 4);
      const stone = ramp('#c8c2d6', 4, 0.4);
      rect(x, w / 2 - 5, 24, 10, h - 30, stone[2]); rect(x, w / 2 - 12, h - 10, 24, 6, stone[1]);
      rect(x, 6, 16, w - 12, 10, stone[3]); rect(x, 10, 16, w - 20, 4, '#4aa8ff');
      return { img: c, h: 1 };
    }
    case 'statue': {
      const w = 70, h = 120, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, 26, 5);
      const st = ramp('#a8a0ba', 5, 0.45);
      rect(x, 8, h - 30, w - 16, 26, st[2]); rect(x, 8, h - 30, w - 16, 4, st[4]);
      dab(x, w / 2, h - 52, 16, st[3]); dab(x, w / 2 - 10, h - 72, 8, st[3]); dab(x, w / 2 + 10, h - 72, 8, st[3]); dab(x, w / 2, h - 62, 10, st[4]);
      rect(x, w / 2 - 6, h - 64, 3, 3, st[0]); rect(x, w / 2 + 4, h - 64, 3, 3, st[0]);
      return { img: c, h: 1.6 };
    }
    case 'flag': {
      const w = 60, h = 140, { c, x } = mk(w, h);
      shadow(x, 10, h - 4, 10, 3);
      rect(x, 8, 6, 4, h - 10, '#c8c2d6'); dab(x, 10, 6, 4, '#ffd23f');
      for (let i = 0; i < 40; i++) rect(x, 12 + i, 12 + Math.sin(i / 7) * 3, 1, 26, i % 14 < 7 ? accent : shadeHex(accent, 0.25));
      return { img: c, h: 2.4 };
    }
    case 'perch': {
      const w = 60, h = 150, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, 18, 4);
      const wood = ramp('#8a5a34', 4, 0.4);
      rect(x, w / 2 - 3, 16, 6, h - 20, wood[1]); rect(x, 6, 14, w - 12, 6, wood[2]); rect(x, 6, 14, w - 12, 2, wood[3]);
      return { img: c, h: 2.6 };
    }
    case 'gate': {
      const w = 220, h = 200, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 6, w * 0.46, 7);
      const st = ramp('#5b45c4', 5, 0.45);
      for (const px of [14, w - 40]) { rect(x, px, 30, 26, h - 36, st[2]); rect(x, px, 30, 6, h - 36, st[4]); }
      for (let i = 0; i <= 60; i++) { const t = i / 60, a = Math.PI * t; rect(x, 26 + t * (w - 52), 40 - Math.sin(a) * 30, 6, 10, st[3]); }
      // the portal: a soft shimmering field between the posts
      x.save(); x.globalAlpha = 0.35; for (let y = 40; y < h - 8; y += 2) rect(x, 40, y, w - 80, 1, y % 6 ? '#7dffcf' : '#c8fff0'); x.restore();
      dab(x, w / 2, 22, 8, '#7dffcf'); dab(x, w / 2, 22, 4, '#ffffff');
      return { img: c, h: 3.4 };
    }
    case 'lily': {
      const w = 40, h = 16, { c, x } = mk(w, h);
      for (let yy = -6; yy <= 6; yy++) { const half = Math.floor(16 * Math.sqrt(1 - (yy / 7) ** 2)); rect(x, w / 2 - half, 8 + yy, half * 2, 1, yy < -2 ? '#7ac85a' : '#4f9a3f'); }
      rect(x, w / 2, 2, 2, 7, '#3a7a30');
      dab(x, w / 2 + 8, 6, 3, '#ffb0d6'); dab(x, w / 2 + 8, 6, 1, '#ffffff');
      return { img: c, h: 0.22 };
    }
    case 'campfire': {
      const w = 80, h = 60, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 6, 30, 5, 0.3);
      for (const [a, b] of [[10, 66], [14, 62]]) line(x, a, h - 8, b, h - 16, '#6b4423', 6);
      line(x, 14, h - 16, 66, h - 8, '#7a5232', 6);
      for (let i = 0; i < 7; i++) dab(x, 12 + i * 9, h - 6, 4, i % 2 ? '#8a8296' : '#a8a0ba');
      return { img: c, h: 0.6 };
    }
    case 'pot': {
      const w = 90, h = 90, { c, x } = mk(w, h);
      const iron = ramp('#3a3550', 5, 0.5);
      line(x, 8, h - 4, 30, 6, '#5a4a3a', 4); line(x, w - 8, h - 4, w - 30, 6, '#5a4a3a', 4); rect(x, 26, 4, w - 52, 4, '#5a4a3a');
      line(x, w / 2, 8, w / 2, 26, '#8a8296', 2);
      for (let yy = 0; yy < 40; yy++) { const half = 30 * Math.sqrt(1 - ((yy - 14) / 30) ** 2); rect(x, w / 2 - half, 30 + yy, half * 2, 1, iron[Math.min(4, 1 + Math.floor((40 - yy) / 12))]); }
      rect(x, w / 2 - 32, 28, 64, 5, iron[4]);
      return { img: c, h: 1.2 };
    }
    case 'table': {
      const w = 140, h = 80, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, w * 0.45, 5);
      const wood = ramp('#a0683a', 5, 0.45);
      rect(x, 6, 20, w - 12, 10, wood[3]); rect(x, 6, 20, w - 12, 3, wood[4]); rect(x, 6, 28, w - 12, 3, wood[1]);
      for (const px of [14, w - 22]) rect(x, px, 30, 8, h - 34, wood[1]);
      // a cloth, a cutting board
      rect(x, 30, 18, 40, 4, '#e5484d'); for (let i = 0; i < 5; i++) rect(x, 30 + i * 8, 18, 4, 4, '#ffffff');
      rect(x, w - 60, 16, 38, 6, '#d8b77a');
      return { img: c, h: 1.05 };
    }
    case 'jar': {
      const w = 28, h = 40, { c, x } = mk(w, h);
      rect(x, 4, 10, w - 8, h - 12, 'rgba(220,240,255,.85)'); rect(x, 6, 18, w - 12, h - 22, accent); rect(x, 3, 4, w - 6, 7, '#8a5a34'); rect(x, 7, 20, 3, 10, 'rgba(255,255,255,.6)');
      return { img: c, h: 0.45 };
    }
    case 'arch': {
      // a course gate: two poles and a flag banner
      const w = 120, h = 130, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, w * 0.4, 4);
      for (const px of [10, w - 16]) { rect(x, px, 14, 6, h - 16, '#f4f0ff'); for (let y = 20; y < h - 4; y += 12) rect(x, px, y, 6, 5, accent); }
      for (let i = 0; i < w - 20; i++) rect(x, 12 + i, 8 + Math.sin(i / 9) * 2, 1, 14, Math.floor(i / 10) % 2 ? accent : '#ffffff');
      return { img: c, h: 2.1 };
    }
    case 'hurdle': {
      const w = 100, h = 50, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 3, w * 0.42, 3);
      for (const px of [10, w - 16]) rect(x, px, 10, 6, h - 12, '#f4f0ff');
      for (let i = 0; i < w - 12; i++) rect(x, 6 + i, 10, 1, 8, Math.floor(i / 12) % 2 ? '#e5484d' : '#ffffff');
      return { img: c, h: 0.55 };
    }
    case 'stump': {
      const w = 60, h = 44, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 3, 24, 4);
      const wood = ramp('#7a5232', 5, 0.45);
      rect(x, 8, 12, w - 16, h - 16, wood[2]); for (let px = 10; px < w - 10; px += 6) rect(x, px, 14, 2, h - 18, wood[1]);
      for (let yy = -6; yy <= 6; yy++) { const half = Math.sqrt(1 - (yy / 7) ** 2) * 22; rect(x, w / 2 - half, 12 + yy, half * 2, 1, yy < 0 ? '#e0b880' : '#c89a60'); }
      return { img: c, h: 0.55 };
    }
    case 'pier': {
      const w = 160, h = 50, { c, x } = mk(w, h);
      const wood = ramp('#8a5a34', 5, 0.45);
      for (let i = 0; i < 9; i++) { rect(x, 6 + i * 17, 6, 15, 18, wood[2 + (i % 2)]); rect(x, 6 + i * 17, 6, 15, 2, wood[4]); }
      for (const px of [10, 70, 140]) rect(x, px, 24, 6, h - 24, wood[0]);
      return { img: c, h: 0.6 };
    }
    case 'cone': {
      // a little track marker
      const w = 24, h = 30, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 2, 10, 2);
      for (let y = 4; y < h - 4; y++) { const half = 2 + (y / h) * 8; rect(x, w / 2 - half, y, half * 2, 1, y > 12 && y < 17 ? '#ffffff' : accent); }
      rect(x, 2, h - 5, w - 4, 3, '#2a2448');
      return { img: c, h: 0.32 };
    }
    case 'lowbar': {
      // a low bar to slide under: two posts and a striped pole up high
      const w = 120, h = 70, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 3, w * 0.42, 3);
      for (const px of [8, w - 14]) rect(x, px, 8, 6, h - 10, '#f4f0ff');
      for (let i = 0; i < w - 10; i++) rect(x, 5 + i, 8, 1, 7, Math.floor(i / 10) % 2 ? '#ffd23f' : '#2a2448');
      return { img: c, h: 0.95 };
    }
    case 'dummy': {
      // a straw training dummy on a post
      const w = 60, h = 110, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 3, 18, 4);
      const straw = ramp('#d8b25a', 5, 0.45), wood = ramp('#7a5232', 4, 0.4);
      rect(x, w / 2 - 3, 50, 6, h - 52, wood[1]);
      for (let y = 30; y < 78; y++) { const half = 14 + Math.sin((y - 30) / 48 * Math.PI) * 6; rect(x, w / 2 - half, y, half * 2, 1, straw[(y % 7 < 2) ? 1 : 3]); }
      rect(x, 6, 40, w - 12, 6, straw[2]);
      for (let y = 6; y < 30; y++) { const half = Math.sqrt(1 - ((y - 18) / 12) ** 2) * 11; rect(x, w / 2 - half, y, half * 2, 1, straw[3]); }
      rect(x, w / 2 - 8, 52, 16, 3, accent); rect(x, w / 2 - 2, 46, 4, 15, accent);
      return { img: c, h: 1.25 };
    }
    case 'can': {
      const w = 26, h = 34, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 2, 11, 2);
      const tin = ramp('#b8c0d0', 5, 0.4);
      rect(x, 4, 6, w - 8, h - 9, tin[2]); rect(x, 4, 6, 4, h - 9, tin[4]); rect(x, w - 8, 6, 4, h - 9, tin[0]);
      rect(x, 4, 12, w - 8, 12, accent); rect(x, 4, 12, w - 8, 2, '#ffffff');
      rect(x, 3, 4, w - 6, 3, tin[3]); rect(x, 3, h - 4, w - 6, 2, tin[1]);
      return { img: c, h: 0.38 };
    }
    case 'target': {
      // a bullseye on a stand
      const w = 80, h = 100, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 3, 26, 4);
      const wood = ramp('#7a5232', 4, 0.4);
      line(x, 18, h - 4, 30, 60, wood[1], 4); line(x, w - 18, h - 4, w - 30, 60, wood[2], 4);
      const cx = w / 2, cy = 38;
      for (const [r, col] of [[34, '#ffffff'], [28, '#e5484d'], [21, '#ffffff'], [14, '#e5484d'], [7, '#ffd23f']]) for (let yy = -r; yy <= r; yy++) { const half = Math.sqrt(r * r - yy * yy); rect(x, cx - half, cy + yy, half * 2, 1, col); }
      return { img: c, h: 1.2 };
    }
    case 'bed': {
      const w = 150, h = 40, { c, x } = mk(w, h);
      const wood = ramp('#8a5a34', 4, 0.4);
      rect(x, 4, 8, w - 8, h - 10, wood[2]); rect(x, 4, 8, w - 8, 3, wood[3]);
      rect(x, 10, 12, w - 20, h - 20, '#5a3a1c'); for (let i = 0; i < 40; i++) rect(x, 12 + (i * 37) % (w - 26), 13 + (i * 13) % (h - 24), 2, 1, '#7a5232');
      return { img: c, h: 0.4 };
    }
    case 'fossilmachine': {
      // a tall glass tube on a machine base, glowing liquid, a screen and a dial
      const w = 90, h = 150, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 5, 38, 6);
      const metal = ramp('#7a8aa8', 5, 0.45);
      rect(x, 8, h - 40, w - 16, 34, metal[1]); rect(x, 8, h - 40, w - 16, 5, metal[3]);
      rect(x, 14, h - 30, 22, 14, '#1b2a3a'); rect(x, 16, h - 28, 18, 10, '#3aff9a');
      for (let i = 0; i < 4; i++) rect(x, 18, h - 26 + i * 2, 6 + ((i * 5) % 9), 1, '#0a5a3a');
      dab(x, w - 24, h - 23, 6, metal[0]); dab(x, w - 24, h - 23, 3, accent);
      // the tube
      rect(x, 22, 12, w - 44, h - 54, 'rgba(160,230,255,.35)'); rect(x, 26, 40, w - 52, h - 84, 'rgba(90,255,190,.45)');
      rect(x, 22, 12, 4, h - 54, 'rgba(255,255,255,.55)'); rect(x, w - 26, 12, 4, h - 54, 'rgba(120,150,190,.6)');
      rect(x, 18, 6, w - 36, 8, metal[2]); rect(x, 18, h - 44, w - 36, 6, metal[2]);
      for (let i = 0; i < 6; i++) dab(x, 34 + (i * 11) % (w - 64), 50 + (i * 17) % 50, 2, 'rgba(230,255,240,.8)');
      return { img: c, h: 2.4 };
    }
    case 'incubator': {
      // a warm, rounded glass dome over a nest, with a little lamp
      const w = 90, h = 80, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, 38, 5);
      const base = ramp(accent, 5, 0.45);
      rect(x, 8, h - 22, w - 16, 16, base[2]); rect(x, 8, h - 22, w - 16, 4, base[4]); rect(x, 14, h - 14, 10, 4, '#ffd23f');
      for (let yy = 0; yy < 42; yy++) { const half = Math.round(36 * Math.sqrt(Math.max(0, 1 - ((42 - yy) / 42) ** 2))); rect(x, w / 2 - half, h - 22 - 42 + yy, half * 2, 1, yy < 3 ? 'rgba(255,255,255,.5)' : 'rgba(200,235,255,.28)'); }
      rect(x, w / 2 - 20, h - 30, 40, 8, '#a8763a'); dab(x, w / 2, h - 36, 9, '#f8f0e0'); dab(x, w / 2 + 3, h - 38, 3, '#9adf7a');
      dab(x, w / 2 - 18, h - 56, 3, 'rgba(255,255,255,.7)');
      return { img: c, h: 1 };
    }
    case 'blender': {
      // a round Berry Blender: a wide bowl on a stand, a clear lid with the spinner inside, four coloured stations
      const w = 110, h = 90, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, 46, 6);
      const metal = ramp('#9aa4b8', 5, 0.45);
      // one solid pedestal from under the bowl down to the base plate
      rect(x, w / 2 - 14, 42, 28, h - 52, metal[1]); rect(x, w / 2 - 14, 42, 6, h - 52, metal[2]); rect(x, w / 2 - 24, h - 12, 48, 7, metal[0]); rect(x, w / 2 - 24, h - 12, 48, 2, metal[2]);
      for (let yy = 0; yy < 30; yy++) { const half = Math.round(48 * Math.sqrt(Math.max(0, 1 - ((yy - 15) / 15) ** 2))); rect(x, w / 2 - half, 20 + yy, half * 2, 1, yy < 4 ? metal[4] : yy > 24 ? metal[0] : metal[2]); }
      for (let yy = 0; yy < 22; yy++) { const half = Math.round(40 * Math.sqrt(Math.max(0, 1 - ((yy - 11) / 11) ** 2))); rect(x, w / 2 - half, 24 + yy, half * 2, 1, yy < 3 ? 'rgba(255,255,255,.55)' : 'rgba(170,220,255,.35)'); }
      rect(x, w / 2 - 2, 26, 4, 18, '#e84a4a'); rect(x, w / 2 - 14, 33, 28, 4, '#e84a4a'); dab(x, w / 2, 35, 4, '#fff');
      [['#e84a4a', 14, 26], ['#3a7ae8', w - 18, 26], ['#3cb85a', 14, 42], ['#f2c23a', w - 18, 42]].forEach(([col, xx, yy]) => dab(x, xx, yy, 4, col));
      // the lid's handle sits on the lid itself
      rect(x, w / 2 - 10, 17, 20, 8, metal[3]); rect(x, w / 2 - 6, 12, 12, 6, metal[2]);
      return { img: c, h: 1.2 };
    }
    default: return null;
  }
}
