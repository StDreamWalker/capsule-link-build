// What they can really do with their moves and their kind: ask “Charmander, light the campfire”, “Pikachu, make
// some sparks”, “Ditto, turn into Pikachu”, “Abra, teleport!”, “Squirtle, water the plants”, “show me a move” —
// and, when it has the move (or the type) for it, it does it right there: flames, sparks, water, leaves, snow,
// wind, light, shields, levitating, digging, flying, growing, shrinking, transforming…
//
//   powerOf(text)              → the power asked for (or null)
//   canUse(idx, c, power)      → { ok, move?, why? }  (which of its moves it would use)
//   bestPower(idx, c)          → the power that suits it best (for “show me a trick”)
//   transformTarget(idx, save, text, self) → { id, name } it would turn into, or null
import { speciesOf, displayName } from './creature.js';

const id = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');
// moves: Showdown ids of moves that do it; types: kinds of creature that can do it anyway (their nature);
// species / abilities: who else can; fx: what the yard shows. Most particular first.
export const POWERS = [
  { id: 'transform', label: 'transform into something', fx: 'transform', moves: ['transform'], abilities: ['imposter', 'illusion'], species: /^(ditto|mew|zorua|zoroark)/,
    re: /transform|turn (yourself )?into|change into|become (a|an|my|the|like)|disguise (yourself )?as|pretend to be|impression of|shape ?shift|look like (a|an|my|the)/ },
  { id: 'teleport', label: 'teleport', fx: 'teleport', moves: ['teleport', 'allyswitch', 'shadowsneak', 'phantomforce', 'shadowforce', 'feint'], types: [],
    re: /teleport|vanish|disappear|blink (away|over)|warp|beam (yourself|over)|appear over/ },
  { id: 'dig', label: 'dig a hole', fx: 'dig', moves: ['dig', 'mudslap', 'bulldoze', 'drillrun', 'mudshot'], types: ['ground'],
    re: /dig (a |me a )?(hole|tunnel|down|under)|burrow|tunnel|go underground|dig dig/ },
  { id: 'fly', label: 'fly up high', fx: 'fly', moves: ['fly', 'bounce', 'skyattack', 'skydrop', 'aerialace', 'acrobatics', 'bravebird'], types: ['flying'],
    re: /\bfly\b|take off|soar|up (in|into) the (air|sky)|go up high|flap|loop the loop/ },
  { id: 'levitate', label: 'levitate things with its mind', fx: 'levitate', moves: ['psychic', 'telekinesis', 'magnetrise', 'confusion', 'psybeam', 'gravity', 'zenheadbutt', 'extrasensory', 'psyshock', 'futuresight', 'kinesis'], types: ['psychic'], abilities: ['levitate'],
    re: /levitat|telekine|float|hover|with your mind|lift (it|that|this|something|the|me)|move (things|it|that|stuff|the) with|mind powers?|psychic powers?|psychic/ },
  { id: 'grow', label: 'grow bigger', fx: 'grow', moves: ['growth', 'bulkup', 'coil', 'dynamaxcannon', 'stockpile', 'ingrain'], types: [],
    re: /grow (big|bigger|huge|tall|taller)|get (big|bigger|huge)|growth|super ?size|bulk up|giant/ },
  { id: 'shrink', label: 'shrink down small', fx: 'shrink', moves: ['minimize'], types: [],
    re: /minimi[sz]e|shrink|get (small|smaller|tiny)|make yourself (small|tiny)|tiny/ },
  { id: 'clones', label: 'make copies of itself', fx: 'clones', moves: ['doubleteam', 'substitute', 'shedtail'], types: [],
    re: /double team|clones?|copies of yourself|copy yourself|multiply|substitute|decoy/ },
  { id: 'protect', label: 'put up a shield', fx: 'protect', moves: ['protect', 'detect', 'lightscreen', 'reflect', 'barrier', 'safeguard', 'kingsshield', 'spikyshield', 'banefulbunker', 'irondefense', 'auroraveil', 'wideguard', 'quickguard', 'matblock', 'obstruct', 'silktrap'], types: [],
    re: /protect|shield|barrier|force ?field|reflect|keep (us|me|them|everyone) safe|bubble (around|over) (us|me)|safeguard|defen[cs]e/ },
  { id: 'heal', label: 'heal the others', fx: 'heal', moves: ['healpulse', 'wish', 'aromatherapy', 'healbell', 'lifedew', 'moonlight', 'softboiled', 'recover', 'junglehealing', 'lunarblessing', 'floralhealing', 'healingwish', 'synthesis', 'morningsun', 'roost', 'milkdrink', 'slackoff', 'refresh', 'pollenpuff', 'present'], types: [], abilities: ['healer', 'regenerator', 'naturalcure'],
    re: /heal|make (them|everyone|him|her|us|me) (feel )?better|cure|first aid|look after (the )?others|aromatherapy|make a wish|patch (them|us|me) up|soothe/ },
  { id: 'lullaby', label: 'sing a lullaby', fx: 'lullaby', moves: ['sing', 'yawn', 'sleeppowder', 'spore', 'hypnosis', 'grasswhistle', 'lovelykiss', 'darkvoid', 'relicsong', 'perishsong'], types: [],
    re: /lullaby|put (them|everyone|him|her|us|me) to sleep|make (them|everyone|us|me) sleepy|hypnoti[sz]|sleep powder|spore|yawn/ },
  { id: 'flash', label: 'make a bright light', fx: 'flash', moves: ['flash', 'dazzlinggleam', 'lightscreen', 'morningsun', 'moonlight', 'lusterpurge', 'prismaticlaser', 'photongeyser', 'tailglow', 'charge', 'mistyterrain'], types: [], abilities: ['illuminate'],
    re: /\bflash\b|light (up )?(the way|it up|the dark|the place|the room|the yard)|make (some )?light|\bglow\b|be (a|our|my) (lamp|torch|night ?light|light)|brighten|it'?s (too )?dark|can'?t see/ },
  { id: 'fire', label: 'breathe fire', fx: 'fire', moves: ['ember', 'flamethrower', 'firespin', 'fireblast', 'flamecharge', 'willowisp', 'heatwave', 'overheat', 'flareblitz', 'firepunch', 'inferno', 'lavaplume', 'mysticalfire', 'burningjealousy', 'incinerate', 'blazekick', 'fierydance', 'searingshot', 'firefang', 'blastburn', 'eruption', 'sacredfire'], types: ['fire'],
    re: /fire|flame|ember|light (the|a|our|my) (campfire|fire|bonfire|candles?|grill|bbq|barbecue|torch|fireplace|stove|oven)|warm (us|me|the place|everyone|it|them) up|toast|roast|heat (it|this|that|up)|blaze|burn|torch|hot ?hot|breathe fire|smoke ?signal/ },
  { id: 'spark', label: 'make sparks', fx: 'spark', moves: ['thundershock', 'thunderbolt', 'thunder', 'discharge', 'spark', 'thunderpunch', 'wildcharge', 'charge', 'electroball', 'voltswitch', 'nuzzle', 'thunderwave', 'zapcannon', 'shockwave', 'electroweb', 'paraboliccharge', 'risingvoltage', 'zingzap', 'boltstrike'], types: ['electric'],
    re: /spark|electric|zap|shock|thunder ?(bolt|shock)|lightning|charge (my|the|our) (phone|battery|laptop|car|lights?|devices?)|power (the|up|it|on)|static|volt|jolt|turn (the )?lights on/ },
  { id: 'water', label: 'spray water', fx: 'water', moves: ['watergun', 'hydropump', 'surf', 'aquajet', 'scald', 'waterpulse', 'brine', 'waterspout', 'muddywater', 'aquatail', 'liquidation', 'hydrocannon', 'waterfall', 'soak', 'raindance', 'whirlpool', 'snipeshot', 'chillingwater', 'flipturn', 'wavecrash'], types: ['water'],
    re: /water (the )?(plants|garden|flowers|crops|berries|grass|trees|lawn)|spray|squirt|water ?gun|hose|shower|put (out )?the fire|put it out|wash (me|it|the|this|that|us)|hydro|soak|wet|surf|make a (wave|splash)|fountain/ },
  { id: 'bubbles', label: 'blow bubbles', fx: 'bubbles', moves: ['bubble', 'bubblebeam', 'aquaring', 'sparklingaria', 'bubbles'], types: [],
    re: /bubbles?\b/ },
  { id: 'ice', label: 'make snow and ice', fx: 'ice', moves: ['icebeam', 'blizzard', 'powdersnow', 'icywind', 'iceshard', 'icepunch', 'icefang', 'aurorabeam', 'frostbreath', 'freezedry', 'snowscape', 'hail', 'mist', 'haze', 'sheercold', 'iciclecrash', 'iciclespear', 'tripleaxel', 'avalanche', 'glaciate', 'chillyreception'], types: ['ice'],
    re: /\bice\b|icy|freeze|frozen|frost|snowflakes?|snow ?(ball|man)|make (some )?snow|cool (us|me|it|them|the place|everyone) down|chill( out)?\b|ice cream|ice cubes?|cold/ },
  { id: 'leaves', label: 'make leaves and petals fly', fx: 'leaves', moves: ['razorleaf', 'magicalleaf', 'leafstorm', 'petaldance', 'petalblizzard', 'leafblade', 'energyball', 'solarbeam', 'gigadrain', 'megadrain', 'absorb', 'vinewhip', 'leafage', 'grassknot', 'seedbomb', 'bulletseed', 'trailblaze', 'flowertrick', 'grassyterrain', 'leechseed', 'stunspore', 'cottonspore'], types: ['grass'],
    re: /leaves|leaf|petals?|flowers? (shower|rain|storm)|confetti|grow (the |some )?(plants|garden|flowers|grass|trees|berries)|make (things|the plants|the garden|it) grow|vines?|blossom|bloom|seeds?/ },
  { id: 'wind', label: 'whip up a wind', fx: 'wind', moves: ['gust', 'tailwind', 'whirlwind', 'hurricane', 'defog', 'aircutter', 'airslash', 'twister', 'razorwind', 'bleakwindstorm', 'fly', 'featherdance', 'bravebird'], types: ['flying'],
    re: /\bwind\b|gust|breeze|blow (the|it|them|away|us)|fan (me|us|it)|tailwind|whirlwind|hurricane|tornado|cool breeze/ },
  { id: 'rock', label: 'throw up rocks', fx: 'rock', moves: ['rockthrow', 'rockslide', 'stoneedge', 'stealthrock', 'rocktomb', 'ancientpower', 'rockblast', 'powergem', 'smackdown', 'headsmash', 'rockpolish', 'meteorbeam', 'diamondstorm', 'saltcure'], types: ['rock'],
    re: /rocks?\b|stones?\b|pebbles?|boulder|gems?\b|crystals?|build (a|me a) (wall|tower|fort)/ },
  { id: 'quake', label: 'shake the ground', fx: 'quake', moves: ['earthquake', 'magnitude', 'bulldoze', 'stomp', 'stompingtantrum', 'earthpower', 'fissure', 'precipiceblades', 'highhorsepower', 'heavyslam', 'bodypress'], types: ['ground'],
    re: /earthquake|quake|shake the ground|stomp|rumble|tremor|make the ground shake|seismic/ },
  { id: 'ghost', label: 'do something spooky', fx: 'ghost', moves: ['shadowball', 'confuseray', 'nightshade', 'hex', 'astonish', 'curse', 'spite', 'trickortreat', 'lick', 'ominouswind', 'shadowclaw', 'poltergeist', 'destinybond', 'grudge'], types: ['ghost'],
    re: /spook|scare (me|us|them)|\bboo\b|haunt|ghost|curse|halloween|creepy|eerie|go invisible|invisible/ },
  { id: 'fairy', label: 'make sparkles', fx: 'fairy', moves: ['dazzlinggleam', 'moonblast', 'drainingkiss', 'charm', 'sweetkiss', 'babydolleyes', 'fairywind', 'disarmingvoice', 'playrough', 'mistyterrain', 'decorate', 'floralhealing', 'sparklyswirl', 'alluringvoice'], types: ['fairy'],
    re: /sparkl|glitter|magic|fairy (dust|wind)|twinkle|make it pretty|enchant|shimmer|pixie/ },
  { id: 'dragon', label: 'roar like a dragon', fx: 'dragon', moves: ['dragonbreath', 'dragonrage', 'dragonpulse', 'dracometeor', 'outrage', 'dragondance', 'dragonclaw', 'roar', 'dragontail', 'twister', 'scaleshot', 'clangingscales', 'dragonenergy'], types: ['dragon'],
    re: /roar|dragon (breath|dance|rage|pulse|fire)|draco|be a dragon|rawr/ },
  { id: 'poison', label: 'puff out poison', fx: 'poison', moves: ['poisongas', 'smog', 'sludgebomb', 'sludge', 'toxic', 'acid', 'poisonpowder', 'clearsmog', 'venoshock', 'gunkshot', 'acidspray', 'toxicspikes', 'banefulbunker', 'mortalspin'], types: ['poison'],
    re: /poison|toxic|smog|sludge|stink|stinky|acid|gas\b|ooze/ },
  { id: 'smoke', label: 'make a smokescreen', fx: 'smoke', moves: ['smokescreen', 'haze', 'mist', 'sandattack', 'smog', 'poisongas', 'kinesis'], types: [],
    re: /smoke ?screen|smoke|mist|haze|cloud of|make (some )?fog|foggy/ },
  { id: 'steel', label: 'gleam like metal', fx: 'steel', moves: ['irondefense', 'flashcannon', 'metalclaw', 'ironhead', 'meteormash', 'steelwing', 'autotomize', 'shiftgear', 'gyroball', 'magnetbomb', 'mirrorshot', 'gearup', 'makeitrain', 'steelbeam', 'smartstrike'], types: ['steel'],
    re: /metal|shiny|shine|polish|iron|gleam|steel|magnet|robot|gears?/ },
  { id: 'dark', label: 'melt into the shadows', fx: 'dark', moves: ['darkpulse', 'nightslash', 'suckerpunch', 'snarl', 'nastyplot', 'foulplay', 'knockoff', 'crunch', 'bite', 'thief', 'darkestlariat', 'obstruct', 'partingshot'], types: ['dark'],
    re: /\bdark(ness)?\b|shadows?|sneak|sneaky|night ?time|lurk|stealth|ninja/ },
  { id: 'fight', label: 'show off its moves', fx: 'fight', moves: ['karatechop', 'brickbreak', 'closecombat', 'machpunch', 'drainpunch', 'dynamicpunch', 'focuspunch', 'highjumpkick', 'lowkick', 'rocksmash', 'skyuppercut', 'crosschop', 'aurasphere', 'bulkup', 'vacuumwave', 'superpower', 'hammerarm', 'jumpkick', 'doublekick', 'triplekick', 'forcepalm'], types: ['fighting'],
    re: /karate|kung ?fu|punch|kick|chop|break (the|a|that) (board|brick|rock|log|wood)|show (me )?your (strength|muscles)|flex|kata|martial|boxing|knock (it|that) over/ },
  { id: 'bug', label: 'spin some silk', fx: 'bug', moves: ['stringshot', 'stickyweb', 'silverwind', 'bugbuzz', 'signalbeam', 'quiverdance', 'ragepowder', 'infestation', 'xscissor', 'uturn', 'pounce', 'skittersmack'], types: ['bug'],
    re: /string ?shot|web|silk|cocoon|thread|spin (a|some|me)|buzz/ },
  { id: 'splash', label: 'use Splash', fx: 'splash', moves: ['splash'], types: [], species: /^(magikarp|gyarados|feebas)/,
    re: /\bsplash\b/ },
  { id: 'metronome', label: 'use a random move', fx: 'metronome', moves: ['metronome', 'assist', 'sleeptalk', 'naturepower', 'copycat', 'mefirst', 'mimic', 'sketch', 'mirrormove'], types: [],
    re: /metronome|surprise me|random move|wag your finger|anything you like|mimic|copy (my|that) move|sketch/ },
  // anything at all: the best of what it can do
  { id: 'trick', label: 'show you one of its moves', fx: 'trick', moves: [], types: [],
    re: /do (a|your|some|one of your|a cool|a fun) (trick|move|power|thing)|show (me |us )?(a trick|your (powers?|moves?|skills?|abilities|tricks?)|what you can do|a move|something cool|off (a|your) move)|use (a|one of your|your|any) (moves?|powers?|attack|abilit)|what can you do|special (move|power)|show off/ },
];
export const POWER_BY_ID = Object.fromEntries(POWERS.map((p) => [p.id, p]));

/** The power asked for (by the words; “use Flamethrower” by the move's name), or null. */
export function powerOf(text, idx = null) {
  const s = String(text ?? '').toLowerCase();
  const tok = /\[power:([a-z]+)\]/.exec(s); if (tok && POWER_BY_ID[tok[1]]) return POWER_BY_ID[tok[1]]; // (placed by the language model)
  // “use Thunderbolt” / “do Ember”: the move itself
  const m = /\b(use|do|try|show (me |us )?|let'?s see|try out)\s+(your\s+)?([a-z][a-z' -]{2,24}?)(\s+(on|at|for|again|please|now)\b|[!.?,]|$)/.exec(s);
  if (m) { const mv = moveByName(idx, m[4]); if (mv) { const p = POWERS.find((x) => x.moves.includes(mv.sid)) ?? typePower(mv.type); if (p) return { ...p, named: mv }; } }
  for (const p of POWERS) if (p.re.test(s)) return p;
  return null;
}
function moveByName(idx, name) {
  const k = id(name); if (!k || k.length < 3) return null;
  for (const mv of idx?.moves?.values?.() ?? []) { const sid = id(mv.showdownName ?? mv.name); if (sid === k || id(mv.name) === k) return { sid, name: mv.name, type: String(mv.type ?? '').toLowerCase(), id: mv.id }; }
  // a real move's name even if the dataset doesn't have it
  for (const p of POWERS) if (p.moves.includes(k)) return { sid: k, name, type: '', id: null };
  return null;
}
// a made-up type still has an element (“Spark”, “Frost”, “Sprout”, “Gale”): which real type it's like
const ELEM = [[/fire|ember|flame|blaze|cinder|magma|lava|heat/, 'fire'], [/water|tide|aqua|wave|sea|rain/, 'water'], [/grass|sprout|leaf|plant|bloom|flora|seed|wood/, 'grass'], [/electric|volt|spark|thunder|zap|storm/, 'electric'], [/ice|frost|snow|cold|glacier/, 'ice'], [/fairy|charm|pixie/, 'fairy'], [/ghost|spirit|phantom/, 'ghost'], [/dark|shade|shadow|night/, 'dark'], [/psychic|mind|psi|dream/, 'psychic'], [/fighting|brawl|martial|fist/, 'fighting'], [/steel|metal|iron/, 'steel'], [/poison|toxic|venom/, 'poison'], [/rock|stone|crystal|gem/, 'rock'], [/ground|earth|sand|mud/, 'ground'], [/flying|gale|wind|air|sky|bird/, 'flying'], [/bug|insect/, 'bug'], [/dragon|wyrm|drake/, 'dragon'], [/normal|plain/, 'normal']];
export const elementOf = (t) => { const s = String(t ?? '').toLowerCase(); return ELEM.find(([re]) => re.test(s))?.[1] ?? s; };
export const POWER_EXAMPLE = { transform: 'Transform', teleport: 'Teleport', dig: 'Dig', fly: 'Fly', levitate: 'Psychic', grow: 'Growth', shrink: 'Minimize', clones: 'Double Team', protect: 'Protect', heal: 'Heal Pulse', lullaby: 'Sing', flash: 'Flash', fire: 'Ember', spark: 'Thunder Shock', water: 'Water Gun', bubbles: 'Bubble', ice: 'Ice Beam', leaves: 'Razor Leaf', wind: 'Gust', rock: 'Rock Throw', quake: 'Earthquake', ghost: 'Shadow Ball', fairy: 'Dazzling Gleam', dragon: 'Dragon Breath', poison: 'Poison Gas', smoke: 'Smokescreen', steel: 'Iron Defense', dark: 'Dark Pulse', fight: 'Karate Chop', bug: 'String Shot', splash: 'Splash', metronome: 'Metronome' };
const TYPE_POWER = { fire: 'fire', electric: 'spark', water: 'water', ice: 'ice', grass: 'leaves', flying: 'wind', rock: 'rock', ground: 'quake', psychic: 'levitate', ghost: 'ghost', fairy: 'fairy', dragon: 'dragon', poison: 'poison', steel: 'steel', dark: 'dark', fighting: 'fight', bug: 'bug', normal: 'trick' };
const typePower = (type) => POWER_BY_ID[TYPE_POWER[elementOf(type)]] ?? null;

function knownMoves(idx, c) {
  return (c.moves ?? []).map((m) => idx?.moves?.get?.(m.id ?? m)).filter(Boolean).map((mv) => ({ sid: id(mv.showdownName ?? mv.name), name: mv.name, type: elementOf(`${mv.type ?? ''} ${idx?.types?.get?.(mv.type)?.name ?? ''}`) }));
}
function kindOf(idx, c) {
  const sp = speciesOf(idx, c);
  const types = [...(sp?.types ?? [])].map((t) => elementOf(`${t} ${idx?.types?.get?.(t)?.name ?? ''}`));
  const abil = [c.ability, ...(Array.isArray(sp?.abilities) ? sp.abilities : Object.values(sp?.abilities ?? {}))].filter(Boolean).map(id);
  return { sp, types, abil, kind: id(sp?.showdownName ?? sp?.name) };
}
/** Can it? Which move it would use, or why not. */
export function canUse(idx, c, power) {
  if (!power) return { ok: false, why: 'unknown' };
  const mv = knownMoves(idx, c), k = kindOf(idx, c);
  if (power.id === 'trick') { const b = bestPower(idx, c); return b ? { ok: true, power: b.power, move: b.move } : { ok: false, why: 'nothing' }; }
  if (power.id === 'metronome') { const has = mv.find((m) => power.moves.includes(m.sid)); if (!has) return { ok: false, why: 'move', need: 'Metronome' }; const pool = POWERS.filter((p) => !['trick', 'metronome', 'transform'].includes(p.id)); return { ok: true, power: pool[Math.floor(Math.random() * pool.length)], move: has.name, random: true }; }
  if (power.named) { const has = mv.find((m) => m.sid === power.named.sid); if (has) return { ok: true, move: has.name }; }
  const byMove = mv.find((m) => power.moves.includes(m.sid));
  if (byMove) return { ok: true, move: byMove.name };
  if (power.species?.test(k.kind)) return { ok: true, move: null };
  if (power.abilities?.some((a) => k.abil.includes(a))) return { ok: true, move: null };
  if (power.types?.some((t) => k.types.includes(t))) return { ok: true, move: null, byType: true };
  // a move of the right type does it too (a Fire move makes flames)
  const tp = mv.find((m) => typePower(m.type)?.id === power.id);
  if (tp) return { ok: true, move: tp.name };
  return { ok: false, why: 'move', need: power.label, example: POWER_EXAMPLE[power.id] ?? null, type: power.types?.[0] ?? null };
}
/** The power that suits it best: one of its own moves first, then its type. */
export function bestPower(idx, c) {
  const mv = knownMoves(idx, c), k = kindOf(idx, c);
  for (const m of mv) { const p = POWERS.find((x) => x.moves.includes(m.sid) && !['metronome', 'splash'].includes(x.id)); if (p) return { power: p, move: m.name }; }
  for (const m of mv) { const p = typePower(m.type); if (p && p.id !== 'trick') return { power: p, move: m.name }; }
  for (const t of k.types) { const p = typePower(t); if (p && p.id !== 'trick') return { power: p, move: null }; }
  return null;
}
/** What “turn into …” means: another creature here by name, a species by name, or any creature present. */
export function transformTarget(idx, save, text, self, here = []) {
  const s = String(text ?? '').toLowerCase();
  const tail = /(?:into|as|like|be|become|of)\s+(?:a |an |my |the |your )?([a-z][a-z' .-]{1,30})/.exec(s)?.[1]?.trim() ?? '';
  const words = tail.split(/\s+/).slice(0, 3);
  if (/^(me|you|yourself|a (person|human)|human|people|my (mum|mom|dad|friend))\b/.test(tail)) return { person: true };
  // a creature here, by its name
  for (const u of here) { const c = save?.creatures?.[u]; if (!c || u === self.uid) continue; const n = displayName(idx, c).toLowerCase(); if (n && tail.startsWith(n)) return { id: c.formId || c.speciesId, name: displayName(idx, c), shiny: !!c.shiny }; }
  // a species by name (the longest that fits)
  for (let n = Math.min(3, words.length); n >= 1; n--) {
    const k = id(words.slice(0, n).join(' '));
    for (const sp of idx?.species?.values?.() ?? []) if (id(sp.name) === k || id(sp.showdownName) === k || sp.id === k) return { id: sp.id, name: sp.name };
  }
  // anyone else here
  const others = here.filter((u) => u !== self.uid && save?.creatures?.[u] && !save.creatures[u].egg);
  if (others.length) { const c = save.creatures[others[Math.floor(Math.random() * others.length)]]; return { id: c.formId || c.speciesId, name: displayName(idx, c), any: true }; }
  return null;
}
