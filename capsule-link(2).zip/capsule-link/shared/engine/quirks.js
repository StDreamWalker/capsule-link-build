// Quirks: little parts of a personality that a nature can (but doesn't have to) bring. A Lax creature
// *might* sleep deeply, nap a lot, or not care for hard exercise — or none of those. Each creature gets
// up to two, picked once from the pool its nature leans toward (and kept: c.quirks), so two creatures of
// the same nature can be quite different.
//
//   quirksOf(idx, c)      → [{ id, name, good, bad }]   (fills c.quirks the first time)
//   hasQuirk(c, id)       → true/false (after quirksOf has run once; tickAll does that)
//   QUIRK_FX              the numbers the rest of the engine uses

export const QUIRKS = {
  'deep-sleeper': { name: 'Deep sleeper', good: 'Gets energy back faster when napping.', bad: '' },
  napper: { name: 'Loves a nap', good: 'Dozes off on their own whenever they get a bit tired.', bad: 'Naps a lot more than most.' },
  'couch-potato': { name: 'Couch potato', good: '', bad: 'Doesn’t enjoy hard exercise (training, the obstacle course) as much.' },
  tireless: { name: 'Tireless', good: 'Runs out of energy more slowly.', bad: '' },
  restless: { name: 'Restless', good: 'Training is a joy.', bad: 'Uses up energy faster, and naps are short.' },
  glutton: { name: 'Big appetite', good: 'Food makes them extra happy.', bad: 'Gets hungry sooner.' },
  picky: { name: 'Picky eater', good: 'Favourite foods mean the world to them.', bad: 'Anything else barely cheers them up.' },
  'clean-freak': { name: 'Neat and tidy', good: 'Stays clean longer and loves bath or brushing time.', bad: '' },
  messy: { name: 'Messy', good: 'Never minds a bit of dirt.', bad: 'Gets grubby quickly.' },
  cuddly: { name: 'Cuddly', good: 'Being petted makes their day.', bad: '' },
  independent: { name: 'Independent', good: 'Happy enough on their own (joy fades more slowly).', bad: 'Petting doesn’t do as much.' },
  'quick-learner': { name: 'Quick learner', good: 'Gets more experience from training.', bad: '' },
  speedy: { name: 'Fleet-footed', good: 'Faster than their stats suggest on the course and when dodging.', bad: '' },
  hothead: { name: 'Hot-headed', good: 'Puts extra power into strength training.', bad: 'Gets fed up with fussing sooner.' },
  curious: { name: 'Curious', good: 'Turns up more when scavenging.', bad: '' },
  'early-bird': { name: 'Early bird', good: 'Cheerful in the mornings.', bad: 'Tired by evening.' },
};

// numbers for the rest of the engine
export const QUIRK_FX = {
  napRate: { 'deep-sleeper': 1.45, restless: 0.85 },
  napAt: { napper: 45 },            // energy below which they doze off by themselves (default 22)
  napEnd: { restless: 80 },          // they wake up at this energy instead of full
  decay: { tireless: { energy: 0.75 }, restless: { energy: 1.25 }, glutton: { fullness: 1.3 }, 'clean-freak': { hygiene: 0.75 }, messy: { hygiene: 1.35 }, independent: { joy: 0.8 } },
};

// the pools natures lean toward: by the stat they favour and the one they neglect, and by name
const BY_UP = { atk: ['hothead', 'glutton', 'restless'], def: ['tireless', 'deep-sleeper', 'independent'], spe: ['speedy', 'restless', 'early-bird'], spa: ['quick-learner', 'curious', 'picky'], spd: ['cuddly', 'clean-freak', 'deep-sleeper'] };
const BY_DOWN = { atk: ['cuddly'], def: ['messy'], spe: ['couch-potato', 'napper'], spa: ['glutton'], spd: ['hothead', 'independent'] };
const BY_NAME = {
  lax: ['deep-sleeper', 'napper', 'couch-potato', 'messy'], relaxed: ['napper', 'deep-sleeper', 'couch-potato'], quiet: ['independent', 'napper'], sassy: ['picky', 'independent'],
  hasty: ['restless', 'speedy'], jolly: ['speedy', 'early-bird'], naive: ['curious', 'restless'], timid: ['independent', 'speedy'],
  brave: ['hothead', 'tireless'], adamant: ['hothead', 'tireless'], naughty: ['messy', 'hothead'], lonely: ['independent', 'cuddly'],
  bold: ['tireless', 'glutton'], impish: ['messy', 'curious'], modest: ['quick-learner', 'picky'], mild: ['cuddly', 'quick-learner'], rash: ['restless', 'messy'],
  calm: ['clean-freak', 'deep-sleeper'], gentle: ['cuddly', 'clean-freak'], careful: ['clean-freak', 'picky'],
  hardy: [], docile: ['napper'], serious: ['quick-learner'], bashful: ['independent'], quirky: ['curious', 'picky', 'restless'],
  // the original data set's temperaments
  mellow: ['napper', 'deep-sleeper', 'couch-potato'], dreamy: ['napper', 'deep-sleeper'], serene: ['deep-sleeper', 'clean-freak'], placid: ['napper', 'couch-potato'],
  rowdy: ['restless', 'messy'], eager: ['quick-learner', 'restless'], cheery: ['early-bird', 'cuddly'], reckless: ['hothead', 'restless'], fierce: ['hothead', 'tireless'],
  skittish: ['speedy', 'independent'], sulky: ['picky', 'independent'], gruff: ['hothead', 'independent'], stoic: ['tireless', 'independent'], wise: ['quick-learner', 'curious'],
};
const hash = (s) => { let h = 2166136261; for (const ch of String(s)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0; return h; };
const CLASH = [['tireless', 'restless'], ['deep-sleeper', 'restless'], ['clean-freak', 'messy'], ['cuddly', 'independent'], ['glutton', 'picky'], ['napper', 'restless'], ['couch-potato', 'restless']];

/** The quirks a creature has (0–2), decided once from its nature and kept. */
export function quirksOf(idx, c) {
  if (!c) return [];
  if (!Array.isArray(c.quirks)) {
    const t = idx?.temperaments?.get?.(c.temper);
    const name = String(t?.name ?? c.temper ?? '').toLowerCase();
    const pool = [...new Set([...(BY_NAME[name] ?? []), ...(BY_UP[t?.up] ?? []), ...(BY_DOWN[t?.down] ?? [])])];
    const got = [];
    let h = hash(`${c.uid}:${c.pid ?? ''}`);
    // the nature's own leanings are likelier; each one has about a one-in-four chance
    for (const id of pool) {
      h = Math.imul(h ^ (h >>> 15), 2246822519) >>> 0;
      if (got.length < 2 && h % 100 < 27 && !got.some((g) => CLASH.some(([a, b]) => (a === g && b === id) || (b === g && a === id)))) got.push(id);
    }
    // and now and then one that has nothing to do with their nature at all
    h = Math.imul(h ^ (h >>> 13), 3266489917) >>> 0;
    if (got.length < 2 && h % 100 < 8) { const all = Object.keys(QUIRKS); const id = all[h % all.length]; if (!got.includes(id) && !got.some((g) => CLASH.some(([a, b]) => (a === g && b === id) || (b === g && a === id)))) got.push(id); }
    c.quirks = got;
  }
  return c.quirks.filter((id) => QUIRKS[id]).map((id) => ({ id, ...QUIRKS[id] }));
}
export const hasQuirk = (c, id) => Array.isArray(c?.quirks) && c.quirks.includes(id);
/** A multiplier from a QUIRK_FX table (1 when none apply). */
export function quirkMul(c, table, key = null) {
  let m = 1;
  for (const q of c?.quirks ?? []) { const v = table[q]; if (v == null) continue; m *= key ? (v[key] ?? 1) : v; }
  return m;
}
/** The first value a quirk sets in a table, or the fallback. */
export function quirkVal(c, table, fallback) { for (const q of c?.quirks ?? []) if (table[q] != null) return table[q]; return fallback; }
