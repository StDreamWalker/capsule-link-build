// A hidden extra in Battle Link: type the name of one of the series' 50 best-known battlers where you'd look for a
// friend, and you can battle them, with the team they're best known for, from the game they're best known from.
// Each mon: "Species|level|Move/Move/Move/Move|item". Teams and levels follow those games; movesets follow them where
// the game gave one, and are filled in with moves the species learns there otherwise.
const T = (name, title, avatar, team, aliases = []) => ({ name, title, avatar, team: team.trim().split(/\n\s*/).map(parseMon), aliases });
function parseMon(line) {
  const [species, lv, moves, item = ''] = line.split('|');
  return { species: species.trim(), level: Number(lv), moves: moves.split('/').map((m) => m.trim()).filter(Boolean), item: item.trim() };
}

export const FAMOUS_TRAINERS = [
  T('Red', 'HeartGold & SoulSilver (Mt. Silver)', 'red', `
    Pikachu|88|Volt Tackle/Thunderbolt/Quick Attack/Iron Tail|Light Ball
    Espeon|84|Psychic/Shadow Ball/Morning Sun/Reflect
    Snorlax|82|Body Slam/Crunch/Rest/Blizzard
    Venusaur|84|Frenzy Plant/Giga Drain/Sunny Day/Synthesis
    Charizard|84|Blast Burn/Flare Blitz/Air Slash/Dragon Pulse
    Blastoise|84|Hydro Cannon/Blizzard/Flash Cannon/Focus Blast`),
  T('Blue', 'Red & Blue (Champion)', 'blue', `
    Pidgeot|61|Wing Attack/Mirror Move/Sky Attack/Whirlwind
    Alakazam|59|Psybeam/Psychic/Reflect/Recover
    Rhydon|61|Stomp/Horn Drill/Fury Attack/Leer
    Exeggutor|61|Barrage/Hypnosis/Stomp/Leech Seed
    Arcanine|63|Roar/Ember/Take Down/Leer
    Blastoise|65|Bite/Withdraw/Blizzard/Hydro Pump`, ['gary', 'gary oak', 'blue oak']),
  T('Lance', 'HeartGold & SoulSilver (Champion)', 'lance', `
    Gyarados|46|Waterfall/Ice Fang/Earthquake/Hyper Beam
    Dragonite|49|Thunder/Thunder Wave/Outrage/Fire Blast
    Dragonite|49|Blizzard/Hyper Beam/Outrage/Safeguard
    Aerodactyl|48|Rock Slide/Crunch/Wing Attack/Ancient Power
    Charizard|48|Flamethrower/Wing Attack/Slash/Fire Spin
    Dragonite|50|Extreme Speed/Outrage/Fire Blast/Blizzard|Sitrus Berry`),
  T('Steven', 'Ruby & Sapphire (Champion)', 'steven', `
    Skarmory|57|Spikes/Steel Wing/Aerial Ace/Toxic
    Claydol|55|Earthquake/Ancient Power/Psychic/Light Screen
    Aggron|56|Thunder/Earthquake/Solar Beam/Dragon Claw
    Cradily|56|Giga Drain/Ancient Power/Ingrain/Confuse Ray
    Armaldo|56|Water Pulse/Ancient Power/Aerial Ace/Slash
    Metagross|58|Earthquake/Psychic/Meteor Mash/Hyper Beam|Sitrus Berry`, ['steven stone']),
  T('Wallace', 'Emerald (Champion)', 'wallace', `
    Wailord|57|Rain Dance/Water Spout/Double-Edge/Blizzard
    Tentacruel|55|Toxic/Hydro Pump/Sludge Bomb/Ice Beam
    Ludicolo|56|Giga Drain/Surf/Leech Seed/Double Team
    Whiscash|56|Earthquake/Surf/Amnesia/Hyper Beam
    Gyarados|56|Dragon Dance/Earthquake/Hyper Beam/Surf
    Milotic|58|Recover/Surf/Ice Beam/Toxic|Sitrus Berry`),
  T('Cynthia', 'Platinum (Champion)', 'cynthia', `
    Spiritomb|58|Dark Pulse/Psychic/Silver Wind/Shadow Ball
    Roserade|58|Energy Ball/Sludge Bomb/Toxic/Extrasensory
    Togekiss|60|Air Slash/Aura Sphere/Water Pulse/Shock Wave
    Lucario|60|Aura Sphere/Dragon Pulse/Psychic/Earthquake
    Milotic|58|Surf/Ice Beam/Mirror Coat/Aqua Ring
    Garchomp|62|Dragon Rush/Earthquake/Brick Break/Giga Impact|Sitrus Berry`),
  T('Alder', 'Black & White (Champion)', 'alder', `
    Accelgor|75|Bug Buzz/Focus Blast/Giga Drain/Spikes
    Bouffalant|75|Head Charge/Earthquake/Megahorn/Swords Dance
    Druddigon|75|Outrage/Superpower/Rock Slide/Night Slash
    Vanilluxe|75|Blizzard/Flash Cannon/Acid Armor/Hail
    Escavalier|75|Iron Head/Megahorn/Swords Dance/Return
    Volcarona|77|Fire Blast/Bug Buzz/Hurricane/Quiver Dance|Sitrus Berry`),
  T('Iris', 'Black 2 & White 2 (Champion)', 'iris', `
    Hydreigon|57|Dragon Pulse/Focus Blast/Flamethrower/Surf
    Druddigon|57|Dragon Tail/Revenge/Chip Away/Retaliate
    Aggron|57|Iron Tail/Rock Slide/Dragon Claw/Double-Edge
    Archeops|57|Acrobatics/Dragon Claw/Rock Slide/Endeavor
    Lapras|57|Hydro Pump/Ice Beam/Thunder/Dragon Pulse
    Haxorus|59|Dragon Dance/Dragon Claw/Earthquake/Rock Slide|Sitrus Berry`),
  T('Diantha', 'X & Y (Champion)', 'diantha', `
    Hawlucha|64|Flying Press/Swords Dance/X-Scissor/Poison Jab
    Tyrantrum|65|Head Smash/Dragon Claw/Earthquake/Crunch
    Aurorus|65|Blizzard/Thunder/Reflect/Light Screen
    Gourgeist|65|Phantom Force/Seed Bomb/Flamethrower/Trick-or-Treat
    Goodra|66|Muddy Water/Dragon Pulse/Fire Blast/Focus Blast
    Gardevoir|68|Moonblast/Psychic/Thunderbolt/Calm Mind|Gardevoirite`),
  T('Leon', 'Sword & Shield (Champion)', 'leon', `
    Aegislash|62|Shadow Ball/Sacred Sword/King's Shield/Flash Cannon
    Dragapult|62|Dragon Darts/Shadow Ball/Thunderbolt/Fly
    Haxorus|63|Dragon Claw/Earthquake/Swords Dance/Iron Head
    Seismitoad|64|Muddy Water/Earth Power/Drain Punch/Stealth Rock
    Cinderace|64|Pyro Ball/Bounce/High Jump Kick/Sucker Punch
    Charizard|65|Fire Blast/Air Slash/Ancient Power/Solar Beam|Sitrus Berry`),
  T('Geeta', 'Scarlet & Violet (Top Champion)', 'geeta', `
    Espathra|61|Lumina Crash/Dazzling Gleam/Quick Attack/Reflect
    Gogoat|61|Horn Leech/Bulldoze/Bulk Up/Play Rough
    Veluza|61|Aqua Cutter/Psycho Cut/Night Slash/Ice Fang
    Avalugg|61|Avalanche/Body Press/Crunch/Curse
    Kingambit|62|Kowtow Cleave/Iron Head/Stone Edge/Zen Headbutt
    Glimmora|62|Mortal Spin/Sludge Wave/Earth Power/Power Gem`),
  T('Nemona', 'Scarlet & Violet (final battle)', 'nemona', `
    Lycanroc|65|Stone Edge/Crunch/Drill Run/Accelerock
    Goodra|65|Dragon Pulse/Sludge Bomb/Fire Blast/Thunderbolt
    Dudunsparce|65|Hyper Drill/Drill Run/Coil/Dragon Rush
    Orthworm|65|Iron Head/Body Press/Earthquake/Coil
    Pawmot|65|Double Shock/Close Combat/Ice Punch/Quick Attack
    Meowscarada|66|Flower Trick/Knock Off/U-turn/Thunder Punch`),
  T('Kukui', 'Sun & Moon (Champion)', 'kukui', `
    Lycanroc|57|Stone Edge/Accelerock/Crunch/Stealth Rock
    Ninetales-Alola|56|Blizzard/Dazzling Gleam/Ice Shard/Aurora Veil
    Braviary|56|Brave Bird/Crush Claw/Superpower/Tailwind
    Magnezone|56|Flash Cannon/Thunderbolt/Discharge/Tri Attack
    Snorlax|56|High Horsepower/Heavy Slam/Body Slam/Rest
    Primarina|58|Sparkling Aria/Moonblast/Ice Beam/Hydro Pump`, ['professor kukui']),
  T('Ash', 'Pokémon Journeys (Masters Eight)', 'ash', `
    Pikachu|70|Thunderbolt/Iron Tail/Quick Attack/Electro Ball|Light Ball
    Lucario|70|Aura Sphere/Bone Rush/Meteor Mash/Steel Wing
    Dragonite|70|Thunder Punch/Draco Meteor/Hurricane/Extreme Speed
    Gengar|70|Shadow Ball/Sludge Bomb/Hypnosis/Dream Eater
    Sirfetch'd|70|Meteor Assault/Leaf Blade/Brutal Swing/Detect
    Dracovish|70|Fishious Rend/Dragon Rush/Crunch/Psychic Fangs`, ['ash ketchum', 'satoshi']),
  T('Brock', 'FireRed & LeafGreen (Pewter Gym)', 'brock', `
    Geodude|12|Tackle/Defense Curl/Rock Throw
    Onix|14|Tackle/Bind/Rock Tomb/Harden`),
  T('Misty', 'FireRed & LeafGreen (Cerulean Gym)', 'misty', `
    Staryu|18|Tackle/Harden/Water Pulse/Rapid Spin
    Starmie|21|Swift/Water Pulse/Recover/Harden`),
  T('Lt. Surge', 'FireRed & LeafGreen (Vermilion Gym)', 'ltsurge', `
    Voltorb|21|Shock Wave/Screech/Sonic Boom/Self-Destruct
    Pikachu|18|Shock Wave/Thunder Wave/Quick Attack/Double Team
    Raichu|24|Shock Wave/Thunder Wave/Quick Attack/Double Team`, ['surge', 'lt surge', 'lieutenant surge']),
  T('Erika', 'FireRed & LeafGreen (Celadon Gym)', 'erika', `
    Victreebel|29|Giga Drain/Sleep Powder/Acid/Stun Spore
    Tangela|24|Giga Drain/Bind/Poison Powder/Ingrain
    Vileplume|29|Giga Drain/Acid/Stun Spore/Sleep Powder`),
  T('Sabrina', 'FireRed & LeafGreen (Saffron Gym)', 'sabrina', `
    Kadabra|38|Psybeam/Reflect/Future Sight/Calm Mind
    Mr. Mime|37|Barrier/Psybeam/Baton Pass/Calm Mind
    Venomoth|38|Psybeam/Gust/Leech Life/Supersonic
    Alakazam|43|Psychic/Recover/Future Sight/Calm Mind`),
  T('Blaine', 'FireRed & LeafGreen (Cinnabar Gym)', 'blaine', `
    Growlithe|42|Bite/Roar/Take Down/Fire Blast
    Ponyta|40|Stomp/Bounce/Fire Spin/Flame Wheel
    Rapidash|42|Stomp/Bounce/Fire Spin/Fire Blast
    Arcanine|47|Bite/Roar/Take Down/Fire Blast`),
  T('Giovanni', 'FireRed & LeafGreen (Viridian Gym)', 'giovanni', `
    Rhyhorn|45|Take Down/Rock Blast/Scary Face/Earthquake
    Dugtrio|42|Dig/Slash/Sand Tomb/Fissure
    Nidoqueen|44|Body Slam/Double Kick/Poison Sting/Earthquake
    Nidoking|45|Thrash/Double Kick/Poison Sting/Earthquake
    Rhyhorn|50|Take Down/Rock Blast/Scary Face/Earthquake`),
  T('Whitney', 'Gold & Silver (Goldenrod Gym)', 'whitney', `
    Clefairy|18|Double Slap/Mimic/Encore/Metronome
    Miltank|20|Rollout/Attract/Stomp/Milk Drink`),
  T('Morty', 'Gold & Silver (Ecruteak Gym)', 'morty', `
    Gastly|21|Lick/Spite/Mean Look/Curse
    Haunter|21|Hypnosis/Mimic/Curse/Night Shade
    Haunter|23|Spite/Mean Look/Mimic/Night Shade
    Gengar|25|Hypnosis/Shadow Ball/Mean Look/Dream Eater`),
  T('Clair', 'HeartGold & SoulSilver (Blackthorn Gym)', 'clair', `
    Dragonair|38|Thunder Wave/Dragon Pulse/Aqua Tail/Slam
    Dragonair|38|Thunder Wave/Dragon Pulse/Aqua Tail/Slam
    Dragonair|38|Thunder Wave/Dragon Pulse/Aqua Tail/Slam
    Kingdra|41|Dragon Pulse/Surf/Smokescreen/Hyper Beam`),
  T('Karen', 'HeartGold & SoulSilver (Elite Four)', 'karen', `
    Umbreon|42|Double Team/Confuse Ray/Feint Attack/Payback
    Vileplume|42|Stun Spore/Sludge Bomb/Moonlight/Petal Dance
    Gengar|45|Shadow Ball/Spite/Curse/Destiny Bond
    Murkrow|44|Quick Attack/Whirlwind/Pursuit/Sucker Punch
    Houndoom|47|Roar/Pursuit/Flamethrower/Crunch`),
  T('Bruno', 'HeartGold & SoulSilver (Elite Four)', 'bruno', `
    Hitmontop|42|Pursuit/Quick Attack/Triple Kick/Dig
    Hitmonlee|42|Swagger/Double Kick/High Jump Kick/Foresight
    Hitmonchan|42|Thunder Punch/Ice Punch/Fire Punch/Mach Punch
    Onix|43|Bind/Earthquake/Sandstorm/Rock Slide
    Machamp|46|Rock Slide/Foresight/Revenge/Cross Chop`),
  T('Lorelei', 'FireRed & LeafGreen (Elite Four)', 'lorelei', `
    Dewgong|52|Ice Beam/Surf/Signal Beam/Safeguard
    Cloyster|51|Spike Cannon/Protect/Dive/Hail
    Slowbro|52|Ice Beam/Surf/Amnesia/Yawn
    Jynx|54|Ice Punch/Lovely Kiss/Psychic/Double Team
    Lapras|54|Ice Beam/Surf/Body Slam/Confuse Ray`),
  T('Agatha', 'FireRed & LeafGreen (Elite Four)', 'agatha', `
    Gengar|54|Shadow Punch/Confuse Ray/Toxic/Double Team
    Golbat|54|Air Cutter/Confuse Ray/Poison Fang/Double Team
    Haunter|53|Hypnosis/Dream Eater/Curse/Mean Look
    Arbok|56|Iron Tail/Bite/Sludge Bomb/Glare
    Gengar|58|Shadow Ball/Sludge Bomb/Hypnosis/Nightmare`),
  T('Silver', 'HeartGold & SoulSilver (final rival battle)', 'silver', `
    Sneasel|46|Screech/Feint Attack/Metal Claw/Ice Punch
    Crobat|47|Leech Life/Poison Fang/Bite/Confuse Ray
    Magneton|46|Thunder/Tri Attack/Screech/Lock-On
    Gengar|48|Shadow Ball/Hypnosis/Dream Eater/Curse
    Alakazam|48|Psychic/Recover/Future Sight/Reflect
    Feraligatr|50|Waterfall/Ice Fang/Crunch/Slash|Sitrus Berry`, ['rival silver']),
  T('Wally', 'Emerald (Victory Road)', 'wally', `
    Altaria|44|Aerial Ace/Safeguard/Dragon Breath/Dragon Dance
    Delcatty|43|Sing/Assist/Charm/Feint Attack
    Roselia|44|Magical Leaf/Leech Seed/Giga Drain/Toxic
    Magneton|41|Thunderbolt/Supersonic/Thunder Wave/Sonic Boom
    Gardevoir|45|Double Team/Calm Mind/Psychic/Future Sight`),
  T('Archie', 'Emerald (Seafloor Cavern)', 'archie', `
    Mightyena|41|Roar/Crunch/Take Down/Scary Face
    Crobat|41|Wing Attack/Bite/Confuse Ray/Poison Fang
    Sharpedo|43|Crunch/Slash/Surf/Swagger`),
  T('Maxie', 'Emerald (Magma Hideout)', 'maxie', `
    Mightyena|37|Roar/Crunch/Take Down/Scary Face
    Crobat|38|Wing Attack/Bite/Confuse Ray/Poison Fang
    Camerupt|39|Earthquake/Flamethrower/Rock Slide/Take Down`),
  T('Drake', 'Ruby, Sapphire & Emerald (Elite Four)', 'drake', `
    Shelgon|52|Rock Tomb/Dragon Claw/Protect/Double-Edge
    Altaria|54|Double-Edge/Dragon Dance/Earthquake/Aerial Ace
    Kingdra|53|Smokescreen/Body Slam/Surf/Dragon Breath
    Flygon|53|Flamethrower/Crunch/Dragon Breath/Earthquake
    Salamence|55|Flamethrower/Dragon Claw/Rock Slide/Crunch|Sitrus Berry`),
  T('Phoebe', 'Ruby, Sapphire & Emerald (Elite Four)', 'phoebe', `
    Dusclops|48|Shadow Punch/Confuse Ray/Curse/Protect
    Banette|49|Shadow Ball/Grudge/Will-O-Wisp/Feint Attack
    Sableye|50|Shadow Ball/Psychic/Feint Attack/Night Shade
    Banette|49|Shadow Ball/Psychic/Thunderbolt/Feint Attack
    Dusclops|51|Shadow Ball/Ice Beam/Rock Slide/Earthquake|Sitrus Berry`),
  T('Volkner', 'Platinum (Sunyshore Gym)', 'volkner', `
    Jolteon|46|Charge Beam/Thunder Wave/Iron Tail/Quick Attack
    Raichu|46|Charge Beam/Brick Break/Signal Beam/Thunderbolt
    Luxray|49|Thunder Fang/Crunch/Fire Fang/Ice Fang
    Electivire|47|Thunder Punch/Fire Punch/Giga Impact/Quick Attack|Sitrus Berry`),
  T('Flint', 'Platinum (Elite Four)', 'flint', `
    Houndoom|52|Flamethrower/Thunder Fang/Sunny Day/Dark Pulse
    Flareon|55|Fire Fang/Overheat/Giga Impact/Quick Attack
    Rapidash|53|Flare Blitz/Solar Beam/Bounce/Sunny Day
    Infernape|55|Flare Blitz/Thunder Punch/Mach Punch/Earthquake
    Magmortar|57|Flamethrower/Thunderbolt/Solar Beam/Hyper Beam|Sitrus Berry`),
  T('Lucian', 'Platinum (Elite Four)', 'lucian', `
    Mr. Mime|53|Psychic/Thunderbolt/Reflect/Light Screen
    Espeon|55|Psychic/Shadow Ball/Signal Beam/Quick Attack
    Bronzong|54|Earthquake/Calm Mind/Gyro Ball/Psychic
    Alakazam|56|Psychic/Energy Ball/Focus Blast/Recover
    Gallade|59|Psycho Cut/Leaf Blade/Night Slash/Drain Punch|Sitrus Berry`),
  T('Cyrus', 'Platinum (Spear Pillar)', 'cyrus', `
    Houndoom|48|Flamethrower/Thunder Fang/Dark Pulse/Embargo
    Honchkrow|48|Night Slash/Sucker Punch/Drill Peck/Haze
    Crobat|50|Cross Poison/Air Slash/Bite/Confuse Ray
    Gyarados|48|Waterfall/Ice Fang/Earthquake/Giga Impact
    Weavile|51|Night Slash/Ice Punch/Fake Out/Ice Shard`),
  T('N', 'Black & White (Pokémon League)', 'n', `
    Zekrom|52|Fusion Bolt/Dragon Claw/Imprison/Crunch
    Carracosta|50|Aqua Jet/Ancient Power/Crunch/Protect
    Vanilluxe|50|Mirror Shot/Acid Armor/Ice Beam/Mirror Coat
    Archeops|50|Acrobatics/Dragon Claw/Ancient Power/Crunch
    Zoroark|50|Night Daze/Retaliate/Feint Attack/Hone Claws
    Klinklang|50|Gear Grind/Charge Beam/Mirror Shot/Thunder Wave`),
  T('Ghetsis', 'Black & White (Pokémon League)', 'ghetsis', `
    Cofagrigus|52|Psychic/Will-O-Wisp/Protect/Toxic Spikes
    Bouffalant|52|Head Charge/Revenge/Swords Dance/Facade
    Seismitoad|52|Muddy Water/Sludge Wave/Rain Dance/Earth Power
    Bisharp|52|Iron Head/Night Slash/Guillotine/Swords Dance
    Eelektross|52|Crunch/Thunder Wave/Flamethrower/Wild Charge
    Hydreigon|54|Dragon Pulse/Fire Blast/Focus Blast/Surf|Life Orb`),
  T('Elesa', 'Black & White (Nimbasa Gym)', 'elesa', `
    Emolga|25|Volt Switch/Quick Attack/Aerial Ace/Double Team
    Emolga|25|Volt Switch/Quick Attack/Aerial Ace/Double Team
    Zebstrika|27|Volt Switch/Quick Attack/Flame Charge/Pursuit|Sitrus Berry`),
  T('Grimsley', 'Black & White (Elite Four)', 'grimsley', `
    Scrafty|48|Crunch/High Jump Kick/Swagger/Sand Attack
    Liepard|48|Night Slash/Fake Out/Attract/Sucker Punch
    Krookodile|48|Earthquake/Crunch/Outrage/Torment
    Bisharp|50|Night Slash/Iron Head/X-Scissor/Retaliate|Sitrus Berry`),
  T('Lysandre', 'X & Y (Lysandre Labs)', 'lysandre', `
    Mienshao|68|High Jump Kick/U-turn/Stone Edge/Poison Jab
    Honchkrow|68|Sucker Punch/Night Slash/Brave Bird/Haze
    Pyroar|68|Flamethrower/Hyper Voice/Noble Roar/Take Down
    Gyarados|70|Waterfall/Crunch/Ice Fang/Dragon Dance|Gyaradosite`),
  T('Guzma', 'Sun & Moon (Aether Paradise)', 'guzma', `
    Ariados|46|Poison Jab/Shadow Sneak/Sucker Punch/Pin Missile
    Masquerain|46|Air Slash/Bug Buzz/Ice Beam/Quiver Dance
    Golisopod|47|First Impression/Liquidation/Razor Shell/Sucker Punch`),
  T('Lusamine', 'Sun & Moon (Ultra Space)', 'lusamine', `
    Clefable|63|Moonblast/Psychic/Metronome/Minimize
    Lilligant|63|Petal Blizzard/Teeter Dance/Sleep Powder/Quiver Dance
    Mismagius|63|Shadow Ball/Power Gem/Mystical Fire/Psychic
    Milotic|63|Hydro Pump/Ice Beam/Recover/Safeguard
    Bewear|63|Hammer Arm/Take Down/Payback/Baby-Doll Eyes`),
  T('Gladion', 'Sun & Moon (title defense)', 'gladion', `
    Crobat|58|Cross Poison/Air Slash/Bite/Confuse Ray
    Lucario|58|Aura Sphere/Dragon Pulse/Flash Cannon/Nasty Plot
    Zoroark|58|Night Daze/Flamethrower/Sludge Bomb/Psychic
    Silvally|60|Multi-Attack/Crunch/Air Slash/Iron Head`),
  T('Hop', 'Sword & Shield (Semifinals)', 'hop', `
    Dubwool|59|Cotton Guard/Double-Edge/Double Kick/Headbutt
    Corviknight|59|Steel Wing/Drill Peck/Scary Face/Iron Defense
    Pincurchin|59|Spark/Zing Zap/Acupressure/Peck
    Snorlax|59|Body Slam/Heavy Slam/Rest/Yawn
    Inteleon|60|Snipe Shot/U-turn/Liquidation/Breaking Swipe`),
  T('Raihan', 'Sword & Shield (Hammerlocke Gym)', 'raihan', `
    Gigalith|46|Rock Blast/Body Press/Stealth Rock/Sandstorm
    Flygon|47|Breaking Swipe/Earth Power/Dragon Claw/Sand Tomb
    Sandaconda|46|Sand Tomb/Drill Run/Glare/Brutal Swing
    Duraludon|48|Breaking Swipe/Flash Cannon/Dragon Pulse/Rock Slide|Sitrus Berry`),
  T('Marnie', 'Sword & Shield (Semifinals)', 'marnie', `
    Liepard|47|Fake Out/Torment/Sucker Punch/Play Rough
    Toxicroak|47|Poison Jab/Sucker Punch/Low Kick/Swagger
    Scrafty|47|Fake Out/Brick Break/Payback/Swagger
    Morpeko|48|Aura Wheel/Bite/Torment/Quick Attack
    Grimmsnarl|49|Spirit Break/False Surrender/Bulk Up/Light Screen|Sitrus Berry`),
  T('Volo', 'Legends: Arceus (Temple of Sinnoh)', 'volo', `
    Spiritomb|68|Dark Pulse/Shadow Ball/Hypnosis/Calm Mind
    Roserade|68|Energy Ball/Sludge Bomb/Petal Blizzard/Poison Jab
    Togekiss|68|Moonblast/Air Slash/Extrasensory/Aura Sphere
    Lucario|68|Aura Sphere/Close Combat/Psychic/Bulk Up
    Arcanine-Hisui|68|Flare Blitz/Head Smash/Wild Charge/Extreme Speed
    Garchomp|70|Dragon Claw/Earthquake/Stone Edge/Swords Dance`),
];

const key = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
/** The famous battler this name is, or null (exact name or a known alias, any case or punctuation). */
export function findFamousTrainer(text) {
  const k = key(text);
  if (!k) return null;
  return FAMOUS_TRAINERS.find((t) => key(t.name) === k || t.aliases.some((a) => key(a) === k)) ?? null;
}

/**
 * Their team as Showdown sets. matchLevel: a level to bring their strongest to (the others keep their gaps
 * below it), or null for the levels from their game. knows(kind, name): what Showdown can use.
 */
export function famousTeam(t, { matchLevel = null, knows = () => true } = {}) {
  const top = Math.max(...t.team.map((m) => m.level));
  return t.team.filter((m) => knows('species', m.species)).map((m, i) => {
    const level = matchLevel ? Math.max(1, Math.min(100, Math.round(matchLevel - (top - m.level)))) : m.level;
    const moves = m.moves.filter((mv) => knows('move', mv));
    return {
      name: `${m.species.replace(/-.*/, '')}${t.team.filter((x, j) => j < i && x.species === m.species).length ? ` ${i + 1}` : ''}`,
      species: m.species, level, moves: moves.length ? moves : ['Tackle'], item: m.item && knows('item', m.item) ? m.item : '', ability: '', gender: '',
      evs: { hp: 84, atk: 84, def: 84, spa: 84, spd: 84, spe: 84 }, ivs: { hp: 31, atk: 31, def: 31, spa: 31, spd: 31, spe: 31 }, nature: '',
    };
  });
}
