// "Who wants to …?" — asking the group, and the ones who'd like to step forward.
// "Who wants to go scavenging?", "Anyone up for a movie?", "Who wants to sit on the desktop while I work?" — each
// matches something the game can really do; the ones who want to (good at it, awake, with the energy, in the mood,
// who like it) volunteer, the rest say why not.
//
//   inviteOf(text)                       → { id, label, act?, verb } or null
//   volunteers(idx, save, uids, inv)      → { yes: [{ uid, why, score }], no: [{ uid, why }] } (best first)
import { aptitude, canDo, typeWords } from './activities.js';
import { isAsleep, tickNeeds } from './care.js';
import { displayName } from './creature.js';
export { noteDid } from './desires.js';

// what can be asked for, and the words that ask for it
export const INVITES = [
  // the more particular asks first: the first one whose words match is the one meant.
  // like: done the same way as that one; seq: a little routine done right there in the yard; en: 'active' (needs
  // energy) or 'calm' (a good one for the tired); types: kinds of creature that especially take to it
  { id: 'berries', act: 'gardening', label: 'pick some berries', verb: 'Pick berries', re: /pick(ing)? (some )?(berr|fruit|apple)|berry pick|harvest/ },
  { id: 'scavenging', act: 'scavenging', label: 'go scavenging', verb: 'Go scavenging', re: /scaveng|treasure|dig(ging)?\b|forag|hunt for|search for|metal detect/ },
  { id: 'cooking', act: 'cooking', label: 'cook something', verb: 'Cook', re: /cook|bake|kitchen|make (some )?(food|dinner|lunch|a dish|poffins?|poké ?puffs?|curry|cake|cookies)/ },
  { id: 'fishing', act: 'fishing', label: 'go fishing', verb: 'Go fishing', re: /fish/ },
  { id: 'gardening', act: 'gardening', label: 'do some gardening', verb: 'Garden', re: /garden|weed|plant|farm|berr(y|ies) patch|water the (flowers|plants)/ },
  { id: 'obstacle', act: 'obstacle', label: 'run the obstacle course', verb: 'Run the course', re: /obstacle|hurdle|agility|course|run (a|some) lap/ },
  // things that aren't activities of their own, done right there in the yard
  { id: 'race', label: 'race', verb: 'Race', re: /\brace\b|first (one )?to (the|that|reach)|fastest|beat (me|everyone|each other) to/ },
  { id: 'dreamhelp', label: 'help the others rest', verb: 'Help them rest', re: /help (the )?others? (sleep|rest|recover|get (their )?energy)|share (its |their )?dreams?|sleep (with|beside|next to) (the )?others|dream ?eat|lull/ },
  { id: 'puzzle', act: 'puzzle', label: 'do some puzzles', verb: 'Do puzzles', re: /puzzle|brain ?teaser|match(ing)? (game|tiles)|riddle|jigsaw/ },
  { id: 'strong', act: 'training', label: 'train to get stronger', verb: 'Train', re: /evolv|evolution|level up|get stronger|grow stronger|power up/ },
  { id: 'tug', label: 'play tug-of-war', verb: 'Tug!', seq: 'pair', en: 'active', re: /tug(-| )?(of(-| )?)?war|wrestl|play ?fight|rough ?hous|pillow fight/ },
  { id: 'training', act: 'training', label: 'train', verb: 'Train', re: /train|practi[cs]e|drill|work ?out|exercise|spar|moves? (practice|lesson)/ },
  { id: 'contest', label: 'put on a contest show', verb: 'Show time!', seq: 'show', en: 'active', re: /contest|appeal|show ?off|tricks?\b|perform|talent show|strut|ribbon|showcase|light show|fireworks|show (me )?(your )?moves/ },
  { id: 'photography', act: 'photography', label: 'pose for photos', verb: 'Take photos', re: /photo|picture|pic\b|camera|pose|selfie/ },
  { id: 'movie', label: 'watch a movie', verb: 'Watch together', re: /movie|film|cinema|watch (something|a show|tv|telly|cartoons|anime)|show night/ },
  { id: 'desktop', label: 'sit on the desktop with you', verb: 'Come out on the desktop', re: /desk ?top|on (my|the) desk|while i (work|study|game|play)|keep me company|on (my|the) screen|sit with me/ },
  { id: 'battle', label: 'battle', verb: 'Battle', re: /battle|fight|duel|take on/ },
  { id: 'swim', label: 'go for a swim', verb: 'Swim', seq: 'swim', en: 'active', types: /water|ice/i, re: /swim|splash|paddl|pond|dip\b|water ?(play|fight|balloon)|surf|dive|sprinkler/ },
  { id: 'groom', label: 'have a bath and a brush', verb: 'Quality time', re: /bath|brush|groom|wash|clean (yourself |you )?up|pamper|spa\b|comb|shampoo|nails|fluff/ },
  { id: 'tidy', label: 'help tidy up the ranch', verb: 'Tidy up', seq: 'roam:✨', en: 'active', re: /tidy|clean (up )?(the )?(ranch|yard|place|house|room)|sweep|litter|rubbish|trash|chores|help (out|me) around/ },
  { id: 'hug', label: 'have a cuddle', verb: 'Cuddle', seq: 'cuddle', en: 'calm', re: /hug|cuddl|snuggl|hold (me|you)|lap\b|sit on my lap/ },
  { id: 'pets', label: 'get some pets', verb: 'Pets!', seq: 'cuddle', en: 'calm', re: /\bpet(s|ted|ting)?\b|scratch|belly rubs?|head ?pats?|chin rubs?|tummy rubs?|massage|ear rubs?/ },
  { id: 'cheer', label: 'cheer you up', verb: 'Cheer me up', seq: 'cheer', re: /cheer (me|for)|cheer( me)? up|make me (smile|laugh|happy)|comfort me|i'?m (sad|down|lonely|upset)|bad day/ },
  { id: 'relax', label: 'relax together', verb: 'Relax', seq: 'think:🍃', en: 'calm', re: /relax|chill( out)?|calm down|unwind|meditat|breathe|zen|lazy day|lounge|veg out/ },
  { id: 'sunbathe', label: 'sunbathe', verb: 'Bask', seq: 'think:☀️', en: 'calm', types: /fire|grass|bug|normal/i, re: /sun ?bath|bask|sunny spot|in the sun|soak up|tan\b|warm up/ },
  { id: 'stargaze', label: 'look at the stars', verb: 'Stargaze', seq: 'think:⭐', en: 'calm', types: /psychic|fairy|dark|ghost/i, re: /star ?gaz|stars|the (sky|moon|sunset|sunrise|clouds)|cloud ?watch|shooting star|night sky|meteor/ },
  { id: 'campfire', label: 'sit round a campfire', verb: 'Campfire', seq: 'think:🔥', en: 'calm', types: /fire/i, re: /camp ?fire|bonfire|marshmallow|camp(ing)?( out)?\b|s'?mores?|ghost stor/ },
  { id: 'story', label: 'hear a story', verb: 'Story time', seq: 'think:📖', en: 'calm', types: /psychic|normal|fairy/i, re: /story|stories|read (a |some |together|to)|book|fairy ?tale|bedtime/ },
  { id: 'paint', label: 'draw and paint', verb: 'Art time', seq: 'think:🎨', en: 'calm', types: /normal|psychic|fairy/i, re: /draw|paint|doodl|colou?r(ing)?\b|\bart\b|craft|sketch|finger ?paint/ },
  { id: 'build', label: 'build something', verb: 'Build', seq: 'think:🏰', types: /rock|ground|steel/i, re: /sand ?(castle|pit|box)|build (something|a|me)|blocks?\b|lego|fort\b|den\b/ },
  { id: 'nap', label: 'take a nap', verb: 'Nap', re: /nap|sleep|rest\b|lie down|snooze|siesta|bed ?time|forty winks/ },
  { id: 'hideseek', label: 'play hide-and-seek', verb: 'Hide and seek', seq: 'hide', en: 'active', types: /ghost|dark|bug|grass/i, re: /hide ?(and|&|n|'n'|-and-) ?(go )?seek|hiding|hide\b|peek ?-?a ?-?boo|find me/ },
  { id: 'tag', label: 'play tag', verb: 'Tag!', seq: 'chase', en: 'active', types: /electric|flying|fighting/i, re: /\btag\b|you'?re it|chase|catch me|zoomies|run around|jog|go (for a )?run|running|sprint/ },
  { id: 'fetch', label: 'play fetch', verb: 'Fetch!', seq: 'fetch', en: 'active', re: /fetch|frisbee|throw (the |a |me )?(ball|stick|disc)|stick/ },
  { id: 'ball', label: 'play ball', verb: 'Play ball', seq: 'ball', en: 'active', re: /\bball\b|catch\b|kick ?about|soccer|football|volley|basketball|bounce/ },
  { id: 'snow', label: 'play in the snow', verb: 'Snow day!', seq: 'hop', en: 'active', types: /ice|water/i, re: /snow|sled|ice skat|skat(e|ing)|ice slide/ },
  { id: 'puddles', label: 'jump in puddles and leaves', verb: 'Jump in!', seq: 'hop', en: 'active', types: /water|grass|ground/i, re: /puddle|leaf pile|leaves|mud\b|mud ?bath|roll in/ },
  { id: 'bubbles', label: 'chase bubbles', verb: 'Bubbles!', seq: 'hop', types: /water|fairy/i, re: /bubbles?\b/ },
  { id: 'fly', label: 'fly about', verb: 'Fly!', seq: 'show', en: 'active', types: /flying|dragon|psychic|ghost/i, re: /\bfly|soar|glide|loop the loop|aerial|sky ?dance/ },
  { id: 'climb', label: 'climb trees', verb: 'Climb', seq: 'climb', en: 'active', types: /bug|grass|fighting|normal/i, re: /climb|up a tree|tree ?house|scale/ },
  { id: 'patrol', label: 'keep watch over the ranch', verb: 'On patrol', seq: 'patrol', types: /steel|fighting|dark|electric|dragon/i, re: /patrol|guard|keep watch|look ?out|on watch|sentry|keep (us|everyone) safe|night watch/ },
  { id: 'bugs', label: 'go looking for bugs and birds', verb: 'Bug hunt', seq: 'roam:🦋', types: /bug|flying|grass/i, re: /butterfl|bugs?\b|bug ?catch|ladybird|ladybug|bird ?watch|watch the birds|nature hunt/ },
  { id: 'explore', label: 'explore the ranch', verb: 'Explore', seq: 'roam:❓', en: 'active', re: /explore (the |this )?(ranch|yard|garden|place|around)|look around|sniff around|nose about|wander/ },
  { id: 'friends', label: 'make friends', verb: 'Make friends', seq: 'pair', re: /make friends|meet (the |some )?(others|friends|new)|hang ?out|sociali[sz]|say hi to|visit (a |your )?friends?|play ?date|play together|get along/ },
  { id: 'lineup', label: 'come and gather round', verb: 'Gather round', seq: 'cheer', re: /line up|roll call|gather (round|around)|huddle|come here everyone|everyone over here|group (hug|photo)|team meeting/ },
  { id: 'follow', label: 'play follow the leader', verb: 'Follow me!', seq: 'follow', re: /follow (me|the leader)|simon says|copy me|do as i do|mirror me/ },
  { id: 'greet', label: 'say hello', verb: 'Say hi', seq: 'hop', re: /say (hi|hello|good ?morning|good ?night|bye)|wave\b|greet|welcome/ },
  { id: 'stretch', label: 'do some stretches', verb: 'Stretch', seq: 'stretch', re: /stretch|yoga|warm(ing)?[ -]?up|limber|pilates|tai chi/ },
  { id: 'picnic', label: 'have a picnic', verb: 'Picnic', like: 'snack', re: /picnic|tea ?party|tea ?time|eat together|share (a|some) (meal|lunch|berries|snacks)|brunch|feast/ },
  { id: 'walk', label: 'come on a walk', verb: 'Come on a walk', re: /walk|stroll|outside|adventure|come with me|on my phone|explore|hike|trip/ },
  { id: 'snack', label: 'have a snack', verb: 'Snack time', re: /snack|eat|food|treat|berr|lunch|dinner|hungry|breakfast|dessert|sweets|candy/ },
  { id: 'sing', label: 'sing together', verb: 'Sing!', seq: 'song', types: /fairy|normal|flying|psychic/i, re: /sing|song|karaoke|hum\b|chorus|lullab|duet/ },
  { id: 'music', label: 'play some music', verb: 'Music!', seq: 'song', re: /play (some )?music|instrument|drum|band\b|jam|concert|guitar|piano|flute|listen to (some )?music/ },
  { id: 'play', label: 'play', verb: 'Play', re: /play|game|toy|fun\b|bored/ },
  { id: 'dance', label: 'dance', verb: 'Dance', re: /danc|music|party|boogie|groove|disco|rave/ },
];
const ASK = /\b(who('?s| is)? (wants?|would like|wanna|fancies|is up for|up for|keen)|who('?d| would) (like|want|love)|anyone (want|wanna|up for|fancy|like)|any ?body (want|wanna|up for)|does anyone|who else wants|who is coming|who'?s coming|who('?ll| will) (come|join))\b/i;

/** What a "who wants to …?" asks for, or null when it isn't one. */
export function inviteOf(text) {
  const s = String(text ?? '').toLowerCase();
  if (!ASK.test(s)) return null;
  const rest = s.replace(ASK, ' ');
  for (const inv of INVITES) if (inv.re.test(rest)) return inv;
  return { id: 'any', label: 'join in', verb: 'Join in', re: null };
}

const energyOf = (c) => c.needs?.energy ?? 60, joyOf = (c) => c.needs?.joy ?? c.needs?.happiness ?? 60;
// ---------- what they feel like ----------
// Wanting to do something isn't the same as being good at it. Each creature has its own long-standing tastes
// (born with them, drifting slowly with what it does and enjoys), and on top of that how it feels about things
// today and this hour, a little boredom with what it's done a lot lately, and how it is right now (tired, hungry,
// sulking). Being made for something only nudges the taste a little.
const hash = (s) => { let x = 2166136261; for (let i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); } return ((x >>> 0) % 10007) / 10007; };
/** Its long-standing taste for something: -1 (can't stand it) … 1 (loves it). */
export function tasteFor(idx, c, key) {
  const born = (hash(`${c.uid}|${key}|taste`) - 0.5) * 1.3;
  const grown = c.likesLong?.[key] ?? 0;
  let made = 0; if (INVITE_BY_ID[key]?.act) { try { made = (aptitude(idx, c, INVITE_BY_ID[key].act).score - 0.5) * 0.25; } catch { /* fine */ } }
  return Math.max(-1, Math.min(1, born + grown + made));
}
/** How it feels about it today (-0.5 … 0.5) and this hour (-0.25 … 0.25). */
export function whimFor(c, key, t = Date.now()) {
  const day = Math.floor(t / 86400000), hour = Math.floor(t / 3600000);
  return { day: hash(`${c.uid}|${key}|d${day}`) - 0.5, hour: (hash(`${c.uid}|${key}|h${hour}`) - 0.5) * 0.5 };
}
const boredOf = (c, key, t) => (c.recentDid?.[key] ?? []).reduce((b, x) => b + (t - x < 86400000 ? 0.09 : t - x < 3 * 86400000 ? 0.04 : 0), 0);
const INVITE_BY_ID = Object.fromEntries(INVITES.map((i) => [i.id, i]));

/** Who'd like to, best first, and the others with why not. score: how much they want to (0 … about 1). */
export function volunteers(idx, save, uids, inv, t = Date.now()) {
  const yes = [], no = [];
  for (const uid of uids) {
    const c = save.creatures[uid];
    if (!c || c.egg) continue;
    try { tickNeeds(idx, c, t); } catch { /* fine */ }
    const name = displayName(idx, c);
    const asleep = isAsleep(c, t), key = inv.id, kind = inv.like ?? inv.id;
    if (asleep && kind !== 'nap') { no.push({ uid, score: 0, why: `${name} is fast asleep.` }); continue; }
    if ((c.upsetUntil ?? 0) > t) { no.push({ uid, score: 0.05, why: `${name} is still upset with you.` }); continue; }
    if (inv.act) { const ok = canDo(idx, save, c, inv.act); if (!ok.ok) { no.push({ uid, score: 0.04, why: ok.reason }); continue; } }
    // what it feels like
    const L = tasteFor(idx, c, key), W = whimFor(c, key, t), bored = boredOf(c, key, t) * (L > 0.4 ? 0.5 : 1);
    let score = 0.48 + 0.34 * L + 0.3 * W.day * (1 - Math.abs(L) * 0.4) + 0.14 * W.hour - bored + Math.min(0.06, (c.friendship ?? 0) / 4000);
    // and how it is right now
    const tw = () => { try { return typeWords(idx, c).join(' '); } catch { return ''; } };
    const en = energyOf(c), joy = joyOf(c), full = c.needs?.fullness ?? c.needs?.hunger ?? 60;
    let block = null;
    if (kind === 'nap') { score += (50 - en) / 100 + (asleep ? 0.4 : 0); if (en > 80 && !asleep) block = `${name} is wide awake.`; }
    else if (kind === 'snack') { score += (55 - full) / 100; if (full > 92) block = `${name} is too full.`; }
    else if (kind === 'movie' || kind === 'desktop' || inv.en === 'calm') score += (55 - en) / 300;
    else if (key === 'dreamhelp') { score += (55 - en) / 250 + (/psychic|dream|fairy|normal/i.test(tw()) ? 0.12 : 0); }
    else if (inv.en === 'active' || ['battle', 'walk', 'play', 'dance', 'obstacle', 'training', 'scavenging', 'race'].includes(kind)) { score += (en - 50) / 300; if (en < 22) block = `${name} is too tired.`; }
    else if (key === 'groom') score += (60 - (c.needs?.clean ?? c.needs?.hygiene ?? 60)) / 250;
    if (inv.types && inv.types.test(tw())) score += 0.1;
    if (/sulk|sad|grump/.test(c.mood ?? '')) score -= 0.12;
    score += (joy - 60) / 600;
    if (block) { no.push({ uid, score: Math.max(0, Math.min(0.3, score)), why: block }); continue; }
    // why, in a few words: its taste first, then today's mood, then (only a nudge) being made for it
    let ap = null; if (inv.act) { try { ap = aptitude(idx, c, inv.act); } catch { /* fine */ } }
    const why = L > 0.45 ? 'loves this' : W.day > 0.3 ? 'in the mood for it today' : bored > 0.15 ? 'did a lot of it lately, but still keen' : L > 0.15 ? 'likes this' : ap?.score > 0.75 && ap.perks[0] ? ap.perks[0] : W.hour > 0.1 ? 'feels like it right now' : 'happy to come along';
    if (score < 0.38) { no.push({ uid, score: Math.max(0, score), why: L < -0.35 ? `${name} has never liked this much.` : W.day < -0.25 ? `${name} isn’t feeling it today.` : bored > 0.15 ? `${name} has had enough of it lately.` : `${name} doesn’t fancy it right now.` }); continue; }
    yes.push({ uid, why, score: Math.min(1.1, score) });
  }
  yes.sort((a, b) => b.score - a.score);
  return { yes, no };
}

/** Requests that don't need a “who wants to…?”: “Cogsy and Mindle, race to the tree!”, “Munna, help the others sleep”. */
export function directInvite(text) {
  const s = String(text ?? '').toLowerCase();
  for (const id of ['race', 'dreamhelp']) { const inv = INVITES.find((i) => i.id === id); if (inv?.re.test(s)) return inv; }
  return null;
}
