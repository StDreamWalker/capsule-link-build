// Short-term boredom and slowly growing tastes (see invite.js for how they're used).
/** It did this: a little boredom for a while, and if it went well and it enjoyed it, a slightly bigger liking in the long run. */
export function noteDid(c, key, { t = Date.now(), joy = 0.5 } = {}) {
  c.recentDid = { ...(c.recentDid ?? {}) };
  c.recentDid[key] = [...(c.recentDid[key] ?? []).filter((x) => t - x < 3 * 86400000), t].slice(-8);
  c.likesLong = { ...(c.likesLong ?? {}) };
  c.likesLong[key] = Math.max(-0.5, Math.min(0.5, (c.likesLong[key] ?? 0) + (joy - 0.45) * 0.03));
}
