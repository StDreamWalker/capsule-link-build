// Short-term and long-term memory.
//
// Through the day a creature keeps a short-term memory (c.today.notes): what you talked about, the
// berry they asked for, who they played with, what upset them. It travels with them wherever they go
// (the R.A.N.C.H., the desktop, the phone, a ball), because it lives on the creature itself.
//
// While they sleep at night (or, failing that, when the real day ends) the day is "slept on": most of
// it fades, and what mattered becomes long-term — a nudge to their preferences, a friendship that grew,
// a line in the journal, now and then a core memory. That's how a craving lasts a day while a favourite
// food lasts for good: crave the same thing day after day and it turns into a real liking.
//
//   remember(c, kind, key, w, t)        a note for today (kind: chat, craving, ate, played, met, upset, care)
//   cravingOf(idx, c, t)                today's craving (a food id) or null — the same on every device
//   setCraving(c, foodId, t, from)      they asked for something (in a chat): that's today's craving
//   satisfyCraving(c, foodId, t)        → true when this was what they were craving (once a day)
//   sleepOnIt(idx, save, c, t)          settle the day if it's time (tickAll calls this)
//   recall(idx, save, c, t)             something from today or yesterday they still have in mind
import { todayKey, displayName, addMemory } from './creature.js';
import { journal } from './memory.js';
import { allFoods } from './shop.js';

const hash = (s) => { let h = 2166136261; for (const ch of String(s)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0; return h; };
const DAY = 86400000;
const MAX_NOTES = 80;
const isNight = (t) => { const h = new Date(t).getHours(); return h >= 21 || h < 5; };
const startOfDay = (t) => { const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); };

function state(c) {
  const s = (c.today = c.today && typeof c.today === 'object' ? c.today : {});
  s.notes = Array.isArray(s.notes) ? s.notes : [];
  return s;
}

/** A note for today. kind: 'chat' | 'craving' | 'ate' | 'played' | 'met' | 'upset' | 'care'; w: how much it mattered. */
export function remember(c, kind, key, w = 1, t = Date.now(), extra = {}) {
  if (!c) return;
  const s = state(c);
  s.notes.push({ t, kind, key: String(key ?? ''), w, ...extra });
  if (s.notes.length > MAX_NOTES) {
    // keep the weightier ones
    s.notes.sort((a, b) => b.w - a.w || b.t - a.t);
    s.notes.length = MAX_NOTES;
    s.notes.sort((a, b) => a.t - b.t);
  }
}

/** Today's craving: a food id, or null. Decided from the creature and the date alone, so every device agrees. */
export function cravingOf(idx, c, t = Date.now()) {
  if (!c || c.egg) return null;
  const s = state(c), day = todayKey(t);
  if (s.craving?.day === day) return s.craving.id ?? null;
  if (s.rolled === day) return null;
  s.rolled = day;
  const r = hash(`${c.uid}:crave:${day}`);
  if (r % 100 >= 35) { s.craving = { day, id: null }; return null; } // most days, no craving
  const liked = Object.entries(c.prefs ?? {}).filter(([k, v]) => k.startsWith('food:') && v >= 1).map(([k]) => k.slice(5));
  const foods = allFoods(idx).filter((f) => f.kind === 'food' && !f.unlimited);
  let id = null;
  if (liked.length && (r >>> 8) % 10 < 6) id = liked[(r >>> 12) % liked.length];
  else if (foods.length) id = foods[(r >>> 12) % foods.length].id;
  s.craving = { day, id, from: 'mood', t };
  return id;
}
/** They asked for something (in a chat): it's on their mind for the rest of the day. */
export function setCraving(c, id, t = Date.now(), from = 'chat') {
  if (!c || !id) return;
  const s = state(c), day = todayKey(t);
  if (s.craving?.day === day && s.craving.id === id) return;
  s.craving = { day, id, from, t };
  s.rolled = day;
  remember(c, 'craving', id, 2, t);
}
/** Fed something: was it today's craving? (Only counts once.) */
export function satisfyCraving(idx, c, id, t = Date.now()) {
  const want = cravingOf(idx, c, t);
  const s = state(c);
  if (!want || want !== id || s.craving.satisfied) return false;
  s.craving.satisfied = t;
  remember(c, 'ate', id, 3, t, { craved: true });
  return true;
}

/** Settle the day if it's time: during a night's sleep, or once the real day has ended. Returns lines it wrote, or null. */
export function sleepOnIt(idx, save, c, t = Date.now()) {
  if (!c || c.egg) return null;
  const s = state(c);
  const asleep = c.sleep && (c.sleep.until ?? 0) > t;
  const today0 = startOfDay(t);
  // asleep at night: settle everything so far; otherwise, at the end of the day, settle what's left from before today
  const cutoff = asleep && isNight(t) && (s.settledAt ?? 0) < t - 6 * 3600000 ? t : today0;
  const old = s.notes.filter((n) => n.t < cutoff);
  if (!old.length) { if (cutoff === t) s.settledAt = t; return null; }
  s.notes = s.notes.filter((n) => n.t >= cutoff);
  if (cutoff === t) s.settledAt = t;
  return settle(idx, save, c, old, t);
}

function settle(idx, save, c, notes, t) {
  const name = displayName(idx, c);
  const lines = [];
  const by = (kind) => notes.filter((n) => n.kind === kind);
  const itemName = (id) => idx.items?.get?.(id)?.name ?? allFoods(idx).find((f) => f.id === id)?.name ?? String(id).replace(/-/g, ' ');
  const day = todayKey(notes[0].t);
  const p = (c.prefs = c.prefs || {});
  const nudge = (k, v) => { p[k] = Math.max(-10, Math.min(10, (p[k] ?? 0) + v)); };

  // cravings: one day is a whim; the same thing on several different days becomes a real liking
  const craved = [...new Set(by('craving').map((n) => n.key))];
  const ateCraved = new Set(by('ate').filter((n) => n.craved).map((n) => n.key));
  const hist = (c.cravedDays = c.cravedDays || {});
  for (const id of craved) {
    const days = (hist[id] = [...new Set([...(hist[id] ?? []), day])].filter((d) => t - new Date(d).getTime() < 14 * DAY));
    nudge(`food:${id}`, ateCraved.has(id) ? 0.6 : 0.2);
    if (days.length >= 3 && (p[`food:${id}`] ?? 0) < 5) {
      nudge(`food:${id}`, 3);
      addMemory(c, `Kept craving ${itemName(id)} day after day. It's one of their favourite foods now.`, t, { keys: [`food:${id}`] });
      lines.push(`${name} has decided they really love ${itemName(id)}.`);
      delete hist[id];
    } else if (ateCraved.has(id)) lines.push(`Finally got the ${itemName(id)} they'd been craving.`);
  }
  for (const k of Object.keys(hist)) if (!hist[k].length) delete hist[k];

  // friends: time spent together today counts for a little extra
  const played = by('played');
  const seen = new Map();
  for (const n of played) seen.set(n.key, (seen.get(n.key) ?? 0) + n.w);
  for (const [uid, w] of seen) {
    const other = save?.creatures?.[uid];
    if (!other) continue;
    const add = Math.min(3, w * 0.5);
    (c.bonds = c.bonds || {})[uid] = Math.min(100, (c.bonds[uid] ?? 0) + add);
    (c.lastSaw = c.lastSaw || {})[uid] = t;
  }
  const best = [...seen.entries()].sort((a, b) => b[1] - a[1])[0];
  if (best && save?.creatures?.[best[0]] && best[1] >= 3) lines.push(`Spent a lot of the day with ${displayName(idx, save.creatures[best[0]])}.`);
  // visitors from other ranches
  for (const n of by('met')) {
    const g = c.guestBonds?.[n.key];
    if (g) g.bond = Math.min(100, (g.bond ?? 0) + Math.min(3, n.w * 0.5));
  }

  // what you talked about: things they like to hear about grow on them
  const talk = new Map();
  for (const n of by('chat')) talk.set(n.key, (talk.get(n.key) ?? 0) + n.w);
  const TALK_PREF = { walk: 'activity:walk', play: 'activity:play', bath: 'activity:bath', sleep: 'activity:nap', car: 'activity:car' };
  for (const [k, w] of talk) if (TALK_PREF[k]) nudge(TALK_PREF[k], Math.min(0.6, w * 0.15));
  const topTalk = [...talk.entries()].filter(([k]) => !k.startsWith('food:') && !k.startsWith('i:') && k !== 'name').sort((a, b) => b[1] - a[1]).slice(0, 2).map(([k]) => k);
  if (topTalk.length && [...talk.values()].reduce((a, b) => a + b, 0) >= 4) lines.push(`Talked with you a lot about ${topTalk.join(' and ')}.`);

  // a bad day sticks a little
  const upsets = by('upset');
  if (upsets.length >= 2) lines.push(`Had a rough day: ${upsets.at(-1).key}.`);

  for (const l of lines) journal(c, l, t);
  c.yesterday = { day, lines, craving: craved[0] ?? null, talked: topTalk, friend: best?.[0] ?? null };
  return lines;
}

/** Something from today or yesterday that's still on their mind: { text, kind, key } or null. */
export function recall(idx, save, c, t = Date.now()) {
  const s = state(c);
  const itemName = (id) => idx.items?.get?.(id)?.name ?? String(id).replace(/-/g, ' ');
  const want = cravingOf(idx, c, t);
  const recent = [...s.notes].reverse();
  const crav = recent.find((n) => n.kind === 'craving');
  if (crav && want === crav.key && !s.craving?.satisfied) return { kind: 'craving', key: want, text: `is still thinking about that ${itemName(want)}` };
  const played = recent.find((n) => n.kind === 'played' && save?.creatures?.[n.key]);
  if (played) return { kind: 'played', key: played.key, text: `remembers playing with ${displayName(idx, save.creatures[played.key])}` };
  const up = recent.find((n) => n.kind === 'upset');
  if (up) return { kind: 'upset', key: up.key, text: `hasn't forgotten ${up.key}` };
  if (c.yesterday?.lines?.length) return { kind: 'yesterday', key: '', text: `remembers yesterday: ${c.yesterday.lines[0].replace(/^[A-Z]/, (m) => m.toLowerCase()).replace(/\.$/, '')}` };
  return null;
}

/** Today at a glance for the journal: { craving, notes: [text] }. */
export function todayOf(idx, save, c, t = Date.now()) {
  const want = cravingOf(idx, c, t);
  const s = state(c);
  const itemName = (id) => idx.items?.get?.(id)?.name ?? allFoods(idx).find((f) => f.id === id)?.name ?? String(id).replace(/-/g, ' ');
  const out = [];
  const talked = [...new Set(s.notes.filter((n) => n.kind === 'chat' && !n.key.startsWith('food:') && !n.key.startsWith('i:') && n.key !== 'name').map((n) => n.key))];
  if (talked.length) out.push(`Talked about ${talked.slice(0, 3).join(', ')}.`);
  const pals = [...new Set(s.notes.filter((n) => n.kind === 'played').map((n) => n.key))].map((u) => save?.creatures?.[u]).filter(Boolean).map((x) => displayName(idx, x));
  if (pals.length) out.push(`Played with ${pals.slice(0, 3).join(', ')}.`);
  const guests = [...new Set(s.notes.filter((n) => n.kind === 'met').map((n) => c.guestBonds?.[n.key]?.name).filter(Boolean))];
  if (guests.length) out.push(`Met ${guests.slice(0, 3).join(', ')} from another ranch.`);
  return { craving: want ? itemName(want) : null, satisfied: !!s.craving?.satisfied, notes: out };
}

/** A creature visiting from another trainer's ranch: remembered, and a bond that grows over visits. */
export function meetGuest(c, g, trainer, w = 1, t = Date.now()) {
  if (!c || !g) return { first: false };
  const key = `${trainer?.code ?? trainer?.name ?? 'friend'}:${g.uid}`;
  const gb = (c.guestBonds = c.guestBonds || {});
  const first = !gb[key];
  const e = (gb[key] = gb[key] || { name: g.name, species: g.speciesId, trainer: trainer?.name ?? 'a friend', bond: 0, visits: 0, first: t });
  e.name = g.name; e.trainer = trainer?.name ?? e.trainer;
  if (!e.last || t - e.last > 2 * 3600000) e.visits++;
  e.last = t;
  e.bond = Math.min(100, e.bond + w);
  remember(c, 'met', key, w, t);
  // keep the closest few dozen
  const keys = Object.keys(gb);
  if (keys.length > 40) { keys.sort((a, b) => gb[a].bond - gb[b].bond); for (const k of keys.slice(0, keys.length - 40)) delete gb[k]; }
  return { first, key, entry: e, friends: e.bond >= 60 };
}
