// Food: what each berry and dish does, berry flavours, and cooking recipes.
//   foodEffects(item)  { fullness, joy, energy, friendship, calm } — a berry's own fields first, then what its
//                      name says (Leppa and Sitrus bring energy back, Persim and Lum calm an upset creature,
//                      Pomeg, Kelpsy, Qualot, Hondew, Grepa and Tamato make them friendlier, like in the games)
//   RECIPES            things to cook, each needing certain berries (by name or by flavour)
//   recipeStatus()     can you make it with what's in the bag, and with which berries
// Kibble never runs out but only fills them a little, and too much of it (unless they love it) gets old.

/** Berry flavours, as in the games (spicy, dry, sweet, bitter, sour). */
const FLAVOR_OF = {
  cheri: ['spicy'], chesto: ['dry'], pecha: ['sweet'], rawst: ['bitter'], aspear: ['sour'],
  leppa: ['spicy', 'sweet', 'bitter', 'sour'], oran: ['dry', 'sweet', 'bitter', 'sour'], persim: ['spicy', 'dry', 'bitter', 'sour'], lum: ['spicy', 'dry', 'sweet', 'bitter'], sitrus: ['dry', 'sweet', 'bitter', 'sour'],
  figy: ['spicy'], wiki: ['dry'], mago: ['sweet'], aguav: ['bitter'], iapapa: ['sour'],
  razz: ['spicy', 'dry'], bluk: ['dry', 'sweet'], nanab: ['sweet', 'bitter'], wepear: ['bitter', 'sour'], pinap: ['spicy', 'sour'],
  pomeg: ['spicy', 'sweet'], kelpsy: ['dry', 'bitter'], qualot: ['sweet', 'sour'], hondew: ['spicy', 'dry', 'bitter'], grepa: ['dry', 'sweet', 'sour'], tamato: ['spicy', 'dry'],
  cornn: ['dry', 'sweet'], magost: ['sweet', 'bitter'], rabuta: ['bitter', 'sour'], nomel: ['spicy', 'sour'], spelon: ['spicy', 'dry'], pamtre: ['dry', 'sweet'], watmel: ['sweet', 'bitter'], durin: ['bitter', 'sour'], belue: ['spicy', 'sour'],
  occa: ['spicy', 'sweet'], passho: ['dry', 'bitter'], wacan: ['sweet', 'sour'], rindo: ['spicy', 'bitter'], yache: ['dry', 'sour'], chople: ['spicy', 'bitter'], kebia: ['dry', 'sour'], shuca: ['spicy', 'sweet'], coba: ['dry', 'bitter'], payapa: ['sweet', 'sour'], tanga: ['spicy', 'sour'], charti: ['spicy', 'dry'], kasib: ['dry', 'sweet'], haban: ['sweet', 'bitter'], colbur: ['bitter', 'sour'], babiri: ['spicy', 'dry'], chilan: ['dry'], roseli: ['sweet', 'bitter'],
  liechi: ['spicy', 'dry', 'sweet'], ganlon: ['dry', 'sweet', 'bitter'], salac: ['sweet', 'bitter', 'sour'], petaya: ['spicy', 'bitter', 'sour'], apicot: ['spicy', 'dry', 'sour'], lansat: ['spicy', 'dry', 'sweet', 'bitter', 'sour'], starf: ['spicy', 'dry', 'sweet', 'bitter', 'sour'],
  enigma: ['spicy', 'dry'], micle: ['dry', 'sweet'], custap: ['sweet', 'bitter'], jaboca: ['bitter', 'sour'], rowap: ['spicy', 'sour'], kee: ['spicy', 'dry'], maranga: ['bitter', 'sour'],
  // the starter set's own
  bramble: ['sour', 'sweet'], glow: ['sweet', 'dry'], sweetroot: ['sweet'], honey: ['sweet'],
};
const EFFECT_OF = {
  oran: { energy: 10, joy: 8 }, sitrus: { energy: 25, joy: 6 }, leppa: { energy: 40 }, chesto: { energy: 30 }, cheri: { energy: 12, joy: 6 },
  pecha: { joy: 22 }, aspear: { joy: 14 }, rawst: { energy: 10, calm: true }, persim: { calm: true, joy: 6 }, lum: { calm: true, energy: 20, joy: 12 },
  figy: { joy: 20 }, wiki: { joy: 20 }, mago: { joy: 24 }, aguav: { joy: 18, energy: 8 }, iapapa: { joy: 20 },
  pomeg: { friendship: 6 }, kelpsy: { friendship: 6 }, qualot: { friendship: 6 }, hondew: { friendship: 6 }, grepa: { friendship: 6 }, tamato: { friendship: 6 },
  razz: { friendship: 3, joy: 10 }, bluk: { friendship: 3, joy: 10 }, nanab: { calm: true, joy: 8 }, wepear: { friendship: 3, joy: 10 }, pinap: { friendship: 3, joy: 10 },
  liechi: { energy: 30, joy: 15 }, ganlon: { energy: 30 }, salac: { energy: 35 }, petaya: { energy: 30 }, apicot: { energy: 30 }, lansat: { energy: 40, joy: 25, friendship: 5 }, starf: { energy: 40, joy: 30, friendship: 5 },
};
const key = (it) => String(it?.name ?? it?.id ?? '').toLowerCase().replace(/\s*berry$/, '').replace(/[^a-z]/g, '');

/** A food's flavours (berries by name; dishes and others: none). */
export function flavorsOf(it) { return FLAVOR_OF[key(it)] ?? (/berry/i.test(it?.name ?? '') ? ['sweet'] : []); }
export const isBerry = (it) => it?.kind === 'food' && !String(it.id).startsWith('dish-') && !it.unlimited && (/berry|drop|root/i.test(`${it.name} ${it.id}`) || !!it.grow);

/** What eating it does: { fullness, joy, energy, friendship, calm }. */
export function foodEffects(it) {
  if (!it) return { fullness: 20, joy: 0, energy: 0, friendship: 1, calm: false };
  const named = EFFECT_OF[key(it)] ?? {};
  return {
    fullness: it.fullness ?? (isBerry(it) ? 12 : 20),
    joy: it.joy ?? named.joy ?? (isBerry(it) ? 10 : 0),
    energy: it.energy ?? named.energy ?? 0,
    friendship: it.friendship ?? named.friendship ?? 1,
    calm: !!(it.calm ?? named.calm),
    // only fresh, minty things freshen them up
    hygiene: it.hygiene ?? (/mint/i.test(`${it.name ?? ''} ${it.id ?? ''}`) ? 15 : 0),
  };
}
/** What one serving restores, in numbers: "Fullness +12 · Energy +10 · Joy +8" (tidiness only for minty things). */
export function foodStats(it) {
  if (!it || it.kind !== 'food') return '';
  const e = foodEffects(it), out = [];
  const full = it.unlimited ? Math.min(e.fullness, KIBBLE_FULLNESS) : e.fullness;
  if (full) out.push(`Fullness +${full}`);
  if (e.energy) out.push(`Energy +${e.energy}`);
  if (e.joy) out.push(`Joy +${e.joy}`);
  if (e.hygiene) out.push(`Tidiness +${e.hygiene}`);
  if (e.friendship > 1) out.push(`Friendship +${e.friendship}`);
  if (e.calm) out.push('Calms them');
  return out.join(' · ');
}
/** A few words on what a food does ("Restores energy · calms them down"). */
export function foodBlurb(it) {
  const e = foodEffects(it), out = [];
  if (it?.unlimited) out.push('never runs out, but only fills them a little');
  if (e.energy >= 25) out.push('restores lots of energy'); else if (e.energy > 0) out.push('restores some energy');
  if (e.calm) out.push('calms an upset creature');
  if (e.friendship >= 5) out.push('makes them much friendlier'); else if (e.friendship >= 3) out.push('makes them friendlier');
  if (e.joy >= 25) out.push('a real treat'); else if (e.joy >= 15) out.push('cheers them up');
  if (e.fullness >= 45) out.push('very filling');
  return out.join(' · ');
}

// ---------- recipes ----------
// needs: [{ name: /regex/ } | { flavor } | { any: true }, n]
const N = (re) => ({ name: re }), F = (flavor) => ({ flavor }), ANY = { any: true };
export const RECIPES = [
  { id: 'jam', name: 'Berry Jam', needs: [[F('sweet'), 3]], color: '#e0406a', fullness: 25, joy: 32, friendship: 3, desc: 'Three sweet berries, cooked down slowly.' },
  { id: 'curry', name: 'Spicy Curry', needs: [[F('spicy'), 2], [ANY, 1]], color: '#d06a20', fullness: 55, joy: 18, energy: 30, desc: 'Warming and full of beans.' },
  { id: 'candy', name: 'Sour Candy', needs: [[F('sour'), 2]], color: '#f2d040', fullness: 8, joy: 26, desc: 'Makes their face scrunch up. They love it.' },
  { id: 'tonic', name: 'Bitter Tonic', needs: [[F('bitter'), 2]], color: '#5a8a4a', fullness: 10, joy: 4, energy: 35, calm: true, desc: 'Tastes awful, works wonders. Calms them down.' },
  { id: 'crackers', name: 'Dry Crackers', needs: [[F('dry'), 2]], color: '#c8a060', fullness: 40, joy: 10, energy: 10, desc: 'Crunchy and filling.' },
  { id: 'oran-soup', name: 'Oran Soup', needs: [[N(/oran/), 2]], color: '#3b6cf6', fullness: 45, joy: 15, energy: 25, desc: 'The classic. Two Oran Berries in a pot.' },
  { id: 'sitrus-smoothie', name: 'Sitrus Smoothie', needs: [[N(/sitrus/), 1], [F('sweet'), 1]], color: '#f2c14a', fullness: 20, joy: 20, energy: 45, desc: 'A big burst of energy.' },
  { id: 'leppa-bar', name: 'Leppa Energy Bar', needs: [[N(/leppa/), 1], [F('dry'), 1]], color: '#e06a3a', fullness: 30, joy: 10, energy: 60, desc: 'For a creature that’s worn out.' },
  { id: 'lum-salad', name: 'Lum Salad', needs: [[N(/lum/), 1], [ANY, 2]], color: '#7ad04a', fullness: 35, joy: 22, energy: 20, calm: true, desc: 'Fresh, green and soothing.' },
  { id: 'persim-tea', name: 'Persim Tea', needs: [[N(/persim/), 1], [F('sweet'), 1]], color: '#ff9a4a', fullness: 10, joy: 14, calm: true, friendship: 3, desc: 'A warm cup that settles any upset.' },
  { id: 'rainbow-mix', name: 'Rainbow Mix', needs: [[{ different: 5 }, 5]], color: '#c07aff', fullness: 30, joy: 40, friendship: 6, desc: 'Five different berries. A feast of colours.' },
  { id: 'friend-pie', name: 'Friendship Pie', needs: [[N(/pomeg|kelpsy|qualot|hondew|grepa|tamato/), 2], [F('sweet'), 1]], color: '#ff7ab0', fullness: 40, joy: 25, friendship: 10, desc: 'Baked with the berries that bring you closer.' },
  { id: 'berry-block', name: 'Berry Block', needs: [[ANY, 4]], color: '#a06aff', fullness: 20, joy: 22, friendship: 4, desc: 'Four berries blended and set into a little block.' },
  { id: 'honey-cake', name: 'Honey Cake', needs: [[N(/honey/), 1], [F('sweet'), 2]], color: '#f2c14a', fullness: 40, joy: 34, friendship: 4, desc: 'Sweet, sticky and everyone’s favourite.' },
  { id: 'root-stew', name: 'Sweetroot Stew', needs: [[N(/sweetroot|root/), 1], [ANY, 2]], color: '#a0603a', fullness: 65, joy: 18, energy: 15, desc: 'A hearty bowl for a hungry creature.' },
  { id: 'glow-pudding', name: 'Glow Pudding', needs: [[N(/glow/), 2]], color: '#4ad0ff', fullness: 20, joy: 28, energy: 25, desc: 'Wobbly and faintly glowing.' },
  { id: 'bramble-tart', name: 'Bramble Tart', needs: [[N(/bramble/), 2], [F('sweet'), 1]], color: '#c0306a', fullness: 30, joy: 28, friendship: 3, desc: 'Tart, sweet and crumbly.' },
  { id: 'trail-mix', name: 'Trail Mix', needs: [[F('dry'), 2], [F('sweet'), 1], [ANY, 1]], color: '#b08050', fullness: 35, joy: 14, energy: 25, desc: 'For long walks.' },
  { id: 'pinch-tea', name: 'Starf Elixir', needs: [[N(/starf|lansat/), 1], [ANY, 2]], color: '#ffe48a', fullness: 15, joy: 40, energy: 45, friendship: 6, desc: 'Made from the rarest berries there are.' },
];
/** Recipe dishes as foods (ids "dish-<recipe>"), so they can be eaten, given and sold like any other. */
export const RECIPE_DISHES = RECIPES.map((r) => ({ id: `dish-${r.id}`, name: r.name, kind: 'food', fullness: r.fullness, joy: r.joy, energy: r.energy ?? 0, friendship: r.friendship ?? 2, calm: !!r.calm, color: r.color, desc: r.desc, price: 80 + r.joy * 3 + (r.energy ?? 0) * 2 }));

/** The berries in the bag that could go into recipes: [{ item, n }]. */
function pantry(allFoodsList, inventory) {
  return allFoodsList.filter((it) => isBerry(it) && (inventory[it.id] ?? 0) > 0).map((item) => ({ item, n: inventory[item.id] }));
}
const needLabel = ([req, n]) => req.any ? `${n} of any berry` : req.flavor ? `${n} ${req.flavor}` : req.different ? `${n} different berries` : `${n} ${String(req.name.source).split('|')[0].replace(/[^a-z]/gi, '').replace(/^./, (x) => x.toUpperCase())}`;
/** What a recipe needs, in words: ["2 sweet", "1 of any berry"]. */
export function recipeNeeds(r) { return r.needs.map(needLabel); }

/**
 * Can you make it with what's in the bag? { ok, picks: [item ids, one per berry used], missing: [labels] }.
 * Specific berries are picked first, then flavours, then anything, using what you have most of.
 */
export function recipeStatus(allFoodsList, inventory, r) {
  const left = new Map(pantry(allFoodsList, inventory).map(({ item, n }) => [item.id, { item, n }]));
  const picks = [], missing = [];
  const order = [...r.needs].sort((a, b) => (a[0].name ? 0 : a[0].flavor ? 1 : a[0].different ? 2 : 3) - (b[0].name ? 0 : b[0].flavor ? 1 : b[0].different ? 2 : 3));
  for (const [req, n] of order) {
    let got = 0;
    if (req.different) {
      const ids = [...left.values()].filter((x) => x.n > 0).sort((a, b) => b.n - a.n).slice(0, n);
      for (const x of ids) { x.n--; picks.push(x.item.id); got++; }
    } else {
      for (let i = 0; i < n; i++) {
        const cand = [...left.values()].filter((x) => x.n > 0 && (req.any || (req.flavor && flavorsOf(x.item).includes(req.flavor)) || (req.name && req.name.test(`${x.item.name} ${x.item.id}`.toLowerCase())))).sort((a, b) => b.n - a.n)[0];
        if (!cand) break;
        cand.n--; picks.push(cand.item.id); got++;
      }
    }
    if (got < n) missing.push(needLabel([req, n - got]));
  }
  return { ok: !missing.length, picks, missing };
}

// ---------- kibble ----------
/** Kibble never runs out; it only fills them a little, and lots of it gets old unless they love it. */
export const KIBBLE_FULLNESS = 12;
