// The berry farm next to the R.A.N.C.H. yard: plant one of a food, harvest several later.
// Growth uses real time, so plants keep growing while the app is closed.
//
// It grows like the yards: a Farm Expansion adds a row of three planters (up to fifteen). Tools you buy
// once and keep (Sprayduck, Wailmer Pail: faster growth; Harvest Basket, Golden Shears: more at harvest),
// and mulch for one planting at a time (as in Diamond/Pearl and the Gen 6 games).
import { blueprintOf, bpId } from './ranchBuild.js';
export const FARM_PLOTS = 6;
export const MAX_FARM_SIZE = 3;
export const farmPlots = (save) => FARM_PLOTS + Math.max(0, Math.min(MAX_FARM_SIZE, save?.farm?.size ?? 0)) * 3;
const has = (save, id) => (save?.inventory?.[bpId(id)] ?? 0) > 0;
/** How much faster everything grows with your tools (1 = normal). */
export const toolSpeed = (save) => (has(save, 'wailmer-pail') ? 1.3 : has(save, 'sprayduck') ? 1.15 : 1);
/** The farm tools you have: [{ id, name, desc }]. */
export const farmTools = (save) => ['sprayduck', 'wailmer-pail', 'harvest-basket', 'golden-shears'].filter((id) => has(save, id)).map((id) => blueprintOf(id));
/** Mulch in the bag: [{ id, name, desc, n }]. */
export const mulchInBag = (save) => ['growth-mulch', 'damp-mulch', 'rich-mulch', 'gooey-mulch', 'amaze-mulch'].map((id) => ({ ...blueprintOf(id), n: save?.inventory?.[bpId(id)] ?? 0 })).filter((m) => m.n > 0);

export function farmState(save) {
  if (!save.farm || !Array.isArray(save.farm.plots)) save.farm = { plots: [], size: save.farm?.size ?? 0 };
  while (save.farm.plots.length < farmPlots(save)) save.farm.plots.push(null);
  return save.farm;
}
/** Use a Farm Expansion: one more row of planters. */
export function expandFarm(save) {
  const farm = farmState(save);
  if ((farm.size ?? 0) >= MAX_FARM_SIZE) return { ok: false, reason: 'The farm is as big as it gets.' };
  if (!has(save, 'farm-expand')) return { ok: false, reason: 'You need a Farm Expansion (Market → Blueprints → Berry farm).' };
  save.inventory[bpId('farm-expand')]--;
  farm.size = (farm.size ?? 0) + 1;
  farmState(save);
  return { ok: true, size: farm.size, plots: farmPlots(save) };
}

/** Foods that can be planted: those with a `grow` entry, or any limited food if none has one. */
export function plantable(idx) {
  const items = idx.ds.items ?? [];
  const growing = items.filter((i) => i.grow);
  return growing.length ? growing : items.filter((i) => i.kind === 'food' && !i.unlimited);
}

export function growInfo(item) {
  return { hours: Math.max(0.01, Number(item?.grow?.hours) || 3), yield: Math.max(1, Math.round(Number(item?.grow?.yield) || 3)) };
}

/** { empty } or { item, stage: 0..3, ready, left (ms), frac } */
export function plotStatus(idx, plot, now = Date.now()) {
  if (!plot) return { empty: true };
  const item = idx.items.get(plot.item);
  // how fast it grows: the tools you had when it was planted, and its mulch
  const ms = (growInfo(item).hours * 3600000) / ((plot.speed ?? 1) * (plot.mulch?.speed ?? 1));
  const frac = Math.max(0, Math.min(1, (now - plot.plantedAt) / ms));
  return { item, itemId: plot.item, mulch: plot.mulchId ?? null, frac, stage: frac >= 1 ? 3 : Math.min(2, Math.floor(frac * 3)), ready: frac >= 1, left: Math.max(0, plot.plantedAt + ms - now) };
}

export function plant(idx, save, i, itemId, now = Date.now(), mulchId = null) {
  const farm = farmState(save);
  if (i < 0 || i >= farmPlots(save)) return { ok: false, reason: 'There is no such plot.' };
  if (farm.plots[i]) return { ok: false, reason: 'Something is already growing there.' };
  const item = idx.items.get(itemId);
  if (!item || !plantable(idx).includes(item)) return { ok: false, reason: 'That cannot be planted.' };
  if (!item.unlimited && (save.inventory[itemId] ?? 0) < 1) return { ok: false, reason: `You have no ${item.name} to plant.` };
  const m = mulchId ? blueprintOf(mulchId) : null;
  if (mulchId && (!m?.mulch || !has(save, mulchId))) return { ok: false, reason: 'You don’t have that mulch.' };
  if (!item.unlimited) save.inventory[itemId] -= 1;
  if (m) save.inventory[bpId(mulchId)]--;
  farm.plots[i] = { item: itemId, plantedAt: now, speed: toolSpeed(save), ...(m ? { mulchId, mulch: { ...m.mulch } } : {}) };
  return { ok: true };
}

export function harvest(idx, save, i, now = Date.now()) {
  const farm = farmState(save);
  const st = plotStatus(idx, farm.plots[i], now);
  if (st.empty) return { ok: false, reason: 'Nothing is planted there.' };
  if (!st.ready) return { ok: false, reason: 'Not ripe yet.' };
  const plot = farm.plots[i];
  const base = growInfo(st.item).yield;
  // extras: mulch, tools, and luck
  let bonus = plot.mulch?.extra ?? 0;
  const roll = () => Math.random();
  if (plot.mulch?.lucky && roll() < plot.mulch.lucky) bonus += roll() < 0.5 ? 2 : 1;
  if (has(save, 'golden-shears')) bonus += 1;
  if (has(save, 'harvest-basket') && roll() < 0.35) bonus += 1;
  const n = base + bonus;
  save.inventory[st.itemId] = (save.inventory[st.itemId] ?? 0) + n;
  // Gooey Mulch: it grows back once by itself
  const regrow = plot.mulch?.regrow > 0;
  farm.plots[i] = regrow ? { item: plot.item, plantedAt: now, speed: toolSpeed(save), mulchId: plot.mulchId, mulch: { ...plot.mulch, regrow: plot.mulch.regrow - 1 } } : null;
  return { ok: true, item: st.item, count: n, bonus, regrew: regrow };
}
