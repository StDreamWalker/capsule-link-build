// Dataset access: indexing, validation, growth curves, type matchups.
import { normalizeBrand } from './brand.js';
import { createDefaultDataset, DEFAULT_FORMULAS, DEFAULT_RULES, DEFAULT_STAT_LABELS, STAT_KEYS } from './defaults.js';
import { compileFormula, checkFormula } from './formula.js';
import { hashString } from './rng.js';

export { STAT_KEYS };

export const slug = (s) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '')
  .replace(/['’.]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');

/** Fill missing sections with defaults so older or pasted datasets keep working. */
export function normalizeDataset(raw) {
  const def = createDefaultDataset();
  const ds = Object.assign({}, raw);
  ds.meta = Object.assign({ name: 'Untitled set', version: 1 }, raw?.meta);
  ds.statLabels = Object.assign({}, DEFAULT_STAT_LABELS, raw?.statLabels);
  for (const key of ['types', 'temperaments', 'growthRates', 'statuses', 'species', 'moves', 'items']) {
    if (!Array.isArray(ds[key])) ds[key] = def[key];
  }
  ds.typeChart = ds.typeChart && typeof ds.typeChart === 'object' ? ds.typeChart : {};
  ds.brand = normalizeBrand(raw?.brand);
  ds.formulas = Object.assign({}, def.formulas, raw?.formulas);
  ds.rules = Object.assign({}, DEFAULT_RULES, raw?.rules);
  ds.rules.needsDecayPerHour = Object.assign({}, DEFAULT_RULES.needsDecayPerHour, raw?.rules?.needsDecayPerHour);

  // give everything stable ids and numbers (numbers are what capsules store)
  const fixList = (list, prefix) => {
    const used = new Set();
    let maxNo = list.reduce((m, x) => Math.max(m, Number(x.no) || 0), 0);
    for (const x of list) {
      if (!x.id) x.id = slug(x.name) || `${prefix}-${x.no ?? used.size + 1}`;
      let id = x.id, n = 2;
      while (used.has(id)) id = `${x.id}-${n++}`;
      x.id = id; used.add(id);
      if (!(Number(x.no) > 0)) x.no = ++maxNo;
      else x.no = Number(x.no);
      if (!x.name) x.name = x.id;
    }
  };
  fixList(ds.species, 'species');
  fixList(ds.moves, 'move');
  for (const t of ds.types) { if (!t.id) t.id = slug(t.name); if (!t.name) t.name = t.id; if (!t.color) t.color = '#aaaaaa'; }
  for (const s of ds.species) {
    s.types = (Array.isArray(s.types) ? s.types : [s.types]).filter(Boolean).slice(0, 2);
    s.baseStats = Object.assign({ hp: 50, atk: 50, def: 50, spa: 50, spd: 50, spe: 50 }, s.baseStats);
    s.learnset = Array.isArray(s.learnset) ? s.learnset : [];
    s.evolutions = Array.isArray(s.evolutions) ? s.evolutions : [];
    s.effortYield = s.effortYield || {};
    if (!s.growthRate) s.growthRate = ds.growthRates[0]?.id;
    if (s.baseExp == null) s.baseExp = 64;
    if (s.baseFriendship == null) s.baseFriendship = 70;
    if (s.abilities && !Array.isArray(s.abilities)) s.abilities = typeof s.abilities === 'string' ? s.abilities.split(/\s*[,/]\s*/).filter(Boolean) : Object.values(s.abilities).filter(Boolean);
  }
  // home-made abilities (the Data Lab's Abilities): a name, what it says, and how it works in battle
  ds.abilities = Array.isArray(ds.abilities) ? ds.abilities.filter((a) => a && a.name) : [];
  for (const a of ds.abilities) { if (!a.id) a.id = slug(a.name); a.kind = a.kind || (a.like ? 'like' : 'none'); }
  for (const m of ds.moves) {
    if (!['physical', 'special', 'status'].includes(m.category)) m.category = m.power > 0 ? 'physical' : 'status';
    m.power = Number(m.power) || 0;
    m.accuracy = m.accuracy == null || m.accuracy === true ? null : Number(m.accuracy);
    m.pp = Number(m.pp) || 10;
    m.priority = Number(m.priority) || 0;
  }
  return ds;
}

/** Fast lookups. Rebuild after editing. */
export function indexDataset(dsRaw) {
  const ds = normalizeDataset(dsRaw);
  const byId = (list) => new Map(list.map((x) => [x.id, x]));
  const byNo = (list) => new Map(list.map((x) => [x.no, x]));
  const idx = {
    ds,
    species: byId(ds.species), speciesByNo: byNo(ds.species),
    moves: byId(ds.moves), movesByNo: byNo(ds.moves),
    types: byId(ds.types), temperaments: byId(ds.temperaments),
    growth: byId(ds.growthRates), items: byId(ds.items), statuses: byId(ds.statuses),
    expTables: new Map(),
    hash: datasetHash(ds),
    // everything (names, intro text, stats, extras…): when this differs, phones get the whole set again
    syncHash: hashString(JSON.stringify(ds)),
  };
  // also allow case-insensitive name lookups for moves/species
  idx.moveByName = new Map(ds.moves.map((m) => [slug(m.name), m]));
  idx.speciesByName = new Map(ds.species.map((s) => [slug(s.name), s]));
  return idx;
}

/** A short fingerprint of the numbering that capsules depend on. */
export function datasetHash(ds) {
  const parts = [
    ds.species.map((s) => `${s.no}:${s.id}`).join(','),
    ds.moves.map((m) => `${m.no}:${m.id}`).join(','),
    ds.temperaments.map((t) => t.id).join(','),
  ];
  return hashString(parts.join('|'));
}

export function formula(idx, key) {
  return compileFormula(idx.ds.formulas[key] ?? DEFAULT_FORMULAS[key]?.src ?? '0');
}

export function runFormula(idx, key, vars, rng) {
  try {
    const v = formula(idx, key)(vars, rng);
    return typeof v === 'boolean' ? (v ? 1 : 0) : Number.isFinite(v) ? v : 0;
  } catch (e) {
    // a broken user formula should not crash a battle; fall back to the default
    const fallback = DEFAULT_FORMULAS[key]?.src;
    if (fallback && idx.ds.formulas[key] !== fallback) {
      console.warn(`Formula "${key}" failed (${e.message}); using the default.`);
      return Number(compileFormula(fallback)(vars, rng)) || 0;
    }
    throw e;
  }
}

/** Total experience needed to reach `level` for a growth rate. */
export function expForLevel(idx, growthId, level) {
  const table = expTable(idx, growthId);
  return table[Math.max(1, Math.min(level, table.length - 1))];
}

export function expTable(idx, growthId) {
  const gid = idx.growth.has(growthId) ? growthId : idx.ds.growthRates[0]?.id;
  if (idx.expTables.has(gid)) return idx.expTables.get(gid);
  const g = idx.growth.get(gid);
  const f = compileFormula(g?.formula ?? 'n^3');
  const max = idx.ds.rules.maxLevel;
  const table = [0, 0];
  for (let n = 2; n <= max; n++) {
    let v = Math.floor(Number(f({ n, level: n })) || 0);
    if (v <= table[n - 1]) v = table[n - 1] + 1; // keep it strictly increasing
    table[n] = v;
  }
  idx.expTables.set(gid, table);
  return table;
}

export function levelForExp(idx, growthId, exp) {
  const table = expTable(idx, growthId);
  let lv = 1;
  while (lv + 1 < table.length && table[lv + 1] <= exp) lv++;
  return lv;
}

export function typeMultiplier(idx, moveType, defenderTypes) {
  let m = 1;
  for (const t of defenderTypes) {
    const row = idx.ds.typeChart[moveType];
    const v = row && row[t] != null ? Number(row[t]) : 1;
    m *= v;
  }
  return m;
}

export function temperMultiplier(idx, temperId, stat) {
  const t = idx.temperaments.get(temperId);
  if (!t) return 1;
  if (t.up === stat) return 1.1;
  if (t.down === stat) return 0.9;
  return 1;
}

/** Validate a dataset; returns a list of human-readable problems. */
export function validateDataset(dsRaw) {
  const problems = [];
  const idx = indexDataset(dsRaw);
  const { ds } = idx;
  const typeIds = new Set(ds.types.map((t) => t.id));
  for (const s of ds.species) {
    for (const t of s.types) if (!typeIds.has(t)) problems.push(`${s.name}: unknown type "${t}"`);
    for (const l of s.learnset) if (!idx.moves.has(l.move)) problems.push(`${s.name}: learnset move "${l.move}" not found`);
    for (const e of s.evolutions) if (!idx.species.has(e.to)) problems.push(`${s.name}: evolves into unknown "${e.to}"`);
    if (!idx.growth.has(s.growthRate)) problems.push(`${s.name}: unknown growth rate "${s.growthRate}"`);
    if (s.no > 65535) problems.push(`${s.name}: number ${s.no} is too large for a capsule (max 65535)`);
  }
  for (const m of ds.moves) {
    if (!typeIds.has(m.type)) problems.push(`Move ${m.name}: unknown type "${m.type}"`);
    if (m.no > 65535) problems.push(`Move ${m.name}: number too large for a capsule`);
  }
  for (const [k, src] of Object.entries(ds.formulas)) {
    const r = checkFormula(src, sampleVars(k));
    if (!r.ok) problems.push(`Formula "${k}": ${r.error}`);
  }
  for (const g of ds.growthRates) {
    const r = checkFormula(g.formula, { n: 50, level: 50 });
    if (!r.ok) problems.push(`Growth rate "${g.name}": ${r.error}`);
  }
  return problems;
}

/** Example variables for testing each formula in the Data Lab. */
export function sampleVars(key) {
  const common = { level: 50 };
  switch (key) {
    case 'hpStat': return { base: 80, genes: 15, effort: 0, level: 50 };
    case 'stat': return { base: 80, genes: 15, effort: 0, level: 50, temper: 1, key: 'atk' };
    case 'expGain': return { baseExp: 64, foeLevel: 20, level: 18, participants: 1, linked: 0 };
    case 'walkFriendship': return { steps: 2500, friendship: 120 };
    case 'walkExp': return { steps: 2500, level: 20 };
    case 'walkFindChance': return { friendship: 120 };
    default: return common;
  }
}
