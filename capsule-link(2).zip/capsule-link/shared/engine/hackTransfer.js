// A creature, described the way a GBA ROM hack save wants it (romhackSaves.js turns this into a record):
// species as a national number and form, moves as national numbers, its own PID and trainer ID when it has
// them (a new PID with the right nature and shininess when it doesn't), genes, effort, experience for its
// level, friendship, ball and ability slot.
import { NATURE_NAMES } from './pkhex.js';
import { speciesAbilities } from './creature.js';
import { expForLevel } from './dataset.js';

const fromB64 = (s) => { const bin = typeof atob === 'function' ? atob(s) : Buffer.from(s, 'base64').toString('binary'); const o = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) o[i] = bin.charCodeAt(i); return o; };
const squash = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');
const hash = (s) => { let h = 2166136261; for (const ch of String(s ?? '')) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0; return h >>> 0; };

/** A PID with this nature (and shiny or not for this trainer ID), close to a seed. */
export function pidFor(nature, shiny, otid, seed = 1) {
  let x = (seed >>> 0) || 0x9e3779b9;
  const tsv = ((otid & 0xffff) ^ (otid >>> 16)) >>> 0;
  for (let i = 0; i < 200000; i++) {
    x = (Math.imul(x, 1103515245) + 12345) >>> 0;
    let pid = x;
    if (shiny) { const lo = pid & 0xffff; const hi = (tsv ^ lo ^ (i & 7)) & 0xffff; pid = ((hi << 16) | lo) >>> 0; }
    if (pid % 25 !== nature) continue;
    const sx = (tsv ^ (pid >>> 16) ^ (pid & 0xffff)) >>> 0;
    if (shiny ? sx < 8 : sx >= 8) return pid;
  }
  return (nature + 25 * 1000) >>> 0;
}

/** { ok, info } or { ok: false, reason } */
export function hackInfoFor(idx, c, { trainer = 'Trainer', trainerId = null } = {}) {
  if (!c) return { ok: false, reason: 'Nobody picked.' };
  if (c.egg) return { ok: false, reason: 'Eggs can’t go into a game yet.' };
  const sp = idx.species.get(c.speciesId);
  const national = Number(sp?.no);
  if (!national) return { ok: false, reason: `${sp?.name ?? 'This species'} has no national number in your data set (set one in the Data Lab), so the game wouldn’t know it.` };
  const sd = String(sp.showdownName ?? '');
  const formName = sd.includes('-') ? sd.slice(sd.indexOf('-') + 1) : '';
  const R = idx.ds.rules ?? {};
  const pk = c.pk ?? {};
  // the trainer: the one it came with, else you
  const otName = (pk.otName || c.origin?.ot || c.trainer || trainer || 'Trainer').slice(0, 7);
  const otid = pk.tid != null ? (((pk.sid ?? 0) << 16) | pk.tid) >>> 0 : (trainerId ?? hash(trainer)) >>> 0;
  // its nature, from its temperament's name or the stats it raises and lowers
  const t = (idx.ds.temperaments ?? []).find((x) => x.id === c.temper);
  let nature = NATURE_NAMES.findIndex((n) => squash(n) === squash(t?.showdownName) || squash(n) === squash(t?.name));
  if (nature < 0) nature = Number.isFinite(pk.nature) ? pk.nature : NATURE_NAMES.indexOf(pk.nature);
  if (nature < 0) nature = hash(c.uid) % 25;
  const pid = Number.isFinite(c.pid) && c.pid % 25 === nature ? c.pid >>> 0 : pidFor(nature, !!c.shiny, otid, hash(c.uid));
  const maxG = R.maxGenes ?? 31;
  const ivs = Object.fromEntries(['hp', 'atk', 'def', 'spe', 'spa', 'spd'].map((k) => [k, Math.round(((c.genes?.[k] ?? 0) * 31) / maxG)]));
  const evs = Object.fromEntries(['hp', 'atk', 'def', 'spe', 'spa', 'spd'].map((k) => [k, Math.min(252, Math.round(c.effort?.[k] ?? 0))]));
  let total = Object.values(evs).reduce((a, b) => a + b, 0);
  for (const k of ['spd', 'spa', 'spe', 'def', 'atk', 'hp']) { if (total <= 510) break; const cut = Math.min(evs[k], total - 510); evs[k] -= cut; total -= cut; }
  const moves = [], pp = [];
  for (const m of c.moves ?? []) { const mv = idx.moves?.get?.(m.id) ?? idx.ds.moves.find((x) => x.id === m.id); const no = Number(mv?.no); if (no) { moves.push(no); pp.push(Math.min(64, m.pp ?? mv.pp ?? 10)); } }
  const abil = speciesAbilities(sp);
  const slot = Math.max(0, abil.indexOf(c.ability));
  const level = Math.max(1, Math.min(100, c.level ?? 5));
  return {
    ok: true,
    info: {
      national, formName, name: sp.name, nickname: (c.nickname || sp.name || '').slice(0, 10), otName, pid, otid,
      exp: expForLevel(idx, sp.growthRate, level), level, moves: moves.slice(0, 4), pp: pp.slice(0, 4), ivs, evs,
      friendship: Math.min(255, c.friendship ?? 70), ball: Number(c.ball) || 4, abilityNumber: slot === 2 ? 4 : slot === 1 ? 2 : 1,
      metLevel: Math.min(100, c.metLevel || level), raw: pk.hackRaw ? fromB64(pk.hackRaw) : null, rawHack: pk.romhack ?? null, importLevel: pk.importLevel ?? null,
    },
  };
}

/**
 * What happens to what a creature gains here when it goes back to the game it came from: null when it all goes
 * with it, else a sentence for the warning marker beside its summary.
 */
export function homeTransferNote(c) {
  const pk = c?.pk;
  if (!pk || c.egg) return null;
  const game = c.origin?.game ?? 'its game';
  if (pk.romhack) {
    const base = `From a ROM hack (${game}). Hacks keep Pokémon their own way, so it may not go back exactly as it was. Keep a backup of that save before putting it back.`;
    if (pk.romhack === 'rowe') return `${base} Going back to ROWE, its level, moves and nickname from here go with it, but effort (EV) training doesn’t.`;
    if (!pk.hackRaw) return base;
    return `${base} Its level, moves, effort, friendship and nickname from here go back with it.`;
  }
  if (pk.raw) return `Going back to ${game}: it returns exactly as it came. Levels, moves, effort (EV) training and anything else it gains here stay in Capsule Link.`;
  return null;
}
