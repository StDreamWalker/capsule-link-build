// A data set's own creatures in battle: everything a battle needs to know about the species, moves, abilities
// and types Showdown has never heard of (the battle bundle builds them into a separate copy of Showdown's
// tables, leaving Showdown's own untouched). Anything Showdown already knows by name stays Showdown's.
//
//   battlePackage(idx) → { types, species, moves, abilities } (plain data, safe to send to a friend too)
//   battleKnows(SD) → knows(kind, name): true for anything Showdown or the data set has

const toId = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');
const clean = (s) => String(s ?? '').replace(/[|,\[\]<>]/g, '').trim().slice(0, 40);
export const ABILITY_KINDS = [
  ['like', 'Works like a Showdown ability'],
  ['typeBoost', 'Powers up moves of one type (×1.3)'],
  ['immune', 'Immune to moves of one type'],
  ['absorb', 'Heals from moves of one type'],
  ['entryBoost', 'Raises a stat when it comes out'],
  ['hitBoost', 'Raises a stat when it’s hit'],
  ['turnBoost', 'Raises a stat every turn'],
  ['regen', 'Heals a little every turn'],
  ['stance', 'Changes form like Stance Change (attacks → its other form, status moves → back)'],
  ['none', 'No effect in battle (just its name)'],
];

export function battlePackage(idx) {
  const ds = idx?.ds ?? idx;
  const types = ds.types ?? [];
  const tName = (id) => { const t = types.find((x) => x.id === id); return clean(t?.showdownName || t?.name || id) || 'Normal'; };
  const chart = ds.typeChart ?? {};
  // forms: battle as "Base-Forme", linked to their base species
  const byId = new Map((ds.species ?? []).map((x) => [x.id, x]));
  const baseOf = (sp) => (sp.baseSpecies ? byId.get(sp.baseSpecies) ?? (ds.species ?? []).find((x) => toId(x.name) === toId(sp.baseSpecies)) : null);
  const formOf = (sp) => { const b = baseOf(sp); return b && b !== sp ? { baseSpecies: clean(b.showdownName || b.name), forme: clean(sp.forme || String(sp.name).replace(new RegExp(`^${String(b.name).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}-?`, 'i'), '') || sp.name), battleOnly: !!sp.battleOnly } : sp.baseForme ? { baseForme: clean(sp.baseForme) } : {}; };
  return {
    types: types.map((t) => ({ name: tName(t.id), against: Object.fromEntries(Object.entries(chart[t.id] ?? {}).map(([d, x]) => [tName(d), Number(x)])) })),
    species: (ds.species ?? []).map((sp) => ({
      ...formOf(sp),
      name: clean(sp.showdownName || sp.name), types: (sp.types ?? []).map(tName), baseStats: sp.baseStats ?? {},
      abilities: (Array.isArray(sp.abilities) ? sp.abilities : sp.abilities && typeof sp.abilities === 'object' ? Object.values(sp.abilities) : []).map(clean).filter(Boolean),
      heightm: Number(sp.height) || 1, weightkg: Number(sp.weight) || 20,
    })),
    moves: (ds.moves ?? []).map((mv) => ({ name: clean(mv.showdownName || mv.name), type: tName(mv.type), category: mv.category, power: mv.power, accuracy: mv.accuracy, pp: mv.pp, priority: mv.priority, effect: mv.effect ?? null, desc: mv.desc ?? '' })),
    abilities: (ds.abilities ?? []).map((a) => ({ name: clean(a.name), desc: String(a.desc ?? '').slice(0, 300), kind: a.kind ?? (a.like ? 'like' : 'none'), like: a.like ?? '', type: a.type ? tName(a.type) : '', stat: a.stat ?? 'atk', amount: a.amount ?? 1, form: clean(a.form ?? '') })),
  };
}

/** What can battle: anything Showdown knows, plus the data set's own (when the battle bundle can take them). */
export function battleKnows(SD, idx) {
  if (!SD?.custom) return SD.knows;
  const ds = idx?.ds ?? idx;
  const have = {
    species: new Set((ds.species ?? []).map((s) => toId(s.showdownName || s.name))),
    move: new Set((ds.moves ?? []).map((m) => toId(m.showdownName || m.name))),
    ability: new Set([...(ds.abilities ?? []).map((a) => toId(a.name)), ...(ds.species ?? []).flatMap((s) => (Array.isArray(s.abilities) ? s.abilities : Object.values(s.abilities ?? {})).map(toId))]),
  };
  return (kind, name) => SD.knows(kind, name) || !!have[kind]?.has(toId(name));
}

// ---------- abilities from a file (the Data Lab's Upload) ----------
/** Abilities from a JSON or CSV/TSV file's text: [{ name, desc, kind, like, type, stat, amount }]. */
export function parseAbilities(text, typeIds = []) {
  const s = String(text ?? '').replace(/^﻿/, '').trim();
  if (!s) return [];
  let rows = [];
  if (/^[[{]/.test(s)) {
    const j = JSON.parse(s);
    rows = Array.isArray(j) ? j : Array.isArray(j.abilities) ? j.abilities : Object.entries(j).map(([name, v]) => (typeof v === 'string' ? { name, desc: v } : { name, ...v }));
  } else {
    const lines = s.split(/\r?\n/).filter((l) => l.trim());
    const sep = lines[0].includes('\t') ? '\t' : ',';
    const split = (l) => { const out = []; let cur = '', q = false; for (const ch of l) { if (ch === '"') q = !q; else if (ch === sep && !q) { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out.map((x) => x.trim()); };
    const head = split(lines[0]).map((x) => x.toLowerCase());
    const has = head.some((x) => /name|ability/.test(x));
    const col = (re) => head.findIndex((x) => re.test(x));
    const ci = { name: has ? col(/^(name|ability)/) : 0, desc: has ? col(/desc|effect|text/) : 1, kind: col(/kind|works|template/), like: col(/like|showdown/), type: col(/^type/), stat: col(/stat/), amount: col(/amount|stages|power/), form: col(/form/) };
    rows = (has ? lines.slice(1) : lines).map((l) => { const c = split(l); const g = (k) => (ci[k] >= 0 ? c[ci[k]] ?? '' : ''); return { name: g('name'), desc: g('desc'), kind: g('kind'), like: g('like'), type: g('type'), stat: g('stat'), amount: g('amount'), form: g('form') }; });
  }
  const kinds = new Set(ABILITY_KINDS.map((k) => k[0]));
  const typeOf = (t) => { const k = toId(t); return typeIds.find((x) => toId(x.id) === k || toId(x.name) === k)?.id ?? ''; };
  return rows.map((r) => {
    const name = clean(r.name ?? r.ability ?? ''); if (!name) return null;
    let kind = String(r.kind ?? '').trim();
    if (!kinds.has(kind)) kind = r.like ? 'like' : 'none';
    const stat = ['atk', 'def', 'spa', 'spd', 'spe'].includes(String(r.stat ?? '').toLowerCase()) ? String(r.stat).toLowerCase() : 'atk';
    return { id: toId(name), name, desc: String(r.desc ?? r.description ?? '').trim().slice(0, 300), kind, like: clean(r.like ?? ''), type: r.type ? typeOf(r.type) : '', stat, amount: Math.max(1, Math.min(3, Number(r.amount) || 1)), ...(r.form ? { form: clean(r.form) } : {}) };
  }).filter(Boolean);
}
