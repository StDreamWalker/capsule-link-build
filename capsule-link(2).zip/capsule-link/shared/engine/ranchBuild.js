// Building up the R.A.N.C.H.: blueprints bought at the market become things you place in a yard
// (a pond, a moonlit grove, a sun patch, play structures, built-in toys, decorations), plus yard
// expansions and the Link gate. Everyone has feelings about what's in their yard: water creatures
// love a pond (and the pond grows lilies when they live there), night owls love a moonlit grove,
// sun-lovers sprawl in the sun patch, fire creatures keep away from water… The yard report shows
// who thrives where, and with whom.
//
//   save.boxes[i].build = { size: 0…3, features: [{ id: 'f-…', bp: 'pond', x, z }] }
//   save.ranch.build      the same, for the free-range yard
//   blueprints you own are items in the bag: 'bp-<id>'
import { createRng, randomId } from './rng.js';
import { experience } from './memory.js';
import { traitsOf } from './personality.js';
import { mood } from './care.js';
import { friendsOf, similarity } from './bonds.js';
import { displayName } from './creature.js';
import { likesHabitat } from './habitats.js';

/** Yard sizes: the original yard, then three expansions. */
export const YARD_SIZES = [
  { x: 8, z: 9, label: 'Cosy' },
  { x: 9.5, z: 10.6, label: 'Roomy' },
  { x: 11, z: 12.2, label: 'Spacious' },
  { x: 13, z: 14, label: 'Sprawling' },
];
export const MAX_YARD_SIZE = YARD_SIZES.length - 1;

// tags: what a feature is about (sun, night, water, play, toy, rest, flowers, rock, sand, cold, warm, spooky, sky)
// floor: how it marks the ground in the yard; art: what stands there; r: its radius in yard units
export const BLUEPRINTS = [
  // habitats
  { id: 'pond', name: 'Pond', kind: 'habitat', price: 900, r: 1.7, floor: 'water', art: ['reed', 'lily'], tags: ['water'], desc: 'A little pond. Swimmers love it; water creatures living here make it bloom with lilies.' },
  { id: 'moon-grove', name: 'Moonlit Grove', kind: 'habitat', price: 1100, r: 1.6, floor: 'moss', art: ['glowshroom', 'glowshroom', 'lantern'], tags: ['night', 'spooky'], desc: 'A shady, glowing hollow. Night owls gather here; it glows brighter the more of them live in the yard.' },
  { id: 'sun-patch', name: 'Sun Patch', kind: 'habitat', price: 600, r: 1.4, floor: 'warm', art: ['flower'], tags: ['sun'], desc: 'A warm, bright clearing for lying in the sun. Grass creatures make flowers spring up around it.' },
  { id: 'flower-bed', name: 'Flower Bed', kind: 'habitat', price: 450, r: 1.1, floor: 'soil', art: ['flower', 'flower', 'flower', 'bush'], tags: ['flowers'], desc: 'Bright flowers. Bugs, fairies and grass creatures adore it.' },
  { id: 'rock-garden', name: 'Rock Garden', kind: 'habitat', price: 500, r: 1.3, floor: 'gravel', art: ['rock', 'rock', 'rock'], tags: ['rock'], desc: 'Boulders to climb and sit on. Rock, ground and fighting types feel at home.' },
  { id: 'sand-pit', name: 'Sand Pit', kind: 'habitat', price: 400, r: 1.3, floor: 'sand', art: [], tags: ['sand'], desc: 'Warm sand to dig in. Ground types love a good dig.' },
  { id: 'hot-spring', name: 'Hot Spring', kind: 'habitat', price: 1400, r: 1.3, floor: 'spring', art: ['rock', 'rock'], tags: ['warm', 'water', 'rest'], desc: 'A steaming pool for a long soak. Tired creatures head straight for it.' },
  { id: 'snow-drift', name: 'Snow Drift', kind: 'habitat', price: 700, r: 1.4, floor: 'snow', art: ['icespike'], tags: ['cold'], desc: 'A patch of snow that never melts. Ice types love it; fire types keep their distance.' },
  { id: 'mushroom-ring', name: 'Mushroom Ring', kind: 'habitat', price: 550, r: 1.1, floor: 'moss', art: ['mushroom', 'mushroom', 'mushroom', 'mushroom'], tags: ['spooky', 'flowers'], desc: 'A fairy ring. Ghosts, fairies and poison types are drawn to it.' },
  { id: 'perch', name: 'High Perch', kind: 'habitat', price: 650, r: 0.8, floor: null, art: ['perch'], tags: ['sky'], desc: 'A tall perch for fliers to rest on and watch the yard.' },
  // play
  { id: 'slide', name: 'Slide', kind: 'play', price: 800, r: 1.1, art: ['slide'], tags: ['play'], desc: 'Up the ladder, down the slide. Playful creatures can’t get enough.' },
  { id: 'swing', name: 'Swing', kind: 'play', price: 700, r: 1, art: ['swing'], tags: ['play'], desc: 'A swing for the brave.' },
  { id: 'climber', name: 'Climbing Frame', kind: 'play', price: 950, r: 1.2, art: ['climber'], tags: ['play', 'rock'], desc: 'Bars to scramble over. Strong, bold creatures love a challenge.' },
  { id: 'tunnel', name: 'Play Tunnel', kind: 'play', price: 500, r: 1, art: ['tunnel'], tags: ['play', 'spooky'], desc: 'A tunnel to dash through or hide in. Shy ones like it too.' },
  // built-in toys
  { id: 'ball-pit', name: 'Ball Pit', kind: 'toy', price: 750, r: 1.1, floor: 'balls', art: [], tags: ['toy', 'play'], desc: 'A pit of soft balls. Endless fun.' },
  { id: 'toy-chest', name: 'Toy Chest', kind: 'toy', price: 600, r: 0.7, art: ['chest'], tags: ['toy'], desc: 'Every so often someone pulls a toy out of it.' },
  { id: 'scratch-post', name: 'Scratching Post', kind: 'toy', price: 350, r: 0.6, art: ['post'], tags: ['toy'], desc: 'Something to scratch, chew and wrestle with.' },
  { id: 'hammock', name: 'Hammock', kind: 'toy', price: 550, r: 1, art: ['hammock'], tags: ['rest'], desc: 'For lazy afternoons. Sleepyheads love it.' },
  // decorations
  { id: 'fountain', name: 'Fountain', kind: 'decor', price: 1200, r: 1, art: ['fountain'], tags: ['water'], desc: 'A tinkling fountain. Water creatures like to splash in it.' },
  { id: 'lanterns', name: 'Lantern Post', kind: 'decor', price: 250, r: 0.5, art: ['lantern'], tags: ['night'], desc: 'A soft light for the evenings.' },
  { id: 'bench', name: 'Bench', kind: 'decor', price: 200, r: 0.8, art: ['bench'], tags: ['rest'], desc: 'Somewhere to sit and watch.' },
  { id: 'birdbath', name: 'Bird Bath', kind: 'decor', price: 300, r: 0.5, art: ['birdbath'], tags: ['sky', 'water'], desc: 'Fliers stop by for a drink and a splash.' },
  { id: 'statue', name: 'Statue', kind: 'decor', price: 900, r: 0.7, art: ['statue'], tags: ['rock'], desc: 'A proud little statue.' },
  { id: 'flag', name: 'Ranch Flag', kind: 'decor', price: 150, r: 0.4, art: ['flag'], tags: [], desc: 'Your ranch colours, flying high.' },
  // machines
  { id: 'fossil-machine', name: 'Fossil Revival Machine', kind: 'machine', price: 4000, r: 0.9, art: ['fossilmachine'], tags: ['rock'], desc: 'Brings a creature back to life from a fossil (very rare finds when scavenging). It takes a few hours; the creature joins this yard.' },
  { id: 'berry-blender', name: 'Berry Blender', kind: 'machine', price: 2500, r: 0.9, art: ['blender'], tags: ['play'], desc: 'Blend berries into Pokéblocks with friends (each brings one creature and one berry). Only one of you needs a blender.' },
  { id: 'incubator', name: 'Egg Incubator', kind: 'machine', price: 1800, r: 0.8, art: ['incubator'], tags: ['rest'], desc: 'Keeps eggs warm: eggs living in this yard hatch four times as fast, even without walks.' },
  // the yard itself
  { id: 'expand', name: 'Yard Expansion', kind: 'expand', price: 2500, desc: 'Makes one yard bigger (up to three times).' },
  // the berry farm: more planters, tools you keep, and mulch for one planting at a time
  { id: 'farm-expand', name: 'Farm Expansion', kind: 'farm', price: 2000, desc: 'Adds a row of three planters to the berry farm (up to three times: fifteen planters).' },
  { id: 'sprayduck', name: 'Sprayduck', kind: 'farm', tool: true, price: 1200, desc: 'A duck-shaped watering can. Everything on the farm grows 15% faster. Kept for good.' },
  { id: 'wailmer-pail', name: 'Wailmer Pail', kind: 'farm', tool: true, price: 2600, desc: 'Waters a lot at once: everything grows 30% faster (instead of the Sprayduck’s 15%). Kept for good.' },
  { id: 'harvest-basket', name: 'Harvest Basket', kind: 'farm', tool: true, price: 1800, desc: 'Every harvest has a 35% chance of one extra. Kept for good.' },
  { id: 'golden-shears', name: 'Golden Shears', kind: 'farm', tool: true, price: 4200, desc: 'Careful picking: one more from every harvest. Kept for good.' },
  { id: 'growth-mulch', name: 'Growth Mulch', kind: 'farm', mulch: { speed: 1.25 }, price: 150, desc: 'Spread on a planter when you plant: grows 25% faster. One planting.' },
  { id: 'damp-mulch', name: 'Damp Mulch', kind: 'farm', mulch: { speed: 0.8, extra: 1 }, price: 150, desc: 'Grows 20% slower, but gives one more. One planting.' },
  { id: 'rich-mulch', name: 'Rich Mulch', kind: 'farm', mulch: { lucky: 0.5 }, price: 260, desc: 'Half a chance of one or two extra at harvest. One planting.' },
  { id: 'gooey-mulch', name: 'Gooey Mulch', kind: 'farm', mulch: { regrow: 1 }, price: 260, desc: 'After you pick it, the plant grows back once by itself. One planting.' },
  { id: 'amaze-mulch', name: 'Amaze Mulch', kind: 'farm', mulch: { speed: 1.25, lucky: 0.5, regrow: 1 }, price: 650, desc: 'Growth, Rich and Gooey Mulch all in one. One planting.' },
  { id: 'link-gate', name: 'Link Gate', kind: 'link', price: 6000, r: 1.4, art: ['gate'], tags: ['link'], desc: 'A big gate that joins your yard to a friend’s, side by side, so your creatures can meet theirs and make friends. (Bring a friend’s yard over as a file for now; live links come later.)' },
];
export const BLUEPRINT_KINDS = { habitat: 'Habitats', play: 'Play areas', toy: 'Built-in toys', decor: 'Decorations', machine: 'Machines', expand: 'Yard', farm: 'Berry farm', link: 'Linking' };
export const bpId = (id) => `bp-${id}`;
export const blueprintOf = (id) => BLUEPRINTS.find((b) => b.id === String(id).replace(/^bp-/, '')) ?? null;
/** A blueprint as a bag item. */
export function blueprintItem(id) {
  const b = blueprintOf(id);
  return b ? { id: bpId(b.id), name: b.kind === 'farm' ? b.name : `${b.name} blueprint`, kind: 'blueprint', bp: b.id, price: b.price, desc: b.desc, color: '#4a7dff' } : null;
}

/** The build state of a yard (key: box index or 'ranch'), made if missing. */
export function yardBuild(save, key) {
  const owner = key === 'ranch' ? (save.ranch = save.ranch || { biome: 'meadow', name: 'Ranch' }) : save.boxes[key];
  if (!owner) return { size: 0, features: [] };
  if (!owner.build) owner.build = { size: 0, features: [] };
  return owner.build;
}

export function buyBlueprint(save, id) {
  const b = blueprintOf(id);
  if (!b) return { ok: false, reason: 'No such blueprint.' };
  const coins = Math.floor(save.wallet ?? 0);
  if (coins < b.price) return { ok: false, reason: `Not enough coins (${b.price} needed).` };
  if (b.tool && (save.inventory[bpId(b.id)] ?? 0) > 0) return { ok: false, reason: `You already have the ${b.name}.` };
  if (b.kind === 'link' && ((save.inventory[bpId(b.id)] ?? 0) > 0 || placedAnywhere(save, b.id))) return { ok: false, reason: 'You already have a Link gate.' };
  save.wallet = coins - b.price;
  save.inventory[bpId(b.id)] = (save.inventory[bpId(b.id)] ?? 0) + 1;
  return { ok: true, blueprint: b };
}
function placedAnywhere(save, bp) {
  return [...(save.boxes ?? []), save.ranch].some((o) => (o?.build?.features ?? []).some((f) => f.bp === bp));
}

/** Place a blueprint from the bag in a yard at (x, z). */
export function placeFeature(save, key, bp, x, z) {
  const b = blueprintOf(bp);
  if (!b || b.kind === 'expand' || b.kind === 'farm') return { ok: false, reason: 'That can’t be placed.' };
  if ((save.inventory[bpId(b.id)] ?? 0) <= 0) return { ok: false, reason: `No ${b.name} blueprint in the bag.` };
  const build = yardBuild(save, key);
  if (build.features.length >= featureRoom(build.size)) return { ok: false, reason: 'This yard is full. Expand it to fit more.' };
  save.inventory[bpId(b.id)]--;
  const f = { id: `f-${randomId(3)}`, bp: b.id, x: round(x), z: round(z), at: Date.now() };
  build.features.push(f);
  return { ok: true, feature: f };
}
export function moveFeature(save, key, fid, x, z) {
  const f = yardBuild(save, key).features.find((q) => q.id === fid);
  if (!f) return { ok: false };
  f.x = round(x); f.z = round(z);
  return { ok: true };
}
/** Take a feature down: its blueprint goes back in the bag. */
export function removeFeature(save, key, fid) {
  const build = yardBuild(save, key);
  const f = build.features.find((q) => q.id === fid);
  if (!f) return { ok: false };
  if (save.revivals?.[f.id]) return { ok: false, reason: 'The machine is busy reviving a fossil. Collect it first.' };
  build.features = build.features.filter((q) => q !== f);
  save.inventory[bpId(f.bp)] = (save.inventory[bpId(f.bp)] ?? 0) + 1;
  return { ok: true };
}
export function expandYard(save, key) {
  const build = yardBuild(save, key);
  if (build.size >= MAX_YARD_SIZE) return { ok: false, reason: 'This yard is as big as it gets.' };
  if ((save.inventory[bpId('expand')] ?? 0) <= 0) return { ok: false, reason: 'You need a Yard Expansion blueprint (the market sells them).' };
  save.inventory[bpId('expand')]--;
  build.size++;
  return { ok: true, size: build.size };
}
const round = (v) => Math.round((Number(v) || 0) * 100) / 100;
/** How many features fit in a yard of this size. */
export const featureRoom = (size) => 5 + (size ?? 0) * 3;

// ---------- feelings about features ----------
const typeWords = (idx, c) => {
  const sp = idx.species.get(c.formId ?? c.speciesId) ?? idx.species.get(c.speciesId);
  return (sp?.types ?? []).flatMap((t) => [String(t).toLowerCase(), String(idx.types?.get(t)?.name ?? '').toLowerCase()]).join(' ');
};
const TAG_TYPES = {
  water: /water|tide|bug/, night: /dark|shade|ghost|psychic|mind/, sun: /fire|ember|grass|sprout|normal|plain/, flowers: /grass|sprout|bug|fairy/,
  rock: /rock|stone|ground|fighting|brawl|steel|metal/, sand: /ground|rock|stone/, cold: /ice|frost/, warm: /fire|ember|normal|plain|psychic|mind/,
  spooky: /ghost|shade|fairy|poison|dark/, sky: /flying|gale|dragon/, play: /normal|plain|fighting|brawl|electric|volt|fairy/, toy: /normal|plain|dark|shade|electric|volt/, rest: /normal|plain|psychic|mind|water|tide/,
};
/**
 * How a creature feels about a feature: -1 (can't stand it) … +1 (loves it).
 * Types, temperament and habits decide, and what it has come to love in that yard.
 */
export function appeal(idx, c, bp) {
  const b = blueprintOf(bp);
  if (!b?.tags?.length) return 0;
  const tw = typeWords(idx, c);
  const tr = traitsOf(idx, c);
  let v = 0;
  for (const tag of b.tags) {
    if (TAG_TYPES[tag]?.test(tw)) v += 0.45;
    if (tag === 'water' && tr.noWater) v -= 0.9;
    if (tag === 'cold' && /fire|ember/.test(tw)) v -= 0.7;
    if (tag === 'sun' && tr.sunLover) v += 0.45;
    if (tag === 'sun' && tr.night) v -= 0.2;
    if (tag === 'night' && tr.night) v += 0.5;
    if ((tag === 'play' || tag === 'toy') && tr.temper === 'playful') v += 0.4;
    if (tag === 'play' && tr.temper === 'lazy') v -= 0.2;
    if (tag === 'rest' && tr.temper === 'lazy') v += 0.45;
    if (tag === 'spooky' && tr.temper === 'shy') v += 0.15;
    if (tag === 'rock' && tr.temper === 'bold') v += 0.25;
  }
  v += (c.prefs?.[`feature:${b.id}`] ?? 0) / 12;
  return Math.max(-1, Math.min(1, v / Math.max(1, b.tags.length * 0.7)));
}

/**
 * How a feature responds to who lives there (0 … 1): a pond with water creatures gets lilies,
 * a moonlit grove with night owls glows, a sun patch with grass creatures blooms.
 */
export function featureLife(idx, bp, residents) {
  const b = blueprintOf(bp);
  if (!b) return 0;
  const fans = residents.filter((c) => !c.egg && appeal(idx, c, bp) > 0.35).length;
  return Math.min(1, fans / 3);
}

/**
 * Who thrives in this yard: [{ uid, name, score (-1…1), label, reasons: [text] }], best first,
 * and pairs that do well together: [{ a, b, why }].
 */
export function thriveReport(idx, save, key, residents) {
  const build = yardBuild(save, key);
  const biome = key === 'ranch' ? save.ranch?.biome : save.boxes[key]?.biome;
  const rows = [];
  for (const c of residents) {
    if (c.egg) continue;
    const sp = idx.species.get(c.speciesId);
    const reasons = [];
    let s = 0;
    if (sp && likesHabitat(idx, sp, biome)) { s += 0.35; reasons.push('feels at home in this environment'); }
    const feats = build.features.map((f) => ({ f, a: appeal(idx, c, f.bp) }));
    const loved = feats.filter((x) => x.a > 0.35), hated = feats.filter((x) => x.a < -0.35);
    for (const x of loved.slice(0, 2)) reasons.push(`loves the ${blueprintOf(x.f.bp)?.name.toLowerCase()}`);
    for (const x of hated.slice(0, 2)) reasons.push(`doesn’t like the ${blueprintOf(x.f.bp)?.name.toLowerCase()}`);
    s += Math.min(0.5, loved.length * 0.2) - hated.length * 0.25;
    const pals = friendsOf(c).filter((f) => residents.some((r) => r.uid === f.uid));
    if (pals.length) { s += Math.min(0.3, pals.length * 0.15); reasons.push(`has ${pals.length === 1 ? 'a friend' : `${pals.length} friends`} here`); }
    const m = mood(c).id;
    if (m === 'happy') s += 0.1; else if (m === 'upset' || m === 'bored') s -= 0.15;
    if (!build.features.length && !pals.length) reasons.push('would like something to do here');
    s = Math.max(-1, Math.min(1, s));
    rows.push({ uid: c.uid, name: displayName(idx, c), score: s, label: s >= 0.5 ? 'Thriving' : s >= 0.2 ? 'Happy' : s >= -0.1 ? 'Settled' : 'Uneasy', reasons });
  }
  rows.sort((a, b) => b.score - a.score);
  const pairs = [];
  const live = residents.filter((c) => !c.egg);
  for (let i = 0; i < live.length; i++) for (let j = i + 1; j < live.length; j++) {
    const a = live[i], b = live[j];
    const bond = a.bonds?.[b.uid] ?? 0;
    const sim = similarity(idx, a, b);
    if (bond >= 60) pairs.push({ a: displayName(idx, a), b: displayName(idx, b), why: 'best of friends', score: 2 + bond / 100 });
    else if (sim.score >= 4) pairs.push({ a: displayName(idx, a), b: displayName(idx, b), why: sim.reasons.slice(0, 2).join(', ') || 'a lot alike', score: sim.score / 10 });
  }
  pairs.sort((p, q) => q.score - p.score);
  return { rows, pairs: pairs.slice(0, 6) };
}

/**
 * Time in a yard with things they love: a little joy, and their liking for those things grows.
 * Call with the hours that passed (tickAll does).
 */
export function tickYards(idx, save, hours, t = Date.now()) {
  if (!(hours > 0)) return;
  const groups = new Map();
  for (const c of Object.values(save.creatures ?? {})) {
    if (c.egg) continue;
    const key = c.location?.kind === 'box' ? c.location.box : c.location?.kind === 'ranch' ? 'ranch' : null;
    if (key == null) continue;
    (groups.get(key) ?? groups.set(key, []).get(key)).push(c);
  }
  for (const [key, members] of groups) {
    const feats = (key === 'ranch' ? save.ranch?.build?.features : save.boxes[key]?.build?.features) ?? [];
    if (!feats.length) continue;
    const rng = createRng(`${key}:${Math.floor(t / 3600000)}`);
    for (const c of members) {
      let best = null;
      for (const f of feats) { const a = appeal(idx, c, f.bp); if (!best || a > best.a) best = { f, a }; }
      if (!best || !c.needs) continue;
      c.needs.joy = Math.max(0, Math.min(100, c.needs.joy + best.a * Math.min(6, hours) * 1.5));
      if (best.a > 0.2 && rng() < Math.min(1, hours / 4)) experience(c, [`feature:${best.f.bp}`], 4 + best.a * 4, { t, label: `an afternoon at the ${blueprintOf(best.f.bp)?.name.toLowerCase()}`, coreChance: 0.004 });
    }
  }
}

// ---------- the Link gate: yards side by side ----------
/**
 * A snapshot of a yard to take to a friend (a .clranch file for now; later it could go through a
 * server). Only what's needed to show your creatures there: no stats, no memories.
 */
export function ranchSnapshot(idx, save, key, residents) {
  const owner = key === 'ranch' ? save.ranch : save.boxes[key];
  return {
    kind: 'capsule-link-ranch', v: 1, at: Date.now(),
    trainer: { name: save.trainer?.name ?? 'Trainer', id: save.trainer?.id ?? '', code: save.trainer?.card?.number ?? '' },
    yard: { name: owner?.name ?? 'Yard', biome: owner?.biome ?? 'meadow', size: owner?.build?.size ?? 0, features: (owner?.build?.features ?? []).map(({ bp, x, z }) => ({ bp, x, z })) },
    creatures: residents.filter((c) => !c.egg).slice(0, 30).map((c) => {
      const sp = idx.species.get(c.speciesId);
      return { uid: c.uid, speciesId: c.speciesId, formId: c.formId ?? null, species: sp?.name ?? c.speciesId, no: sp?.no ?? 0, nickname: c.nickname ?? '', name: displayName(idx, c), level: c.level, shiny: !!c.shiny, sizeScalar: c.sizeScalar ?? null, temper: c.temper ?? null, types: sp?.types ?? [] };
    }),
  };
}
/** Read a friend's yard snapshot. Returns { ok, snap, missing: [species they have that you don't] }. */
export function readSnapshot(idx, text) {
  let snap;
  try { snap = typeof text === 'string' ? JSON.parse(text) : text; } catch { return { ok: false, reason: 'That isn’t a ranch file.' }; }
  if (snap?.kind !== 'capsule-link-ranch' || !Array.isArray(snap.creatures)) return { ok: false, reason: 'That isn’t a ranch file.' };
  const missing = [...new Set(snap.creatures.filter((g) => !idx.species.has(g.speciesId)).map((g) => g.species || g.speciesId))];
  return { ok: true, snap, missing };
}
