// The bag in a battle: which of your items can be used mid-battle, and what each does. Consumables only
// (medicine, drinks, status heals, revives, PP restorers, X items, berries eaten from the bag); things that
// only work when held aren't here (give those to someone to hold before the battle), and there are no balls.
import { itemInfo } from './shop.js';
import { healingOf } from './wildBattle.js';

const nm = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
// the games' battle-usable items by name (Gen 9 values): what they heal or raise
const BY_NAME = {
  'potion': { hp: 20 }, 'super potion': { hp: 60 }, 'hyper potion': { hp: 120 }, 'max potion': { full: true }, 'full restore': { full: true, cure: true, confusion: true },
  'fresh water': { hp: 30 }, 'soda pop': { hp: 50 }, 'lemonade': { hp: 70 }, 'moomoo milk': { hp: 100 }, 'energy powder': { hp: 60 }, 'energy root': { hp: 120 },
  'berry juice': { hp: 20 }, 'sweet heart': { hp: 20 },
  'antidote': { cure: 'psn' }, 'paralyze heal': { cure: 'par' }, 'parlyz heal': { cure: 'par' }, 'burn heal': { cure: 'brn' }, 'ice heal': { cure: 'frz' }, 'awakening': { cure: 'slp' },
  'full heal': { cure: true, confusion: true }, 'heal powder': { cure: true }, 'lava cookie': { cure: true, confusion: true }, 'old gateau': { cure: true, confusion: true },
  'casteliacone': { cure: true, confusion: true }, 'lumiose galette': { cure: true, confusion: true }, 'shalour sable': { cure: true, confusion: true }, 'rage candy bar': { cure: true, confusion: true },
  'big malasada': { cure: true, confusion: true }, 'pewter crunchies': { cure: true, confusion: true }, 'jubilife muffin': { cure: true, confusion: true },
  'revive': { revive: 0.5 }, 'max revive': { revive: 1 }, 'revival herb': { revive: 1 },
  'ether': { pp: 10, one: true }, 'max ether': { pp: 99, one: true }, 'elixir': { pp: 10 }, 'max elixir': { pp: 99 },
  'x attack': { boost: { atk: 2 } }, 'x defense': { boost: { def: 2 } }, 'x defend': { boost: { def: 2 } }, 'x sp atk': { boost: { spa: 2 } }, 'x special': { boost: { spa: 2 } },
  'x sp def': { boost: { spd: 2 } }, 'x speed': { boost: { spe: 2 } }, 'x accuracy': { boost: { accuracy: 2 } }, 'dire hit': { crit: true }, 'guard spec': { mist: true },
  'oran berry': { hp: 10 }, 'sitrus berry': { frac: 0.25 }, 'leppa berry': { pp: 10, one: true }, 'lum berry': { cure: true, confusion: true }, 'persim berry': { confusion: true },
  'cheri berry': { cure: 'par' }, 'chesto berry': { cure: 'slp' }, 'pecha berry': { cure: 'psn' }, 'rawst berry': { cure: 'brn' }, 'aspear berry': { cure: 'frz' },
  'figy berry': { frac: 0.33 }, 'wiki berry': { frac: 0.33 }, 'mago berry': { frac: 0.33 }, 'aguav berry': { frac: 0.33 }, 'iapapa berry': { frac: 0.33 },
};
const STATUS_WORD = { psn: 'poison', tox: 'poison', par: 'paralysis', brn: 'a burn', frz: 'freezing', slp: 'sleep' };

/** What using this item in a battle does, or null if it can't be used there. */
export function battleUseOf(item) {
  if (!item) return null;
  if (item.kind === 'held' || item.kind === 'clothes' || item.kind === 'valuable' || item.kind === 'incense' || /\bball$/i.test(item.name ?? '')) return null;
  const known = BY_NAME[nm(item.name).replace(/\./g, '')] ?? BY_NAME[nm(item.showdownName)];
  if (known) return known;
  const h = healingOf(item);
  if (!h) return null;
  const out = {};
  if (h.hp) { if (h.hp > 999) out.full = true; else out.hp = h.hp; }
  if (h.frac) out.frac = h.frac;
  if (h.cure) out.cure = h.cure;
  if (h.revive) out.revive = h.revive;
  if (h.pp) { out.pp = h.pp; if (h.one) out.one = true; }
  return Object.keys(out).length ? out : null;
}

/** The bag for a battle: [{ id, name, count, use, desc, needsMove, target: 'active'|'any'|'fainted' }] */
export function battleBag(idx, save) {
  const out = [];
  for (const [id, n] of Object.entries(save?.inventory ?? {})) {
    if (!(n > 0)) continue;
    const item = itemInfo(idx, id) ?? idx?.items?.get?.(id);
    const use = battleUseOf(item);
    if (!use) continue;
    out.push({ id, name: item.name, count: n, use, desc: describeUse(use), needsMove: !!(use.pp && use.one), target: use.revive ? 'fainted' : use.boost || use.crit || use.mist ? 'active' : 'any' });
  }
  const order = (b) => (b.use.hp || b.use.full || b.use.frac ? 0 : b.use.cure || b.use.confusion ? 1 : b.use.revive ? 2 : b.use.pp ? 3 : 4);
  return out.sort((a, b) => order(a) - order(b) || a.name.localeCompare(b.name));
}

export function describeUse(u) {
  const bits = [];
  if (u.full) bits.push('Restores all HP'); else if (u.hp) bits.push(`Restores ${u.hp} HP`); else if (u.frac) bits.push(`Restores ${Math.round(u.frac * 100)}% of HP`);
  if (u.cure === true) bits.push('cures any status'); else if (u.cure) bits.push(`cures ${STATUS_WORD[u.cure] ?? u.cure}`);
  if (u.confusion) bits.push(u.cure ? 'and confusion' : 'Snaps it out of confusion');
  if (u.revive) bits.push(`Revives a fainted one with ${u.revive >= 1 ? 'all' : 'half'} its HP`);
  if (u.pp) bits.push(`${u.pp > 98 ? 'Restores all PP' : `Restores ${u.pp} PP`} ${u.one ? 'to one move' : 'to every move'}`);
  if (u.boost) { const [k, v] = Object.entries(u.boost)[0]; bits.push(`Raises ${{ atk: 'Attack', def: 'Defense', spa: 'Sp. Atk', spd: 'Sp. Def', spe: 'Speed', accuracy: 'accuracy' }[k]} by ${v} stages`); }
  if (u.crit) bits.push('Makes critical hits much more likely');
  if (u.mist) bits.push('Stops its stats being lowered for 5 turns');
  return bits.join(', ').replace(/^./, (x) => x.toUpperCase()) + '.';
}

/**
 * Would it do anything for this creature right now? mon: { hp, maxhp, status, fainted, confused, moves: [{ pp, maxpp }] }
 * → null when it would, else the reason it wouldn't (the games' "It won't have any effect.").
 */
export function whyNoEffect(use, mon, moveIndex = null) {
  if (!mon) return 'Nobody to use it on.';
  if (use.revive) return mon.fainted ? null : `${mon.name} hasn’t fainted.`;
  if (mon.fainted) return `${mon.name} has fainted.`;
  let does = false;
  if ((use.hp || use.full || use.frac) && mon.hp < mon.maxhp) does = true;
  if (use.cure && mon.status && (use.cure === true || use.cure === mon.status || (use.cure === 'psn' && mon.status === 'tox'))) does = true;
  if (use.confusion && mon.confused) does = true;
  if (use.pp) { const list = use.one ? [mon.moves?.[moveIndex ?? -1]].filter(Boolean) : mon.moves ?? []; if (list.some((m) => m.pp < m.maxpp)) does = true; }
  if (use.boost || use.crit || use.mist) does = true;
  return does ? null : 'It won’t have any effect.';
}
