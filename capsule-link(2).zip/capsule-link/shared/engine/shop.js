// The shop: a stock that changes every day (berries, battle items, dress-up clothes and incense),
// paid for with coins earned by walking and battling.
//   save.wallet          coins
//   save.shop            { day, bought: { id: n } }   today's purchases (stock is limited)
//   save.incense         { type, until, name }        lit on the phone: that type turns up more on walks
//   c.clothes            [{ id, fx, fy, s }]           worn clothes, placed on the sprite (fractions of its box)
import { isTm, tmInfo, tmsForShop } from './teamEdit.js';
import { createRng, hashString } from './rng.js';
import { todayKey } from './creature.js';
import { blueprintItem } from './ranchBuild.js';
import { DISHES } from './activities.js';
import { FOSSILS } from './fossils.js';
import { evolutionItems } from './transform.js';

/** Coins for walking (per step) and battles. */
export const EARN = { perSteps: 25, battleWin: 40, battleLoss: 10, linkWin: 60 };

/** Dress-up clothes: small pictures placed anywhere on a creature. art = the picture's shape. */
export const CLOTHES = [
  { id: 'bow', name: 'Ribbon Bow', art: 'bow', color: '#ff5d8f' },
  { id: 'tophat', name: 'Top Hat', art: 'tophat', color: '#3b3550' },
  { id: 'cap', name: 'Sports Cap', art: 'cap', color: '#4a7dff' },
  { id: 'scarf', name: 'Knit Scarf', art: 'scarf', color: '#e5484d' },
  { id: 'specs', name: 'Round Specs', art: 'specs', color: '#2a2a3a' },
  { id: 'shades', name: 'Sunglasses', art: 'shades', color: '#1b1b28' },
  { id: 'flower', name: 'Hair Flower', art: 'flower', color: '#ffd23f' },
  { id: 'crown', name: 'Tiny Crown', art: 'crown', color: '#ffc93c' },
  { id: 'bandana', name: 'Bandana', art: 'bandana', color: '#3fb26a' },
  { id: 'starpin', name: 'Star Pin', art: 'star', color: '#ffe27a' },
  { id: 'bellcollar', name: 'Bell Collar', art: 'bell', color: '#c0306a' },
  { id: 'witchhat', name: 'Pointy Hat', art: 'witchhat', color: '#5a3a8a' },
  { id: 'beanie', name: 'Beanie', art: 'beanie', color: '#ff8a3d' },
  { id: 'headphones', name: 'Headphones', art: 'headphones', color: '#7db8ff' },
  { id: 'monocle', name: 'Monocle', art: 'monocle', color: '#ffc93c' },
  { id: 'heartclip', name: 'Heart Clip', art: 'heart', color: '#ff4f86' },
  { id: 'beret', name: 'Beret', art: 'beret', color: '#c0306a' },
  { id: 'bowtie', name: 'Bow Tie', art: 'bowtie', color: '#e5484d' },
  { id: 'tiara', name: 'Tiara', art: 'tiara', color: '#7ad6ff' },
  { id: 'partyhat', name: 'Party Hat', art: 'partyhat', color: '#ff5d8f' },
  { id: 'santahat', name: 'Winter Hat', art: 'santahat', color: '#e5484d' },
  { id: 'earmuffs', name: 'Earmuffs', art: 'earmuffs', color: '#ffb0d6' },
  { id: 'goggles', name: 'Goggles', art: 'goggles', color: '#ff8a3d' },
  { id: 'cowboy', name: 'Ranch Hat', art: 'cowboy', color: '#a0703c' },
  { id: 'halo', name: 'Halo', art: 'halo', color: '#ffe27a' },
  { id: 'antlers', name: 'Toy Antlers', art: 'antlers', color: '#8a5a34' },
  { id: 'cape', name: 'Little Cape', art: 'cape', color: '#5a3a8a' },
  { id: 'necklace', name: 'Pearl Necklace', art: 'necklace', color: '#f4f0ff' },
  { id: 'leaf', name: 'Leaf Pin', art: 'leaf', color: '#5cbf4a' },
  { id: 'sweatband', name: 'Sweatband', art: 'sweatband', color: '#4a7dff' },
].map((c) => ({ ...c, id: `clothes-${c.id}`, kind: 'clothes', desc: 'Dress-up. Put it on anyone in the R.A.N.C.H. (they grow to like what you give them).' }));
// colour variants of the pieces that come in more than one colour
const VARIANTS = { red: '#e5484d', blue: '#4a7dff', green: '#3fb26a', yellow: '#ffd23f', pink: '#ff5d8f', purple: '#8a5ad6', black: '#2a2a3a', white: '#f2f0f8', orange: '#ff8a3d', teal: '#2bc4b4' };
const RECOLOUR = ['bow', 'cap', 'scarf', 'bandana', 'beanie', 'beret', 'bowtie', 'partyhat', 'earmuffs', 'cape', 'sweatband', 'witchhat', 'tophat', 'headphones', 'santahat'];
for (const base of RECOLOUR) {
  const b0 = CLOTHES.find((c) => c.id === `clothes-${base}`);
  if (!b0) continue;
  for (const [cn, hex] of Object.entries(VARIANTS)) {
    if (hex.toLowerCase() === b0.color.toLowerCase()) continue;
    CLOTHES.push({ ...b0, id: `${b0.id}-${cn}`, name: `${b0.name} (${cn})`, color: hex, variantOf: b0.id });
  }
}

/**
 * Items held in battle. Names are your own: set "showdownName" in the Data Lab to the item's name in
 * the battle simulator if you want it to work there too (until then it is only for show).
 */
export const HELD = [
  { id: 'held-snack', name: 'Snack Pouch', desc: 'Nibbles a little back each turn.' },
  { id: 'held-band', name: 'Brawn Band', desc: 'Hits harder, but sticks to one move.' },
  { id: 'held-scarf', name: 'Swift Scarf', desc: 'Moves first, but sticks to one move.' },
  { id: 'held-specs', name: 'Clever Specs', desc: 'Special moves hit harder, but sticks to one move.' },
  { id: 'held-charm', name: 'Focus Charm', desc: 'Hangs on with a sliver of health once.' },
  { id: 'held-gem', name: 'Life Gem', desc: 'Every hit is stronger; costs a little health.' },
  { id: 'held-vest', name: 'Sturdy Vest', desc: 'Takes special hits better.' },
  { id: 'held-claw', name: 'Lucky Claw', desc: 'Sometimes gets to move first.' },
  { id: 'held-boots', name: 'Trail Boots', desc: 'Ignores traps on the ground.' },
  { id: 'held-berry', name: 'Pocket Berry', desc: 'Eats it when health runs low.' },
].map((h) => ({ ...h, kind: 'held', showdownName: '' }));
// the games' power items: held while training, effort goes into one stat (and nowhere else)
export const POWER_ITEMS = [
  { id: 'power-weight', name: 'Power Weight', stat: 'hp', drills: ['swipe'] },
  { id: 'power-bracer', name: 'Power Bracer', stat: 'atk', drills: ['moves', 'smash'] },
  { id: 'power-belt', name: 'Power Belt', stat: 'def', drills: ['smash'] },
  { id: 'power-lens', name: 'Power Lens', stat: 'spa', drills: ['moves'] },
  { id: 'power-band', name: 'Power Band', stat: 'spd', drills: ['swipe'] },
  { id: 'power-anklet', name: 'Power Anklet', stat: 'spe', drills: ['dodge'] },
].map((p) => ({ ...p, kind: 'held', showdownName: p.name, price: 600, desc: `Held while training, all the effort goes into ${{ hp: 'HP', atk: 'Attack', def: 'Defence', spa: 'Sp. Atk', spd: 'Sp. Def', spe: 'Speed' }[p.stat]}. Training without one is just for fun and coins.` }));
HELD.push(...POWER_ITEMS);
/** The power item someone is holding (theirs or one of the data set's with the same name), else null. */
export function powerItemOf(idx, c) {
  const id = c?.heldItemId;
  if (!id) return null;
  const own = POWER_ITEMS.find((p) => p.id === id);
  if (own) return own;
  const name = String(idx?.items?.get?.(id)?.name ?? c.heldItem ?? '').toLowerCase();
  return POWER_ITEMS.find((p) => p.name.toLowerCase() === name) ?? null;
}

// medicine: what each heals (also found by name in your data set's items)
export const MEDICINE = [
  { id: 'med-potion', name: 'Potion', hp: 20, price: 80 }, { id: 'med-super-potion', name: 'Super Potion', hp: 60, price: 200 },
  { id: 'med-hyper-potion', name: 'Hyper Potion', hp: 120, price: 400 }, { id: 'med-max-potion', name: 'Max Potion', hp: 9999, price: 700 },
  { id: 'med-full-restore', name: 'Full Restore', hp: 9999, cure: true, price: 900 }, { id: 'med-full-heal', name: 'Full Heal', cure: true, price: 150 },
  { id: 'med-revive', name: 'Revive', revive: 0.5, price: 500 }, { id: 'med-ether', name: 'Ether', pp: 10, one: true, price: 300 },
  { id: 'med-max-ether', name: 'Max Ether', pp: 99, one: true, price: 600 }, { id: 'med-elixir', name: 'Elixir', pp: 10, price: 800 }, { id: 'med-max-elixir', name: 'Max Elixir', pp: 99, price: 1200 },
  // first aid for Quality time: put on by hand (a bit gentler and cheaper than the battle medicines)
  { id: 'care-bandage', name: 'Bandage', frac: 0.3, price: 60, care: true, hint: 'Wrap a sore spot: heals a third of their HP.' },
  { id: 'care-burn-cream', name: 'Burn Cream', cure: 'brn', frac: 0.1, price: 90, care: true, hint: 'Soothes a burn away.' },
  { id: 'care-antidote-salve', name: 'Antidote Salve', cure: 'psn', frac: 0.1, price: 90, care: true, hint: 'Draws the poison out.' },
  { id: 'care-cold-pack', name: 'Cold Pack', cure: 'par', frac: 0.15, price: 90, care: true, hint: 'Eases the stiffness of paralysis.' },
  { id: 'care-warm-pack', name: 'Warm Pack', cure: 'frz', frac: 0.15, price: 90, care: true, hint: 'Thaws them out.' },
  { id: 'care-herbal-poultice', name: 'Herbal Poultice', cure: true, frac: 0.5, price: 260, care: true, hint: 'Heals half their HP and cures any condition.' },
].map((m) => ({ ...m, kind: 'medicine', showdownName: '', desc: [m.hp ? (m.hp > 999 ? 'Restores all HP' : `Restores ${m.hp} HP`) : '', m.revive ? 'Revives a fainted creature with half its HP' : '', m.pp ? `${m.pp > 98 ? 'Restores all PP' : `Restores ${m.pp} PP`} ${m.one ? 'to one move' : 'to every move'}` : '', m.cure ? 'cures any status' : ''].filter(Boolean).join(', ').replace(/^./, (x) => x.toUpperCase()) + '. Healing happens by itself over time too; this just speeds it up.' }));

const PRICE = { food: 30, held: 300, clothes: 140, incense: 160 };

/** Shiny things your creatures turn up on walks: worth nothing to them, good coins at the market. */
export const VALUABLES = [
  { id: 'val-stardust', name: 'Stardust', value: 60, color: '#ffb0d6', rarity: 5, desc: 'Fine, sparkly sand. Sells for a little.' },
  { id: 'val-pearl', name: 'Pearl', value: 90, color: '#f4f0ff', rarity: 4, desc: 'A small, lustrous pearl.' },
  { id: 'val-star-piece', name: 'Star Piece', value: 250, color: '#ff8a8a', rarity: 2, desc: 'A shard of a pretty gem. Sells well.' },
  { id: 'val-nugget', name: 'Gold Nugget', value: 400, color: '#ffd23f', rarity: 2, desc: 'A lump of pure gold.' },
  { id: 'val-big-pearl', name: 'Big Pearl', value: 450, color: '#e9e4ff', rarity: 1, desc: 'A large, gleaming pearl.' },
  { id: 'val-big-nugget', name: 'Big Nugget', value: 1200, color: '#ffc21a', rarity: 0.3, desc: 'A big lump of gold. A rare find!' },
].map((v) => ({ ...v, kind: 'valuable' }));

/** An incense for a type: held, that type's moves are 1.2× as strong; lit (on a walk), that type turns up more. */
export const incenseId = (typeId) => `incense-${typeId}`;
// the games' own incenses, and the type each one is for
export const REAL_INCENSE = { sea: 'water', wave: 'water', rock: 'rock', rose: 'grass', odd: 'psychic' };
// battle items that do exactly the same thing when held (1.2× that type's moves): what Showdown is told
export const TYPE_BOOSTER = { normal: 'Silk Scarf', fire: 'Charcoal', water: 'Mystic Water', electric: 'Magnet', grass: 'Miracle Seed', ice: 'Never-Melt Ice', fighting: 'Black Belt', poison: 'Poison Barb', ground: 'Soft Sand', flying: 'Sharp Beak', psychic: 'Twisted Spoon', bug: 'Silver Powder', rock: 'Hard Stone', ghost: 'Spell Tag', dragon: 'Dragon Fang', dark: 'Black Glasses', steel: 'Metal Coat', fairy: 'Fairy Feather' };
const typeByName = (idx, name) => [...(idx?.types?.values?.() ?? [])].find((t) => String(t.name ?? t.id).toLowerCase() === name || t.id === name) ?? null;
/** The type an incense is for (a made one, or one of the games' own like Sea Incense), else null. */
export function incenseType(idx, item) {
  if (!item) return null;
  if (item.kind === 'incense') return item.type ?? null;
  const m = /^(\w+)\s+incense$/i.exec(String(item.name ?? ''));
  const tn = m && REAL_INCENSE[m[1].toLowerCase()];
  if (!tn) return null;
  return typeByName(idx, tn)?.id ?? (idx ? null : tn);
}
/** Lightable: every type incense, the games' own included. */
export const isIncense = (item) => !!item && (item.kind === 'incense' || !!REAL_INCENSE[String(/^(\w+)\s+incense$/i.exec(String(item.name ?? ''))?.[1] ?? '').toLowerCase()]);
export function incenseItems(idx) {
  // types that already have one of the games' own incenses use that one instead
  const real = new Set((idx.ds?.items ?? []).map((i) => incenseType(idx, i)).filter(Boolean));
  return [...(idx.types?.values?.() ?? [])].filter((t) => !real.has(t.id)).map((t) => ({
    id: incenseId(t.id), name: `${t.name} Incense`, kind: 'incense', type: t.id, color: t.color, hold: true,
    showdownName: TYPE_BOOSTER[String(t.name ?? t.id).toLowerCase()] ?? '', boost: 1.2,
    desc: `When being held: ${t.name}-type moves are 1.2× as strong.`,
    pairDesc: `Or light it (on a walk with your phone, or from the bag): ${t.name}-type creatures turn up more on walks for an hour.`,
  }));
}

/** Any item by id: the dataset's own, then the shop's clothes, battle items and incense. */
export function itemInfo(idx, id) {
  if (!id) return null;
  const own = idx.items?.get?.(id);
  if (own) return own;
  const c = CLOTHES.find((x) => x.id === id) ?? HELD.find((x) => x.id === id) ?? MEDICINE.find((x) => x.id === id) ?? VALUABLES.find((x) => x.id === id) ?? DISHES.find((x) => x.id === id) ?? FOSSILS.find((x) => x.id === id) ?? (String(id).startsWith('evo-') ? evolutionItems(idx).find((x) => x.id === id) : null);
  if (c) return c;
  if (String(id).startsWith('bp-')) return blueprintItem(id);
  if (String(id).startsWith('incense-')) return incenseItems(idx).find((x) => x.id === id) ?? null;
  if (isTm(id)) return tmInfo(idx, id);
  return null;
}
/** Every food: the data set's, and dishes cooked in Activities. */
export function allFoods(idx) { return [...(idx.ds?.items ?? []).filter((i) => i.kind === 'food'), ...DISHES]; }
/** Every clothing item, the dataset's own included. */
export function allClothes(idx) { return [...CLOTHES, ...(idx.ds?.items ?? []).filter((i) => i.kind === 'clothes')]; }

// ---------- one item, several uses ----------
// Items aren't split into "battle items", "incense" and so on: one berry can be eaten, planted or held;
// one incense can be held in battle or lit on a walk. The description says each way it can be used.
const BERRY_HOLD = 'Or when being held: eats it in battle when its health runs low.';
/** Can a creature hold this item (in battle)? */
export function holdable(item) {
  if (!item) return false;
  return item.kind === 'held' || !!item.hold || (item.kind === 'food' && (!!item.grow || /berry/i.test(item.name ?? '')) && !item.unlimited);
}
/** Every way an item can be used: ['feed', 'plant', 'hold', 'light', 'wear', 'toy', 'groom', 'build', 'sell']. */
export function itemUses(item) {
  if (!item) return [];
  const u = [];
  if (item.kind === 'food') u.push('feed');
  if (item.kind === 'food' && item.grow) u.push('plant');
  if (holdable(item)) u.push('hold');
  if (isIncense(item)) u.push('light');
  if (item.kind === 'clothes') u.push('wear');
  if (item.kind === 'toy') u.push('toy');
  if (item.kind === 'groom') u.push('groom');
  if (item.kind === 'blueprint') u.push('build');
  if (!item.unlimited && item.kind !== 'blueprint' && item.kind !== 'fossil') u.push('sell');
  return u;
}
/** The full description, with the other ways it can be used ("Or when being held…"). */
export function itemDesc(item) {
  if (!item) return '';
  const parts = [item.desc ?? ''];
  if (item.kind === 'incense' && item.pairDesc) parts.push(item.pairDesc);
  else if (isIncense(item)) parts.push('Or light it (on a walk with your phone, or from the bag): creatures of its type turn up more on walks for an hour.');
  // only items that really exist in battles (a Showdown item name set in the Data Lab) say they do anything there
  else if (item.kind === 'food' && holdable(item) && item.kind !== 'held' && (item.holdDesc || item.showdownName)) parts.push(item.holdDesc ?? BERRY_HOLD);
  else if (item.kind === 'held' && item.pairDesc) parts.push(item.pairDesc);
  return parts.filter(Boolean).join(' ');
}
/** What the market pays for one (valuables: their worth; everything else: about half what it costs). */
export function sellPrice(item) {
  if (!item || item.unlimited || item.kind === 'blueprint') return 0;
  if (item.kind === 'valuable') return item.value;
  const base = item.price ?? (item.kind === 'food' ? PRICE.food + (item.grow?.hours ?? 2) * 8 : PRICE[item.kind] ?? 20);
  return Math.max(1, Math.floor(base / 2));
}
/** Sell n of an item from the bag (clothes someone is wearing stay). */
export function sell(idx, save, id, n = 1) {
  const item = itemInfo(idx, id);
  const price = sellPrice(item);
  if (!price) return { ok: false, reason: 'The market doesn’t buy that.' };
  let have = save.inventory[id] ?? 0;
  if (item.kind === 'clothes') have -= Object.values(save.creatures).filter((c) => (c.clothes ?? []).some((w) => w.id === id)).length;
  const k = Math.min(n, have);
  if (k <= 0) return { ok: false, reason: item.kind === 'clothes' ? 'Someone is wearing it. Take it off them first.' : 'None left to sell.' };
  save.inventory[id] -= k;
  earn(save, price * k);
  return { ok: true, count: k, coins: price * k };
}
/** Something found on a walk (rng: a seeded rng): { coins } | { item }. */
export function walkFind(idx, rng) {
  const r = rng();
  if (r < 0.4) return { coins: 3 + Math.floor(rng() * 4) * 3 + (rng() < 0.1 ? 25 : 0) };
  if (r < 0.78) {
    const foods = (idx.ds?.items ?? []).filter((i) => i.kind === 'food' && !i.unlimited);
    const other = (idx.ds?.items ?? []).filter((i) => !i.unlimited && i.kind !== 'food' && i.kind !== 'clothes' && i.kind !== 'held');
    const pool = [...foods, ...foods.filter((i) => i.grow), ...other];
    if (pool.length) return { item: pool[Math.floor(rng() * pool.length)].id };
  }
  const total = VALUABLES.reduce((a, v) => a + v.rarity, 0);
  let x = rng() * total;
  for (const v of VALUABLES) { x -= v.rarity; if (x <= 0) return { item: v.id }; }
  return { item: VALUABLES[0].id };
}

export function wallet(save) { return Math.max(0, Math.floor(save.wallet ?? 0)); }
export function earn(save, n) { save.wallet = Math.max(0, (save.wallet ?? 0) + n); return wallet(save); }

/** Today's stock. The same on every device for the same day. */
export function shopStock(idx, save, t = Date.now()) {
  const day = todayKey(t);
  const rng = createRng(hashString(`shop:${day}`));
  const pick = (list, n) => { const pool = [...list]; const out = []; while (pool.length && out.length < n) out.push(pool.splice(Math.floor(rng() * pool.length), 1)[0]); return out; };
  const foods = (idx.ds?.items ?? []).filter((i) => i.kind === 'food' && !i.unlimited);
  const held = [...HELD, ...(idx.ds?.items ?? []).filter((i) => i.kind === 'held')];
  const lines = [
    ...pick(foods, 3).map((item) => ({ item, price: item.price ?? Math.round(PRICE.food + (item.grow?.hours ?? 2) * 8 + (item.joy ?? 0)), stock: 5, section: 'Berries and treats' })),
    ...pick(held, 3).map((item) => ({ item, price: item.price ?? PRICE.held + Math.floor(rng() * 4) * 50, stock: 1, section: 'Gear' })),
    ...pick(incenseItems(idx), 2).map((item) => ({ item, price: PRICE.incense, stock: 3, section: 'Gear' })),
    ...pick(allClothes(idx), 3).map((item) => ({ item, price: item.price ?? PRICE.clothes + Math.floor(rng() * 5) * 20, stock: 1, section: 'Clothes' })),
    ...tmsForShop(idx, save, rng, 2).map((item) => ({ item, price: item.price, stock: 1, section: 'TMs' })),
    ...pick(evolutionItems(idx), 3).map((item) => ({ item, price: item.price ?? 1500, stock: 2, section: 'Evolution items' })),
    // medicine: Potions every day, and a couple of others
    { item: MEDICINE[0], price: MEDICINE[0].price, stock: 10, section: 'Medicine' },
    ...pick(MEDICINE.slice(1), 3).map((item) => ({ item, price: item.price, stock: 3, section: 'Medicine' })),
  ];
  const bought = save.shop?.day === day ? save.shop.bought ?? {} : {};
  return { day, lines: lines.map((l) => ({ ...l, id: l.item.id, left: Math.max(0, l.stock - (bought[l.item.id] ?? 0)) })) };
}
/** Milliseconds until the stock changes (local midnight). */
export function shopResetIn(t = Date.now()) { const d = new Date(t); d.setHours(24, 0, 0, 0); return d.getTime() - t; }

export function buy(idx, save, id, t = Date.now()) {
  const stock = shopStock(idx, save, t);
  const line = stock.lines.find((l) => l.id === id);
  if (!line) return { ok: false, reason: 'That isn’t for sale today.' };
  if (line.left <= 0) return { ok: false, reason: 'Sold out until tomorrow.' };
  if (wallet(save) < line.price) return { ok: false, reason: `Not enough coins (${line.price} needed).` };
  save.wallet = wallet(save) - line.price;
  if (save.shop?.day !== stock.day) save.shop = { day: stock.day, bought: {} };
  save.shop.bought[id] = (save.shop.bought[id] ?? 0) + 1;
  save.inventory[id] = (save.inventory[id] ?? 0) + 1;
  return { ok: true, item: line.item, price: line.price };
}

/**
 * Put a piece of clothing on (or move it): fx, fy are where on the sprite (0..1), s its size.
 * form: the form it's being placed for (another form's sprite is a different shape, so each form can
 * keep its own placement; the first placement is used for any form that has none of its own).
 */
export function wear(save, uid, id, fx, fy, s = 1, form = null, r = 0) {
  const c = save.creatures[uid];
  if (!c) return { ok: false, reason: 'Nobody to dress.' };
  const prev = (c.clothes ?? []).find((w) => w.id === id);
  const owned = save.inventory[id] ?? 0;
  const inUse = Object.values(save.creatures).filter((x) => x.uid !== uid && (x.clothes ?? []).some((w) => w.id === id)).length;
  if (owned - inUse <= 0) return { ok: false, reason: 'Someone else is wearing it. Take it off them first, or buy another.' };
  const place = { fx: clamp01(fx), fy: clamp01(fy), s: Math.max(0.3, Math.min(3, Number(s) || 1)), r: Math.max(-180, Math.min(180, Math.round(Number(r) || 0))) };
  if (prev && form && form !== c.speciesId) { prev.at = { ...(prev.at ?? {}), [form]: place }; return { ok: true }; }
  c.clothes = (c.clothes ?? []).filter((w) => w.id !== id);
  c.clothes.push({ id, ...place, ...(prev?.at ? { at: prev.at } : {}), ...(!prev && form && form !== c.speciesId ? { at: { [form]: place } } : {}) });
  if (c.clothes.length > 4) c.clothes.shift();
  return { ok: true };
}
/** Where a worn piece sits for a form: that form's own placement, or the first one. */
export function wornAt(w, form) { const p = (form && w.at?.[form]) || { fx: w.fx, fy: w.fy, s: w.s ?? 1, r: w.r ?? 0 }; return { ...p, r: p.r ?? 0 }; }
export function unwear(save, uid, id) {
  const c = save.creatures[uid];
  if (c) c.clothes = (c.clothes ?? []).filter((w) => w.id !== id);
  return { ok: true };
}
/** Clothes in the bag that nobody is wearing right now. */
export function spareClothes(idx, save) {
  const worn = {};
  for (const c of Object.values(save.creatures)) for (const w of c.clothes ?? []) worn[w.id] = (worn[w.id] ?? 0) + 1;
  return allClothes(idx).map((item) => ({ item, owned: save.inventory[item.id] ?? 0, spare: (save.inventory[item.id] ?? 0) - (worn[item.id] ?? 0) })).filter((x) => x.owned > 0);
}
const clamp01 = (v) => Math.max(0, Math.min(1, Number(v) || 0));

/** Light an incense (from the phone): uses one, lasts an hour of walking time. */
export function lightIncense(idx, save, id, t = Date.now(), minutes = 60) {
  if ((save.inventory[id] ?? 0) <= 0) return { ok: false, reason: 'None left in the bag.' };
  const item = itemInfo(idx, id);
  const type = incenseType(idx, item);
  if (!item || !type) return { ok: false, reason: 'That isn’t incense.' };
  save.inventory[id]--;
  save.incense = { id, type, name: item.name, until: t + minutes * 60000 };
  return { ok: true, incense: save.incense };
}
export function activeIncense(save, t = Date.now()) { return save.incense && save.incense.until > t ? save.incense : null; }
