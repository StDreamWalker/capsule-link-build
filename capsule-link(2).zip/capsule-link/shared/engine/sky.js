// The real sky where you are: sunrise and sunset (worked out from a rough location, so they're right
// every day even offline), the weather and how far you can see (fog), from Open-Meteo. The phone looks
// it up on walks and sends it to the PC; the PC can also look it up itself (Settings → Where you are).
// Everything that asks "is it night?" (the R.A.N.C.H., walks, the desktop pet) goes through here.

let SKY = null; // { lat, lon (1 decimal), sunrise, sunset (ms), weather, visibility (m), temp, isDay, at }

/** Remember the sky (merged into what's known). Coordinates are kept to 1 decimal (about 10 km). */
export function setSky(s) {
  if (!s) { SKY = null; return null; }
  const r1 = (v) => (Number.isFinite(Number(v)) ? Math.round(Number(v) * 10) / 10 : undefined);
  const next = { ...(SKY ?? {}), ...s };
  if (s.lat != null) next.lat = r1(s.lat);
  if (s.lon != null) next.lon = r1(s.lon);
  if ((SKY?.at ?? 0) > (s.at ?? 0) && SKY?.weather) { next.weather = SKY.weather; next.visibility = SKY.visibility; next.at = SKY.at; }
  SKY = next;
  return SKY;
}
export function getSky() { return SKY; }

const RAD = Math.PI / 180, DAY = 86400000, J1970 = 2440588, J2000 = 2451545;
/** Sunrise and sunset (ms) on the day of t at lat, lon (the same sums the games' calendars use: NOAA's). */
export function sunTimes(t, lat, lon) {
  const lw = RAD * -lon, phi = RAD * lat, e = RAD * 23.4397;
  const days = t / DAY - 0.5 + J1970 - J2000;
  const n = Math.round(days - 0.0009 - lw / (2 * Math.PI));
  const ds = 0.0009 + lw / (2 * Math.PI) + n;
  const M = RAD * (357.5291 + 0.98560028 * ds);
  const C = RAD * (1.9148 * Math.sin(M) + 0.02 * Math.sin(2 * M) + 0.0003 * Math.sin(3 * M));
  const L = M + C + RAD * 102.9372 + Math.PI;
  const dec = Math.asin(Math.sin(L) * Math.sin(e));
  const Jnoon = J2000 + ds + 0.0053 * Math.sin(M) - 0.0069 * Math.sin(2 * L);
  const cosw = (Math.sin(RAD * -0.833) - Math.sin(phi) * Math.sin(dec)) / (Math.cos(phi) * Math.cos(dec));
  const fromJ = (j) => (j + 0.5 - J1970) * DAY;
  if (cosw > 1) return { sunrise: null, sunset: null, polar: 'night' };
  if (cosw < -1) return { sunrise: null, sunset: null, polar: 'day' };
  const w = Math.acos(cosw);
  const Jset = J2000 + 0.0009 + (w + lw) / (2 * Math.PI) + n + 0.0053 * Math.sin(M) - 0.0069 * Math.sin(2 * L);
  return { sunrise: fromJ(Jnoon - (Jset - Jnoon)), sunset: fromJ(Jset) };
}

/** Sun times for now from what's known: worked out from the location, else the last looked-up times (they barely move in a week). */
export function sunFor(t = Date.now(), sky = SKY) {
  if (!sky) return null;
  if (Number.isFinite(sky.lat) && Number.isFinite(sky.lon)) {
    const s = sunTimes(t, sky.lat, sky.lon);
    if (s.polar) return { isDay: s.polar === 'day' };
    return s;
  }
  if (sky.sunrise && sky.sunset && t - (sky.at ?? 0) < 14 * DAY) return { sunrise: sky.sunrise, sunset: sky.sunset };
  return null;
}

/** Open-Meteo weather code → our weather word (sun, clear, clouds, rain, storm, snow, fog, wind). */
export function weatherWord(code, wind = 0, visibility = null) {
  if (code >= 95) return 'storm';
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return 'snow';
  if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return 'rain';
  if (code === 45 || code === 48 || (visibility != null && visibility < 1000)) return 'fog';
  if (wind >= 35) return 'wind';
  if (code >= 2) return 'clouds';
  return 'sun';
}
export const METEO = 'https://api.open-meteo.com/v1/forecast';
export function meteoUrl(lat, lon) {
  return `${METEO}?latitude=${Number(lat).toFixed(2)}&longitude=${Number(lon).toFixed(2)}&current=temperature_2m,relative_humidity_2m,weather_code,is_day,wind_speed_10m,visibility&daily=sunrise,sunset&forecast_days=1&timezone=auto&timeformat=unixtime`;
}
/** Open-Meteo's answer → a sky. */
export function skyFromMeteo(j, lat, lon, t = Date.now()) {
  const cur = j?.current ?? {}, daily = j?.daily ?? {};
  const vis = Number.isFinite(cur.visibility) ? cur.visibility : null;
  let weather = weatherWord(cur.weather_code ?? 0, cur.wind_speed_10m ?? 0, vis);
  const isDay = cur.is_day === 1;
  if (!isDay && weather === 'sun') weather = 'clear';
  return { lat, lon, at: t, weather, visibility: vis, isDay, temp: Number.isFinite(cur.temperature_2m) ? Math.round(cur.temperature_2m) : null,
    sunrise: daily.sunrise?.[0] ? daily.sunrise[0] * 1000 : null, sunset: daily.sunset?.[0] ? daily.sunset[0] * 1000 : null };
}
/** The R.A.N.C.H.'s weather for the real sky ('clear', 'cloudy', 'rain', 'storm', 'snow', 'fog', 'windy'), or null if it's out of date. */
let FIX = null;
/** The hand correction (settings.skyFix) applies to the R.A.N.C.H. and walks too: each app sets it from its settings. */
export function setSkyFix(f) { FIX = f ?? null; }
export function activeSkyFix(t = Date.now()) { return FIX && (!FIX.until || FIX.until > t) ? FIX : null; }
export function yardWeather(sky = SKY, t = Date.now()) {
  const fx = sky === SKY ? activeSkyFix(t) : null;
  if (fx?.weather) return fx.weather;
  if (!sky?.weather || t - (sky.at ?? 0) > 3 * 3600000) return null;
  if (sky.visibility != null && sky.visibility < 1000) return 'fog';
  return { sun: 'clear', clear: 'clear', clouds: 'cloudy', rain: 'rain', storm: 'storm', snow: 'snow', fog: 'fog', wind: 'windy' }[sky.weather] ?? 'clear';
}
/** The sky as it's saved (and sent from the phone): no exact position. */
export function skyRecord(s) {
  if (!s) return null;
  const r1 = (v) => (Number.isFinite(Number(v)) ? Math.round(Number(v) * 10) / 10 : null);
  return { lat: r1(s.lat), lon: r1(s.lon), sunrise: s.sunrise ?? null, sunset: s.sunset ?? null, weather: s.weather ?? null, visibility: s.visibility ?? null, temp: s.temp ?? null, isDay: s.isDay ?? null, at: s.at ?? Date.now() };
}

// ---------- battles under the real sky ----------
// Settings → "Battles follow the real weather and time" (on unless turned off). When the sky's wrong (a sudden
// fog, rain that hasn't shown up yet, sunset earlier than it was), it can be corrected by hand for a while:
// settings.skyFix = { weather: 'rain'|…|null, tod: 'dawn'|'day'|'dusk'|'night'|null, until: ms (0 = until changed back) }
export const SKY_FIX_WEATHER = ['clear', 'cloudy', 'rain', 'storm', 'snow', 'fog', 'windy'];
export const SKY_FIX_TOD = ['dawn', 'day', 'dusk', 'night'];
/** The time of day at t: from the real sunrise and sunset when the location's known, else the clock. */
export function realTod(t = Date.now(), sky = SKY) {
  const s = sunFor(t, sky);
  if (s && s.sunrise && s.sunset) {
    const m = 45 * 60000;
    if (Math.abs(t - s.sunrise) < m) return 'dawn';
    if (Math.abs(t - s.sunset) < m) return 'dusk';
    return t > s.sunrise && t < s.sunset ? 'day' : 'night';
  }
  if (s && s.isDay != null) return s.isDay ? 'day' : 'night';
  const h = new Date(t).getHours();
  return h >= 5 && h < 7 ? 'dawn' : h >= 7 && h < 18 ? 'day' : h >= 18 && h < 20 ? 'dusk' : 'night';
}
function fixOf(settings, t) { const f = settings?.skyFix ?? FIX; return f && (!f.until || f.until > t) ? f : null; }
/**
 * The weather and time a battle starts under: { weather (the R.A.N.C.H.'s words), tod, field (a Showdown weather
 * that lasts the whole battle, as in the games' overworld weather, or null), source: 'real'|'fixed' } or null when off.
 */
export function battleSky(settings, t = Date.now(), sky = SKY) {
  if (settings?.realSkyBattles === false) return null;
  const fx = fixOf(settings, t);
  const weather = fx?.weather ?? yardWeather(sky, t) ?? 'clear';
  const tod = fx?.tod ?? realTod(t, sky);
  const temp = sky?.temp ?? null;
  const field = weather === 'rain' || weather === 'storm' ? 'RainDance' : weather === 'snow' ? 'Snowscape'
    : weather === 'clear' && tod === 'day' && temp != null && temp >= 30 ? 'SunnyDay' : null;
  return { weather, tod, field, source: fx ? 'fixed' : 'real', temp };
}
