// MemeCrypto save signing for Sun/Moon and Ultra Sun/Ultra Moon, following PKHeX
// (PKHeX.Core/Saves/Encryption/MemeCrypto: MemeCrypto.SignInPlace, MemeKey). The games sign a SHA-256 of the
// block checksum table with the "Pokédex and save file" key, whose private half is public knowledge (PKHeX ships
// it). Pure JS so it runs in the app and on the phone: SHA-1, AES-128 (encrypt only), RSA with BigInt.
import { sha256 } from './gameSaves.js';

const hex = (s) => Uint8Array.from(s.match(/../g), (b) => parseInt(b, 16));
// DER of key 3 (PokedexAndSaveFile) and its private exponent, as in MemeKey.cs
const DER = hex('307c300d06092a864886f70d0101010500036b003068026100b61e192091f90a8f76a6eaaa9a3ce58c863f39ae253f037816f5975854e07a9a456601e7c94c29759fe155c064eddfa111443f81ef1a428cf6cd32f9dac9d48e94cfb3f690120e8e6b9111addaf11e7c96208c37c0143ff2bf3d7e831141a9730203010001');
const D = BigInt('0x00775455668fff3cba3026c2d0b26b8085895958341157aeb03b6b0495ee57803e2186eb6cb2eb62a71df18a3c9c6579077670961b3a6102dabe5a194ab58c3250aed597fc78978a326db1d7b28dcccb2a3e014edbd397ad33b8f28cd525054251');
const N = BigInt('0x' + [...DER.subarray(0x18, 0x18 + 0x61)].map((b) => b.toString(16).padStart(2, '0')).join(''));

export function sha1(bytes) {
  const n = bytes.length, total = ((n + 8) >>> 6) * 64 + 64;
  const m = new Uint8Array(total); m.set(bytes); m[n] = 0x80;
  const dv = new DataView(m.buffer); dv.setUint32(total - 4, (n * 8) >>> 0); dv.setUint32(total - 8, Math.floor(n / 0x20000000));
  let h0 = 0x67452301, h1 = 0xefcdab89, h2 = 0x98badcfe, h3 = 0x10325476, h4 = 0xc3d2e1f0;
  const w = new Uint32Array(80);
  for (let o = 0; o < total; o += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
    for (let i = 16; i < 80; i++) { const x = w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]; w[i] = (x << 1) | (x >>> 31); }
    let a = h0, b = h1, c = h2, d = h3, e = h4;
    for (let i = 0; i < 80; i++) {
      const f = i < 20 ? (b & c) | (~b & d) : i < 40 ? b ^ c ^ d : i < 60 ? (b & c) | (b & d) | (c & d) : b ^ c ^ d;
      const k = i < 20 ? 0x5a827999 : i < 40 ? 0x6ed9eba1 : i < 60 ? 0x8f1bbcdc : 0xca62c1d6;
      const t = (((a << 5) | (a >>> 27)) + f + e + k + w[i]) >>> 0;
      e = d; d = c; c = (b << 30) | (b >>> 2); b = a; a = t;
    }
    h0 = (h0 + a) >>> 0; h1 = (h1 + b) >>> 0; h2 = (h2 + c) >>> 0; h3 = (h3 + d) >>> 0; h4 = (h4 + e) >>> 0;
  }
  const out = new Uint8Array(20); const ov = new DataView(out.buffer);
  [h0, h1, h2, h3, h4].forEach((v, i) => ov.setUint32(i * 4, v));
  return out;
}

// ---- AES-128, encrypt direction only ----
const SBOX = new Uint8Array(256);
(() => {
  let p = 1, q = 1;
  do {
    p = p ^ ((p << 1) & 0xff) ^ (p & 0x80 ? 0x1b : 0);
    q ^= q << 1; q ^= q << 2; q ^= q << 4; q &= 0xff; if (q & 0x80) q ^= 0x09;
    const x = q ^ ((q << 1) | (q >> 7)) ^ ((q << 2) | (q >> 6)) ^ ((q << 3) | (q >> 5)) ^ ((q << 4) | (q >> 4));
    SBOX[p] = (x ^ 0x63) & 0xff;
  } while (p !== 1);
  SBOX[0] = 0x63;
})();
const xt = (b) => ((b << 1) ^ (b & 0x80 ? 0x1b : 0)) & 0xff;
function expandKey(key) {
  const w = new Uint8Array(176); w.set(key);
  let rcon = 1;
  for (let i = 16; i < 176; i += 4) {
    let t = [w[i - 4], w[i - 3], w[i - 2], w[i - 1]];
    if (i % 16 === 0) { t = [SBOX[t[1]] ^ rcon, SBOX[t[2]], SBOX[t[3]], SBOX[t[0]]]; rcon = xt(rcon); }
    for (let j = 0; j < 4; j++) w[i + j] = w[i - 16 + j] ^ t[j];
  }
  return w;
}
export function aesEncryptBlock(rk, blk) {
  const s = new Uint8Array(16);
  for (let i = 0; i < 16; i++) s[i] = blk[i] ^ rk[i];
  for (let r = 1; r <= 10; r++) {
    const t = new Uint8Array(16);
    for (let c = 0; c < 4; c++) for (let row = 0; row < 4; row++) t[c * 4 + row] = SBOX[s[((c + row) % 4) * 4 + row]]; // SubBytes + ShiftRows
    if (r < 10) for (let c = 0; c < 4; c++) {
      const a0 = t[c * 4], a1 = t[c * 4 + 1], a2 = t[c * 4 + 2], a3 = t[c * 4 + 3], x = a0 ^ a1 ^ a2 ^ a3;
      t[c * 4] ^= x ^ xt(a0 ^ a1); t[c * 4 + 1] ^= x ^ xt(a1 ^ a2); t[c * 4 + 2] ^= x ^ xt(a2 ^ a3); t[c * 4 + 3] ^= x ^ xt(a3 ^ a0);
    }
    for (let i = 0; i < 16; i++) s[i] = t[i] ^ rk[r * 16 + i];
  }
  return s;
}
export const aesKeySchedule = expandKey;

const xor = (a, b) => { for (let i = 0; i < b.length; i++) a[i] ^= b[i]; };
function subKey(temp) {
  const k = new Uint8Array(16);
  for (let i = 0; i < 16; i += 2) {
    const b1 = temp[i], b2 = temp[i + 1];
    k[i] = (2 * b1 + (b2 >> 7)) & 0xff; k[i + 1] = (2 * b2) & 0xff;
    if (i + 2 < 16) k[i + 1] = (k[i + 1] + (temp[i + 2] >> 7)) & 0xff;
  }
  if (temp[0] & 0x80) k[15] ^= 0x87;
  return k;
}
/** MemeKey.AesEncrypt over data (payload, then a 0x60 signature area). */
function memeAesEncrypt(data) {
  const payload = data.subarray(0, data.length - 0x60), sig = data.subarray(data.length - 0x60);
  const key = sha1(Uint8Array.from([...DER, ...payload])).subarray(0, 16);
  const rk = expandKey(key);
  let temp = new Uint8Array(16);
  for (let i = 0; i < 0x60; i += 16) { const sl = sig.subarray(i, i + 16); xor(sl, temp); sl.set(aesEncryptBlock(rk, sl)); temp = sl.slice(); }
  xor(temp, sig.subarray(0, 16));
  const k = subKey(temp);
  for (let i = 0; i < 0x60; i += 16) xor(sig.subarray(i, i + 16), k);
  temp = new Uint8Array(16);
  for (let i = 0x60 - 16; i >= 0; i -= 16) { const sl = sig.subarray(i, i + 16); const next = sl.slice(); sl.set(aesEncryptBlock(rk, sl)); xor(sl, temp); temp = next; }
}
const modPow = (b, e, m) => { let r = 1n; b %= m; while (e > 0n) { if (e & 1n) r = (r * b) % m; b = (b * b) % m; e >>= 1n; } return r; };
/** Sign a 0x80-byte area in place (MemeCrypto.SignMemeDataInPlace with key 3). */
export function signMemeInPlace(area) {
  area.set(sha1(area.subarray(0, area.length - 8)).subarray(0, 8), area.length - 8);
  memeAesEncrypt(area);
  const sig = area.subarray(area.length - 0x60);
  sig[0] &= 0x7f;
  let M = 0n; for (const b of sig) M = (M << 8n) | BigInt(b);
  let r = modPow(M, D, N);
  // BigInteger.TryWriteBytes (big-endian, unsigned): the shortest form, written from the start
  const bytes = []; while (r > 0n) { bytes.unshift(Number(r & 0xffn)); r >>= 8n; }
  sig.set(bytes.slice(0, 0x60));
}
/** MemeCrypto.SignInPlace for a whole save: SHA-256 of the checksum table into the signature area, then sign it. */
export function signSaveInPlace(data, memeAt, tableAt, tableLen) {
  const area = data.subarray(memeAt, memeAt + 0x80);
  area.fill(0);
  area.set(sha256(data.subarray(tableAt, tableAt + tableLen)));
  signMemeInPlace(area);
}
export const MEME_PUBLIC = { der: DER, n: N, e: 0x10001n };
