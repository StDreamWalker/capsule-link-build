// Game Boy Advance ROM hack saves: hacks that keep their Pokémon differently from the official games, so
// PKHeX shows them as the wrong species or not at all. Checked against real saves of Pokémon Unbound,
// Emerald Seaglass and ROWE.
//
//   CFRU hacks (Complete FireRed Upgrade): Pokémon Unbound, Radical Red and others
//     · save sectors signed 0x01121999 / 0x01121998 (Unbound) or the usual 0x08012025 (Radical Red)
//     · the PC holds 58-byte "compact" records, unencrypted, packed across sectors 5–13, the spare
//       physical sectors 30 and 31, the tail of sector 2, sector 3 and part of sector 0
//       (24 boxes in Unbound, 25 in Radical Red; plus Unbound's "preset" box)
//     · party: the usual 100-byte record but unencrypted, blocks always in the order G A E M, checksum 0,
//       the ball in the growth block
//     · sector checksums over 0xFF0 bytes (sector 0: 0xF24, 13: 0x450; sector 4 isn't checked)
//   pokeemerald-expansion hacks (Emerald Seaglass and most modern Emerald hacks)
//     · the usual sectors, checksums and encryption, but the Pokémon's fields packed the expansion's
//       way (species in 11 bits, experience in 21, moves in 11, the ball in the growth block, a 2-bit
//       ability slot) and species numbered the expansion's way (Gen 1–8 by national number, then forms,
//       then Gen 9); older expansion builds keep the classic field places, and both are understood
//     · the party may sit elsewhere in the save: found by looking for it (records whose checksums agree)
//   ROWE: its own unencrypted, packed records (76 bytes in the party: PID, OT ID, nickname, experience and
//     four 10-bit moves packed together, species, OT name, PP, then the party stats). Its PC layout isn't
//     known yet (no example with Pokémon in the PC), so only the party is read, and nothing is written.
//
// Species and moves go through tables to national numbers (romhackData.js), and back when writing.
// Every record is checked before it's believed. Unbound, Radical Red and expansion saves can take
// Pokémon back (or new ones): records are written the hack's own way and sector checksums updated.
//
//   openRomhackSave(bytes, name, { hint, makeSave }) → a save (as gameSaves.js makes) or null
//   hackRecord(sav, info) → { ok, bytes, notes } | { ok: false, reason }: a record for that save
//   ROMHACKS: the hacks it knows, for "which game is this from?" choices

import { makeOld3, gen3Text } from './pkhex.js';
import { CFRU_UNBOUND_SPECIES, CFRU_RR_SPECIES, CFRU_UNBOUND_MOVES, CFRU_RR_MOVES, CFRU_UNBOUND_GROWTH, CFRU_RR_GROWTH, EXPANSION_SPECIES, EXPANSION_MOVES, SEAGLASS_NATIONAL } from './romhackData.js';

const u16 = (d, o) => d[o] | (d[o + 1] << 8);
const u32 = (d, o) => (d[o] | (d[o + 1] << 8) | (d[o + 2] << 16) | (d[o + 3] << 24)) >>> 0;
const w16 = (d, o, v) => { d[o] = v & 255; d[o + 1] = (v >>> 8) & 255; };
const w32 = (d, o, v) => { d[o] = v & 255; d[o + 1] = (v >>> 8) & 255; d[o + 2] = (v >>> 16) & 255; d[o + 3] = (v >>> 24) & 255; };
const SECTOR = 0x1000;
const SIG_VANILLA = 0x08012025;
const SIG_UNBOUND = [0x01121999, 0x01121998];
const GEN3_ORDER = ['GAEM', 'GAME', 'GEAM', 'GEMA', 'GMAE', 'GMEA', 'AGEM', 'AGME', 'AEGM', 'AEMG', 'AMGE', 'AMEG', 'EGAM', 'EGMA', 'EAGM', 'EAMG', 'EMGA', 'EMAG', 'MGAE', 'MGEA', 'MAGE', 'MAEG', 'MEGA', 'MEAG'];

export const ROMHACKS = [
  { id: 'unbound', name: 'Pokémon Unbound', family: 'cfru', words: ['unbound'] },
  { id: 'radicalred', name: 'Pokémon Radical Red', family: 'cfru', words: ['radical', 'radred'] },
  { id: 'seaglass', name: 'Pokémon Emerald Seaglass', family: 'expansion', words: ['seaglass'] },
  { id: 'rowe', name: 'Pokémon ROWE', family: 'rowe', words: ['rowe'] },
  { id: 'expansion', name: 'Another Emerald hack (pokeemerald-expansion)', family: 'expansion', words: ['expansion', 'emerald x', 'elite redux', 'inclement', 'lazarus', 'emerald imperium', 'run and bun', 'run & bun'] },
  { id: 'cfru', name: 'Another FireRed hack (CFRU)', family: 'cfru', words: ['cfru'] },
];
const hackOf = (id) => ROMHACKS.find((h) => h.id === id) ?? null;
/** Which hack the file name points to, or null. */
export function romhackFromName(name) {
  const n = String(name ?? '').toLowerCase().replace(/[_\-.]+/g, ' ');
  return ROMHACKS.find((h) => h.words.some((w) => n.includes(w)))?.id ?? null;
}

// balls: each family's own numbers ↔ the usual numbering (1 Master … 4 Poké … 16 Cherish, 17 Fast … 26 Beast, 27 Strange)
const BALL_EXP = [27, 4, 3, 2, 1, 12, 14, 6, 8, 7, 13, 10, 15, 9, 11, 18, 19, 23, 22, 21, 17, 20, 25, 5, 24, 4, 26, 16];
const BALL_CFRU = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 4, 17, 18, 19, 20, 21, 22, 23, 24, 26, 25];
const ballIn = (table, n) => { const i = table.indexOf(n); return i < 0 ? table.indexOf(4) : i; };

// gen 3 text, both ways (the English set)
function enc3(str, n) {
  const out = new Uint8Array(n).fill(0xff);
  const s = [...String(str ?? '')].slice(0, n);
  s.forEach((ch, i) => {
    const c = ch.charCodeAt(0);
    out[i] = c >= 65 && c <= 90 ? 0xbb + c - 65 : c >= 97 && c <= 122 ? 0xd5 + c - 97 : c >= 48 && c <= 57 ? 0xa1 + c - 48
      : ({ ' ': 0x00, '!': 0xab, '?': 0xac, '.': 0xad, '-': 0xae, '…': 0xb0, '“': 0xb1, '”': 0xb2, '‘': 0xb3, '’': 0xb4, "'": 0xb4, '♂': 0xb5, '♀': 0xb6, ',': 0xb8, '/': 0xba, 'é': 0x1b }[ch] ?? 0x00);
  });
  return out;
}

// ---------- the flash: two save slots of 14 sectors, plus spare sectors ----------
function slots(data) {
  const out = [];
  for (let s = 0; s < 2; s++) {
    const secs = new Map();
    let sig = null, counter = null, ok = true;
    for (let i = 0; i < 14; i++) {
      const o = (s * 14 + i) * SECTOR;
      if (o + SECTOR > data.length) { ok = false; break; }
      const id = u16(data, o + 0xff4), sg = u32(data, o + 0xff8);
      if (id >= 14 || secs.has(id) || !(sg === SIG_VANILLA || SIG_UNBOUND.includes(sg))) { ok = false; break; }
      sig = sig ?? sg; counter = counter ?? u32(data, o + 0xffc);
      secs.set(id, o);
    }
    if (ok && secs.size === 14) out.push({ secs, sig, counter });
  }
  if (out.length === 2) { const d = (out[1].counter - out[0].counter) >>> 0; return d > 0 && d < 0x80000000 ? [out[1], out[0]] : [out[0], out[1]]; }
  return out;
}
const sectorSum = (d, o, len) => { let t = 0; for (let i = 0; i < len; i += 4) t = (t + u32(d, o + i)) >>> 0; return ((t >>> 16) + (t & 0xffff)) & 0xffff; };

// ---------- tables ----------
const tables = (hack, family) => family === 'cfru'
  ? (hack === 'radicalred' ? { sp: CFRU_RR_SPECIES, mv: CFRU_RR_MOVES } : { sp: CFRU_UNBOUND_SPECIES, mv: CFRU_UNBOUND_MOVES })
  : { sp: EXPANSION_SPECIES, mv: EXPANSION_MOVES };
const reverse = new Map();
function nativeOf(table, key) {
  let m = reverse.get(table);
  if (!m) { m = new Map(); table.forEach((v, i) => { if (v && !m.has(String(v))) m.set(String(v), i); }); reverse.set(table, m); }
  return m.get(String(key)) ?? 0;
}
function national(code) {
  if (!code) return { national: null, formName: '' };
  if (typeof code === 'number') return { national: code, formName: '' };
  const [n, ...f] = String(code).split('-');
  return { national: Number(n), formName: f.join('-') };
}

// the Gen 3 experience curves (0 medium fast, 1 erratic, 2 fluctuating, 3 medium slow, 4 fast, 5 slow)
export function gen3Exp(rate, n) {
  if (n <= 1) return 0;
  n = Math.min(100, n);
  switch (rate) {
    case 1: return Math.floor(n <= 50 ? (n ** 3 * (100 - n)) / 50 : n <= 68 ? (n ** 3 * (150 - n)) / 100 : n <= 98 ? (n ** 3 * Math.floor((1911 - 10 * n) / 3)) / 500 : (n ** 3 * (160 - n)) / 100);
    case 2: return Math.floor(n <= 15 ? n ** 3 * ((Math.floor((n + 1) / 3) + 24) / 50) : n <= 36 ? n ** 3 * ((n + 14) / 50) : n ** 3 * ((Math.floor(n / 2) + 32) / 50));
    case 3: return Math.floor(1.2 * n ** 3 - 15 * n ** 2 + 100 * n - 140);
    case 4: return Math.floor((4 * n ** 3) / 5);
    case 5: return Math.floor((5 * n ** 3) / 4);
    default: return n ** 3;
  }
}

// ---------- reading one Pokémon ----------
const ivs = (w) => ({ hp: w & 31, atk: (w >>> 5) & 31, def: (w >>> 10) & 31, spe: (w >>> 15) & 31, spa: (w >>> 20) & 31, spd: (w >>> 25) & 31 });
// the four 12-byte blocks back in order G A E M (encrypted ones: decrypt, check, unshuffle)
function blocks(rec, encrypted) {
  const data = rec.subarray(32, 80);
  if (!encrypted) return new Uint8Array(data);
  const pid = u32(rec, 0), key = (pid ^ u32(rec, 4)) >>> 0;
  const t = new Uint8Array(48);
  for (let i = 0; i < 48; i += 4) w32(t, i, (u32(data, i) ^ key) >>> 0);
  let sum = 0; for (let i = 0; i < 48; i += 2) sum = (sum + u16(t, i)) & 0xffff;
  if (sum !== u16(rec, 0x1c)) return null;
  const order = GEN3_ORDER[pid % 24], out = new Uint8Array(48);
  for (let i = 0; i < 4; i++) out.set(t.subarray(i * 12, i * 12 + 12), 'GAEM'.indexOf(order[i]) * 12);
  return out;
}
/** A 100- or 80-byte record (expansion: encrypted; CFRU party: plain). */
function readFull(rec, hack, family) {
  if (u32(rec, 0) === 0 && u32(rec, 4) === 0) return null;
  const enc = family === 'expansion';
  const d = blocks(rec, enc);
  if (!d) return null;
  const G = 0, A = 12, E = 24, M = 36;
  const species = enc ? u16(d, G) & 0x7ff : u16(d, G);
  if (!species) return null;
  const { sp, mv } = tables(hack, family);
  const iv = u32(d, M + 4), rib = u32(d, M + 8), origins = u16(d, M + 2);
  // expansion moved the ball into the growth block (6 bits at byte 10) and keeps a 2-bit ability slot in
  // the ribbon word; older expansion builds keep the classic places; CFRU keeps its ball at byte 10 too
  const newExp = enc && (d[G + 10] & 0x3f) !== 0;
  const ball = family === 'cfru' ? BALL_CFRU[d[G + 10]] ?? 4 : newExp ? BALL_EXP[d[G + 10] & 0x3f] ?? 4 : (origins >> 11) & 15;
  const abilitySlot = newExp ? (rib >>> 29) & 3 : (iv >>> 31) & 1 ? 2 : 0;
  const rawMoves = [0, 1, 2, 3].map((i) => (enc ? u16(d, A + i * 2) & 0x7ff : u16(d, A + i * 2) & 0x3ff));
  return fields(rec, hack, {
    species, table: sp, exp: enc ? u32(d, G + 4) & 0x1fffff : u32(d, G + 4), heldItem: enc ? u16(d, G + 2) & 0x3ff : u16(d, G + 2),
    friendship: d[G + 9], moves: rawMoves.map((m) => mv[m] ?? 0), rawMoves, pp: [0, 1, 2, 3].map((i) => d[A + 8 + i] & (enc ? 0x7f : 0xff)),
    evs: { hp: d[E], atk: d[E + 1], def: d[E + 2], spe: d[E + 3], spa: d[E + 4], spd: d[E + 5] },
    contest: { cool: d[E + 6], beauty: d[E + 7], cute: d[E + 8], smart: d[E + 9], tough: d[E + 10], sheen: d[E + 11] },
    ivWord: iv, pokerus: d[M], metLocation: d[M + 1], metLevel: origins & 0x7f, version: (origins >> 7) & 15, ball, otGender: origins >> 15,
    abilityNumber: abilitySlot === 2 ? 4 : abilitySlot === 1 ? 2 : 1, level: rec.length >= 100 ? rec[0x54] : 0,
    hp: rec.length >= 100 ? u16(rec, 0x56) : 0, newLayout: newExp,
  });
}
/** CFRU's 58-byte PC record. */
function readCompact(rec, hack) {
  const species = u16(rec, 28), exp = u32(rec, 32);
  if (!species || species > 2500 || exp > 2000000) return null;
  const { sp, mv } = tables(hack, 'cfru');
  let packed = 0n; for (let i = 0; i < 5; i++) packed |= BigInt(rec[39 + i]) << BigInt(8 * i);
  const rawMoves = [0, 1, 2, 3].map((i) => Number((packed >> BigInt(i * 10)) & 0x3ffn));
  const iv = u32(rec, 54);
  return fields(rec, hack, {
    species, table: sp, exp, heldItem: u16(rec, 30), friendship: rec[37], moves: rawMoves.map((m) => mv[m] ?? 0), rawMoves, pp: [0, 0, 0, 0],
    evs: { hp: rec[44], atk: rec[45], def: rec[46], spe: rec[47], spa: rec[48], spd: rec[49] }, contest: null,
    ivWord: iv, pokerus: 0, metLocation: 0, metLevel: 0, version: 0, ball: BALL_CFRU[rec[38]] ?? 4, otGender: 0, abilityNumber: (iv >>> 31) & 1 ? 4 : 1, level: 0,
  });
}
/**
 * ROWE's records: 52 bytes in the PC, 76 in the party (the same 52, then PP, status, level and stats).
 *   0 PID · 4 OT ID · 8 nickname (10) · 0x14 move 1 (10 bits) + experience (22) · 0x18 moves 2 and 3
 *   (10 bits each, then 12 bits ROWE keeps for itself) · 0x1C species · 0x1E move 4 (bits 1–10)
 *   0x28 met level · 0x29 ball · 0x2B OT name (7) · party: 0x34 PP (4) · 0x38 status · 0x3C level · 0x3E HP, stats
 * Its genes and effort aren't kept where the official games keep them (its "fighting styles"): left at 0.
 * Worked out from a real ROWE save (Rhyhorn with Smack Down, Wurmple, Zigzagoon).
 */
const roweMoves = (rec) => { const w1 = u32(rec, 0x14), w2 = u32(rec, 0x18); return [w1 & 0x3ff, w2 & 0x3ff, (w2 >>> 10) & 0x3ff, (u16(rec, 0x1e) >>> 1) & 0x3ff]; };
function readRowe(rec) {
  if (u32(rec, 0) === 0 && u32(rec, 4) === 0) return null;
  const species = u16(rec, 0x1c) & 0x7ff;
  if (!species) return null;
  const rawMoves = roweMoves(rec), party = rec.length >= 76;
  return fields(rec, 'rowe', {
    species, table: EXPANSION_SPECIES, exp: u32(rec, 0x14) >>> 10, heldItem: 0, friendship: 70, moves: rawMoves.map((m) => EXPANSION_MOVES[m] ?? 0), rawMoves,
    pp: party ? [rec[0x34], rec[0x35], rec[0x36], rec[0x37]] : [0, 0, 0, 0], evs: { hp: 0, atk: 0, def: 0, spe: 0, spa: 0, spd: 0 }, contest: null,
    ivWord: 0, pokerus: 0, metLocation: 0, metLevel: rec[0x28] & 0x7f, version: 3, ball: BALL_EXP[rec[0x29]] ?? 4, otGender: 0, abilityNumber: 1,
    level: party ? rec[0x3c] : 0, hp: party ? u16(rec, 0x3e) : 0, otNameAt: 0x2b,
  });
}
function fields(rec, hack, f) {
  const pid = u32(rec, 0), otid = u32(rec, 4);
  const { national: nat, formName } = national(f.table[f.species]);
  const jp = rec[0x12] === 1 && hack !== 'rowe';
  const pk = makeOld3({
    ec: pid, pid, tid: otid & 0xffff, sid: otid >>> 16,
    speciesInternal: f.species, national: nat || null, formName, speciesUnsure: !nat,
    heldItem: f.heldItem, exp: f.exp, otFriendship: f.friendship, moves: f.moves, pp: f.pp, evs: f.evs, contest: f.contest,
    ivs: ivs(f.ivWord), isEgg: !!((f.ivWord >>> 30) & 1) || (hack !== 'rowe' && !!(rec[0x13] & 4)), abilityNumber: f.abilityNumber,
    pokerus: f.pokerus, metLocation: f.metLocation, metLevel: f.metLevel, version: f.version, ball: f.ball, otGender: f.otGender,
    nickname: gen3Text(rec, 8, 10, jp), otName: gen3Text(rec, f.otNameAt ?? 0x14, 7, jp), language: hack === 'rowe' ? 2 : rec[0x12] & 7, markings: hack === 'rowe' ? 0 : rec[0x1b],
    nature: pid % 25, gender: 2, statLevel: f.level, genderFromPid: pid & 0xff, hpCurrent: f.hp ?? 0,
    gameName: hackOf(hack)?.name ?? 'a ROM hack', romhack: hack, rawMoves: f.rawMoves, newLayout: !!f.newLayout,
    raw: null, // not the official games' format: they go to PKHeX as new files, not as they came
    hackRaw: new Uint8Array(rec), // …but back into the same hack exactly as they came
  }, hack);
  pk.isNicknamed = false;
  return pk;
}
// is this read believable? (species known or at least in range, a sane level for its experience)
const sane = (pk) => pk && (pk.national || pk.speciesInternal < 2048) && pk.exp <= 1640000 && (!pk.statLevel || (pk.statLevel >= 1 && pk.statLevel <= 100)) && pk.moves.some(Boolean);
const entryOf = (pk, hack) => (sane(pk) ? { bytes: pk.hackRaw, ext: hack, pk } : null);

// ---------- where each slot's record lives ----------
// A layout: { boxes: [{ name, n }], read(b, s) → bytes, write(b, s, bytes), party(s) → bytes, partyCount,
//             recSize, touched: Set of flash offsets of sectors written, sums: (sector) → length | 0 }
function cfruLayout(data, slot, hack) {
  const sec = (id) => slot.secs.get(id);
  const REGIONS = [[5, 4, 4080], [6, 0, 4080], [7, 0, 4080], [8, 0, 4080], [9, 0, 4080], [10, 0, 4080], [11, 0, 4080], [12, 0, 4080], [13, 0, 424], [30, 2828, 4080], [31, 0, 3968], [2, 3864, 4080], [3, 0, 3264]];
  const parts = [];
  let total = 0;
  for (const [s, a, b] of REGIONS) { const base = s < 14 ? sec(s) : s * SECTOR; if (base == null || base + b > data.length) return null; parts.push({ at: base + a, len: b - a, from: total, sector: s }); total += b - a; }
  const where = (off) => { for (const p of parts) if (off < p.from + p.len) return p.at + (off - p.from); return -1; };
  const sectorAt = (off) => parts.find((p) => off < p.from + p.len);
  const nboxes = Math.floor(total / (30 * 58));
  const s0 = sec(0);
  const touched = new Set();
  const lay = {
    recSize: 58, family: 'cfru',
    boxes: [...Array.from({ length: nboxes }, (_, b) => ({ name: `Box ${b + 1}` })), { name: hack === 'radicalred' ? 'Box 25' : 'Preset box' }],
    read(b, s) {
      const out = new Uint8Array(58);
      if (b === nboxes) { out.set(data.subarray(s0 + 176 + s * 58, s0 + 176 + s * 58 + 58)); return out; }
      const base = (b * 30 + s) * 58;
      for (let i = 0; i < 58; i++) out[i] = data[where(base + i)];
      return out;
    },
    write(b, s, rec) {
      if (b === nboxes) { data.set(rec, s0 + 176 + s * 58); touched.add(s0); return; }
      if (b > nboxes) return;
      const base = (b * 30 + s) * 58;
      for (let i = 0; i < 58; i++) { data[where(base + i)] = rec[i]; const p = sectorAt(base + i); if (p.sector < 14) touched.add(sec(p.sector)); }
    },
    partyCount: () => Math.min(6, u32(data, sec(1) + 0x34)),
    party: (s) => data.subarray(sec(1) + 0x38 + s * 100, sec(1) + 0x38 + s * 100 + 100),
    finish() {
      // Unbound: 0xFF0 bytes per sector, sector 0 0xF24, 13 0x450, 4 isn't checked; spare sectors 30/31 have no footer
      for (const o of touched) { const id = u16(data, o + 0xff4); if (id === 4) continue; w16(data, o + 0xff6, sectorSum(data, o, id === 0 ? 0xf24 : id === 13 ? 0x450 : 0xff0)); }
      touched.clear();
    },
    readRec: (rec) => readCompact(rec, hack),
  };
  return lay;
}
function expansionLayout(data, slot, hack) {
  const sec = (id) => slot.secs.get(id);
  const pcAt = (off) => sec(5 + Math.floor(off / 0xf80)) + (off % 0xf80);
  const touched = new Set();
  const names = (b) => { const t = new Uint8Array(9); for (let i = 0; i < 9; i++) t[i] = data[pcAt(4 + 420 * 80 + b * 9 + i)]; return gen3Text(t, 0, 8); };
  // the party: where Emerald keeps it, or wherever a count is followed by that many good records
  const sb1 = new Uint8Array(4 * 0xf80); for (let i = 1; i <= 4; i++) sb1.set(data.subarray(sec(i), sec(i) + 0xf80), (i - 1) * 0xf80);
  const partyAt = (o) => { const n = u32(sb1, o - 4); if (n < 1 || n > 6) return 0; for (let i = 0; i < n; i++) if (!sane(readFull(sb1.subarray(o + i * 100, o + i * 100 + 100), hack, 'expansion'))) return 0; return n; };
  let pOff = [0x238, 0x38].find((o) => partyAt(o)) ?? 0;
  for (let o = 4; !pOff && o + 100 <= sb1.length; o += 4) if (partyAt(o)) pOff = o;
  return {
    recSize: 80, family: 'expansion',
    boxes: Array.from({ length: 14 }, (_, b) => ({ name: names(b) || `Box ${b + 1}` })),
    read(b, s) { const out = new Uint8Array(80), base = 4 + (b * 30 + s) * 80; for (let i = 0; i < 80; i++) out[i] = data[pcAt(base + i)]; return out; },
    write(b, s, rec) { const base = 4 + (b * 30 + s) * 80; for (let i = 0; i < 80; i++) { data[pcAt(base + i)] = rec[i]; touched.add(sec(5 + Math.floor((base + i) / 0xf80))); } },
    partyCount: () => (pOff ? u32(sb1, pOff - 4) : 0),
    party: (s) => sb1.subarray(pOff + s * 100, pOff + s * 100 + 100),
    finish() { for (const o of touched) w16(data, o + 0xff6, sectorSum(data, o, 0xf80)); touched.clear(); },
    readRec: (rec) => readFull(rec, hack, 'expansion'),
  };
}
// ROWE uses each sector's whole 0xFF4 bytes (and checks all of them): 21 boxes of 30 × 52-byte records
function roweLayout(data, slot) {
  const sec = (id) => slot.secs.get(id);
  const S = 0xff4, s1 = sec(1);
  const pcAt = (off) => sec(5 + Math.floor(off / S)) + (off % S);
  const touched = new Set();
  const BOXES = 21, names = (b) => { const t = new Uint8Array(9); for (let i = 0; i < 9; i++) t[i] = data[pcAt(4 + BOXES * 30 * 52 + b * 9 + i)]; return gen3Text(t, 0, 8); };
  return {
    recSize: 52, family: 'rowe',
    boxes: Array.from({ length: BOXES }, (_, b) => ({ name: names(b) || `Box ${b + 1}` })),
    read(b, s) { const out = new Uint8Array(52), base = 4 + (b * 30 + s) * 52; for (let i = 0; i < 52; i++) out[i] = data[pcAt(base + i)]; return out; },
    write(b, s, rec) { const base = 4 + (b * 30 + s) * 52; for (let i = 0; i < 52; i++) { data[pcAt(base + i)] = rec[i]; touched.add(sec(5 + Math.floor((base + i) / S))); } },
    partyCount: () => Math.min(6, u32(data, s1 + 0x234)),
    party: (s) => data.subarray(s1 + 0x238 + s * 76, s1 + 0x238 + s * 76 + 76),
    finish() { for (const o of touched) w16(data, o + 0xff6, sectorSum(data, o, S)); touched.clear(); },
    readRec: readRowe,
  };
}

/** How many believable Pokémon a layout finds (and how many with species it doesn't know). */
function fit(lay, hack) {
  if (!lay) return -1;
  let good = 0, unsure = 0;
  const look = (pk) => { if (sane(pk)) { good++; if (pk.speciesUnsure) unsure++; } };
  for (let s = 0; s < lay.partyCount(); s++) look(lay.family === 'cfru' ? readFull(lay.party(s), hack, 'cfru') : lay.family === 'rowe' ? readRowe(lay.party(s)) : readFull(lay.party(s), hack, 'expansion'));
  lay.boxes.forEach((_, b) => { for (let s = 0; s < 30; s++) look(lay.readRec(lay.read(b, s))); });
  return good * 2 - unsure * 3;
}
const layoutFor = (data, slot, hack) => { const fam = hackOf(hack)?.family; return fam === 'cfru' ? cfruLayout(data, slot, hack) : fam === 'rowe' ? roweLayout(data, slot) : expansionLayout(data, slot, hack); };

/**
 * Open a GBA ROM hack save. hint: a ROMHACKS id (from the file name or the trainer's choice), or null to
 * work it out. Returns a save or null when this isn't a hack save it can read.
 */
export function openRomhackSave(input, name = '', { hint = null, makeSave } = {}) {
  const bytes = new Uint8Array(input);
  if (bytes.length < 0x20000) return null;
  const data = new Uint8Array(bytes.subarray(0, 0x20000)), tail = bytes.slice(0x20000);
  const [slot] = slots(data);
  if (!slot) return null;
  const guess = hint ?? romhackFromName(name);
  let hack = guess;
  if (SIG_UNBOUND.includes(slot.sig)) hack = guess && hackOf(guess)?.family === 'cfru' ? guess : 'unbound';
  else if (!guess) {
    // no name to go on: try each kind and keep the one that finds the most believable Pokémon
    const tries = ['radicalred', 'expansion', 'rowe'].map((h) => [h, fit(layoutFor(data, slot, h), h)]).sort((a, b) => b[1] - a[1]);
    if (tries[0][1] <= 0) return null;
    hack = tries[0][0];
  }
  const lay = layoutFor(data, slot, hack);
  if (!lay) return null;
  const h = hackOf(hack);
  const readParty = (s) => { if (s >= lay.partyCount()) return null; const rec = lay.party(s); return entryOf(lay.family === 'cfru' ? readFull(rec, hack, 'cfru') : lay.family === 'rowe' ? readRowe(rec) : readFull(rec, hack, 'expansion'), hack); };
  const canWrite = true;
  const sav = makeSave({
    gen: 3, game: h?.name ?? 'a ROM hack', format: hack, data, tail,
    trainer: { name: gen3Text(data, slot.secs.get(0), 7), tid: u16(data, slot.secs.get(0) + 0x0a), sid: u16(data, slot.secs.get(0) + 0x0c) },
    boxes: lay.boxes.map((b) => ({ name: b.name, slots: new Array(30).fill(null) })), party: new Array(6).fill(null),
    canWrite, whyNot: canWrite ? '' : `${h?.name ?? 'This hack'}'s PC isn't understood yet, so Pokémon can be brought over from its party but not put back.`,
    readSlot: (b, s) => (b < 0 ? readParty(s) : entryOf(lay.readRec(lay.read(b, s)), hack)),
    clearSlot: (b, s) => lay.write(b, s, new Uint8Array(lay.recSize)),
    writeSlot: (b, s, rec) => {
      if (rec.length !== lay.recSize) return { ok: false, reason: `That record isn't a ${h?.name} one.` };
      if (hack === 'unbound' && b === lay.boxes.length - 1) return { ok: false, reason: 'Unbound’s preset box holds the game’s team presets: put them into an ordinary box.' };
      lay.write(b, s, rec); return { ok: true };
    },
    finish: () => lay.finish(),
  });
  sav.romhack = hack; sav.family = lay.family;
  // ROWE: a record of its own to copy the bytes it keeps for itself from, when writing a new Pokémon
  if (lay.family === 'rowe') { const e = [...sav.party, ...sav.boxes.flatMap((b) => b.slots)].find(Boolean); sav.roweTemplate = e ? new Uint8Array(e.pk.hackRaw.subarray(0, 52)) : null; }
  // which way this save's expansion records are packed (newer builds moved the ball and ability slot)
  sav.newLayout = lay.family === 'expansion' ? ![...sav.party, ...sav.boxes.flatMap((b) => b.slots)].some((e) => e && !e.pk.newLayout) : false;
  return sav;
}

// ---------- writing: a record for a hack save ----------
/**
 * A record in this save's own format. info: { national, formName, name (species, for messages), nickname,
 * otName, pid, otid, exp, moves: [national numbers], pp, ivs, evs, friendship, ball (usual numbering),
 * abilityNumber (1, 2 or 4 = hidden), metLevel, heldItem, isEgg, raw (the hack record it came in as) }.
 * Returns { ok, bytes, notes } or { ok: false, reason }.
 */
/** Does this hack have this species (and form)? → { ok, form } (form: the one it'll arrive in) or { ok: false } */
export function hackHas(hack, family, national, formName = '') {
  const { sp } = tables(hack, family);
  const base = nativeOf(sp, national);
  if (hack === 'seaglass') {
    // Seaglass: Gens 1–3, their families' later evolutions, the Tinkaton and Applin lines; of forms, the Alolan ones
    if (!SEAGLASS_NATIONAL.includes(Number(national)) || !base) return { ok: false };
    return { ok: true, form: formName === 'Alola' && nativeOf(sp, `${national}-Alola`) ? 'Alola' : '' };
  }
  if (!base) return { ok: false };
  return { ok: true, form: formName && nativeOf(sp, `${national}-${formName}`) ? formName : '' };
}
const RECORD_SIZE = { cfru: 58, expansion: 80, rowe: 52 };

export function hackRecord(sav, info) {
  const hack = sav.romhack, family = sav.family;
  if (!hack) return { ok: false, reason: `That isn't a ROM hack save.` };
  const has = hackHas(hack, family, info.national, info.formName);
  if (!has.ok) return { ok: false, reason: `${sav.game} doesn't have ${info.name ?? `#${info.national}`}.` };
  // one that came from this same hack goes back as it came, with what changed here written in
  if (info.raw && info.rawHack === hack && info.raw.length >= RECORD_SIZE[family]) return patchRecord(sav, info);
  const notes = [];
  const { sp, mv } = tables(hack, family);
  const species = has.form ? nativeOf(sp, `${info.national}-${has.form}`) : nativeOf(sp, info.national);
  if (info.formName && has.form !== info.formName) notes.push(`${sav.game} has no ${info.formName} form, so it arrives in its usual form.`);
  const moves = [], pp = [];
  (info.moves ?? []).forEach((n, i) => { if (!n) return; const m = nativeOf(mv, n); if (m) { moves.push(m); pp.push(info.pp?.[i] ?? 10); } else notes.push(`Move #${n} isn't in ${sav.game}, so it was left out.`); });
  if (!moves.length) { moves.push(nativeOf(mv, 33) || 1); pp.push(35); notes.push('It knew no moves this game has, so it arrives knowing Tackle.'); }
  const iv = (k) => Math.max(0, Math.min(31, info.ivs?.[k] ?? 0));
  const ivWord = (iv('hp') | (iv('atk') << 5) | (iv('def') << 10) | (iv('spe') << 15) | (iv('spa') << 20) | (iv('spd') << 25)) >>> 0;
  const ev = (k) => Math.max(0, Math.min(252, info.evs?.[k] ?? 0));
  // CFRU hacks have their own growth rates: the level it had here, on the hack's own curve
  const growth = family === 'cfru' ? (hack === 'radicalred' ? CFRU_RR_GROWTH : CFRU_UNBOUND_GROWTH)[species] : null;
  const exp = Math.max(0, Math.min(0x1fffff, Math.round(growth != null && info.level ? gen3Exp(growth, info.level) : info.exp ?? 0)));
  const hidden = info.abilityNumber === 4;
  if (family === 'cfru') {
    const r = new Uint8Array(58);
    // CFRU's regular ability comes from the PID's lowest bit: 25 more keeps the nature and flips it
    let pid = info.pid >>> 0;
    if (!hidden && (pid & 1) !== (info.abilityNumber === 2 ? 1 : 0)) pid = pid > 0xffffffe6 ? pid - 25 : pid + 25;
    w32(r, 0, pid); w32(r, 4, info.otid >>> 0); r.set(enc3(info.nickname, 10), 8); r[18] = 2; r[19] = 2; r.set(enc3(info.otName, 7), 20);
    w16(r, 28, species); w16(r, 30, 0); w32(r, 32, exp); r[36] = 0; r[37] = Math.min(255, info.friendship ?? 70); r[38] = ballIn(BALL_CFRU, info.ball);
    let p = 0n; moves.forEach((m, i) => { p |= BigInt(m & 0x3ff) << BigInt(i * 10); }); for (let i = 0; i < 5; i++) r[39 + i] = Number((p >> BigInt(8 * i)) & 0xffn);
    ['hp', 'atk', 'def', 'spe', 'spa', 'spd'].forEach((k, i) => { r[44 + i] = ev(k); });
    // CFRU picks the regular ability from the PID's lowest bit, or the hidden one when bit 31 is set
    w32(r, 54, (ivWord | (hidden ? 0x80000000 : 0)) >>> 0);
    return { ok: true, bytes: r, notes };
  }
  if (family === 'rowe') {
    // ROWE: its own 52-byte record; the bytes it keeps for itself come from one of the save's own Pokémon
    const r = sav.roweTemplate ? new Uint8Array(sav.roweTemplate) : new Uint8Array(52);
    w32(r, 0, info.pid >>> 0); w32(r, 4, info.otid >>> 0); r.set(enc3(info.nickname, 10), 8);
    roweSet(r, exp, moves);
    w16(r, 0x1c, species); r[0x28] = Math.min(100, info.metLevel || 5); r[0x29] = ballIn(BALL_EXP, info.ball); r.set(enc3(info.otName, 7), 0x2b);
    notes.push('ROWE keeps genes and effort its own way (its fighting styles), so those start fresh there.');
    return { ok: true, bytes: r, notes };
  }
  // expansion: the encrypted 80-byte BoxPokemon, packed this save's way
  const r = new Uint8Array(80);
  w32(r, 0, info.pid >>> 0); w32(r, 4, info.otid >>> 0); r.set(enc3(info.nickname, 10), 8); r[0x12] = 2; r[0x13] = 0x02; r.set(enc3(info.otName, 7), 0x14);
  const G = new Uint8Array(12), A = new Uint8Array(12), E = new Uint8Array(12), M = new Uint8Array(12);
  const slot = hidden ? 2 : (info.abilityNumber === 2 ? 1 : 0), ball = ballIn(BALL_EXP, info.ball);
  if (sav.newLayout) {
    w16(G, 0, species & 0x7ff); w16(G, 2, 0); w32(G, 4, (exp | (0xff << 21)) >>> 0); G[8] = 0; G[9] = Math.min(255, info.friendship ?? 70); w16(G, 10, (ball & 0x3f) | (0xff << 6));
    moves.forEach((m, i) => { w16(A, i * 2, m & 0x7ff); A[8 + i] = Math.min(127, pp[i]); });
    w16(M, 2, (Math.min(100, info.metLevel || 5) & 0x7f) | (3 << 7));
    w32(M, 4, ivWord); w32(M, 8, (slot & 3) << 29);
  } else {
    w16(G, 0, species); w16(G, 2, 0); w32(G, 4, exp); G[9] = Math.min(255, info.friendship ?? 70);
    moves.forEach((m, i) => { w16(A, i * 2, m); A[8 + i] = Math.min(255, pp[i]); });
    w16(M, 2, (Math.min(100, info.metLevel || 5) & 0x7f) | (3 << 7) | ((ball & 15) << 11));
    w32(M, 4, (ivWord | (slot ? 0x80000000 : 0)) >>> 0);
  }
  ['hp', 'atk', 'def', 'spe', 'spa', 'spd'].forEach((k, i) => { E[i] = ev(k); });
  M[1] = 0xff; // met in a trade
  const plain = { G, A, E, M };
  let sum = 0; for (const b of [G, A, E, M]) for (let i = 0; i < 12; i += 2) sum = (sum + u16(b, i)) & 0xffff;
  w16(r, 0x1c, sum);
  const order = GEN3_ORDER[(info.pid >>> 0) % 24], key = ((info.pid >>> 0) ^ (info.otid >>> 0)) >>> 0;
  for (let i = 0; i < 4; i++) { const blk = plain[order[i]]; for (let j = 0; j < 12; j += 4) w32(r, 32 + i * 12 + j, (u32(blk, j) ^ key) >>> 0); }
  return { ok: true, bytes: r, notes };
}

// ROWE: experience and the four moves (1 with the experience, 2–3 together, 4 on its own)
function roweSet(r, exp, moves) {
  const m = [0, 1, 2, 3].map((i) => moves[i] ?? 0);
  w32(r, 0x14, ((m[0] & 0x3ff) | ((Math.min(exp, 0x3fffff) & 0x3fffff) << 10)) >>> 0);
  w32(r, 0x18, ((u32(r, 0x18) & 0xfff00000) | (m[1] & 0x3ff) | ((m[2] & 0x3ff) << 10)) >>> 0);
  w16(r, 0x1e, (u16(r, 0x1e) & ~(0x3ff << 1)) | ((m[3] & 0x3ff) << 1));
}

/**
 * A Pokémon going back to the hack it came from: its own record, with what it gained in Capsule Link written
 * in (level, moves, effort, friendship, nickname); everything else stays byte for byte.
 */
function patchRecord(sav, info) {
  const hack = sav.romhack, family = sav.family, notes = [];
  const r = new Uint8Array(info.raw.subarray(0, RECORD_SIZE[family]));
  const { mv } = tables(hack, family);
  const moves = [], pp = [];
  (info.moves ?? []).forEach((n, i) => { const m = nativeOf(mv, n); if (m) { moves.push(m); pp.push(info.pp?.[i] ?? 10); } else if (n) notes.push(`Move #${n} isn't in ${sav.game}, so it was left out.`); });
  const keepMoves = !moves.length;
  const ev = (k) => Math.max(0, Math.min(252, info.evs?.[k] ?? 0));
  const levelChanged = info.level && info.importLevel && info.level !== info.importLevel;
  if (family === 'cfru') {
    const species = u16(r, 28), growth = (hack === 'radicalred' ? CFRU_RR_GROWTH : CFRU_UNBOUND_GROWTH)[species];
    if (levelChanged && growth != null) w32(r, 32, gen3Exp(growth, info.level));
    if (!keepMoves) { let p = 0n; moves.forEach((m, i) => { p |= BigInt(m & 0x3ff) << BigInt(i * 10); }); for (let i = 0; i < 5; i++) r[39 + i] = Number((p >> BigInt(8 * i)) & 0xffn); }
    ['hp', 'atk', 'def', 'spe', 'spa', 'spd'].forEach((k, i) => { r[44 + i] = ev(k); });
    r[37] = Math.min(255, info.friendship ?? r[37]);
    if (info.nickname) r.set(enc3(info.nickname, 10), 8);
    return { ok: true, bytes: r, notes };
  }
  if (family === 'rowe') {
    const exp = levelChanged ? Math.round(info.exp ?? 0) : u32(r, 0x14) >>> 10;
    roweSet(r, exp, keepMoves ? roweMoves(r) : moves);
    if (info.nickname) r.set(enc3(info.nickname, 10), 8);
    if (Object.values(info.evs ?? {}).some(Boolean)) notes.push('ROWE keeps effort its own way, so effort gained here stays in Capsule Link.');
    return { ok: true, bytes: r, notes };
  }
  // expansion: decrypt, change, checksum, encrypt
  const pid = u32(r, 0), key = (pid ^ u32(r, 4)) >>> 0, order = GEN3_ORDER[pid % 24];
  const t = new Uint8Array(48); for (let i = 0; i < 48; i += 4) w32(t, i, (u32(r, 32 + i) ^ key) >>> 0);
  const at = (blk) => order.indexOf(blk) * 12;
  const G = at('G'), A = at('A'), E = at('E');
  const newLay = (t[G + 10] & 0x3f) !== 0;
  if (levelChanged) { const exp = Math.min(0x1fffff, Math.round(info.exp ?? 0)); w32(t, G + 4, newLay ? ((u32(t, G + 4) & ~0x1fffff) | exp) >>> 0 : exp); }
  t[G + 9] = Math.min(255, info.friendship ?? t[G + 9]);
  if (!keepMoves) for (let i = 0; i < 4; i++) { const m = moves[i] ?? 0; w16(t, A + i * 2, newLay ? (u16(t, A + i * 2) & ~0x7ff) | (m & 0x7ff) : m); t[A + 8 + i] = m ? Math.min(newLay ? 127 : 255, pp[i]) | (newLay ? t[A + 8 + i] & 0x80 : 0) : 0; }
  ['hp', 'atk', 'def', 'spe', 'spa', 'spd'].forEach((k, i) => { t[E + i] = ev(k); });
  if (info.nickname) r.set(enc3(info.nickname, 10), 8);
  let sum = 0; for (let i = 0; i < 48; i += 2) sum = (sum + u16(t, i)) & 0xffff;
  w16(r, 0x1c, sum);
  for (let i = 0; i < 48; i += 4) w32(r, 32 + i, (u32(t, i) ^ key) >>> 0);
  return { ok: true, bytes: r, notes };
}
