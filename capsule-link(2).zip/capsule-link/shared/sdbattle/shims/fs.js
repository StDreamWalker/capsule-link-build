// (one mod: 'capsule', filled in at run time with a data set's own creatures, moves, abilities and types)
export const readdirSync = (p) => (/mods\/?$/.test(String(p)) ? ['capsule'] : []);
export const existsSync = () => false;
export default { readdirSync, existsSync };
