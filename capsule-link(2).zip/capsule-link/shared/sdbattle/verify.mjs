// Keeps Pokémon Showdown exactly Showdown. Every vendored file (simulator, data, battle screen, styles) must
// match vendor/showdown/MANIFEST.sha256, which was checked byte for byte against the upstream repositories.
// The build calls verifyShowdown() before bundling and stops if anything was edited, added or removed, so a
// change to Showdown's rules can't slip into the app. (The README is the only file not covered.)
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
export const VENDOR = path.join(here, '..', '..', 'vendor', 'showdown');

function walk(dir, out = [], base = dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out, base);
    else out.push(path.relative(base, p).split(path.sep).join('/'));
  }
  return out;
}

/** { ok, changed: [file], missing: [file], extra: [file], checked } */
export function checkShowdown(dir = VENDOR) {
  const manifest = new Map();
  for (const line of fs.readFileSync(path.join(dir, 'MANIFEST.sha256'), 'utf8').split('\n')) {
    const m = /^([0-9a-f]{64}) {2}(.+)$/.exec(line.trim());
    if (m) manifest.set(m[2], m[1]);
  }
  const changed = [], missing = [], extra = [];
  for (const [file, want] of manifest) {
    const p = path.join(dir, file);
    if (!fs.existsSync(p)) { missing.push(file); continue; }
    const got = crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
    if (got !== want) changed.push(file);
  }
  for (const file of walk(dir)) if (!manifest.has(file) && file !== 'MANIFEST.sha256' && file !== 'README.md') extra.push(file);
  return { ok: !changed.length && !missing.length && !extra.length && manifest.size > 0, changed, missing, extra, checked: manifest.size };
}

/** Throws (stopping the build) unless the vendored Showdown is untouched. */
export function verifyShowdown(dir = VENDOR) {
  const r = checkShowdown(dir);
  if (!r.ok) {
    const list = [...r.changed.map((f) => `changed: ${f}`), ...r.missing.map((f) => `missing: ${f}`), ...r.extra.map((f) => `not from upstream: ${f}`)];
    throw new Error(`Pokémon Showdown's vendored files don't match upstream (vendor/showdown/MANIFEST.sha256), so the battle bundle was not built:\n  ${list.join('\n  ')}\nRestore them from the upstream commits listed in the manifest.`);
  }
  return r;
}
