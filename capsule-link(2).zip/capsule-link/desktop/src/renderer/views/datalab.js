// Data Lab: edit or paste every species, move, type matchup, curve and formula the apps use.
import { h, mount, toast, confirmDialog, promptDialog, typeChip, refocus } from '../../../../shared/ui/dom.js';
import { spriteCanvas, SpriteBank } from '../../../../shared/ui/art.js';
import { searchPick } from '../../../../shared/ui/searchPick.js';
import { BIOME_IDS, BIOME_INFO } from '../../../../shared/ui/biomes.js';
import { playCry, sfx, creatureCry } from '../../../../shared/ui/audio.js';
import { loadShowdown } from '../../../../shared/ui/showdownWild.js';
import {
  parseAbilities, ABILITY_KINDS, formsOf,
  STAT_KEYS, DEFAULT_FORMULAS, slug, validateDataset, sampleVars, checkFormula, parseCry, cryFor, compileFormula,
  parsePaste, guessMapping, applyImport, looksLikeShowdownSet, TARGETS, createDefaultDataset, normalizeDataset, datasetHash, parseMultiplier, list, movementOf, habitatsOf,
} from '../../../../shared/engine/index.js';

const clone = (x) => JSON.parse(JSON.stringify(x));
const TABS = [
  ['species', 'Species'], ['moves', 'Moves'], ['abilities', 'Abilities'], ['types', 'Types'], ['growth', 'Growth'],
  ['formulas', 'Formulas'], ['items', 'Items'], ['import', 'Paste'], ['files', 'Rules'],
];

/** The two halves of the lab app: a big button over to the other one, and Home. */
export function labSwitch(app, side, { leaving } = {}) {
  const go = async (id) => { if (leaving && !(await leaving())) return; sfx('select'); app.go(id); };
  return h('div', { class: `lab-switch lab-switch-${side}` },
    side === 'data'
      ? h('button', { class: 'lab-swap lab-swap-battle', title: 'The battle stage: every move, one click away', onclick: () => go('battlelab') }, h('span', { class: 'lab-swap-k' }, '⚔'), 'Battle Lab')
      : h('button', { class: 'lab-swap lab-swap-data', title: 'Species, moves, abilities and formulas', onclick: () => go('data') }, h('span', { class: 'lab-swap-k' }, '⚗'), 'Data Lab'),
    h('span', { class: 'lab-switch-where micro dim' }, side === 'data' ? 'Data Lab · your species, moves, abilities and rules' : 'Battle Lab · how every move looks on the battle stage'),
    h('span', { class: 'spacer' }),
    h('button', { class: 'btn lab-home', onclick: () => go('home') }, '⌂ Home'));
}

export function dataLabView(app) {
  let draft = clone(app.dataset);
  // the old Rules lists (always/never float, swim) become each species' own movement settings
  if (draft.movement) {
    for (const s of draft.species) {
      const m = draft.movement, mv = { ...(s.movement ?? {}) };
      if (m.float?.includes(s.id)) { mv.fly = true; mv.default = 'fly'; }
      if (m.noFloat?.includes(s.id)) { mv.default = mv.default === 'fly' ? 'walk' : mv.default; if (mv.fly == null) mv.fly = false; }
      if (m.swim?.includes(s.id)) mv.swim = true;
      if (m.noSwim?.includes(s.id)) mv.swim = false;
      if (Object.keys(mv).length) s.movement = mv;
    }
    delete draft.movement;
  }
  let dirty = false;
  let tab = 'species';
  let selSpecies = draft.species[0]?.id ?? null;
  let selMove = draft.moves[0]?.id ?? null;
  let selItem = draft.items[0]?.id ?? null;
  let selAbility = draft.abilities?.[0]?.id ?? null, sdAbilities = null;
  let search = '';
  let importState = { text: '', target: 'species', parsed: null, mapping: {}, mode: 'merge', speciesId: null, report: null, mainOnly: true };
  const labBank = new SpriteBank({ idx: null, resolveTexture: (p) => app.textures[p.toLowerCase()] ?? null });
  const el = h('div', { class: 'datalab' });
  const bar = h('div', { class: 'lab-bar' });
  const body = h('div', { class: 'lab-body' });
  // (leaving with unsaved changes: ask first)
  el.append(labSwitch(app, 'data', { leaving: async () => !dirty || confirmDialog('Unsaved changes', 'Your Data Lab changes aren’t saved yet. Leave anyway (they’ll be lost)?', { ok: 'Leave', cancel: 'Stay' }) }), bar, body);

  const touch = () => { if (!dirty) { dirty = true; renderBar(); } };
  const typeOptions = (sel, allowNone) => [allowNone ? h('option', { value: '', selected: !sel }, '—') : null, ...draft.types.map((t) => h('option', { value: t.id, selected: t.id === sel }, t.name))];
  const idxLike = () => ({ types: new Map(draft.types.map((t) => [t.id, t])) });

  /** An input bound to obj[key]. */
  function bind(obj, key, { type = 'text', min, max, step, placeholder, onChange, width } = {}) {
    const isNum = type === 'number';
    const input = h('input', { type, value: obj[key] ?? '', min, max, step, placeholder, style: width ? { width } : null });
    input.addEventListener('input', () => {
      const v = isNum ? (input.value === '' ? null : Number(input.value)) : input.value;
      obj[key] = v;
      touch();
      onChange?.(v, false);
    });
    input.addEventListener('change', () => onChange?.(obj[key], true));
    return input;
  }
  /** Where a species likes to live: any number of places, the first one picked is its main home. */
  function habitatPicker(sp) {
    const tIdx = { types: new Map(draft.types.map((t) => [t.id, t])) };
    const wrap = h('div', { class: 'field habitat-pick' });
    const paint = () => {
      const cur = habitatsOf(tIdx, sp);
      mount(wrap, h('span', null, 'Habitats ', h('span', { class: 'micro faint' }, sp.habitats?.length ? '(your choice)' : '(suggested from its types — click to change)')),
        h('div', { class: 'chip-row' }, BIOME_IDS.map((b) => h('button', { type: 'button', class: `chip-toggle ${cur.includes(b) ? 'on' : ''} ${cur[0] === b ? 'main' : ''}`, title: cur[0] === b ? 'Main habitat' : '',
          onclick: () => {
            let next = cur.includes(b) ? cur.filter((x) => x !== b) : [...cur, b];
            if (!next.length) next = [b];
            sp.habitats = next; sp.habitat = next[0]; touch(); paint();
          } }, cur[0] === b ? '★ ' : '', BIOME_INFO[b].label))),
        h('span', { class: 'micro faint' }, 'Pick every place it would feel at home; ★ is its main home (walk scenery and new yards). It counts for who turns up on walks, how happy it is in a yard, and who becomes friends.'));
    };
    paint();
    return wrap;
  }
  const field = (label, input, hint) => h('label', { class: 'field' }, h('span', null, label), input, hint ? h('span', { class: 'micro faint' }, hint) : null);

  // ---------------- top bar ----------------
  function renderBar() {
    mount(bar,
      h('div', { class: 'tabs', role: 'tablist' }, TABS.map(([id, label]) => h('button', { role: 'tab', 'aria-selected': tab === id ? 'true' : 'false', onclick: () => { tab = id; sfx('move'); renderBar(); renderBody(); } }, label))),
      h('span', { class: 'spacer' }),
      dirty ? h('span', { class: 'unsaved' }, 'Unsaved changes') : h('span', { class: 'dim' }, `${draft.species.length} species · ${draft.moves.length} moves`),
      h('button', { class: 'btn', disabled: !dirty, onclick: discard }, 'Discard'),
      h('button', { class: 'btn primary', disabled: !dirty, onclick: commit }, 'Save data set'));
  }

  async function commit() {
    const norm = normalizeDataset(clone(draft));
    const problems = validateDataset(norm);
    const oldHash = datasetHash(normalizeDataset(clone(app.dataset)));
    const newHash = datasetHash(norm);
    const missing = list(app.save).filter((c) => !norm.species.some((s) => s.id === c.speciesId));
    let msg = problems.length ? `${problems.length} problem${problems.length > 1 ? 's' : ''} found (see the Rules tab). Save anyway?` : 'Save these changes?';
    if (missing.length) msg += ` ${missing.length} of your creatures use species that are no longer in the list; they will show as unknown until you add them back.`;
    if (oldHash !== newHash && Object.values(app.save.capsules ?? {}).some((c) => c.uid)) msg += ' Species or move numbering changed: capsules written before now should be synced at the dock.';
    if ((problems.length || missing.length || oldHash !== newHash) && !(await confirmDialog('Save data set', msg, { ok: 'Save' }))) return;
    await app.saveDataset(norm);
    draft = clone(app.dataset);
    dirty = false;
    sfx('heal');
    app.say('Data set saved.', 'ok');
    renderBar(); renderBody();
  }

  async function discard() {
    if (!(await confirmDialog('Discard changes?', 'Everything since the last save is lost.', { ok: 'Discard', danger: true }))) return;
    draft = clone(app.dataset);
    dirty = false;
    renderBar(); renderBody();
  }

  // ---------------- species ----------------
  function speciesTab() {
    const q = search.toLowerCase();
    // (forms listed right under their usual form)
    const byId = new Map(draft.species.map((x) => [x.id, x]));
    const order = (x) => { const b = x.baseSpecies && byId.get(x.baseSpecies); return b ? [b.no, 1, x.no] : [x.no, 0, 0]; };
    const items = draft.species.filter((s) => !q || s.name.toLowerCase().includes(q) || String(s.no) === q).sort((a, b) => { const A = order(a), B = order(b); return A[0] - B[0] || A[1] - B[1] || A[2] - B[2]; });
    const sp = draft.species.find((s) => s.id === selSpecies);
    const listEl = h('div', { class: 'lab-list' },
      h('input', { type: 'search', placeholder: 'Search name or number', value: search, oninput: (e) => { search = e.target.value; renderBody(); setTimeout(() => refocus(body.querySelector('input[type=search]')), 0); } }),
      h('div', { class: 'lab-items scroll' }, items.map((s) => h('button', { class: `lab-item ${s.id === selSpecies ? 'sel' : ''}`, onclick: () => { selSpecies = s.id; renderBody(); } },
        h('span', { class: 'dim mono-num' }, s.baseSpecies ? '  ↳' : `#${String(s.no).padStart(3, '0')}`), h('span', { class: 'grow ell' }, s.name), s.baseSpecies ? h('span', { class: 'micro dim' }, 'form') : null))),
      h('button', { class: 'btn', onclick: addSpecies }, 'New species'));
    return h('div', { class: 'lab-split' }, listEl, sp ? speciesEditor(sp) : h('p', { class: 'dim' }, 'No species yet. Add one, or paste a list on the Paste tab.'));
  }

  function addSpecies() {
    const no = draft.species.reduce((m, s) => Math.max(m, s.no), 0) + 1;
    let id = `new-species-${no}`;
    while (draft.species.some((s) => s.id === id)) id += 'x';
    draft.species.push({ id, no, name: `New species ${no}`, types: [draft.types[0]?.id], baseStats: { hp: 50, atk: 50, def: 50, spa: 50, spd: 50, spe: 50 }, growthRate: draft.growthRates[0]?.id, baseExp: 64, baseFriendship: 70, effortYield: {}, habitat: 'meadow', cry: '', flavor: '', learnset: [], evolutions: [] });
    selSpecies = id; touch(); renderBody();
  }

  function speciesEditor(sp) {
    const total = () => STAT_KEYS.reduce((s, k) => s + (Number(sp.baseStats[k]) || 0), 0);
    const totalEl = h('span', { class: 'dim' }, `Total ${total()}`);
    const preview = h('div', { class: 'lab-sprite' });
    const paintSprite = () => {
      labBank.idx = { species: new Map(draft.species.map((x) => [x.id, x])), types: idxLike().types };
      labBank.cache.delete(sp.id);
      mount(preview, spriteCanvas(labBank, sp.id, { scale: 4, animate: true }), spriteCanvas(labBank, sp.id, { scale: 2, anim: 'back' }));
    };
    paintSprite();
    const cryInput = bind(sp, 'cry', { placeholder: 'E5:2 G5:2 C6:4', onChange: () => { try { parseCry(sp.cry); cryInput.setCustomValidity(''); } catch (e) { cryInput.setCustomValidity(e.message); } } });
    const typeSel = (i) => h('select', { onchange: (e) => { const t = [...sp.types]; t[i] = e.target.value || undefined; sp.types = t.filter(Boolean); touch(); paintSprite(); } }, typeOptions(sp.types[i], i === 1));

    return h('div', { class: 'lab-editor scroll' },
      h('div', { class: 'row', style: { alignItems: 'flex-start' } },
        h('div', { class: 'col grow' },
          h('div', { class: 'form-grid' },
            field('Name', bind(sp, 'name', { onChange: (v, done) => { if (done) renderBody(); } })),
            field('Number', bind(sp, 'no', { type: 'number', min: 1, max: 65535 }), 'What capsules store'),
            field('Id', h('input', { type: 'text', value: sp.id, disabled: true }), 'Texture file name'),
            field('Type', typeSel(0)), field('Second type', typeSel(1)),
            field('Name on Showdown', bind(sp, 'showdownName', { placeholder: sp.name }), 'Only if it differs from Name'),
            field('Abilities', abilitiesInput(sp), 'Comma separated. New creatures get the first. Showdown’s, or your own (Abilities tab).')),
          habitatPicker(sp),
          formsEditor(sp),
          h('h2', null, 'Base stats ', totalEl),
          h('div', { class: 'form-grid six' }, STAT_KEYS.map((k) => field(draft.statLabels?.[k] ?? k, bind(sp.baseStats, k, { type: 'number', min: 1, max: 255, onChange: () => { totalEl.textContent = `Total ${total()}`; } })))),
          h('h2', null, 'Effort given when defeated'),
          h('div', { class: 'form-grid six' }, STAT_KEYS.map((k) => field(draft.statLabels?.[k] ?? k, bind(sp.effortYield, k, { type: 'number', min: 0, max: 3 })))),
          movementEditor(sp),
          h('div', { class: 'form-grid' },
            field('Growth rate', h('select', { onchange: (e) => { sp.growthRate = e.target.value; touch(); } }, draft.growthRates.map((g) => h('option', { value: g.id, selected: g.id === sp.growthRate }, g.name)))),
            field('Base exp', bind(sp, 'baseExp', { type: 'number', min: 1 })),
            field('Base friendship', bind(sp, 'baseFriendship', { type: 'number', min: 0, max: 255 })),
            field('Height (m)', bind(sp, 'height', { type: 'number', min: 0, step: 0.1, placeholder: 'guessed' }), 'Sets how big it is drawn in the R.A.N.C.H. and on the desktop'))),
        h('div', { class: 'col', style: { width: '220px' } }, preview,
          h('label', { class: 'btn small' }, 'Load sprite PNG', h('input', { type: 'file', accept: 'image/png', class: 'hidden', onchange: (e) => loadTexture(e, `creatures/${sp.id}.png`) })),
          h('label', { class: 'btn small' }, 'Load back view PNG', h('input', { type: 'file', accept: 'image/png', class: 'hidden', onchange: (e) => loadTexture(e, `creatures/${sp.id}-back.png`) })),
          h('p', { class: 'micro faint' }, 'Frames side by side, each one square. More poses: docs/textures.md'))),
      h('div', { class: 'form-grid two' },
        field('Cry', h('div', { class: 'row' }, cryInput, h('button', { class: 'btn small', onclick: () => { try { creatureCry(sp); } catch (e) { toast(e.message, 'err'); } } }, 'Play')), 'Note + octave : ticks of 40 ms. Empty = generated.'),
        field('Description', bind(sp, 'flavor'))),
      evolutionEditor(sp),
      learnsetEditor(sp),
      h('div', { class: 'row' }, h('span', { class: 'spacer' }), h('button', { class: 'btn danger', onclick: async () => {
        if (!(await confirmDialog('Delete species?', `${sp.name} is removed from the data set.`, { ok: 'Delete', danger: true }))) return;
        draft.species = draft.species.filter((s) => s !== sp);
        selSpecies = draft.species[0]?.id; touch(); renderBody();
      } }, 'Delete species')));
  }

  // ---------- forms: a species' other looks (Castform's weather, Deoxys' formes, a battle form like Aegislash's) ----------
  // Each form is a species entry of its own, linked to its usual form (baseSpecies), with its own stats, types
  // and picture. Battle-only forms go into battles as the usual form (an ability like Stance Change switches).
  let sdForms = new Map(); // Showdown name → its forms (looked up once)
  function formsEditor(sp) {
    const lidx = { species: new Map(draft.species.map((x) => [x.id, x])) };
    const forms = formsOf(lidx, sp.id), base = forms[0]?.sp ?? sp, isForm = base !== sp;
    const box = h('div', { class: 'lab-forms' });
    const open = (id) => { selSpecies = id; renderBody(); };
    const statLine = (bs) => STAT_KEYS.map((k) => bs?.[k] ?? '–').join(' / ');
    const sdName = base.showdownName || base.name;
    const addForm = async () => {
      const forme = (await promptDialog('New form', `What’s this form of ${base.name} called? (e.g. Awakened, Sunny, Attack)`, ''))?.trim();
      if (!forme) return;
      const x = newForm(base, forme, {});
      selSpecies = x.id; touch(); renderBody();
      toast(`${x.name} added: set its stats, types and picture. Tick “Battle-only” if it only appears mid-battle.`, 'ok');
    };
    const rows = [];
    if (isForm) {
      rows.push(h('p', { class: 'micro' }, 'This is the ', h('b', null, sp.forme || sp.name), ' form of ', h('button', { class: 'linkish', onclick: () => open(base.id) }, base.name), '.'),
        h('div', { class: 'form-grid' },
          field('Form name', bind(sp, 'forme', { placeholder: 'e.g. Awakened', onChange: (v, done) => { if (done) renderBody(); } })),
          h('label', { class: 'check', title: 'Goes into battles as its usual form, and changes into this one mid-battle (with an ability like Stance Change, or a home-made one)' }, h('input', { type: 'checkbox', checked: !!sp.battleOnly, onchange: (e) => { sp.battleOnly = e.target.checked || undefined; touch(); } }), 'Battle-only (starts battles as ', base.name, ')')));
    } else {
      rows.push(h('div', { class: 'form-grid' }, field('Its usual form’s name', bind(sp, 'baseForme', { placeholder: 'Usual', onChange: (v, done) => { if (done) renderBody(); } }), 'Shown when picking a form (e.g. Meteor, Shield, Normal)')));
    }
    // the forms in this data set
    rows.push(h('div', { class: 'lab-form-list' }, forms.map((f) => h('div', { class: `lab-form ${f.sp === sp ? 'sel' : ''}` },
      h('span', { class: 'grow' }, h('b', null, f.forme), f.battleOnly ? h('span', { class: 'micro dim' }, '  battle-only') : null, h('span', { class: 'micro dim' }, `  ${(f.sp.types ?? []).map((t) => draft.types.find((x) => x.id === t)?.name ?? t).join('/')} · ${statLine(f.sp.baseStats)}`)),
      f.sp === sp ? h('span', { class: 'micro dim' }, 'this one') : h('button', { class: 'btn small', onclick: () => open(f.id) }, 'Open')))));
    rows.push(h('div', { class: 'row' }, h('button', { class: 'btn small', onclick: addForm }, '+ Add a form'), h('span', { class: 'micro dim' }, 'A new form starts as a copy of the usual one.')));
    // a real Pokémon's forms, from Showdown (the ones not in this data set yet can be added)
    const sdBox = h('div', { class: 'lab-sdforms' });
    const paint = (list) => {
      const have = new Set(forms.map((f) => (f.sp.showdownName || f.sp.name).toLowerCase()));
      const extra = (list ?? []).filter((f) => !f.usual);
      if (!extra.length) { mount(sdBox); return; }
      mount(sdBox, h('div', { class: 'micro dim' }, `Showdown’s forms of ${list[0].name}:`),
        extra.map((f) => h('div', { class: 'lab-form' },
          h('span', { class: 'grow' }, h('b', null, f.forme || f.name), f.battleOnly ? h('span', { class: 'micro dim' }, '  battle-only') : f.cosmetic ? h('span', { class: 'micro dim' }, '  just a look') : null, h('span', { class: 'micro dim' }, `  ${f.types.join('/')} · ${statLine(f.baseStats)}`)),
          have.has(f.name.toLowerCase()) ? h('span', { class: 'micro dim' }, 'in your data set') : h('button', { class: 'btn small', onclick: () => {
            const x = newForm(base, f.forme || f.name, { showdownName: f.name, types: f.types.map((t) => typeIdFor(t)).filter(Boolean), baseStats: f.baseStats, abilities: f.abilities, battleOnly: f.battleOnly || undefined, height: f.heightm });
            touch(); renderBody(); toast(`${x.name} added from Showdown.`, 'ok');
          } }, 'Add'))));
    };
    if (sdForms.has(sdName)) paint(sdForms.get(sdName));
    else loadShowdown().then((SD) => { const l = SD.speciesForms?.(sdName) ?? null; sdForms.set(sdName, l); if (sdBox.isConnected) paint(l); }).catch(() => {});
    mount(box, h('h2', null, 'Forms'), rows, sdBox);
    return box;
  }
  // a type of this data set for a Showdown type name (or none)
  function typeIdFor(name) { const k = slug(name); return draft.types.find((t) => slug(t.showdownName || t.name) === k || t.id === k)?.id ?? null; }
  // a new form of a species: a copy of it, linked to it, numbered past the real ones (capsules store numbers)
  function newForm(base, forme, extra) {
    let id = slug(`${base.id}-${forme}`), n = 2;
    while (draft.species.some((x) => x.id === id)) id = slug(`${base.id}-${forme}-${n++}`);
    const no = Math.max(10000, ...draft.species.map((x) => Number(x.no) || 0)) + 1;
    const x = { ...clone(base), id, no, name: `${base.name}-${forme}`, forme, baseSpecies: base.id, evolutions: [], ...extra };
    delete x.showdownName; if (extra.showdownName) x.showdownName = extra.showdownName;
    delete x.baseForme;
    if (!x.types?.length) x.types = [...(base.types ?? [])];
    draft.species.push(x);
    return x;
  }

  // ---------- how it gets about: in the R.A.N.C.H., on the desktop ----------
  function movementEditor(sp) {
    const wrap = h('div', { class: 'col' });
    const auto = () => movementOf(idxLike(), { ...sp, movement: {} });
    const tri = (key, label, hint, autoVal) => field(label, h('select', { onchange: (e) => {
      const v = e.target.value;
      const mv = { ...(sp.movement ?? {}) };
      if (v === '') delete mv[key]; else mv[key] = v === 'yes';
      sp.movement = mv; touch(); render();
    } },
    h('option', { value: '', selected: sp.movement?.[key] == null }, `Automatic (${autoVal ? 'yes' : 'no'})`),
    h('option', { value: 'yes', selected: sp.movement?.[key] === true }, 'Yes'),
    h('option', { value: 'no', selected: sp.movement?.[key] === false }, 'No')), hint);
    const render = () => {
      const a = auto(), now = movementOf(idxLike(), sp);
      mount(wrap,
        h('div', { class: 'row' }, h('h2', null, 'Movement'), h('span', { class: 'dim' }, `Right now: ${now.def === 'fly' ? 'flies' : now.def === 'hover' ? 'hovers' : now.def === 'swim' ? 'swims' : 'walks'} by default${now.canFly && now.def !== 'fly' ? ', can fly' : ''}${now.canSwim && now.def !== 'swim' ? ', can swim' : ''}${!now.water ? ', stays out of water' : ''}`)),
        h('p', { class: 'micro dim' }, 'How it gets about in the R.A.N.C.H. and on your desktop. Automatic goes by its types (flying, water, fire) and abilities (levitate). A mountaintop yard of only fliers becomes a sea of clouds; a seafloor yard of only swimmers fills with water, and anyone who can’t go in water gets a dry dome.'),
        h('div', { class: 'form-grid' },
          tri('walk', 'Can walk', 'On legs (or hops, or slithers)', a.walk),
          tri('swim', 'Can swim', 'Goes into ponds and the sea', a.canSwim),
          tri('water', 'Can be in water at all', 'No: never bathed (brushed instead) and kept dry', a.water),
          tri('fly', 'Can fly or float', 'Takes off now and then', a.canFly),
          field('Usually', h('select', { onchange: (e) => { const mv = { ...(sp.movement ?? {}) }; if (e.target.value) mv.default = e.target.value; else delete mv.default; sp.movement = mv; touch(); render(); } },
            h('option', { value: '', selected: !sp.movement?.default }, `Automatic (${a.def === 'fly' ? 'flies' : a.def === 'hover' ? 'hovers' : a.def === 'swim' ? 'swims' : 'walks'})`),
            [['walk', 'Walks'], ['hover', 'Hovers (a little off the ground)'], ['fly', 'Flies / floats'], ['swim', 'Swims']].map(([v, l]) => h('option', { value: v, selected: sp.movement?.default === v }, l))), 'What it does when it isn’t doing anything special')));
    };
    render();
    return wrap;
  }

  function abilitiesInput(sp) {
    const list = Array.isArray(sp.abilities) ? sp.abilities : sp.abilities && typeof sp.abilities === 'object' ? Object.values(sp.abilities) : [];
    return h('input', { type: 'text', value: list.join(', '), placeholder: 'e.g. Overgrowth, Sun Soak', oninput: (e) => { sp.abilities = e.target.value.split(',').map((x) => x.trim()).filter(Boolean); touch(); } });
  }

  async function loadTexture(e, path) {
    const f = e.target.files[0];
    if (!f) return;
    const bytes = new Uint8Array(await f.arrayBuffer());
    app.textures = await app.platform.importTexture(path, bytes);
    app.bank.setResolver((p) => app.textures[p.toLowerCase()] ?? null);
    labBank.setResolver((p) => app.textures[p.toLowerCase()] ?? null);
    toast(`Saved ${path}.`, 'ok');
    renderBody();
  }

  function evolutionEditor(sp) {
    const rows = sp.evolutions;
    const render = () => mount(wrap,
      h('div', { class: 'row' }, h('h2', null, 'Evolves into'), h('span', { class: 'spacer' }),
        h('button', { class: 'btn small', onclick: () => { rows.push({ to: draft.species.find((s) => s.id !== sp.id)?.id, method: 'level', value: 16 }); touch(); render(); } }, 'Add')),
      rows.length ? h('table', { class: 'grid' }, h('tbody', null, rows.map((ev, i) => h('tr', null,
        h('td', null, h('select', { onchange: (e) => { ev.to = e.target.value; touch(); } }, draft.species.map((s) => h('option', { value: s.id, selected: s.id === ev.to }, s.name)))),
        h('td', null, h('select', { onchange: (e) => { ev.method = e.target.value; if (['item', 'trade'].includes(ev.method) && typeof ev.value === 'number') ev.value = ''; touch(); render(); } }, [['level', 'at level'], ['friendship', 'at friendship'], ['steps', 'after steps walked'], ['item', 'using an item (name)'], ['trade', 'when traded']].map(([v, l]) => h('option', { value: v, selected: v === ev.method }, l)))),
        h('td', null, ev.method === 'item' || ev.method === 'trade' ? bind(ev, 'value', { type: 'text', width: '140px' }) : bind(ev, 'value', { type: 'number', min: 0, width: '120px' })),
        h('td', null, h('button', { class: 'btn small', 'aria-label': 'Remove', onclick: () => { rows.splice(i, 1); touch(); render(); } }, '×')))))) : h('p', { class: 'dim' }, 'Does not evolve.'));
    const wrap = h('div', { class: 'col' });
    render();
    return wrap;
  }

  function learnsetEditor(sp) {
    const wrap = h('div', { class: 'col' });
    const moveOpts = (sel) => draft.moves.slice().sort((a, b) => a.name.localeCompare(b.name)).map((m) => h('option', { value: m.id, selected: m.id === sel }, m.name));
    const render = () => mount(wrap,
      h('div', { class: 'row' }, h('h2', null, 'Learnset'), h('span', { class: 'dim' }, 'Level 0 = learned on growing'), h('span', { class: 'spacer' }),
        h('button', { class: 'btn small', onclick: () => { sp.learnset.push({ level: 1, move: draft.moves[0]?.id }); touch(); render(); } }, 'Add move'),
        h('button', { class: 'btn small', onclick: () => { importState = { ...importState, target: 'learnset', speciesId: sp.id, text: '', parsed: null, report: null }; tab = 'import'; renderBar(); renderBody(); } }, 'Paste a learnset')),
      h('table', { class: 'grid' }, h('thead', null, h('tr', null, h('th', null, 'Level'), h('th', null, 'Move'), h('th', null, 'Type'), h('th', null, ''))),
        h('tbody', null, sp.learnset.map((l, i) => {
          const mv = draft.moves.find((m) => m.id === l.move);
          return h('tr', null,
            h('td', null, bind(l, 'level', { type: 'number', min: 0, max: 255, width: '90px', onChange: (v, done) => { if (done) { sp.learnset.sort((a, b) => a.level - b.level); render(); } } })),
            h('td', null, searchPick(draft.moves.map((m) => ({ value: m.id, label: m.name })).sort((x, y) => x.label.localeCompare(y.label)), l.move, (v) => { if (!v) return; l.move = v; touch(); render(); }, { allowNone: false })),
            h('td', null, mv ? typeChip(idxLike(), mv.type) : h('span', { class: 'err-text' }, 'missing')),
            h('td', null, h('button', { class: 'btn small', 'aria-label': 'Remove', onclick: () => { sp.learnset.splice(i, 1); touch(); render(); } }, '×')));
        }))));
    render();
    return wrap;
  }

  // ---------------- moves ----------------
  function movesTab() {
    const q = search.toLowerCase();
    const items = draft.moves.filter((m) => !q || m.name.toLowerCase().includes(q)).sort((a, b) => a.name.localeCompare(b.name));
    const mv = draft.moves.find((m) => m.id === selMove);
    return h('div', { class: 'lab-split' },
      h('div', { class: 'lab-list' },
        h('input', { type: 'search', placeholder: 'Search moves', value: search, oninput: (e) => { search = e.target.value; renderBody(); setTimeout(() => refocus(body.querySelector('input[type=search]')), 0); } }),
        h('div', { class: 'lab-items scroll' }, items.map((m) => h('button', { class: `lab-item ${m.id === selMove ? 'sel' : ''}`, onclick: () => { selMove = m.id; renderBody(); } },
          h('span', { class: 'type-dot', style: { background: draft.types.find((t) => t.id === m.type)?.color ?? '#999' } }), h('span', { class: 'grow ell' }, m.name), h('span', { class: 'dim mono-num' }, m.power || '—')))),
        h('button', { class: 'btn', onclick: () => {
          const no = draft.moves.reduce((x, m) => Math.max(x, m.no), 0) + 1;
          draft.moves.push({ id: `move-${no}`, no, name: `New move ${no}`, type: draft.types[0]?.id, category: 'physical', power: 40, accuracy: 100, pp: 20, priority: 0, effect: {} });
          selMove = `move-${no}`; touch(); renderBody();
        } }, 'New move')),
      mv ? moveEditor(mv) : h('p', { class: 'dim' }, 'No moves yet.'));
  }

  function moveEditor(mv) {
    return h('div', { class: 'lab-editor scroll' },
      h('div', { class: 'form-grid' },
        field('Name', bind(mv, 'name', { onChange: (v, done) => { if (done) renderBody(); } })),
        field('Name on Showdown', bind(mv, 'showdownName', { placeholder: mv.name }), 'Only if it differs from Name'),
        field('Number', bind(mv, 'no', { type: 'number', min: 1, max: 65535 }), 'What capsules store'),
        field('Type', h('select', { onchange: (e) => { mv.type = e.target.value; touch(); } }, typeOptions(mv.type))),
        field('Category', h('select', { onchange: (e) => { mv.category = e.target.value; touch(); } }, ['physical', 'special', 'status'].map((c) => h('option', { value: c, selected: c === mv.category }, c[0].toUpperCase() + c.slice(1))))),
        field('Power', bind(mv, 'power', { type: 'number', min: 0 })),
        field('Accuracy', bind(mv, 'accuracy', { type: 'number', min: 1, max: 100, placeholder: 'never misses' }), 'Empty = never misses'),
        field('PP', bind(mv, 'pp', { type: 'number', min: 1 }))),
      field('Description', bind(mv, 'desc')),
      h('p', { class: 'dim' }, 'Showdown runs the move in battle. These fields are what the apps show on summaries and learnsets.'),
      h('div', { class: 'row' }, h('span', { class: 'spacer' }), h('button', { class: 'btn danger', onclick: async () => {
        const users = draft.species.filter((s) => s.learnset.some((l) => l.move === mv.id));
        if (!(await confirmDialog('Delete move?', users.length ? `${users.length} species learn it; it is removed from their learnsets.` : 'The move is removed.', { ok: 'Delete', danger: true }))) return;
        for (const s of users) s.learnset = s.learnset.filter((l) => l.move !== mv.id);
        draft.moves = draft.moves.filter((m) => m !== mv);
        selMove = draft.moves[0]?.id; touch(); renderBody();
      } }, 'Delete move')));
  }

  // ---------------- types ----------------
  function typesTab() {
    return h('div', { class: 'col' },
      h('p', { class: 'dim' }, 'Types give chips and generated sprites their colours. Showdown decides type matchups in battle.'),
      h('div', { class: 'row wrap' }, draft.types.map((t, i) => h('div', { class: 'type-edit' },
        h('input', { type: 'color', value: t.color, oninput: (e) => { t.color = e.target.value; touch(); }, onchange: () => renderBody(), 'aria-label': `${t.name} colour` }),
        h('input', { type: 'text', value: t.name, style: { width: '130px' }, oninput: (e) => { t.name = e.target.value; touch(); }, onchange: () => renderBody() }),
        h('button', { class: 'btn small', 'aria-label': `Delete ${t.name}`, onclick: async () => {
          const users = draft.species.filter((s) => s.types.includes(t.id)).length + draft.moves.filter((m) => m.type === t.id).length;
          if (users && !(await confirmDialog('Delete type?', `${users} species and moves use ${t.name}. They keep the id until you change them.`, { ok: 'Delete', danger: true }))) return;
          draft.types.splice(i, 1);
          touch(); renderBody();
        } }, '\u00d7'))),
      h('button', { class: 'btn', onclick: async () => {
        const name = await promptDialog('New type', 'Name');
        if (!name) return;
        const id = slug(name);
        if (draft.types.some((t) => t.id === id)) return toast('That type exists already.', 'err');
        draft.types.push({ id, name: name.trim(), color: '#a0a0b0' }); touch(); renderBody();
      } }, 'Add type')));
  }

  // ---------------- growth & temperaments ----------------
  function growthTab() {
    const canvas = h('canvas', { width: 420, height: 200, class: 'curve' });
    const drawCurves = () => {
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, 420, 200);
      const max = draft.rules?.maxLevel ?? 100;
      const curves = draft.growthRates.map((g) => { try { const f = compileFormula(g.formula); return Array.from({ length: max + 1 }, (_, n) => Math.max(0, Number(f({ n, level: n })) || 0)); } catch { return null; } });
      const top = Math.max(1, ...curves.filter(Boolean).map((c) => c[max]));
      const colors = ['#5b45c4', '#e5484d', '#178c80', '#c99412', '#3f6fd8', '#b04ad0'];
      ctx.strokeStyle = '#c4d3f2';
      for (let i = 1; i < 4; i++) { ctx.beginPath(); ctx.moveTo(30, 10 + i * 45); ctx.lineTo(410, 10 + i * 45); ctx.stroke(); }
      curves.forEach((c, i) => {
        if (!c) return;
        ctx.strokeStyle = colors[i % colors.length]; ctx.lineWidth = 2; ctx.beginPath();
        c.forEach((v, n) => { const x = 30 + (n / max) * 380, y = 190 - (v / top) * 180; if (n) ctx.lineTo(x, y); else ctx.moveTo(x, y); });
        ctx.stroke();
      });
    };
    setTimeout(drawCurves, 0);
    const tempers = draft.temperaments;
    const statOpt = (sel) => [h('option', { value: '', selected: !sel }, '—'), ...['atk', 'def', 'spa', 'spd', 'spe'].map((k) => h('option', { value: k, selected: k === sel }, draft.statLabels?.[k] ?? k))];
    return h('div', { class: 'lab-two' },
      h('section', { class: 'col' },
        h('h2', null, 'Growth rates'),
        h('p', { class: 'dim' }, 'Total experience needed to reach level n. Paste your own curve as a formula of n.'),
        canvas,
        draft.growthRates.map((g, i) => {
          const res = h('span', { class: 'micro' });
          const test = () => { const r = checkFormula(g.formula, { n: 50, level: 50 }); res.textContent = r.ok ? `Lv 50 needs ${Math.round(r.value).toLocaleString('en-US')} exp` : r.error; res.className = r.ok ? 'micro dim' : 'micro err-text'; };
          test();
          return h('div', { class: 'growth-row' },
            h('input', { type: 'text', value: g.name, style: { width: '140px' }, oninput: (e) => { g.name = e.target.value; touch(); } }),
            h('input', { type: 'text', class: 'code', value: g.formula, oninput: (e) => { g.formula = e.target.value; touch(); test(); drawCurves(); } }),
            h('button', { class: 'btn small', 'aria-label': 'Remove', onclick: () => { draft.growthRates.splice(i, 1); touch(); renderBody(); } }, '×'),
            res);
        }),
        h('button', { class: 'btn', onclick: () => { draft.growthRates.push({ id: `rate-${draft.growthRates.length + 1}`, name: 'New rate', formula: 'n^3' }); touch(); renderBody(); } }, 'Add growth rate')),
      h('section', { class: 'col' },
        h('h2', null, 'Temperaments'),
        h('p', { class: 'dim' }, 'Each raises one stat by 10% and lowers another by 10% (or neither).'),
        h('div', { class: 'scroll', style: { maxHeight: '520px' } }, h('table', { class: 'grid' },
          h('thead', null, h('tr', null, h('th', null, 'Name'), h('th', null, 'Raises'), h('th', null, 'Lowers'), h('th', null, ''))),
          h('tbody', null, tempers.map((t, i) => h('tr', null,
            h('td', null, h('input', { type: 'text', value: t.name, style: { width: '140px' }, oninput: (e) => { t.name = e.target.value; touch(); } })),
            h('td', null, h('select', { onchange: (e) => { t.up = e.target.value || null; touch(); } }, statOpt(t.up))),
            h('td', null, h('select', { onchange: (e) => { t.down = e.target.value || null; touch(); } }, statOpt(t.down))),
            h('td', null, h('button', { class: 'btn small', 'aria-label': 'Remove', onclick: () => { tempers.splice(i, 1); touch(); renderBody(); } }, '×'))))))),
        h('button', { class: 'btn', onclick: () => { tempers.push({ id: `temper-${tempers.length + 1}`, name: 'New', up: null, down: null }); touch(); renderBody(); } }, 'Add temperament')));
  }

  // ---------------- formulas ----------------
  function formulasTab() {
    return h('div', { class: 'col' },
      h('p', { class: 'dim' }, 'Each formula is a small program: one statement per line, the last line is the answer. You can use + - * / ^, comparisons, a ? b : c, [lists], and floor ceil round min max abs sqrt pow clamp rand(a, b) chance(%) and more.'),
      h('div', { class: 'formula-grid' }, Object.entries(DEFAULT_FORMULAS).map(([key, def]) => {
        const vars = { v: JSON.stringify(sampleVars(key)) };
        const out = h('div', { class: 'formula-out' });
        const ta = h('textarea', { class: 'code', rows: Math.max(2, (draft.formulas[key] ?? def.src).split('\n').length + 1), spellcheck: false }, draft.formulas[key] ?? def.src);
        const test = () => {
          let v;
          try { v = JSON.parse(vars.v); } catch { out.textContent = 'Test values must be JSON, like {"level": 50}'; out.className = 'formula-out err-text'; return; }
          let i = 0;
          const r = checkFormula(ta.value, v, () => [0.5, 0.25, 0.75][i++ % 3]);
          out.textContent = r.ok ? `= ${typeof r.value === 'number' ? Math.round(r.value * 1000) / 1000 : r.value}` : r.error;
          out.className = `formula-out ${r.ok ? '' : 'err-text'}`;
        };
        ta.addEventListener('input', () => { draft.formulas[key] = ta.value; touch(); test(); });
        const varsInput = h('input', { type: 'text', class: 'code', value: vars.v, oninput: (e) => { vars.v = e.target.value; test(); } });
        test();
        return h('section', { class: 'panel flat formula' },
          h('div', { class: 'row' }, h('h2', { class: 'grow' }, def.label),
            h('button', { class: 'btn small', onclick: () => { ta.value = def.src; draft.formulas[key] = def.src; touch(); test(); } }, 'Default')),
          h('p', { class: 'micro faint' }, `Variables: ${def.vars}`),
          ta,
          h('div', { class: 'row' }, h('span', { class: 'dim' }, 'Try'), varsInput),
          out);
      })));
  }

  // ---------------- items ----------------
  function itemsTab() {
    const it = draft.items.find((x) => x.id === selItem);
    return h('div', { class: 'lab-split' },
      h('div', { class: 'lab-list' },
        h('div', { class: 'lab-items scroll' }, draft.items.map((x) => h('button', { class: `lab-item ${x.id === selItem ? 'sel' : ''}`, onclick: () => { selItem = x.id; renderBody(); } }, h('span', { class: 'grow ell' }, x.name), h('span', { class: 'dim' }, x.kind)))),
        h('button', { class: 'btn', onclick: () => { const id = `item-${draft.items.length + 1}`; draft.items.push({ id, name: 'New item', kind: 'food', fullness: 20, joy: 5 }); selItem = id; touch(); renderBody(); } }, 'New item')),
      it ? h('div', { class: 'lab-editor' },
        h('div', { class: 'form-grid' },
          field('Name', bind(it, 'name', { onChange: (v, done) => { if (done) renderBody(); } })),
          field('Kind', h('select', { onchange: (e) => { it.kind = e.target.value; touch(); } }, [['food', 'Food'], ['toy', 'Toy'], ['groom', 'Grooming'], ['keepsake', 'Keepsake'], ['held', 'Held item']].map(([v, l]) => h('option', { value: v, selected: v === it.kind }, l)))),
          field('Fullness', bind(it, 'fullness', { type: 'number' })), field('Joy', bind(it, 'joy', { type: 'number' })),
          field('Energy', bind(it, 'energy', { type: 'number' })), field('Tidiness', bind(it, 'hygiene', { type: 'number' })),
          field('Friendship', bind(it, 'friendship', { type: 'number' }))),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!it.unlimited, onchange: (e) => { it.unlimited = e.target.checked; touch(); } }), 'Never runs out (not found on walks)'),
        field('Description', bind(it, 'desc')),
        h('div', { class: 'row' }, h('span', { class: 'spacer' }), h('button', { class: 'btn danger', onclick: () => { draft.items = draft.items.filter((x) => x !== it); selItem = draft.items[0]?.id; touch(); renderBody(); } }, 'Delete item'))) : h('p', { class: 'dim' }, 'No items.'));
  }

  // ---------------- abilities: home-made ones, how they work in battle, and uploading a file of them ----------------
  function abilitiesTab() {
    draft.abilities = Array.isArray(draft.abilities) ? draft.abilities : [];
    if (!sdAbilities) { sdAbilities = []; loadShowdown().then((SD) => { sdAbilities = SD.allAbilities?.() ?? []; if (tab === 'abilities') renderBody(); }).catch(() => {}); }
    const a = draft.abilities.find((x) => x.id === selAbility) ?? null;
    const usedBy = (ab) => draft.species.filter((sp) => (Array.isArray(sp.abilities) ? sp.abilities : []).some((n) => slug(n) === slug(ab.name)));
    const fileIn = h('input', { type: 'file', accept: '.json,.csv,.tsv,.txt,application/json,text/csv,text/plain', style: { display: 'none' }, onchange: async (e) => {
      const f = e.target.files?.[0]; e.target.value = ''; if (!f) return;
      try {
        const got = parseAbilities(await f.text(), draft.types);
        if (!got.length) { toast('No abilities found in that file (see the format below).', 'err'); return; }
        let added = 0, changed = 0;
        for (const x of got) { const i = draft.abilities.findIndex((y) => y.id === x.id || slug(y.name) === slug(x.name)); if (i >= 0) { draft.abilities[i] = { ...draft.abilities[i], ...x }; changed++; } else { draft.abilities.push(x); added++; } }
        selAbility = got[0].id; touch(); renderBody(); sfx('heal');
        toast(`${added} abilit${added === 1 ? 'y' : 'ies'} added${changed ? `, ${changed} updated` : ''}. Save the data set to keep them.`, 'ok');
      } catch (err) { toast(`Couldn’t read that file: ${err.message}`, 'err'); }
    } });
    const kindOpts = ABILITY_KINDS.map(([v, l]) => h('option', { value: v, selected: a?.kind === v }, l));
    const typeSel = (cur) => h('select', { onchange: (e) => { a.type = e.target.value; touch(); } }, typeOptions(cur, true));
    const statSel = h('select', { onchange: (e) => { a.stat = e.target.value; touch(); } }, STAT_KEYS.filter((k) => k !== 'hp').map((k) => h('option', { value: k, selected: (a?.stat ?? 'atk') === k }, draft.statLabels?.[k] ?? k)));
    const likeList = h('datalist', { id: 'lab-sd-abilities' }, (sdAbilities ?? []).map((x) => h('option', { value: x.name }, x.desc)));
    const likeHit = a?.like ? (sdAbilities ?? []).find((x) => slug(x.name) === slug(a.like)) : null, likeDesc = likeHit ? likeHit.desc || `battles exactly like ${likeHit.name}` : null;
    return h('div', { class: 'lab-split' },
      h('div', { class: 'lab-list' },
        h('div', { class: 'lab-items scroll' }, draft.abilities.length ? draft.abilities.map((x) => h('button', { class: `lab-item ${x.id === selAbility ? 'sel' : ''}`, onclick: () => { selAbility = x.id; renderBody(); } }, h('span', { class: 'grow ell' }, x.name), h('span', { class: 'dim micro' }, ABILITY_KINDS.find((k) => k[0] === x.kind)?.[0] === 'like' ? `like ${x.like || '?'}` : ''))) : h('p', { class: 'dim', style: { padding: '8px' } }, 'No home-made abilities yet.')),
        h('button', { class: 'btn', onclick: () => { let n = 1; while (draft.abilities.some((x) => x.id === `new-ability-${n}`)) n++; const x = { id: `new-ability-${n}`, name: `New Ability ${n}`, desc: '', kind: 'like', like: '' }; draft.abilities.push(x); selAbility = x.id; touch(); renderBody(); } }, 'New ability'),
        h('button', { class: 'btn', title: 'A .json or .csv file of abilities', onclick: () => fileIn.click() }, '⬆ Upload abilities'), fileIn),
      h('div', { class: 'lab-editor' },
        a ? [
          h('div', { class: 'form-grid' },
            field('Name', bind(a, 'name', { onChange: (v, done) => { if (done) { a.id = a.id || slug(v); renderBody(); } } }), 'What battles and summaries show'),
            field('In battle', h('select', { onchange: (e) => { a.kind = e.target.value; touch(); renderBody(); } }, kindOpts))),
          field('Description', bind(a, 'desc', { placeholder: 'e.g. Its Sprout moves hit harder in sunshine.' })),
          a.kind === 'like' ? field('Works like', h('span', null, h('input', { type: 'text', list: 'lab-sd-abilities', value: a.like ?? '', placeholder: 'A Showdown ability, e.g. Levitate', oninput: (e) => { a.like = e.target.value; touch(); }, onchange: () => renderBody() }), likeList),
            likeDesc ? `Showdown: ${likeDesc}` : a.like ? (sdAbilities?.length ? 'Showdown doesn’t know that ability: it’ll have no effect.' : 'Looking it up in Showdown’s abilities…') : 'It behaves exactly like this Showdown ability, under its own name.') : null,
          ['typeBoost', 'immune', 'absorb'].includes(a.kind) ? field('Type', typeSel(a.type)) : null,
          a.kind === 'stance' ? field('Its other form', h('span', null, h('input', { type: 'text', list: 'lab-form-names', value: a.form ?? '', placeholder: 'e.g. Awakened', oninput: (e) => { a.form = e.target.value; touch(); } }),
            h('datalist', { id: 'lab-form-names' }, [...new Set(draft.species.filter((x) => x.baseSpecies && x.forme).map((x) => x.forme))].map((f) => h('option', { value: f })))),
            'Attacking moves switch it to this form, any status move back to its usual form; it starts every battle in its usual form. (Add the form on the species’ page: Forms.)') : null,
          ['entryBoost', 'hitBoost', 'turnBoost'].includes(a.kind) ? h('div', { class: 'form-grid' }, field('Stat', statSel), field('Stages', bind(a, 'amount', { type: 'number', min: 1, max: 3 }))) : null,
          (() => { const u = usedBy(a); return h('p', { class: 'micro dim' }, u.length ? `Species with it: ${u.map((x) => x.name).join(', ')}.` : 'No species has it yet: add its name to a species’ Abilities (Species tab).'); })(),
          h('div', { class: 'row' }, h('span', { class: 'spacer' }), h('button', { class: 'btn danger', onclick: () => { draft.abilities = draft.abilities.filter((x) => x !== a); selAbility = draft.abilities[0]?.id ?? null; touch(); renderBody(); } }, 'Delete ability')),
        ] : h('p', { class: 'dim' }, 'Make one, or upload a file of them.'),
        h('details', { class: 'lab-help' }, h('summary', null, 'Uploading abilities: the file format'),
          h('p', { class: 'micro' }, 'A .csv (or tab-separated) file with a header row: name, description, and optionally kind, like, type, stat, amount. Or a .json list: [{ "name": "Sun Soak", "desc": "…", "kind": "typeBoost", "type": "Sprout" }].'),
          h('p', { class: 'micro' }, `Kinds: ${ABILITY_KINDS.map((k) => `${k[0]} (${k[1].toLowerCase()})`).join(', ')}. With only a name and description, it battles like the Showdown ability named in “like”, or has no effect.`),
          h('p', { class: 'micro dim' }, 'Every battle in the app (wild ones, famous trainers, in-app battles with friends) uses them. Showdown’s own server only knows Showdown’s abilities.'))));
  }

  // ---------------- paste & import ----------------
  function importTab() {
    const st = importState;
    // very large pastes stay out of the text box so typing does not slow down
    const big = st.text.length > 200000;
    const ta = h('textarea', { class: 'code paste', id: 'lab-paste', placeholder: 'Paste a table from a spreadsheet or web page, a JSON list, or a JavaScript/TypeScript data file such as Showdown’s pokedex.ts…', spellcheck: false }, big ? '' : st.text);
    if (big) ta.placeholder = `${Math.round(st.text.length / 1024)} KB loaded from a file. Press Read paste, or paste over this to replace it.`;
    ta.addEventListener('input', () => { st.text = ta.value; });
    const loadFile = async (e) => {
      const f = e.target.files?.[0];
      if (!f) return;
      st.text = await f.text();
      e.target.value = '';
      readPaste();
    };
    const targetSel = h('select', { id: 'lab-target', onchange: (e) => { st.target = e.target.value; st.mapping = st.parsed ? guessMapping(st.parsed.columns, st.target) : {}; renderBody(); } },
      [['species', 'Species'], ['moves', 'Moves'], ['learnset', 'Learnset'], ['temperaments', 'Natures (temperaments)']].map(([v, l]) => h('option', { value: v, selected: v === st.target }, l)));
    const parts = [
      h('div', { class: 'row wrap' },
        h('label', { class: 'row' }, h('span', { class: 'dim' }, 'This is a'), targetSel),
        st.target === 'learnset' ? h('label', { class: 'row' }, h('span', { class: 'dim' }, 'for'),
          h('select', { onchange: (e) => { st.speciesId = e.target.value; } }, [h('option', { value: '' }, 'the species named in each row'), ...draft.species.map((s) => h('option', { value: s.id, selected: s.id === st.speciesId }, s.name))])) : null,
        h('label', { class: 'row' }, h('span', { class: 'dim' }, 'and should'),
          h('select', { onchange: (e) => { st.mode = e.target.value; } }, [['merge', 'add to and update the list'], ['replace', 'replace the whole list']].map(([v, l]) => h('option', { value: v, selected: v === st.mode }, l)))),
        st.target === 'species' || st.target === 'moves' ? h('label', { class: 'check' }, h('input', { type: 'checkbox', id: 'lab-mainonly', checked: st.mainOnly, onchange: (e) => { st.mainOnly = e.target.checked; } }),
          st.target === 'species' ? 'Skip Mega, Gigantamax and Totem forms and unofficial entries (other forms and regional variants come in)' : 'Skip unofficial entries') : null,
        h('span', { class: 'spacer' }),
        h('label', { class: 'btn' }, 'Load a file', h('input', { type: 'file', class: 'hidden', accept: '.ts,.js,.json,.csv,.tsv,.txt', onchange: loadFile })),
        h('button', { class: 'btn primary', onclick: readPaste }, 'Read paste')),
      ta,
      h('p', { class: 'micro faint' }, 'Fastest order: species, then moves, then learnsets, then natures. See docs/adding-your-data.md.'),
    ];
    if (st.parsed) parts.push(mappingPanel());
    if (st.report) {
      parts.push(h('section', { class: 'panel flat' },
        h('h2', null, `Imported: ${st.report.added} added, ${st.report.updated} updated${st.report.skipped ? `, ${st.report.skipped} skipped` : ''}`),
        st.report.warnings.length ? h('ul', { class: 'warn-list' }, st.report.warnings.slice(0, 40).map((w) => h('li', null, w))) : h('p', { class: 'dim' }, 'No warnings. Remember to save the data set.')));
    }
    return h('div', { class: 'col import' }, parts);
  }

  function readPaste() {
    const st = importState;
    st.report = null;
    try {
      st.parsed = parsePaste(st.text);
    } catch (e) { toast(`Could not read that: ${e.message}`, 'err'); return; }
    if (st.parsed.format === 'empty') { toast('Paste something first.', 'err'); st.parsed = null; return; }
    if (st.parsed.partial) toast(`The paste stopped part-way through (${st.parsed.partial.kept} entries came through). The rest may have been cut off when copying — load the file instead.`, 'err');
    if (looksLikeShowdownSet(st.text)) { toast('That is a Showdown team. Creatures can go to Showdown but never come back from it — bring creatures in from PKHeX files (Storage → Import from PKHeX).', 'err'); st.parsed = null; return; }
    if (st.parsed.format === 'dataset') {
      confirmDialog('Whole data set found', 'This looks like a complete Capsule Link data set. Replace everything in the Data Lab with it?', { ok: 'Replace' }).then((ok) => {
        if (!ok) return;
        draft = clone(normalizeDataset(st.parsed.data)); st.parsed = null; touch(); renderBody(); toast('Data set loaded. Save to keep it.', 'ok');
      });
      return;
    }
    if (st.parsed.target) st.target = st.parsed.target;
    else if (st.parsed.format === 'lines') st.target = 'learnset';
    else if (st.parsed.columns.some((c) => /basestats|^types?\b|abilities/i.test(c))) st.target = 'species';
    else if (st.parsed.columns.some((c) => /power|accuracy|^pp$|category|basepower/i.test(c))) st.target = 'moves';
    else {
      // no telling columns (e.g. a descriptions file): go by which list the names already match
      const squash = (x) => String(x ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');
      const mv = new Set(draft.moves.map((m) => squash(m.name)));
      const spp = new Set(draft.species.map((x) => squash(x.name)));
      let a = 0, b = 0;
      for (const r of st.parsed.rows.slice(0, 100)) { const k = squash(r.name ?? r.key); if (mv.has(k)) a++; if (spp.has(k)) b++; }
      if (a > b && a >= 3) st.target = 'moves'; else if (b > a && b >= 3) st.target = 'species';
    }
    st.mapping = guessMapping(st.parsed.columns, st.target);
    renderBody();
  }

  function mappingPanel() {
    const st = importState;
    const p = st.parsed;
    if (p.format === 'lines') {
      return h('section', { class: 'panel flat col' },
        h('p', null, `Read ${p.rows.length} learnset lines.`),
        h('div', { class: 'row' }, h('span', { class: 'spacer' }), h('button', { class: 'btn primary', onclick: doImport }, 'Import')));
    }
    const fields = Object.keys(TARGETS[st.target].fields);
    const colOpts = (sel) => [h('option', { value: '', selected: !sel }, '—'), ...p.columns.map((c) => h('option', { value: c, selected: c === sel }, c)),
      sel && sel.endsWith('#2') ? h('option', { value: sel, selected: true }, `${sel.slice(0, -2)} (second part)`) : null];
    const preview = p.rows.slice(0, 6);
    const lead = p.format === 'learnsets'
      ? `Read ${p.rows.length} level-up moves for ${new Set(p.rows.map((r) => r.species)).size} species from a Showdown learnsets file (each species uses the newest generation it appears in). Species not in your list are skipped.`
      : `Read ${p.rows.length} rows with ${p.columns.length} columns (${p.format}). Check which column feeds each field:`;
    return h('section', { class: 'panel flat col' },
      h('p', null, lead),
      h('div', { class: 'map-grid' }, fields.map((f) => h('label', { class: 'field' }, h('span', null, f),
        h('select', { onchange: (e) => { st.mapping[f] = e.target.value || undefined; renderBody(); } }, colOpts(st.mapping[f]))))),
      h('div', { class: 'scroll', style: { maxHeight: '260px' } }, h('table', { class: 'grid' },
        h('thead', null, h('tr', null, fields.filter((f) => st.mapping[f]).map((f) => h('th', null, f)))),
        h('tbody', null, preview.map((r) => h('tr', null, fields.filter((f) => st.mapping[f]).map((f) => {
          const col = st.mapping[f];
          let v = col.endsWith('#2') ? String(Array.isArray(r[col.slice(0, -2)]) ? r[col.slice(0, -2)][1] ?? '' : (String(r[col.slice(0, -2)] ?? '').split(/\s*[/,|&]\s*/)[1] ?? '')) : r[col];
          if (Array.isArray(v)) v = v.join(' / ');
          return h('td', null, String(v ?? ''));
        })))))),
      h('div', { class: 'row' }, h('span', { class: 'spacer' }), h('button', { class: 'btn primary', onclick: doImport }, `Import ${p.rows.length} rows`)));
  }

  function doImport() {
    const st = importState;
    try {
      st.report = applyImport(draft, st.target, st.parsed.rows, st.mapping, { mode: st.mode, speciesId: st.speciesId, mainOnly: (st.target === 'species' || st.target === 'moves') && st.mainOnly });
      if (st.text.length > 200000) st.text = ''; // done with the big file
      touch();
      sfx('heal');
    } catch (e) { toast(`Import failed: ${e.message}`, 'err'); }
    renderBody();
    body.querySelector('.import > section:last-child')?.scrollIntoView({ block: 'nearest' });
  }

  // ---------------- rules & files ----------------
  function filesTab() {
    const problems = validateDataset(clone(draft));
    const r = draft.rules;
    r.needsDecayPerHour = r.needsDecayPerHour || {};
    return h('div', { class: 'lab-two' },
      h('section', { class: 'col' },
        h('h2', null, 'Data set'),
        h('div', { class: 'form-grid' }, field('Name', bind(draft.meta, 'name')), field('Author', bind(draft.meta, 'author'))),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn', onclick: () => app.platform.exportFile(`${slug(draft.meta.name) || 'dataset'}.json`, JSON.stringify(draft, null, 1)) }, 'Export to file'),
          h('button', { class: 'btn', onclick: async () => {
            const f = await app.platform.importFile([{ name: 'Data set', extensions: ['json'] }]);
            if (!f) return;
            try { importState.text = f.text; importState.target = 'species'; tab = 'import'; readPaste(); renderBar(); } catch (e) { toast(e.message, 'err'); }
          } }, 'Import a file'),
          h('button', { class: 'btn danger', onclick: async () => {
            if (!(await confirmDialog('Load the starter set?', 'Replaces the Data Lab with the original placeholder creatures. Save afterwards to keep it.', { ok: 'Load', danger: true }))) return;
            draft = createDefaultDataset(); touch(); renderBody();
          } }, 'Load starter set'),
          h('button', { class: 'btn danger', onclick: async () => {
            if (!(await confirmDialog('Start from empty?', 'Removes every species, move, type and nature so you can paste your own. Growth curves, items, formulas and rules stay. Creatures you already have keep their species numbers and come back once a species with that number exists. Nothing changes until you save.', { ok: 'Empty it', danger: true }))) return;
            draft.species = []; draft.moves = []; draft.types = []; draft.temperaments = []; draft.typeChart = {};
            touch(); renderBody();
          } }, 'Start from empty')),
        h('h2', null, 'Stat names'),
        h('div', { class: 'form-grid six' }, STAT_KEYS.map((k) => field(k, bind(draft.statLabels, k)))),
        h('h2', null, problems.length ? `${problems.length} problem${problems.length > 1 ? 's' : ''}` : 'No problems found'),
        problems.length ? h('ul', { class: 'warn-list scroll', style: { maxHeight: '260px' } }, problems.map((p) => h('li', null, p))) : h('p', { class: 'dim' }, 'Every type, move, growth rate and formula checks out.')),
      h('section', { class: 'col' },
        h('h2', null, 'Rules'),
        h('div', { class: 'form-grid' },
          field('Max level', bind(r, 'maxLevel', { type: 'number', min: 1, max: 255 })),
          field('Party size', bind(r, 'partySize', { type: 'number', min: 1, max: 6 }), 'Battles use up to 6'),
          field('Max friendship', bind(r, 'maxFriendship', { type: 'number', min: 1, max: 255 })),
          field('Max genes per stat', bind(r, 'maxGenes', { type: 'number', min: 0, max: 255 })),
          field('Max effort per stat', bind(r, 'maxEffortPerStat', { type: 'number', min: 0, max: 255 })),
          field('Max effort total', bind(r, 'maxEffortTotal', { type: 'number', min: 0 })),
          field('Steps counted per day', bind(r, 'walkDailyStepCap', { type: 'number', min: 0 })),
          field('Steps per item roll', bind(r, 'stepsPerFind', { type: 'number', min: 50 })),
          field('Care friendship per day', bind(r, 'careFriendshipPerDay', { type: 'number', min: 0 }))),
        h('p', { class: 'micro dim' }, 'Walking, flying and swimming are set for each species now: Species tab → Movement.'),
        h('h2', null, 'Needs drop per hour'),
        h('div', { class: 'form-grid' }, ['fullness', 'joy', 'energy', 'hygiene'].map((k) => field(k === 'hygiene' ? 'tidiness' : k, bind(r.needsDecayPerHour, k, { type: 'number', min: 0, step: 0.5 }))))));
  }

  function renderBody() {
    const tabs = { species: speciesTab, moves: movesTab, abilities: abilitiesTab, types: typesTab, growth: growthTab, formulas: formulasTab, items: itemsTab, import: importTab, files: filesTab };
    mount(body, tabs[tab]());
  }

  renderBar();
  renderBody();
  return {
    el,
    update: () => { if (!dirty) { draft = clone(app.dataset); renderBar(); renderBody(); } },
    art: () => {},
  };
}
