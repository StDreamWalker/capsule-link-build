// Moving a creature anywhere from one place, and seeing where everyone is.
//
//   openMoveTo(app, c, { move })   "Move …" — every place they can go, with what happens and why not when they can't:
//                                   party, free range, a PC box, the desktop, any paired phone, the ball on the dock.
//                                   Away on a phone? Ask for them back. In a ball? It says how to bring them home.
//   openTracker(app, { move })     "Where is everyone?" — everyone grouped by where they are right now, with the
//                                   state of anything on its way (sent to a phone and not picked up yet, asked back…)
//   whereLabel(app, c)              one line saying where they are
import { h, toast, dialog } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { sfx } from '../../../../shared/ui/audio.js';
import { displayName, firstFreeBoxSlot, toggleBuddy, isDesktopBuddy, capsuleName, list } from '../../../../shared/engine/index.js';

const ago = (t) => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : m < 1440 ? `${Math.round(m / 60)} h ago` : `${Math.round(m / 1440)} d ago`; };
const phoneName = (app, id) => app.save.devices?.[id]?.name ?? 'your phone';

/** Where they are, in a few words, with anything in progress. */
export function whereLabel(app, c) {
  const L = c.location ?? {};
  if (isDesktopBuddy(app.save, c.uid)) return 'Out on your desktop';
  if (L.kind === 'party') return 'In your party';
  if (L.kind === 'ranch') return 'Out on the free range';
  if (L.kind === 'box') return `In ${app.save.boxes?.[L.box]?.name ?? 'a PC box'}`;
  if (L.kind === 'capsule') return `Inside the ball “${capsuleName(app.save, L.tag)}”`;
  if (L.kind === 'phone') {
    const p = phoneName(app, L.device);
    if (L.recall) return `Coming back from ${p} (next time it syncs)`;
    if (L.pending) return `On its way to ${p} (arrives when it syncs${L.sentAt ? ` · sent ${ago(L.sentAt)}` : ''})`;
    return `With ${p}`;
  }
  return 'Somewhere';
}

/** Every place they could go from here: [{ key, icon, label, detail, ok, run }]. */
function destinations(app, c, move) {
  const name = displayName(app.idx, c), L = c.location ?? {}, out = [];
  const away = L.kind === 'phone' || L.kind === 'capsule', pet = isDesktopBuddy(app.save, c.uid);
  const partyN = list(app.save).filter((x) => x.location?.kind === 'party').length, size = app.idx.ds.rules.partySize;
  if (L.kind === 'phone') {
    out.push({ key: 'recall', icon: '📲', label: L.recall ? 'Already asked to come back' : `Ask ${phoneName(app, L.device)} to send them back`, ok: !L.recall,
      detail: L.pending ? 'The phone hasn’t picked them up yet, so they come straight back.' : 'They come home the next time the phone syncs (it does when the app opens). Nothing they did on walks is lost.',
      run: () => {
        if (L.pending) { app.commit((s) => { const x = s.creatures[c.uid]; const back = x.location.from; x.location = back && back.kind !== 'phone' && back.kind !== 'capsule' ? back : firstFreeBoxSlot(s) ?? { kind: 'ranch' }; }, 'transfer'); toast(`${name} stayed home.`, 'ok'); return; }
        app.commit((s) => { s.creatures[c.uid].location = { ...s.creatures[c.uid].location, recall: true, recallAt: Date.now() }; }, 'transfer'); toast(`Asked for ${name} back. They’ll come home when the phone next syncs.`, 'ok');
      } });
    return out;
  }
  if (L.kind === 'capsule') {
    out.push({ key: 'ball', icon: '⚪', label: 'Bring them out of the ball', ok: false, detail: `Put “${capsuleName(app.save, L.tag)}” on the dock (Dock tab), then press Let out.` });
    return out;
  }
  out.push({ key: 'party', icon: '⭐', label: 'Party', ok: L.kind !== 'party' && partyN < size, detail: L.kind === 'party' ? 'Already here.' : partyN >= size ? `The party is full (${size}). Move someone out first.` : 'Battles with you, and comes along to the phone’s battles.', run: () => move(c.uid, { kind: 'party' }) });
  out.push({ key: 'ranch', icon: '🌳', label: 'Free range', ok: L.kind !== 'ranch', detail: L.kind === 'ranch' ? 'Already here.' : 'Roams the R.A.N.C.H. with the others: plays, makes friends, finds things.', run: () => move(c.uid, { kind: 'ranch' }) });
  out.push({ key: 'box', icon: '📦', label: 'A PC box', ok: L.kind !== 'box' && !!firstFreeBoxSlot(app.save), detail: L.kind === 'box' ? 'Already in a box.' : firstFreeBoxSlot(app.save) ? 'Rests in the first free box slot.' : 'Every box is full.', run: () => { const to = firstFreeBoxSlot(app.save); if (to) move(c.uid, to); } });
  if (!c.egg) out.push({ key: 'desk', icon: '🖥️', label: pet ? 'Call back from the desktop' : 'The desktop', ok: true, detail: pet ? 'Comes back in from your desk.' : 'Walks about on top of your windows while you work (up to six at once).',
    run: () => { let r; app.commit((s) => { r = toggleBuddy(s, c.uid, !pet); }); if (r && r.ok === false) { toast(r.reason ?? 'Couldn’t do that.', 'err'); return; } sfx('warp'); toast(pet ? `${name} came back in.` : `${name} hopped out onto your desktop.`, 'ok'); } });
  const phones = Object.entries(app.save.devices ?? {});
  if (!phones.length) out.push({ key: 'phone', icon: '📱', label: 'A phone', ok: false, detail: 'No phone is paired yet. Pair one in the Link tab first.' });
  for (const [id, d] of phones) {
    out.push({ key: `phone:${id}`, icon: '📱', label: d.name ?? 'Phone', ok: !c.egg || true, detail: `Goes on walks with you. Arrives the next time ${d.name ?? 'the phone'} syncs (open the app there)${d.lastSeen ? ` · last seen ${ago(d.lastSeen)}` : ''}.`,
      run: () => {
        app.commit((s) => { const x = s.creatures[c.uid]; if (isDesktopBuddy(s, c.uid)) toggleBuddy(s, c.uid, false); x.location = { kind: 'phone', device: id, from: x.location, pending: true, sentAt: Date.now() }; }, 'transfer');
        sfx('transfer'); toast(`${name} is on the way to ${d.name ?? 'your phone'}. Open the app there to pick them up.`, 'ok');
      } });
  }
  const dock = app.dockCtl?.current;
  const ballReady = !!(dock?.info && !dock.error);
  out.push({ key: 'ball', icon: '⚪', label: ballReady ? `The ball on the dock (“${capsuleName(app.save, dock.tag?.uid ?? dock.info?.uid)}”)` : 'A ball', ok: ballReady && !away,
    detail: ballReady ? 'Goes inside it, ready to carry about or walk with (the ball counts steps).' : 'Put a ball on the dock first (or open the virtual one in the Dock tab).',
    run: () => app.dockCtl.send(c.uid, 'walk') });
  return out;
}

/** "Move …": choose where they go. */
export async function openMoveTo(app, c, { move } = {}) {
  const name = displayName(app.idx, c);
  const rows = destinations(app, c, move ?? ((uid, to) => app.commit((s) => { s.creatures[uid].location = to; }, 'move')));
  const pick = await dialog(`Move ${name}`, (close) => h('div', { class: 'col move-to' },
    h('div', { class: 'row', style: { gap: '10px', alignItems: 'center' } }, spriteCanvas(app.bank, c, { scale: 2 }), h('div', { class: 'col' }, h('b', null, name), h('span', { class: 'dim' }, `Now: ${whereLabel(app, c)}`))),
    h('div', { class: 'col', style: { gap: '6px', maxHeight: '60vh', overflow: 'auto', padding: '2px' } }, rows.map((r) => h('button', {
      class: `btn choose-row ${r.ok ? '' : 'off'}`, disabled: !r.ok, style: { justifyContent: 'flex-start', minHeight: '56px', opacity: r.ok ? 1 : 0.55 }, onclick: () => close(r),
    }, h('span', { style: { fontSize: '22px', width: '32px', textAlign: 'center' } }, r.icon), h('span', { class: 'grow col', style: { textAlign: 'left', gap: '2px' } }, h('span', null, r.label), h('span', { class: 'dim choose-detail' }, r.detail))))),
    h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(null) }, 'Cancel'))));
  if (pick?.run) { try { await pick.run(); } catch (e) { toast(String(e?.message ?? e), 'err'); } }
  return pick?.key ?? null;
}

/** "Where is everyone?": grouped by place, with anything in progress, and a Move button on each. */
export function openTracker(app, { move } = {}) {
  return dialog('Where is everyone?', (close) => {
    const groups = new Map();
    const add = (g, c) => { if (!groups.has(g)) groups.set(g, []); groups.get(g).push(c); };
    for (const c of list(app.save)) {
      const L = c.location ?? {};
      const g = isDesktopBuddy(app.save, c.uid) ? '🖥️ On the desktop' : L.kind === 'party' ? '⭐ Party' : L.kind === 'ranch' ? '🌳 Free range' : L.kind === 'box' ? '📦 PC boxes' : L.kind === 'capsule' ? '⚪ In balls' : L.kind === 'phone' ? `📱 ${phoneName(app, L.device)}` : 'Elsewhere';
      add(g, c);
    }
    const order = ['⭐ Party', '🌳 Free range', '🖥️ On the desktop'];
    const keys = [...groups.keys()].sort((a, b) => (order.indexOf(a) + 1 || 9) - (order.indexOf(b) + 1 || 9) || a.localeCompare(b));
    const moving = list(app.save).filter((c) => c.location?.pending || c.location?.recall);
    return h('div', { class: 'col', style: { gap: '10px' } },
      moving.length ? h('div', { class: 'panel', style: { padding: '8px 10px' } }, h('b', null, 'On the move'), moving.map((c) => h('div', { class: 'dim' }, `${displayName(app.idx, c)} — ${whereLabel(app, c)}`))) : null,
      h('div', { class: 'col', style: { gap: '10px', maxHeight: '62vh', overflow: 'auto' } }, keys.map((k) => h('div', { class: 'col', style: { gap: '4px' } },
        h('div', { class: 'btn-group-head' }, `${k} · ${groups.get(k).length}`),
        h('div', { class: 'row wrap', style: { gap: '6px' } }, groups.get(k).slice(0, 60).map((c) => h('button', {
          class: 'btn small', title: `${displayName(app.idx, c)}: ${whereLabel(app, c)}. Click to move.`, style: { display: 'flex', alignItems: 'center', gap: '4px' },
          onclick: () => { close(null); openMoveTo(app, c, { move }); },
        }, spriteCanvas(app.bank, c, { scale: 1 }), h('span', null, displayName(app.idx, c)), c.location?.pending ? h('span', { class: 'dim' }, ' · on its way') : c.location?.recall ? h('span', { class: 'dim' }, ' · coming back') : null)),
          groups.get(k).length > 60 ? h('span', { class: 'dim' }, `and ${groups.get(k).length - 60} more`) : null)))),
      h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(null) }, 'Close')));
  }, { wide: true });
}
