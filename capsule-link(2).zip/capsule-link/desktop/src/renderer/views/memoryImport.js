// Import from memory: a creature you remember, brought in by answering what PKHeX would show, one easy
// question at a time. Every answer is optional ("No idea" is always fine). As you go, the panel on the
// right narrows down who they are in your PC Storage System's data and shows how they'll look.
import { h, mount, dialog, toast } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { ballIcon } from '../../../../shared/ui/capsuleArt.js';
import { sfx } from '../../../../shared/ui/audio.js';
import {
  memoryQuestions, narrow, creatureFromMemory, placesFor, speciesAbilities, memoryConfidence,
} from '../../../../shared/engine/index.js';

const STAT_LABEL = { hp: 'HP', atk: 'Attack', def: 'Defense', spa: 'Sp. Atk', spd: 'Sp. Def', spe: 'Speed' };

/** Resolves to { creature, notes } or null. */
export function rememberDialog(app, { location }) {
  const qs = memoryQuestions(app.idx);
  const a = { types: [], moves: [], ivs: {}, evs: {}, markings: [], ribbons: [], memories: [] };
  let step = -1; // -1: the little intro tab
  const body = h('div', { class: 'remember-q col' });
  const side = h('aside', { class: 'remember-side col' });
  const nav = h('div', { class: 'actions' });
  const bar = h('div', { class: 'remember-progress' });

  const sp = () => (a.speciesId ? app.idx.species.get(a.speciesId) : null);
  const field = (label, el) => h('label', { class: 'field' }, h('span', null, label), el);
  const text = (key, ph = '', max = 40) => h('input', { type: 'text', value: a[key] ?? '', placeholder: ph, maxLength: max, oninput: (e) => { a[key] = e.target.value; renderSide(); } });
  const select = (key, opts, none = 'No idea') => h('select', { onchange: (e) => { a[key] = e.target.value || undefined; renderSide(); } },
    h('option', { value: '' }, none), opts.map(([v, l]) => h('option', { value: String(v), selected: String(a[key] ?? '') === String(v) }, l)));
  const chips = (key, opts) => h('div', { class: 'chip-row' }, opts.map(([v, l]) => h('button', { type: 'button', class: `chip-toggle ${a[key].includes(v) ? 'on' : ''}`, onclick: (e) => {
    a[key] = a[key].includes(v) ? a[key].filter((x) => x !== v) : [...a[key], v]; e.currentTarget.classList.toggle('on'); renderSide();
  } }, l)));

  function input(q) {
    switch (q.kind) {
      case 'hex': return field('PID', h('input', { type: 'text', value: a.pid ?? '', placeholder: 'e.g. 1A2B3C4D', maxLength: 8, class: 'mono', oninput: (e) => { a.pid = e.target.value.replace(/[^0-9a-f]/gi, '').toUpperCase(); e.target.value = a.pid; } }));
      case 'species': {
        const list = h('div', { class: 'remember-pick' });
        const draw = () => {
          const n = narrow(app.idx, { species: a.species, types: a.types, region: a.region });
          mount(list, n.list.slice(0, 24).map((s) => h('button', { type: 'button', class: `remember-sp ${a.speciesId === s.id ? 'on' : ''}`, title: s.name, onclick: () => { a.speciesId = s.id; a.species = s.name; draw(); renderSide(); sfx('blip'); } },
            spriteCanvas(app.bank, s.id, { scale: 1 }), h('span', null, s.name))),
          n.list.length > 24 ? h('span', { class: 'micro dim' }, `…and ${n.list.length - 24} more. Keep narrowing.`) : null,
          !n.list.length ? h('span', { class: 'micro dim' }, 'Nobody fits all of that. Loosen something.') : null);
          renderSide();
        };
        draw();
        return h('div', { class: 'col' },
          field('Name', h('input', { type: 'text', value: a.species ?? '', placeholder: 'Start typing…', oninput: (e) => { a.species = e.target.value; a.speciesId = null; draw(); } })),
          h('div', { class: 'row wrap' },
            field('Type', h('select', { onchange: (e) => { a.types = [e.target.value].filter(Boolean); a.speciesId = null; draw(); } }, h('option', { value: '' }, 'Any'), q.types.map((t) => h('option', { value: t, selected: a.types[0] === t }, t)))),
            field('Second type', h('select', { onchange: (e) => { a.types = [a.types[0], e.target.value].filter(Boolean); a.speciesId = null; draw(); } }, h('option', { value: '' }, 'Any'), q.types.map((t) => h('option', { value: t, selected: a.types[1] === t }, t)))),
            field('From which region', h('select', { onchange: (e) => { a.region = e.target.value || null; a.speciesId = null; draw(); } }, h('option', { value: '' }, 'Any'), q.regions.map((r) => h('option', { value: r, selected: a.region === r }, r))))),
          list);
      }
      case 'looks': return h('div', { class: 'row wrap' },
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!a.shiny, onchange: (e) => { a.shiny = e.target.checked; renderSide(); } }), 'Shiny ✦'),
        field('Gender', select('gender', [['male', 'Male ♂'], ['female', 'Female ♀'], ['none', 'Neither']])));
      case 'choice': return select(q.id, q.options, 'I don’t remember');
      case 'game': { // the games, or “Other”: a fan game, a ROM hack, anything — typed in, kept as written
        const other = h('input', { type: 'text', value: a.gameText ?? '', placeholder: 'e.g. Pokémon Radical Red, Insurgence, a fan game…', maxLength: 60, hidden: a.game !== 'other', oninput: (e) => { a.gameText = e.target.value; renderSide(); } });
        const sel = h('select', { onchange: (e) => { a.game = e.target.value || undefined; other.hidden = a.game !== 'other'; if (a.game === 'other') other.focus(); renderSide(); } },
          h('option', { value: '' }, 'Not sure'), q.options.map(([v, n]) => h('option', { value: v, selected: String(a.game) === String(v) }, n)), h('option', { value: 'other', selected: a.game === 'other' }, 'Other (type it in)…'));
        return h('div', { class: 'col', style: { gap: '6px' } }, sel, other);
      }
      case 'place': {
        const id = `places-${Math.random().toString(36).slice(2)}`;
        return h('div', { class: 'col' }, h('input', { type: 'text', list: id, value: a.place ?? '', placeholder: 'e.g. Route 1', maxLength: 60, oninput: (e) => { a.place = e.target.value; } }),
          h('datalist', { id }, placesFor(a.game).map((p) => h('option', { value: p }))));
      }
      case 'when': return h('div', { class: 'row wrap' }, field('When', text('when', 'e.g. summer 2006')), field('Their level then', h('input', { type: 'number', min: 1, max: 100, value: a.metLevel ?? '', oninput: (e) => { a.metLevel = e.target.value; } })));
      case 'ball': return h('div', { class: 'ball-pick' }, q.options.map(([n, name]) => h('button', { type: 'button', class: `ball-opt ${Number(a.ball) === n ? 'on' : ''}`, title: name, onclick: (e) => { a.ball = n; body.querySelectorAll('.ball-opt').forEach((x) => x.classList.remove('on')); e.currentTarget.classList.add('on'); renderSide(); } }, ballIcon(String(n), 24, 'closed'), h('span', null, name))));
      case 'ot': return h('div', { class: 'col' },
        h('div', { class: 'row wrap' },
          h('button', { type: 'button', class: 'btn small', onclick: () => { a.otName = app.save.trainer?.name ?? ''; render(); } }, 'They were mine from the start'),
          field('OT name', text('otName', 'e.g. Ash', 12)), field('ID No.', text('otId', 'e.g. 123456', 7))),
        field('Trainer was', select('otGender', [['male', 'a boy'], ['female', 'a girl']], 'Not sure')));
      case 'nature': {
        const abil = sp() ? speciesAbilities(sp()) : [];
        return h('div', { class: 'row wrap' }, field('Nature', select('nature', q.natures.map((n) => [n, n]))),
          abil.length ? field('Ability', select('ability', abil.map((x, i) => [i, `${x}${i === 2 ? ' (hidden)' : ''}`]))) : h('span', { class: 'micro dim' }, 'Pick who they are first to choose an ability.'));
      }
      case 'number': return h('input', { type: 'number', min: q.min, max: q.max, value: a[q.id] ?? '', oninput: (e) => { a[q.id] = e.target.value; renderSide(); } });
      case 'moves': {
        const learn = new Set((sp()?.learnset ?? []).map((l) => l.move ?? l.id ?? l));
        const all = [...app.idx.moves.values()].sort((x, y) => (learn.has(y.id) - learn.has(x.id)) || x.name.localeCompare(y.name));
        const id = `moves-${Math.random().toString(36).slice(2)}`;
        const chosen = h('div', { class: 'chip-row' });
        const draw = () => mount(chosen, a.moves.map((m) => h('button', { type: 'button', class: 'chip-toggle on', title: 'Remove', onclick: () => { a.moves = a.moves.filter((x) => x !== m); draw(); renderSide(); } }, `${app.idx.moves.get(m)?.name ?? m} ✕`)));
        draw();
        const inp = h('input', { type: 'text', list: id, placeholder: a.moves.length >= 4 ? 'Four is the most' : 'Type a move…', onchange: (e) => {
          const m = all.find((x) => x.name.toLowerCase() === e.target.value.trim().toLowerCase());
          if (m && a.moves.length < 4 && !a.moves.includes(m.id)) { a.moves.push(m.id); draw(); renderSide(); }
          e.target.value = '';
        } });
        return h('div', { class: 'col' }, inp, h('datalist', { id }, all.map((m) => h('option', { value: m.name }))), chosen);
      }
      case 'stats': return h('div', { class: 'remember-stats' },
        h('span', null), h('b', { class: 'micro' }, 'The judge said (IVs)'), h('b', { class: 'micro' }, 'Effort (EVs)'),
        Object.entries(STAT_LABEL).map(([k, l]) => [h('span', null, l),
          h('select', { onchange: (e) => { if (e.target.value === '') delete a.ivs[k]; else a.ivs[k] = Number(e.target.value); } }, h('option', { value: '' }, 'No idea'), q.judge.map(([v, t]) => h('option', { value: v, selected: String(a.ivs[k] ?? '') === v }, t))),
          h('input', { type: 'number', min: 0, max: 252, step: 4, value: a.evs[k] ?? '', placeholder: '0', oninput: (e) => { a.evs[k] = Number(e.target.value) || 0; } })]));
      case 'extras': return h('div', { class: 'col' },
        h('div', { class: 'row wrap' }, h('span', { class: 'dim' }, 'Markings'), chips('markings', q.markings.map(([v, s]) => [v, s]))),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!a.pokerus, onchange: (e) => { a.pokerus = e.target.checked; } }), 'Had Pokérus'),
        field('Tera Type', select('tera', q.tera.map((t) => [t, t]))));
      case 'ribbons': return h('div', { class: 'col' }, chips('ribbons', q.options.map((r) => [r, r])),
        h('input', { type: 'text', placeholder: 'Another one (type and press Enter)', onkeydown: (e) => { if (e.key === 'Enter' && e.target.value.trim()) { a.ribbons.push(e.target.value.trim()); e.target.value = ''; render(); } } }));
      case 'memories': return h('div', { class: 'col' }, [0, 1, 2].map((i) => h('input', { type: 'text', maxLength: 140, value: a.memories[i] ?? '', placeholder: ['e.g. beat the Champion together on the first try', 'e.g. evolved during a thunderstorm', 'e.g. always rode on my shoulder'][i], oninput: (e) => { a.memories[i] = e.target.value; } })));
      default: return text(q.id, q.placeholder ?? '');
    }
  }

  function renderSide() {
    const s = sp();
    const n = narrow(app.idx, { species: a.species, types: a.types, region: a.region, speciesId: a.speciesId });
    // before they know the kind, the bar fills as the list of who it could be shrinks (up to a fifth)
    const conf = memoryConfidence(a);
    const pct = s ? conf.pct : Math.round(20 * (1 - Math.max(0, n.list.length - 1) / Math.max(1, n.total - 1)));
    const line = !s ? (n.list.length ? `${n.list.length} of ${n.total} kinds could be them.` : 'Nobody fits yet.')
      : conf.stage === 'found' ? (conf.pct >= 100 ? 'Found them. No doubt about it.' : 'Found them!')
      : conf.stage === 'close' ? `Getting close… (${conf.pct}%) Every detail you remember makes sure it’s really them.`
      : `It’s a ${s.name}, but which one? (${conf.pct}%) Keep going: the PID, nickname, trainer and stats narrow it down.`;
    mount(side,
      h('div', { class: 'remember-tab' }, 'Searching the PC Storage System'),
      h('div', { class: `remember-meter ${conf.stage}` }, h('i', { style: { width: `${pct}%` } })),
      h('p', { class: 'micro dim' }, line),
      s ? h('div', { class: 'remember-card col' },
        h('div', { class: 'row' }, spriteCanvas(app.bank, { speciesId: s.id, shiny: !!a.shiny }, { scale: 2 }), a.ball ? ballIcon(String(a.ball), 22, 'closed') : null),
        h('b', null, `${a.nickname || s.name}${a.shiny ? ' ✦' : ''}${a.gender === 'male' ? ' ♂' : a.gender === 'female' ? ' ♀' : ''}`),
        h('span', { class: 'micro dim' }, [a.level ? `Lv. ${a.level}` : null, a.nature, a.otName ? `OT ${a.otName}` : null].filter(Boolean).join(' · ') || s.name),
        a.moves.length ? h('span', { class: 'micro' }, a.moves.map((m) => app.idx.moves.get(m)?.name).join(' · ')) : null,
        a.markings.length ? h('span', { class: 'micro' }, a.markings.map((m) => ({ circle: '●', triangle: '▲', square: '■', heart: '♥', star: '★', diamond: '◆' }[m])).join(' ')) : null)
        : h('div', { class: 'remember-pick small' }, n.list.slice(0, 12).map((x) => spriteCanvas(app.bank, x.id, { scale: 1 }))));
  }

  function render() {
    const q = qs[step];
    const groups = [...new Set(qs.map((x) => x.group))];
    mount(bar, groups.map((g) => h('span', { class: `rp-step ${q?.group === g ? 'on' : step > qs.findIndex((x) => x.group === g) ? 'done' : ''}` }, g)));
    if (step < 0) {
      mount(body,
        h('div', { class: 'remember-intro' },
          h('h2', null, 'Bring someone home from memory'),
          h('p', null, 'Lost the cartridge, the save, the old phone? Answer what you remember, the way PKHeX would show it, and they’ll come home to your PC Storage System.'),
          h('p', { class: 'dim' }, 'As you answer, the search narrows down who they are (watch the panel on the right). Every question has a “No idea”: skip anything you don’t know, we’ll fill the rest in sensibly.'),
          h('p', { class: 'micro dim' }, 'Afterwards you can send them to PKHeX as a .pk9 file. What only lives here (memories, mood, the journal) doesn’t fit in that file, but if you bring the same file back in, we’ll recognise them and keep it all.')));
      mount(nav, h('button', { class: 'btn', onclick: () => closeRef(null) }, 'Cancel'), h('button', { class: 'btn primary', onclick: () => { step = 0; render(); } }, 'Let’s start'));
      return;
    }
    if (step >= qs.length) {
      const s = sp() ?? narrow(app.idx, a).list[0];
      mount(body, h('h2', null, 'That’s everything'),
        s ? h('p', null, `${a.nickname || s.name}${a.speciesId ? '' : ` (our best guess: ${s.name})`} is ready to come home.`) : h('p', { class: 'err-text' }, 'We still need to know what kind they are. Go back to the first questions.'),
        h('p', { class: 'micro dim' }, 'You can change their nickname, moves and more later, like anyone else in your boxes.'));
      mount(nav, h('button', { class: 'btn', onclick: () => { step--; render(); } }, 'Back'),
        h('button', { class: 'btn primary', disabled: !s, onclick: () => {
          try {
            if (!a.speciesId && s) a.speciesId = s.id;
            const out = creatureFromMemory(app.idx, a, { trainer: app.save.trainer?.name ?? '', location });
            closeRef(out);
          } catch (e) { toast(e.message, 'err'); }
        } }, 'Bring them home'));
      return;
    }
    mount(body,
      h('div', { class: 'micro dim' }, `${q.group} · ${step + 1} of ${qs.length}`),
      h('h2', null, q.ask),
      q.hint ? h('p', { class: 'dim' }, q.hint) : null,
      input(q));
    mount(nav,
      h('button', { class: 'btn', onclick: () => { step--; render(); } }, 'Back'),
      h('span', { class: 'spacer' }),
      h('button', { class: 'btn ghost', onclick: () => { step++; render(); } }, q.id === 'pid' ? 'No idea, no sweat' : 'No idea'),
      h('button', { class: 'btn primary', onclick: () => { if (q.id === 'species' && !a.speciesId) { const n = narrow(app.idx, a); if (n.list.length === 1) a.speciesId = n.list[0].id; } step++; render(); } }, 'Next'));
    setTimeout(() => body.querySelector('input, select')?.focus(), 20);
  }
  let closeRef = () => {};
  return dialog('Import from memory', (close) => {
    closeRef = close;
    render(); renderSide();
    // every answer moves the bar
    for (const ev of ['input', 'change', 'click']) body.addEventListener(ev, () => setTimeout(renderSide, 0));
    return h('div', { class: 'remember col' }, bar, h('div', { class: 'remember-main' }, h('div', { class: 'col grow' }, body), side), nav);
  }, { wide: true });
}
