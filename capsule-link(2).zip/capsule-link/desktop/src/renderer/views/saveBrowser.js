// "Import from save…": a game's PC boxes and party, opened from its save file. Pick creatures to bring
// over (they stay in the game too, or move out of it), or put creatures that came from that kind of game
// back into an empty slot; then save the changed game file (keep a backup of the old one).
import { h, mount, toast, dialog, confirmDialog } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { sfx } from '../../../../shared/ui/audio.js';
import { matchSpecies, displayName, rawForSave, exportPkm, alreadyImported, ROMHACKS, hackInfoFor, hackRecord } from '../../../../shared/engine/index.js';

/** The first-time walk-through for bringing creatures over (from PKHeX files or a game save). */
export async function importTutorial(app, kind) {
  const key = kind === 'save' ? 'tutSaveImport' : 'tutPkhexImport';
  if (app.save.settings?.[key]) return true;
  const steps = kind === 'save' ? [
    ['Back up your save', 'Copy the save file somewhere safe first. If you take creatures out of the game or put some back, you’ll write a changed save over the old one.'],
    ['Get the save file', 'Emulators: the .sav next to the game (or File → Export save). Game Boy / GBA / DS cartridges: a save dumper or flashcart. 3DS: Checkpoint or JKSM (the file called "main"). Switch: JKSV (the folder’s "main" file).'],
    ['Open it here', 'Press Import from save… and pick the file. You’ll see the game’s boxes and party, as they are in the game.'],
    ['Choose who comes over', 'Click creatures to select them, then Bring over (they stay in the game too) or Move out of the game (they leave it: save the changed file afterwards).'],
    ['Putting them back', 'Creatures that came from that kind of game can go back into an empty slot (Put back…). Their memories here aren’t lost: bring them in again and they’re recognised.'],
    ['Put the save back', 'If you changed anything, press Save changed game file and copy it over the old save (same name), then load the game.'],
  ] : [
    ['Open the game in PKHeX', 'Open your save in PKHeX (File → Open), or use any PKHeX file you already have.'],
    ['Export the creature', 'Right-click a creature in a box → View, then File → Save as (or drag it out of PKHeX). You get a .pk3 … .pk9 file (.pk1 / .pk2 for the Game Boy games).'],
    ['Bring it in', 'Press Import from PKHeX… and pick one or more of those files. Older games kept less, so you may be asked a few friendly questions (all optional).'],
    ['Going back', 'Send to PKHeX… makes a file PKHeX opens. Memories and moods live only here, and come back when the same file returns.'],
  ];
  const ok = await dialog(kind === 'save' ? 'Bringing creatures over from a game save' : 'Bringing creatures over from PKHeX', (close) => h('div', { class: 'col' },
    h('ol', { class: 'tut-steps' }, steps.map(([t, d]) => h('li', null, h('b', null, t), h('span', { class: 'dim' }, d)))),
    h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(false) }, 'Not now'), h('button', { class: 'btn primary', onclick: () => close(true) }, 'Got it — pick the file'))), { wide: true });
  if (ok) app.commit((s) => { s.settings[key] = true; }, 'settings', { quiet: true });
  return !!ok;
}

/** What Import from save can and can't do, shown each time it's pressed (until "don't show again"). */
export const SAVE_SUPPORT = {
  missing: [
    ['Let’s Go, Pikachu! / Let’s Go, Eevee!', 'Not supported yet: its saves are recognised but not opened. In PKHeX, export the creatures and Convert them to .pk8, then use Import from PKHeX….'],
    ['Legends: Arceus', 'Not supported yet. In PKHeX, export the creatures (.pa8) and Convert them to .pk8 or .pk9 first.'],
    ['Legends: Z-A', 'Not supported yet.'],
    ['Korean Gold / Silver', 'Not supported yet (Japanese and international Gold, Silver and Crystal are).'],
  ],
  partial: [
    ['Putting creatures back', 'Every supported game can be written, but a game only takes back creatures that came from a game of its own generation. Scarlet/Violet can also take new ones made here.'],
    ['DS saves', 'Plain .sav, DeSmuME .dsv, Action Replay .duc and 1 MB dumps open. NO$GBA saves need exporting as a raw .sav first.'],
    ['3DS and Switch', 'Use the file called "main" from Checkpoint, JKSM, JKSV or Citra/Azahar. Sun/Moon and Ultra Sun/Ultra Moon are re-signed the way PKHeX does it.'],
    ['Side games', 'Colosseum, XD and Battle Revolution (GameCube/Wii), Stadium, Ranch, Bank and HOME aren’t opened here; PKHeX can export their creatures.'],
  ],
  hack: 'ROM hacks (Unbound, Radical Red, Emerald Seaglass, ROWE and other GBA hacks) keep Pokémon their own way, and Capsule Link reads them by working that format out. Their Pokémon come over fine, but may not go back into the hack exactly as they were, and only species the hack has can go in. Make a backup of the hack’s .sav before you change anything, and keep it somewhere safe.',
};
export async function importNotice(app) {
  // shown every time, kept short: what opens, what doesn't, and the one warning that matters
  const ok = await dialog('Before you open a save', (close) => h('div', { class: 'col save-notice' },
    h('p', { class: 'sn-row' }, h('span', { class: 'sn-ic ok', 'aria-hidden': 'true' }, '✓'), h('span', null, h('b', null, 'Opens: '), 'every main game, Red/Blue to Scarlet/Violet.')),
    h('p', { class: 'sn-row' }, h('span', { class: 'sn-ic no', 'aria-hidden': 'true' }, '✕'), h('span', null, h('b', null, 'Not yet: '), SAVE_SUPPORT.missing.map(([t]) => t).join(', '), '.')),
    h('p', { class: 'sn-row hack' }, h('span', { class: 'sn-ic warn', 'aria-hidden': 'true' }, '⚠'), h('span', null, h('b', null, 'ROM hacks: '), 'back up the .sav first. Their Pokémon may not go back exactly as they were.')),
    h('details', { class: 'sn-more' }, h('summary', null, 'Which file to pick'),
      h('ul', { class: 'support-list' }, SAVE_SUPPORT.partial.map(([t, d]) => h('li', null, h('b', null, t), ' ', h('span', { class: 'dim' }, d))))),
    h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(false) }, 'Cancel'), h('button', { class: 'btn primary', autofocus: true, onclick: () => close(true) }, 'Pick a save file'))));
  return !!ok;
}

/**
 * Show a game save's boxes. onBring(items, { fromSave }) brings [{ name, pk }] in (boxes.js does the rest);
 * the dialog stays open so you can keep going.
 */
export async function browseSave(app, sav, fileName, { onBring, reopen = null }) {
  let box = 0, picked = new Set(); // keys "box:slot" (-1 = party)
  let gameChoice = sav.romhack ?? 'auto';
  const key = (b, s) => `${b}:${s}`;
  const spriteOf = (e) => {
    const sp = matchSpecies(app.idx, e.pk).species;
    return sp ? spriteCanvas(app.bank, sp.id, { scale: 1 }) : h('span', { class: 'sb-unknown' }, '?');
  };
  const label = (e) => e.pk.nickname || matchSpecies(app.idx, e.pk).species?.name || (e.pk.national ? `#${e.pk.national}` : `? (#${e.pk.speciesInternal})`);
  const speciesOf = (e) => matchSpecies(app.idx, e.pk).species?.name ?? (e.pk.national ? `#${e.pk.national}${e.pk.formName ? ` (${e.pk.formName})` : ''}` : `unknown (${e.pk.gameName ?? 'game'} #${e.pk.speciesInternal})`);
  // ROM hacks keep Pokémon their own way: say which game this is from and the save is read again that way
  const gamePicker = () => (reopen && sav.gen === 3 ? h('label', { class: 'row', title: 'ROM hacks keep their Pokémon differently from the official games. If the species look wrong, pick the game this save is from.' },
    h('span', { class: 'dim' }, 'Game:'),
    h('select', { onchange: (e) => {
      const v = e.target.value;
      const next = reopen(v === 'auto' ? undefined : v);
      if (!next?.ok) { toast(next?.error ?? 'That save can’t be read as that game.', 'err'); e.target.value = gameChoice; return; }
      gameChoice = v; sav = next; box = 0; picked.clear(); sfx('blip'); render();
    } },
      h('option', { value: 'auto', selected: gameChoice === 'auto' }, 'Work it out'),
      h('option', { value: 'vanilla', selected: gameChoice === 'vanilla' }, 'An official game (Ruby, Sapphire, Emerald, FireRed, LeafGreen)'),
      ROMHACKS.map((x) => h('option', { value: x.id, selected: gameChoice === x.id }, x.name)))) : null);
  const here = (e) => alreadyImported(app.save, e.pk);
  return dialog(`${sav.game} · ${sav.trainer?.name || 'Trainer'}`, (close) => {
    const root = h('div', { class: 'col sb' });
    const render = () => {
      const slots = box < 0 ? sav.party : sav.boxes[box].slots;
      const total = sav.boxes.reduce((n, b) => n + b.slots.filter(Boolean).length, 0);
      mount(root,
        h('div', { class: 'row wrap' },
          h('select', { onchange: (e) => { box = Number(e.target.value); render(); } },
            h('option', { value: -1, selected: box < 0 }, `Party (${sav.party.filter(Boolean).length})`),
            sav.boxes.map((b, i) => h('option', { value: i, selected: i === box }, `${b.name} (${b.slots.filter(Boolean).length})`))),
          h('span', { class: 'dim grow' }, `${sav.game} · ${total} in the PC · ${fileName}`),
          gamePicker(),
          sav.changed ? h('span', { class: 'chip warn' }, 'changed — save the file') : null),
        h('div', { class: `sb-grid ${box < 0 ? 'party' : ''}` }, slots.map((e, s) => {
          if (!e) return h('div', { class: 'sb-slot empty' });
          const k = key(box, s);
          const dup = here(e);
          return h('button', { class: `sb-slot ${picked.has(k) ? 'on' : ''} ${dup ? 'dup' : ''} ${e.pk.speciesUnsure ? 'unsure' : ''}`, title: `${label(e)} · ${speciesOf(e)} · Lv. ${levelOf(e)}${e.pk.shiny ? ' · shiny' : ''}${dup ? ' · already here' : ''}${e.pk.speciesUnsure ? ' · species not known: you’ll be asked which it is' : ''}`, onclick: () => { picked.has(k) ? picked.delete(k) : picked.add(k); sfx('blip'); render(); } },
            spriteOf(e), h('span', { class: 'sb-name' }, label(e)), e.pk.shiny ? h('span', { class: 'sb-shiny' }, '✦') : null, dup ? h('span', { class: 'sb-dup' }, '✓') : null);
        })),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn small', onclick: () => { slots.forEach((e, s) => { if (e) picked.add(key(box, s)); }); render(); } }, 'Select all here'),
          h('button', { class: 'btn small', disabled: !picked.size, onclick: () => { picked.clear(); render(); } }, 'Clear'),
          h('span', { class: 'grow dim' }, picked.size ? `${picked.size} selected` : 'Click creatures to select them.')),
        h('div', { class: 'actions wrap' },
          h('button', { class: 'btn', onclick: () => putBack() }, sav.canWrite ? 'Put back…' : 'Put back… (not for this game)'),
          h('button', { class: 'btn', disabled: !sav.changed, onclick: () => saveFile() }, 'Save changed game file'),
          h('span', { class: 'spacer' }),
          h('button', { class: 'btn', disabled: !picked.size, onclick: () => bring(false) }, 'Bring over (copy)'),
          h('button', { class: 'btn primary', disabled: !picked.size || !sav.canWrite || box < 0, title: box < 0 ? 'Move party members into a box in the game first' : sav.canWrite ? 'They leave the game; save the changed file afterwards' : sav.whyNot, onclick: () => bring(true) }, 'Move out of the game'),
          h('button', { class: 'btn', onclick: async () => { if (sav.changed && !(await confirmDialog('Unsaved changes', 'You took creatures out of (or put them into) this save but haven’t saved the changed game file. Close anyway? The game won’t see those changes.', { ok: 'Close anyway', danger: true }))) return; close(); } }, 'Done')));
    };
    async function bring(move) {
      const list = [...picked].map((k) => { const [b, s] = k.split(':').map(Number); return { b, s, e: (b < 0 ? sav.party : sav.boxes[b].slots)[s] }; }).filter((x) => x.e);
      if (!list.length) return;
      // ROM hacks keep Pokémon their own way: say so once per save before anything leaves it
      if (sav.romhack && !sav.hackWarned) {
        const ok = await confirmDialog('Coming from a ROM hack', `${sav.game} keeps its Pokémon its own way, and Capsule Link reads it by working that format out. They come over fine, but they may not go back into ${sav.game} exactly as they were (or at all, if something about them doesn’t fit the hack). If this save matters to you, make a backup copy of the .sav before you go on, and keep it somewhere safe. Pokémon from a hack get a ⚠ beside their name in their summary as a reminder.`, { ok: 'I have a backup, go on' });
        if (!ok) return;
        sav.hackWarned = true;
      }
      if (move && !(await confirmDialog('Move out of the game', `${list.length} creature${list.length > 1 ? 's' : ''} will leave ${sav.game} and come here. Save the changed game file afterwards and copy it over the old one (keep a backup).`, { ok: 'Move them' }))) return;
      const items = list.map((x) => ({ name: `${label(x.e)} (${sav.game})`, pk: { ...x.e.pk, gameName: x.e.pk.gameName ?? undefined } }));
      const res = await onBring(items, { fromSave: sav.game });
      const came = new Set(res?.arrived ?? []);
      if (move) {
        // take them out of the game, last slot first (Game Boy boxes shuffle down when one leaves)
        const out = list.filter((x, i) => came.has(i)).sort((a, b) => b.b - a.b || b.s - a.s);
        for (const x of out) sav.take(x.b, x.s);
        if (out.length) toast(`${out.length} moved out of ${sav.game}. Remember to save the changed game file.`, 'ok');
      }
      picked.clear();
      render();
    }
    async function putBack() {
      if (!sav.canWrite) { toast(sav.whyNot, 'err'); return; }
      // who can go: creatures that came from this kind of game (their own file), or — for Scarlet/Violet — anyone
      const all = Object.values(app.save.creatures).filter((c) => !c.egg);
      const tried = all.filter((c) => c.location?.kind !== 'game').map((c) => ({ c, file: fileFor(app, c, sav) }));
      const fits = tried.filter((x) => x.file && !x.file.blocked);
      // ROM hacks: who can't go, and why (a species the game doesn't have can't be sent to it)
      const blocked = tried.filter((x) => x.file?.blocked);
      if (!fits.length) { toast(sav.romhack ? `Nobody here can go into ${sav.game} (they need a species ${sav.game} has, with a national number in your data set).` : `Nobody here came from ${sav.format === 'pk9' ? 'Scarlet/Violet (or can be made into a file for it)' : `a ${sav.game}-generation game`} yet.`, 'err'); return; }
      const chosen = await dialog(`Put back into ${sav.game}`, (done) => {
        const sel = new Set();
        const body = h('div', { class: 'col' });
        const draw = () => mount(body,
          h('p', { class: 'dim' }, `They go into the first empty slots in ${box >= 0 ? sav.boxes[box].name : 'the boxes'}. Their memories here stay in Capsule Link and come back with them if you bring them in again.${sav.romhack ? ` Ones that came from ${sav.game} go back as they came, with the levels, moves, effort and friendship they gained here; others are written as ${sav.game} Pokémon (species, moves, genes, effort and level carried over). Only species ${sav.game} has can go.` : ''}`),
          blocked.length ? h('details', { class: 'micro dim' }, h('summary', null, `${blocked.length} can’t go into ${sav.game}`),
            h('ul', null, blocked.slice(0, 40).map(({ c, file }) => h('li', null, `${displayName(app.idx, c)}: ${file.blocked}`)))) : null,
          h('div', { class: 'sb-grid' }, fits.map(({ c }) => h('button', { class: `sb-slot ${sel.has(c.uid) ? 'on' : ''}`, onclick: () => { sel.has(c.uid) ? sel.delete(c.uid) : sel.add(c.uid); draw(); } },
            spriteCanvas(app.bank, c, { scale: 1 }), h('span', { class: 'sb-name' }, displayName(app.idx, c))))),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: true, id: 'sb-leave' }), 'They leave Capsule Link (moved, not copied)'),
          h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => done(null) }, 'Cancel'),
            h('button', { class: 'btn primary', disabled: !sel.size, onclick: () => done({ uids: [...sel], leave: body.querySelector('#sb-leave').checked }) }, `Put ${sel.size || ''} back`)));
        draw();
        return body;
      }, { wide: true });
      if (!chosen) return;
      let n = 0;
      for (const uid of chosen.uids) {
        const c = app.save.creatures[uid];
        const file = fileFor(app, c, sav);
        if (!file || file.blocked) { toast(`${displayName(app.idx, c)}: ${file?.blocked ?? 'can’t go into this game.'}`, 'err'); continue; }
        const spot = sav.firstEmpty(box >= 0 ? box : null) ?? sav.firstEmpty();
        if (!spot) { toast('The game’s boxes are full.', 'err'); break; }
        const r = sav.put(spot.box, spot.slot, file.bytes, file.ext);
        if (!r.ok) { toast(`${displayName(app.idx, c)}: ${r.reason}`, 'err'); continue; }
        if (file.notes?.length) toast(`${displayName(app.idx, c)}: ${file.notes.join(' ')}`, 'ok');
        n++;
        if (chosen.leave) app.commit((s) => { s.creatures[uid].location = { kind: 'game', game: sav.game, at: Date.now(), from: s.creatures[uid].location }; }, 'export', { quiet: true });
      }
      if (n) { sfx('access'); toast(`${n} put into ${sav.game}. Save the changed game file to keep it.`, 'ok'); }
      render();
    }
    function saveFile() {
      const bytes = sav.toBytes();
      const blob = new Blob([bytes], { type: 'application/octet-stream' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = fileName.replace(/(\.[^.]*)?$/, (ext) => ext || '') || 'main';
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      sfx('access');
      toast('Saved. Copy it over the old save (same file name), keeping a backup of the old one.', 'ok');
    }
    render();
    return root;
  }, { wide: true });
}
const levelOf = (e) => e.pk.statLevel || (e.pk.exp ? `~${Math.max(1, Math.min(100, Math.round(Math.cbrt(e.pk.exp))))}` : '?');

/** A creature's file in the format a save wants, or null. */
function fileFor(app, c, sav) {
  const format = sav.format;
  if (!c || c.location?.kind === 'game') return null;
  // a ROM hack: written the hack's own way (or exactly as it came, if it came from this hack)
  if (sav.romhack) {
    const i = hackInfoFor(app.idx, c, { trainer: sav.trainer?.name || app.save.trainer?.name, trainerId: ((sav.trainer?.sid ?? 0) << 16 | (sav.trainer?.tid ?? 0)) >>> 0 });
    if (!i.ok) return { blocked: i.reason };
    const rec = hackRecord(sav, i.info);
    return rec.ok ? { bytes: rec.bytes, ext: format, notes: rec.notes } : { blocked: rec.reason };
  }
  const raw = rawForSave(c);
  if (format === 'pk9' || format === 'pk8') {
    // Gen 8/9: write what changed here into the file (or make a fresh Scarlet/Violet one)
    if (raw && raw.ext !== format) return null;
    if (!raw && format !== 'pk9') return null;
    const r = exportPkm(app.idx, c);
    return r.ok && r.name.toLowerCase().endsWith(format) ? { bytes: r.bytes, ext: format } : null;
  }
  return raw && raw.ext === format ? raw : null;
}
