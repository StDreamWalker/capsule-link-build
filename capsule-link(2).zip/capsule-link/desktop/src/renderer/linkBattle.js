// In-app battles with a friend (any creatures: Showdown's, or your data sets' own). One app runs the battle
// (the one who invited), the other sees its side of it and chooses its moves; the two talk through a play
// room on your friends server. Each brings its own party at full health; nothing is won or lost but the battle.
import { h, mount, toast } from '../../../shared/ui/dom.js';
import { sfx } from '../../../shared/ui/audio.js';
import { loadShowdown, playWildBattle } from '../../../shared/ui/showdownWild.js';
import { battleKnows, battlePackage, wildTeams } from '../../../shared/engine/index.js';
import { spriteIdOf } from '../../../shared/ui/art.js';
import { showdownSettings } from '../../../shared/ui/showdownUi.js';

const toId = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');

// ---------- messages (big ones in parts: the server passes on up to 64 KB at a time) ----------
function channel(S, roomId) {
  const fns = new Set(), parts = new Map();
  const send = (data) => {
    const s = JSON.stringify(data);
    if (s.length < 48000) return S.client.roomSend(roomId, data);
    const id = Math.random().toString(36).slice(2), n = Math.ceil(s.length / 48000);
    for (let k = 0; k < n; k++) S.client.roomSend(roomId, { t: 'part', id, k, n, s: s.slice(k * 48000, (k + 1) * 48000) });
    return true;
  };
  const off = S.client.onRoom((m) => {
    if (m.id !== roomId) return;
    let d = m.data ?? {};
    if (d.t === 'part') {
      const p = parts.get(d.id) ?? []; p[d.k] = d.s; parts.set(d.id, p);
      if (p.filter((x) => x != null).length < d.n) return;
      parts.delete(d.id);
      try { d = JSON.parse(p.join('')); } catch { return; }
    }
    for (const f of fns) { try { f(d, m.from); } catch (e) { console.error(e); } }
  });
  return { send, on: (f) => { fns.add(f); return () => fns.delete(f); }, close: off };
}

// ---------- what each side brings ----------
function myTeam(app, SD) {
  const knows = battleKnows(SD, app.idx);
  const sp0 = app.idx.ds.species[0]?.id;
  const t = wildTeams(app.idx, app.save, { speciesId: sp0, level: 5, seed: 1 }, knows);
  // (a friendly battle: everyone at full health)
  const sets = t.team.map(({ hpLeft, ppLeft, ...set }) => set);
  // only the data set entries those sets use (the whole data set could be huge)
  const pkg = battlePackage(app.idx), used = new Set();
  for (const s of sets) { used.add(toId(s.species)); used.add(toId(s.ability)); for (const m of s.moves ?? []) used.add(toId(m)); }
  const spUsed = pkg.species.filter((x) => used.has(toId(x.name)));
  for (const x of spUsed) for (const a of x.abilities ?? []) used.add(toId(a));
  const sub = { types: pkg.types, species: spUsed, moves: pkg.moves.filter((x) => used.has(toId(x.name))), abilities: pkg.abilities.filter((x) => used.has(toId(x.name))) };
  return { sets, map: t.map, pkg: sub, left: t.left };
}
// small pictures of the team's creatures (so the other side sees them, even ones its data set doesn't have)
function teamPics(app, sets, map) {
  const out = {};
  for (const s of sets) {
    const c = app.save.creatures[map[s.name]?.uid]; if (!c) continue;
    const e = app.bank.get(spriteIdOf(c)); const img = e?.frames?.idle?.[0];
    if (!img || e.waiting) continue;
    const k = 96 / Math.max(img.width, img.height), cv = document.createElement('canvas');
    cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
    const x = cv.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(img, 0, 0, cv.width, cv.height);
    out[toId(s.species)] = cv.toDataURL('image/png');
  }
  return out;
}
const merge = (a, b) => {
  const one = (x, y) => { const seen = new Set(x.map((v) => toId(v.name))); return [...x, ...y.filter((v) => !seen.has(toId(v.name)))]; };
  return { types: one(a.types ?? [], b.types ?? []), species: one(a.species ?? [], b.species ?? []), moves: one(a.moves ?? [], b.moves ?? []), abilities: one(a.abilities ?? [], b.abilities ?? []) };
};
function battleCtx(app, extraSprites) {
  const st = app.save.settings ?? {};
  return {
    settings: st, idx: app.idx, bank: app.bank, resolve: (p) => app.textures[p.toLowerCase()] ?? null, trainer: app.save.trainer?.name ?? 'You',
    cardSprite: app.save.trainer?.card?.avatar?.sprite || '', sdAvatar: showdownSettings(app.save).avatar || '', sound: (st.battleSound ?? st.sound) !== false, volume: st.battleVolume ?? st.volume ?? 0.6,
    creatures: app.save.creatures, bag: [], extraSprites,
  };
}
function waiting(title, text, onCancel) {
  const scrim = h('div', { class: 'wb-scrim' });
  const box = h('div', { class: 'panel lb-wait' });
  const set = (t) => mount(box, h('div', { class: 'panel-title' }, h('h1', null, title)), h('p', { class: 'dim' }, t), h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: onCancel }, 'Cancel')));
  set(text); scrim.append(box); document.body.append(scrim);
  return { set, close: () => scrim.remove() };
}

/** Invite a friend to an in-app battle (you run it). */
export async function hostLinkBattle(app, S, friend) {
  let SD; try { SD = await loadShowdown(); } catch (e) { toast(e.message, 'err'); return; }
  const mine = myTeam(app, SD);
  if (!mine.sets.length) { toast('Nobody in your party can battle right now (heal them first, or add someone).', 'err'); return; }
  let room;
  try { room = (await S.client.openRoom('battle', [friend.username], 2)).room; } catch (e) { toast(e.message, 'err'); return; }
  sfx('access');
  const ch = channel(S, room.id);
  let started = false, choiceFn = null, forfeitFn = null;
  const offs = [];
  const quit = () => { offs.forEach((f) => f()); ch.close(); S.client.leaveRoom(room.id).catch(() => {}); w?.close(); };
  const w = waiting('In-app battle', `Waiting for ${friend.trainerName ?? friend.username} to accept…`, () => { quit(); toast('Battle invite cancelled.'); });
  offs.push(S.on((n) => { if (n.id === room.id && n.what === 'room-leave' && !started) { quit(); toast(`${friend.trainerName ?? friend.username} can’t battle right now.`, 'err'); } }));
  offs.push(ch.on(async (d) => {
    if (d.t === 'choice') { choiceFn?.(d.c); return; }
    if (d.t === 'forfeit') { forfeitFn?.(); return; }
    if (d.t !== 'team' || started) return;
    started = true; w.close();
    const guestSets = (d.sets ?? []).slice(0, 6);
    if (!guestSets.length) { toast('Your friend has nobody who can battle.', 'err'); quit(); return; }
    const custom = merge(battlePackage(app.idx), d.pkg ?? {});
    ch.send({ t: 'start', trainer: app.save.trainer?.name ?? 'Trainer', pics: teamPics(app, mine.sets, mine.map), pkg: custom });
    const remote = { send: (chunk) => ch.send({ t: 'chunk', s: chunk }), onChoice: (fn) => { choiceFn = fn; }, onForfeit: (fn) => { forfeitFn = fn; } };
    const teams = { team: mine.sets, map: mine.map, foe: guestSets[0], foeTeam: guestSets, foeTrainerName: String(d.trainer ?? friend.trainerName ?? 'Friend').slice(0, 24), foeAvatar: '', custom, remote, versus: true };
    try {
      const res = await playWildBattle(battleCtx(app, d.pics ?? {}), teams, { biome: 'stadium', seed: Date.now() });
      if (res?.won) { toast(`You beat ${teams.foeTrainerName}!`, 'ok'); app.commit((sv) => { sv.stats.friendWins = (sv.stats.friendWins ?? 0) + 1; }, 'stats', { quiet: true }); }
      else if (res && !res.ran) toast(`${teams.foeTrainerName} won this one. Good battle!`);
    } catch (e) { console.error(e); toast(`The battle stopped: ${e.message}`, 'err'); }
    ch.send({ t: 'end' });
    quit();
  }));
}

/** Accept a friend's in-app battle (they run it; you choose for your side). */
export async function joinLinkBattle(app, S, roomId, fromName = 'your friend') {
  let SD; try { SD = await loadShowdown(); } catch (e) { toast(e.message, 'err'); return; }
  const mine = myTeam(app, SD);
  if (!mine.sets.length) { toast('Nobody in your party can battle right now (heal them first, or add someone).', 'err'); return; }
  let room;
  try { room = (await S.client.joinRoom(roomId)).room; } catch (e) { toast(e.message, 'err'); return; }
  const ch = channel(S, room.id);
  const me = app.save.trainer?.name ?? 'Trainer';
  let started = false, chunkCb = null, closeCb = null, again = null;
  const buf = [];
  const offs = [];
  const quit = () => { clearInterval(again); offs.forEach((f) => f()); ch.close(); S.client.leaveRoom(room.id).catch(() => {}); w?.close(); };
  const w = waiting('In-app battle', `Getting ready with ${room.hostName ?? fromName}…`, () => quit());
  const hello = () => ch.send({ t: 'team', trainer: me, sets: mine.sets, pkg: mine.pkg, pics: teamPics(app, mine.sets, mine.map) });
  hello(); again = setInterval(() => { if (started) { clearInterval(again); return; } hello(); }, 3000);
  offs.push(S.on((n) => { if (n.id === room.id && n.what === 'room-closed') { if (closeCb) closeCb(); else { toast(`${room.hostName ?? fromName} left.`, 'err'); quit(); } } }));
  offs.push(ch.on(async (d) => {
    if (d.t === 'chunk') { if (chunkCb) chunkCb(d.s); else buf.push(d.s); return; }
    if (d.t === 'end') { setTimeout(() => closeCb?.(), 4000); return; }
    if (d.t !== 'start' || started) return;
    started = true; clearInterval(again); w.close();
    const online = {
      spectate: false, title: `Battle with ${d.trainer}`,
      onChunk(cb, onClose) { chunkCb = cb; closeCb = onClose; for (const c of buf.splice(0)) cb(c); },
      choose(choice) { ch.send({ t: 'choice', c: String(choice) }); },
      isMe: (name) => name === me,
      forfeit() { ch.send({ t: 'forfeit' }); },
      close() { /* (the room closes after) */ },
    };
    try {
      const res = await playWildBattle(battleCtx(app, d.pics ?? {}), { online, custom: d.pkg ?? null, map: mine.map, team: [], foe: null, versus: true }, { biome: 'stadium' });
      if (res?.won) { toast(`You beat ${d.trainer}!`, 'ok'); app.commit((sv) => { sv.stats.friendWins = (sv.stats.friendWins ?? 0) + 1; }, 'stats', { quiet: true }); }
    } catch (e) { console.error(e); toast(`The battle stopped: ${e.message}`, 'err'); }
    quit();
  }));
}
