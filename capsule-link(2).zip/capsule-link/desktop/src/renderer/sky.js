// Where you are, for the real sky: sunrise and sunset, weather and fog in the R.A.N.C.H. and for the
// desktop buddies. Found from a town name or this connection's rough location (to about 10 km), or sent
// over by the phone after a walk. Only the rounded position and the sky are kept.
import { setSky, getSky, meteoUrl, skyFromMeteo, skyRecord, setSkyFix } from '../../../shared/engine/index.js';

async function getJson(app, url) {
  const r = await app.platform.fetchUrl(url, 'text');
  if (!r?.ok) throw new Error(`The service answered ${r?.status ?? 'nothing'}.`);
  return JSON.parse(r.text);
}
function keep(app, sky) {
  setSky(sky);
  app.commit((s) => { s.sky = skyRecord(getSky()); }, 'settings', { quiet: true });
  return getSky();
}
/** Look up the weather and sun times for the saved place. */
export async function refreshSky(app) {
  const s = app.save.sky;
  if (!Number.isFinite(s?.lat) || !Number.isFinite(s?.lon)) return null;
  const j = await getJson(app, meteoUrl(s.lat, s.lon));
  return keep(app, { ...skyFromMeteo(j, s.lat, s.lon), place: s.place });
}
/** A town or city by name (Open-Meteo's place search). */
export async function locateByName(app, name) {
  const j = await getJson(app, `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(String(name).trim())}&count=1&language=en&format=json`);
  const p = j?.results?.[0];
  if (!p) throw new Error(`Couldn’t find “${name}”. Try a nearby town or city.`);
  const place = [p.name, p.admin1, p.country].filter(Boolean).join(', ');
  keep(app, { lat: p.latitude, lon: p.longitude, place, at: 0 });
  app.commit((s) => { s.sky = { ...(s.sky ?? {}), place }; }, 'settings', { quiet: true });
  await refreshSky(app).catch(() => null);
  return getSky();
}
/** A pin dropped on the map. */
export async function locateAt(app, lat, lon, place) {
  keep(app, { lat, lon, place, at: 0 });
  app.commit((s) => { s.sky = { ...(s.sky ?? {}), place }; }, 'settings', { quiet: true });
  await refreshSky(app).catch(() => null);
  return getSky();
}
/** Roughly where this internet connection is (city level). */
export async function locateByConnection(app) {
  const j = await getJson(app, 'https://ipwho.is/');
  if (!j || j.success === false || !Number.isFinite(j.latitude)) throw new Error('Couldn’t work out where this connection is. Type a town instead.');
  const place = [j.city, j.region, j.country].filter(Boolean).join(', ');
  keep(app, { lat: j.latitude, lon: j.longitude, place, at: 0 });
  app.commit((s) => { s.sky = { ...(s.sky ?? {}), place }; }, 'settings', { quiet: true });
  await refreshSky(app).catch(() => null);
  return getSky();
}
/** At start: what's saved (from here or the phone), then a fresh look every 30 minutes. */
export function startSky(app) {
  if (app.save.sky) setSky(app.save.sky);
  setSkyFix(app.save.settings?.skyFix ?? null);
  const tick = () => { if (Date.now() - (app.save.sky?.at ?? 0) > 25 * 60000) refreshSky(app).catch(() => {}); };
  setTimeout(tick, 4000);
  setInterval(tick, 30 * 60000);
}
