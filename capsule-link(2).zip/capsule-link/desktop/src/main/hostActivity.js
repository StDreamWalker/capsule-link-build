// What you're doing on the computer, roughly, for the desktop buddies: is music playing (Spotify, YouTube
// Music, anything that shows in the system's media controls), and is something fullscreen in front (a video
// player, a video in a browser, a game)? Buddies bob along with music notes, or gather in a corner and
// watch the screen with you.
//
// Windows: a small PowerShell loop reads the system media sessions and the foreground window every few
// seconds. Linux: `playerctl` (if installed) for music. macOS: nothing yet.
//   startHostActivity(onChange) → stop()      onChange({ music, video, game, app })
import { spawn, execFile } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

/** The last thing noticed, and any problem starting the watcher (for Settings). */
export const hostStatus = { state: null, error: '', at: 0, raw: null };

const PS = String.raw`
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
Add-Type @"
using System; using System.Runtime.InteropServices;
public class CLWin {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("user32.dll")] public static extern IntPtr MonitorFromWindow(IntPtr h, uint f);
  [DllImport("user32.dll")] public static extern bool GetMonitorInfo(IntPtr m, ref MONITORINFO mi);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [StructLayout(LayoutKind.Sequential)] public struct MONITORINFO { public int cbSize; public RECT rcMonitor; public RECT rcWork; public uint dwFlags; }
}
"@
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation` + '`' + String.raw`1' })[0]
function Await($op, $t) { $task = $asTask.MakeGenericMethod($t).Invoke($null, @($op)); $task.Wait(-1) | Out-Null; $task.Result }
$mgr = $null
try {
  [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime] | Out-Null
  $mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
} catch {}
while ($true) {
  $music = $false; $mediaVideo = $false; $app = ''
  if ($mgr) {
    foreach ($s in $mgr.GetSessions()) {
      $pi = $s.GetPlaybackInfo()
      if ("$($pi.PlaybackStatus)" -eq 'Playing') {
        $id = [string]$s.SourceAppUserModelId
        $kind = ''
        try { $kind = "$($pi.PlaybackType)" } catch {}
        if ($kind -eq 'Video' -or $kind -eq '2') { $mediaVideo = $true } else { $music = $true; $app = $id }
      }
    }
  }
  $fs = $false; $proc = ''
  $h = [CLWin]::GetForegroundWindow()
  if ($h -ne [IntPtr]::Zero) {
    $r = New-Object CLWin+RECT; [void][CLWin]::GetWindowRect($h, [ref]$r)
    $mi = New-Object CLWin+MONITORINFO; $mi.cbSize = 40
    [void][CLWin]::GetMonitorInfo([CLWin]::MonitorFromWindow($h, 2), [ref]$mi)
    $m = $mi.rcMonitor
    if ($r.L -le $m.L -and $r.T -le $m.T -and $r.R -ge $m.R -and $r.B -ge $m.B) { $fs = $true }
    $pid0 = 0; [void][CLWin]::GetWindowThreadProcessId($h, [ref]$pid0)
    try { $proc = (Get-Process -Id $pid0).ProcessName } catch {}
  }
  $o = @{ music = $music; mediaVideo = $mediaVideo; app = $app; fullscreen = $fs; proc = $proc; media = [bool]$mgr }
  [Console]::Out.WriteLine(($o | ConvertTo-Json -Compress))
  Start-Sleep -Seconds 4
}
`;

const VIDEO_APPS = /^(vlc|mpc-hc|mpc-hc64|mpc-be|mpv|potplayer|potplayermini64|wmplayer|video\.ui|microsoft\.media\.player|netflix|plex|kodi|stremio|disney|primevideo|mediaplayer)$/i;
const BROWSERS = /^(chrome|msedge|firefox|brave|opera|vivaldi|arc|librewolf)$/i;
const DESKTOP = /^(explorer|shellexperiencehost|searchhost|startmenuexperiencehost|lockapp|electron|capsule link|capsule-link)$/i;

export function classify(raw) {
  const proc = String(raw.proc ?? '');
  const fs = !!raw.fullscreen && !DESKTOP.test(proc);
  const video = (fs && (VIDEO_APPS.test(proc) || BROWSERS.test(proc) || raw.mediaVideo)) || (VIDEO_APPS.test(proc) && raw.mediaVideo);
  const game = fs && !video && !BROWSERS.test(proc);
  return { music: !!raw.music && !video, video: !!video, game: !!game, app: raw.app || proc };
}

export function startHostActivity(onChange) {
  let last = '', child = null, timer = null, stopped = false;
  const emit = (state) => { hostStatus.state = state; const k = JSON.stringify(state); if (k !== last) { last = k; try { onChange(state); } catch { /* ignore */ } } };
  if (process.platform === 'win32') {
    // the script goes in a file and runs with -File (piping it in breaks its multi-line parts)
    const file = path.join(os.tmpdir(), 'capsule-link-activity.ps1');
    try { fs.writeFileSync(file, '\ufeff' + PS, 'utf8'); } catch (e) { hostStatus.error = `Couldn't write the watcher script: ${e.message}`; }
    let fails = 0;
    const run = () => {
      if (stopped) return;
      child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', file], { windowsHide: true });
      let buf = '', err = '';
      child.stdout.on('data', (d) => {
        buf += d.toString();
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
          if (!line.startsWith('{')) continue;
          try { const raw = JSON.parse(line); hostStatus.raw = raw; hostStatus.at = Date.now(); hostStatus.error = raw.media === false ? 'Music: the system media controls couldn’t be read on this PC.' : ''; fails = 0; emit(classify(raw)); } catch { /* skip */ }
        }
      });
      child.stderr.on('data', (d) => { err = (err + d.toString()).slice(-600); });
      child.on('exit', (code) => { child = null; if (stopped) return; fails++; hostStatus.error = `The watcher stopped (${code ?? '?'}): ${err.trim().split('\n').slice(-2).join(' ')}`; timer = setTimeout(run, Math.min(300000, 15000 * fails)); });
      child.on('error', (e) => { child = null; hostStatus.error = `Couldn't start PowerShell: ${e.message}`; });
    };
    run();
  } else if (process.platform === 'linux') {
    const poll = () => {
      if (stopped) return;
      execFile('playerctl', ['status'], { timeout: 2000 }, (err, out) => {
        emit({ music: !err && /playing/i.test(String(out)), video: false, game: false, app: '' });
        if (!stopped) timer = setTimeout(poll, 5000);
      });
    };
    poll();
  }
  return () => { stopped = true; clearTimeout(timer); try { child?.kill(); } catch { /* gone */ } };
}

