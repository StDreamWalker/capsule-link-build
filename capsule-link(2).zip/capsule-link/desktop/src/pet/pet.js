// Desktop buddies: up to six creatures out on your desktop, over other windows. Walkers stroll along
// the bottom of the screen (just above the taskbar); fliers and levitators float about anywhere and
// land for a rest now and then. Pick one up and fling it (it falls and bounces; fliers glide back up),
// rub to pet, double-click to call, right-click for more. Friends hang out and play together, and
// now and then someone finds a little something lying around (click it to keep it).
// Pixel art stays crisp: pictures are only ever drawn at whole multiples of their size, never shrunk.
import { indexDataset, displayName, mood, speciesOf, tickNeeds, friendsOf, formsOf, currentFormId, movementOf } from '../../../shared/engine/index.js';
import { SpriteBank, spriteIdOf, EGG_ID } from '../../../shared/ui/art.js';
import { setBrand, brandText } from '../../../shared/ui/dom.js';
import { spriteBox, petFactor, sizeVariant, animRate } from '../../../shared/ui/creatureSize.js';
import { sfx, setSound, creatureCry, setCryResolver } from '../../../shared/ui/audio.js';
import { drawFaceBubble, MOOD_FACE } from '../../../shared/ui/emote.js';
import { typeFxOf } from '../../../shared/ui/yard.js';
import { warmLlm, llmReact } from '../../../shared/ui/localLlm.js';
// 3D mode: the same setting as the app (this computer), with your own model files if you've chosen a folder

const api = window.capsule;
const DPR = Math.max(1, Math.round(window.devicePixelRatio || 1));
// a 1 m creature is BASE screen pixels tall at size 1 (Settings → Desktop buddy → Size)
const BASE = 56;
const G = 2600; // gravity, device px/s²

let idx, bank, settings, canvas, ctx, W = 0, H = 0;
const actors = new Map();
const fx = [];
let gift = null, ball = null, menu = null, overAny = false, drag = null, last = 0;
let nextGift = Date.now() + (12 + Math.random() * 20) * 60000;
// what you're up to on the computer (from the app): music playing, a fullscreen video or game
let host = { music: false, video: false, game: false };
let aquarium = false; // only swimmers out: they swim about the screen like fish
// what's on: found by itself (a video or game full screen, music playing), or picked from their menu
let mode = null; // null | 'music' | 'movie'
const watching = () => mode === 'movie' || (mode !== 'music' && !!(host.video || host.game));
const musicOn = () => mode === 'music' || (mode !== 'movie' && !!host.music);
function setMode(m) { const was = watching(); mode = m; if (watching() !== was) for (const a of actors.values()) if (!['held', 'fall', 'gone', 'away', 'return'].includes(a.state)) { a.timer = 0; if (!watching() && a.state === 'watch') a.state = 'idle'; } if (m === 'music') for (const a of actors.values()) emote(a, 'note'); }

// ---------- data from the app ----------
async function boot() {
  await document.fonts?.load?.('10px "Capsule Pixel"').catch(() => {});
  canvas = document.getElementById('stage');
  ctx = canvas.getContext('2d');
  resize();
  apply(await api.petData());
  api.onPetData(apply);
  api.onPetHost?.((st) => { const was = watching(); host = st ?? host; if (watching() !== was) for (const a of actors.values()) if (!['held', 'fall', 'gone', 'away', 'return'].includes(a.state)) { a.timer = 0; if (!watching() && a.state === 'watch') a.state = 'idle'; } });
  bindPointer();
  requestAnimationFrame(loop);
  scheduleCry();
}
function resize() {
  W = Math.round(window.innerWidth * DPR); H = Math.round(window.innerHeight * DPR);
  canvas.width = W; canvas.height = H;
  for (const a of actors.values()) { a.x = Math.min(a.x, W - 20); if (!a.fly) a.y = ground(); }
}
window.addEventListener('resize', resize);
const ground = () => H - 2 * DPR;
/** Where they rest: the floor, or a little above it for hoverers. */
const floorOf = (a) => ground() - (a.hover && !a.egg ? Math.round((14 + (a.hoverPh ?? 0) * 8) * DPR * Math.sqrt(petSize())) : 0);
const petSize = () => Math.max(0.25, Math.min(3, Number(settings?.petSize) || 1));

function apply(data) {
  const list = data?.creatures ?? (data?.creature ? [data.creature] : []);
  settings = data?.settings ?? settings;
  if (!data?.dataset) return;
  setSound(settings.sound !== false, settings.volume ?? 0.6);
  if (!idx || data.dataset !== idx.ds) { idx = indexDataset(data.dataset); setBrand(idx.ds.brand); }
  const textures = data.textures ?? {};
  setCryResolver((p) => textures[p.toLowerCase()] ?? null);
  if (!bank) bank = new SpriteBank({ idx, resolveTexture: (p) => textures[p.toLowerCase()] ?? null });
  else { bank.setDataset(idx); bank.setResolver((p) => textures[p.toLowerCase()] ?? null); }
  const keep = new Set(list.map((c) => c.uid));
  for (const uid of [...actors.keys()]) if (!keep.has(uid)) actors.delete(uid);
  list.forEach((c, i) => {
    tickNeeds(idx, c);
    const sp = speciesOf(idx, c);
    const types = (sp?.types ?? []).flatMap((t) => [t, idx.types.get(t)?.name ?? t]).join(' ');
    const mv = movementOf(idx, sp, c);
    const fly = !c.egg && mv.float;
    let a = actors.get(c.uid);
    if (!a) {
      // everyone arrives on the ground (the beam looks right that way); fliers take off afterwards
      a = { uid: c.uid, x: W * (0.2 + 0.6 * Math.random()), y: ground(), sitting: fly, vx: 0, vy: 0, state: 'idle', timer: 2 + Math.random() * 2, flip: Math.random() < 0.5, ft: Math.random() * 4, hop: 0, appear: -0.3 * i, blink: 3, squash: 0 };
      actors.set(c.uid, a);
    }
    Object.assign(a, { c, sp, fly, hover: !c.egg && !!mv.hover, swim: !c.egg && !!mv.swim, hoverPh: a.hoverPh ?? Math.random(), name: displayName(idx, c), mood: mood(c).id, speciesId: spriteIdOf(c), sizeMul: sizeVariant(c).mult, speed: c.egg ? 0 : 60 + (sp?.baseStats?.spe ?? 50) * 1.4, fxKind: typeFxOf((sp?.types ?? []).flatMap((t) => [t, idx.types.get(t)?.name ?? ''])), friends: friendsOf(c).map((f) => f.uid), egg: !!c.egg });
  });
  // only swimmers out (eggs aside): the desktop becomes an aquarium
  const live = [...actors.values()].filter((a) => !a.egg);
  const was = aquarium;
  aquarium = live.length > 0 && live.every((a) => a.swim);
  for (const a of live) { a.swimmer = aquarium; if (aquarium) { a.fly = true; a.sitting = false; } }
  if (aquarium && !was) for (const a of live) if (a.state !== 'held') { a.state = 'idle'; a.timer = 0; }
}

// ---------- pictures: menu icons with a white border when there are some, else the sprite ----------
const outlinedCache = new WeakMap();
function outlined(img) {
  if (outlinedCache.has(img)) return outlinedCache.get(img);
  const c = document.createElement('canvas');
  c.width = img.width + 2; c.height = img.height + 2;
  const x = c.getContext('2d');
  // white silhouette around the edge, then the picture on top
  const sil = document.createElement('canvas'); sil.width = img.width; sil.height = img.height;
  const sx = sil.getContext('2d'); sx.drawImage(img, 0, 0); sx.globalCompositeOperation = 'source-in'; sx.fillStyle = '#ffffff'; sx.fillRect(0, 0, img.width, img.height);
  // the outline is see-through, so it softens the edge instead of a hard white line
  const ring = document.createElement('canvas'); ring.width = c.width; ring.height = c.height;
  const rx = ring.getContext('2d');
  for (const [dx, dy] of [[0, 1], [2, 1], [1, 0], [1, 2], [0, 0], [2, 2], [0, 2], [2, 0]]) rx.drawImage(sil, dx, dy);
  x.globalAlpha = 0.38; x.drawImage(ring, 0, 0); x.globalAlpha = 1;
  x.drawImage(img, 1, 1);
  outlinedCache.set(img, c);
  return c;
}
/** { img, k, box } for this frame: k is the whole-number scale. */
function look(a, anim, frame) {
  const e = bank.get(a.speciesId);
  const icon = e.ownFile?.icon && e.frames.icon;
  if (icon) {
    const img = outlined(icon[frame % icon.length]);
    const k = Math.max(1, Math.round(2 * petSize() * DPR * Math.sqrt(a.sizeMul)));
    return { img, k, box: boxOf(img) };
  }
  const list = e.frames[anim] ?? e.frames.idle;
  const img = list[((frame % list.length) + list.length) % list.length] ?? list[0];
  const box = spriteBox(e);
  const visiblePx = Math.max(1, (box.bottom - box.top) * img.height);
  const want = BASE * petSize() * DPR * (a.sizeMul ?? 1) * (a.speciesId === EGG_ID ? 0.5 : petFactor(idx.species.get(String(a.speciesId).split(':')[0])));
  return { img, k: Math.max(1, Math.round(want / visiblePx)), box };
}
const boxCache = new WeakMap();
function boxOf(img) {
  if (boxCache.has(img)) return boxCache.get(img);
  let box = { left: 0, right: 1, top: 0, bottom: 1 };
  try {
    const d = img.getContext('2d').getImageData(0, 0, img.width, img.height).data;
    let x0 = img.width, x1 = 0, y0 = img.height, y1 = 0;
    for (let y = 0; y < img.height; y++) for (let x = 0; x < img.width; x++) if (d[(y * img.width + x) * 4 + 3] > 20) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    if (x1 >= x0) box = { left: x0 / img.width, right: (x1 + 1) / img.width, top: y0 / img.height, bottom: (y1 + 1) / img.height };
  } catch { /* fine */ }
  boxCache.set(img, box);
  return box;
}

// ---------- life ----------
const night = () => { const h = new Date().getHours(); return h >= 23 || h < 6; };
function emote(a, face) { if (!a.egg) a.bubble = { face: face ?? MOOD_FACE[a.mood] ?? 'calm', t: 0, life: 2.6 }; }
function burst(a, kind, n = 6) {
  for (let i = 0; i < n; i++) fx.push({ kind, x: a.x + (Math.random() - 0.5) * 40 * DPR, y: a.y - a.h * (0.4 + Math.random() * 0.6), vx: (Math.random() - 0.5) * 120 * DPR, vy: -(40 + Math.random() * 120) * DPR, life: 1 + Math.random() * 0.7, c: Math.random() < 0.5 ? 0 : 1 });
}
function pick(a) {
  // what next? walk somewhere, visit a friend, rest, play with someone close, or (fliers) take off / land
  if (a.egg) { a.state = 'idle'; a.timer = 4 + Math.random() * 6; if (Math.random() < 0.4) a.hop = 0.6; return; }
  // napping: sleeps on until the nap ends (or you wake them: double-click, or right-click → Wake up)
  if (a.c?.sleep && a.c.sleep.until > Date.now()) { a.state = 'sleep'; a.timer = 10; a.sitting = true; return; }
  // something fullscreen in front (a video, a game): they gather in the corner and watch it with you
  if (watching()) {
    const order = [...actors.values()].filter((o) => !o.egg).sort((p, q) => (p.uid < q.uid ? -1 : 1)).indexOf(a);
    const step = 70 * DPR * Math.sqrt(petSize());
    a.state = 'watch'; a.tx = Math.max(30, W - 60 * DPR - order * step); a.timer = 8; a.sitting = !a.swimmer;
    return;
  }
  if ((a.mood === 'sleepy' || night()) && Math.random() < 0.5 && !a.swimmer) { a.state = 'sleep'; a.timer = 20 + Math.random() * 40; a.sitting = true; return; }
  const others = [...actors.values()].filter((o) => o !== a && o.appear >= 1 && !['held', 'fall', 'sleep'].includes(o.state));
  const friend = others.find((o) => a.friends.includes(o.uid));
  const near = others.find((o) => Math.abs(o.x - a.x) < 260 * DPR && !o.fly === !a.fly);
  if (near && Math.random() < 0.12 && near.state !== 'spar') { a.state = near.state = 'spar'; a.timer = near.timer = 3 + Math.random() * 2; a.with = near.uid; near.with = a.uid; a.flip = near.x < a.x; near.flip = !a.flip; return; }
  // now and then: off on a little expedition, back later with something found
  if (Math.random() < 0.025 && ![...actors.values()].some((o) => ['away', 'gone', 'return'].includes(o.state))) {
    a.side = Math.random() < 0.5 ? -1 : 1; a.state = 'away'; a.tx = a.side < 0 ? -160 * DPR : W + 160 * DPR; a.timer = 40; a.flip = a.side < 0; a.sitting = false;
    emote(a, 'wow');
    return;
  }
  if (a.swimmer) {
    // in the aquarium: drift about anywhere on the screen, slowly, like a fish
    a.sitting = false;
    const goal = friend && Math.random() < 0.3 ? { x: friend.x + (Math.random() - 0.5) * 200 * DPR, y: friend.y + (Math.random() - 0.5) * 80 * DPR } : { x: W * (0.05 + Math.random() * 0.9), y: H * (0.15 + Math.random() * 0.78) };
    a.state = 'fly'; a.tx = goal.x; a.ty = Math.min(ground() - 20 * DPR, goal.y); a.timer = 18;
    return;
  }
  if (a.fly) {
    if (!a.sitting && Math.random() < 0.18) { a.state = 'land'; a.tx = a.x + (Math.random() - 0.5) * 300 * DPR; a.ty = ground(); a.timer = 12; return; }
    a.sitting = false;
    const goal = friend && Math.random() < 0.35 ? { x: friend.x + (Math.random() - 0.5) * 160 * DPR, y: friend.y - 60 * DPR } : { x: W * (0.05 + Math.random() * 0.9), y: H * (0.12 + Math.random() * 0.6) };
    a.state = 'fly'; a.tx = goal.x; a.ty = Math.min(ground() - 40 * DPR, goal.y); a.timer = 14;
    return;
  }
  if (Math.random() < 0.65) {
    const tx = friend && Math.random() < 0.4 ? friend.x + (Math.random() < 0.5 ? -1 : 1) * (50 + Math.random() * 60) * DPR : W * (0.03 + Math.random() * 0.94);
    a.state = 'walk'; a.tx = Math.max(30, Math.min(W - 30, tx)); a.timer = 18;
  } else { a.state = 'idle'; a.timer = 2 + Math.random() * 5; }
}

function update(dt) {
  const gy = ground();
  for (const a of actors.values()) {
    a.ft += dt; a.hop = Math.max(0, a.hop - dt * 2.5); a.squash = Math.max(0, a.squash - dt * 4);
    a.appear = Math.min(1, a.appear + dt * 1.2);
    a.blink -= dt; if (a.blink < -0.15) a.blink = 2 + Math.random() * 4;
    if (a.bubble) { a.bubble.t += dt; if (a.bubble.t > a.bubble.life) a.bubble = null; }
    else if (!a.egg && a.state !== 'sleep' && a.state !== 'held' && Math.random() < dt * 0.012) emote(a);
    if (a.appear < 1) continue;
    // music playing: little notes over their heads, and a bounce to the beat now and then
    if (musicOn() && !a.egg && a.state !== 'sleep' && a.state !== 'held') {
      if (Math.random() < dt * 0.35) { burst(a, 'note', 1); }
      if (!a.bubble && Math.random() < dt * 0.08) emote(a, 'note');
      if (a.hop <= 0 && a.state !== 'walk' && Math.random() < dt * 0.9) a.hop = 0.45;
    }
    // the aquarium: bubbles drift up from swimmers
    if (a.swimmer && Math.random() < dt * 0.7) fx.push({ kind: 'bubble', float: true, x: a.x + (Math.random() - 0.5) * 16 * DPR, y: a.y - (a.h ?? 40) * 0.7, vx: (Math.random() - 0.5) * 10 * DPR, vy: -(30 + Math.random() * 30) * DPR, life: 2 + Math.random(), c: 0 });
    if (a.state === 'held') continue;
    if (a.state === 'fall') {
      a.x += a.vx * dt; a.y += a.vy * dt;
      if (a.x < 20 || a.x > W - 20) { a.x = Math.max(20, Math.min(W - 20, a.x)); a.vx *= -0.5; }
      if (a.y < a.h) { a.y = a.h; a.vy = Math.abs(a.vy) * 0.3; }
      if (a.fly) {
        // fliers catch themselves and glide
        const k = Math.pow(0.15, dt); a.vx *= k; a.vy = a.vy * k;
        if (Math.hypot(a.vx, a.vy) < 40 * DPR) { a.state = 'fly'; a.tx = a.x; a.ty = Math.min(gy - 60 * DPR, a.y); a.timer = 2; emote(a, 'wow'); }
        continue;
      }
      a.vy += G * DPR * dt;
      if (a.y >= gy) {
        a.y = gy;
        if (a.vy > 500 * DPR) { a.vy = -a.vy * 0.35; a.vx *= 0.6; a.squash = 1; }
        else { a.vy = 0; a.vx = 0; a.y = floorOf(a); a.state = 'idle'; a.timer = 1.2; a.squash = 1; a.hop = 1; emote(a, Math.random() < 0.5 ? 'wow' : 'smile'); }
      }
      continue;
    }
    a.timer -= dt;
    // a ball's been thrown: everyone awake runs after it
    if (ball && !a.egg && a.state !== 'sleep' && !(ball.still > 1.5)) {
      const dx = ball.x - a.x;
      a.flip = dx < 0;
      if (Math.abs(dx) > 10) a.x += Math.sign(dx) * Math.min(Math.abs(dx), a.speed * DPR * 1.8 * dt);
      if (a.fly) a.y += (Math.min(gy, ball.y + 20 * DPR) - a.y) * Math.min(1, dt * 2);
      else a.y = floorOf(a);
      if (Math.abs(dx) < 30 * DPR && Math.abs(ball.y - (a.y - a.h / 2)) < a.h) { ball.vx = (a.flip ? -1 : 1) * (300 + Math.random() * 500) * DPR; ball.vy = -(600 + Math.random() * 700) * DPR; a.hop = 1; burst(a, 'note', 2); if (!a.played || Date.now() - a.played > 3000) { a.played = Date.now(); api.petCare('play', undefined, a.uid); } }
      continue;
    }
    switch (a.state) {
      case 'away': {
        a.x += a.side * a.speed * DPR * 1.2 * dt;
        a.y = a.fly ? a.y + (H * 0.35 - a.y) * Math.min(1, dt) : gy;
        if (a.x < -120 * DPR || a.x > W + 120 * DPR) { a.state = 'gone'; a.back = Date.now() + (25 + Math.random() * 50) * 1000; }
        break;
      }
      case 'gone': if (Date.now() > a.back) { a.state = 'return'; a.x = a.side < 0 ? -100 * DPR : W + 100 * DPR; a.tx = W * (0.25 + Math.random() * 0.5); a.flip = a.side > 0; a.carrying = true; } break;
      case 'return': {
        const dx = a.tx - a.x;
        a.x += Math.sign(dx) * Math.min(Math.abs(dx), a.speed * DPR * dt); a.flip = dx < 0;
        a.y = a.fly ? a.y + (gy - a.y) * Math.min(1, dt * 2) : floorOf(a);
        if (Math.abs(dx) < 3) {
          a.state = 'idle'; a.timer = 4; a.carrying = false; a.sitting = !!a.fly && !a.swimmer; a.y = a.swimmer ? a.y : floorOf(a);
          if (!gift) gift = { x: a.x + (a.flip ? -30 : 30) * DPR, y: gy - 10 * DPR, vy: 0, t: 0, by: a.uid, found: true };
          a.hop = 1; emote(a, 'smile'); burst(a, 'glitter', 6); toastAt(a, `${a.name} brought something back!`);
        }
        break;
      }
      case 'walk': {
        const dx = a.tx - a.x;
        a.flip = dx < 0;
        a.x += Math.sign(dx) * Math.min(Math.abs(dx), a.speed * DPR * dt);
        a.y = floorOf(a);
        if (Math.abs(dx) < 2 || a.timer < 0) { a.state = 'idle'; a.timer = 1.5 + Math.random() * 4; }
        break;
      }
      case 'fly': case 'land': {
        const dx = a.tx - a.x, dy = a.ty - a.y, d = Math.hypot(dx, dy);
        const sp = a.speed * DPR * (a.swimmer ? 0.45 : 0.9);
        if (d > 2) { a.x += (dx / d) * Math.min(d, sp * dt); a.y += (dy / d) * Math.min(d, sp * dt); a.flip = dx < -1 ? true : dx > 1 ? false : a.flip; }
        if (d < 4 || a.timer < 0) {
          if (a.state === 'land') { a.y = gy; a.sitting = true; a.state = 'idle'; a.timer = 6 + Math.random() * 10; }
          else { a.state = 'hover'; a.timer = 1.5 + Math.random() * 4; a.baseY = a.y; }
        }
        break;
      }
      case 'hover': a.y = (a.baseY ?? a.y) + Math.sin(a.ft * 2) * 6 * DPR; if (a.timer < 0) pick(a); break;
      case 'watch': {
        // off to the corner, then sit (or float) facing the screen
        const dx = a.tx - a.x;
        if (Math.abs(dx) > 3) { a.x += Math.sign(dx) * Math.min(Math.abs(dx), a.speed * DPR * (a.swimmer ? 0.6 : 1) * dt); a.flip = dx < 0; a.walking = true; }
        else a.walking = false;
        const wantY = a.swimmer || (a.fly && !a.sitting) ? ground() - 90 * DPR : floorOf(a);
        a.y += (wantY - a.y) * Math.min(1, dt * 3);
        if (!watching()) { a.state = 'idle'; a.timer = 1; a.walking = false; }
        else if (a.timer < 0) a.timer = 8;
        break;
      }
      case 'spar': {
        const o = actors.get(a.with);
        if (!o || o.state !== 'spar' || a.timer < 0) { a.state = 'idle'; a.timer = 2; a.hop = 1; emote(a, 'smile'); break; }
        // little lunges at each other, stars when they bump
        const dir = o.x > a.x ? 1 : -1;
        a.flip = dir < 0;
        const gap = Math.abs(o.x - a.x);
        const want = 40 * DPR + Math.abs(Math.sin(a.ft * 6 + (a.uid > o.uid ? 1.5 : 0))) * 50 * DPR;
        a.x += Math.sign(gap - want) * dir * Math.min(Math.abs(gap - want), 240 * DPR * dt);
        if (gap < 46 * DPR && Math.random() < dt * 4) { burst(a, 'star', 2); a.hop = 0.7; }
        break;
      }
      case 'sleep': a.y = a.fly && !a.sitting ? a.y : a.fly ? gy : gy; if (a.timer < 0) { a.state = 'idle'; a.timer = 1; emote(a, 'calm'); } break;
      default:
        if (!a.fly || a.sitting) a.y = a.fly ? gy : floorOf(a);
        if (a.timer < 0) pick(a);
    }
  }
  // the ball bounces about the screen
  if (ball) {
    ball.t += dt;
    ball.vy += G * DPR * dt; ball.x += ball.vx * dt; ball.y += ball.vy * dt; ball.spin += ball.vx * dt * 0.05;
    const r = ball.r;
    if (ball.y > gy - r) { ball.y = gy - r; ball.vy = -Math.abs(ball.vy) * 0.72; ball.vx *= 0.92; if (Math.abs(ball.vy) < 120 * DPR) ball.vy = 0; }
    // rolling along the floor it slows down gradually
    if (ball.vy === 0 && ball.y >= gy - r - 1) { ball.vx *= Math.pow(0.55, dt); if (Math.abs(ball.vx) < 4 * DPR) ball.vx = 0; }
    if (ball.x < r || ball.x > W - r) { ball.x = Math.max(r, Math.min(W - r, ball.x)); ball.vx *= -0.7; }
    // once it's come to rest they lose interest; it fades away where it stopped
    if (ball.vx === 0 && ball.vy === 0) ball.still = (ball.still ?? 0) + dt; else ball.still = 0;
    if (ball.still > 1.5 || ball.t > 45) ball.fade = (ball.fade ?? 1) - dt / 1.2;
    if ((ball.fade ?? 1) <= 0) {
      ball = null;
      // everyone carries on from wherever they ended up (fliers hover there, nobody jumps back)
      for (const a of actors.values()) { if (['held', 'fall', 'sleep', 'gone', 'away', 'return'].includes(a.state)) continue; a.baseY = a.y; a.ty = a.y; a.tx = a.x; a.state = a.fly && !a.sitting ? 'hover' : 'idle'; a.timer = 1 + Math.random() * 2; }
    }
  }
  // now and then something turns up on the desktop
  if (!gift && Date.now() > nextGift && actors.size) {
    gift = { x: W * (0.1 + Math.random() * 0.8), y: -20, vy: 0, t: 0 };
    nextGift = Date.now() + (25 + Math.random() * 25) * 60000;
  }
  if (gift) {
    gift.t += dt;
    if (gift.y < gy - 10 * DPR) { gift.vy += G * DPR * 0.3 * dt; gift.y = Math.min(gy - 10 * DPR, gift.y + gift.vy * dt); }
    // the nearest buddy wanders over and sniffs it
    const a = [...actors.values()].filter((x) => !x.fly && x.state === 'idle').sort((p, q) => Math.abs(p.x - gift.x) - Math.abs(q.x - gift.x))[0];
    if (a && Math.random() < dt * 0.3) { a.state = 'walk'; a.tx = gift.x + (a.x < gift.x ? -40 : 40) * DPR; a.timer = 10; }
    if (gift.t > 600) gift = null;
  }
  for (const f of fx) { f.life -= dt; f.x += f.vx * dt + (f.float ? Math.sin(f.life * 5) * 8 * DPR * dt : 0); f.y += f.vy * dt; if (!f.float) f.vy += 200 * DPR * dt; }
  for (let i = fx.length - 1; i >= 0; i--) if (fx[i].life <= 0) fx.splice(i, 1);
}

const FX_COL = { ember: ['#ff6a2a', '#ffd45e'], drop: ['#4aa8ff', '#bfe6ff'], leaf: ['#4fb63f', '#a8e070'], spark: ['#ffe23d', '#ffffff'], flake: ['#ffffff', '#bfe8ff'], pebble: ['#9a8468', '#cbb89a'], gust: ['#ffffff', '#d8f0ff'], ring: ['#ff7ad6', '#ffc0ec'], wisp: ['#9a6ae0', '#5a3a8a'], star: ['#ffb23d', '#ffffff'], glint: ['#ffffff', '#a8b4c8'], glitter: ['#ffa8dc', '#ffffff'], bubble: ['#b45ad0', '#e6a8ff'], mote: ['#a6d03d', '#efff8a'], scale: ['#8a6aff', '#ff9a4d'], plain: ['#ffffff', '#fff3a0'], note: ['#ffffff', '#7db8ff'], heart: ['#ff5d8f', '#ffb0c8'] };
function draw() {
  ctx.clearRect(0, 0, W, H);
  ctx.imageSmoothingEnabled = false;
  const hits = [];
  const list = [...actors.values()].sort((p, q) => p.y - q.y);
  for (const a of list) {
    const many = (bank.get(a.speciesId).frames.idle?.length ?? 1) > 4;
    // big creatures animate slowly
    const ft = a.ft * (a.sp ? animRate(a.sp, a.c ? sizeVariant(a.c).mult : 1) : 1);
    let anim = 'idle', frame = Math.floor(ft * (many ? 10 : 2));
    const e0 = bank.get(a.speciesId);
    const back = !!(e0.ownFile?.back || (!e0.custom && !e0.waiting && e0.frames.back?.length));
    if (a.state === 'watch' && !a.walking && back) { anim = 'back'; frame = Math.floor(ft * (many ? 6 : 1)); }
    else if (a.state === 'walk' || a.state === 'fly' || a.state === 'land' || (a.state === 'watch' && a.walking) || (ball && !a.egg && !(ball.still > 1.5))) { anim = 'walk'; frame = Math.floor(ft * 6); }
    else if (a.state === 'sleep') { anim = 'sleep'; frame = Math.floor(ft); }
    else if (a.state === 'spar' || a.hop > 0) { anim = 'happy'; frame = Math.floor(ft * 4); }
    else if (a.state === 'held' || a.state === 'fall') { anim = 'walk'; frame = Math.floor(ft * 10); }
    else if (a.blink < 0) anim = 'blink';
    if (a.state === 'gone') continue;
    const { img, k, box } = look(a, anim, frame);
    const w = img.width * k, h = img.height * k;
    a.h = (box.bottom - box.top) * h;
    const hop = Math.round(Math.sin(a.hop * Math.PI) * Math.max(4, a.h * 0.15));
    const bob = ((a.fly && !a.sitting) || a.hover) && a.state !== 'fall' && a.state !== 'held' ? Math.round(Math.sin(a.ft * (a.swimmer ? 1.6 : 3)) * (a.hover ? 2 : 3) * DPR) : 0;
    const sq = a.squash * 0.2;
    const dw = Math.round(w * (1 + sq)), dh = Math.round(h * (1 - sq));
    const x0 = Math.round(a.x - dw / 2 + (0.5 - (box.left + box.right) / 2) * dw * (a.flip ? -1 : 1));
    const y0 = Math.round(a.y - dh * box.bottom - hop + bob);
    // shadow on the floor (smaller the higher they are)
    const lift = Math.max(0, ground() - a.y);
    const sw = Math.max(6, Math.round((box.right - box.left) * dw * 0.8 / (1 + lift / (120 * DPR))));
    ctx.fillStyle = `rgba(20,16,40,${(0.22 / (1 + lift / (200 * DPR))).toFixed(3)})`;
    ctx.beginPath(); ctx.ellipse(Math.round(a.x), ground(), sw / 2, Math.max(2, 3 * DPR), 0, 0, Math.PI * 2); ctx.fill();
    const paint = () => {
      ctx.save();
      if (a.state === 'held') { ctx.translate(a.x, y0); ctx.rotate(Math.sin(a.ft * 7) * 0.12); ctx.translate(-a.x, -y0); }
      // 3D mode: the creature's 3D model in place of its picture (a square view centred on where it stands)
      if (!a.flip) { ctx.translate(x0 + dw, y0); ctx.scale(-1, 1); /* sprites face left as drawn: mirror when heading right */ ctx.drawImage(img, 0, 0, dw, dh); } else ctx.drawImage(img, x0, y0, dw, dh);
      ctx.restore();
    };
    if (a.appear < 1) {
      if (a.appear <= 0) continue;
      const bw = Math.max(3, Math.round(dw * 0.6));
      ctx.fillStyle = `rgba(125,255,207,${(0.55 * (1 - a.appear)).toFixed(3)})`;
      ctx.fillRect(Math.round(a.x - bw / 2), 0, bw, Math.round(a.y));
      const shown = Math.max(0, (a.appear - 0.25) / 0.75);
      ctx.save(); ctx.beginPath(); ctx.rect(0, Math.round(a.y - dh * shown), W, Math.ceil(dh * shown) + 2); ctx.clip(); paint(); ctx.restore();
      continue;
    }
    paint();
    const top = y0 + box.top * dh;
    hits.push({ uid: a.uid, x0: x0 + Math.min(box.left, 1 - box.right) * dw - 6, x1: x0 + Math.max(box.right, 1 - box.left) * dw + 6, y0: top - 6, y1: y0 + box.bottom * dh + 4 });
    if (a.state === 'sleep' && Math.sin(a.ft * 2) > 0) { ctx.fillStyle = '#ffffff'; ctx.font = `${12 * DPR}px "Capsule Pixel", monospace`; ctx.fillText('z', a.x + dw * 0.25, top); }
    if (a.bubble) drawFaceBubble(ctx, Math.round(a.x + (box.right - box.left) * dw * 0.2), Math.round(top - 4 * DPR - a.bubble.t * 3), Math.max(2 * DPR, Math.round(a.h / 20)), a.bubble.face, { alpha: Math.min(1, (a.bubble.life - a.bubble.t) / 0.35), pop: Math.min(1, a.bubble.t / 0.12) });
    if (a.ask && !a.bubble) { // a “!” bubble over its head: it has something to say (click it)
      const bx = Math.round(a.x), by = Math.round(top - 14 * DPR + Math.sin(performance.now() / 260) * 2 * DPR), r = 10 * DPR;
      ctx.save(); ctx.fillStyle = '#ffd84a'; ctx.strokeStyle = '#1a1838'; ctx.lineWidth = 2 * DPR; ctx.beginPath(); ctx.arc(bx, by, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(bx - 3 * DPR, by + r - 1 * DPR); ctx.lineTo(bx, by + r + 6 * DPR); ctx.lineTo(bx + 3 * DPR, by + r - 1 * DPR); ctx.fill();
      ctx.fillStyle = '#1a1838'; ctx.font = `900 ${14 * DPR}px system-ui`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('!', bx, by + 1 * DPR); ctx.restore();
    }
    if (a.hover && a.name) label(a.name, a.x, top - (a.bubble ? 30 * DPR : 8 * DPR));
  }
  if (ball) {
    const r = ball.r;
    ctx.save(); ctx.globalAlpha = Math.max(0, Math.min(1, ball.fade ?? 1)); ctx.translate(Math.round(ball.x), Math.round(ball.y)); ctx.rotate(ball.spin);
    ctx.fillStyle = '#1b1838'; ctx.beginPath(); ctx.arc(0, 0, r + DPR, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#e5484d'; ctx.beginPath(); ctx.arc(0, 0, r, Math.PI, 0); ctx.fill();
    ctx.fillStyle = '#f2f2fa'; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI); ctx.fill();
    ctx.fillStyle = '#1b1838'; ctx.fillRect(-r, -DPR, r * 2, 2 * DPR); ctx.beginPath(); ctx.arc(0, 0, r * 0.32, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(0, 0, r * 0.18, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
  if (gift) {
    const s = 3 * DPR, gx = Math.round(gift.x), gy = Math.round(gift.y);
    const glow = 0.3 + 0.2 * Math.sin(gift.t * 4);
    ctx.fillStyle = `rgba(255,233,140,${glow.toFixed(3)})`; ctx.beginPath(); ctx.arc(gx, gy - 4 * s, 9 * s, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#1b1838'; ctx.fillRect(gx - 5 * s, gy - 8 * s, 10 * s, 8 * s);
    ctx.fillStyle = '#ff5d8f'; ctx.fillRect(gx - 4 * s, gy - 7 * s, 8 * s, 6 * s);
    ctx.fillStyle = '#ffd23f'; ctx.fillRect(gx - s, gy - 7 * s, 2 * s, 6 * s); ctx.fillRect(gx - 4 * s, gy - 5 * s, 8 * s, s);
    ctx.fillRect(gx - 3 * s, gy - 10 * s, 2 * s, 2 * s); ctx.fillRect(gx + s, gy - 10 * s, 2 * s, 2 * s);
    hits.push({ gift: true, x0: gx - 12 * s, x1: gx + 12 * s, y0: gy - 14 * s, y1: gy + 2 * s });
  }
  for (const f of fx) {
    ctx.globalAlpha = Math.max(0, Math.min(1, f.life * 1.5));
    const col = (FX_COL[f.kind] ?? FX_COL.plain)[f.c]; const s = 2 * DPR;
    ctx.fillStyle = col;
    if (f.kind === 'heart') { ctx.font = `${14 * DPR}px sans-serif`; ctx.fillText('♥', f.x, f.y); }
    else if (f.kind === 'note') { ctx.font = `${14 * DPR}px sans-serif`; ctx.fillText(f.c ? '♫' : '♪', f.x, f.y); }
    else if (f.kind === 'bubble') { ctx.strokeStyle = 'rgba(200,236,255,.85)'; ctx.lineWidth = DPR; ctx.beginPath(); ctx.arc(f.x, f.y, 3 * DPR, 0, Math.PI * 2); ctx.stroke(); }
    else if (f.kind === 'star' || f.kind === 'glitter' || f.kind === 'glint') { ctx.fillRect(f.x - s, f.y, s * 3, s); ctx.fillRect(f.x, f.y - s, s, s * 3); }
    else ctx.fillRect(Math.round(f.x), Math.round(f.y), s, s);
  }
  ctx.globalAlpha = 1;
  draw.hits = hits;
}
function label(text, x, y) {
  text = brandText(String(text));
  ctx.font = `${10 * DPR}px "Capsule Pixel", monospace`;
  const w = Math.ceil(ctx.measureText(text).width) + 8 * DPR;
  const lx = Math.round(Math.max(2, Math.min(W - w - 2, x - w / 2))), ly = Math.round(Math.max(2, y - 13 * DPR));
  ctx.fillStyle = 'rgba(27,24,56,0.85)'; ctx.fillRect(lx, ly, w, 13 * DPR);
  ctx.fillStyle = '#ffffff'; ctx.textBaseline = 'top'; ctx.fillText(text, lx + 4 * DPR, ly + 2 * DPR);
  ctx.textBaseline = 'alphabetic';
}

function loop(t) {
  const dt = Math.min(0.05, Math.max(0, (t - (last || t)) / 1000));
  last = t;
  if (bank) { try { update(dt); draw(); } catch (e) { if (!loop.warned) { loop.warned = true; console.error(e); } } }
  requestAnimationFrame(loop);
}

// ---------- pointer: only over a buddy (or its menu) does the window take the mouse ----------
function hitAt(x, y) { const hs = draw.hits ?? []; for (let i = hs.length - 1; i >= 0; i--) { const b = hs[i]; if (x >= b.x0 && x <= b.x1 && y >= b.y0 && y <= b.y1) return b; } return null; }
function setOver(v) { if (v === overAny) return; overAny = v; api.petMouse(v); }
function bindPointer() {
  const P = (e) => ({ x: e.clientX * DPR, y: e.clientY * DPR });
  window.addEventListener('pointermove', (e) => {
    const p = P(e);
    if (drag) {
      const a = actors.get(drag.uid);
      if (!a) return;
      drag.moved += Math.abs(p.x - drag.last.x) + Math.abs(p.y - drag.last.y);
      drag.hist.push({ ...p, t: performance.now() }); if (drag.hist.length > 6) drag.hist.shift();
      if (a.state !== 'held') {
        // rubbing over them pets them; pulling away picks them up
        drag.rub += Math.abs(p.x - drag.last.x);
        if (drag.moved > 18 * DPR && Math.hypot(p.x - drag.start.x, p.y - drag.start.y) > 24 * DPR) { a.state = 'held'; a.sitting = false; emote(a, 'wow'); }
        else if (drag.rub > 60 * DPR) { drag.rub = 0; pet(a); }
      }
      if (a.state === 'held') { a.x = p.x; a.y = p.y + a.h * 0.6; if (p.x !== drag.last.x) a.flip = p.x < drag.last.x; }
      drag.last = p;
      return;
    }
    const hit = menu ? null : hitAt(p.x, p.y);
    for (const a of actors.values()) a.hover = hit?.uid === a.uid;
    setOver(!!hit || !!menu);
    document.body.style.cursor = hit ? (hit.gift ? 'pointer' : 'grab') : '';
  });
  window.addEventListener('pointerdown', (e) => {
    if (menu && !menu.contains(e.target)) closeMenu();
    if (e.button !== 0) return;
    const p = P(e), hit = hitAt(p.x, p.y);
    if (hit?.gift) { collectGift(); return; }
    if (!hit?.uid) return;
    drag = { uid: hit.uid, start: p, last: p, moved: 0, rub: 0, hist: [{ ...p, t: performance.now() }] };
  });
  window.addEventListener('pointerup', (e) => {
    if (!drag) return;
    const a = actors.get(drag.uid);
    if (a?.ask && drag.moved < 6 * DPR && a.state !== 'held') { const d = drag; drag = null; openAsk(a, e.clientX, e.clientY); void d; return; }
    if (a?.state === 'held') {
      const hs = drag.hist, dt = Math.max(0.016, (hs[hs.length - 1].t - hs[0].t) / 1000);
      a.vx = Math.max(-4000, Math.min(4000, (hs[hs.length - 1].x - hs[0].x) / dt));
      a.vy = Math.max(-4000, Math.min(4000, (hs[hs.length - 1].y - hs[0].y) / dt));
      a.state = 'fall';
      if (Math.hypot(a.vx, a.vy) > 2500) sfx('miss'); else sfx('blip');
    }
    drag = null;
  });
  window.addEventListener('dblclick', (e) => { const hit = hitAt(e.clientX * DPR, e.clientY * DPR); const a = hit?.uid && actors.get(hit.uid); if (a) call(a); });
  window.addEventListener('contextmenu', (e) => { e.preventDefault(); const hit = hitAt(e.clientX * DPR, e.clientY * DPR); const a = hit?.uid && actors.get(hit.uid); if (a) openMenu(a, e.clientX, e.clientY); });
}

async function pet(a) {
  if (Date.now() - (a.petAt ?? 0) < 700) return;
  a.petAt = Date.now();
  sfx('heart'); a.hop = 0.8; burst(a, 'heart', 3); emote(a, 'love');
  const out = await api.petCare('pet', undefined, a.uid);
  if (out?.reaction === 'annoyed') { emote(a, 'angry'); a.hop = 0; }
}
async function wake(a) {
  await api.petCare('wake', undefined, a.uid);
  if (a.c) a.c.sleep = null;
  a.state = 'idle'; a.timer = 1; a.sitting = false; emote(a, 'angry'); sfx('back');
}
async function call(a) {
  if (a.c?.sleep && a.c.sleep.until > Date.now()) { wake(a); return; }
  creatureCry(a.sp, a.c, { talk: true }); a.hop = 1; burst(a, a.fxKind, 6); emote(a, 'note');
  const out = await api.petCare('talk', undefined, a.uid);
  if (out?.reaction === 'annoyed') emote(a, 'angry');
}
async function collectGift() {
  if (!gift) return;
  const g = gift;
  const near = (g.by && actors.get(g.by)) || [...actors.values()].sort((p, q) => Math.abs(p.x - g.x) - Math.abs(q.x - g.x))[0];
  gift = null;
  const r = await api.petGift(near?.uid, !!g.found);
  sfx('level');
  if (near && r) { burst(near, 'glitter', 8); emote(near, 'smile'); toastAt(near, `Found ${r.name}!`); }
}
function toastAt(a, text) {
  const el = document.createElement('div');
  el.className = 'pet-say';
  el.textContent = brandText(text);
  el.style.left = `${a.x / DPR}px`; el.style.top = `${(a.y - a.h) / DPR - 40}px`;
  document.body.append(el);
  setTimeout(() => el.remove(), 2600);
}

async function openMenu(a, x, y) {
  closeMenu();
  setOver(true);
  const changes = (await api.petChanges?.(a.uid).catch(() => [])) ?? [];
  const items = [
    [`${a.name}`, null],
    ['Feed', async () => { const r = await api.petCare('feed', undefined, a.uid); if (r?.reaction === 'full') emote(a, 'meh'); else { burst(a, 'heart', 2); emote(a, 'smile'); } sfx('munch'); }],
    // things to do together (a menu of its own, beside this one)
    ['Actions', null, { sub: [
      ['💬 Talk to', () => openTalk(a)],
      ['⚽ Play', () => { ball = { x: a.x + (a.flip ? -40 : 40) * DPR, y: a.y - a.h, vx: (a.flip ? -1 : 1) * 700 * DPR, vy: -900 * DPR, r: 7 * DPR, t: 0, spin: 0 }; sfx('blip'); }],
      // they can't always tell what you're doing: say so, and they join in (on top of everything, even full screen)
      mode === 'movie' ? ['🎬 Stop watching', () => setMode(null)] : ['🎬 Watch the screen', () => setMode('movie')],
      mode === 'music' ? ['🎵 Stop the music', () => setMode(null)] : ['🎵 Listen to music', () => setMode('music')],
    ] }],
    ['Call', () => call(a)],
    a.c?.sleep && a.c.sleep.until > Date.now() ? ['Wake up', () => wake(a)] : ['Nap', async () => { const r = await api.petCare('rest', undefined, a.uid); if (r?.reaction === 'sleep') { a.state = 'sleep'; a.timer = 10; a.sitting = true; if (a.c) a.c.sleep = { since: Date.now(), until: Date.now() + 45 * 60000 }; } else emote(a, 'meh'); }],
    // evolve / Mega Evolve / change form: what they can do now (the rest greyed, the reason on hover)
    ...changes.map((o) => [o.label, async () => {
      if (!o.ok) return;
      const r = await api.petChange(a.uid, o.key);
      if (r?.ok) { a.appear = 0.2; sfx(o.kind === 'evolve' ? 'level' : 'warp'); burst(a, 'heart', 3); } else emote(a, 'meh');
    }, { off: !o.ok, title: o.why }]),
    ['Smaller', () => api.petSize(Math.max(0.25, +(petSize() / 1.25).toFixed(2)))],
    ['Bigger', () => api.petSize(Math.min(3, +(petSize() * 1.25).toFixed(2)))],
    ['Open Capsule Link', () => api.petOpenApp()],
    [actors.size > 1 ? `Put ${a.name} away` : 'Put away', () => api.petAway(a.uid)],
  ];
  menu = document.createElement('div');
  menu.className = 'pet-menu';
  for (const [text, fn, opt] of items) {
    const b = document.createElement(fn || opt?.sub ? 'button' : 'div');
    b.textContent = brandText(text);
    if (opt?.sub) { b.textContent = `${brandText(text)}  ▸`; b.className = 'has-sub'; const show = () => openSub(b, opt.sub); b.addEventListener('pointerenter', show); b.onclick = show; }
    else if (fn) b.onclick = () => { if (opt?.off) return; closeMenu(); fn(); }; else b.className = 'pet-menu-head';
    if (opt?.title) b.title = opt.title;
    if (opt?.off) { b.className = 'off'; b.setAttribute('aria-disabled', 'true'); }
    menu.append(b);
  }
  document.body.append(menu);
  const r = menu.getBoundingClientRect();
  menu.style.left = `${Math.max(4, Math.min(window.innerWidth - r.width - 8, x))}px`;
  menu.style.top = `${Math.max(4, Math.min(window.innerHeight - r.height - 4, y - r.height - 8))}px`;
  menu.addEventListener('pointerleave', () => setTimeout(() => { if (menu && !menu.matches(':hover')) closeMenu(); }, 500));
}
function closeMenu() { if (!menu) return; menu.remove(); menu = null; sub?.remove(); sub = null; setOver(false); }
// the menu beside the menu (Actions ▸): opens on hover, to the right (or the left, near the screen's edge)
let sub = null;
function openSub(btn, list) {
  sub?.remove();
  sub = document.createElement('div'); sub.className = 'pet-menu pet-sub';
  for (const [text, fn] of list) { const b = document.createElement('button'); b.textContent = text; b.onclick = () => { closeMenu(); fn(); }; sub.append(b); }
  document.body.append(sub);
  const r = btn.getBoundingClientRect(), sr = sub.getBoundingClientRect();
  const right = r.right + sr.width + 6 < window.innerWidth;
  sub.style.left = `${right ? r.right + 2 : Math.max(4, r.left - sr.width - 2)}px`;
  sub.style.top = `${Math.max(4, Math.min(window.innerHeight - sr.height - 4, r.top - 4))}px`;
  sub.addEventListener('pointerleave', () => setTimeout(() => { if (menu && !menu.matches(':hover') && !sub?.matches(':hover')) closeMenu(); }, 500));
}

// ---------- talking to them on the desktop ----------
// a little box above them to type in; they react the same way as in the app (and, once the on-device language
// model is ready, in its words). What's on — the music, the film or game — can turn into a memory or a liking.
let talkBox = null;
function openTalk(a) {
  talkBox?.remove();
  setOver(true);
  warmLlm();
  api.petFocus?.(true);
  talkBox = document.createElement('form'); talkBox.className = 'pet-talk';
  const inp = document.createElement('input'); inp.placeholder = mode === 'music' ? `Tell ${a.name} what's playing…` : mode === 'movie' ? `Tell ${a.name} what's on…` : `Say something to ${a.name}…`; inp.maxLength = 200;
  const go = document.createElement('button'); go.textContent = 'Say'; go.type = 'submit';
  const x = document.createElement('button'); x.textContent = '✕'; x.type = 'button'; x.onclick = () => closeTalk();
  talkBox.append(inp, go, x);
  document.body.append(talkBox);
  const place = () => { if (!talkBox) return; const r = talkBox.getBoundingClientRect(); talkBox.style.left = `${Math.max(4, Math.min(window.innerWidth - r.width - 4, a.x / DPR - r.width / 2))}px`; talkBox.style.top = `${Math.max(4, (a.y - a.h) / DPR - r.height - 40)}px`; };
  place(); inp.focus();
  talkBox.onsubmit = async (e) => {
    e.preventDefault(); const text = inp.value.trim(); if (!text) return; inp.value = '';
    a.bubble = { face: 'question', t: 0, life: 30 }; // (thinking it over)
    const out = await api.petTalk?.(a.uid, text, mode).catch(() => null);
    let line = out?.note ?? null;
    try { const l = await llmReact(text, { name: out?.name ?? a.name, species: a.sp?.name, mood: a.mood }); if (l) line = l; } catch { /* the rules' line */ }
    a.bubble = null; emote(a, out?.mood === 'happy' ? 'smile' : undefined); sfx('blip'); creatureCry(a.sp, a.c, { talk: true });
    if (line) say(a, line);
  };
  inp.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeTalk(); });
}
function closeTalk() { talkBox?.remove(); talkBox = null; api.petFocus?.(false); setOver(!!menu); }
// a line of what they did, shown above them for a few seconds
function say(a, line) {
  const el = document.createElement('div'); el.className = 'pet-say'; el.textContent = line;
  document.body.append(el);
  const r = el.getBoundingClientRect();
  el.style.left = `${Math.max(4, Math.min(window.innerWidth - r.width - 4, a.x / DPR - r.width / 2))}px`; el.style.top = `${Math.max(4, (a.y - a.h) / DPR - r.height - 12)}px`;
  setTimeout(() => el.classList.add('out'), 5200); setTimeout(() => el.remove(), 5800);
}

// ---------- “!”: something they want to tell you or do ----------
// Now and then one has something on its mind: what song this is, what's on the screen, or an activity or a battle
// it wants. Click the “!” and choose: start it, put it on the task list, or not now.
const ASKS = [
  { kind: 'activity', act: 'scavenging', icon: '🧭', text: 'wants to go scavenging' }, { kind: 'activity', act: 'cooking', icon: '🍳', text: 'wants to cook something together' },
  { kind: 'activity', act: 'fishing', icon: '🎣', text: 'wants to go fishing' }, { kind: 'activity', act: 'obstacle', icon: '🏃', text: 'wants to run the obstacle course' },
  { kind: 'activity', act: 'puzzle', icon: '🧩', text: 'wants to do a puzzle with you' }, { kind: 'activity', act: 'training', icon: '💪', text: 'wants to train' },
  { kind: 'activity', act: 'gardening', icon: '🌱', text: 'wants to do some gardening' }, { kind: 'battle', icon: '⚔️', text: 'wants to battle!' },
];
function maybeAsk() {
  const list = [...actors.values()].filter((a) => !a.egg && a.state !== 'sleep' && !a.ask);
  if (!list.length) return;
  const a = list[Math.floor(Math.random() * list.length)];
  if (mode === 'music' || host.music) a.ask = { kind: 'talk', icon: '🎵', text: 'wants to know what song this is' };
  else if (mode === 'movie' || host.video || host.game) a.ask = { kind: 'talk', icon: '📺', text: host.game ? 'wonders what you’re playing' : 'wonders what you’re watching' };
  else a.ask = { ...ASKS[Math.floor(Math.random() * ASKS.length)] };
  a.askAt = Date.now(); sfx('blip');
}
function openAsk(a, x, y) {
  const q = a.ask; if (!q) return;
  closeMenu(); setOver(true);
  menu = document.createElement('div'); menu.className = 'pet-menu pet-ask';
  const head = document.createElement('div'); head.className = 'pet-menu-head'; head.textContent = `${q.icon} ${a.name} ${q.text}`; menu.append(head);
  const add = (t, fn) => { const b = document.createElement('button'); b.textContent = t; b.onclick = () => { closeMenu(); fn(); }; menu.append(b); };
  if (q.kind === 'talk') { add('💬 Tell them', () => { a.ask = null; openTalk(a); }); add('Not now', () => { a.ask = null; emote(a, 'meh'); }); }
  else {
    add('▶ Let’s do it now', async () => { a.ask = null; burst(a, 'heart', 3); emote(a, 'smile'); await api.petAsk?.(a.uid, q, 'start'); });
    add('📝 Add to the task list', async () => { a.ask = null; emote(a, 'smile'); await api.petAsk?.(a.uid, q, 'task'); });
    add('Not now', async () => { a.ask = null; emote(a, 'meh'); await api.petAsk?.(a.uid, q, 'no'); });
  }
  document.body.append(menu);
  const r = menu.getBoundingClientRect();
  menu.style.left = `${Math.max(4, Math.min(window.innerWidth - r.width - 8, x))}px`; menu.style.top = `${Math.max(4, Math.min(window.innerHeight - r.height - 4, y - r.height - 8))}px`;
  menu.addEventListener('pointerleave', () => setTimeout(() => { if (menu && !menu.matches(':hover')) closeMenu(); }, 900));
}
function scheduleAsk() { setTimeout(() => { try { maybeAsk(); } catch { /* fine */ } scheduleAsk(); }, (6 + Math.random() * 10) * 60 * 1000); }

function scheduleCry() {
  // every so often someone calls out or wiggles, like a capsule in desk mode
  setTimeout(() => {
    const list = [...actors.values()].filter((a) => !a.egg && a.state !== 'sleep');
    const a = list[Math.floor(Math.random() * list.length)];
    if (a) { emote(a); if (Math.random() < 0.6) creatureCry(a.sp, a.c); }
    scheduleCry();
  }, (5 + Math.random() * 12) * 60 * 1000);
}

scheduleAsk();
boot();
