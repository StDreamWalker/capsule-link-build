# Your own textures

Until you add art, every species gets a generated pixel creature, and the R.A.N.C.H. and every
box use generated pixel biomes. Drop PNGs into the PC app's textures folder
(**Settings → Open textures folder**) and they replace the generated art.

The quickest way to add creature art is **Settings → Add creature sprites…**: select a whole
folder of PNGs and each one is matched to a species by name or number. The full naming rules,
sizes and tips are in [adding-your-data.md](adding-your-data.md#5-sprites).

| File | Used for | Native size |
|---|---|---|
| `creatures/<name>.png` | Idle animation everywhere | square frames side by side, or one picture (32×32 is the built-in size; over 64 is shrunk to 64) |
| `creatures/<name>-walk.png` | Walking in the ranch / desktop buddy | same frame size |
| `creatures/<name>-sleep.png` | Sleeping | same |
| `creatures/<name>-happy.png` | Petted, fed, playing | same |
| `creatures/<name>-back.png` | Seen from behind | same |
| `ranch/<biome>.png` | Background of the phone's buddy screen | 320 × 180 |
| `ranch/<biome>-ground.png` | R.A.N.C.H.: the yard's ground, seen from above with the back fence at the top | 432 × 264 (24 px per unit) |
| `ranch/<biome>-sky.png` | R.A.N.C.H.: sky, repeats sideways | e.g. 640 × 160 |
| `ranch/<biome>-far.png`, `-mid.png`, `-near.png` | R.A.N.C.H.: scenery strips beyond the fence, far to near (they slide at different speeds); transparent above the scenery, repeats sideways | 2048 wide; about 190, 125 and 110 tall |
| `ranch/<biome>-prop1.png` … `-prop8.png` | R.A.N.C.H.: props inside the yard, two of each | any size; drawn about one unit (half a creature) tall per 18 px |
| `boxes/<biome>.png` | The habitat wallpaper for that biome | 216 × 180 |
| `boxes/<anything>.png` | An extra storage wallpaper (listed under **Yours**) | 216 × 180 |
| `ui/logo.png`, `ui/ball.png`, `ui/ball-off.png` | The app's logo and the capsule picture | see [making-it-yours.md](making-it-yours.md) |
| `trainers/<anything>.png` | Trainer pictures for ID cards | any size |

`<name>` can be the species id (`mr-bristle`), the name squashed (`mrbristle`), the name with its
form (`bristle-mega`) or the number (`122`, `0122`).

- Species ids are shown in the Data Lab (lowercase, dashes for spaces).
- Biome ids: `meadow forest shoreline volcano cavern tundra desert skyline seafloor marsh starfield crystal`.
- Art is scaled with nearest-neighbour, so pixel art stays crisp. Backgrounds can be larger than
  the native size as long as the proportions match.
- Any pose you leave out reuses the idle frames.
- The Data Lab's species editor also has **Load sprite PNG** buttons that copy a file into the
  right place for you.

Phones copy the PC's textures when they sync (files over 512 KB are skipped), so your art shows
up on the phone too.
