# The 0.5.0 update (requested 2026-10-27, built in 0.5.0)

Status at the end of this file.

1) The weather and location feature isn't currently very accurate. I'll be in the city and my pokemon says it's walking through a field, or it'll be night where I'm at and it says its watching the sun. If there's a way to get it more accurate then please let's try.
2) When I picked to decide if pokemon can walk, fly, or swim I didn't mean adding a list feature, I meant in the data Dex for each pokemon you can decide giving them tabs underneath stuff like effort or evolves into or learnset. Like giving them movement options and the option to make one default. To decide if it can walk, if it walks be default, can it also swim, can it even be in water at all, can it fly, will it by default fly? Etc.
3) Give the Market its own app feature rather than it's own Ranch tab. If it makes sense you can make the inventory it's own app as well but if you can sensibly work it into the market app that would be great. Also just to mention because I feel I have to, the market is no longer going to be a 3D environment but a regular app like the rest of the apps. Also if items like incense are being sold, then they're not separate battle items or incense. In your inventory they'll show up as the same item, you just have the option to use it for both. Their item descriptions will just say "Or when being held..." or "Or when paired with a PokéBall..."
4) When walking with your pokemon outside of monitoring their stats you can sometimes collect coins and also sometimes your pokemon can find berries or small shiny items you can sell like stardust or gold nuggets.
5) In the market there should be blueprints to things you can build and add to and or extend to your ranch. Let players gradually create habitats, decorate spaces, build play areas, establish ponds, and discover which Pokémon thrive together.
Rather than another generic house-decoration game, make the environment respond to the species living there. Water Pokémon might transform a pond area; nocturnal Pokémon might prefer a moonlit habitat. Adding built in toys, decorations, and or other things for each habitat type that pokemon can like or dislike.
6) Add a big blueprint/cost item that allows you to host a ranch environment and connect it side by side to a friend who also has the PC application and let your pokemon interact and be friends 
7) add a friend system, you can visit their ranch, give gifts, trade pokemon and or items, and also message them.
8) Make activities that allows trainers and their pokemon to use their actual characteristics: cooking, gardening, fishing, scavenging, obstacle courses, puzzle-solving, photography, etc. (Species and moves could influence how these activities work without every activity becoming a competitive battle.
9)  Continue working on and further developing and adding complexity to individual pokemon personalities; Your Pokémon should do things without you issuing commands. Two Pokémon might become friends, one might prefer sleeping in the sun, and another might repeatedly try to play with a toy it can't quite reach.
Their behavior should reflect their species, temperament, individual history, and relationships. Continue adding complexity to time of day reactions and feelings, weather reactions, if we can get down the location issue maybe remembering where home is and making thoughts about home or leaving or returning, realizing when they're in a car or probably an alternate form of transportation like a bike, skateboard, plane, or boat.
10) When spending quality time with your pokemon on the ranch, you should be able to open a little journal or small pokedex like device to see their preferences, dislikes, current favorite toys, berries, foods, places, etc. I'd prefer it there than anywhere else it currently is.
11) Also in quality time when I said double click to throw the toy I meant when it's already in your hand not double clicking the actual selection icon for whichever toy.
12) Have Pokémon of certain types like fire not be able to go in the seafloor environment or have like a dome where they have to stay whenever in that environment. Make sure they can't be washed but instead have to be brushed, combed, or another combination of cleaned. 
13) When pokemon in the ranch are playing with toys, ensure they can play with the others around them if they're juggling or throwing toys around.
14) Again add more variation to the chops and pitch cadences of Pokemon cries. And when asking pokemon to speak in the ranch.
15) When pokemon are in the ranch don't let players infinitely spam the nap button for their pokemon to get them energy back, their pokemon can take a nap for a considerable amount of time but they can't do it back to back and get more and more energy. This applies with playing and petting and calling, making a pokemon do too much of anything should decrease their joy and make them upset with you. It should be important to monitor how they feel.
16) It's okay to play in a ranch if some pokemon are already max happiness or tired and don't want to play, once they get full/done only by clicking them specifically and trying to interact with that pokemon will negatively impact their stats.
17) When a pokemon is casted to the desktop from the ranch, they should leave the ranch. 
18) with the introduction of the friendship system players can't all expect to be on the same wifi, meaning the game will need wifi accessibility and likely will involve making actual usernames and passwords for their PC's since alongside now receiving actual important RNG trainer codes, we'll also want actual usernames for the friend requests and system.
19) Outside of sprites the player already has for creatures with an exact title/id when players connect with other players, they'll likely have to sync and download any missing data for said creatures. If the player has their own sprites already for a creature they won't have to redownload them.
20) The larger a pokemon is, the slower it's animated sprite should be. At the smallest pokemon there are it should be the standard animation rate, but exponentially as you increase to sizes like Wailord and eternatus it should slow down a lot

## Status (0.5.0)

1. Done: real sunrise/sunset for time of day, "clear night" instead of sun after dark, building and street density from the map (so the city counts as the city), location turned on with the first walk. Home is remembered (set it on the walk screen, or the first late-evening place).
2. Done: Data Lab → Species → Movement (can walk, swim, be in water, fly; what it usually does). The old Rules lists convert automatically.
3. Done: Market app (today's stock, bag, blueprints). Shop removed from the R.A.N.C.H. One item, several uses; descriptions say "Or when being held…", "Or when paired with a capsule…".
4. Done: walks find coins, berries and valuables (stardust, pearls, star pieces, nuggets); sell them in the Market.
5. Done: 24 blueprints (habitats, play areas, built-in toys, decorations), yard expansions (yards start at their original size), feelings per species, features that come alive with the right residents, the "Who thrives here" report.
6. Groundwork: the Link gate blueprint; yards travel as snapshots (file, or through the home server); visitors play with your creatures and can become friends. Live side-by-side comes with the server.
7. Groundwork: Friends app (preview) + home server: friends, messages, gifts, trades, yard visits.
8. Done: Activities app: cooking, gardening, fishing, scavenging, obstacle course, puzzles, photography.
9. Done (first pass): temperament styles, sunbathing, night owls, sulking when upset, chatting with friends, reaching for toys stuck in trees, taking off for a fly, time-of-day naps, playing together making friends; walk thoughts about home, leaving, returning and how you're travelling (bike, skateboard, car, train, plane, boat).
10. Done: the journal in Quality time; likes removed from the other panels.
11. Done: double-click the scene while holding something to throw it.
12. Done: no baths for fire types (brush and comb clean them); a dry dome on the seafloor.
13. Done: toys get passed to nearby creatures, who join in; fliers juggle.
14. Done: more cry variations (yawns, huffs, warbles, trills, back-to-front) and "Call" talks in syllables.
15. Done: nap cooldown; too much of anything makes them upset.
16. Done: only direct interaction with a full or tired creature costs you; yard toys and berries don't.
17. Done: creatures on the desktop leave the yard (and can be called back).
18. Groundwork: usernames, passwords and server-issued trainer codes on the home server.
19. Groundwork: shared creature data and pictures by hash; you only download what you don't have.
20. Done: animation slows with size (in the yard, on the desktop and in lists).

