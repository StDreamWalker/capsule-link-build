# The Capsule Link home server (preview)

Friends who aren't on your Wi-Fi meet through a small server: accounts with usernames and passwords,
friend requests, messages, gifts, trades, yard visits through the Link gate, and sharing creature data
(and pictures) that one of you has and the other doesn't. It also hosts the battle relay.

It's deliberately small: no database to install, no dependencies, just Node. An old laptop or a
Raspberry Pi in a cupboard is plenty for a group of friends.

## Running it

1. Install Node 20 or newer on the computer that will be the server.
2. Copy the `capsule-link` folder there (only `server/` and `shared/` are needed).
3. Start it:

   ```
   node server/home-server.mjs --port 47830 --data ./server-data
   ```

   Everything it keeps (accounts, friends, messages, inboxes, shared yards and pictures) lives in the
   `--data` folder. Back that folder up and you've backed up the server.

4. In the PC app: **Friends → Server → `http://<that computer's address>:47830` → Connect**, then
   create an account. Your friends do the same with the same address.

Battles through it: set the phone's battle server to `ws://<address>:47830/relay`.

## Reaching it from outside your home

- Give the server computer a fixed address on your network (most routers call this a "DHCP reservation").
- Forward TCP port 47830 on your router to that computer.
- Friends then use your public address (or a free dynamic-DNS name) instead of the local one.

Once it's open to the internet, put it behind HTTPS: a reverse proxy like Caddy does this in a couple
of lines and gets a certificate automatically:

```
your-name.example.net {
  reverse_proxy localhost:47830
}
```

Then everyone uses `https://your-name.example.net`.

## What it stores, and how

- Passwords are never stored: only a salted scrypt hash.
- Signing in gives the app a random token; the server keeps only its SHA-256. Tokens last 90 days.
- Each account gets a random 12-digit trainer code (unique on that server). Friends can add you by
  code or by username; the code is also added to your trainer card's "Other trainer IDs".
- Gifts and trades are held by the server until the other person opens them. A gift leaves your bag
  when it's sent; a creature you offer in a trade leaves your boxes until the trade is accepted
  (or comes back if it's declined).
- Shared creature data: when you share, the server keeps each species' record and its pictures, named by
  their SHA-256. A friend who's missing a species downloads only that — and never a picture they already have.
- There's simple rate limiting (240 requests a minute per address) and size limits on everything.

## The API

See the comment at the top of `server/home-server.mjs` for every endpoint. `shared/net/friends.js` is
the client the app uses; `tests/server.test.mjs` walks through all of it.

## Not done yet

- Live, real-time side-by-side yards (today a friend's yard comes over as a snapshot through your Link gate).
- The phone app doesn't sign in yet; the PC does.
- Password reset (for now the server's owner can delete an account from `server-data/users.json`).
