# The Capsule Link home server (preview)

Friends who aren't on your Wi-Fi meet through a small server: accounts with usernames and passwords,
friend requests, messages, gifts, trades, yard visits through the Link gate, and sharing creature data
(and pictures) that one of you has and the other doesn't. It also hosts the battle relay.

It's deliberately small: no database to install, no dependencies, just Node. An old laptop or a
Raspberry Pi in a cupboard is plenty for a group of friends.

## The easy way: host it from the PC app

On the computer that will be the server (an old PC is perfect), install the Capsule Link app as usual,
sign in, and open **Settings → Debug → Host a server from this PC**. It's a step-by-step guide with a
button for each step:

1. **Start the server**: the app runs it in the background, no Node or terminal needed.
2. **Let it through the firewall**: one button adds the Windows firewall rule (Windows asks once).
3. **Check it at home**: open the shown `http://192.168.x.x:47830` address from a phone on your Wi-Fi.
4. **Open it to the internet**: the app asks your router to forward the port (UPnP). If your router
   says no, the guide shows how to forward port 47830 by hand. It also warns you if your internet
   provider shares one public address between many homes (CGNAT), where forwarding can't work.
5. **An address that doesn't change**: optional, a free DuckDNS name kept up to date by the app.
6. **Keep it running**: start the server when the app opens, open the app when Windows starts,
   keep it running in the tray when the window is closed, and stop the PC sleeping.
7. **Invite your friends**: test it from the internet, then send them the address. Friends put
   it in **Friends → Server** and make an account; you can make your own account on it too.

Everything the server keeps lives in the folder the guide shows; back that folder up to back up the server.

### What friends can do on it

- See who's online right now and when everyone else was last about (Friends, and the home screen).
- Message, send gifts, trade, visit each other's yards through a Link gate, and share creature data.
- Battle: in **Battle Link → Battle a friend**, press Invite. When they accept, Showdown opens on both
  PCs with each of your parties, and the one who invited sends the challenge. Before you go, **Change
  your team** lets each of you pick moves (any learned by levelling up to their level, or from a TM in
  your bag) and held items.
- Visit with their Data Lab: in Friends, **Share my Data Lab** puts your species, moves, items and the
  pictures that go with them on the server. A friend visiting your yard can use your data for the
  visit, and keep it as a preset (it only downloads again when you change yours).
- Make Pokéblocks together: whoever has a **Berry Blender** in a ranch yard (Market → Machines) presses
  **Blend…** in that yard's log and invites friends who are online (up to four at the blender; helpers can
  fill the empty stations). Each of you brings one creature and one berry. The host's app runs the
  blender and the server passes the arrow's position and everyone's presses round (`/api/rooms` and
  `room` messages on the live socket).

## Running it from a terminal

1. Install Node 20 or newer on the computer that will be the server.
2. Copy the `capsule-link` folder there (only `server/` and `shared/` are needed).
3. Start it:

   ```
   node server/home-server.mjs --port 47830 --data ./server-data
   ```

   Everything it keeps (accounts, friends, messages, inboxes, shared yards and pictures) lives in the
   `--data` folder. Back that folder up and you've backed up the server.

4. In the PC app: **Friends → Server → `http://<that computer's address>:47830` → Connect**, then
   create an account. Your friends do the same with the same address.

Battles through it: set the phone's battle server to `ws://<address>:47830/relay`.

## Reaching it from outside your home

- Give the server computer a fixed address on your network (most routers call this a "DHCP reservation").
- Forward TCP port 47830 on your router to that computer.
- Friends then use your public address (or a free dynamic-DNS name) instead of the local one.

Once it's open to the internet, put it behind HTTPS: a reverse proxy like Caddy does this in a couple
of lines and gets a certificate automatically:

```
your-name.example.net {
  reverse_proxy localhost:47830
}
```

Then everyone uses `https://your-name.example.net`.

## What it stores, and how

- Passwords are never stored: only a salted scrypt hash.
- Signing in gives the app a random token; the server keeps only its SHA-256. Tokens last 90 days.
- Each account gets a random 12-digit trainer code (unique on that server). Friends can add you by
  code or by username; the code is also added to your trainer card's "Other trainer IDs".
- Gifts and trades are held by the server until the other person opens them. A gift leaves your bag
  when it's sent; a creature you offer in a trade leaves your boxes until the trade is accepted
  (or comes back if it's declined).
- Shared creature data: when you share, the server keeps each species' record and its pictures, named by
  their SHA-256. A friend who's missing a species downloads only that — and never a picture they already have.
- There's simple rate limiting (240 requests a minute per address) and size limits on everything.

## The API

See the comment at the top of `server/home-server.mjs` for every endpoint. `shared/net/friends.js` is
the client the app uses; `tests/server.test.mjs` walks through all of it.

## Not done yet

- Live, real-time side-by-side yards (today a friend's yard comes over as a snapshot through your Link gate).
- The phone app doesn't sign in yet; the PC does.
- Password reset (for now the server's owner can delete an account from `server-data/users.json`).
