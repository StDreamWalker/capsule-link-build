# Making it yours

Capsule Link ships with neutral names and original placeholder creatures. Everything that names
the world can be changed in one place, and everything that draws it can be replaced with a PNG.

## Names

**Settings → Names and setup → Change names and pictures** (also part of the first-run setup).

| Field | Default | Where it shows |
|---|---|---|
| App name | Capsule Link | Window title, home, sign-in, ID cards, phone header |
| Network / company | Capsule Link Network | The "connecting" screen when you sign in |
| What creatures travel in | capsule (plural: capsules) | Everywhere a capsule is mentioned |
| What you call them | creature (plural: creatures) | Everywhere |
| The computer | PC | "Whose PC are you using?", storage, phone link |
| The device's product name | Nexus Ball | The introduction slideshow |

Type exactly what you want, including accents and capitals. Plurals follow the singular unless you
type your own. The names are stored in the data set, so phones pick them up on their next sync,
and they apply to every screen, message, notification and ID card. Capitalisation follows the
sentence ("capsule" → "orb", "Capsules" → "Orbs").

## The introduction

The very first time either app starts, a full-screen slideshow introduces the Nexus Ball: slides
fade in and out, there is no skip and no back, only **Next** (press it as fast as you like). It
uses the names above, so it reads the way you set them. The device's product name has its own
field (default "Nexus Ball").

Edit the text under **Names and pictures → Introduction text** (Preview and Restore the original
are there too), and replay it from **Settings → Play the introduction**. Format: slides are
separated by a line with `---`; `## ` starts a headline, `> ` a small line above it, and
`- Label: text` makes a feature card. Any other line is a paragraph.

## Pictures

| File (in the textures folder) | Replaces |
|---|---|
| `ui/logo.png` | The app's mark (sign-in, home, phone header). Square, transparent. |
| `ui/app-icon.png` | The app's icon: window, taskbar, Start menu and desktop shortcuts, and the phone's home-screen shortcut. Square, 512×512. |
| `ui/ball.png` | The capsule everywhere (dock, phone, monitor, catching). One picture, or a strip of poses (below). |
| `ui/ball-<type>.png` | Another kind of capsule, e.g. `ui/ball-4.png` or `ui/ball-great.png` (below). |
| `ui/toy-ball.png` | The ball you throw for them in the R.A.N.C.H. |
| `trainers/<anything>.png` | Trainer pictures to choose on your ID card. Any size; full body works best. They are listed first under **Look**, with *Make your own* last. |
| `boxes/<anything>.png` | Extra storage wallpapers (listed under **Yours**). 216×180 or larger, same shape. |
| `creatures/…`, `ranch/…`, `boxes/<biome>.png` | See [textures.md](textures.md). |

The setup screen has buttons for the logo, capsule picture, creature sprites and trainer pictures,
so you don't need to find the folder. Phones copy all of it on their next sync (files over 512 KB
are skipped).

## Capsule pictures, poses and kinds

Every capsule drawn in either app (the dock, the phone's monitor and capsule list, the catching
animation, storage) comes from the textures folder when a picture is there.

**Poses.** One PNG holds up to seven square frames side by side, in this order:

1. `closed`: someone inside
2. `empty`: nobody inside
3. `open`: letting someone in or out
4. `shake1`, 5. `shake2`, 6. `shake3`: the wobble while catching (tilted left, upright, tilted right)
7. `icon`: a small version for lists

See `docs/templates/capsule-sheet-guide.png` (and `capsule-sheet-example.png`, the built-in
capsule drawn that way). Frames you leave out reuse the first one; missing shake frames are made
by tilting it. A single pose can also be its own file: `ui/ball-open.png`, `ui/ball-4-shake2.png`.

**Kinds.** Each creature can show a different capsule: `ui/ball-<kind>.png`, where `<kind>` is
any name you like (`great`, `luxury`…) or the ball number a PKHeX file carries. Creatures brought
over from PKHeX keep their ball's number, so a set named by number lines up by itself. Change a
creature's capsule in **Storage → Summary → Capsule**, and an empty capsule's look with **Look**
on the dock or the phone's Capsules screen. Wild creatures caught on a walk take the look of the
capsule that caught them.

## Your species, moves and natures

**Settings → Names and setup → Bring in data and sprites** walks through each file in order:
species, moves, learnsets, natures and move descriptions. Each step has **Download for me**: the
PC fetches the file itself, so nothing has to be copied. Paste and **Load a file** still work, and
**Check and add** says if a paste was the wrong file or got cut off part-way.

**Settings → Data and art** has the rest, also on the last setup step:

- **Experience, growth and effort**: base experience, growth rate, effort yield, base
  friendship, catch rate and habitat, from PokéAPI's open data tables (`pokemon.csv`,
  `pokemon_species.csv`, `pokemon_stats.csv`). Download them, or paste any of them.
- **Creature sprites**: download one picture per species from Showdown's sprite folders or
  PokéAPI's sprite set (front and back), from any address you type with `{num}` (number),
  `{num3}` (001), `{sd}` (Showdown name) or `{id}` in it, or **cut up a sprite sheet**: one big
  picture with all of them in a grid, read left to right from the number you give. **Trim
  empty space** crops each one so it fills its frame.
- **Trainer pictures**: download every PNG listed in a web folder (Showdown's trainer folder is
  filled in), or choose files.

**Settings → Debug** adds any creature with a click (or one of every species), shows which
species have sprites for each pose, and removes test creatures in bulk.

The full reference is in [adding-your-data.md](adding-your-data.md).

## Bringing creatures from PKHeX

**Storage → Import from PKHeX…** accepts `.pk8`, `.pb8`, `.pk9` and the encrypted `.ek8`, `.eb8`,
`.ek9`. In PKHeX, right-click a creature → *Save as…* (or drag it out of the box) to get one.

What comes across:

- species — by national number, or by the species name the file carries for species that
  Scarlet/Violet number differently; if neither matches, you pick it
- nickname, level, nature (by name, or the stats it raises and lowers), ability slot, moves (by
  number) with their PP, IVs → genes, EVs → effort, friendship with whoever holds it now
- original trainer, game, met date and level, special-event flag, shiny
- memories: hatching, meeting the first trainer, the memories the games record with the original
  trainer and the most recent one, then arriving here — shown in its memories tagged with the
  game they came from

Moves or natures missing from your data set are listed after the import. The same file can't be
imported twice. Eggs need to hatch first. Legends: Arceus (`.pa8`) and older formats are not read
yet; convert them in PKHeX first.

Teams exported from Showdown are never imported: creatures go to Showdown to battle, and only the
results come back.
