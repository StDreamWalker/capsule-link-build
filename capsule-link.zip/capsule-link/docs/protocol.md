# Capsule Link protocols

Everything a capsule, the dock, the PC app and the phone app say to each other. The
reference code is in `shared/engine/capsule.js` (tag format), `desktop/src/renderer/dock.js`
(dock serial), `shared/net/hub.js` (WebSocket hub) and the two firmware sketches.

## 1. What is on a capsule tag

A capsule is an NFC Forum Type 2 tag: **NTAG215**, **NTAG216**, or (recommended, because the
capsule's own microcontroller can also reach the memory over I2C) **NTAG I2C plus**
(NT3H2111 or NT3H2211). NTAG213 is too small.

User memory starts at page 4 and holds one NDEF message (232 bytes = 58 pages):

| User byte | Page | I2C block | Content |
|---:|---:|---:|---|
| 0–1 | 4 | 1 | NDEF TLV: `03`, length `E3` |
| 2–31 | 4–11 | 1–2 | Record 1 header + MIME type `application/vnd.capsulelink` |
| 32–159 | 12–43 | 3–10 | **MAIN** record (128 bytes) |
| 160–191 | 44–51 | 11–12 | **WALK** record (32 bytes) |
| 192–228 | 52–61 | 13–15 | Record 2: Android Application Record `com.capsulelink.app` |
| 229 | 61 | 15 | `FE` terminator |

The MIME type is exactly 27 characters long so both records start on 16-byte boundaries.
The Android Application Record means tapping a capsule to an Android phone opens the app.

All multi-byte numbers are **big-endian**. Checksums are **CRC-16/CCITT-FALSE**
(polynomial 0x1021, initial value 0xFFFF; "123456789" gives 0x29B1).

### MAIN — written only by the PC and the phone

| Offset | Bytes | Field |
|---:|---:|---|
| 0 | 2 | magic "CL" |
| 2 | 1 | format version |
| 3 | 1 | flags (bit0 = holds a creature) |
| 4 | 1 | mode 0 desk / 1 walk / 2 battle / 3 sleep |
| 5 | 1 | primary type index |
| 6 | 4 | dataset fingerprint |
| 10 | 8 | creature uid |
| 18 | 2 | species number |
| 20 | 1 | level |
| 21 | 1 | temperament index |
| 22 | 4 | experience |
| 26 | 1 | friendship |
| 27 | 4 | needs: fullness, joy, energy, tidiness |
| 31 | 1 | status |
| 32 | 2 | current HP |
| 34 | 6 | genes (hp atk def spa spd spe) |
| 40 | 6 | effort (same order) |
| 46 | 12 | 4 moves: uint16 move number + uint8 PP |
| 58 | 4 | total steps walked |
| 62 | 4 | updated at (unix seconds) |
| 66 | 12 | nickname (UTF-8) |
| 78 | 10 | trainer (UTF-8) |
| 88 | 1 | cry note count |
| 89 | 24 | cry: 12 × (MIDI note, ticks of 40 ms) |
| 113 | 3 | LED colour RGB |
| 116 | 2 | sync id of last sync |
| 118 | 4 | walk steps already counted |
| 122 | 4 | reserved |
| 126 | 2 | CRC-16/CCITT-FALSE of bytes 0–125 |

The species and move numbers refer to the `no` fields in the Data Lab. The dataset fingerprint lets
a device warn when a capsule was written with a different species list.

### WALK — written by the capsule, reset by the PC/phone

| Offset | Bytes | Field |
|---:|---:|---|
| 0 | 2 | magic "WK" |
| 2 | 2 | sync id (set by PC/phone on reset) |
| 4 | 4 | steps since reset |
| 8 | 2 | bump count |
| 10 | 4 | last bumped capsule (low 4 UID bytes) |
| 14 | 4 | last bump time (capsule seconds) |
| 18 | 2 | cries played |
| 20 | 2 | wiggles |
| 22 | 2 | times picked up |
| 24 | 1 | battery % (255 unknown) |
| 25 | 1 | firmware version |
| 26 | 1 | flags |
| 27 | 3 | reserved |
| 30 | 2 | CRC-16 of bytes 0–29 |

### Syncing safely

When the PC or phone syncs a capsule it:

1. reads MAIN and WALK and works out the steps walked since the last sync:
   `walk.syncId == main.syncId ? walk.steps : max(0, walk.steps − main.walkCounted)`
2. applies those steps to the creature (friendship, experience, finds),
3. writes MAIN with a **new sync id** and `walkCounted = walk.steps`,
4. then writes WALK with the same new sync id and `steps = 0`.

If the capsule is pulled away between steps 3 and 4, the next reading sees mismatched sync ids
and only counts the steps beyond `walkCounted`, so nothing is counted twice.

The capsule firmware keeps its unsaved steps in RAM, re-reads both records whenever an NFC field
goes away (its FD pin), and adds the RAM steps on top of whatever it finds.

## 2. Dock serial protocol

USB serial at 115200 baud, one JSON object per line.

| Direction | Message | Meaning |
|---|---|---|
| PC → dock | `{"id":1,"cmd":"info"}` | Reply has `fw`, `reader`, and `tag` if one is docked |
| PC → dock | `{"id":2,"cmd":"read","page":4,"count":16}` | Reply `{"id":2,"ok":true,"hex":"…"}` (max 32 pages) |
| PC → dock | `{"id":3,"cmd":"write","page":12,"hex":"…"}` | Whole pages, page ≥ 4, max 32 pages |
| PC → dock | `{"id":4,"cmd":"led","mode":"solid","rgb":"55ccff"}` | `solid`, `pulse` or `off` |
| PC → dock | `{"id":5,"cmd":"tone","notes":[[76,2],[79,4]]}` | MIDI note + ticks of 40 ms |
| dock → PC | `{"ev":"hello","fw":"dock-1.0","reader":"PN532"}` | After reset |
| dock → PC | `{"ev":"tag","uid":"04A1B2C3D4E5F6","size":496}` | Capsule placed |
| dock → PC | `{"ev":"removed","uid":"04A1B2C3D4E5F6"}` | Capsule lifted |
| dock → PC | `{"id":2,"ok":false,"error":"Read failed"}` | Any failed command |

## 3. Phone ⇄ PC hub (WebSocket)

The PC app listens on **TCP 47820** (it tries 47822, 47824… if that is busy) and broadcasts a UDP
beacon on **47821** every 3 seconds: `{"app":"capsule-link","name":"<hostname>","port":47820,"v":1}`.
Messages are JSON objects with a `type`.

| From | Type | Body |
|---|---|---|
| phone | `hello` | `deviceId`, `name`, `kind`, and `pairCode` (first time) or `token` |
| hub | `welcome` | `token` (save it), `trainer`, `datasetHash` |
| phone | `sync.push` | `events` (queued changes), `creatures` (ones the PC has never seen), `datasetHash` |
| hub | `sync.state` | `pocket` (creatures on this phone or in capsules), `all` (summary of every creature), `inventory`, `capsules`, `acked`, and `dataset` when the phone's fingerprint differs |
| phone | `sync.pull` | Ask for `sync.state` without sending anything |
| phone | `pocket.take` / `pocket.return` | `uids` (and on return, the phone's latest copies) |
| any | `battle.find` | `mode` (`bump` or `code`), `code`, `name`, `showdown` (your Showdown name), `capsules` (last 8 hex digits of each capsule's NFC id), `format`, `server` |
| hub | `battle.waiting` | `mode`, `code` |
| any | `battle.bump` | `elapsed` (ms since the bump happened) |
| hub | `battle.matched` | `role` (`challenge` or `accept`), `format`, `server`, `opponent` {`name`, `showdown`, `capsules`} |
| hub | `battle.nomatch` | Nobody bumped back in time, or you cancelled |

Events in `sync.push` are applied with the same rules on both sides, and each has an id so it is
never applied twice: `walk`, `care`, `battle`, `evolve`, `learn`, `rename`, `snapshot` (newest copy
of a creature that lives in a capsule wins), `items` and `capsule`.

Bump battles: both phones send `battle.find` with `mode: "bump"`, then `battle.bump` when the
accelerometer (or a capsule beacon) reports a knock. The hub pairs two bumps that happened within
1.5 seconds of each other and sends both `battle.matched`. The battle itself is played on
Pokémon Showdown (section 5).

## 5. The Showdown bridge

The apps show Showdown's real site and add one script before it loads
(`bridgeScript()` in `shared/engine/showdown.js`). It changes nothing on the page except a small
Capsule team panel. It:

- wraps `window.WebSocket` so it sees Showdown's own messages (plain websocket or SockJS frames),
- reads `|updateuser|` for your name and `|updatechallenges|` for incoming challenges,
- for a matched battle sends `|/utm <packed team>` then `|/challenge <name>, <format>`, or waits for
  their challenge and sends `|/utm <packed team>` then `|/accept <name>`,
- collects each `>battle-…` room's lines (leaving out chat and `|request|`) and, at `|win|` or
  `|tie`, calls `CapsuleBridge.post({"type":"battle","room":…,"user":…,"log":…})`.

Android delivers those posts through a `JavascriptInterface` in `ShowdownActivity`; the PC
through the Showdown window's preload. The app then matches your side by the nicknames it gave
your team (made unique per team) and works out the rewards.

## 4. Capsule Bluetooth beacon

In battle mode a tap makes the capsule advertise for 8 seconds with manufacturer data (company id
`0xFFFF`):

| Byte | Content |
|---:|---|
| 0–1 | `43 4C` ("CL") |
| 2 | beacon version (1) |
| 3–6 | last four bytes of the tag UID |
| 7–8 | bump count, little-endian |
| 9 | mode (0 desk, 1 walk, 2 battle, 3 sleep) |
| 10 | battery % |

The phone app (Link → Listen for capsule bumps) scans for this. When one of your capsules' bump
count goes up, it waits 1.5 seconds for another capsule's beacon. If that one belongs to a saved
friend, the two phones go straight to Showdown (the smaller Showdown id sends the challenge);
otherwise the phone pairs through the PC or pairing server like a phone bump.
