# Example creature: how much space it takes on a ball

Made by `node tools/example-monster.mjs --write`. The full record format is described in shared/engine/fullRecord.js.

Example creature: Moonbeam (Gloomoth), Lv. 58, shiny (square), 20 core memories, 20 likes, 5 friends, 3 clothes

| What | Bytes | Deflated | Smallest NFC tag that holds it (deflated, plus ~75 B of NDEF wrapping) |
|---|---:|---:|---|
| Today's tag record (summary: MAIN 128 + WALK 32) | 160 | — | NTAG215 |
| Full record without the original game file | 1494 | 970 | NTAG I2C plus 2k |
| Full record with the original game file (344 B) | 1841 | 1367 | NTAG I2C plus 2k |
| Full record + game file + 20-entry journal | 2365 | 1527 | NTAG I2C plus 2k |
| Everything as JSON (what the PC keeps) | 4823 | 2020 | none (needs the ball’s own memory) |

Tag user memory: NTAG213 144 B, NTAG215 504 B, NTAG216 / NTAG I2C plus 1k 888 B, NTAG I2C plus 2k 1912 B.
