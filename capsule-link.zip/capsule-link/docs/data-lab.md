# Data Lab guide

The Data Lab (PC app) holds every species, move, ability list, growth curve, temperament (nature),
item and formula. Battles run on Pokémon Showdown, so damage, type matchups and move effects come
from Showdown; the Data Lab decides everything outside battle and the rewards after it.

The apps contain no built-in game data beyond 15 original placeholder creatures. Replace them
with whatever you like. Phones receive the data set from the PC when
they sync.

Edits are kept in a draft until you press **Save data set**.

**Filling it with every species, move and sprite:** follow [adding-your-data.md](adding-your-data.md).
It covers the fastest order, Showdown's data files, the spreadsheet templates in
[templates/](templates/) and sprite naming.

## Pasting data

**Paste** tab: paste anything and press **Read paste**. It understands:

- **Tables** copied from a spreadsheet or a web page (tab, comma, semicolon or `|` separated).
  The first row should be headers.
- **JSON** — a list of objects, an object of objects keyed by id, or `{ "species": [...] }`.
- **JavaScript object literals** — unquoted keys, single quotes, trailing commas, comments and an
  `export const Something = ` prefix are all fine.
- **Showdown's data files** — `pokedex.ts`, `moves.ts`, `learnsets.ts` and `natures.ts` are recognised
  and imported as species, moves, learnsets and natures. Use **Load a file** for big ones.
- **Learnset lines** such as `Lv. 12 Vine Lash`, `12 - Vine Lash`, `Vine Lash 12`, `Start Nudge`
  (level 1) or `Evo Cheer` (learned on growing).

Columns are matched to fields automatically (for example `Sp. Atk`, `SpA`, `special attack` and
`baseStats.spa` all become Sp. Attack). Check the dropdowns, look at the preview rows, then import.
**Add to and update** keeps what you have; **replace** clears that list first.

Unknown types and growth rates are created for you (with a warning). Moves named in a learnset
that do not exist yet become placeholders you can fill in on the Moves tab.

### Species fields

`name`, `no` (the number capsules store, 1–65535), `type1`, `type2` (or one `types` column like
`Fire/Flying`), `hp atk def spa spd spe`, `abilities` (or `ability1`, `ability2`,
`hiddenAbility`; Showdown's `abilities: {0: …, H: …}` works too), `showdownName`, `growthRate`,
`baseExp`, `baseFriendship`, `flavor`, `habitat` (a biome id), `cry`, `height`, `weight`,
`evolvesTo`, `evolveLevel`.

`baseExp` and the effort yield are what your creatures earn for defeating that species in a
Showdown battle, so include them for every species you will battle against.

### Move fields

`name`, `no`, `type`, `category` (physical / special / status), `power`, `accuracy` (blank, `—`
or `true` = never misses), `pp`, `desc`. These are shown on summaries and learnsets; Showdown
uses its own move data in battle, matched by name.

## Formulas

Each formula is a tiny program. One statement per line; `name = expression` stores a value;
the last line is the answer. `//` or `#` starts a comment.

```
// experience for one defeated foe, shared between the creatures that faced it
base = baseExp * foeLevel / 7
bonus = linked ? 1.5 : 1
floor(base * bonus / max(1, participants))
```

| Syntax | Meaning |
|---|---|
| `+ - * / %` and `^` | Arithmetic (`^` is power) |
| `== != < <= > >=` `&&` `\|\|` `!` | Comparisons and logic |
| `a ? b : c` | Choice |
| `[100, 200, 400][tier]` | Lists and indexing |
| `floor ceil round trunc abs sqrt pow log exp min max clamp lerp sign sum len has` | Functions |
| `rand()`, `rand(a, b)`, `randInt(a, b)`, `chance(percent)` | Randomness (seeded, so phone and PC agree) |

Division by zero returns 0. A formula that fails falls back to the built-in default so a typo never
loses a battle's rewards; the Formulas tab shows errors with line and column as you type.

## How a Showdown battle becomes rewards

The app reads the finished log: who was sent out when, who fainted, who won. Every foe that
faints gives experience (the formula above) and its effort yield to each of your creatures that
was out at the same time as it and had not fainted. Friendship changes by +3 for a win and +1 for a
loss, minus 1 if that creature fainted. Genes become IVs, effort becomes EVs, temperament becomes
the nature, and friendship becomes Happiness when the team goes to Showdown.

| Formula | Variables |
|---|---|
| HP stat, other stats | `base genes effort level` (+ `temper`): shown in the apps; Showdown calculates its own |
| Experience after a battle | `baseExp foeLevel level participants linked` (per defeated foe, shared by your creatures that faced it) |
| Friendship from walking | `steps friendship` |
| Experience from walking | `steps level` |
| Item find chance (per roll) | `friendship` |

Growth rates are formulas of `n` (the level) giving the **total** experience needed to reach it.

## Numbers and capsules

Capsules store species and moves by number. If you renumber after writing capsules, sync every
capsule at the dock once so they are rewritten. The Data Lab warns you when numbering changes.
