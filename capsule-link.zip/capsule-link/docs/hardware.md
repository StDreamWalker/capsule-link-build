# Building the dock and the capsules

You can start with no electronics at all: a plain **NTAG215 sticker** stuck inside a ball is
already a working capsule for the PC dock and the phone (the phone counts steps instead of the
capsule). Add the electronics below when you want the capsule to count steps, cry, wiggle and
bump on its own.

## Dock (the receptacle on your desk)

| Part | Notes |
|---|---|
| Microcontroller with USB | ESP32-S3 dev board, XIAO ESP32-S3, Raspberry Pi Pico, or Arduino Leonardo |
| PN532 NFC module | The common red "PN532 NFC RFID V3" board, set to **I2C** (switch 1 ON, switch 2 OFF) |
| WS2812 ring, 12 LEDs | Optional glow around the cradle |
| Passive buzzer | Optional; plays the creature's cry when it arrives |
| 3D-printed or turned cradle | The ball rests in a cup; the PN532 antenna sits flat underneath, centred |

Wiring (ESP32-S3 example — any I2C pins work, set them in the sketch):

| PN532 | Board |
|---|---|
| VCC | 3V3 (or 5V if your module has a regulator) |
| GND | GND |
| SDA | SDA (GPIO 8 on many S3 boards) |
| SCL | SCL (GPIO 9) |

| Extra | Board |
|---|---|
| WS2812 DIN | `LED_PIN` (default 8) through a 330 Ω resistor; 5V and GND to the ring |
| Buzzer + | `BUZZER_PIN` (default 9), buzzer − to GND |

Keep the tag inside the ball within about **1–2 cm** of the PN532 antenna, and keep metal
(including batteries) away from the space between them. If reads are flaky, lower the cradle
or move the tag closer to the bottom of the ball.

Flashing: open `firmware/dock/dock.ino` in the Arduino IDE, install **Adafruit PN532**,
**ArduinoJson** (v7) and **Adafruit NeoPixel**, pick your board, upload. The Serial Monitor at
115200 baud should print `{"ev":"hello",…}`; placing a tag prints `{"ev":"tag",…}`.
Then in the PC app: **Capsule dock → Connect USB dock**.

## Capsule (inside the ball)

| Part | Notes |
|---|---|
| Seeed XIAO ESP32-C3 | Bluetooth LE, I2C, and a built-in LiPo charger (battery pads on the back) |
| NTAG I2C plus module (NT3H2111 or NT3H2211) with antenna | The heart of the capsule: phones and the dock read it over NFC, the XIAO reads it over I2C. Use one with its field-detect (FD) pin broken out. |
| IMU: MPU-6050 (GY-521) or LSM6DS3 / LSM6DSO breakout | Steps and taps. The firmware detects which one you fitted. |
| Passive piezo, 9–12 mm | The cry |
| 10 mm coin vibration motor + NPN transistor (S8050/2N3904) + 1 kΩ + 1N4148 diode | The wiggle |
| LiPo 3.7 V, 300–500 mAh | Whatever fits; a slim pouch cell sits nicely against the inside of the shell |
| 2 × 100 kΩ resistors | Battery voltage divider into `BATT_PIN` |
| Small slide switch | Power off for storage |
| WS2812B-mini (optional) | Lights the ring or the button of the ball |

Wiring (XIAO ESP32-C3 pin numbers are the GPIO numbers used in the sketch):

| Signal | XIAO pin | Goes to |
|---|---|---|
| SDA | GPIO 6 (D4) | NTAG SDA and IMU SDA (4.7 kΩ pull-ups to 3V3 if the modules have none) |
| SCL | GPIO 7 (D5) | NTAG SCL and IMU SCL |
| FD | GPIO 3 (D1) | NTAG FD (open drain, pulled up in software) |
| Buzzer | GPIO 4 (D2) | Piezo +, piezo − to GND |
| Motor | GPIO 5 (D3) | 1 kΩ → transistor base; motor between 3V3 and collector; diode across the motor |
| Battery sense | GPIO 2 (D0) | Middle of the 100k/100k divider between BAT+ and GND |
| LED | GPIO 10 (D10) | WS2812 DIN |
| Power | 3V3, GND | NTAG VCC, IMU VCC |

Placement inside the ball:

- Put the **NTAG antenna flat against the shell** on the side that will face the dock and the
  phone (the bottom of the ball). Nothing metal behind it — if the battery has to be close, put a
  ferrite sheet between them.
- Mount the IMU firmly (hot glue or a printed bracket): a loose IMU makes step counting noisy.
- The vibration motor should touch the shell so the wiggle is felt and seen.

Flashing: open `firmware/capsule/capsule.ino`, choose **XIAO_ESP32C3**, install **Adafruit
NeoPixel**, upload. With the capsule empty it stays quiet. Send a creature to it from the dock
or the phone and it plays its cry.

### How the capsule behaves

| Mode | What it does |
|---|---|
| Desk | Cries or wiggles every 3–12 minutes; cries when picked up after a rest |
| Walk | Counts steps; wiggles and cries every 1,000; saves to the tag every 100 steps or 10 minutes |
| Battle | A sharp tap records a bump and broadcasts a Bluetooth beacon for 8 seconds |
| Sleep | Silent |

Change modes from the PC dock screen or the phone's Capsule screen.

### Battery life

The reference firmware keeps the ESP32-C3 awake and samples motion at 50 Hz, which is simple and
reliable but drains a 400 mAh cell in roughly a day of carrying. To stretch it:

- use the IMU's own step counter and tap interrupt and put the ESP32 in light sleep between them,
- or move to a **Seeed XIAO nRF52840 Sense** (Bluetooth, built-in LSM6DS3 and LiPo charging,
  far lower power) — the tag format and beacon stay the same.

### Charging

The XIAO charges its LiPo from USB-C. For a sealed ball, bring two pogo pins (or a small
magnetic connector) out through the shell and add matching contacts in the dock's cradle, wired
to 5 V. Wireless (Qi) charging works too, but Qi coils interfere with NFC: if you add one to the
dock, keep it off while a capsule is being read.

## Bump battles end to end

1. Set both capsules to **battle** mode (dock or phone).
2. On both phones: Link → **Listen for capsule bumps**, and set your Showdown name on the Battle tab.
3. Knock the balls together. Each capsule beacons its new bump count. The first time, the phones
   pair through the PC or a pairing server and save each other as friends; after that, friends'
   capsules find each other over Bluetooth alone. Both phones get a "Battle found" notification
   and open Showdown, one challenging and one accepting, each with its own team.
