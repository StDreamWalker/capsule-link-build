# Getting the apps

You don't need to install any developer tools.

## Try both in a browser

Open **Preview.html** (in the main folder) in Chrome, Edge or Firefox. Both apps run side by
side, the same as the online preview. Anything that needs real hardware (the dock, NFC, step
counting, Showdown windows) is simulated or switched off there.

## PC (Windows)

1. Unzip **Capsule Link for Windows.zip** anywhere (Documents is fine).
2. Open the folder and run **Capsule Link.exe**.
3. If Windows says it protected your PC: **More info → Run anyway**. (The app isn't signed with
   a paid certificate; that's the only reason for the warning.)

The first start adds Start menu and desktop shortcuts. They use the name and icon you choose in
setup (Settings → Names and setup → App icon), and update when you change them. The window
and taskbar follow them too. To move or remove the app, delete the folder and the shortcuts.

## Phone (Android)

An Android app has to be put together with Google's build tools, which this workspace can't
download. There are two easy ways to get the APK:

**A. Let Claude build it.** Connect GitHub to Claude (claude.ai → Settings → Connectors →
GitHub), then ask for the phone app. Claude uploads the project, runs the build and gives you
the APK.

**B. Build it yourself in GitHub (about 15 minutes, all in the browser).**

1. Make a free account at github.com.
2. Click **+ → New repository**, give it any name, choose **Private**, and create it.
3. On the new repository's page, click **uploading an existing file**.
4. Open the **upload-to-github** folder from this download, select everything inside it
   (the `.github` folder and `capsule-link.zip`) and drag it onto the page. Press **Commit changes**.
   (If the `.github` folder doesn't come along: **Add file → Create new file**, name it
   `.github/workflows/build-apps.yml`, and paste in the contents of that file.)
5. Open the **Actions** tab. A build named "Build the apps" starts on its own; wait for the
   green tick (10–15 minutes).
6. Open **Releases → Latest build** and download **phone-app.apk** on your phone (and
   **pc-app-setup.exe**, a proper installer for the PC, if you want one).
7. On the phone, open the APK. Allow installing from your browser or files app when Android asks.

To bake your own name and icon into the installed apps (what the home screen and Windows show
before the app opens), also upload a `branding` folder with `app-name.txt` (one line) and
`app-icon.png` (square, 512×512). Every time you upload a new copy of `capsule-link.zip`, the
apps build again.

Inside the app, the phone follows everything set up on the PC: names, pictures, the
introduction and the data set arrive with each sync. **Link → Add to home screen** makes a
home-screen icon with your app name and icon. (Android doesn't let an installed app rename
itself, so the shortcut stands in for that.)

## Updates

After this, new versions come as one small **update file** (`capsule-link-update-<version>.clupdate`,
well under 1 MB) instead of two whole apps.

- **PC:** drop the file anywhere on the app's window, or use **Settings → General → Updates →
  Install update file**. Press **Restart now**. Your creatures, save, textures and names aren't
  touched.
- **Phone:** nothing to do. The next time the phone syncs with the PC, it asks
  "Update to v…?". Say yes and the app restarts on the new version a few seconds later.
  **Link → About this app** shows the version, checks again, or goes back to the version that
  came with the app.

Safety nets:

- If an updated PC app fails to start twice in a row, it goes back to its built-in version by
  itself, and Settings says so. **Go back to v…** in Settings does the same by hand.
- Installing a newer full APK on the phone always replaces any update it got from the PC.
- An update only carries the apps' own code. A few changes go deeper than that: a new app engine
  on the PC, or new Android permissions or hardware code on the phone. For those, the PC says a
  full download is needed for that side, and the GitHub build (or Claude) makes a new one. These
  should be rare.

### New phone builds without uninstalling

Every phone build is signed with the same key (`mobile/native/signing`), so a new **phone-app.apk**
installs over the old app and keeps everything on the phone. (The first build with this key needs one
last uninstall, because older builds were signed with a throwaway key.)

Easier still: in the phone app, **Link → About this app → New builds from GitHub**, type your
repository (like `yourname/capsule-link`) and tap **Check GitHub now**. From then on the app checks
by itself twice a day and offers to download and install a new build. The first time, Android asks
you to allow Capsule Link to install apps: allow it, then tap Install again.

## Backups

Both apps can save everything into one JSON file and put it back later.

- **PC:** **Settings → General → Backups → Download backup** saves every trainer, their creatures
  and items, the data set and your names (and your textures, unless you untick that). **Restore a
  backup…** puts one back; what was there just before is kept as a backup of its own, so a restore
  can be undone. The PC also keeps backups by itself: a full one before every update file is
  installed, a daily copy of each trainer (two weeks), and backups sent by phones. They are listed
  under Backups with **Save a copy** and **Restore**.
- **Phone:** **Link → Backups → Download backup**. **Keep on PC** sends a copy to the linked PC,
  which also keeps one by itself once a day and right before the phone updates. **Restore from a
  file**, **Restore from your PC** or **Restore from before the last update** puts one back.

## Building on your own computer (optional)

This is for people who want to change the code. The commands are in the main README, under
"PC app" and "Android app".
