# Adding all your creatures, moves and sprites

This guide fills the apps with your own data set: every species, move, learnset, nature and
sprite. It takes about fifteen minutes. Everything happens in the PC app. Phones pick up the new
data and art the next time they sync.

## The guided way

**Settings → Names and setup → Bring in data and sprites** (also offered on first run) takes you
through every step below in order. Each step has **Download for me**, which fetches the file
straight from its source with no copy and paste. The extras, sprites and trainer pictures are
under **Settings → Data and art** (see [making-it-yours.md](making-it-yours.md)). The rest of this
page is the reference, for doing it by hand.

## The short version

1. **Data Lab → Rules → Start from empty** (or keep the 15 starter creatures and add to them).
2. **Data Lab → Paste**: load these files in this order, pressing **Read paste** and then
   **Import** for each one:
   species → moves → learnsets → natures → the extras table (base exp, growth rate, effort).
3. **Save data set** (top right of the Data Lab).
4. **Settings → Add creature sprites…** and select every sprite PNG at once.
5. Sync each phone once.

The order matters. Learnsets refer to species and moves by name, so those need to exist first.
Otherwise you get placeholder moves and skipped species.

---

## 1. Start clean or add on

**Data Lab → Rules → Start from empty** removes every species, move, type and nature. Growth
curves, items, formulas and rules stay. Nothing is lost until you press **Save data set**.
**Discard** undoes it.

Creatures you already own keep their species *number*. They show up again as soon as a species
with that number exists. If you keep national-dex style numbers, your existing creatures come back
as the right species.

## 2. The fastest path: Showdown's own data files

Battles run on Showdown, so the names in your data set have to be the ones Showdown uses. The
simplest way to get that right is to import Showdown's own data files. They are in the `data/`
folder of the Pokémon Showdown repository on GitHub:

| File | What it gives you | Import as |
|---|---|---|
| `data/pokedex.ts` | names, numbers, types, base stats, abilities, height, weight, evolutions | detected automatically (Species) |
| `data/moves.ts` | names, numbers, type, category, power, accuracy, PP, priority | detected automatically (Moves) |
| `data/learnsets.ts` | level-up moves (it uses the newest generation each species appears in) | detected automatically (Learnset) |
| `data/natures.ts` | nature names with the stat each raises and lowers | detected automatically (Natures) |
| `data/text/moves.ts` (optional) | move descriptions | Moves (*add to and update*) |

For each file, open **Data Lab → Paste** and press **Load a file**. You can also paste the text
straight in, since the `export const … = {` line, comments and the functions inside moves.ts are
all skipped. Check the preview and press **Import**. Large files (learnsets.ts is several MB) are
kept out of the text box so typing stays fast; they still import in about a second.

**Skip alternate forms** (on by default) leaves out alternate forms and Showdown's unofficial
entries. That keeps the list to one entry per species, which makes lists, the ranch and capsules
simpler. Untick it if you want forms as separate species. They get numbers from 10001 up, because
a capsule stores one number per species.

### What Showdown's files do not have: the extras table

Showdown never needs **base experience**, **growth rate** or **effort yield**, so its files leave
them out. The apps use them for experience after battles and walks. Paste one more table with
those columns from any reference you like (a spreadsheet works). Matching is by name. Existing
species are updated and never duplicated. Rows for species you do not have (skipped forms, say)
are ignored, because a table without types or stats never creates species:

```
name      baseExp  growthRate   evHp  evAtk  evDef  evSpA  evSpD  evSpe
Budling   66       medium slow  0     0      0      1      0      0
Bloomer   148      medium slow  0     0      0      1      1      0
```

Template: [`templates/extras-template.csv`](templates/extras-template.csv). Species you leave out
keep 64 base exp, the Steady curve and no effort yield.

## 3. Your own spreadsheet instead

If your data is in a spreadsheet (or you are making up new creatures), copy the cells and paste
them. Tab-separated (straight from Excel/Sheets), CSV, `;` and `|` all work. The first row must be
headers. Start from the templates in [`docs/templates`](templates/):

| Template | Contents |
|---|---|
| `species-template.csv` | one row per species: everything in one table |
| `moves-template.csv` | one row per move |
| `learnset-template.csv` | one row per (species, level, move), for every species at once |
| `learnset-one-species.txt` | the quick typed format for one species |
| `natures-template.csv` | one row per nature |
| `extras-template.csv` | base exp / growth / effort for an existing list |

Headers are matched loosely: `Sp. Atk`, `SpA`, `special attack` and `baseStats.spa` all mean the
same thing. After **Read paste** every field has a dropdown showing which column feeds it. Fix
any it guessed wrong before importing.

### Species columns

| Column | Example | Notes |
|---|---|---|
| `name` | `Budling` | required; also how everything else refers to it |
| `no` | `101` | 1–65535, stored in capsules; keep it stable (see Numbers below) |
| `type1`, `type2` | `sprout`, `gale` | or one `types` column: `Sprout/Gale`. New types are created for you |
| `hp atk def spa spd spe` | `47 44 52 61 60 41` | base stats |
| `ability1`, `ability2`, `hiddenAbility` | `Sun Soak` | or one `abilities` column: `Sun Soak, Root Grip`. Must be Showdown's names to battle |
| `growthRate` | `medium slow` | `fast`/`quick`, `medium fast`/`steady`, `medium slow`/`wavy`, `slow`, `erratic`, `fluctuating` |
| `baseExp` | `66` | experience for defeating it |
| `evHp` … `evSpe` | `0 0 0 1 0 0` | effort yield for defeating it |
| `baseFriendship` | `50` | starting friendship when caught |
| `evolvesTo`, `evolveLevel` | `Bloomer`, `16` | or Showdown's `prevo` + `evoLevel` on the later stage |
| `habitat` | `forest` | biome it likes on the ranch: `meadow forest shoreline volcano cavern tundra desert skyline seafloor marsh starfield crystal` |
| `showdownName` | `Budling-Spring` | only if Showdown calls it something different from `name` |
| `flavor` | `A seed sleeps…` | summary text; quote it if it contains commas |
| `height`, `weight`, `cry` | `0.7`, `6.9` | optional; `cry` is a note string, blank = generated from the species |

Evolutions that need an item, a trade or anything else are set to "at friendship 220" with a
warning. Change them on the species page if you want.

### Move columns

| Column | Example | Notes |
|---|---|---|
| `name` | `Vine Lash` | required |
| `no` | `201` | stored in capsules |
| `type` | `sprout` | |
| `category` | `physical` | `physical`, `special` or `status` |
| `power` | `45` | blank or 0 for status moves |
| `accuracy` | `100` | blank, `—` or `true` = never misses |
| `pp`, `priority` | `25`, `0` | |
| `desc` | `Strikes with a thin vine.` | shown on summaries |
| `showdownName` | | only if Showdown's name differs |

These fields are what the apps show. In battle, Showdown uses its own move data, matched by name.

### Learnsets

As a table, for any number of species: `species, level, move`. Level `0` (or `Evo`) means
"learned on evolving", and level `1` (or `Start`) means "knows it from the start".

For one species, choose **Learnset** and that species in the *for* dropdown, then type lines in
whatever style you have:

```
Start Vine Lash
Lv. 9 Quick Jab
12 - Sure Swipe
Spark Burst 20
Evo Bloom Burst
```

Importing a learnset for a species replaces that species' old learnset, so you can re-import
freely.

### Natures

`name, plus, minus` with stats written as `atk def spa spd spe` (or `Attack`, `Sp. Def`…). Leave
both blank for a neutral nature. Showdown only accepts its own nature names. The starter set's
temperaments have invented names, so import Showdown's `natures.ts` (or fill in a `showdownName`
column) before battling.

## 4. Numbers

A capsule stores a creature as a species number plus move numbers (two bytes each). So:

- **Keep numbers stable.** If you renumber after writing capsules, dock each capsule once so it
  is rewritten. The Data Lab warns you when a save changes numbering.
- Leaving `no` blank hands out the next free number.
- Two entries with the same number (alternate forms in Showdown's files) are separated
  automatically: the later one moves to 10001+.

## 5. Sprites

### Naming

Sprites go in the textures folder under `creatures/`. You do not have to rename anything:
**Settings → Add creature sprites…** takes a whole folder at once, matches each file to a
species, and saves it under the species id. A file matches when its name (ignoring case,
spaces and punctuation) is any of:

| Name style | Example for "Mr. Bristle", no. 122 |
|---|---|
| species id | `mr-bristle.png` |
| name squashed | `mrbristle.png`, `Mr. Bristle.png` |
| name with its form | `bristle-mega.png` for "Bristle-Mega" |
| Showdown name | whatever is in `showdownName`, in any of the styles above |
| number | `122.png`, `0122.png` |

Add a pose to the end for extra animations: `-walk`, `-sleep`, `-happy`, `-blink`, `-back`
(`_walk` works too). For a folder of back views named like the front views, tick **These are back
views** before adding.

Files that match nothing are kept anyway (in case you add that species later), and the result
lists them. **Show species without art** lists who is still using generated pixel art.

### Format

| | Best | Also fine |
|---|---|---|
| Frame size | 32×32 (the built-in size) or 64×64 | any square size; bigger than 64 is shrunk to 64 |
| Animation | square frames side by side in one strip: 4 frames of 32 = 128×32 | a single picture of any shape (padded to a square, standing on the bottom edge) |
| Background | transparent | |
| File | PNG-8 (indexed colour), a few KB | any PNG under 512 KB |

Poses you leave out reuse the idle frames, so one file per species is enough. Pixel art is drawn
without smoothing, so 32 px art stays crisp at every zoom.

### Keeping it fast

- **Crop empty space.** A 96×96 picture with the creature in the middle 40 px wastes most of
  every frame. Trimmed sprites look bigger and load faster.
- **Use indexed colour.** Pixel art rarely needs more than 32 colours, and an indexed PNG is
  roughly a quarter the size of a full-colour one.
- **Stay under 512 KB per file.** Phones copy every sprite from the PC when they sync and skip
  larger files. A full set of 32×32 strips is a couple of MB, which phones handle easily.
- **One strip per pose** rather than one file per frame: a quarter of the files, the same look.

### Backgrounds

`ranch/<biome>.png` (320×180) and `boxes/<biome>.png` (216×180) replace the generated biomes. See
[textures.md](textures.md).

## 6. Keeping the data set fast

- **One entry per species** (leave *Skip alternate forms* on) unless you really want forms
  separate. Lists, searches and capsule lookups stay instant either way, but a list of 1,000 is
  nicer to scroll than 1,500.
- **Level-up moves only.** Showdown's custom game format does not check learnsets, so you
  choose moves freely when building a team. The learnset is only what creatures learn by
  levelling, and that keeps it small.
- **Short flavour text.** Each line is stored on every phone.
- Phones keep the data set and sprites in app storage, not the small browser storage, so a full
  set fits.

## 7. If something looks wrong

| Message or symptom | Cause and fix |
|---|---|
| "N moves were not in the list, so placeholders were added" | Learnsets were imported before moves. Import moves, then the learnsets again |
| "N species in the learnsets are not in your list (skipped)" | Normal for forms you skipped. Otherwise import species first |
| "N rows name species that are not in your list…" | The table has no types or stats, so it only updates. Import the species first, or ignore it for skipped forms |
| "Added new type …" | Types are created from names as they appear. Pick colours on the Types tab |
| Everything went in as species | The file had no telling columns. Choose the right *This is a* option and press **Read paste** again |
| A creature shows generated art despite a file | The file name matches nothing. Check **Show species without art**, rename it to the species id, add it again |
| Showdown rejects the team | A species, move, ability or nature name is not Showdown's. Set `showdownName` for it |
