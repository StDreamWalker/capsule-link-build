// The web copy's "video page" look (Debug → Disguise): the page dresses up as a video site's watch page, and
// the PC app runs as the video in its player. Everything here is made up: the site ("Streamly"), its logo,
// the channel, the videos, the comments. Nothing on it goes anywhere: the search box, buttons and links only
// pretend. The app inside is the ordinary app (the same save, the same everything), in a frame of this page.

const VIDEO = {
  title: 'Cozy creature ranch longplay 🌿 3 hours of chores, races & naps (no commentary)',
  channel: 'Pixel Hearth', subs: '1.24M subscribers', views: '412,806 views', viewsShort: '412K views', when: 'Premiered Oct 24, 2026', ago: '3 weeks ago', likes: '18K', length: 3 * 3600 + 2 * 60 + 15,
  chapters: [[0, 'Intro'], [214, 'Morning chores'], [1460, 'Feeding time'], [2950, 'First race of the day'], [4410, 'Berry farm'], [6120, 'Afternoon naps'], [7900, 'Evening walk'], [9800, 'Night yard & outro']],
  tags: '#longplay #cozygames #nocommentary',
  description: 'Three hours of slow mornings on the ranch: feeding, tidying the yard, a few races from the hammock to the toy box, and a lot of naps. No commentary, no music over the top, just the game.\n\nChapters are in the progress bar. Thanks for keeping me company while you work or study ✨',
};
const RECS = [
  ['Rainy day yard tour 🌧️ every building, every corner', 'Pixel Hearth', '96K views', '1 month ago', '42:18', true],
  ['I let my creatures decide everything for a week', 'Moss & Mallow', '1.1M views', '5 months ago', '24:51', true],
  ['The ULTIMATE berry farm layout (beginner → endgame)', 'Tilled', '388K views', '2 months ago', '18:07', false],
  ['lofi for slow mornings ☕ 2 hour mix', 'quiet hours', '2.3M views', '1 year ago', '2:00:04', true],
  ['Every rare find in one video (and where to look)', 'Fieldnotes Gaming', '742K views', '3 weeks ago', '31:40', false],
  ['Speedrunning the race track with only sleepy creatures', 'Dozy Runs', '210K views', '6 days ago', '12:33', false],
  ['Building a cozy night yard from scratch | no talking', 'Pixel Hearth', '157K views', '2 months ago', '1:12:45', true],
  ['Why do they nap so much? The sleep system explained', 'Game Mechanics Club', '531K views', '4 months ago', '16:22', true],
  ['8 hours of soft rain and a crackling fire', 'Ambient Rooms', '14M views', '3 years ago', '8:00:00', true],
  ['Ranking every toy from worst to best', 'Moss & Mallow', '689K views', '1 month ago', '27:09', true],
  ['My creatures remembered my birthday?!', 'Fieldnotes Gaming', '1.8M views', '7 months ago', '9:48', false],
  ['Late night study session 📚 real time, 4 hours', 'deskside', '903K views', '8 months ago', '4:01:16', false],
  ['The race that broke my heart (they promised…)', 'Dozy Runs', '322K views', '2 weeks ago', '14:56', false],
  ['Autumn yard makeover 🍂 relaxing build', 'Tilled', '276K views', '1 month ago', '58:30', false],
  ['Every creature reacting to music they hate', 'Game Mechanics Club', '2.6M views', '9 months ago', '19:12', true],
  ['Slow living in a creature town — full day, no cuts', 'Pixel Hearth', '1.3M views', '1 year ago', '6:14:02', true],
  ['beginner tips nobody tells you (I wish I knew)', 'Fieldnotes Gaming', '455K views', '3 months ago', '22:37', false],
  ['Snow day! First winter on the farm ❄️', 'Moss & Mallow', '812K views', '11 months ago', '33:05', true],
];
const COMMENTS = [
  ['studywithsol', '2 weeks ago', 'Third time putting this on during finals week. The little naps in the afternoon chapter are weirdly calming.', '2.1K'],
  ['Rowan K.', '3 weeks ago', 'The part at 52:10 where two of them race to the toy box and the slow one still celebrates… 10/10', '1.4K'],
  ['mapleandmoss', '1 week ago', 'Not me working an 8 hour shift with this on loop again', '864'],
  ['Theo Varga', '2 weeks ago', 'Love that there\'s no commentary. Just vibes and tiny footsteps.', '512'],
  ['quietquill', '5 days ago', 'Came for background noise, stayed because I got emotionally invested in the one that keeps losing races', '398'],
  ['Juniper', '3 weeks ago', 'The evening walk chapter is my favourite thing on this site right now', '233'],
];
const AVATAR_COLORS = ['#e8710a', '#1e88e5', '#8e24aa', '#43a047', '#d81b60', '#00897b', '#f4511e', '#5e35b1', '#c0ca33', '#6d4c41'];
const PALETTES = [['#2b5876', '#4e4376'], ['#f7971e', '#ffd200'], ['#1d976c', '#93f9b9'], ['#ee0979', '#ff6a00'], ['#141e30', '#243b55'], ['#c94b4b', '#4b134f'], ['#00b4db', '#0083b0'], ['#3a1c71', '#d76d77'], ['#56ab2f', '#a8e063'], ['#614385', '#516395'], ['#e65c00', '#f9d423'], ['#16222a', '#3a6073'], ['#8e2de2', '#4a00e0'], ['#f857a6', '#ff5858'], ['#0f2027', '#2c5364'], ['#de6262', '#ffb88c'], ['#1f4037', '#99f2c8'], ['#4568dc', '#b06ab3']];
const WORDS = ['WEEK 1', '', 'ENDGAME', '☕', '', 'SPEEDRUN', '', '', '', 'TIER LIST', '?!', '', 'THEY PROMISED', '', '', '', 'WISH I KNEW', '❄️'];

const fmt = (s) => { s = Math.max(0, Math.floor(s)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`; };
const ic = (d, extra = '') => `<svg viewBox="0 0 24 24" ${extra} aria-hidden="true"><path d="${d}"/></svg>`;
// (plain outline icons drawn for this page)
const I = {
  menu: 'M3 6h18v2H3zm0 5h18v2H3zm0 5h18v2H3z',
  search: 'M10 3a7 7 0 0 1 5.6 11.2l5.1 5.1-1.4 1.4-5.1-5.1A7 7 0 1 1 10 3zm0 2a5 5 0 1 0 0 10 5 5 0 0 0 0-10z',
  mic: 'M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.9V21h2v-3.1A7 7 0 0 0 19 11h-2z',
  plus: 'M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z',
  bell: 'M12 22a2.5 2.5 0 0 0 2.4-2h-4.8a2.5 2.5 0 0 0 2.4 2zm7-6V11a7 7 0 0 0-5.5-6.8V3h-3v1.2A7 7 0 0 0 5 11v5l-2 2v1h18v-1l-2-2zm-2 1H7v-6a5 5 0 0 1 10 0v6z',
  like: 'M2 21h4V9H2v12zm20-11a2 2 0 0 0-2-2h-6.3l1-4.6v-.3a1.5 1.5 0 0 0-.4-1L13.2 1 7.6 6.6A2 2 0 0 0 7 8v11a2 2 0 0 0 2 2h9a2 2 0 0 0 1.8-1.2l3-7.1c.1-.2.2-.5.2-.7v-2z',
  dislike: 'M22 3h-4v12h4V3zM2 14a2 2 0 0 0 2 2h6.3l-1 4.6v.3c0 .4.2.8.4 1l1.1 1.1 5.6-5.6A2 2 0 0 0 17 16V5a2 2 0 0 0-2-2H6a2 2 0 0 0-1.8 1.2l-3 7.1c-.1.2-.2.5-.2.7v2z',
  share: 'M15 5.6V2l7 7-7 7v-3.7c-5 0-8.5 1.6-11 5.1 1-5 4-10 11-10.8z',
  save: 'M4 6h12v2H4zm0 5h12v2H4zm0 5h8v2H4zm14-2v-3h-2v3h-3v2h3v3h2v-3h3v-2z',
  dots: 'M12 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm0 2a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm0 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4z',
  play: 'M8 5v14l11-7z',
  pause: 'M6 5h4v14H6zm8 0h4v14h-4z',
  next: 'M6 18l8.5-6L6 6v12zm10-12v12h2V6h-2z',
  vol: 'M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 8v8a4.5 4.5 0 0 0 2.5-4zM14 3.2v2.1a7 7 0 0 1 0 13.4v2.1a9 9 0 0 0 0-17.6z',
  mute: 'M3 9v6h4l5 5V4L7 9H3zm13.6 3 2.7-2.7-1.4-1.4-2.7 2.7-2.7-2.7-1.4 1.4 2.7 2.7-2.7 2.7 1.4 1.4 2.7-2.7 2.7 2.7 1.4-1.4z',
  cc: 'M19 4H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm-8 7H9.5v-.5h-2v3h2V13H11v1a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v1zm7 0h-1.5v-.5h-2v3h2V13H18v1a1 1 0 0 1-1 1h-3a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v1z',
  gear: 'M19.4 13a7.6 7.6 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.4 7.4 0 0 0-1.7-1L15 3h-4l-.4 2.6a7.4 7.4 0 0 0-1.7 1l-2.5-1-2 3.5L6.6 11a7.6 7.6 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1c.5.4 1.1.7 1.7 1L11 21h4l.4-2.6c.6-.3 1.2-.6 1.7-1l2.5 1 2-3.5-2.2-1.9zM13 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z',
  mini: 'M21 3H3a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zm0 16H3V5h18v14zm-2-8h-8v6h8v-6z',
  theater: 'M19 6H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zm0 10H5V8h14v8z',
  full: 'M5 14H3v7h7v-2H5v-5zm-2-4h2V5h5V3H3v7zm16 9h-5v2h7v-7h-2v5zM14 3v2h5v5h2V3h-7z',
  exitFull: 'M3 16h5v5h2v-7H3v2zm5-8H3v2h7V3H8v5zm6 13h2v-5h5v-2h-7v7zm2-13V3h-2v7h7V8h-5z',
  sort: 'M3 18h6v-2H3v2zM3 6v2h18V6H3zm0 7h12v-2H3v2z',
  check: 'M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z',
};
// the site's own mark: a rounded wave-bubble in teal and violet with a small play notch (not anyone's logo)
const LOGO_MARK = `<svg viewBox="0 0 32 32" aria-hidden="true"><defs><linearGradient id="sl-g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#22d3c5"/><stop offset="1" stop-color="#7c5cff"/></linearGradient></defs><path d="M16 2.5c7.7 0 13.5 5.6 13.5 13S23.7 29.5 16 29.5c-2.2 0-4.2-.4-6-1.3L3.5 30l1.7-6A12.9 12.9 0 0 1 2.5 15.5C2.5 8.1 8.3 2.5 16 2.5z" fill="url(#sl-g)"/><path d="M13 10.5v10l8-5z" fill="#fff"/></svg>`;
const FAVICON = 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#22d3c5"/><stop offset="1" stop-color="#7c5cff"/></linearGradient></defs><path d="M16 2.5c7.7 0 13.5 5.6 13.5 13S23.7 29.5 16 29.5c-2.2 0-4.2-.4-6-1.3L3.5 30l1.7-6A12.9 12.9 0 0 1 2.5 15.5C2.5 8.1 8.3 2.5 16 2.5z" fill="url(#g)"/><path d="M13 10.5v10l8-5z" fill="#fff"/></svg>`);

const CSS = `
:root { color-scheme: dark; --bg:#0f0f0f; --fg:#f1f1f1; --fg2:#aaa; --chip:#272727; --chip-h:#3f3f3f; --line:#3f3f3f; --sb:#121212; --hover:#272727; --accent:#7c5cff; --link:#3ea6ff; --desc:#272727; --desc-h:#3f3f3f; --input:#121212; --input-b:#303030; --btn-s:#222; }
@media (prefers-color-scheme: light) { :root { color-scheme: light; --bg:#fff; --fg:#0f0f0f; --fg2:#606060; --chip:#f2f2f2; --chip-h:#e5e5e5; --line:#e5e5e5; --sb:#fff; --hover:#f2f2f2; --link:#065fd4; --desc:#f2f2f2; --desc-h:#e5e5e5; --input:#fff; --input-b:#ccc; --btn-s:#f8f8f8; } }
* { box-sizing: border-box; }
html, body { margin: 0; background: var(--bg); color: var(--fg); font-family: Roboto, Arial, sans-serif; font-size: 14px; -webkit-font-smoothing: antialiased; }
body { overflow-y: scroll; }
button { font: inherit; color: inherit; background: none; border: 0; cursor: pointer; padding: 0; }
svg { width: 24px; height: 24px; fill: currentColor; display: block; }
a { color: inherit; text-decoration: none; }
.sl-head { position: sticky; top: 0; z-index: 50; height: 56px; display: flex; align-items: center; justify-content: space-between; padding: 0 16px; background: var(--bg); }
.sl-start { display: flex; align-items: center; gap: 4px; min-width: 200px; }
.sl-ibtn { width: 40px; height: 40px; border-radius: 50%; display: grid; place-items: center; flex: none; }
.sl-ibtn:hover { background: var(--hover); } .sl-ibtn:active { background: var(--chip-h); }
.sl-logo { display: flex; align-items: center; gap: 4px; padding: 18px 14px 18px 12px; }
.sl-logo svg { width: 30px; height: 30px; }
.sl-logo b { font-family: 'Segoe UI', Roboto, Arial, sans-serif; font-size: 20px; letter-spacing: -.6px; font-weight: 700; }
.sl-logo sup { font-size: 10px; color: var(--fg2); margin: -12px 0 0 2px; }
.sl-center { flex: 0 1 732px; display: flex; align-items: center; margin: 0 40px; }
.sl-search { flex: 1; display: flex; height: 40px; margin-left: 32px; }
.sl-search input { flex: 1; min-width: 0; height: 40px; border: 1px solid var(--input-b); border-right: 0; border-radius: 40px 0 0 40px; background: var(--input); color: var(--fg); font: 16px Roboto, Arial, sans-serif; padding: 0 4px 0 16px; outline: none; }
.sl-search input:focus { border-color: #1c62b9; box-shadow: inset 0 1px 2px rgba(0,0,0,.3); margin-left: -32px; padding-left: 48px; }
.sl-search button { width: 64px; height: 40px; border: 1px solid var(--input-b); border-radius: 0 40px 40px 0; background: var(--btn-s); display: grid; place-items: center; }
.sl-search button:hover { background: var(--chip); }
.sl-mic { margin-left: 12px; background: var(--btn-s); }
.sl-end { display: flex; align-items: center; gap: 8px; min-width: 225px; justify-content: flex-end; }
.sl-create { display: flex; align-items: center; gap: 6px; height: 36px; padding: 0 16px 0 10px; border-radius: 18px; background: var(--chip); font-weight: 500; }
.sl-create:hover { background: var(--chip-h); }
.sl-bell { position: relative; }
.sl-bell i { position: absolute; top: 2px; right: 0; background: #cc0000; color: #fff; font: 500 11px Roboto, Arial; font-style: normal; padding: 1px 4px; border-radius: 9px; border: 2px solid var(--bg); }
.sl-av { width: 32px; height: 32px; border-radius: 50%; display: grid; place-items: center; color: #fff; font-weight: 500; font-size: 15px; flex: none; user-select: none; }
.sl-page { display: flex; gap: 24px; justify-content: center; padding: 24px 24px 0; max-width: 2200px; margin: 0 auto; }
.sl-primary { flex: 1; min-width: 0; max-width: calc((100vh - 56px - 24px - 136px) * 16 / 9); }
.sl-secondary { width: 402px; flex: none; }
.sl-player { position: relative; width: 100%; aspect-ratio: 16 / 9; background: #000; border-radius: 12px; overflow: hidden; }
.sl-player iframe { position: absolute; left: 0; top: 0; border: 0; transform-origin: 0 0; background: #14122b; }
.sl-ctl { position: absolute; left: 0; right: 0; bottom: 0; height: 120px; padding: 0 12px; display: flex; flex-direction: column; justify-content: flex-end; background: linear-gradient(transparent, rgba(0,0,0,.72)); color: #fff; opacity: 0; transition: opacity .25s cubic-bezier(.4,0,.2,1); pointer-events: none; }
.sl-player.show .sl-ctl, .sl-player.paused .sl-ctl { opacity: 1; }
.sl-player.show .sl-ctl > *, .sl-player.paused .sl-ctl > * { pointer-events: auto; }
.sl-prog { position: relative; height: 16px; display: flex; align-items: center; cursor: pointer; }
.sl-prog .rail { position: relative; flex: 1; height: 3px; display: flex; gap: 2px; transition: height .1s; }
.sl-prog:hover .rail { height: 5px; }
.sl-prog .seg { position: relative; height: 100%; background: rgba(255,255,255,.2); overflow: hidden; }
.sl-prog .seg .buf { position: absolute; inset: 0 auto 0 0; background: rgba(255,255,255,.4); }
.sl-prog .seg .done { position: absolute; inset: 0 auto 0 0; background: var(--accent); }
.sl-prog .knob { position: absolute; top: 50%; width: 13px; height: 13px; margin: -6.5px 0 0 -6.5px; border-radius: 50%; background: var(--accent); transform: scale(0); transition: transform .1s; }
.sl-prog:hover .knob { transform: scale(1); }
.sl-bar { height: 48px; display: flex; align-items: center; gap: 0; }
.sl-bar .b { width: 48px; height: 48px; display: grid; place-items: center; opacity: .92; }
.sl-bar .b:hover { opacity: 1; }
.sl-bar .b svg { width: 26px; height: 26px; filter: drop-shadow(0 0 2px rgba(0,0,0,.5)); }
.sl-bar .time { font-size: 13px; padding: 0 10px; white-space: nowrap; text-shadow: 0 0 2px rgba(0,0,0,.5); font-variant-numeric: tabular-nums; }
.sl-bar .time span { color: #ddd; }
.sl-bar .chap { font-size: 13px; color: #eee; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; text-shadow: 0 0 2px rgba(0,0,0,.5); }
.sl-bar .grow { flex: 1; }
.sl-vol { display: flex; align-items: center; }
.sl-vol .slider { width: 0; overflow: hidden; transition: width .2s; height: 48px; display: flex; align-items: center; }
.sl-vol:hover .slider { width: 64px; }
.sl-vol .slider i { display: block; width: 52px; height: 3px; margin-left: 4px; background: linear-gradient(90deg, #fff 70%, rgba(255,255,255,.3) 70%); position: relative; }
.sl-vol .slider i::after { content: ''; position: absolute; left: 70%; top: -5px; width: 12px; height: 12px; margin-left: -6px; border-radius: 50%; background: #fff; }
.sl-tog { width: 36px; height: 14px; border-radius: 7px; background: rgba(255,255,255,.3); position: relative; margin: 0 8px; }
.sl-tog::after { content: ''; position: absolute; top: -3px; left: 18px; width: 20px; height: 20px; border-radius: 50%; background: #fff; display: grid; }
.sl-hd { position: relative; } .sl-hd::after { content: 'HD'; position: absolute; top: 9px; right: 7px; background: var(--accent); color: #fff; font: 700 8px Roboto, Arial; padding: 1px 2px; border-radius: 2px; }
.sl-big { position: absolute; left: 50%; top: 50%; width: 68px; height: 48px; margin: -24px 0 0 -34px; border-radius: 14px; background: rgba(0,0,0,.6); display: grid; place-items: center; color: #fff; opacity: 0; pointer-events: none; }
.sl-big.pop { animation: sl-pop .6s ease-out; }
@keyframes sl-pop { 0% { opacity: .9; transform: scale(.8); } 100% { opacity: 0; transform: scale(1.4); } }
.sl-player.theater-on { border-radius: 0; }
.sl-title { font-size: 20px; line-height: 28px; font-weight: 700; margin: 12px 0 0; word-break: break-word; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.sl-row { display: flex; align-items: center; justify-content: space-between; margin-top: 12px; gap: 8px; flex-wrap: wrap; }
.sl-owner { display: flex; align-items: center; min-width: 0; }
.sl-owner .sl-av { width: 40px; height: 40px; font-size: 18px; margin-right: 12px; }
.sl-owner .nm { font-size: 16px; font-weight: 500; line-height: 22px; display: flex; align-items: center; gap: 4px; }
.sl-owner .nm svg { width: 14px; height: 14px; color: var(--fg2); }
.sl-owner .sb { color: var(--fg2); font-size: 12px; line-height: 18px; }
.sl-sub { margin-left: 24px; height: 36px; padding: 0 16px; border-radius: 18px; background: var(--fg); color: var(--bg); font-weight: 500; }
.sl-sub:hover { opacity: .88; }
.sl-sub.on { background: var(--chip); color: var(--fg); display: flex; align-items: center; gap: 6px; padding: 0 12px; }
.sl-sub.on svg { width: 20px; height: 20px; }
.sl-acts { display: flex; gap: 8px; align-items: center; }
.sl-pill { height: 36px; border-radius: 18px; background: var(--chip); display: flex; align-items: center; font-weight: 500; white-space: nowrap; }
.sl-pill > button { height: 36px; display: flex; align-items: center; gap: 6px; padding: 0 16px; border-radius: 18px; }
.sl-pill > button:hover { background: var(--chip-h); }
.sl-pill svg { width: 22px; height: 22px; }
.sl-pill.split > button:first-child { border-radius: 18px 0 0 18px; padding-right: 12px; }
.sl-pill.split > button:last-child { border-radius: 0 18px 18px 0; padding: 0 14px 0 12px; position: relative; }
.sl-pill.split > button:last-child::before { content: ''; position: absolute; left: 0; top: 6px; bottom: 6px; width: 1px; background: rgba(128,128,128,.4); }
.sl-pill.round > button { width: 36px; padding: 0; justify-content: center; }
.sl-pill .on svg { color: var(--fg); }
.sl-desc { margin-top: 12px; background: var(--desc); border-radius: 12px; padding: 12px; font-size: 14px; line-height: 20px; cursor: pointer; }
.sl-desc:hover { background: var(--desc-h); }
.sl-desc.open { cursor: default; } .sl-desc.open:hover { background: var(--desc); }
.sl-desc .meta { font-weight: 500; } .sl-desc .meta span { color: var(--link); font-weight: 500; }
.sl-desc .txt { white-space: pre-wrap; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.sl-desc.open .txt { display: block; }
.sl-desc .more { font-weight: 500; margin-top: 2px; }
.sl-desc .chaps { display: none; margin-top: 16px; } .sl-desc.open .chaps { display: block; }
.sl-desc .chaps div { display: flex; gap: 12px; padding: 4px 0; } .sl-desc .chaps a { color: var(--link); min-width: 56px; }
.sl-coms { margin: 24px 0 40px; }
.sl-coms h3 { font-size: 20px; font-weight: 700; margin: 0; display: flex; align-items: center; gap: 32px; }
.sl-coms h3 button { display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 500; }
.sl-add { display: flex; gap: 16px; margin: 24px 0 32px; align-items: flex-start; }
.sl-add .sl-av { width: 40px; height: 40px; }
.sl-add input { flex: 1; background: none; border: 0; border-bottom: 1px solid var(--line); color: var(--fg); font: 14px Roboto, Arial; padding: 6px 0 4px; outline: none; }
.sl-add input:focus { border-bottom: 2px solid var(--fg); padding-bottom: 3px; }
.sl-com { display: flex; gap: 16px; margin-bottom: 16px; }
.sl-com .sl-av { width: 40px; height: 40px; }
.sl-com .who { font-size: 13px; font-weight: 500; } .sl-com .who span { color: var(--fg2); font-weight: 400; margin-left: 4px; font-size: 12px; }
.sl-com .body { margin-top: 2px; line-height: 20px; }
.sl-com .acts { display: flex; align-items: center; gap: 4px; margin-top: 4px; color: var(--fg2); font-size: 12px; }
.sl-com .acts button { width: 32px; height: 32px; border-radius: 50%; display: grid; place-items: center; color: var(--fg); }
.sl-com .acts button:hover { background: var(--hover); }
.sl-com .acts svg { width: 18px; height: 18px; }
.sl-com .acts .rep { width: auto; padding: 0 12px; border-radius: 16px; font-weight: 500; margin-left: 8px; font-size: 12px; }
.sl-chips { display: flex; gap: 12px; overflow: hidden; margin-bottom: 12px; mask-image: linear-gradient(90deg, #000 85%, transparent); }
.sl-chips button { height: 32px; padding: 0 12px; border-radius: 8px; background: var(--chip); font-weight: 500; white-space: nowrap; flex: none; }
.sl-chips button:hover { background: var(--chip-h); }
.sl-chips button.on { background: var(--fg); color: var(--bg); }
.sl-rec { display: flex; gap: 8px; margin-bottom: 8px; cursor: pointer; border-radius: 8px; }
.sl-rec .th { position: relative; width: 168px; height: 94px; border-radius: 8px; overflow: hidden; flex: none; background: #222; }
.sl-rec .th canvas { width: 100%; height: 100%; display: block; }
.sl-rec .dur { position: absolute; right: 4px; bottom: 4px; background: rgba(0,0,0,.8); color: #fff; font-size: 12px; font-weight: 500; padding: 1px 4px; border-radius: 4px; }
.sl-rec .watched { position: absolute; left: 0; bottom: 0; height: 3px; background: var(--accent); }
.sl-rec .info { min-width: 0; padding-right: 24px; position: relative; flex: 1; }
.sl-rec .t { font-size: 14px; line-height: 20px; font-weight: 500; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; margin-bottom: 4px; }
.sl-rec .c, .sl-rec .v { color: var(--fg2); font-size: 12px; line-height: 18px; }
.sl-rec .c { display: flex; align-items: center; gap: 4px; } .sl-rec .c svg { width: 12px; height: 12px; }
.sl-rec .menu { position: absolute; right: -8px; top: -6px; width: 36px; height: 36px; border-radius: 50%; display: grid; place-items: center; opacity: 0; }
.sl-rec:hover .menu { opacity: 1; } .sl-rec .menu:hover { background: var(--hover); }
.sl-rec .menu svg { width: 20px; height: 20px; }
.sl-more { width: 100%; height: 36px; border-radius: 18px; border: 1px solid var(--line); color: var(--link); font-weight: 500; margin: 8px 0 32px; }
.sl-more:hover { background: rgba(62,166,255,.1); }
body.theater .sl-tslot { background: #000; }
body.theater .sl-theater .sl-player { width: min(100%, calc((100vh - 56px - 169px) * 16 / 9)); margin: 0 auto; border-radius: 0; }
body.theater .sl-primary { max-width: none; }
.sl-toast { position: fixed; left: 12px; bottom: 12px; background: #f1f1f1; color: #0f0f0f; padding: 14px 16px; border-radius: 8px; font-size: 14px; box-shadow: 0 4px 16px rgba(0,0,0,.4); transform: translateY(calc(100% + 24px)); visibility: hidden; transition: transform .2s, visibility .2s; z-index: 99; }
.sl-toast.on { transform: none; visibility: visible; }
@media (max-width: 1016px) {
  .sl-page { flex-direction: column; padding: 24px 24px 0; }
  .sl-primary { max-width: none; }
  .sl-secondary { width: auto; margin-top: 24px; }
  .sl-end .sl-create span { display: none; } .sl-create { padding: 0 8px; width: 40px; justify-content: center; }
}
@media (max-width: 656px) {
  .sl-head { height: 48px; padding: 0 4px 0 12px; }
  .sl-start { min-width: 0; } .sl-start > .sl-ibtn { display: none; } .sl-logo { padding: 0; }
  .sl-center { display: none; } .sl-end { min-width: 0; gap: 0; } .sl-create { display: none; }
  .sl-end .sl-ibtn.sl-msearch { display: grid; }
  .sl-page { padding: 0; gap: 0; }
  .sl-player { border-radius: 0; }
  .sl-under { padding: 0 12px; }
  .sl-title { font-size: 18px; line-height: 26px; margin-top: 10px; }
  .sl-sub { margin-left: auto; }
  .sl-owner { flex: 1; }
  .sl-acts { overflow-x: auto; width: 100%; scrollbar-width: none; }
  .sl-pill > button { padding: 0 12px; }
  .sl-secondary { padding: 0 12px; }
  .sl-rec { flex-direction: column; margin: 0 -12px 16px; } .sl-rec .th { width: 100%; height: auto; aspect-ratio: 16 / 9; border-radius: 0; }
  .sl-rec .info { padding: 0 36px 0 12px; } .sl-rec .menu { opacity: 1; right: 0; top: 0; }
  .sl-bar .chap, .sl-vol .slider, .sl-bar .b.sl-wide { display: none; }
}
.sl-msearch { display: none; }
`;

/** Turns this page into the watch page and runs the app (the html given, the page itself) as the "video". */
export function startDisguise({ appHtml, allow, turnOff }) {
  document.title = `${VIDEO.title} - Streamly`;
  for (const l of document.querySelectorAll('link[rel~="icon"]')) l.remove();
  document.head.append(Object.assign(document.createElement('link'), { rel: 'icon', type: 'image/svg+xml', href: FAVICON }));
  const st = document.createElement('style'); st.id = 'sl-style'; st.textContent = CSS; document.head.append(st);
  document.documentElement.lang = 'en';

  const av = (name, size) => `<div class="sl-av" style="background:${AVATAR_COLORS[[...name].reduce((a, c) => a + c.charCodeAt(0), 0) % AVATAR_COLORS.length]}${size ? `;width:${size}px;height:${size}px` : ''}">${name.replace(/[^A-Za-z]/g, '').charAt(0).toUpperCase() || '•'}</div>`;
  const verified = ic('M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-1.5 14.5-4-4 1.4-1.4 2.6 2.6 5.6-5.6 1.4 1.4-7 7z');
  const chapAt = (t) => { let c = VIDEO.chapters[0]; for (const x of VIDEO.chapters) if (x[0] <= t) c = x; return c; };
  const segs = VIDEO.chapters.map((c, i) => [c[0], (VIDEO.chapters[i + 1]?.[0] ?? VIDEO.length)]);

  document.body.innerHTML = `
  <header class="sl-head">
    <div class="sl-start"><button class="sl-ibtn" title="Menu">${ic(I.menu)}</button><a class="sl-logo" href="#" title="Streamly Home">${LOGO_MARK}<b>Streamly</b><sup>US</sup></a></div>
    <div class="sl-center"><form class="sl-search" onsubmit="return false"><input placeholder="Search" aria-label="Search"><button title="Search">${ic(I.search)}</button></form><button class="sl-ibtn sl-mic" title="Search with your voice">${ic(I.mic)}</button></div>
    <div class="sl-end"><button class="sl-ibtn sl-msearch" title="Search">${ic(I.search)}</button><button class="sl-create">${ic(I.plus)}<span>Create</span></button><button class="sl-ibtn sl-bell" title="Notifications">${ic(I.bell)}<i>9+</i></button><button class="sl-ibtn" title="Account">${av('Alex', 32)}</button></div>
  </header>
  <div class="sl-tslot"></div>
  <div class="sl-page">
    <div class="sl-primary">
      <div class="sl-theater"><div class="sl-player paused" tabindex="-1">
        <iframe name="cl-player" title="Video player" allow="${allow}"></iframe>
        <div class="sl-big"></div>
        <div class="sl-ctl">
          <div class="sl-prog"><div class="rail">${segs.map(([a, b]) => `<div class="seg" style="flex:${b - a}"><div class="buf"></div><div class="done"></div></div>`).join('')}</div><div class="knob"></div></div>
          <div class="sl-bar">
            <button class="b sl-pp" title="Pause (k)">${ic(I.pause)}</button>
            <button class="b" title="Next (SHIFT+n)">${ic(I.next)}</button>
            <div class="sl-vol"><button class="b sl-mute" title="Mute (m)">${ic(I.vol)}</button><div class="slider"><i></i></div></div>
            <div class="time"><b class="sl-cur">0:00</b> <span>/ ${fmt(VIDEO.length)}</span></div>
            <div class="chap">• <span class="sl-chap"></span> ›</div>
            <div class="grow"></div>
            <div class="sl-tog sl-wide" title="Autoplay is on"></div>
            <button class="b sl-wide" title="Subtitles/closed captions (c)">${ic(I.cc)}</button>
            <button class="b sl-hd" title="Settings">${ic(I.gear)}</button>
            <button class="b sl-wide" title="Miniplayer (i)">${ic(I.mini)}</button>
            <button class="b sl-wide sl-th" title="Theater mode (t)">${ic(I.theater)}</button>
            <button class="b sl-fs" title="Full screen (f)">${ic(I.full)}</button>
          </div>
        </div>
      </div></div>
      <div class="sl-under">
        <h1 class="sl-title">${VIDEO.title}</h1>
        <div class="sl-row">
          <div class="sl-owner">${av(VIDEO.channel)}<div><div class="nm">${VIDEO.channel} ${verified}</div><div class="sb">${VIDEO.subs}</div></div><button class="sl-sub">Subscribe</button></div>
          <div class="sl-acts">
            <div class="sl-pill split"><button class="sl-like" title="I like this">${ic(I.like)}<span>${VIDEO.likes}</span></button><button title="I dislike this">${ic(I.dislike)}</button></div>
            <div class="sl-pill"><button>${ic(I.share)}Share</button></div>
            <div class="sl-pill"><button>${ic(I.save)}Save</button></div>
            <div class="sl-pill round"><button title="More actions">${ic(I.dots)}</button></div>
          </div>
        </div>
        <div class="sl-desc"><div class="meta">${VIDEO.views}&nbsp;&nbsp;${VIDEO.when}&nbsp;&nbsp;<span>${VIDEO.tags}</span></div><div class="txt">${VIDEO.description}</div>
          <div class="chaps"><b>Chapters</b>${VIDEO.chapters.map(([t, n]) => `<div><a href="#" data-t="${t}">${fmt(t)}</a>${n}</div>`).join('')}</div>
          <div class="more">...more</div></div>
        <section class="sl-coms">
          <h3>1,284 Comments <button>${ic(I.sort)}Sort by</button></h3>
          <div class="sl-add">${av('Alex')}<input placeholder="Add a comment..."></div>
          ${COMMENTS.map(([who, when, body, likes]) => `<div class="sl-com">${av(who)}<div><div class="who">@${who.toLowerCase().replace(/[^a-z0-9]/g, '')}<span>${when}</span></div><div class="body">${body}</div><div class="acts"><button>${ic(I.like)}</button>${likes}<button>${ic(I.dislike)}</button><button class="rep">Reply</button></div></div></div>`).join('')}
        </section>
      </div>
    </div>
    <aside class="sl-secondary">
        <div class="sl-chips">${['All', `From ${VIDEO.channel}`, 'Longplays', 'Cozy games', 'Related', 'For you', 'Recently uploaded', 'Watched'].map((c, i) => `<button class="${i ? '' : 'on'}">${c}</button>`).join('')}</div>
        <div class="sl-recs">${RECS.map(([t, c, v, a, d, ver], i) => `<div class="sl-rec"><div class="th"><canvas width="336" height="188" data-i="${i}"></canvas><div class="dur">${d}</div>${i === 3 || i === 8 ? `<div class="watched" style="width:${i === 3 ? 34 : 71}%"></div>` : ''}</div><div class="info"><div class="t">${t}</div><div class="c">${c}${ver ? ` ${verified}` : ''}</div><div class="v">${v} • ${a}</div><button class="menu" title="Action menu">${ic(I.dots)}</button></div></div>`).join('')}</div>
        <button class="sl-more">Show more</button>
    </aside>
  </div>
  <div class="sl-toast"></div>`;
  // (theater mode: the player moves up above both columns, full width, as such pages do)
  const primary = document.querySelector('.sl-primary'), theater = document.querySelector('.sl-theater'), tslot = document.querySelector('.sl-tslot');

  const toastEl = document.querySelector('.sl-toast');
  let toastT = 0;
  const toast = (msg) => { toastEl.textContent = msg; toastEl.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('on'), 2600); };

  // ---------- the "video": the app, drawn at a desktop size and scaled to the player ----------
  const player = document.querySelector('.sl-player'), frame = player.querySelector('iframe'), big = player.querySelector('.sl-big');
  const BASE_W = 1280;
  function fit() {
    const w = player.clientWidth, h = player.clientHeight;
    if (!w || !h) return;
    const full = document.fullscreenElement === player;
    // (full screen: the app at its real size; otherwise a desktop-sized app shrunk to the player, as a recording would be)
    const bw = full ? w : Math.max(BASE_W, w), s = w / bw, bh = h / s;
    Object.assign(frame.style, { width: `${bw}px`, height: `${bh}px`, transform: s === 1 ? 'none' : `scale(${s})` });
  }
  new ResizeObserver(fit).observe(player);
  frame.srcdoc = appHtml;

  // ---------- the controls (they only pretend, except full screen, theater and the shortcuts) ----------
  let playing = true, t = 2464 + Math.floor(Math.random() * 1800), lastTick = performance.now(), hideT = 0, muted = false;
  const cur = player.querySelector('.sl-cur'), chap = player.querySelector('.sl-chap'), segEls = [...player.querySelectorAll('.seg')], knob = player.querySelector('.knob');
  const pp = player.querySelector('.sl-pp'), rail = player.querySelector('.rail');
  function paint() {
    cur.textContent = fmt(t); chap.textContent = chapAt(t)[1];
    const buffered = Math.min(VIDEO.length, t + 95);
    segs.forEach(([a, b], i) => { const el = segEls[i]; el.querySelector('.done').style.width = `${Math.max(0, Math.min(1, (t - a) / (b - a))) * 100}%`; el.querySelector('.buf').style.width = `${Math.max(0, Math.min(1, (buffered - a) / (b - a))) * 100}%`; });
    knob.style.left = `${(t / VIDEO.length) * rail.clientWidth}px`;
  }
  setInterval(() => { const now = performance.now(); if (playing) { t += (now - lastTick) / 1000; if (t >= VIDEO.length) t = 0; } lastTick = now; paint(); }, 250);
  paint();
  player.classList.remove('paused');
  const show = () => { player.classList.add('show'); clearTimeout(hideT); hideT = setTimeout(() => player.classList.remove('show'), 2600); };
  const pop = (icon) => { big.innerHTML = ic(icon); big.classList.remove('pop'); void big.offsetWidth; big.classList.add('pop'); };
  function setPlaying(on) {
    playing = on; player.classList.toggle('paused', !on);
    pp.innerHTML = ic(on ? I.pause : I.play); pp.title = on ? 'Pause (k)' : 'Play (k)';
    pop(on ? I.play : I.pause); show();
  }
  pp.onclick = () => setPlaying(!playing);
  player.querySelector('.sl-mute').onclick = (e) => { muted = !muted; e.currentTarget.innerHTML = ic(muted ? I.mute : I.vol); try { frame.contentWindow.document.querySelectorAll('audio,video').forEach((m) => { m.muted = muted; }); } catch { /* fine */ } };
  player.querySelector('.sl-prog').onclick = (e) => { const r = rail.getBoundingClientRect(); t = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * VIDEO.length; paint(); };
  for (const a of document.querySelectorAll('.sl-desc .chaps a')) a.onclick = (e) => { e.preventDefault(); e.stopPropagation(); t = Number(a.dataset.t); paint(); window.scrollTo({ top: 0, behavior: 'smooth' }); show(); };
  const fsBtn = player.querySelector('.sl-fs');
  const toggleFs = () => { if (document.fullscreenElement) document.exitFullscreen?.(); else player.requestFullscreen?.().catch(() => {}); };
  fsBtn.onclick = toggleFs;
  document.addEventListener('fullscreenchange', () => { fsBtn.innerHTML = ic(document.fullscreenElement ? I.exitFull : I.full); setTimeout(fit, 50); });
  let theaterOn = false;
  function setTheater(on) {
    theaterOn = on; document.body.classList.toggle('theater', on);
    (on ? tslot : primary).prepend(theater);
    try { localStorage.setItem('clweb:disguiseTheater', on ? '1' : '0'); } catch { /* fine */ }
    setTimeout(fit, 30);
  }
  player.querySelector('.sl-th').onclick = () => setTheater(!theaterOn);
  // (narrow windows: the suggestions come between the description and the comments, as on such sites)
  const secondary = document.querySelector('.sl-secondary'), page = document.querySelector('.sl-page'), coms = document.querySelector('.sl-coms');
  const narrowMq = matchMedia('(max-width: 1016px)');
  const place = () => { if (narrowMq.matches) coms.before(secondary); else page.append(secondary); };
  narrowMq.addEventListener?.('change', place); place();
  try { if (localStorage.getItem('clweb:disguiseTheater') === '1') setTheater(true); } catch { /* fine */ }

  // the controls come up when the pointer moves near the bottom of the player (inside the app too), or over them
  player.addEventListener('pointermove', (e) => { if (e.target !== frame) show(); });
  player.addEventListener('pointerleave', () => { if (playing) { clearTimeout(hideT); hideT = setTimeout(() => player.classList.remove('show'), 300); } });
  frame.addEventListener('load', () => {
    try {
      const w = frame.contentWindow;
      w.addEventListener('pointermove', (e) => { const s = frame.getBoundingClientRect().height / w.innerHeight; if ((w.innerHeight - e.clientY) * s < 70) show(); }, { passive: true });
      w.addEventListener('keydown', (e) => { if (e.altKey && e.shiftKey && (e.key === 'D' || e.key === 'd')) { e.preventDefault(); turnOff(); } });
    } catch { /* fine */ }
    fit();
  });

  // ---------- shortcuts on the page (outside the app): k/space, f, t, m, j/l, and Alt+Shift+D to leave ----------
  document.addEventListener('keydown', (e) => {
    if (e.target.closest?.('input, textarea')) return;
    if (e.altKey && e.shiftKey && (e.key === 'D' || e.key === 'd')) { e.preventDefault(); turnOff(); return; }
    const k = e.key.toLowerCase();
    if (k === 'k' || k === ' ') { e.preventDefault(); setPlaying(!playing); }
    else if (k === 'f') toggleFs();
    else if (k === 't') setTheater(!theaterOn);
    else if (k === 'm') player.querySelector('.sl-mute').click();
    else if (k === 'j' || k === 'arrowleft') { t = Math.max(0, t - (k === 'j' ? 10 : 5)); paint(); show(); }
    else if (k === 'l' || k === 'arrowright') { t = Math.min(VIDEO.length - 1, t + (k === 'l' ? 10 : 5)); paint(); show(); }
  });

  // ---------- the rest of the page: it all only pretends ----------
  const desc = document.querySelector('.sl-desc'), more = desc.querySelector('.more');
  desc.onclick = (e) => { if (e.target === more && desc.classList.contains('open')) { desc.classList.remove('open'); more.textContent = '...more'; e.stopPropagation(); return; } if (!desc.classList.contains('open')) { desc.classList.add('open'); more.textContent = 'Show less'; } };
  const sub = document.querySelector('.sl-sub');
  sub.onclick = () => { const on = !sub.classList.contains('on'); sub.classList.toggle('on', on); sub.innerHTML = on ? `${ic(I.bell)}Subscribed` : 'Subscribe'; if (on) toast('Subscription added'); };
  const like = document.querySelector('.sl-like');
  like.onclick = () => { const on = !like.classList.contains('on'); like.classList.toggle('on', on); like.querySelector('span').textContent = on ? '18K' : VIDEO.likes; if (on) toast('Added to Liked videos'); };
  for (const c of document.querySelectorAll('.sl-chips button')) c.onclick = () => { document.querySelectorAll('.sl-chips button').forEach((x) => x.classList.toggle('on', x === c)); };
  document.querySelector('.sl-logo').onclick = (e) => e.preventDefault();
  for (const b of document.querySelectorAll('.sl-rec, .sl-more, .sl-pill button, .sl-create, .sl-bell, .sl-search button, .sl-mic')) if (!b.onclick) b.addEventListener('click', (e) => { e.preventDefault(); if (b.classList.contains('sl-pill') || b.closest('.sl-pill')) toast(b.textContent.trim() === 'Share' ? 'Link copied to clipboard' : b.textContent.trim() === 'Save' ? 'Saved to Watch later' : 'Not available right now'); });

  // thumbnails: soft gradients, a glow and a few shapes, a little like a game still, with an occasional big word
  for (const cv of document.querySelectorAll('.sl-rec canvas')) {
    const i = Number(cv.dataset.i), g = cv.getContext('2d'), [a, b] = PALETTES[i % PALETTES.length], W = cv.width, H = cv.height;
    let seed = i * 9301 + 49297; const rnd = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
    const lg = g.createLinearGradient(0, 0, W, H); lg.addColorStop(0, a); lg.addColorStop(1, b); g.fillStyle = lg; g.fillRect(0, 0, W, H);
    // ground and hills
    g.fillStyle = 'rgba(0,0,0,.18)'; g.beginPath(); g.moveTo(0, H * (0.62 + rnd() * 0.1)); for (let x = 0; x <= W; x += 24) g.lineTo(x, H * (0.6 + Math.sin(x / 40 + i) * 0.05 + rnd() * 0.03)); g.lineTo(W, H); g.lineTo(0, H); g.fill();
    g.fillStyle = 'rgba(0,0,0,.22)'; g.fillRect(0, H * 0.82, W, H * 0.18);
    // a glow (sun or lamp)
    const sx = W * (0.2 + rnd() * 0.6), sy = H * (0.18 + rnd() * 0.25), rg = g.createRadialGradient(sx, sy, 2, sx, sy, 70); rg.addColorStop(0, 'rgba(255,255,230,.9)'); rg.addColorStop(1, 'rgba(255,255,230,0)'); g.fillStyle = rg; g.fillRect(0, 0, W, H);
    // round little creatures and boxes
    for (let k = 0; k < 3 + Math.floor(rnd() * 3); k++) {
      const x = W * (0.1 + rnd() * 0.8), y = H * (0.66 + rnd() * 0.18), r = 10 + rnd() * 18;
      g.fillStyle = `hsl(${Math.floor(rnd() * 360)},70%,${55 + rnd() * 20}%)`; g.beginPath(); g.ellipse(x, y, r, r * 0.86, 0, 0, Math.PI * 2); g.fill();
      g.fillStyle = 'rgba(20,20,30,.85)'; g.beginPath(); g.arc(x - r * 0.3, y - r * 0.15, r * 0.12, 0, 7); g.arc(x + r * 0.3, y - r * 0.15, r * 0.12, 0, 7); g.fill();
    }
    if (rnd() < 0.6) { g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(W * (0.55 + rnd() * 0.3), H * 0.42, 46, 40); g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.moveTo(W * 0.55 + 0, H * 0.42); g.fill(); }
    const word = WORDS[i % WORDS.length];
    if (word) {
      g.save(); g.font = `900 ${word.length <= 2 ? 64 : word.length > 10 ? 30 : 38}px Impact, 'Arial Black', Arial, sans-serif`; g.textBaseline = 'top';
      g.lineWidth = 7; g.strokeStyle = 'rgba(0,0,0,.85)'; g.fillStyle = rnd() < 0.5 ? '#fff' : '#ffe14d';
      const tx = 14, ty = 12; g.strokeText(word, tx, ty); g.fillText(word, tx, ty); g.restore();
    }
    const vg = g.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, W * 0.7); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.35)'); g.fillStyle = vg; g.fillRect(0, 0, W, H);
  }
  fit();
  return { frame };
}
