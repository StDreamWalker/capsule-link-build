#!/usr/bin/env node
// Capsule Link home server: accounts, friends, messages, gifts, trades, yard visits and shared creature
// data, so friends who aren't on the same Wi-Fi can play together. It is small enough to run on an old
// computer at home (any machine with Node 20+), and it also hosts the battle relay.
//
//   node server/home-server.mjs --port 47830 --data ./server-data
//
// Then in the PC app: Friends → Server address → http://<that computer>:47830
// To reach it from outside your home, forward the port on your router (or put it behind a reverse
// proxy with HTTPS, which is strongly recommended once it's on the internet). See docs/home-server.md.
//
// HTTP API (JSON; send "Authorization: Bearer <token>" once signed in):
//   GET  /api/info                            server name, version, how many trainers
//   POST /api/signup   { username, password, trainerName }   → { token, user }
//   POST /api/login    { username, password }                 → { token, user }
//   POST /api/logout
//   GET  /api/me                              your account, with your trainer code
//   GET  /api/friends                         friends, requests in and out
//   POST /api/friends/request { username }    POST /api/friends/accept { username }
//   POST /api/friends/remove  { username }
//   GET  /api/messages?with=<username>        POST /api/messages { to, text }
//   GET  /api/inbox                           gifts and trade offers waiting for you
//   POST /api/gifts    { to, items: { id: n }, coins, note }     POST /api/gifts/claim { id }
//   POST /api/trades   { to, give: { creature?, items? }, want: { note } }
//   POST /api/trades/respond { id, accept, give: { creature?, items? } }   POST /api/trades/claim { id }
//   PUT  /api/ranch    (a .clranch yard snapshot)        GET /api/ranch/<username>
//   POST /api/species/missing { ids: [...] }  → which of these the server has data for
//   PUT  /api/species/<id>  { record, sprites: { anim: hash } }    GET /api/species/<id>
//   PUT  /api/blob/<sha256>  (raw PNG bytes)    GET /api/blob/<sha256>
// WebSocket: /live (send { type: 'auth', token }, then get { type: 'notify', … } pushes)
//            /relay (the battle relay, same as relay/relay.mjs)
import crypto from 'node:crypto';
import { createWsServer } from '../shared/net/wsserver.js';
import { Hub } from '../shared/net/hub.js';
import { Store } from './store.mjs';

export const SERVER_VERSION = 1;
const arg = (name, def) => { const i = process.argv.indexOf(`--${name}`); return i > 0 ? process.argv[i + 1] : process.env[`CL_${name.toUpperCase()}`] ?? def; };

/** Make a server (exported for tests). */
export function makeServer({ port = 47830, dataDir = './server-data', name = 'Capsule Link home server', log = () => {} } = {}) {
  const store = new Store(dataDir);
  const users = store.col('users');        // username → { username, trainerName, code, salt, hash, createdAt, friends: [], reqIn: [], reqOut: [] }
  const sessions = store.col('sessions');  // sha256(token) → { username, at }
  const messages = store.col('messages');  // "a|b" → [{ from, text, at }]
  const inbox = store.col('inbox');        // username → [{ id, kind: 'gift'|'trade', … }]
  const ranches = store.col('ranches');    // username → snapshot
  const species = store.col('species');    // id → { record, sprites, by, at }
  const live = new Map();                  // username → Set(conn)
  const hub = new Hub({ mode: 'relay', name: `${name} (battles)`, log });
  const hits = new Map();                  // ip → { n, at } very simple rate limiting

  const now = () => Date.now();
  const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
  const lc = (s) => String(s ?? '').trim().toLowerCase();
  const pair = (a, b) => [a, b].sort().join('|');
  const pub = (u) => u && { username: u.username, trainerName: u.trainerName, code: u.code };
  const notify = (username, msg) => { for (const c of live.get(username) ?? []) c.send({ type: 'notify', ...msg }); };

  // ---------- accounts ----------
  const USER_RE = /^[a-z0-9_.-]{3,20}$/;
  function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
    return { salt, hash: crypto.scryptSync(String(password), salt, 64).toString('hex') };
  }
  /** A trainer code: 12 random digits, unique on this server ("1234 5678 9012"). */
  function newCode() {
    for (;;) {
      const code = Array.from({ length: 3 }, () => String(crypto.randomInt(0, 10000)).padStart(4, '0')).join(' ');
      if (!Object.values(users).some((u) => u.code === code)) return code;
    }
  }
  function issueToken(username) {
    const token = crypto.randomBytes(32).toString('base64url');
    sessions[sha(token)] = { username, at: now() };
    store.save('sessions');
    return token;
  }
  function who(req) {
    const m = /^Bearer (.+)$/.exec(req.headers.authorization ?? '');
    const s = m && sessions[sha(m[1])];
    if (!s) return null;
    if (now() - s.at > 90 * 86400000) { delete sessions[sha(m[1])]; store.save('sessions'); return null; }
    return users[s.username] ?? null;
  }

  // ---------- http plumbing ----------
  const send = (res, code, body, type = 'application/json') => {
    res.writeHead(code, { 'Content-Type': type, 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS' });
    res.end(type === 'application/json' ? JSON.stringify(body) : body);
  };
  const readBody = (req, max = 2 * 1024 * 1024) => new Promise((resolve, reject) => {
    const chunks = []; let n = 0;
    req.on('data', (d) => { n += d.length; if (n > max) { reject(Object.assign(new Error('Too big'), { code: 413 })); req.destroy(); } else chunks.push(d); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
  const json = async (req) => { const b = await readBody(req); try { return b.length ? JSON.parse(b.toString('utf8')) : {}; } catch { throw Object.assign(new Error('Bad JSON'), { code: 400 }); } };
  const fail = (code, error) => Object.assign(new Error(error), { code });
  const limited = (req) => {
    const ip = req.socket.remoteAddress ?? '?', t = now();
    const h = hits.get(ip) ?? { n: 0, at: t };
    if (t - h.at > 60000) { h.n = 0; h.at = t; }
    h.n++; hits.set(ip, h);
    return h.n > 240;
  };

  async function route(req, res) {
    const url = new URL(req.url, 'http://x');
    const p = url.pathname, M = req.method;
    if (M === 'OPTIONS') return send(res, 204, '', 'text/plain');
    if (limited(req)) throw fail(429, 'Slow down a little.');
    if (p === '/' || p === '/api/info') return send(res, 200, { app: 'capsule-link', kind: 'home-server', version: SERVER_VERSION, name, trainers: Object.keys(users).length, relay: hub.status?.() ?? null });

    if (p === '/api/signup' && M === 'POST') {
      const b = await json(req);
      const username = lc(b.username);
      if (!USER_RE.test(username)) throw fail(400, 'Usernames are 3–20 letters, numbers, dots, dashes or underscores.');
      if (String(b.password ?? '').length < 8) throw fail(400, 'Passwords need at least 8 characters.');
      if (users[username]) throw fail(409, 'That username is taken.');
      const { salt, hash } = hashPassword(b.password);
      users[username] = { username, trainerName: String(b.trainerName ?? username).slice(0, 16), code: newCode(), salt, hash, createdAt: now(), friends: [], reqIn: [], reqOut: [] };
      store.save('users');
      log('signup', username);
      return send(res, 200, { token: issueToken(username), user: pub(users[username]) });
    }
    if (p === '/api/login' && M === 'POST') {
      const b = await json(req);
      const u = users[lc(b.username)];
      const ok = u && crypto.timingSafeEqual(Buffer.from(hashPassword(b.password ?? '', u.salt).hash, 'hex'), Buffer.from(u.hash, 'hex'));
      if (!ok) throw fail(401, 'Wrong username or password.');
      return send(res, 200, { token: issueToken(u.username), user: pub(u) });
    }

    const me = who(req);
    if (!me) throw fail(401, 'Sign in first.');
    if (p === '/api/logout' && M === 'POST') { const m = /^Bearer (.+)$/.exec(req.headers.authorization); delete sessions[sha(m[1])]; store.save('sessions'); return send(res, 200, { ok: true }); }
    if (p === '/api/me') return send(res, 200, { user: pub(me) });

    // friends
    if (p === '/api/friends' && M === 'GET') return send(res, 200, { friends: me.friends.map((f) => pub(users[f])).filter(Boolean), incoming: me.reqIn.map((f) => pub(users[f])).filter(Boolean), outgoing: me.reqOut.map((f) => pub(users[f])).filter(Boolean) });
    if (p.startsWith('/api/friends/') && M === 'POST') {
      const b = await json(req);
      const other = users[lc(b.username)] ?? Object.values(users).find((u) => u.code === String(b.username ?? '').trim());
      if (!other || other === me) throw fail(404, 'No trainer by that name or code here.');
      const act = p.slice('/api/friends/'.length);
      const drop = (list, x) => list.splice(0, list.length, ...list.filter((y) => y !== x));
      if (act === 'request') {
        if (me.friends.includes(other.username)) return send(res, 200, { ok: true, already: true });
        if (me.reqIn.includes(other.username)) { drop(me.reqIn, other.username); drop(other.reqOut, me.username); me.friends.push(other.username); other.friends.push(me.username); notify(other.username, { what: 'friend', from: me.username }); }
        else if (!me.reqOut.includes(other.username)) { me.reqOut.push(other.username); other.reqIn.push(me.username); notify(other.username, { what: 'request', from: me.username }); }
      } else if (act === 'accept') {
        if (!me.reqIn.includes(other.username)) throw fail(400, 'They haven’t asked.');
        drop(me.reqIn, other.username); drop(other.reqOut, me.username);
        me.friends.push(other.username); other.friends.push(me.username);
        notify(other.username, { what: 'friend', from: me.username });
      } else if (act === 'remove') {
        drop(me.friends, other.username); drop(other.friends, me.username); drop(me.reqIn, other.username); drop(me.reqOut, other.username); drop(other.reqIn, me.username); drop(other.reqOut, me.username);
      } else throw fail(404, 'Unknown');
      store.save('users');
      return send(res, 200, { ok: true });
    }
    const friendOf = (username) => { const o = users[lc(username)]; if (!o || !me.friends.includes(o.username)) throw fail(403, 'You can only do that with friends.'); return o; };

    // messages
    if (p === '/api/messages' && M === 'GET') { const o = friendOf(url.searchParams.get('with')); return send(res, 200, { messages: (messages[pair(me.username, o.username)] ?? []).slice(-100) }); }
    if (p === '/api/messages' && M === 'POST') {
      const b = await json(req); const o = friendOf(b.to);
      const text = String(b.text ?? '').trim().slice(0, 500);
      if (!text) throw fail(400, 'Say something!');
      const k = pair(me.username, o.username);
      (messages[k] = messages[k] ?? []).push({ from: me.username, text, at: now() });
      if (messages[k].length > 500) messages[k].splice(0, messages[k].length - 500);
      store.save('messages'); notify(o.username, { what: 'message', from: me.username });
      return send(res, 200, { ok: true });
    }

    // gifts and trades: the server holds them until the other side claims (items/creatures leave the
    // sender's save when sent, and arrive in the receiver's when claimed)
    const box = (u) => (inbox[u] = inbox[u] ?? []);
    const cleanGive = (g = {}) => ({
      items: Object.fromEntries(Object.entries(g.items ?? {}).filter(([k, v]) => /^[\w:-]{1,64}$/.test(k) && Number.isInteger(v) && v > 0 && v <= 99).slice(0, 20)),
      coins: Number.isInteger(g.coins) && g.coins > 0 && g.coins <= 100000 ? g.coins : 0,
      creature: g.creature && typeof g.creature === 'object' && JSON.stringify(g.creature).length < 60000 ? g.creature : null,
    });
    if (p === '/api/inbox' && M === 'GET') return send(res, 200, { inbox: box(me.username).filter((x) => !x.claimed), sent: Object.values(inbox).flat().filter((x) => x.from === me.username && !x.claimed).slice(-30) });
    if (p === '/api/gifts' && M === 'POST') {
      const b = await json(req); const o = friendOf(b.to);
      const give = cleanGive(b);
      if (!Object.keys(give.items).length && !give.coins && !give.creature) throw fail(400, 'Nothing to send.');
      const g = { id: crypto.randomUUID(), kind: 'gift', from: me.username, to: o.username, ...give, note: String(b.note ?? '').slice(0, 140), at: now() };
      box(o.username).push(g); store.save('inbox'); notify(o.username, { what: 'gift', from: me.username });
      return send(res, 200, { ok: true, id: g.id });
    }
    if (p === '/api/gifts/claim' && M === 'POST') {
      const b = await json(req); const g = box(me.username).find((x) => x.id === b.id && x.kind === 'gift' && !x.claimed);
      if (!g) throw fail(404, 'Already opened, or not for you.');
      g.claimed = now(); store.save('inbox');
      return send(res, 200, { gift: g });
    }
    if (p === '/api/trades' && M === 'POST') {
      const b = await json(req); const o = friendOf(b.to);
      const t = { id: crypto.randomUUID(), kind: 'trade', from: me.username, to: o.username, give: cleanGive(b.give), want: String(b.want?.note ?? '').slice(0, 140), state: 'offered', at: now() };
      box(o.username).push(t); store.save('inbox'); notify(o.username, { what: 'trade', from: me.username });
      return send(res, 200, { ok: true, id: t.id });
    }
    if (p === '/api/trades/respond' && M === 'POST') {
      const b = await json(req); const t = box(me.username).find((x) => x.id === b.id && x.kind === 'trade' && x.state === 'offered');
      if (!t) throw fail(404, 'That offer is gone.');
      if (!b.accept) { t.state = 'declined'; t.claimed = now(); box(t.from).push({ id: crypto.randomUUID(), kind: 'gift', from: t.to, to: t.from, ...t.give, note: 'Your trade offer came back.', at: now() }); }
      else { t.state = 'accepted'; t.back = cleanGive(b.give); box(t.from).push({ id: crypto.randomUUID(), kind: 'gift', from: me.username, to: t.from, ...t.back, note: 'Your trade went through!', at: now() }); }
      store.save('inbox'); notify(t.from, { what: 'trade', from: me.username, state: t.state });
      return send(res, 200, { trade: t });
    }
    if (p === '/api/trades/claim' && M === 'POST') {
      const b = await json(req); const t = box(me.username).find((x) => x.id === b.id && x.kind === 'trade' && x.state === 'accepted' && !x.claimed);
      if (!t) throw fail(404, 'Nothing to collect.');
      t.claimed = now(); store.save('inbox');
      return send(res, 200, { trade: t });
    }

    // yards: your latest snapshot, for friends to visit through their Link gate
    if (p === '/api/ranch' && M === 'PUT') {
      const b = await json(req);
      if (b?.kind !== 'capsule-link-ranch' || !Array.isArray(b.creatures) || b.creatures.length > 30) throw fail(400, 'That isn’t a yard snapshot.');
      ranches[me.username] = { ...b, at: now() }; store.save('ranches');
      return send(res, 200, { ok: true });
    }
    if (p.startsWith('/api/ranch/') && M === 'GET') { const o = friendOf(decodeURIComponent(p.slice(11))); const r = ranches[o.username]; if (!r) throw fail(404, 'They haven’t shared a yard yet.'); return send(res, 200, r); }

    // creature data and sprites: whoever has them shares; others fetch only what they're missing
    if (p === '/api/species/missing' && M === 'POST') { const b = await json(req); const ids = (b.ids ?? []).slice(0, 2000).map(String); return send(res, 200, { available: ids.filter((id) => species[id]) }); }
    if (p.startsWith('/api/species/')) {
      const id = decodeURIComponent(p.slice(13));
      if (!/^[\w.:-]{1,64}$/.test(id)) throw fail(400, 'Bad id');
      if (M === 'GET') { const s = species[id]; if (!s) throw fail(404, 'Nobody has shared that one yet.'); return send(res, 200, s); }
      if (M === 'PUT') {
        const b = await json(req);
        if (!b.record || typeof b.record !== 'object' || b.record.id !== id) throw fail(400, 'Bad record');
        const sprites = Object.fromEntries(Object.entries(b.sprites ?? {}).filter(([k, h]) => /^[a-z]{2,10}$/.test(k) && /^[a-f0-9]{64}$/.test(h)));
        species[id] = { record: b.record, sprites, by: me.username, at: now() }; store.save('species');
        return send(res, 200, { ok: true, need: Object.values(sprites).filter((h) => !store.hasBlob(h)) });
      }
    }
    if (p.startsWith('/api/blob/')) {
      const hash = p.slice(10);
      if (!/^[a-f0-9]{64}$/.test(hash)) throw fail(400, 'Bad hash');
      if (M === 'GET') { const buf = store.getBlob(hash); if (!buf) throw fail(404, 'Not here'); return send(res, 200, buf, 'image/png'); }
      if (M === 'PUT') {
        const buf = await readBody(req, 4 * 1024 * 1024);
        if (sha(buf) !== hash) throw fail(400, 'That file doesn’t match its hash.');
        if (buf.slice(1, 4).toString() !== 'PNG') throw fail(400, 'Only PNG images.');
        store.putBlob(hash, buf);
        return send(res, 200, { ok: true });
      }
    }
    throw fail(404, 'Not found');
  }

  const server = createWsServer({
    port,
    onConnection: (conn) => {
      const path = new URL(conn.req.url ?? '/', 'http://x').pathname;
      if (path === '/relay' || path === '/') { hub.attach(conn); return; }
      // /live: notifications for a signed-in trainer
      let me = null;
      conn.on('message', (msg) => {
        if (msg?.type !== 'auth') return;
        const s = sessions[sha(String(msg.token ?? ''))];
        if (!s) { conn.send({ type: 'error', error: 'Sign in again.' }); return; }
        me = s.username;
        if (!live.has(me)) live.set(me, new Set());
        live.get(me).add(conn);
        conn.send({ type: 'ready', username: me });
      });
      conn.on('close', () => { if (me) live.get(me)?.delete(conn); });
    },
    onHttp: (req, res) => {
      route(req, res).catch((e) => send(res, e.code && e.code >= 400 && e.code < 600 ? e.code : 500, { error: e.code ? e.message : 'Something went wrong.' }));
    },
  });
  return { server, store, close: async () => { store.flushAll(); await server.close(); } };
}

// run directly: node server/home-server.mjs
if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(arg('port', 47830));
  const s = makeServer({ port, dataDir: arg('data', './server-data'), name: arg('name', 'Capsule Link home server'), log: (...a) => console.log(new Date().toISOString(), ...a) });
  await s.server.ready;
  console.log(`Capsule Link home server on port ${port} (data in ${s.store.dir})`);
  console.log('Friends connect to http://<this computer>:' + port + '   battles: ws://<this computer>:' + port + '/relay');
  const stop = async () => { await s.close(); process.exit(0); };
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
}
