#!/usr/bin/env node
// Start the Capsule Link home server from a terminal (the PC app can also host it for you:
// Settings → Debug → Host a server from this PC). See server/core.mjs for what it does.
//   node server/home-server.mjs --port 47830 --data ./server-data
import { makeServer } from './core.mjs';

const arg = (name, def) => { const i = process.argv.indexOf(`--${name}`); return i > 0 ? process.argv[i + 1] : process.env[`CL_${name.toUpperCase()}`] ?? def; };
const port = Number(arg('port', 47830));
const s = makeServer({ port, dataDir: arg('data', './server-data'), name: arg('name', 'Capsule Link home server'), log: (...a) => console.log(new Date().toISOString(), ...a) });
await s.server.ready;
console.log(`Capsule Link home server on port ${port} (data in ${s.store.dir})`);
console.log('Friends connect to http://<this computer>:' + port + '   battles: ws://<this computer>:' + port + '/relay');
const stop = async () => { await s.close(); process.exit(0); };
process.on('SIGINT', stop); process.on('SIGTERM', stop);
