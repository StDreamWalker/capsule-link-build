// A tiny file-backed store for the home server: one JSON file per collection, written atomically
// (write a temp file, then rename), plus a folder of shared sprite files. Fine for a household or a
// group of friends on an old computer; swap it for a real database if it ever grows past that.
import fs from 'node:fs';
import path from 'node:path';

export class Store {
  constructor(dir) {
    this.dir = path.resolve(dir);
    fs.mkdirSync(path.join(this.dir, 'blobs'), { recursive: true });
    this.cols = new Map();
    this.timers = new Map();
  }
  /** A collection: a plain object you change, then call save(name). */
  col(name) {
    if (!this.cols.has(name)) {
      const file = path.join(this.dir, `${name}.json`);
      let data = {};
      try { data = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { /* new */ }
      this.cols.set(name, data);
    }
    return this.cols.get(name);
  }
  /** Save a collection soon (changes close together are written once). */
  save(name) {
    if (this.timers.has(name)) return;
    this.timers.set(name, setTimeout(() => this.flush(name), 150));
  }
  flush(name) {
    clearTimeout(this.timers.get(name));
    this.timers.delete(name);
    const file = path.join(this.dir, `${name}.json`);
    const tmp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.cols.get(name) ?? {}));
    fs.renameSync(tmp, file);
  }
  flushAll() { for (const name of [...this.timers.keys()]) this.flush(name); }
  // shared files (sprites), by content hash
  blobPath(hash) { if (!/^[a-f0-9]{16,64}$/.test(hash)) throw new Error('bad hash'); return path.join(this.dir, 'blobs', hash); }
  hasBlob(hash) { try { return fs.existsSync(this.blobPath(hash)); } catch { return false; } }
  putBlob(hash, buf) { const p = this.blobPath(hash); if (!fs.existsSync(p)) fs.writeFileSync(p, buf); }
  getBlob(hash) { try { return fs.readFileSync(this.blobPath(hash)); } catch { return null; } }
}
