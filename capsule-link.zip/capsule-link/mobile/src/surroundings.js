// Where you are walking: the phone's location, read now and then while the app is open, turned into
// what is nearby (OpenStreetMap features within a few hundred metres, through the public Overpass API)
// and the weather (Open-Meteo). Only the summary is kept: kinds of places, the weather, the temperature,
// how far the town centre is. The position itself is rounded and stays on this phone.
const OVERPASS = 'https://overpass-api.de/api/interpreter';
const METEO = 'https://api.open-meteo.com/v1/forecast';

// OpenStreetMap tags → our place kinds (PLACES in the engine's walkLife.js)
const RULES = [
  ['natural', /^(beach|sand)$/, 'beach'], ['natural', /^coastline$/, 'beach'],
  ['waterway', /^(river|stream|canal)$/, 'river'], ['natural', /^water$/, 'lake'],
  ['leisure', /^marina$/, 'harbour'], ['landuse', /^harbour$/, 'harbour'], ['natural', /^wetland$/, 'wetland'],
  ['leisure', /^park$/, 'park'], ['leisure', /^garden$/, 'garden'], ['leisure', /^playground$/, 'playground'],
  ['landuse', /^forest$/, 'forest'], ['natural', /^wood$/, 'forest'],
  ['landuse', /^(farmland|meadow|orchard|vineyard|farmyard)$/, 'farm'],
  ['landuse', /^cemetery$/, 'cemetery'], ['amenity', /^grave_yard$/, 'cemetery'],
  ['amenity', /^place_of_worship$/, 'temple'], ['amenity', /^(hospital|clinic)$/, 'hospital'],
  ['leisure', /^(stadium|sports_centre|pitch|fitness_centre|track)$/, 'sports'],
  ['landuse', /^industrial$/, 'industrial'], ['power', /^(plant|substation|generator)$/, 'power'],
  ['railway', /^(station|halt)$/, 'station'], ['amenity', /^parking$/, 'parking'], ['landuse', /^quarry$/, 'quarry'],
  ['historic', /^(castle|monument|memorial|ruins|fort)$/, 'landmark'], ['tourism', /^attraction$/, 'landmark'],
  ['leisure', /^golf_course$/, 'golf'], ['landuse', /^residential$/, 'residential'], ['landuse', /^(retail|commercial)$/, 'shops'],
  ['natural', /^(bare_rock|cliff|scree|rock)$/, 'rocky'], ['natural', /^(peak|volcano)$/, 'peak'], ['natural', /^hot_spring$/, 'hot-spring'],
  ['natural', /^cave_entrance$/, 'cave'], ['aeroway', /^aerodrome$/, 'airport'], ['amenity', /^cinema$/, 'cinema'],
  ['amenity', /^fire_station$/, 'fire-station'], ['shop', /^bakery$/, 'bakery'],
];
// how close a kind of place has to be to count (metres; big areas are measured to their middle)
const NEAR = { lake: 500, forest: 500, farm: 500, residential: 250, shops: 250, industrial: 450, airport: 1500, peak: 800, golf: 500, park: 400, beach: 600 };

function query(lat, lon, r = 600) {
  const a = `(around:${r},${lat},${lon})`;
  return `[out:json][timeout:20];(
nwr${a}[natural~"^(beach|sand|coastline|water|wetland|wood|bare_rock|cliff|scree|rock|peak|volcano|hot_spring|cave_entrance)$"];
nwr${a}[waterway~"^(river|stream|canal)$"];
nwr${a}[landuse~"^(harbour|forest|farmland|meadow|orchard|vineyard|farmyard|cemetery|industrial|quarry|residential|retail|commercial)$"];
nwr${a}[leisure~"^(marina|park|garden|playground|stadium|sports_centre|pitch|fitness_centre|track|golf_course)$"];
nwr${a}[amenity~"^(grave_yard|place_of_worship|hospital|clinic|parking|cinema|fire_station)$"];
nwr${a}[power~"^(plant|substation|generator)$"];
nwr${a}[railway~"^(station|halt)$"];
nwr${a}[historic~"^(castle|monument|memorial|ruins|fort)$"];
nwr${a}[tourism=attraction];nwr${a}[shop=bakery];nwr(around:1500,${lat},${lon})[aeroway=aerodrome];
node(around:25000,${lat},${lon})[place~"^(city|town)$"];
);out tags center qt 400;`;
}

const R = 6371000;
export function distance(a, b) {
  const toR = (d) => (d * Math.PI) / 180;
  const dLat = toR(b.lat - a.lat), dLon = toR(b.lon - a.lon);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toR(a.lat)) * Math.cos(toR(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export { weatherWord } from '../../shared/engine/sky.js';
import { weatherWord, meteoUrl } from '../../shared/engine/sky.js';

// How built-up it is right around you: buildings and streets within 200 m.
function densityQuery(lat, lon) {
  return `[out:json][timeout:15];way(around:200,${lat},${lon})[building];out count;way(around:200,${lat},${lon})[highway~"^(primary|secondary|tertiary|residential|living_street|pedestrian|service|unclassified|trunk)$"];out count;`;
}

function position(opts) {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) { reject(new Error('This phone can’t share its location with the app.')); return; }
    navigator.geolocation.getCurrentPosition(resolve, (e) => reject(new Error(e.code === 1 ? 'Location is turned off for Capsule Link. Allow it in Android settings → Apps → Capsule Link → Permissions.' : 'Couldn’t get a location fix. Try again outdoors.')), opts);
  });
}

async function fetchJson(url, init, ms = 20000) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), ms);
  try {
    const r = await fetch(url, { ...init, signal: ctl.signal });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  } finally { clearTimeout(timer); }
}

/**
 * Look around: { at, lat, lon (rounded), places: [kinds, nearest first], near: { kind: metres }, cityKm, town,
 *   weather, temp, humidity, isDay, wind, speedKmh, vehicle, accuracy }.
 * prev: the last result (for speed between fixes).
 */
export async function sense(prev = null) {
  const pos = await position({ enableHighAccuracy: true, timeout: 20000, maximumAge: 60000 });
  const here = { lat: pos.coords.latitude, lon: pos.coords.longitude };
  const out = { at: Date.now(), lat: Math.round(here.lat * 1000) / 1000, lon: Math.round(here.lon * 1000) / 1000, accuracy: Math.round(pos.coords.accuracy ?? 0), places: [], near: {} };
  // speed: from the fix, or between this fix and the last one
  let speed = Number.isFinite(pos.coords.speed) && pos.coords.speed != null ? pos.coords.speed * 3.6 : null;
  if (speed == null && prev?.exact && out.at - prev.at < 10 * 60000) speed = (distance(prev.exact, here) / ((out.at - prev.at) / 1000)) * 3.6;
  out.speedKmh = speed != null ? Math.round(speed) : null;
  out.vehicle = speed != null && speed > 25;
  out.exact = here; // kept in memory only (never saved)
  const [weather, dens, osm] = await Promise.allSettled([
    fetchJson(meteoUrl(here.lat, here.lon)),
    fetchJson(OVERPASS, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: `data=${encodeURIComponent(densityQuery(here.lat.toFixed(5), here.lon.toFixed(5)))}` }, 20000),
    fetchJson(OVERPASS, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: `data=${encodeURIComponent(query(here.lat.toFixed(5), here.lon.toFixed(5)))}` }, 30000),
  ]);
  if (weather.status === 'fulfilled') {
    const cur = weather.value.current ?? {};
    out.temp = Math.round(cur.temperature_2m ?? NaN);
    out.humidity = cur.relative_humidity_2m;
    out.wind = cur.wind_speed_10m;
    out.isDay = cur.is_day === 1;
    out.visibility = Number.isFinite(cur.visibility) ? cur.visibility : null;
    out.weather = weatherWord(cur.weather_code ?? 0, cur.wind_speed_10m ?? 0, out.visibility);
    const daily = weather.value.daily ?? {};
    if (daily.sunrise?.[0]) out.sunrise = daily.sunrise[0] * 1000;
    if (daily.sunset?.[0]) out.sunset = daily.sunset[0] * 1000;
    // a cloudless sky after dark is a clear night, not sunshine
    if (!out.isDay && out.weather === 'sun') out.weather = 'clear';
  } else out.weatherError = String(weather.reason?.message ?? weather.reason);
  if (osm.status === 'fulfilled') {
    let town = null;
    for (const el of osm.value.elements ?? []) {
      const tags = el.tags ?? {};
      const at = el.center ? { lat: el.center.lat, lon: el.center.lon } : el.lat != null ? { lat: el.lat, lon: el.lon } : null;
      if (!at) continue;
      const d = distance(here, at);
      if (/^(city|town)$/.test(tags.place ?? '')) { if (!town || d < town.d) town = { d, name: tags.name ?? '' }; continue; }
      for (const [k, re, kind] of RULES) {
        if (!re.test(tags[k] ?? '')) continue;
        // areas count when you're inside or beside them: measure to their middle, generously
        const dd = el.type === 'node' ? d : Math.max(0, d - 150);
        if (dd <= (NEAR[kind] ?? 300) && (out.near[kind] == null || dd < out.near[kind])) out.near[kind] = Math.round(dd);
      }
    }
    if (town) {
      out.cityKm = Math.round(town.d / 100) / 10;
      out.town = town.name;
      if (town.d < 1500) out.near['city-centre'] = Math.round(town.d);
    } else out.cityKm = null;
    // how built-up: lots of buildings and streets close by means the city, whatever the land-use maps say
    if (dens.status === 'fulfilled') {
      const counts = (dens.value.elements ?? []).map((e) => +(e.tags?.total ?? e.tags?.ways ?? 0));
      out.buildings = counts[0] ?? 0;
      out.streets = counts[1] ?? 0;
    }
    const dense = (out.buildings ?? 0) >= 60 || ((out.buildings ?? 0) >= 25 && (out.streets ?? 0) >= 8);
    const built = dense || (out.buildings ?? 0) >= 12 || (out.cityKm != null && out.cityKm < 4);
    out.urban = dense ? 2 : built ? 1 : 0;
    if (dense && out.near['city-centre'] == null) out.near['city-centre'] = out.cityKm != null && out.cityKm < 3 ? 1 : 60;
    else if (built && out.near.residential == null && out.near.shops == null) out.near.residential = 40;
    // fields and parks only lead when they really are what's around you
    if (built) for (const k of ['farm', 'countryside', 'golf']) if (out.near[k] != null) out.near[k] += 300;
    if (!built && !out.near['city-centre'] && (out.cityKm == null || out.cityKm > 8) && !out.near.residential && !out.near.shops) out.near.countryside = 0;
    out.places = Object.entries(out.near).sort((a, b) => a[1] - b[1]).map(([k]) => k).slice(0, 6);
  } else out.placesError = String(osm.reason?.message ?? osm.reason);
  return out;
}

/** What gets saved and sent with walks (no position). */
export function summary(s) {
  if (!s) return null;
  const { at, places, weather, temp, humidity, isDay, sunrise, sunset, cityKm, town, vehicle, speedKmh, near, urban, home, visibility, lat, lon } = s;
  return { at, places, weather, temp, humidity, isDay, sunrise, sunset, cityKm, town, vehicle, speedKmh, near, urban, home, visibility, lat, lon };
}
