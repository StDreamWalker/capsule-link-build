// Texting your buddy, right on the monitor: type what you're up to; what you said floats up and fades,
// and they answer the only way they can — a picture in a speech bubble over their head (happy, sad,
// a music note, the berry they want…), a cry (or a word they've learned, said their own way), and a
// line underneath ("Lileep is ready to go!") that fades away. What you typed isn't shown (it would
// cover them), and they never "say" words in text: their words are sounds, cut from their own cry.
import { h, mount, toast } from '../../shared/ui/dom.js';
import { bubblePic, reactLine } from '../../shared/ui/talkOverlay.js';
import { warmLlm } from '../../shared/ui/localLlm.js';
import { creatureCry, sfx } from '../../shared/ui/audio.js';
import { displayName, speciesOf, makeEvent, itemInfo, wordLabel } from '../../shared/engine/index.js';

const MOOD_ICON = { happy: '😊', meh: '😕', sleepy: '💤', worried: '🥺', curious: '❔', content: '🙂' };

/** The talk layer over the monitor and the box to type in. Returns { layer, bar }. */
export function talkParts(app) {
  const layer = h('div', { class: 'talk-layer', 'aria-live': 'polite' });
  const input = h('input', { type: 'text', class: 'talk-input', maxLength: 200, enterkeyhint: 'send', placeholder: 'Tell them what you’re up to…' });
  const bar = h('form', { class: 'talk-bar', onsubmit: (e) => { e.preventDefault(); send(input.value); input.value = ''; } },
    input, h('button', { class: 'btn primary', type: 'submit', 'aria-label': 'Say it' }, 'Say'));
  const fade = (node, ms) => { layer.append(node); setTimeout(() => node.classList.add('out'), ms); setTimeout(() => node.remove(), ms + 900); };
  function send(text) {
    text = String(text || '').trim();
    const b = app.buddy();
    if (!text || !b) return;
    input.placeholder = `Tell ${displayName(app.idx, b)} what you’re up to…`;
    // what you said floats up and fades
    layer.querySelectorAll('.talk-bubble, .talk-line').forEach((n) => n.remove());
    sfx('blip');
    const out = app.record(makeEvent('chat', { uid: b.uid, text }))?.outcome;
    if (!out) return;
    warmLlm();
    const line = reactLine(app, b.uid, text, out); // (in the on-device model's words, once it's ready)
    setTimeout(async () => {
      const note = (await line) ?? out.note;
      const c = app.save.creatures[b.uid];
      if (!c) return;
      // their answer: a picture over their head, a word if they have one, and a line that fades
      const pic = out.bubble?.kind === 'item' || out.bubble?.kind === 'creature' ? bubblePic(app, out) : h('span', { class: 'talk-emoji' }, out.bubble?.e ?? MOOD_ICON[out.mood] ?? '❔');
      if (pic.tagName === 'CANVAS') { pic.style.width = '44px'; pic.style.height = '44px'; pic.style.imageRendering = 'pixelated'; }
      fade(h('div', { class: `talk-bubble mood-${out.mood ?? 'content'}` }, pic), 4200);
      if (note) fade(h('div', { class: 'talk-line' }, out.learned ? `${displayName(app.idx, c)} seems to know what “${wordLabel(app.idx, out.learned)}” means now.` : note), 4200);
      try { creatureCry(speciesOf(app.idx, c), c, out.pieces ? { chop: out.pieces } : { talk: true, mood: out.mood === 'happy' ? 'happy' : out.mood === 'sleepy' ? 'sleepy' : undefined }); } catch { /* no sound */ }
      app.platform.vibrate?.([12]);
      if (out.learned) { sfx('level'); toast(`${displayName(app.idx, c)} learned a word: “${wordLabel(app.idx, out.learned)}” — listen for their own sound for it.`, 'ok'); }
    }, 550);
  }
  void mount;
  return { layer, bar, focus: () => input.focus() };
}
