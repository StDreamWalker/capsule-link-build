// The phone's Settings, in tabs like the PC's: General (this phone, look, sound and battle music), Data and art
// (Get everything with a preset, one thing at a time, the Creature System Reset), Updates and backups, and Debug
// (Full PC mode, adding creatures, test tools and the ball hardware).
import { h, mount, toast, confirmDialog } from '../../shared/ui/dom.js';
import { qualitySlider } from '../../shared/ui/quality.js';
import { musicPicker } from '../../shared/ui/musicStore.js';
import { createDefaultDataset, normalizeDataset } from '../../shared/engine/index.js';
import { settingsPanel, backupPanel, aboutPanel } from './views.js';
import { debugView } from './debug.js';
import { pcFacade, linkedNote } from './pcviews.js';
import { presetTool, oneThingTool } from '../../desktop/src/renderer/presets.js';
import { kvSet } from './kv.js';

const TABS = [['general', 'General'], ['data', 'Data and art'], ['backup', 'Backups'], ['debug', 'Debug']];

export function settingsView(app) {
  const tabsEl = h('div', { class: 'seg m-set-tabs', role: 'tablist' });
  const body = h('div', { class: 'm-set-body col' });
  const el = h('div', { class: 'm-settings' }, tabsEl, body);
  let tab = settingsView.tab ?? 'general';
  let dbg = null;
  const tools = {};

  function render() {
    mount(tabsEl, TABS.map(([k, l]) => h('button', { role: 'tab', 'aria-pressed': String(tab === k), 'aria-selected': String(tab === k), class: tab === k ? 'on' : '', onclick: () => { if (tab === k) return; tab = settingsView.tab = k; if (k !== 'debug') { dbg?.dispose?.(); dbg = null; } render(); } }, l)));
    if (tab === 'general') general();
    else if (tab === 'data') data();
    else if (tab === 'backup') mount(body, aboutPanel(app), backupPanel(app));
    else debug();
  }

  function general() {
    const s = app.settings;
    mount(body,
      h('section', { class: 'panel col' }, h('h2', null, 'Graphics'),
        qualitySlider(h, { onChange: () => render() }),
        h('p', { class: 'micro dim' }, 'Used everywhere on this phone: battles, activities, quality time and walks. Lower it if things feel slow or the phone gets warm.'),
        h('label', { class: 'col' }, h('span', { class: 'dim' }, 'Sizes in battles'),
          h('select', { onchange: (e) => app.local((st) => { st.settings.battleSizes = e.target.value; }) },
            [['default', 'Default (everyone easy to see)'], ['full', 'Fully scaled (true to real heights)'], ['partial', 'Partly scaled (like the R.A.N.C.H.)']].map(([v, l]) => h('option', { value: v, selected: v === (s.battleSizes ?? 'default') }, l)))),
        h('p', { class: 'micro dim' }, 'Fully scaled: giants like Wailord tower over the rest, moves and camera to match.')),
      settingsPanel(app, s, render),
      h('section', { class: 'panel col' }, h('h2', null, 'Battle music'),
        musicPicker(h, { get: () => app.settings.battleMusic, set: (v) => app.local((st) => { st.settings.battleMusic = v; }), toast }),
        h('p', { class: 'micro dim' }, 'Wild battles, Battle Link and the PC apps all use it.')));
  }

  function data() {
    const fa = pcFacade(app);
    tools.all = tools.all ?? presetTool(fa, { onDone: () => app.refresh() });
    tools.one = tools.one ?? oneThingTool(fa);
    mount(body,
      linkedNote(app, 'data set and pictures'),
      h('div', { class: 'm-data-tools col' }, tools.all),
      h('h2', { class: 'section-title' }, 'One thing at a time'),
      h('div', { class: 'm-data-tools col' }, tools.one),
      h('section', { class: 'panel col danger-zone' },
        h('h2', null, 'Start over'),
        h('p', { class: 'dim' }, 'Wipe this phone’s creature system (every species, move, learnset, nature, item, name, picture and cry it keeps) and set it all up again from nothing.'),
        h('button', { class: 'btn danger-solid wide', onclick: systemReset }, 'Creature System Reset')));
  }

  async function systemReset() {
    const ok = await confirmDialog('Creature System Reset',
      'This wipes this phone’s whole creature system: every species, move, learnset, nature, item, rule and name goes back to the few placeholder creatures, and its pictures and cries are deleted. You’ll have to bring everything in again and redo the setup. This can’t be undone. (Your creatures aren’t deleted; make a backup first if you might want this system back.)',
      { ok: 'Reset everything', danger: true });
    if (!ok || !(await confirmDialog('Are you sure?', 'Last chance: the creature system is wiped as soon as you press Reset. It can’t be undone.', { ok: 'Reset', danger: true }))) return;
    const fa = pcFacade(app);
    await fa.saveDataset(normalizeDataset(createDefaultDataset()));
    app.textures = { hash: '', files: {} }; app.cries = { hash: '', files: {} };
    fa.applyTextures();
    await kvSet('textures', app.textures).catch(() => {});
    await kvSet('cries', app.cries).catch(() => {});
    tools.all = null; tools.one = null;
    app.local((st) => { st.settings.introSeen = false; });
    toast('The creature system was reset. Starting over…', 'ok');
    setTimeout(() => location.reload(), 900);
  }

  function debug() {
    dbg = dbg ?? debugView(app);
    const on = app.fullPc;
    mount(body,
      h('section', { class: `panel col full-pc ${on ? 'on' : ''}` },
        h('h2', null, 'Full PC mode'),
        h('p', { class: 'dim' }, 'Everything the PC app can do, on this phone: the R.A.N.C.H., the Market, the storage system and every other PC app. The phone becomes its own PC and links to it by itself.'),
        h('label', { class: 'switch-row' },
          h('span', { class: 'grow' }, on ? 'On: this phone is its own PC' : 'Off'),
          h('input', { type: 'checkbox', class: 'switch', checked: on, onchange: async (e) => {
            const want = e.target.checked;
            e.target.checked = on;
            if (want) {
              const yes = await confirmDialog('Make this phone its own PC?',
                `Your account on this phone becomes a PC account: its creatures, items and data move into this phone’s own PC, and the phone links to it.${app.settings.hubUrl ? ' It unlinks from your PC now.' : ''}\n\nThis account won’t be able to reconnect to a PC. The next time you link to one, you’ll have to choose to overwrite this phone’s account with the PC’s main account to sync with it.`,
                { ok: 'Turn on Full PC mode', danger: true });
              if (!yes) return;
              try { await app.enableFullPc(); toast('Full PC mode is on. Open the PC apps from Home.', 'ok'); } catch (err) { toast(`Couldn’t turn it on: ${err.message}`, 'err'); }
            } else {
              const yes = await confirmDialog('Turn off Full PC mode?', 'The PC apps go away (what’s in them stays on this phone, for if you turn it back on). This account still can’t join another PC without being overwritten.', { ok: 'Turn off' });
              if (!yes) return;
              await app.disableFullPc();
            }
            render();
          } })),
        on ? h('button', { class: 'btn primary wide', onclick: () => app.openPcApps() }, 'Open the PC apps') : null,
        app.settings.ownPc && !on ? h('p', { class: 'micro m-note' }, 'This phone has been its own PC: linking to a PC will ask to overwrite its account.') : null),
      dbg.el);
  }

  render();
  return { el, update: () => { if (tab === 'debug') dbg?.update?.(); }, dispose: () => dbg?.dispose?.() };
}
