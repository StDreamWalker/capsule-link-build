import { brandText } from '../../shared/ui/dom.js';
// Phone capabilities. On Android the native CapsuleLink plugin (mobile/native) provides NFC,
// the step counter service, capsule Bluetooth beacons, notifications and PC discovery.
// In a desktop browser everything is simulated so the app can be tried without a phone.
import { makeVirtualTag, fromBase64, toBase64, toHex, fromHex } from '../../shared/engine/index.js';

const cap = typeof window !== 'undefined' ? window.Capacitor : null;
export const isNative = !!cap?.isNativePlatform?.();

function nativePlatform() {
  const P = cap.registerPlugin('CapsuleLink');
  const listeners = {};
  const on = (ev, fn) => {
    const handle = P.addListener(ev, fn);
    return () => Promise.resolve(handle).then((h) => h.remove());
  };
  return {
    native: true,
    async permissions(opts) { try { return await P.ensurePermissions(opts); } catch (e) { return { error: e.message }; } },
    // ---- NFC ----
    async startNfc() { return P.startNfc(); },
    async stopNfc() { return P.stopNfc().catch(() => {}); },
    onTag(fn) {
      return on('nfcTag', (t) => {
        if (t.error) { fn(null, t.error); return; }
        const mem = fromBase64(t.data);
        fn({
          uid: String(t.uid).toUpperCase(),
          size: t.size,
          readUser: async () => mem,
          writePages: async (page, bytes) => {
            await P.writeTag({ uid: t.uid, page, data: toBase64(bytes) });
            mem.set(bytes, (page - 4) * 4);
          },
        });
      });
    },
    // ---- walking ----
    async startWalk(title, text) { return P.startWalk({ title, text }); },
    async stopWalk() { return P.stopWalk(); },
    async walkStatus() { return P.getWalk(); },
    async ackSteps(count) { return P.ackSteps({ count }); },
    onSteps(fn) { return on('steps', fn); },
    // ---- capsule beacons (bumps) ----
    async startBeacons() { return P.startBleScan(); },
    async stopBeacons() { return P.stopBleScan().catch(() => {}); },
    onBeacon(fn) { return on('capsuleBeacon', fn); },
    // ---- misc ----
    // ---- Showdown ----
    canEmbedShowdown: true,
    openShowdown(url, script) { return P.openShowdown({ url, script }); },
    onShowdown(fn) { return on('showdown', fn); },
    async takeShowdownEvents() {
      const r = await P.takeShowdownEvents();
      return (r.events ?? []).map((j) => { try { return JSON.parse(j); } catch { return null; } }).filter(Boolean);
    },
    setCapsuleWatch(mine) { return P.setCapsuleWatch({ mine }).catch(() => {}); },
    // CapacitorHttp makes fetch native, so replay sites need no CORS headers
    async fetchText(url) { const r = await fetch(url); if (!r.ok) throw new Error(`The server answered ${r.status}.`); return r.text(); },
    notify(title, body) { return P.showNotification({ title: brandText(title), body: brandText(body) }).catch(() => {}); },
    vibrate(pattern = [40]) { return P.vibrate({ pattern }).catch(() => {}); },
    async discover(ms = 3500) { try { return (await P.discoverPc({ timeout: ms })).found ?? []; } catch { return []; } },
    canPinShortcut: true,
    canUpdate: true,
    async appInfo() { try { return await P.appInfo(); } catch { return {}; } },
    installWebBundle(version, files) { return P.installWebBundle({ version, files }); },
    useBuiltIn() { return P.useBuiltIn(); },
    async pinShortcut(label, iconBase64) { return P.pinShortcut({ label, icon: iconBase64 }); },
    listeners,
  };
}

/** Browser stand-in: virtual capsules you "tap" from the Capsule screen, steps from motion or buttons. */
const PENDING = 'capsule-link-mobile:pending';
const getPending = () => { try { return Number(localStorage.getItem(PENDING) || 0); } catch { return 0; } };
const setPending = (n) => { try { localStorage.setItem(PENDING, String(n)); } catch { /* storage blocked */ } };

function webPlatform() {
  const KEY = 'capsule-link-mobile:vtags';
  const tags = new Map();
  try { for (const [uid, hex] of Object.entries(JSON.parse(localStorage.getItem(KEY) || '{}'))) tags.set(uid, makeVirtualTag(uid, fromHex(hex))); } catch { /* fresh */ }
  const store = () => { const o = {}; for (const [uid, t] of tags) o[uid] = toHex(t.mem); try { localStorage.setItem(KEY, JSON.stringify(o)); } catch { /* full */ } };
  const tagSubs = new Set(), stepSubs = new Set();
  let walking = null;
  let motion = null;
  return {
    native: false,
    async permissions() { return { activity: 'granted', notifications: 'granted' }; },
    async startNfc() {}, async stopNfc() {},
    onTag(fn) { tagSubs.add(fn); return () => tagSubs.delete(fn); },
    // simulation helpers used by the dev panel
    virtualTags: () => [...tags.values()],
    newVirtualTag() {
      const uid = '04' + Array.from({ length: 6 }, () => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join('').toUpperCase();
      const t = makeVirtualTag(uid); t.mem.set([0x03, 0x00, 0xfe], 0); tags.set(uid, t); store(); return uid;
    },
    walkVirtual(uid, n, opts) { tags.get(uid)?.addSteps(n, opts); store(); },
    tapVirtual(uid) {
      const t = tags.get(uid);
      if (!t) return;
      const wrapped = { uid, readUser: () => t.readUser(), writePages: async (p, b) => { await t.writePages(p, b); store(); } };
      for (const fn of tagSubs) fn(wrapped);
    },
    async startWalk() {
      walking = { session: 0, pending: getPending() };
      // rough step detection from the accelerometer, when the browser offers it
      let last = 0, armed = true;
      motion = (e) => {
        const a = e.accelerationIncludingGravity;
        if (!a) return;
        const m = Math.hypot(a.x || 0, a.y || 0, a.z || 0);
        const now = performance.now();
        if (armed && m > 12.5 && now - last > 280) { last = now; armed = false; this.addSteps(1); }
        if (m < 10.5) armed = true;
      };
      window.addEventListener('devicemotion', motion);
      return { ok: true };
    },
    async stopWalk() { window.removeEventListener('devicemotion', motion); const s = walking?.session ?? 0; walking = null; return { steps: s }; },
    async walkStatus() { return { walking: !!walking, sessionSteps: walking?.session ?? 0, pending: getPending() }; },
    async ackSteps(n) { setPending(Math.max(0, getPending() - n)); },
    addSteps(n) {
      if (!walking) return;
      walking.session += n;
      const p = getPending() + n;
      setPending(p);
      for (const fn of stepSubs) fn({ sessionSteps: walking.session, pending: p });
    },
    onSteps(fn) { stepSubs.add(fn); return () => stepSubs.delete(fn); },
    async startBeacons() {}, async stopBeacons() {},
    onBeacon() { return () => {}; },
    canEmbedShowdown: false,
    openShowdown: null,
    onShowdown() { return () => {}; },
    async takeShowdownEvents() { return []; },
    setCapsuleWatch() {},
    async fetchText(url) { const r = await fetch(url); if (!r.ok) throw new Error(`The server answered ${r.status}.`); return r.text(); },
    notify(title, body) {
      title = brandText(title); body = brandText(body);
      if ('Notification' in window && Notification.permission === 'granted') new Notification(title, { body });
    },
    vibrate(pattern = [40]) { navigator.vibrate?.(pattern); },
    async discover() { return []; },
    canPinShortcut: false,
    canUpdate: false,
    async installWebBundle() { throw new Error('This copy of the app is running without its Android parts, so it can’t update itself. Install the newest APK (from your GitHub build) instead; it already includes this version.'); },
    useBuiltIn() { return Promise.resolve(); },
    async appInfo() { return {}; },
  };
}

// if the phone's own code can't be reached, run with simulated parts rather than not at all
function pick() {
  if (!isNative) return webPlatform();
  try { return nativePlatform(); } catch (e) { console.error('Native parts unavailable, simulating them', e); return webPlatform(); }
}
export const platform = pick();
