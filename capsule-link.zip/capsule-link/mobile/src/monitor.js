// The phone's main screen: a monitor for the creature riding in your ball. Away from the PC
// nobody leaves their ball, so there is no petting or feeding here — you watch their vitals,
// read what they seem to be thinking, give the ball a gentle tap, and walk.
import { h, mount, toast, hearts, fmtNum, timeAgo, hpBar, bar, typeChip } from '../../shared/ui/dom.js';
import { spriteCanvas } from '../../shared/ui/art.js';
import { capsuleCanvas, drawCapsule } from '../../shared/ui/capsuleArt.js';
import { creatureSummary } from '../../shared/ui/summary.js';
import { sfx, playCry, creatureCry } from '../../shared/ui/audio.js';
import {
  displayName, speciesOf, friendshipTier, mood, makeEvent, cryFor, calcStats, tickNeeds, ENVIRONMENTS, normalizeEnv, timeOfDay, envPhrase, transportOf,
  PLACES, activeIncense, itemInfo, contextEnv,
} from '../../shared/engine/index.js';
import { icon } from './icons.js';

const VITALS = [
  ['energy', 'Energy'],
  ['fullness', 'Fullness'],
  ['joy', 'Happiness'],
  ['hygiene', 'Grooming'],
];
const TOD_LABEL = { dawn: 'Dawn', day: 'Daytime', dusk: 'Dusk', night: 'Night' };

/** Where a creature is, as the trainer would say it. */
export function whereLabel(app, c) {
  if (c.location?.kind === 'capsule') return app.save.capsules[c.location.tag]?.name ?? 'In a capsule';
  if (c.location?.kind === 'phone') return 'Phone link';
  return 'At the PC';
}

export function buddyView(app) {
  const el = h('div', { class: 'm-buddy' });
  let lastTap = 0;
  let pinged = 0;
  const offs = [app.on((w) => {
    if (w === 'steps') renderWalk();
    if (w === 'thought') renderThoughts();
    if (w === 'encounter') renderEncounter();
    if (w === 'surroundings') renderWalk();
  })];
  const walkEl = h('section', { class: 'walk-stats' });
  const thoughtsEl = h('section', { class: 'thoughts' });
  const encEl = h('div', { class: 'enc-slot' });
  let monitorEl = null;

  function monitor(b) {
    const sp = speciesOf(app.idx, b);
    const tint = app.idx.types.get(sp?.types?.[0])?.color ?? '#5b8cff';
    const m = mood(b).id;
    const beat = m === 'sleepy' ? 2.2 : m === 'happy' ? 0.8 : 1.2;
    return h('div', { class: 'ball-monitor', style: { '--tint': tint, '--beat': `${beat}s` } },
      h('div', { class: 'bm-grid' }),
      h('div', { class: 'bm-rings' }, h('i'), h('i'), h('i')),
      h('div', { class: 'bm-sprite' }, spriteCanvas(app.bank, b, { scale: 3, animate: true, anim: m === 'sleepy' ? 'sleep' : 'idle' })),
      h('div', { class: 'bm-scan' }),
      h('div', { class: 'bm-ecg', html: '<svg viewBox="0 0 200 30" preserveAspectRatio="none"><path d="M0 15 H60 L68 15 L74 4 L80 26 L86 15 H120 L126 12 L130 15 H200" fill="none" stroke="currentColor" stroke-width="1.6" vector-effect="non-scaling-stroke"/></svg>' }),
      h('div', { class: 'bm-tag' }, h('span', { class: 'dot on' }), `${whereLabel(app, b).toUpperCase()} · LIVE`),
      h('div', { class: 'bm-ball' }, capsuleCanvas({ skin: b.ball, ring: tint, lit: true }, 2)));
  }

  function vitals(b) {
    const st = calcStats(app.idx, b);
    const n = b.needs ?? {};
    return h('section', { class: 'panel vitals' },
      h('div', { class: 'vital-row hp' }, h('span', null, 'HP'), hpBar(b.hp ?? st.hp, st.hp), h('span', { class: 'mono-num' }, `${b.hp ?? st.hp}/${st.hp}`)),
      VITALS.map(([k, label]) => h('div', { class: `vital-row v-${k}` }, h('span', null, label), bar((n[k] ?? 0) / 100, `v-${k}`), h('span', { class: 'mono-num' }, `${Math.round(n[k] ?? 0)}`))),
      h('p', { class: 'micro dim' }, 'Inside the capsule, hunger and grooming hold steady. Meals and brushing happen back at the PC.'));
  }

  function renderThoughts() {
    const b = app.buddy();
    const list = (app.save.thoughts ?? []).filter((x) => !b || x.uid === b.uid).slice(-4).reverse();
    mount(thoughtsEl,
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, 'Thoughts'), h('span', { class: 'micro dim' }, app.walk.walking ? 'every so often while you walk' : '')),
      list.length ? [
        h('p', { class: 'thought-now' }, `“${list[0].text}”`),
        list.slice(1).map((x) => h('p', { class: 'thought-old' }, h('span', null, x.text), h('span', { class: 'micro faint' }, timeAgo(x.at)))),
      ] : h('p', { class: 'dim' }, 'Start a walk and you will hear how they are doing.'));
  }

  function envPicker() {
    const env = normalizeEnv(app.settings.walkEnv);
    return h('div', { class: 'env-pick' },
      h('div', { class: 'row' }, h('span', { class: 'grow' }, 'Where are you walking?'), h('span', { class: 'micro dim' }, `Pick up to two · ${TOD_LABEL[timeOfDay()]}`)),
      h('div', { class: 'env-chips' }, ENVIRONMENTS.map((e) => {
        const on = env.includes(e.id);
        return h('button', {
          class: `env-chip ${on ? 'on' : ''}`, title: e.hint, 'aria-pressed': on ? 'true' : 'false',
          onclick: () => {
            let next = on ? env.filter((x) => x !== e.id) : [...env, e.id];
            if (next.length > 2) next = next.slice(-2);
            app.local((s) => { s.settings.walkEnv = next.length ? next : [e.id]; });
          },
        }, e.label);
      })));
  }

  const RIDE_LABEL = { bike: 'On a bike', skate: 'Rolling along', car: 'In a car', train: 'On a train', plane: 'Flying', boat: 'On a boat' };
  const HOME_LABEL = { home: 'At home', leaving: 'Heading out', far: 'Far from home', returning: 'Heading home' };
  const WEATHER_LABEL = { clear: 'Clear night', sun: 'Sunny', clouds: 'Cloudy', rain: 'Rain', storm: 'Thunderstorm', snow: 'Snow', fog: 'Fog', wind: 'Windy' };
  const WEATHER_ICON = { clear: '☾', sun: '☀', clouds: '☁', rain: '☂', storm: '⚡', snow: '❄', fog: '≋', wind: '≈' };
  /** What's around you (from the location), or the manual picker when location is off. */
  function surroundings() {
    if (!app.settings.useLocation) {
      return [envPicker(), h('button', { class: 'btn small', onclick: async () => {
        app.local((s) => { s.settings.useLocation = true; });
        const r = await app.lookNow();
        if (!r) app.local((s) => { s.settings.useLocation = false; });
      } }, 'Use my location instead'),
      h('p', { class: 'micro dim' }, 'With your location, the app looks up what’s nearby on OpenStreetMap and the weather on Open-Meteo, so wild creatures, thoughts and favourite places follow where you really walk. Your position stays on this phone.')];
    }
    const s = app.settings.surroundings;
    const old = s && Date.now() - s.at > 45 * 60000;
    const env = s ? contextEnv({ ...s, env: [] }) : [];
    return h('div', { class: 'env-pick' },
      h('div', { class: 'row' }, h('span', { class: 'grow' }, 'Around you'), h('span', { class: 'micro dim' }, app.sensing ? 'Looking around…' : s ? `${TOD_LABEL[timeOfDay(Date.now(), s)]} · ${timeAgo(s.at)}${old ? ' (old)' : ''}` : 'Not yet looked')),
      s ? h('div', { class: 'env-chips' },
        s.weather ? h('span', { class: 'env-chip on' }, `${WEATHER_ICON[s.weather] ?? ''} ${WEATHER_LABEL[s.weather] ?? s.weather}${Number.isFinite(s.temp) ? ` · ${s.temp}°C` : ''}`) : null,
        (s.places ?? []).slice(0, 5).map((p) => h('span', { class: 'env-chip' }, (PLACES[p]?.label ?? p).replace(/^the /, ''))),
        !(s.places ?? []).length ? env.map((e) => h('span', { class: 'env-chip' }, ENVIRONMENTS.find((x) => x.id === e)?.label ?? e)) : null,
        transportOf(s) ? h('span', { class: 'env-chip' }, `${RIDE_LABEL[transportOf(s)]} · ${s.speedKmh} km/h`) : null,
        s.home?.state ? h('span', { class: 'env-chip' }, HOME_LABEL[s.home.state]) : null) : null,
      s && s.cityKm != null ? h('p', { class: 'micro dim' }, `${s.cityKm < 1.5 ? 'In the middle of' : `${s.cityKm} km from the middle of`} ${s.town || 'town'}`) : null,
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small', disabled: app.sensing, onclick: () => app.lookNow() }, app.sensing ? 'Looking…' : 'Look around now'),
        h('button', { class: 'btn small ghost', title: 'Your creatures remember home and notice when you leave it or come back', onclick: async () => {
          const r = await app.lookNow({ quiet: true });
          if (!r) return;
          app.local((st) => { st.settings.home = { lat: r.lat, lon: r.lon, at: Date.now() }; if (st.settings.surroundings) st.settings.surroundings.home = { state: 'home', km: 0 }; });
          toast('Home is set to where you are now.', 'ok');
        } }, app.settings.home ? 'Home is here now' : 'This is home'),
        h('button', { class: 'btn small ghost', onclick: () => app.local((st) => { st.settings.useLocation = false; }) }, 'Pick by hand instead')));
  }
  function incense() {
    const lit = activeIncense(app.save);
    const bag = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && itemInfo(app.idx, id)?.kind === 'incense');
    if (!lit && !bag.length) return null;
    return h('div', { class: 'row wrap incense-row' },
      lit ? h('span', { class: 'grow' }, `${lit.name} is lit · ${Math.max(1, Math.round((lit.until - Date.now()) / 60000))} min left`)
        : [h('span', { class: 'grow dim' }, 'Incense'), bag.map(([id, n]) => h('button', { class: 'btn small', onclick: () => app.lightIncense(id) }, `Light ${itemInfo(app.idx, id).name} (${n})`))]);
  }

  function renderWalk() {
    const b = app.buddy();
    if (!b) return;
    const inCapsule = b.location?.kind === 'capsule';
    const empties = app.emptyBalls();
    const mins = app.walkMinutes();
    mount(walkEl,
      h('div', { class: 'big-steps' }, icon('steps', 30), h('span', { class: 'mono-num' }, fmtNum(app.walk.session)), h('span', { class: 'dim' }, app.walk.walking ? `steps · ${mins} min` : 'steps last walk')),
      h('div', { class: 'row wrap dim' },
        h('span', null, `Today ${fmtNum(b.walk?.todaySteps ?? 0)}`), h('span', null, '·'), h('span', null, `Together ${fmtNum(b.walk?.totalSteps ?? 0)}`)),
      surroundings(),
      incense(),
      h('p', { class: 'micro dim' }, empties.length
        ? `${empties.length === 1 ? 'An empty capsule is' : `${empties.length} empty capsules are`} with you, so wild creatures may turn up. Longer walks bring rarer ones.`
        : 'Carry an empty capsule to find wild creatures on your walks.'),
      inCapsule ? h('p', { class: 'note' }, `${displayName(app.idx, b)}’s capsule counts these steps itself. Tap it to the phone after your walk to sync.`) : null,
      h('button', { class: `btn wide ${app.walk.walking ? 'danger' : 'primary'}`, onclick: () => (app.walk.walking ? app.stopWalk() : app.startWalk()) }, app.walk.walking ? 'End walk' : 'Start a walk'),
      !app.native && app.walk.walking ? h('div', { class: 'row wrap' }, h('span', { class: 'dim' }, 'Preview:'),
        h('button', { class: 'btn small', onclick: () => app.platform.addSteps(100) }, '+100 steps'),
        h('button', { class: 'btn small', onclick: () => app.platform.addSteps(1000) }, '+1,000'),
        h('button', { class: 'btn small', onclick: () => app.think(true) }, 'Thought'),
        empties.length ? h('button', { class: 'btn small', onclick: () => app.lookAround(true) }, 'Encounter') : null) : null);
  }

  function renderEncounter() {
    const enc = app.encounter;
    if (!enc) { mount(encEl); return; }
    mount(encEl, catchPanel(app, enc));
  }

  function tap() {
    const b = app.buddy();
    if (!b || Date.now() - lastTap < 2500) return;
    lastTap = Date.now();
    app.record(makeEvent('care', { uid: b.uid, action: 'tap' }));
    creatureCry(speciesOf(app.idx, b), b);
    app.platform.vibrate([18, 40, 18]);
    pinged = Date.now();
    monitorEl?.classList.remove('ping');
    void monitorEl?.offsetWidth;
    monitorEl?.classList.add('ping');
    const replies = ['wiggled in response.', 'tapped back from inside.', 'made a happy sound.', 'pressed up against the glass.', 'gave a little hop.'];
    app.addThought(b, `${displayName(app.idx, b)} ${replies[Math.floor(Math.random() * replies.length)]}`);
  }

  function render() {
    const b = app.buddy();
    if (!b) {
      mount(el, h('div', { class: 'empty-state' }, h('h1', null, 'No one in your capsules yet'),
        h('p', { class: 'dim' }, 'Bring creatures from your PC, or tap a capsule to the phone.'),
        h('button', { class: 'btn primary wide', onclick: () => app.go('party') }, 'See who is with you')),
      encEl);
      renderEncounter();
      return;
    }
    tickNeeds(app.idx, b);
    const tier = friendshipTier(b.friendship);
    const m = mood(b);
    const sp = speciesOf(app.idx, b);
    monitorEl = monitor(b);
    if (Date.now() - pinged < 900) monitorEl.classList.add('ping');
    mount(el,
      encEl,
      h('div', { class: 'buddy-head' },
        h('div', { class: 'grow' }, h('h1', null, displayName(app.idx, b)),
          h('div', { class: 'row wrap' }, (sp?.types ?? []).map((t) => typeChip(app.idx, t)), hearts(tier.hearts), h('span', { class: 'dim' }, tier.label))),
        h('div', { class: 'col', style: { alignItems: 'flex-end', gap: '0' } }, h('span', null, `Lv. ${b.level}`), h('span', { class: 'dim' }, m.label))),
      h('button', { class: 'monitor-btn', 'aria-label': `Tap ${displayName(app.idx, b)}’s capsule`, onclick: tap }, monitorEl),
      h('p', { class: 'micro dim center' }, 'Tap the capsule gently to let them know you are there.'),
      thoughtsEl,
      vitals(b),
      walkEl,
      h('details', { class: 'more' }, h('summary', null, 'Stats, moves and memories'),
        creatureSummary(app.idx, app.bank, b, { compact: true, sections: ['stats', 'moves', 'walk', 'likes', 'memories'] })));
    renderThoughts();
    renderWalk();
    renderEncounter();
  }
  render();
  return {
    el, update: render,
    mounted() { if (!(app.save.thoughts ?? []).some((x) => x.uid === app.settings.buddyUid && Date.now() - x.at < 30 * 60000)) app.think(true); },
    dispose() { offs.forEach((o) => o()); },
  };
}

/** A wild creature turned up: a timing-ring throw, up to three tries. */
function catchPanel(app, enc) {
  const sp = app.idx.species.get(enc.speciesId);
  const el = h('section', { class: 'panel encounter' });
  const cv = h('canvas', { class: 'ring-canvas', width: 240, height: 240 });
  let raf = 0, t0 = performance.now(), busy = false, msg = '';
  const tries = () => enc.tries ?? 0;
  const ctx = cv.getContext('2d');
  // the ring shrinks from 110 to 20 and starts over; the sweet spot is the target circle
  const TARGET = 46;
  const ringR = (t) => { const k = ((t - t0) / 1300) % 1; return 110 - k * 90; };
  function draw(t) {
    const r = ringR(t);
    ctx.clearRect(0, 0, 240, 240);
    const g = ctx.createRadialGradient(120, 120, 10, 120, 120, 120);
    g.addColorStop(0, 'rgba(91,140,255,.18)'); g.addColorStop(1, 'rgba(91,140,255,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, 240, 240);
    ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(52,209,191,.9)';
    ctx.beginPath(); ctx.arc(120, 120, TARGET, 0, Math.PI * 2); ctx.stroke();
    const good = Math.abs(r - TARGET) < 8;
    ctx.lineWidth = 3; ctx.strokeStyle = good ? '#ffd23c' : 'rgba(255,255,255,.85)';
    ctx.beginPath(); ctx.arc(120, 120, r, 0, Math.PI * 2); ctx.stroke();
    raf = requestAnimationFrame(draw);
  }
  async function thrw() {
    if (busy) return;
    busy = true;
    const r = ringR(performance.now());
    const quality = Math.max(0, 1 - Math.abs(r - TARGET) / 40);
    cancelAnimationFrame(raf);
    const caught = app.rollThrow(enc, quality);
    await throwShow(caught);
    const out = await app.throwAt(enc, quality, caught);
    busy = false;
    if (out === 'caught' || out === 'fled') return; // the app replaces this panel
    msg = quality > 0.85 ? 'Great throw! It broke free at the last second.' : quality > 0.5 ? 'Almost had it!' : 'It slipped right out.';
    render();
  }
  // the throw, the way the games show it: arc in, open, take them in, drop, shake, click (or pop)
  const skin = app.emptyBalls()[0] ? app.save.capsules?.[app.emptyBalls()[0].tag]?.skin ?? app.settings.catchBall ?? '' : '';
  const ball = (pose, x, y, s = 3) => drawCapsule(ctx, x - 10 * s, y - 22 * s, s, { skin, pose, lit: true, ring: '#7dffcf' });
  const anim = (ms, fn) => new Promise((res) => {
    const t0 = performance.now();
    const step = (now) => { const k = Math.min(1, (now - t0) / ms); ctx.clearRect(0, 0, 240, 240); fn(k); if (k < 1) requestAnimationFrame(step); else res(); };
    requestAnimationFrame(step);
  });
  async function throwShow(caught) {
    const spriteEl = el.querySelector('.enc-sprite');
    sfx('blip'); app.platform.vibrate([20]);
    await anim(420, (k) => ball('closed', 120, 250 - 120 * k - Math.sin(Math.PI * k) * 70, 2 + k));
    spriteEl?.classList.add('absorb');
    sfx('transfer');
    await anim(420, (k) => { ball('open', 120, 130, 3); ctx.fillStyle = `rgba(255,255,255,${0.7 * (1 - k)})`; ctx.beginPath(); ctx.arc(120, 105, 40 * (1 - k) + 4, 0, Math.PI * 2); ctx.fill(); });
    await anim(260, (k) => ball('closed', 120, 130 + 50 * k * k, 3));
    const shakes = caught ? 3 : 1 + Math.floor(Math.random() * 3);
    for (let n = 0; n < shakes; n++) {
      await anim(140, () => ball('closed', 120, 180, 3));
      app.platform.vibrate([15]);
      await anim(420, (k) => ball(k < 0.33 ? 'shake1' : k < 0.66 ? 'shake2' : 'shake3', 120, 180, 3));
      sfx('move');
    }
    if (caught) {
      sfx('heal');
      await anim(700, (k) => { ball('closed', 120, 180, 3); ctx.fillStyle = '#ffd23c'; for (let s = 0; s < 3; s++) { const a = -Math.PI / 2 + (s - 1) * 0.7; const r = 30 + 30 * k; ctx.globalAlpha = 1 - k; ctx.fillRect(120 + Math.cos(a) * r - 3, 150 + Math.sin(a) * r - 3, 6, 6); ctx.globalAlpha = 1; } });
    } else {
      await anim(300, (k) => { ball('open', 120, 180, 3); ctx.fillStyle = `rgba(255,255,255,${1 - k})`; ctx.fillRect(0, 0, 240, 240); });
      spriteEl?.classList.remove('absorb');
    }
  }

  function render() {
    const left = 3 - tries();
    mount(el,
      h('div', { class: 'row' }, h('span', { class: 'enc-badge' }, 'WILD'), h('h2', { class: 'grow' }, `${sp?.name ?? enc.speciesId} · Lv. ${enc.level}`),
        h('button', { class: 'btn small', onclick: () => app.leaveEncounter() }, 'Leave it')),
      h('p', { class: 'dim' }, msg || `Your empty capsule is buzzing. Something is nearby in ${envPhrase(enc.env)}.`),
      h('div', { class: 'enc-stage' }, cv, h('div', { class: 'enc-sprite' }, spriteCanvas(app.bank, enc, { scale: 3, animate: true }))),
      h('button', { class: 'btn primary wide', onclick: thrw }, `Throw when the ring lines up (${left} ${left === 1 ? 'try' : 'tries'} left)`));
    t0 = performance.now();
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(draw);
  }
  render();
  const stop = new MutationObserver(() => { if (!el.isConnected) { cancelAnimationFrame(raf); stop.disconnect(); } });
  queueMicrotask(() => { if (el.parentNode) stop.observe(el.parentNode, { childList: true }); });
  void toast;
  return el;
}
