// Full PC mode (Settings → Debug): this phone becomes its own PC. The PC's data lives in the same place the web
// copy of the PC app keeps it (web/src/store.js, in this app's IndexedDB), the PC app itself is www/pc.html (the
// web build's PC part), and while the phone app is open a hub runs right here in the page, so the phone links to
// its own PC with the ordinary sync: catch someone on a walk and they're in the PC's boxes the next time you open
// the PC apps, and the other way round.
import { WebStore, unb64 } from '../../web/src/store.js';
import { Hub } from '../../shared/net/hub.js';
import { createSave, HUB_PORT, randomId } from '../../shared/engine/index.js';

export const INNER_URL = `ws://this-page:${HUB_PORT}`;
const TOKEN_KEY = 'innerPcToken';
const clone = (x) => JSON.parse(JSON.stringify(x));

let store = null, hub = null, starting = null;
export const innerPcRunning = () => !!hub;
export const isInnerUrl = (url) => { try { const u = new URL(url); return u.hostname === 'this-page'; } catch { return false; } };

/** A socket to the hub in this page that looks like a WebSocket to the phone's hub client. */
function LocalSocket(url) {
  const self = this, handlers = { message: [], close: [] };
  let open = false;
  this.url = url; this.readyState = 0;
  this.onopen = this.onmessage = this.onclose = this.onerror = null;
  const conn = {
    id: `inner-${randomId(4)}`, remote: 'this phone',
    on(evt, fn) { handlers[evt]?.push(fn); },
    send(obj) { if (!open) return; const data = typeof obj === 'string' ? obj : JSON.stringify(obj); setTimeout(() => { if (open) self.onmessage?.({ data }); }, 0); },
    close() { finish(); },
  };
  function finish() {
    if (self.readyState === 3) return;
    open = false; self.readyState = 3;
    for (const fn of handlers.close) { try { fn(); } catch { /* fine */ } }
    setTimeout(() => self.onclose?.({ code: 1000, wasClean: true }), 0);
  }
  this.send = (text) => {
    if (!open) throw new Error('The link is not open.');
    let msg; try { msg = JSON.parse(text); } catch { return; }
    setTimeout(() => { for (const fn of handlers.message) { try { fn(msg); } catch (e) { console.error('[inner hub]', e); } } }, 0);
  };
  this.close = () => finish();
  this.addEventListener = (t, fn) => { if (t === 'message') { const prev = self.onmessage; self.onmessage = (e) => { prev?.(e); fn(e); }; } };
  this.removeEventListener = () => {};
  setTimeout(async () => {
    try { await startInnerPc(); } catch (e) { self.onerror?.({}); finish(); return; }
    open = true; self.readyState = 1;
    hub.attach(conn);
    self.onopen?.({});
  }, 0);
}
let shimmed = false;
function installShim() {
  if (shimmed || typeof window === 'undefined') return;
  shimmed = true;
  const Real = window.WebSocket;
  function Socket(url, protocols) {
    if (isInnerUrl(url)) return new LocalSocket(url);
    return protocols === undefined ? new Real(url) : new Real(url, protocols);
  }
  Socket.prototype = Real.prototype;
  Socket.CONNECTING = 0; Socket.OPEN = 1; Socket.CLOSING = 2; Socket.CLOSED = 3;
  window.WebSocket = Socket;
}

/** Open the phone's own PC (once) and start its hub. */
export function startInnerPc() {
  installShim();
  starting ??= (async () => {
    store = new WebStore();
    await store.load();
    let token = store.kv.get(TOKEN_KEY);
    if (!token) { token = randomId(16); store.put(TOKEN_KEY, token); }
    hub = new Hub({
      mode: 'home',
      name: 'This phone’s PC',
      getIdx: () => store.idx,
      getSave: () => store.save,
      onSaveChanged: () => { store.rev++; store.persist(); },
      getPhoneUpdate: () => null,
      getDock: () => null,
      getCries: () => store.cryBundle(),
      getTextures: () => store.textureBundle(),
      localToken: token,
      backups: {
        put: (device, backup) => store.keepPhoneBackup(device, backup),
        list: () => store.listBackups().filter((b) => b.kind === 'phone').slice(0, 30),
        get: (file) => store.readBackupFile(file),
      },
      log: () => {},
    });
    return { store, hub, token };
  })();
  starting.catch(() => { starting = null; });
  return starting;
}

/** Everything written down (before the page changes to the PC apps, or back). */
export async function flushInnerPc() {
  if (!store) return;
  try { await store.writeNow(); await store.flushTextures?.(); } catch { /* fine */ }
}

/**
 * The first time: the phone's account becomes the PC's. Its trainer, creatures (still with you, on this phone),
 * items, capsules and stats, its data set, and its pictures and cries. Returns the token the phone links with.
 */
export async function seedInnerPc(app) {
  const { store: st, token } = await startInnerPc();
  if (st.kv.get('seededFrom') === app.settings.deviceId) return token;
  const ph = app.save;
  const pc = createSave(ph.trainer?.name ?? 'Trainer', 1);
  for (const [k, v] of Object.entries(clone(ph))) if (!['settings', 'queue', 'satchel', 'satchelOnly', 'devices'].includes(k)) pc[k] = v;
  if (ph.satchelOnly) pc.inventory = clone(ph.satchelOnly);
  pc.settings = { ...pc.settings, sound: ph.settings.sound, volume: ph.settings.volume, battleMusic: ph.settings.battleMusic, atlasSpot: ph.settings.atlasSpot ?? null };
  pc.devices = { [app.settings.deviceId]: { name: app.settings.deviceName || 'My phone', token: randomId(16), pairedAt: Date.now() } };
  for (const c of Object.values(pc.creatures ?? {})) {
    if (!c.location || c.location.kind === 'phone' || c.location.kind === 'party') c.location = { kind: 'phone', device: app.settings.deviceId };
  }
  // (the phone was set up already: the PC skips its own setup)
  st.setDataset({ ...clone(app.dataset), setup: { ...(app.dataset.setup ?? {}), done: true } });
  // a fresh profile holding the phone's save
  const id = st.createProfile({ name: pc.trainer?.name ?? 'Trainer' }, { open: false });
  st.put(st.saveKey(id), pc);
  // (the empty profile the store made for itself the first time goes: this phone's account is the only one)
  for (const other of st.profiles.order) if (other !== id) st.del(st.saveKey(other));
  st.profiles.order = [id];
  st.profiles.active = id;
  st.writeIndex();
  st.save = null;
  st.openProfile(id);
  // pictures and cries the phone has
  const files = [];
  for (const [p, url] of Object.entries({ ...(app.textures?.files ?? {}), ...(app.cries?.files ?? {}) })) {
    const m = /^data:[^;]+;base64,(.*)$/.exec(String(url));
    if (m) { try { files.push({ path: p, data: unb64(m[1]) }); } catch { /* skip */ } }
  }
  if (files.length) st.importTextures(files);
  st.put('seededFrom', app.settings.deviceId);
  await flushInnerPc();
  return token;
}

/** The phone's own PC data, gone (when the phone links to a real PC again and overwrites itself). */
export async function wipeInnerPc() {
  const { store: st } = await startInnerPc();
  await st.wipe();
  store = null; hub = null; starting = null;
}
