// Capsule Link — phone app core: local pocket save, PC sync, walking, capsule taps, bumps.
import {
  indexDataset, createDefaultDataset, createSave, applyEvent, makeEvent, MSG, diffMutator, tickAll, list,
  displayName, speciesOf, createCreature, cryFor, readCapsule, syncCapsule, sendToCapsule, releaseFromCapsule, setCapsuleMode,
  writeCapsule, randomId, party as partyOf, bridgeScript, toId, ensureTrainerCard,
  thoughtFor, rollEncounter, tryCatch, caughtCreature, walkFirsts, normalizeEnv, envPhrase,
  contextEnv, PLACES, activeIncense, weatherForm, currentFormId, friendsOf, timeOfDay, transportOf, homeState, itemInfo, sunFor, setSky, skyRecord,
} from '../../shared/engine/index.js';
import { sense, summary as senseSummary } from './surroundings.js';
import { SpriteBank } from '../../shared/ui/art.js';
import { h, mount, toast, setBrand, confirmDialog } from '../../shared/ui/dom.js';
import { sfx, setSound, playCry, creatureCry, setCryResolver } from '../../shared/ui/audio.js';
import { HubClient } from '../../shared/net/client.js';
import { platform, isNative } from './platform.js';
import { buddyView } from './monitor.js';
import { partyView, capsuleView, battleView, linkView, welcomeView } from './views.js';
import { prepareTeam, ingestBattle, showdownSettings } from '../../shared/ui/showdownUi.js';
import { icon } from './icons.js';
import { logoMark } from '../../shared/ui/icons.js';
import { EmulatedBalls } from './simball.js';
import { debugView } from './debug.js';
import { togetherView } from './together.js';
import { kvGet, kvSet } from './kv.js';
import { transferLine } from '../../shared/ui/transfer.js';
import { setUiArt } from '../../shared/ui/brandArt.js';
import { playIntro } from '../../shared/ui/introShow.js';
import { makeBackup, readBackup, backupFileName } from '../../shared/engine/backup.js';

const KEY = 'capsule-link-mobile:v1';
const BUILD = typeof __BUILD__ !== 'undefined' ? __BUILD__ : { version: '0.0.0' };
const clone = (x) => JSON.parse(JSON.stringify(x));

const TABS = [
  ['buddy', 'Monitor', buddyView],
  ['party', 'With you', partyView],
  ['together', 'Together', togetherView],
  ['capsule', 'Capsules', capsuleView],
  ['battle', 'Battle', battleView],
  ['link', 'Link', linkView],
  ['debug', 'Debug', debugView, true], // opened from the Link tab
];

class PhoneApp {
  constructor() {
    this.platform = platform;
    this.native = isNative;
    this.tab = 'buddy';
    this.view = null;
    this.subs = new Set();
    this.walk = { walking: false, session: 0, pending: 0 };
    this.capsuleArm = null; // what the next capsule tap does
    this.lastTag = null;
  }

  // ---------- persistence ----------
  // The save stays in localStorage (small, written often). The data set and textures can be
  // megabytes once every species and sprite is in, so they live in IndexedDB.
  async load() {
    let data = null;
    try { data = JSON.parse(localStorage.getItem(KEY)); } catch { /* fresh */ }
    const storedDs = data?.dataset ?? (await kvGet('dataset'));
    this.dataset = storedDs ?? createDefaultDataset();
    this.idx = indexDataset(this.dataset);
    this.dataset = this.idx.ds; setBrand(this.dataset.brand);
    this.save = data?.save ?? createSave('Trainer', 1);
    this.pcList = data?.pcList ?? [];
    let tex = await kvGet('textures');
    if (!tex) { try { tex = JSON.parse(localStorage.getItem(`${KEY}:textures`)); } catch { /* none */ } }
    this.textures = tex?.files ? tex : { hash: '', files: {} };
    setUiArt((p) => this.textures.files[p.toLowerCase()] ?? null, () => Object.keys(this.textures.files ?? {}));
    // the PC's downloaded cries
    this.cries = (await kvGet('cries')) ?? { hash: '', files: {} };
    setCryResolver((p) => this.cries.files?.[p.toLowerCase()] ?? null);
    if (data?.dataset) this.storeDataset(); // move an older phone's data set out of localStorage
    try {
      if (localStorage.getItem(`${KEY}:textures`)) kvSet('textures', this.textures).then(() => localStorage.removeItem(`${KEY}:textures`)).catch(() => {});
    } catch { /* storage blocked */ }
    ensureTrainerCard(this.save);
    // the satchel is this phone's bag (one object, so using an item here empties it there)
    if (this.save.satchel) this.save.satchel = this.save.inventory;
    // the sky where you last were: night is night even before the next look-around
    if (this.save.sky) setSky(this.save.sky);
    if (this.save.settings?.surroundings?.lat != null) setSky({ lat: this.save.settings.surroundings.lat, lon: this.save.settings.surroundings.lon });
    // in the browser preview the PC preview runs next door: until a real PC is linked, the phone
    // shows the same data set, names and pictures (on a real phone these arrive with each sync)
    if (!isNative && !this.save.settings?.hubUrl) {
      try {
        const pcDs = JSON.parse(localStorage.getItem('capsule-link:dataset'));
        if (pcDs?.species?.length) { this.idx = indexDataset(pcDs); this.dataset = this.idx.ds; setBrand(this.dataset.brand); }
        const pcTex = JSON.parse(localStorage.getItem('capsule-link:textures'));
        if (pcTex && typeof pcTex === 'object') { this.textures = { hash: 'preview', files: pcTex }; setUiArt((p) => this.textures.files[p.toLowerCase()] ?? null, () => Object.keys(this.textures.files ?? {})); }
      } catch { /* nothing there */ }
    }
    const s = this.save.settings;
    s.deviceId = s.deviceId || `phone-${randomId(6)}`;
    s.deviceName = s.deviceName || 'My phone';
    this.save.queue = this.save.queue || [];
    tickAll(this.idx, this.save);
  }
  persist() {
    if (this.restoring) return; // a backup is being put back: don't write over it before the restart
    try { localStorage.setItem(KEY, JSON.stringify({ save: this.save, pcList: this.pcList })); }
    catch (e) { toast(`Could not save on this phone: ${e.message}`, 'err'); }
  }
  storeDataset() {
    kvSet('dataset', this.dataset).then(() => this.persist()).catch((e) => toast(`Could not keep the data set on this phone: ${e.message}`, 'err'));
  }

  get settings() { return this.save.settings; }
  creatures() { return list(this.save); }
  buddy() { return this.save.creatures[this.settings.buddyUid] ?? null; }
  /** Everyone who is with you: on the phone or in a capsule you carry. The buddy leads. */
  team() {
    const with_ = this.creatures().filter((c) => ['phone', 'party', 'capsule'].includes(c.location?.kind) && this.idx.species.has(c.speciesId));
    with_.sort((a, b) => (b.uid === this.settings.buddyUid) - (a.uid === this.settings.buddyUid));
    return with_.slice(0, this.idx.ds.rules.partySize);
  }

  on(fn) { this.subs.add(fn); return () => this.subs.delete(fn); }
  emit(what) { for (const fn of this.subs) fn(what); }

  /** Apply an event here now and queue it for the PC. */
  record(ev) {
    // items used here come out of the satchel packed at the PC
    if (this.save.satchel) ev.satchel = true;
    const r = applyEvent(this.idx, this.save, ev);
    if (r.ok !== false) this.save.queue.push(ev);
    this.persist();
    this.refresh();
    return r;
  }

  /** Changes made on a copy (capsule work): apply them and queue matching events for the PC. */
  adopt(before, after) {
    diffMutator(before, after)(this.save);
    const evs = [];
    for (const [uid, c] of Object.entries(after.creatures)) {
      if (JSON.stringify(c) !== JSON.stringify(before.creatures[uid])) evs.push(makeEvent('snapshot', { creature: clone(c) }));
    }
    const delta = {};
    for (const k of new Set([...Object.keys(after.inventory), ...Object.keys(before.inventory)])) {
      const d = (after.inventory[k] ?? 0) - (before.inventory[k] ?? 0);
      if (d) delta[k] = d;
    }
    const steps = (after.stats.totalSteps ?? 0) - (before.stats.totalSteps ?? 0);
    if (Object.keys(delta).length || steps) evs.push(makeEvent('items', { delta, steps }));
    for (const [tag, cap] of Object.entries(after.capsules)) {
      if (JSON.stringify(cap) !== JSON.stringify(before.capsules[tag])) evs.push(makeEvent('capsule', { tag, uid: cap.uid ?? null, mode: cap.mode, name: cap.name, skin: cap.skin ?? '', holder: cap.holder }));
    }
    for (const ev of evs) { this.save.appliedEvents.push(ev.id); this.save.queue.push(ev); }
    this.watchCapsules();
    this.persist();
    this.refresh();
  }

  local(fn) { fn(this.save); this.persist(); this.refresh(); }

  // ---------- shell ----------
  async boot() {
    await this.load();
    this.emulated = new EmulatedBalls(this);
    this.startDockWatch();
    this.bank = new SpriteBank({ idx: this.idx, resolveTexture: (p) => this.textures.files[p.toLowerCase()] ?? null });
    setSound(this.settings.sound !== false, this.settings.volume ?? 0.6);
    this.root = h('div', { class: 'm-app' });
    document.body.append(this.root);
    this.startNfc();
    this.startWalkWatch();
    this.startBeacons();
    this.startShowdownWatch();
    // browser preview: follow the PC preview next door as it changes (names, data, pictures)
    if (!isNative) {
      window.addEventListener('storage', (e) => {
        if (this.settings.hubUrl || !['capsule-link:dataset', 'capsule-link:textures'].includes(e.key)) return;
        try {
          const v = JSON.parse(e.newValue);
          if (e.key === 'capsule-link:dataset' && v?.species?.length) { this.idx = indexDataset(v); this.dataset = this.idx.ds; setBrand(this.dataset.brand); this.bank?.setDataset(this.idx); }
          if (e.key === 'capsule-link:textures' && v) { this.textures = { hash: 'preview', files: v }; this.bank?.setResolver((p) => this.textures.files[p.toLowerCase()] ?? null); setUiArt((p) => this.textures.files[p.toLowerCase()] ?? null, () => Object.keys(this.textures.files ?? {})); }
          if (this.topEl) this.refresh();
        } catch { /* not ours */ }
      });
    }
    if (!this.settings.onboarded) { this.showWelcome(); requestAnimationFrame(() => window.__bootDone?.()); return; }
    this.buildShell();
    this.go(this.tab);
    requestAnimationFrame(() => window.__bootDone?.());
    // a new build of the app on GitHub? (twice a day at most)
    if (this.settings.githubRepo && this.native && Date.now() - (this.settings.githubCheckedAt ?? 0) > 12 * 3600000) setTimeout(() => this.checkGithub({ quiet: true }), 5000);
    if (this.settings.hubUrl) this.sync({ quiet: true }).catch(() => {});
  }

  async showWelcome() {
    if (!this.settings.introSeen) {
      await playIntro(this.root, { text: this.dataset.introText });
      this.settings.introSeen = true;
      this.persist();
    }
    mount(this.root, welcomeView(this, () => { this.settings.onboarded = true; this.persist(); this.buildShell(); this.go('buddy'); }));
  }

  buildShell() {
    this.topEl = h('header', { class: 'm-top' });
    this.viewEl = h('main', { class: 'm-view' });
    this.tabsEl = h('nav', { class: 'm-tabs', 'aria-label': 'Sections' });
    mount(this.root, this.topEl, this.viewEl, this.tabsEl);
    this.renderTabs();
    this.renderTop();
  }

  renderTop() {
    if (!this.topEl) return;
    const linked = !!this.settings.hubUrl;
    const pending = this.save.queue.length;
    mount(this.topEl,
      h('span', { class: 'm-brand' }, logoMark(22), 'Capsule Link'),
      h('span', { class: 'spacer' }),
      this.walk.walking ? h('span', { class: 'm-pill walking' }, '♪ walking') : null,
      h('button', { class: 'm-pill', onclick: () => this.go('link') }, h('span', { class: `dot ${linked ? (pending ? 'sim' : 'on') : ''}` }), linked ? (pending ? `${pending} to sync` : 'Linked') : 'Not linked'));
  }

  renderTabs() {
    mount(this.tabsEl, TABS.filter((t) => !t[3]).map(([id, label]) => h('button', {
      'aria-current': this.tab === id || (this.tab === 'debug' && id === 'link') ? 'page' : 'false',
      onclick: () => { sfx('move'); this.go(id); },
    }, icon(id, 22), label)));
  }

  go(id) {
    const t = TABS.find((x) => x[0] === id) ?? TABS[0];
    this.view?.dispose?.();
    this.tab = t[0];
    this.renderTabs();
    this.view = t[2](this);
    mount(this.viewEl, this.view.el);
    this.view.mounted?.();
    this.viewEl.scrollTop = 0;
  }

  refresh() {
    this.renderTop();
    this.view?.update?.();
  }

  // ---------- PC link ----------
  client(url = this.settings.hubUrl, extra = {}) {
    return new HubClient({ url, deviceId: this.settings.deviceId, name: this.settings.deviceName, kind: 'phone', token: this.settings.token, ...extra });
  }

  async connectPc(url, pairCode, { keepUrl = false } = {}) {
    const c = this.client(url, { pairCode });
    const w = await c.connect();
    if (!keepUrl || !this.settings.hubUrl) this.settings.hubUrl = url;
    if (w.token) this.settings.token = w.token;
    if (w.trainer?.name) { this.save.trainer = w.trainer; ensureTrainerCard(this.save); }
    this.persist();
    c.close();
    await this.sync();
  }

  /** Send queued events and phone-only creatures, then take the PC's view of our pocket. */
  async sync({ quiet = false, forceUpdate = false } = {}) {
    if (!this.settings.hubUrl) throw new Error('Link to your PC first.');
    const c = this.client();
    try {
      await c.connect();
      const known = new Set(this.pcList.map((x) => x.uid));
      const newOnes = this.creatures().filter((x) => !known.has(x.uid));
      const native = this.native ? (await this.platform.appInfo()).builtIn : null;
      const appVer = { version: BUILD.version, phoneNative: native?.phoneNative || BUILD.phoneNative, declined: this.settings.declinedUpdate ?? null, force: forceUpdate || undefined };
      const st = await c.request(MSG.PUSH, { events: this.save.queue, creatures: newOnes, datasetHash: this.idx.syncHash, texturesHash: this.textures.hash, criesHash: this.cries?.hash ?? '', app: appVer }, MSG.STATE, 60000);
      this.applyState(st);
      if (!quiet) toast('Synced with your PC.', 'ok');
      // once a day the PC keeps a copy of this phone's save too
      if (Date.now() - (this.settings.lastPcBackup ?? 0) > 20 * 3600e3) {
        try {
          const r = await c.request(MSG.BACKUP_PUT, { backup: this.backup('daily') }, MSG.BACKUP, 30000);
          if (r.ok) { this.settings.lastPcBackup = Date.now(); this.persist(); }
        } catch { /* an older PC app: fine */ }
      }
      return st;
    } finally { c.close(); }
  }

  applyState(st) {
    if (st.dataset) {
      this.dataset = st.dataset;
      this.idx = indexDataset(st.dataset);
      this.dataset = this.idx.ds; setBrand(this.dataset.brand);
      this.bank.setDataset(this.idx);
      this.storeDataset();
    }
    this.pcDock = st.dock ?? null; // what the PC's dock holds
    this.appStatus = st.appStatus ?? null;
    // an update is waiting on the PC but was made for a different Android build: say so once
    if (this.appStatus?.state === 'native' && this.settings.nativeNotice !== this.appStatus.version && this.platform.canUpdate) {
      this.settings.nativeNotice = this.appStatus.version;
      setTimeout(() => this.askUpdateAnyway(), 400);
    }
    if (st.appUpdate) {
      this.pendingUpdate = st.appUpdate; // also shown under Link → About this app
      if (this.platform.canUpdate) setTimeout(() => this.offerUpdate(st.appUpdate), 300);
      else toast(`Update v${st.appUpdate.version} is ready, but this phone can’t install it (${this.native ? 'the app’s Android part is missing' : 'browser preview'}).`, 'err');
    }
    if (st.textures) {
      this.textures = st.textures;
      kvSet('textures', st.textures).catch(() => toast('Your PC textures are too big to keep on this phone.', 'err'));
      this.bank.setResolver((p) => this.textures.files[p.toLowerCase()] ?? null);
      setUiArt((p) => this.textures.files[p.toLowerCase()] ?? null, () => Object.keys(this.textures.files ?? {}));
    }
    const mine = (c) => (c.location?.kind === 'phone' && c.location.device === this.settings.deviceId) || c.location?.kind === 'capsule';
    for (const c of st.pocket ?? []) this.save.creatures[c.uid] = c;
    // creatures the PC holds now (returned, or let out at the dock) leave the phone
    for (const s of st.all ?? []) {
      const local = this.save.creatures[s.uid];
      if (local && !mine(s)) delete this.save.creatures[s.uid];
    }
    if (st.inventory) { this.save.inventory = st.inventory; this.save.satchel = st.satchel ? this.save.inventory : null; }
    if (st.cries) {
      this.cries = st.cries;
      kvSet('cries', st.cries).catch(() => toast('Your PC’s cries are too big to keep on this phone.', 'err'));
      setCryResolver((p) => this.cries.files?.[p.toLowerCase()] ?? null);
    }
    if (st.capsules) {
      // the PC's list wins: balls unsynced or deleted there disappear here too, unless this phone
      // has news about one that hasn't reached the PC yet
      const pending = new Set(this.save.queue.filter((e) => e.type === 'capsule').map((e) => e.tag));
      const next = {};
      for (const [tag, cap] of Object.entries(st.capsules)) next[tag] = pending.has(tag) ? { ...cap, ...(this.save.capsules[tag] ?? {}) } : { ...(this.save.capsules[tag] ?? {}), ...cap };
      for (const [tag, cap] of Object.entries(this.save.capsules)) if (!(tag in next) && pending.has(tag)) next[tag] = cap;
      this.save.capsules = next;
    }
    if (st.trainer) { this.save.trainer = st.trainer; ensureTrainerCard(this.save); }
    if (st.stats) this.save.stats = st.stats;
    const acked = new Set(st.acked ?? []);
    this.save.queue = this.save.queue.filter((ev) => !acked.has(ev.id));
    this.pcList = st.all ?? this.pcList;
    this.settings.lastSync = Date.now();
    if (this.settings.buddyUid && !this.save.creatures[this.settings.buddyUid]) this.settings.buddyUid = null;
    if (!this.settings.buddyUid) this.settings.buddyUid = this.creatures()[0]?.uid ?? null;
    this.persist();
    this.refresh();
  }

  /** The PC has an update whose Android fingerprint differs from this phone's: offer it anyway. */
  async askUpdateAnyway() {
    const s = this.appStatus;
    if (!s || s.state !== 'native') return;
    const yes = await confirmDialog(`Update to v${s.version}?`, `Your PC has v${s.version} of this app, made for a slightly different build of the Android app (${s.need ?? '?'} here: ${s.have ?? '?'}). It usually works fine. If it doesn't start properly, Link → About this app → Use the built-in version puts things back.`, { ok: 'Update anyway', cancel: 'Not now' });
    if (!yes) return;
    try { await this.sync({ quiet: true, forceUpdate: true }); } catch (e) { toast(e.message, 'err'); }
  }

  /** A newer version of this app's code came from the PC (from an update file installed there). */
  async offerUpdate(u) {
    if (this.updating) return;
    const yes = await confirmDialog(`Update to v${u.version}?`, `${u.notes ? `${u.notes} ` : ''}It takes a few seconds and the app restarts. Your creatures and settings stay as they are.${u.nativeMismatch ? ' (It was made for a slightly different build of the Android app; if it doesn’t start properly, choose “Use the built-in version” on the start-up screen or under Link → About this app.)' : ''}`, { ok: 'Update now', cancel: 'Not now' });
    if (!yes) { this.local((s) => { s.settings.declinedUpdate = u.version; }); toast('You can update later from Link → About this app.'); return; }
    this.updating = true;
    this.persist();
    // keep everything as it is now, on this phone and on the PC, before the new code runs
    const before = this.backup(`before-update-${u.version}`);
    try { await kvSet('backup:before-update', before); } catch { /* storage full */ }
    try { await this.sendBackup(before, 6000); } catch { /* the PC copy is a bonus */ }
    try { await this.platform.installWebBundle(u.version, u.files); toast('Updating…'); }
    catch (e) { this.updating = false; toast(`The update didn’t install: ${e?.message || e}`, 'err'); }
  }

  // ---------- backups ----------
  /** Everything this phone keeps, in one object (see shared/engine/backup.js). */
  backup(reason = 'by hand') {
    const ls = (k) => { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } };
    return makeBackup('phone', BUILD.version, {
      save: clone(this.save), pcList: this.pcList,
      vtags: ls('capsule-link-mobile:vtags'), simball: ls('capsule-link-mobile:simball'), pending: ls('capsule-link-mobile:pending'),
    }, { reason });
  }
  backupText() { return JSON.stringify(this.backup()); }
  backupName() { return backupFileName('phone', this.settings.deviceName); }

  /** Keep a backup on the linked PC (Settings → Backups there). */
  async sendBackup(backup = this.backup(), ms = 30000) {
    if (!this.settings.hubUrl) throw new Error('Link to your PC first.');
    const c = this.client();
    try {
      await c.connect();
      const r = await c.request(MSG.BACKUP_PUT, { backup }, MSG.BACKUP, ms);
      if (!r.ok) throw new Error(r.error);
      this.settings.lastPcBackup = Date.now();
      this.persist();
      return r.file;
    } catch (e) {
      if (/Unknown message/.test(e.message)) throw new Error('Update the PC app first: this version of it can’t keep phone backups.');
      throw e;
    } finally { c.close(); }
  }
  async pcBackups() {
    const c = this.client();
    try {
      await c.connect();
      const r = await c.request(MSG.BACKUP_LIST, {}, MSG.BACKUP, 15000);
      if (!r.ok) throw new Error(r.error);
      return r.list ?? [];
    } catch (e) {
      if (/Unknown message/.test(e.message)) throw new Error('Update the PC app first: this version of it can’t keep phone backups.');
      throw e;
    } finally { c.close(); }
  }
  async pcBackup(file) {
    const c = this.client();
    try {
      await c.connect();
      const r = await c.request(MSG.BACKUP_GET, { file }, MSG.BACKUP, 30000);
      if (!r.ok) throw new Error(r.error);
      return r.text;
    } finally { c.close(); }
  }
  async beforeUpdateBackup() { try { return await kvGet('backup:before-update'); } catch { return null; } }

  /** Put a phone backup back, then start over on it. */
  restoreBackup(input) {
    const r = readBackup(input);
    if (!r.ok) throw new Error(r.error);
    if (r.kind !== 'phone') throw new Error(r.kind === 'pc' ? 'That is a PC backup: restore it in the PC app (Settings → Backups).' : 'That is a save from the PC, not a phone backup.');
    const b = r.backup;
    const put = (k, v) => { if (v == null) localStorage.removeItem(k); else localStorage.setItem(k, typeof v === 'string' ? v : JSON.stringify(v)); };
    put(KEY, { save: b.save, pcList: b.pcList ?? [] });
    put('capsule-link-mobile:vtags', b.vtags);
    put('capsule-link-mobile:simball', b.simball);
    put('capsule-link-mobile:pending', b.pending == null ? null : String(b.pending));
    this.restoring = true;
    setTimeout(() => location.reload(), 600);
    return r.summary;
  }

  async take(uids) {
    await this.sync({ quiet: true });
    const c = this.client();
    try {
      await c.connect();
      const st = await c.request(MSG.TAKE, { uids, datasetHash: this.idx.syncHash }, MSG.STATE);
      this.applyState(st);
    } finally { c.close(); }
  }

  async giveBack(uids) {
    await this.sync({ quiet: true });
    const c = this.client();
    try {
      await c.connect();
      const st = await c.request(MSG.RETURN, { uids, creatures: uids.map((u) => this.save.creatures[u]).filter(Boolean), datasetHash: this.idx.syncHash }, MSG.STATE, 30000);
      this.applyState(st);
      const failed = (st.returned ?? []).find((r) => !r.ok);
      if (failed) throw new Error(failed.error);
    } finally { c.close(); }
  }

  // ---------- walking ----------
  startWalkWatch() {
    this.platform.onSteps((s) => {
      this.walk.session = s.sessionSteps ?? this.walk.session;
      this.walk.pending = s.pending ?? this.walk.pending;
      this.emit('steps');
      if (this.walk.pending >= 200) this.creditSteps();
      if (this.walk.walking && this.walk.session - (this.lastLook ?? 0) >= 250) { this.lastLook = this.walk.session; this.lookAround(); }
    });
    const whileAway = (s) => {
      // steps the phone counted while the app was closed
      if (s?.addedWhileClosed > 20 && this.buddy()) toast(`${displayName(this.idx, this.buddy())} walked ${Number(s.addedWhileClosed).toLocaleString()} steps with you while the app was closed.`, 'ok');
    };
    this.platform.walkStatus().then((s) => {
      this.walk = { walking: !!s.walking, session: s.sessionSteps ?? 0, pending: s.pending ?? 0 };
      if (this.walk.walking) this.startThinking();
      whileAway(s);
      this.creditSteps();
      this.renderTop();
    }).catch(() => {});
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) this.platform.walkStatus().then((s) => { Object.assign(this.walk, { walking: !!s.walking, session: s.sessionSteps ?? 0, pending: s.pending ?? 0 }); whileAway(s); this.creditSteps(); }).catch(() => {});
    });
    // counting steps while the app is closed: on unless turned off (asks for the activity permission once)
    if (this.settings.backgroundSteps !== false && this.native) this.setBackgroundSteps(true, { quiet: true });
  }

  async setBackgroundSteps(on, { quiet = false } = {}) {
    if (on) {
      const perm = await this.platform.permissions({ activity: true }).catch(() => null);
      if (perm?.activity === 'denied') { if (!quiet) toast('Allow physical activity so your phone can count steps.', 'err'); return false; }
    }
    try { await this.platform.setBackgroundSteps(on); this.local((st) => { st.settings.backgroundSteps = !!on; }); return true; } catch (e) { if (!quiet) toast(e.message, 'err'); return false; }
  }

  async startWalk() {
    const b = this.buddy();
    if (!b) { toast('Choose a buddy first.', 'err'); return; }
    const perm = await this.platform.permissions({ activity: true, notifications: true });
    if (perm?.activity === 'denied') { toast('Allow physical activity so your phone can count steps.', 'err'); return; }
    try {
      await this.platform.startWalk(`Walking with ${displayName(this.idx, b)}`, 'Steps count toward your friendship.');
      this.walk.walking = true;
      this.walk.session = 0;
      this.lastLook = 0;
      this.settings.walkStartedAt = Date.now();
      // somewhere new is worth remembering
      this.noteFirsts();
      // location makes walks real (places, weather, the sun): ask the first time, unless they chose not to
      if (this.settings.useLocation == null) this.settings.useLocation = true;
      if (this.settings.useLocation) this.lookNow({ quiet: true });
      this.startThinking();
      this.think(true);
      sfx('heal');
      this.refresh();
    } catch (e) { toast(e.message, 'err'); }
  }

  async stopWalk() {
    try { await this.platform.stopWalk(); } catch { /* already stopped */ }
    this.walk.walking = false;
    this.settings.walkStartedAt = null;
    clearInterval(this.thinkTimer);
    await this.creditSteps();
    this.refresh();
  }

  /** Turn counted steps into friendship for the buddy (unless the buddy's capsule counts them). */
  async creditSteps() {
    if (this.crediting) return;
    const n = this.walk.pending;
    if (!n) return;
    const b = this.buddy();
    if (!b) return;
    this.crediting = true;
    try {
      if (b.location?.kind === 'capsule' && this.emulated.has(b.location.tag)) {
        // the ball counts the steps itself, like a real one would
        this.emulated.addSteps(b.location.tag, n);
      } else if (b.location?.kind !== 'capsule') {
        const w = this.walkCtx();
        const context = { env: normalizeEnv(w.env), places: w.places.slice(0, 4), weather: w.weather, temp: w.temp, tod: w.tod, vehicle: w.vehicle, speedKmh: w.speedKmh };
        const r = this.record(makeEvent('walk', { uid: b.uid, steps: n, source: 'phone', context }));
        const out = r.outcome;
        if (out?.finds?.length || out?.coins) {
          const what = [...(out.finds ?? []).map((id) => itemInfo(this.idx, id)?.name ?? 'something'), out.coins ? `${out.coins} coins` : null].filter(Boolean);
          toast(`${displayName(this.idx, b)} found ${what.slice(0, 3).join(', ')} on the walk!`, 'ok');
          for (const id of out.finds ?? []) if (itemInfo(this.idx, id)?.kind === 'valuable') this.addThought(b, `${displayName(this.idx, b)} found something shiny: a ${itemInfo(this.idx, id).name}! It could sell well at the market.`);
        }
        if (out?.events?.some((e) => e.type === 'level')) { sfx('level'); toast(`${displayName(this.idx, b)} grew to Lv. ${b.level}!`, 'ok'); }
      }
      await this.platform.ackSteps(n);
      this.walk.pending = 0;
    } finally { this.crediting = false; }
  }

  // ---------- new builds of the app itself, straight from your GitHub repository ----------
  /**
   * The newest phone-app.apk under Releases in settings.githubRepo ("owner/name"). quiet: no messages unless
   * there's something new. Returns { newer, asset } or null.
   */
  async checkGithub({ quiet = false } = {}) {
    const repo = String(this.settings.githubRepo ?? '').trim().replace(/^https?:\/\/github\.com\//, '').replace(/\/+$/, '');
    if (!/^[\w.-]+\/[\w.-]+$/.test(repo)) { if (!quiet) toast('Type your GitHub repository first (like yourname/capsule-link).', 'err'); return null; }
    let rel;
    try {
      const r = await fetch(`https://api.github.com/repos/${repo}/releases/tags/latest-build`, { headers: { Accept: 'application/vnd.github+json' } });
      if (!r.ok) throw new Error(r.status === 404 ? 'No “Latest build” release there yet (or the repository is private).' : `GitHub answered ${r.status}.`);
      rel = await r.json();
    } catch (e) { if (!quiet) toast(e.message, 'err'); return null; }
    const asset = (rel.assets ?? []).find((a) => /\.apk$/i.test(a.name));
    if (!asset) { if (!quiet) toast('That release has no APK yet. Wait for the build to finish.', 'err'); return null; }
    const at = Date.parse(asset.updated_at || asset.created_at || 0);
    const BUILD = typeof __BUILD__ !== 'undefined' ? __BUILD__ : {};
    const have = Math.max(this.settings.apkAt ?? 0, Date.parse(BUILD.built ?? 0) || 0);
    this.local((s) => { s.settings.githubCheckedAt = Date.now(); });
    const newer = at > have + 60000;
    if (!newer) { if (!quiet) toast('You have the newest build from GitHub.', 'ok'); return { newer, asset }; }
    const yes = await confirmDialog('A new build of the app', `GitHub has a newer phone app (${new Date(at).toLocaleString()}). Download and install it? Everything on this phone stays.`, { ok: 'Download and install' });
    if (yes) await this.installApkFrom(asset, at);
    return { newer, asset };
  }
  async installApkFrom(asset, at) {
    try {
      toast('Downloading the new app…');
      await this.platform.installApk(asset.browser_download_url);
      this.local((s) => { s.settings.apkAt = at; });
    } catch (e) { toast(e.message ?? String(e), 'err'); }
  }

  // ---------- where you are: places nearby and the weather (when location is allowed) ----------
  /** Everything known about this walk right now, for thoughts, encounters and memories. */
  walkCtx() {
    const s = this.settings.useLocation && this.settings.surroundings && Date.now() - this.settings.surroundings.at < 45 * 60000 ? this.settings.surroundings : null;
    const inc = activeIncense(this.save);
    return {
      env: s ? contextEnv({ ...s, env: [] }) : this.settings.walkEnv,
      places: s?.places ?? [], weather: s?.weather ?? null, temp: Number.isFinite(s?.temp) ? s.temp : undefined, humidity: s?.humidity,
      vehicle: !!s?.vehicle, speedKmh: s?.speedKmh ?? null, incense: inc?.type ?? null, home: s?.home?.state ?? null,
      // the sun: worked out for where you last were (right every day, even when the last look-around is old)
      sun: sunFor(Date.now()) ?? (s ? { sunrise: s.sunrise, sunset: s.sunset, isDay: s.isDay } : null), ride: s ? transportOf(s) : null,
      walkMinutes: this.walkMinutes(), steps: this.walk.session, t: Date.now(), tod: timeOfDay(Date.now()),
    };
  }
  /** Look around (location, then OpenStreetMap and the weather). quiet: no messages. */
  async lookNow({ quiet = false } = {}) {
    if (this.sensing) return null;
    this.sensing = true;
    this.emit('surroundings');
    try {
      const s = await sense(this.lastSense);
      // home: set by hand on the walk screen, or the first place you're at late in the evening
      const hr = new Date().getHours();
      if (!this.settings.home && (hr >= 21 || hr < 6) && !s.vehicle) this.settings.home = { lat: s.lat, lon: s.lon, at: Date.now() };
      const hs = homeState(this.settings.home, s, this.lastHomeKm);
      if (hs) { this.lastHomeKm = hs.km; s.home = { state: hs.state, km: Math.round(hs.km * 10) / 10 }; }
      this.lastSense = s;
      this.settings.surroundings = senseSummary(s);
      // the real sky (sun times, weather, fog): kept here, and sent to the PC now and then
      if (s.lat != null && !s.weatherError) {
        setSky(skyRecord({ ...s, at: Date.now() }));
        if (Date.now() - (this.settings.skySent ?? 0) > 20 * 60000) { this.settings.skySent = Date.now(); this.record(makeEvent('sky', { sky: skyRecord({ ...s, at: Date.now() }) })); }
      } else if (s.lat != null) setSky({ lat: s.lat, lon: s.lon });
      this.persist();
      // somewhere new on a walk is worth remembering
      if (this.walk.walking) this.noteFirsts();
      this.applyWeatherForms();
      if (!quiet && s.placesError && s.weatherError) toast('Couldn’t reach the map or the weather service. Check the internet connection.', 'err');
      return s;
    } catch (e) {
      if (!quiet) toast(e.message, 'err');
      return null;
    } finally { this.sensing = false; this.emit('surroundings'); this.refresh(); }
  }
  /** Weather-shaped creatures change inside their ball (sunny when it's hot, rainy, snowy when it's freezing). */
  applyWeatherForms() {
    const s = this.settings.surroundings;
    if (!s?.weather && !Number.isFinite(s?.temp)) return;
    for (const c of this.team()) {
      const want = weatherForm(this.idx, c, { weather: s.weather, temp: s.temp });
      if (!want || want === currentFormId(this.idx, c)) continue;
      this.record(makeEvent('form', { uid: c.uid, form: want === c.speciesId ? null : want, why: 'weather' }));
      const name = displayName(this.idx, c);
      this.addThought(c, `${name} changed with the weather!`);
    }
  }
  /** First times somewhere: kinds of place, and real places nearby (core memories). */
  noteFirsts() {
    const ctx = this.walkCtx();
    for (const c of this.team()) {
      for (const f of walkFirsts(c, ctx.env, Date.now(), ctx.places)) this.record(makeEvent('memory', { uid: c.uid, text: f.text, seen: { [f.key]: Date.now() } }));
    }
  }
  /** Light an incense from the bag: one hour of its type turning up more. */
  lightIncense(id) {
    const r = this.record(makeEvent('incense', { item: id }));
    if (r?.ok === false) { toast(r.error ?? 'Couldn’t light it.', 'err'); return; }
    sfx('heal');
    toast(`${activeIncense(this.save)?.name ?? 'The incense'} is lit for an hour.`, 'ok');
    this.refresh();
  }

  // ---------- life in the ball: thoughts and wild encounters ----------
  walkMinutes() { return this.walk.walking && this.settings.walkStartedAt ? Math.floor((Date.now() - this.settings.walkStartedAt) / 60000) : 0; }

  startThinking() {
    clearInterval(this.thinkTimer);
    this.nextThought = Date.now() + 60000 + Math.random() * 90000;
    this.thinkTimer = setInterval(() => {
      if (!this.walk.walking) return;
      if (Date.now() > this.nextThought) this.think();
      // look around again every few minutes while the app is open
      if (this.settings.useLocation && !document.hidden && Date.now() - (this.settings.surroundings?.at ?? 0) > 6 * 60000) this.lookNow({ quiet: true });
    }, 15000);
  }

  addThought(c, text) {
    const list = this.save.thoughts || (this.save.thoughts = []);
    list.push({ uid: c.uid, text, at: Date.now() });
    if (list.length > 30) list.splice(0, list.length - 30);
    this.persist();
    this.emit('thought');
  }

  /** Someone in a ball you carry has a thought (the buddy, mostly). */
  think(now = false) {
    const team = this.team();
    if (!team.length) return;
    const c = Math.random() < 0.7 || team.length === 1 ? (this.buddy() ?? team[0]) : team[1 + Math.floor(Math.random() * (team.length - 1))];
    this.nextThought = Date.now() + 60000 + Math.random() * 90000;
    const pal = friendsOf(c)[0];
    const text = thoughtFor(this.idx, c, { ...this.walkCtx(), seed: Date.now(), friendName: pal && this.save.creatures[pal.uid] ? displayName(this.idx, this.save.creatures[pal.uid]) : null });
    this.addThought(c, text);
    if (!now && document.hidden && this.settings.thoughtAlerts) this.platform.notify(displayName(this.idx, c), text);
  }

  /** Empty balls you carry: registered ones with nobody inside, and the simulated ball when empty. */
  emptyBalls() {
    return this.myBalls().filter(([, c]) => !c.uid).map(([tag, c]) => ({ tag, name: c.name ?? 'Capsule', sim: this.emulated.has(tag) }));
  }

  /** Every so often on a walk an empty ball picks up something nearby. */
  lookAround(force = false) {
    if (this.encounter || !this.emptyBalls().length) return;
    const ctx = { ...this.walkCtx(), seed: Date.now() };
    let enc = rollEncounter(this.idx, ctx);
    for (let i = 1; force && !enc && i < 40; i++) enc = rollEncounter(this.idx, { ...ctx, seed: ctx.seed + i });
    if (!enc) return;
    this.encounter = { ...enc, tries: 0 };
    this.platform.vibrate([40, 60, 40, 60, 40]);
    sfx('alert');
    const name = this.idx.species.get(enc.speciesId)?.name ?? 'Something';
    if (document.hidden) this.platform.notify('Your empty capsule is buzzing', `A wild ${name} is nearby.`);
    const b = this.buddy();
    if (b) this.addThought(b, `${displayName(this.idx, b)} noticed something moving nearby!`);
    if (this.topEl && this.tab !== 'buddy') this.go('buddy');
    this.emit('encounter');
    this.viewEl?.scrollTo?.({ top: 0, behavior: 'smooth' });
  }

  leaveEncounter(text) {
    if (!this.encounter) return;
    const name = this.idx.species.get(this.encounter.speciesId)?.name ?? 'It';
    this.encounter = null;
    toast(text ?? `You let the ${name} go on its way.`);
    this.emit('encounter');
  }

  /** Returns 'caught' | 'fled' | 'missed'. */
  /** Decide a throw before showing it (so the capsule can shake the right number of times). */
  rollThrow(enc, quality) { return tryCatch(enc, quality, Date.now()).caught; }

  async throwAt(enc, quality, decided = null) {
    if (this.encounter !== enc) return 'fled';
    enc.tries = (enc.tries ?? 0) + 1;
    const r = decided == null ? tryCatch(enc, quality, Date.now()) : { caught: decided };
    const name = this.idx.species.get(enc.speciesId)?.name ?? 'It';
    if (!r.caught) {
      if (enc.tries >= 3) { sfx('error'); this.leaveEncounter(`The ${name} got away.`); return 'fled'; }
      return 'missed';
    }
    this.encounter = null;
    const ball = this.emptyBalls()[0];
    const c = caughtCreature(this.idx, enc, { trainer: this.save.trainer.name, location: { kind: 'phone', device: this.settings.deviceId } });
    c.ball = this.save.capsules?.[ball?.tag]?.skin ?? this.settings.catchBall ?? '';
    this.save.creatures[c.uid] = c;
    this.persist();
    sfx('level');
    creatureCry(this.idx.species.get(c.speciesId));
    this.platform.vibrate([60, 40, 120]);
    this.emit('encounter');
    if (ball?.sim) {
      // the simulated ball seals it straight away, like a real ball would on the spot
      this.arm({ kind: 'send', uid: c.uid, mode: 'walk' });
      await this.onCapsule(this.emulated.asTag(ball.tag), { stay: true });
      toast(`Gotcha! ${name} is safe inside your capsule. It goes to your PC on the next sync.`, 'ok');
    } else if (ball) {
      this.arm({ kind: 'send', uid: c.uid, mode: 'walk' });
      toast(`Gotcha! Hold ${ball.name} to your phone to seal ${name} inside.`, 'ok');
    } else {
      toast(`Gotcha! ${name} is on your phone link until you sync with the PC.`, 'ok');
    }
    this.refresh();
    return 'caught';
  }

  // ---------- capsules ----------
  startNfc() {
    this.platform.onTag((tag, err) => {
      if (err) { toast(err, 'err'); return; }
      this.onCapsule(tag);
    });
    this.platform.startNfc().catch(() => {});
  }

  /** A capsule touched the phone: do whatever is armed (default: read and sync). */
  async onCapsule(tag, { stay = false, arm: armOverride = null } = {}) {
    sfx('dock');
    this.platform.vibrate([30]);
    if (!stay && this.tab !== 'capsule' && this.topEl) this.go('capsule');
    const arm = armOverride ?? this.capsuleArm;
    this.capsuleArm = null;
    const before = clone(this.save);
    const work = clone(this.save);
    let message = null;
    try {
      const info = await readCapsule(this.idx, tag);
      if (arm?.kind === 'send') {
        const c = await sendToCapsule(this.idx, work, tag, info, arm.uid, { mode: arm.mode ?? 'walk' });
        if (this.settings.buddyUid === c.uid) { /* still the buddy, now counted by the capsule */ }
        message = `${displayName(this.idx, c)} is in the capsule.`;
      } else if (arm?.kind === 'release') {
        const c = await releaseFromCapsule(this.idx, work, tag, info, { kind: 'phone', device: this.settings.deviceId });
        if (c) message = `${displayName(this.idx, c)} came out onto your phone.`;
      } else if (arm?.kind === 'mode') {
        await setCapsuleMode(this.idx, work, tag, info, arm.mode);
        message = `Capsule set to ${arm.mode} mode.`;
      } else if (arm?.kind === 'format') {
        await writeCapsule(this.idx, tag, null, null, { mode: 'desk', full: true });
        message = 'Capsule formatted.';
      } else if (info.state === 'creature' && info.known) {
        const res = await syncCapsule(this.idx, work, tag, info);
        const name = displayName(this.idx, res.creature);
        message = res.walk?.steps ? `${name} walked ${res.walk.steps.toLocaleString('en-US')} steps. Friendship +${res.walk.friendship}.` : `${name} is up to date.`;
        if (res.isNew) message = `${name} joined you from the capsule.`;
      }
      // this ball is now synced with this phone (its tab lists it until the PC docks or unsyncs it)
      if (work.capsules[tag.uid]) { work.capsules[tag.uid].holder = tag.onPc ? 'pc' : this.settings.deviceId; work.capsules[tag.uid].heldAt = Date.now(); }
      this.adopt(before, work);
      this.lastTag = { uid: tag.uid, info: await readCapsule(this.idx, tag).catch(() => info), at: Date.now() };
      if (message) toast(message, 'ok');
    } catch (e) {
      console.error(e);
      this.lastTag = { uid: tag.uid, error: e.message, at: Date.now() };
      toast(/lost|IO|timed/i.test(e.message) ? 'Hold the capsule still against the back of the phone and try again.' : e.message, 'err');
    }
    this.emit('capsule');
    this.refresh();
  }

  arm(action) {
    this.capsuleArm = action;
    this.emit('capsule');
  }

  // ---------- bumps from capsules (Bluetooth beacons) ----------
  startBeacons() {
    this.platform.onBeacon((b) => this.onBeacon(b));
    this.watchCapsules();
    if (this.settings.watchBumps) this.platform.startBeacons().catch(() => {});
  }

  myCapsuleIds() { return Object.keys(this.save.capsules).map((t) => t.slice(-8).toUpperCase()); }
  watchCapsules() { this.platform.setCapsuleWatch?.(this.myCapsuleIds()); }

  /** Capsule beacons: one of mine bumping together with a friend's capsule starts a Showdown battle. */
  onBeacon(b) {
    const uid4 = String(b.uid4).toUpperCase();
    const now = Date.now();
    this.beacons = this.beacons || {};
    const prev = this.beacons[uid4];
    this.beacons[uid4] = { bumps: b.bumps, at: now };
    const tag = Object.keys(this.save.capsules).find((t) => t.toUpperCase().endsWith(uid4));
    if (tag) this.save.capsules[tag].battery = b.battery >= 0 ? b.battery : this.save.capsules[tag].battery;
    if (!prev || !(b.bumps > prev.bumps)) return;
    if (tag) {
      this.myBumpAt = now;
      clearTimeout(this.bumpTimer);
      // give the other capsule's beacon a moment to arrive
      this.bumpTimer = setTimeout(() => this.resolveBump(this.save.capsules[tag]), 1500);
    } else {
      this.otherBump = { uid4, at: now };
    }
  }

  resolveBump(cap) {
    const at = this.myBumpAt;
    const other = this.otherBump && Math.abs(this.otherBump.at - at) < 4000 ? this.otherBump : null;
    this.otherBump = null;
    const friend = other && Object.values(this.save.friends ?? {}).find((f) => (f.capsules ?? []).includes(other.uid4));
    this.platform.vibrate([80, 40, 80]);
    if (friend) { this.startFriendBattle(friend); return; }
    if (document.hidden) this.platform.notify('Capsule bump!', `${cap.name} bumped another capsule. Open Capsule Link to battle.`);
    if (!this.topEl) return;
    if (this.tab !== 'battle') this.go('battle');
    this.view?.autoBump?.(at);
  }

  /** The simulated capsule was knocked (Debug screen): same path as a real capsule's bump. */
  simulatedBump(uid) {
    const r = this.emulated.bump(uid);
    if (!r.ok) { toast(r.reason, 'err'); return; }
    this.myBumpAt = Date.now();
    this.resolveBump(this.save.capsules[uid] ?? { name: 'Ball' });
  }

  /** Balls synced with this phone right now (the PC hasn't docked or unsynced them since). */
  myBalls() { return Object.entries(this.save.capsules ?? {}).filter(([, c]) => c.holder === this.settings.deviceId); }

  /** Keep an eye on the PC's dock while the app is open; say so when a ball is lifted off. */
  startDockWatch() {
    const look = async () => {
      if (!this.settings?.hubUrl || document.hidden || this.dockLooking) return;
      this.dockLooking = true;
      const c = this.client();
      try {
        await c.connect();
        const r = await c.request(MSG.DOCK_GET, {}, MSG.DOCK, 8000);
        const prev = this.pcDock;
        this.pcDock = r.dock ?? null;
        if (prev?.uid && (!this.pcDock || this.pcDock.uid !== prev.uid)) {
          const what = prev.name ? `${prev.name}’s ball` : prev.capsule ?? 'A ball';
          toast(`${what} was taken off your PC’s dock.`);
          this.platform.notify('Off the dock', `${what} was taken off your PC’s dock.`);
        }
        if (JSON.stringify(prev) !== JSON.stringify(this.pcDock)) this.emit('capsule');
      } catch { /* PC asleep or out of reach */ } finally { c.close(); this.dockLooking = false; }
    };
    setInterval(look, 45000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) look(); });
  }

  // ---------- Showdown ----------
  sdCtx() {
    return {
      idx: this.idx, bank: this.bank, getSave: () => this.save,
      record: (ev) => this.record(ev),
      update: (fn) => this.local(fn),
      team: () => this.team(),
      fetchText: this.platform.fetchText,
    };
  }

  /** Open Showdown with your team. config: { action: 'challenge'|'accept', opponent, format } */
  async openShowdown(config = {}) {
    const s = showdownSettings(this.save);
    const team = prepareTeam(this.sdCtx());
    if (!team.sets.length) { toast('Take creatures along first (Party tab).', 'err'); return false; }
    if (!this.platform.canEmbedShowdown) return false;
    await this.platform.openShowdown(s.server, bridgeScript({ ...config, packed: team.packed, format: config.format || s.format }));
    return true;
  }

  rememberFriend(o) {
    if (!o?.showdown) return;
    this.local((save) => {
      save.friends = save.friends || {};
      const id = toId(o.showdown);
      const cur = save.friends[id] || {};
      save.friends[id] = { name: o.name || cur.name || o.showdown, showdown: o.showdown, capsules: [...new Set([...(cur.capsules ?? []), ...(o.capsules ?? [])])], at: Date.now() };
    });
  }

  /** Battle a friend without any server: the smaller Showdown id sends the challenge. */
  startFriendBattle(friend) {
    const me = toId(showdownSettings(this.save).name);
    if (!me) { toast('Set your Showdown name on the Battle tab first.', 'err'); this.go('battle'); return; }
    const role = me < toId(friend.showdown) ? 'challenge' : 'accept';
    if (document.hidden) this.platform.notify('Battle found', `Battle ${friend.name} on Showdown. Tap to open.`);
    toast(role === 'challenge' ? `Challenging ${friend.name} on Showdown…` : `Waiting for ${friend.name}'s challenge on Showdown…`, 'ok');
    this.openShowdown({ action: role, opponent: friend.showdown });
  }

  startShowdownWatch() {
    const drain = async () => {
      const evs = await this.platform.takeShowdownEvents().catch(() => []);
      for (const e of evs) await this.onShowdown(e);
    };
    this.platform.onShowdown(() => drain());
    document.addEventListener('visibilitychange', () => { if (!document.hidden) drain(); });
    drain();
  }

  async onShowdown(msg) {
    if (msg.type === 'user' && msg.named && msg.name && showdownSettings(this.save).name !== msg.name) {
      this.local((s) => { s.settings.showdown = { ...(s.settings.showdown || {}), name: msg.name }; });
    } else if (msg.type === 'battle') {
      try {
        const el = await ingestBattle(this.sdCtx(), msg.log, { id: msg.room, user: msg.user });
        if (!el) return;
        this.lastResult = el;
        if (this.topEl && this.tab !== 'battle') this.go('battle');
        this.emit('battle-result');
      } catch (e) { toast(`That Showdown battle was not counted: ${e.message}`, 'err'); }
    }
  }

  battleUrl() { return this.settings.battleUrl || this.settings.hubUrl || ''; }
}


export const app = new PhoneApp();
window.addEventListener('DOMContentLoaded', () => {
  app.boot().catch((e) => { console.error(e); throw e; }); // the start-up screen (index.html) shows it
});
export { createCreature, speciesOf, partyOf };
