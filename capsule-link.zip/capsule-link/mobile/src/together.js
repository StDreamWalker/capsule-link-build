// Together (phone): spend time with the creatures you have with you. Quality time (wash, brush, feed by
// hand, play, their journal) and activities (cooking, gardening, fishing, scavenging, an obstacle course,
// puzzles, photography), in the same 2.5D world as the PC's R.A.N.C.H. Everything you do here is recorded
// as events, so the PC gets the same results at the next sync.
import { h, mount, toast, chooseDialog } from '../../shared/ui/dom.js';
import { spriteCanvas } from '../../shared/ui/art.js';
import { sfx } from '../../shared/ui/audio.js';
import { openCareRoom } from '../../shared/ui/careRoom.js';
import { runActivity } from '../../shared/ui/activityGames.js';
import { DRILLS, drillPlan } from '../../shared/ui/trainingGames.js';
import { pickCooking } from '../../shared/ui/cookPicker.js';
import {
  displayName, mood, makeEvent, ACTIVITIES, aptitude, canDo, allFoods, dishFor, itemInfo, speciesOf, tickNeeds, isAsleep, sleepLeft, foodBlurb,
} from '../../shared/engine/index.js';

export function togetherView(app) {
  const el = h('div', { class: 'm-view together' });
  let pick = togetherView.pick ?? null;
  let session = null, overlay = null;
  const resolveTexture = (p) => app.textures?.files?.[p.toLowerCase()] ?? null;
  const env = { idx: app.idx, bank: app.bank, get save() { return app.save; } };

  function render() {
    const team = app.team().filter((c) => !c.egg);
    if (!team.some((c) => c.uid === pick)) pick = team[0]?.uid ?? null;
    const c = pick && app.save.creatures[pick];
    if (c) tickNeeds(app.idx, c);
    mount(el,
      h('h2', null, 'Together'),
      team.length ? h('div', { class: 'tg-team' }, team.map((x) => h('button', { class: `tg-pal ${x.uid === pick ? 'on' : ''}`, onclick: () => { pick = togetherView.pick = x.uid; sfx('move'); render(); } },
        spriteCanvas(app.bank, x, { scale: 2, animate: x.uid === pick }), h('span', null, displayName(app.idx, x)))))
        : h('p', { class: 'dim' }, 'Nobody is with you right now. Take someone along from the PC, or tap a capsule.'),
      c ? [
        h('div', { class: 'card tg-card' },
          h('div', { class: 'row' }, h('strong', { class: 'grow' }, displayName(app.idx, c)), h('span', { class: 'dim micro' }, `${isAsleep(c) ? `asleep (${sleepLeft(c)} min)` : mood(c).label} · energy ${Math.round(c.needs?.energy ?? 0)} · full ${Math.round(c.needs?.fullness ?? 0)}`)),
          h('div', { class: 'btn-group' },
            h('div', { class: 'btn-group-head' }, 'Look after'),
            h('button', { class: 'btn small', disabled: isAsleep(c), onclick: () => feed(c) }, 'Feed'),
            isAsleep(c) ? h('button', { class: 'btn small', onclick: () => careDo(c, 'wake') }, 'Wake up')
              : h('button', { class: 'btn small', title: 'Energy comes back bit by bit, empty to full in about 90 minutes', onclick: () => careDo(c, 'rest') }, 'Nap')),
          h('button', { class: 'btn primary wide', disabled: isAsleep(c), onclick: () => quality(c) }, 'Quality time'),
          h('p', { class: 'micro dim' }, 'Wash, brush, feed by hand, play, and read their journal. Food comes from the satchel you packed at the PC (kibble is always there).')),
        h('h3', null, 'Activities'),
        h('div', { class: 'tg-acts' }, ACTIVITIES.map((a) => {
          const apt = aptitude(app.idx, c, a.id), ok = canDo(app.idx, app.save, c, a.id);
          return h('button', { class: 'tg-act', disabled: !ok.ok, onclick: () => start(c, a.id) },
            h('span', { class: 'row' }, h('strong', { class: 'grow' }, a.name), h('span', { class: 'tg-stars' }, '★'.repeat(1 + Math.round(apt.score * 4)))),
            h('span', { class: 'micro dim' }, ok.ok ? (apt.perks[0] ?? a.desc.split('.')[0]) : ok.reason));
        })),
      ] : null);
  }

  function careDo(c, action, item) {
    const r = app.record(makeEvent('care', { uid: c.uid, action, item }));
    const out = r.outcome ?? {};
    if (r.ok === false || out.ok === false) { toast(out.reason ?? r.error ?? 'They don’t want to right now.', 'err'); render(); return; }
    const nm = displayName(app.idx, c);
    if (action === 'rest' && out.reaction === 'awake') { toast(`${nm}: ${out.reason ?? 'not sleepy right now.'}`, 'err'); render(); return; }
    if (action === 'rest') { sfx('heal'); toast(`${nm} curled up for a nap.`, 'ok'); }
    else if (action === 'wake') { sfx('back'); toast(out.reaction === 'grumpy' ? `${nm} woke up, a bit grumpy.` : `${nm} woke up and stretched.`, out.reaction === 'grumpy' ? 'err' : 'ok'); }
    else if (action === 'feed') { sfx('munch'); toast(out.reaction === 'full' ? `${nm} is full.` : out.reaction === 'delighted' ? `${nm} loved that!` : `${nm} munched it up.`, 'ok'); }
    render();
  }
  async function feed(c) {
    const foods = allFoods(app.idx).filter((it) => it.unlimited || (app.save.inventory[it.id] ?? 0) > 0);
    const pick = await chooseDialog(`Feed ${displayName(app.idx, c)}`, foods.map((it) => ({ value: it.id, label: `${it.name}${it.unlimited ? '' : ` × ${app.save.inventory[it.id]}`}`, detail: foodBlurb(it) || it.desc || '' })), { empty: 'No food packed. Pack some in the satchel at the PC (Phone link).' });
    if (pick) careDo(c, 'feed', pick);
  }
  async function quality(c) {
    sfx('access');
    await openCareRoom(env, c.uid, {
      biome: speciesOf(app.idx, c)?.habitat ?? 'meadow', seed: 5, resolveTexture,
      doCare: (action, opts = {}) => {
        const { item, ...rest } = opts;
        const r = app.record(makeEvent('care', { uid: c.uid, action, item, opts: rest }));
        if (r.ok === false && r.error) toast(r.error, 'err');
        return r.outcome ?? { ok: r.ok !== false, reason: r.error };
      },
    });
    render();
  }

  async function start(c, actId) {
    const extra = {};
    if (actId === 'cooking') {
      const got = await pickCooking(app.idx, app.save, c);
      if (!got) return;
      Object.assign(extra, got);
    }
    if (actId === 'training') {
      const drill = await chooseDialog('Which drill?', DRILLS.map((d) => { const pl = drillPlan(app.idx, c, d.id); return { value: d.id, label: `${pl.fits ? '★ ' : ''}${d.name}`, detail: `${pl.line} ${d.desc}` }; }));
      if (!drill) return;
      extra.drill = drill;
    }
    const apt = aptitude(app.idx, c, actId).score;
    const holder = h('div', { class: 'act-holder' });
    overlay = h('div', { class: 'tg-stage' },
      h('div', { class: 'row' }, h('strong', { class: 'grow' }, `${ACTIVITIES.find((x) => x.id === actId).name} with ${displayName(app.idx, c)}`), h('button', { class: 'btn small', onclick: () => stop(null) }, 'Stop')),
      holder);
    document.body.append(overlay);
    sfx('access');
    session = runActivity(holder, { bank: app.bank, idx: app.idx, c, actId, apt, resolveTexture, extra: { ...extra, dish: extra.dish ?? (extra.ingredients ? dishFor(app.idx, c, extra.ingredients) : null) }, onDone: (perf, info) => stop(perf, info) });
    function stop(perf, info = {}) {
      session?.stop(); session = null;
      if (perf == null) { overlay?.remove(); overlay = null; render(); return; }
      // recorded as an event: the PC gets the same result at the next sync
      const r = app.record(makeEvent('activity', { uid: c.uid, act: actId, perf: Math.round(perf * 1000) / 1000, extra: { ingredients: extra.ingredients ?? [], recipe: extra.recipe, moves: info.moves ?? undefined, drill: extra.drill }, replay: true }));
      const out = r.outcome ?? {};
      sfx((out.stars ?? 0) >= 2 ? 'level' : 'heal');
      mount(overlay, h('div', { class: 'card tg-results' },
        out.stars == null ? null : h('div', { class: 'act-stars big' }, '★'.repeat(out.stars ?? 0), h('span', { class: 'dim' }, '★'.repeat(3 - (out.stars ?? 0)))),
        spriteCanvas(app.bank, c, { scale: 3, animate: true }),
        h('p', null, out.text ?? (r.error || '')),
        out.coins ? h('p', null, `+${out.coins} coins`) : null,
        out.items?.length ? h('p', null, `Got: ${out.items.map((id) => itemInfo(app.idx, id)?.name ?? id).join(', ')}`) : null,
        info.photo ? [h('img', { class: 'act-photo', src: info.photo, alt: 'Your photo' }), h('a', { class: 'btn small', href: info.photo, download: `${displayName(app.idx, c)}-photo.png` }, 'Save the photo')] : null,
        h('button', { class: 'btn primary wide', onclick: () => { overlay.remove(); overlay = null; render(); } }, 'Done')));
    }
  }

  render();
  return { el, update: () => { if (!session) render(); }, dispose() { session?.stop(); session = null; overlay?.remove(); overlay = null; } };
}
