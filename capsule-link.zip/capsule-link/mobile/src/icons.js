// Line icons for the phone's navigation (24×24, Material-style outlines).
const PATHS = {
  buddy: 'M12 20.5s-7.5-4.4-7.5-10A4.3 4.3 0 0 1 12 7.6a4.3 4.3 0 0 1 7.5 2.9c0 5.6-7.5 10-7.5 10z',
  party: 'M4 5.5A1.5 1.5 0 0 1 5.5 4h4A1.5 1.5 0 0 1 11 5.5v4A1.5 1.5 0 0 1 9.5 11h-4A1.5 1.5 0 0 1 4 9.5zM13 5.5A1.5 1.5 0 0 1 14.5 4h4A1.5 1.5 0 0 1 20 5.5v4a1.5 1.5 0 0 1-1.5 1.5h-4A1.5 1.5 0 0 1 13 9.5zM4 14.5A1.5 1.5 0 0 1 5.5 13h4a1.5 1.5 0 0 1 1.5 1.5v4A1.5 1.5 0 0 1 9.5 20h-4A1.5 1.5 0 0 1 4 18.5zM13 14.5a1.5 1.5 0 0 1 1.5-1.5h4a1.5 1.5 0 0 1 1.5 1.5v4a1.5 1.5 0 0 1-1.5 1.5h-4a1.5 1.5 0 0 1-1.5-1.5z',
  capsule: 'M12 3a5.5 5.5 0 0 1 5.5 5.5v7a5.5 5.5 0 0 1-11 0v-7A5.5 5.5 0 0 1 12 3zM6.5 11.5h11M12 14.5v.01',
  battle: 'M5 4l7.5 7.5M19 4l-7.5 7.5M3.5 14.5l6 6M14.5 20.5l6-6M7 17l-3 3M17 17l3 3',
  link: 'M10 14a4 4 0 0 0 5.66 0l3-3a4 4 0 0 0-5.66-5.66l-1 1M14 10a4 4 0 0 0-5.66 0l-3 3a4 4 0 0 0 5.66 5.66l1-1',
  steps: 'M8 3.5c1.7 0 2.5 1.8 2.5 4s-1 3.5-2.5 3.5S5.5 9.7 5.5 7.5 6.3 3.5 8 3.5zM6 13.5h4l-.5 3a2 2 0 0 1-3 0zM16 8.5c1.7 0 2.5 1.8 2.5 4s-1 3.5-2.5 3.5-2.5-1.3-2.5-3.5.8-4 2.5-4zM14 18.5h4l-.5 1.5a2 2 0 0 1-3 0z',
};

export function icon(name, size = 22) {
  const span = document.createElement('span');
  span.className = 'pix-icon';
  span.setAttribute('aria-hidden', 'true');
  span.innerHTML = `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="${PATHS[name] ?? PATHS.buddy}"/></svg>`;
  return span;
}
