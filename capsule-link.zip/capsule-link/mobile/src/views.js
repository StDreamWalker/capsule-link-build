import { chooseBall } from '../../shared/ui/ballPicker.js';
import { readBackup } from '../../shared/engine/backup.js';
// Phone screens: welcome, buddy (walking), party, capsule (NFC), battle, link.
import { brandText } from '../../shared/ui/dom.js';
import { logoMark } from '../../shared/ui/icons.js';
import { h, mount, toast, dialog, chooseDialog, confirmDialog, promptDialog, hearts, typeChip, fmtNum, timeAgo, hpBar } from '../../shared/ui/dom.js';
import { spriteCanvas } from '../../shared/ui/art.js';
import { capsuleCanvas } from '../../shared/ui/capsuleArt.js';
import { creatureSummary, formPicker } from '../../shared/ui/summary.js';
import { teamPanel, resultPanel, historyPanel, showdownSettingsPanel, showdownSettings } from '../../shared/ui/showdownUi.js';
import { sfx, playCry, setSound, creatureCry } from '../../shared/ui/audio.js';
import {
  displayName, speciesOf, friendshipTier, mood, createCreature, makeEvent, cryFor, calcStats, CAPSULE, MSG, tickNeeds, toId, wallet, itemInfo,
} from '../../shared/engine/index.js';
import { icon } from './icons.js';
import { transferLine } from '../../shared/ui/transfer.js';
import { idCardEl, partyForCard } from '../../shared/ui/idcard.js';
import { cardEditor } from '../../shared/ui/idcardEditor.js';

const MODE_HELP = {
  desk: 'Sits on a desk and wiggles now and then.',
  walk: 'Counts your steps together.',
  battle: 'Tap it against a friend’s capsule to battle.',
  sleep: 'Quiet and saving battery.',
};

// ---------------- welcome ----------------
export function welcomeView(app, done) {
  let step = 'intro1';
  const el = h('div', { class: 'm-welcome' });
  const starters = app.idx.ds.species.filter((s) => s.evolutions?.length).slice(0, 3);
  const dots = (k) => h('div', { class: 'w-dots' }, [0, 1, 2].map((j) => h('i', { class: j === k ? 'on' : '' })));
  function render() {
    if (step === 'intro1') {
      mount(el,
        h('div', { class: 'welcome-hero' }, capsuleCanvas({ ring: '#34d1bf', creature: starters[0]?.id, bank: app.bank }, 6)),
        h('h1', null, 'They travel with you'),
        h('p', null, 'Creatures live on your PC. When you head out, they ride along inside a capsule — this phone is how you check on them.'),
        h('p', { class: 'dim' }, 'Nobody leaves their capsule away from the PC. Here you can see how they are doing, hear what they are thinking on walks, and give the capsule a gentle tap.'),
        dots(0),
        h('button', { class: 'btn primary wide', onclick: () => { step = 'intro2'; render(); } }, 'Next'),
        h('button', { class: 'btn wide', onclick: () => { step = 'hello'; render(); } }, 'Skip'));
    } else if (step === 'intro2') {
      mount(el,
        h('div', { class: 'welcome-hero row-hero' }, icon('link', 48), capsuleCanvas({ ring: '#ffc93c' }, 5)),
        h('h1', null, 'Connecting'),
        h('p', null, 'Your PC: open Phone Link there and enter its address and six-digit code on the next screen. Same Wi-Fi, or a USB-C cable.'),
        h('p', null, 'Your capsule: hold it against the back of this phone. It syncs steps and shows who is inside. Empty capsules can pick up wild creatures on walks.'),
        dots(1),
        h('button', { class: 'btn primary wide', onclick: () => { step = 'hello'; render(); } }, 'Next'),
        h('button', { class: 'btn wide', onclick: () => { step = 'intro1'; render(); } }, 'Back'));
    } else if (step === 'hello') {
      mount(el,
        h('div', { class: 'welcome-hero' }, capsuleCanvas({ ring: '#34d1bf', creature: starters[0]?.id, bank: app.bank }, 6)),
        h('h1', null, 'Capsule Link'),
        h('p', null, 'Walk with your creatures, sync capsules with a tap, and battle friends.'),
        dots(2),
        h('label', { class: 'field' }, h('span', null, 'Your name'), h('input', { type: 'text', maxLength: 10, value: app.save.trainer.name === 'Trainer' ? '' : app.save.trainer.name, placeholder: 'Trainer', oninput: (e) => { app.save.trainer.name = e.target.value.trim() || 'Trainer'; } })),
        h('button', { class: 'btn primary wide', onclick: () => { step = 'link'; render(); } }, 'Link to my PC'),
        h('button', { class: 'btn wide', onclick: () => { step = 'starter'; render(); } }, 'Start without a PC'));
    } else if (step === 'link') {
      mount(el, h('h1', null, 'Link to your PC'), linkForm(app, async () => { done(); }), h('button', { class: 'btn wide', onclick: () => { step = 'hello'; render(); } }, 'Back'));
    } else {
      mount(el,
        h('h1', null, 'Pick a buddy'),
        h('p', { class: 'dim' }, 'You can link your PC later; this creature comes along.'),
        h('div', { class: 'starter-row' }, starters.map((s) => h('button', { class: 'starter', onclick: () => {
          const c = createCreature(app.idx, s.id, { level: 5, trainer: app.save.trainer.name, metHow: 'Chosen as a first buddy', location: { kind: 'phone', device: app.settings.deviceId } });
          app.save.creatures[c.uid] = c;
          app.settings.buddyUid = c.uid;
          app.persist();
          creatureCry(s);
          done();
        } }, spriteCanvas(app.bank, s.id, { scale: 3, animate: true }), h('span', null, s.name), h('span', { class: 'row' }, s.types.map((t) => typeChip(app.idx, t)))))),
        h('button', { class: 'btn wide', onclick: () => { step = 'hello'; render(); } }, 'Back'));
    }
  }
  render();
  return el;
}

/** Address + pairing code form, with LAN discovery on Android. */
function linkForm(app, onDone) {
  let url = app.settings.hubUrl || '';
  let code = '';
  const found = h('div', { class: 'col' });
  const urlInput = h('input', { type: 'url', value: url, placeholder: 'ws://192.168.1.20:47820', oninput: (e) => { url = e.target.value.trim(); } });
  const discover = async () => {
    mount(found, h('p', { class: 'dim' }, 'Looking for your PC on this network…'));
    const list = await app.platform.discover(4000);
    if (!list.length) { mount(found, h('p', { class: 'dim' }, app.native ? 'No PC answered. Check that Capsule Link is open on the PC and both are on the same Wi-Fi, or type the address shown on the PC’s Phone link screen.' : 'Discovery works in the Android app. Type the address shown on the PC’s Phone link screen.')); return; }
    mount(found, list.map((p) => h('button', { class: 'btn wide', onclick: () => { url = `ws://${p.address}:${p.port}`; urlInput.value = url; } }, `${p.name}  ${p.address}`)));
  };
  return h('div', { class: 'col' },
    h('p', { class: 'dim' }, 'Open Phone link on the PC to see its address and a six-digit pairing code.'),
    h('div', { class: 'row' },
      h('button', { class: 'btn grow', onclick: discover }, 'Find my PC'),
      h('button', { class: 'btn grow', onclick: () => { url = 'ws://127.0.0.1:47820'; urlInput.value = url; toast('USB cable: on the PC open Phone link → USB cable → Set up USB link first.'); } }, 'Use USB cable')),
    found,
    h('label', { class: 'field' }, h('span', null, 'PC address'), urlInput),
    h('label', { class: 'field' }, h('span', null, 'Pairing code'), h('input', { type: 'text', inputMode: 'numeric', maxLength: 6, placeholder: '123456', oninput: (e) => { code = e.target.value.trim(); } })),
    h('button', { class: 'btn primary wide', onclick: async (e) => {
      if (!/^wss?:\/\//.test(url)) url = `ws://${url.replace(/^\/+/, '')}`;
      if (!/:\d+$/.test(url.replace(/\/$/, ''))) url = `${url.replace(/\/$/, '')}:47820`;
      e.target.disabled = true;
      try { await app.connectPc(url, code); toast('Linked to your PC.', 'ok'); onDone?.(); }
      catch (err) { toast(err.code === 'pair' ? 'That pairing code did not match. Check the code on the PC.' : err.message, 'err'); }
      e.target.disabled = false;
    } }, 'Link'));
}

// ---------------- party ----------------
export function partyView(app) {
  const el = h('div', { class: 'm-party' });
  function card(c) {
    const st = calcStats(app.idx, c);
    const where = c.location?.kind === 'capsule' ? (app.save.capsules[c.location.tag]?.name ?? 'In a capsule') : 'Phone link';
    const isBuddy = app.settings.buddyUid === c.uid;
    return h('button', { class: `m-card ${isBuddy ? 'sel' : ''}`, onclick: () => open(c) },
      spriteCanvas(app.bank, c, { scale: 2 }),
      h('div', { class: 'grow' },
        h('div', { class: 'row' }, h('span', { class: 'grow ell' }, displayName(app.idx, c)), h('span', { class: 'dim' }, `Lv${c.level}`)),
        hpBar(c.hp ?? st.hp, st.hp),
        h('div', { class: 'row' }, hearts(friendshipTier(c.friendship).hearts), h('span', { class: 'spacer' }), h('span', { class: 'micro dim' }, isBuddy ? 'Buddy' : where))));
  }
  async function open(c) {
    const inCapsule = c.location?.kind === 'capsule';
    await dialog(displayName(app.idx, c), (close) => h('div', { class: 'col' },
      creatureSummary(app.idx, app.bank, c, { compact: true, sections: ['stats', 'moves', 'care', 'walk', 'likes', 'memories'] }),
      h('div', { class: 'col' },
        formPicker(app.idx, c, (form) => { app.record(makeEvent('form', { uid: c.uid, form })); toast(`${displayName(app.idx, c)} changed form.`, 'ok'); }),
        h('button', { class: 'btn primary', disabled: app.settings.buddyUid === c.uid, onclick: () => { app.local((s) => { s.settings.buddyUid = c.uid; }); close(); toast(`Watching ${displayName(app.idx, c)} on the monitor.`, 'ok'); app.go('buddy'); } }, 'Watch on the monitor'),
        !inCapsule ? h('button', { class: 'btn', onclick: () => { app.arm({ kind: 'send', uid: c.uid, mode: 'walk' }); close(); app.go('capsule'); } }, 'Put in a capsule') : null,
        h('button', { class: 'btn', onclick: async () => {
          const name = await promptDialog('Nickname', 'Leave empty to use the species name', c.nickname, { maxLength: 12 });
          if (name != null) app.record(makeEvent('rename', { uid: c.uid, nickname: name.trim() }));
          close();
        } }, 'Rename'),
        !inCapsule && app.settings.hubUrl ? h('button', { class: 'btn', onclick: async () => {
          close();
          try { await app.giveBack([c.uid]); toast(`${displayName(app.idx, c)} streamed back to your PC.`, 'ok'); sfx('transfer'); } catch (e) { toast(e.message, 'err'); }
        } }, 'Send back to PC') : null,
        h('button', { class: 'btn', onclick: () => close() }, 'Close'))));
  }
  async function takeFromPc() {
    if (!app.settings.hubUrl) { toast('Link to your PC first (Link tab).', 'err'); return; }
    try { await app.sync({ quiet: true }); } catch (e) { toast(e.message, 'err'); return; }
    const options = app.pcList.filter((x) => ['box', 'party', 'ranch'].includes(x.location?.kind));
    const uid = await chooseDialog('Bring from the PC', options.map((x) => ({
      value: x.uid, label: x.nickname || app.idx.species.get(x.speciesId)?.name || x.speciesId, detail: `Lv. ${x.level} · ${x.location.kind}`,
      el: spriteCanvas(app.bank, x, { scale: 1 }),
    })), { empty: 'Nobody is waiting at the PC.' });
    if (!uid) return;
    try { await app.take([uid]); { const nm = app.save.creatures[uid] ? displayName(app.idx, app.save.creatures[uid]) : 'They'; toast(transferLine('phone', nm), 'ok'); sfx('materialize'); } if (!app.settings.buddyUid) app.local((s) => { s.settings.buddyUid = uid; }); } catch (e) { toast(e.message, 'err'); }
  }
  function render() {
    const list = app.creatures().filter((c) => app.idx.species.has(c.speciesId));
    mount(el,
      h('div', { class: 'row' }, h('h1', { class: 'grow' }, 'With you'), h('button', { class: 'btn small', onclick: takeFromPc }, 'Bring from PC')),
      h('p', { class: 'micro dim' }, 'Everyone here rides in a capsule. Your phone only reads their data — they come out at your PC.'),
      list.length ? h('div', { class: 'col' }, list.map(card)) : h('p', { class: 'dim' }, 'Nobody yet. Take creatures from your PC, or tap a capsule.'),
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, app.save.satchel ? 'Satchel' : 'Bag'), h('span', { class: 'dim mono-num' }, `${wallet(app.save)} coins`)),
      app.save.satchel ? h('p', { class: 'micro dim' }, 'What you packed at the PC (Phone link → Satchel for walks). Feed and heal from it in Together; kibble always comes along. Finds on walks go home to the PC’s bag.') : null,
      Object.entries(app.save.inventory).filter(([, n]) => n > 0).length
        ? h('div', { class: 'kv' }, Object.entries(app.save.inventory).filter(([, n]) => n > 0).map(([id, n]) => [h('span', null, itemInfo(app.idx, id)?.name ?? id), h('span', null, `×${n}`)]))
        : h('p', { class: 'dim' }, app.save.satchel ? 'Nothing packed. Pack food, Potions or incense at the PC before a walk.' : 'Empty. Walking turns things up.'));
  }
  render();
  return { el, update: render };
}

// ---------------- capsule ----------------
export function capsuleView(app) {
  const el = h('div', { class: 'm-capsule' });
  const off = app.on((w) => { if (w === 'capsule') render(); });
  function armText(arm) {
    if (!arm) return 'Hold a capsule against the back of your phone to sync it.';
    if (arm.kind === 'send') return `Tap a capsule to put ${displayName(app.idx, app.save.creatures[arm.uid])} inside.`;
    if (arm.kind === 'release') return 'Tap the capsule to bring its creature onto your phone.';
    if (arm.kind === 'mode') return `Tap the capsule to switch it to ${arm.mode} mode.`;
    if (arm.kind === 'format') return 'Tap the tag to format it as an empty capsule.';
    return '';
  }
  function lastPanel() {
    const t = app.lastTag;
    if (!t || Date.now() - t.at > 10 * 60 * 1000) return null;
    if (t.error) return h('section', { class: 'panel' }, h('p', { class: 'err-text' }, t.error));
    const info = t.info;
    const cap = app.save.capsules[t.uid] ?? { name: 'Capsule' };
    if (!info) return null;
    if (info.state === 'creature') {
      const c = app.save.creatures[info.rec.uid];
      return h('section', { class: 'panel col' },
        h('div', { class: 'row' }, capsuleCanvas({ skin: c?.ball ?? cap.skin, ring: app.idx.types.get(speciesOf(app.idx, c ?? { speciesId: '' })?.types?.[0])?.color, creature: c?.speciesId, bank: app.bank }, 3),
          h('div', { class: 'grow' }, h('h2', null, c ? displayName(app.idx, c) : info.rec.nickname || `#${info.rec.speciesNo}`), h('div', { class: 'dim' }, `${cap.name} · ${info.rec.mode} mode`),
            h('div', { class: 'dim' }, `${fmtNum(info.rec.totalSteps)} steps together`))),
        h('div', { class: 'row wrap' }, CAPSULE.MODES.map((m) => h('button', { class: `btn small ${m === info.rec.mode ? 'primary' : ''}`, onclick: () => app.arm({ kind: 'mode', mode: m }) }, m[0].toUpperCase() + m.slice(1)))),
        h('p', { class: 'dim' }, MODE_HELP[info.rec.mode] ?? ''),
        h('p', { class: 'micro dim' }, 'Creatures stay in their capsule until they reach your PC.'));
    }
    return h('section', { class: 'panel col' },
      h('h2', null, info.state === 'empty' ? `${cap.name} is empty` : info.state === 'blank' ? 'A new tag' : 'Not a capsule'),
      h('p', { class: 'dim' }, info.message ?? 'Choose who goes inside, then tap again.'),
      info.state === 'foreign' || info.state === 'damaged' ? h('button', { class: 'btn danger', onclick: () => app.arm({ kind: 'format' }) }, 'Format as capsule') : null,
      h('div', { class: 'col' }, app.creatures().filter((c) => c.location?.kind !== 'capsule').map((c) => h('button', { class: 'btn', style: { justifyContent: 'flex-start' }, onclick: () => app.arm({ kind: 'send', uid: c.uid, mode: 'walk' }) },
        spriteCanvas(app.bank, c, { scale: 1 }), `Put ${displayName(app.idx, c)} inside`))));
  }
  // the PC's dock, as of the last sync (this phone can't take from it; the PC can)
  if (app.settings.hubUrl && Date.now() - (app.settings.lastSync ?? 0) > 15000) app.sync({ quiet: true }).then(() => render()).catch(() => {});
  function pcDockPanel() {
    const d = app.pcDock;
    if (!app.settings.hubUrl) return null;
    // look only: what the PC's dock holds right now (the phone is told when it's lifted off)
    return h('section', { class: 'panel col pc-dock-panel' },
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, 'On your PC’s dock'), h('span', { class: `dot ${d ? 'on' : ''}` })),
      !d ? h('p', { class: 'dim' }, 'Nothing on the dock.')
        : d.state !== 'creature' ? h('p', { class: 'dim' }, d.state === 'empty' ? `${d.capsule ?? 'A ball'}, empty.` : 'A ball is being read…')
          : h('div', { class: 'row' },
            capsuleCanvas({ ring: d.speciesId ? app.idx.types.get(app.idx.species.get(String(d.speciesId).split(':')[0])?.types?.[0])?.color : '#34d1bf', lit: true, creature: d.speciesId, bank: app.bank, pulse: true }, 2),
            h('div', { class: 'grow' }, h('div', null, `${d.name ?? 'Someone'}${d.level ? ` · Lv. ${d.level}` : ''}`), h('div', { class: 'micro dim' }, d.capsule ?? 'Ball'))));
  }
  function devPanel() {
    if (app.native) return null;
    const tags = app.platform.virtualTags();
    return h('section', { class: 'panel col dev' },
      h('h2', null, 'Browser preview: no NFC here'),
      h('p', { class: 'dim' }, 'In this preview, tap a virtual capsule instead.'),
      tags.map((t) => h('div', { class: 'row' }, h('span', { class: 'grow mono-num' }, t.uid.slice(-6)),
        h('button', { class: 'btn small', onclick: () => app.platform.tapVirtual(t.uid) }, 'Tap'),
        h('button', { class: 'btn small', onclick: () => { app.platform.walkVirtual(t.uid, 2500); toast('The capsule counted 2,500 steps.'); } }, 'Walk'))),
      h('button', { class: 'btn small', onclick: () => { app.platform.newVirtualTag(); render(); } }, 'New virtual capsule'));
  }
  function render() {
    const arm = app.capsuleArm;
    mount(el,
      h('div', { class: `tap-zone ${arm ? 'armed' : ''}` },
        h('div', { class: 'tap-anim' }, capsuleCanvas({ ring: arm ? '#ffc93c' : '#34d1bf', pulse: true }, 5)),
        h('p', null, armText(arm)),
        arm ? h('button', { class: 'btn small', onclick: () => app.arm(null) }, 'Cancel') : null),
      lastPanel(),
      pcDockPanel(),
      devPanel(),
      h('section', { class: 'panel col' }, h('h2', null, 'Synced with this phone'),
        app.myBalls().length ? app.myBalls().map(([tag, cap]) => {
          const c = cap.uid ? app.save.creatures[cap.uid] : null;
          return h('div', { class: 'row' }, capsuleCanvas({ skin: c?.ball ?? cap.skin, ring: c ? app.idx.types.get(speciesOf(app.idx, c)?.types[0])?.color : '#2a2848', lit: !!c, creature: c?.speciesId, bank: app.bank }, 2),
            h('div', { class: 'grow' }, h('div', null, cap.name), h('div', { class: 'dim micro' }, c ? `${displayName(app.idx, c)} · ${cap.mode ?? ''}` : 'Empty')),
            h('span', { class: 'micro dim' }, cap.battery != null ? `${cap.battery}%` : ''),
            h('button', { class: 'btn small', onclick: async () => {
              const t = await chooseBall(cap.skin);
              if (t != null) app.record(makeEvent('capsule', { tag, skin: t }));
            } }, 'Look'));
        }) : h('p', { class: 'dim' }, 'No balls synced with this phone. Hold one to the phone to sync it; it stays listed until it goes back on your PC’s dock.')));
  }
  render();
  return { el, update: render, dispose: off };
}

// ---------------- battle (on Showdown) ----------------
export function battleView(app) {
  const el = h('div', { class: 'm-battle' });
  let client = null, waiting = null, motionOff = null, autoBumpAt = null;
  let result = app.lastResult ?? null;
  app.lastResult = null;
  const offs = [
    app.on((w) => {
      if (w === 'battle-result') { result = app.lastResult; app.lastResult = null; render(); el.parentElement?.scrollTo?.(0, 0); }
    }),
  ];

  const settings = () => showdownSettings(app.save);

  async function find(kind, code) {
    const s = settings();
    if (!toId(s.name)) { toast('Enter your Showdown name first.', 'err'); return; }
    if (!app.battleUrl()) { toast('Link to your PC, or set a pairing server on the Link tab.', 'err'); return; }
    try {
      client?.close();
      client = app.client(app.battleUrl());
      await client.connect();
      client.on(MSG.MATCHED, (m) => {
        stopMotion();
        waiting = null;
        app.rememberFriend(m.opponent);
        app.platform.vibrate([60, 40, 60]);
        if (document.hidden) app.platform.notify('Battle found', `${m.opponent.name} wants to battle. Tap to open Showdown.`);
        toast(m.role === 'challenge' ? `Matched with ${m.opponent.name}. Sending the challenge on Showdown…` : `Matched with ${m.opponent.name}. Accepting their challenge on Showdown…`, 'ok');
        client.close(); client = null;
        render();
        if (app.native) app.openShowdown({ action: m.role, opponent: m.opponent.showdown, format: m.format });
        else matchedNote = m;
        render();
      });
      client.on(MSG.NO_MATCH, (m) => { if (!m.cancelled) toast(m.message, 'err'); });
      client.on(MSG.ERROR, (m) => toast(m.message, 'err'));
      client.on(MSG.WAITING, (m) => {
        waiting = m; render();
        if (m.mode === 'bump') startMotion();
        if (m.mode === 'bump' && autoBumpAt) { bump(Date.now() - autoBumpAt); autoBumpAt = null; }
      });
      client.send(MSG.FIND, { mode: kind, code, name: app.save.trainer.name, showdown: s.name, format: s.format, server: s.server, capsules: app.myCapsuleIds() });
    } catch (e) { toast(e.message, 'err'); }
  }
  let matchedNote = null;

  function bump(elapsed = 0) {
    try { client?.send(MSG.BUMP, { elapsed }); app.platform.vibrate([30]); sfx('blip'); } catch { /* not connected */ }
  }
  function startMotion() {
    let last = 0;
    const onMotion = (e) => {
      const a = e.acceleration;
      const g = a && a.x != null ? Math.hypot(a.x, a.y, a.z) : Math.max(0, Math.hypot(e.accelerationIncludingGravity?.x || 0, e.accelerationIncludingGravity?.y || 0, e.accelerationIncludingGravity?.z || 0) - 9.8);
      const now = performance.now();
      if (g > 22 && now - last > 1200) { last = now; bump(0); }
    };
    window.addEventListener('devicemotion', onMotion);
    motionOff = () => window.removeEventListener('devicemotion', onMotion);
  }
  function stopMotion() { motionOff?.(); motionOff = null; }
  function cancel() {
    try { client?.send(MSG.CANCEL); } catch { /* ignore */ }
    client?.close(); client = null; waiting = null; stopMotion(); render();
  }

  function openButton(label = 'Open Showdown') {
    const s = settings();
    return app.platform.canEmbedShowdown
      ? h('button', { class: 'btn primary', disabled: !app.team().length, onclick: () => app.openShowdown({}) }, label)
      : h('a', { class: 'btn primary', href: s.server, target: '_blank', rel: 'noopener' }, label);
  }

  function friendsPanel() {
    const friends = Object.values(app.save.friends ?? {});
    return h('section', { class: 'panel col' },
      h('h2', null, 'Friends'),
      friends.length ? friends.map((f) => h('div', { class: 'row' },
        h('div', { class: 'grow' }, h('div', null, f.name), h('div', { class: 'micro dim' }, `${f.showdown} on Showdown${f.capsules?.length ? ` · ${f.capsules.length} capsule${f.capsules.length > 1 ? 's' : ''}` : ''}`)),
        h('button', { class: 'btn small', disabled: !app.platform.canEmbedShowdown, onclick: () => app.openShowdown({ action: 'challenge', opponent: f.showdown }) }, 'Challenge')))
        : h('p', { class: 'dim' }, 'Friends you battle by bump or code are saved here. After that, knocking your capsules together starts a battle with no PC or server needed.'),
      h('button', { class: 'btn small', onclick: async () => {
        const name = await promptDialog('Add a friend', 'Their Showdown name', '', { maxLength: 18, ok: 'Add' });
        if (name && toId(name)) app.rememberFriend({ name: name.trim(), showdown: name.trim(), capsules: [] });
        render();
      } }, 'Add by Showdown name'));
  }

  function render() {
    const s = settings();
    const team = app.team();
    mount(el,
      result ? h('section', { class: 'panel col' }, result, h('button', { class: 'btn wide', onclick: () => { result = null; render(); } }, 'Done')) : null,
      h('h1', null, 'Battle'),
      h('p', { class: 'dim' }, 'Battles are played on Showdown with your creatures. Experience, friendship and new moves come back here when the battle ends.'),
      teamPanel(app.sdCtx(), { actions: openButton() }),
      matchedNote && !app.native ? h('p', { class: 'note' }, `Matched with ${matchedNote.opponent.name} (${matchedNote.opponent.showdown}). In Showdown, ${matchedNote.role === 'challenge' ? 'challenge them' : 'accept their challenge'} with your imported team.`) : null,
      h('section', { class: 'panel col' },
        h('h2', null, 'Battle someone nearby'),
        waiting ? [
          h('p', { class: 'waiting' }, waiting.mode === 'bump' ? 'Bump your phones together, or knock your capsules together.' : `Battle code ${waiting.code}. Your friend enters it in their app.`),
          h('button', { class: 'btn wide', onclick: cancel }, 'Stop waiting'),
        ] : [
          h('button', { class: 'btn wide', disabled: !team.length, onclick: () => find('bump') }, 'Bump to battle'),
          h('div', { class: 'row' },
            h('input', { type: 'text', placeholder: 'Code', maxLength: 8, id: 'code-in' }),
            h('button', { class: 'btn', disabled: !team.length, onclick: () => find('code', document.getElementById('code-in').value.trim().toUpperCase()) }, 'Join or host')),
          h('p', { class: 'micro dim' }, app.battleUrl() ? 'Pairing goes through your PC or pairing server; the battle itself is on Showdown.' : 'Bump and code pairing need your PC or a pairing server (Link tab). Friends below work without one.'),
        ]),
      friendsPanel(),
      showdownSettingsPanel(app.save, (fn) => { fn(app.save); app.persist(); }),
      resultPanel(app.sdCtx(), (res) => { result = res; render(); }),
      historyPanel(app.sdCtx()));
    void s;
  }
  render();
  return {
    el,
    update: () => render(),
    /** A capsule bump arrived (no known friend nearby): pair through the PC or pairing server. */
    autoBump(at) {
      if (!app.battleUrl()) { toast('Bump recorded. Link to your PC or a pairing server (Link tab) to find the other player.', 'err'); return; }
      if (!app.team().length) { toast('Take creatures along first (Party tab).', 'err'); return; }
      if (waiting?.mode === 'bump') { bump(Date.now() - at); return; }
      autoBumpAt = at;
      find('bump');
    },
    dispose() { stopMotion(); if (waiting) cancel(); offs.forEach((o) => o()); },
  };
}

// ---------------- link & settings ----------------
export function linkView(app) {
  const el = h('div', { class: 'm-link' });
  function render() {
    const s = app.settings;
    mount(el,
      h('h1', null, 'Link'),
      idPanel(app, render),
      s.hubUrl ? h('section', { class: 'panel col' },
        h('div', { class: 'row' }, h('span', { class: 'dot on' }), h('span', { class: 'grow ell' }, s.hubUrl)),
        h('div', { class: 'dim' }, `Last sync ${timeAgo(s.lastSync)} · ${app.save.queue.length} change${app.save.queue.length === 1 ? '' : 's'} waiting`),
        h('button', { class: 'btn primary wide', onclick: async () => { try { await app.sync(); } catch (e) { toast(e.message, 'err'); } } }, 'Sync now'),
        h('button', { class: 'btn wide', onclick: async () => {
          if (!(await confirmDialog('Unlink this phone?', 'Creatures on the phone stay here. Link again with a new pairing code.', { ok: 'Unlink', danger: true }))) return;
          app.local((st) => { st.settings.hubUrl = ''; st.settings.token = null; });
        } }, 'Unlink')) : h('section', { class: 'panel col' }, h('h2', null, 'Link to your PC'), linkForm(app, () => render())),
      h('section', { class: 'panel col' },
        h('h2', null, 'Pairing server'),
        h('p', { class: 'dim' }, 'Used to pair phones for bump and code battles. Leave empty to pair through your PC; away from home, enter a relay address (see the README).'),
        h('input', { type: 'url', value: s.battleUrl || '', placeholder: s.hubUrl || 'ws://relay.example:47820', onchange: (e) => app.local((st) => { st.settings.battleUrl = e.target.value.trim(); }) })),
      h('section', { class: 'panel col' },
        h('h2', null, 'This phone'),
        homeIconRow(app),
        h('label', { class: 'field' }, h('span', null, 'Trainer name'), h('input', { type: 'text', maxLength: 10, value: app.save.trainer.name, onchange: (e) => app.local((st) => { st.trainer.name = e.target.value.trim().slice(0, 10) || 'Trainer'; }) })),
        h('label', { class: 'field' }, h('span', null, 'Phone name (shown on the PC)'), h('input', { type: 'text', maxLength: 20, value: s.deviceName, onchange: (e) => app.local((st) => { st.settings.deviceName = e.target.value.trim() || 'My phone'; }) })),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.sound !== false, onchange: (e) => { app.local((st) => { st.settings.sound = e.target.checked; }); setSound(e.target.checked, s.volume ?? 0.6); } }), 'Sounds and cries'),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!s.watchBumps, onchange: async (e) => {
          const on = e.target.checked;
          if (on) { const p = await app.platform.permissions({ bluetooth: true }); if (p?.bluetooth === 'denied') { toast('Allow nearby devices so the app can hear your capsules.', 'err'); e.target.checked = false; return; } await app.platform.startBeacons(); }
          else await app.platform.stopBeacons();
          app.local((st) => { st.settings.watchBumps = on; });
        } }), 'Listen for capsule bumps (Bluetooth)')),
      backupPanel(app),
      aboutPanel(app),
      h('section', { class: 'panel col' },
        h('h2', null, 'Debug tools'),
        h('p', { class: 'dim' }, 'Ball hardware and the USB-C link, for testing.'),
        h('button', { class: 'btn', onclick: () => app.go('debug') }, 'Open debug tools')),
      h('p', { class: 'micro faint center' }, `Data set: ${app.idx.ds.meta?.name ?? ''} · ${app.idx.ds.species.length} species`));
  }
  render();
  return { el, update: render };
}


/** The trainer ID card. With a PC linked, the PC's card wins; without one it can be edited here. */
function cardScale(card, tall = 0.5) {
  const avail = Math.min(window.innerWidth || 360, 520) - 72;
  const portrait = card?.design === 'badge' || card?.design === 'field';
  const w = portrait ? 150 : 240, hgt = portrait ? 240 : 150;
  const fit = Math.min(avail / w, ((window.innerHeight || 700) * tall) / hgt);
  return Math.max(1, Math.floor(fit * 2) / 2);
}
function idPanel(app, rerender) {
  const t = app.save.trainer;
  const linked = !!app.settings.hubUrl;
  return h('section', { class: 'panel col m-id' },
    h('h2', null, 'Trainer ID'),
    h('button', { class: 'm-id-card', 'aria-label': 'Show your trainer ID', onclick: () => dialog('Trainer ID', (close) => h('div', { class: 'col center-items' },
      idCardEl(t, { scale: cardScale(t.card, 0.62), party: partyForCard(app.bank, app.team(), (c) => displayName(app.idx, c)) }),
      h('p', { class: 'micro dim center' }, 'Tilt the card to catch the light; swipe it sideways to see the back.'),
      h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: () => close() }, 'Done')))) }, idCardEl(t, { scale: cardScale(t.card, 0.42), flip: false })),
    linked ? h('p', { class: 'micro dim' }, 'This card comes from your PC. Change it on the PC under Trainer ID; it updates here on the next sync.')
      : h('button', { class: 'btn wide', onclick: () => {
        let ed;
        dialog('Edit trainer ID', (close) => {
          ed = cardEditor({ trainer: t, editName: true, scale: 1, party: partyForCard(app.bank, app.team(), (c) => displayName(app.idx, c)) });
          return h('div', { class: 'col' }, ed.el, h('div', { class: 'actions' },
            h('button', { class: 'btn', onclick: () => close() }, 'Cancel'),
            h('button', { class: 'btn primary', onclick: () => { const v = ed.value(); app.local((st) => { st.trainer.name = v.name; st.trainer.card = v.card; }); close(); rerender(); } }, 'Save')));
        });
      } }, 'Edit card'));
}


/** The name and icon chosen on the PC, on this phone's home screen. */
function homeIconRow(app) {
  const files = app.textures?.files ?? {};
  const src = files['ui/app-icon.png'] ?? files['ui/logo.png'] ?? null;
  const name = brandText('Capsule Link');
  return h('div', { class: 'home-icon-row' },
    src ? h('img', { src, alt: '', class: 'home-icon' }) : logoMark(44),
    h('div', { class: 'grow' }, h('div', null, name), h('div', { class: 'micro dim' }, app.settings.hubUrl ? 'Name, pictures and wording come from your PC on every sync.' : 'Link a PC to bring over its names, pictures and wording.')),
    app.platform.canPinShortcut ? h('button', { class: 'btn small', onclick: async () => {
      try {
        await app.platform.pinShortcut(name, src ? src.split(',')[1] : null);
        toast('Look for it on your home screen. You can remove the original icon there; the app stays in your app drawer.', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    } }, 'Add to home screen') : null);
}


/** Backups of everything on this phone: download, keep on the PC, and put back. */
function downloadText(name, text) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  a.download = name;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 60000);
}
function backupPanel(app) {
  const linked = !!app.settings.hubUrl;
  const restore = async (text, label) => {
    const r = readBackup(text);
    if (!r.ok) return toast(r.error, 'err');
    if (r.kind !== 'phone') return toast(r.kind === 'pc' ? 'That is a PC backup: restore it in the PC app (Settings → Backups).' : 'That is a save from the PC, not a phone backup.', 'err');
    if (!(await confirmDialog('Put this backup back?', `${label ? `${label}: ` : ''}${r.summary}. Everything on this phone is replaced with it and the app starts over. Creatures already back on the PC stay there.`, { ok: 'Restore', danger: true }))) return;
    try { app.restoreBackup(text); toast('Restored. Starting over…', 'ok'); } catch (e) { toast(e.message, 'err'); }
  };
  const before = h('span');
  app.beforeUpdateBackup().then((b) => {
    if (b) mount(before, h('button', { class: 'btn small', onclick: () => restore(JSON.stringify(b), 'From just before the last update') }, 'Restore from before the last update'));
  });
  return h('section', { class: 'panel col' },
    h('h2', null, 'Backups'),
    h('p', { class: 'dim' }, 'Everything on this phone in one file: creatures with you, items, capsules, the PC link and steps not synced yet.'),
    h('div', { class: 'btn-group' }, h('div', { class: 'btn-group-head' }, 'Make one'),
      h('button', { class: 'btn primary', onclick: () => { downloadText(app.backupName(), app.backupText()); sfx('level'); toast(app.native ? 'Look in Downloads. If nothing arrived, use Keep on PC.' : 'Backup downloaded.', 'ok'); } }, 'Download backup'),
      linked ? h('button', { class: 'btn', onclick: async () => { try { await app.sendBackup(); sfx('level'); toast('Kept on your PC (Settings → Backups there).', 'ok'); } catch (e) { toast(e.message, 'err'); } } }, 'Keep on PC') : null),
    h('p', { class: 'micro dim' }, linked ? `Your PC also keeps one by itself each day and before every update${app.settings.lastPcBackup ? ` (last ${timeAgo(app.settings.lastPcBackup)})` : ''}.` : 'Link a PC and it keeps one each day by itself.'),
    h('div', { class: 'btn-group' }, h('div', { class: 'btn-group-head' }, 'Restore'),
      h('label', { class: 'btn small' }, 'Restore from a file', h('input', { type: 'file', accept: '.json,application/json', class: 'hidden', onchange: async (e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) restore(await f.text()); } })),
      linked ? h('button', { class: 'btn small', onclick: async () => {
        let list;
        try { list = await app.pcBackups(); } catch (e) { return toast(e.message, 'err'); }
        if (!list.length) return toast('Your PC has no phone backups yet.', 'err');
        const file = await dialog('Backups on your PC', (close) => h('div', { class: 'col' },
          list.slice(0, 12).map((b) => h('button', { class: 'btn wide left', onclick: () => close(b.file) },
            h('div', { class: 'col tight' }, h('strong', null, new Date(b.at).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })), h('span', { class: 'micro dim' }, b.summary)))),
          h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(null) }, 'Cancel'))));
        if (!file) return;
        try { restore(await app.pcBackup(file)); } catch (e) { toast(e.message, 'err'); }
      } }, 'Restore from your PC') : null,
      before));
}

/** Version, updates from the PC, and going back to the version inside the app. */
function aboutPanel(app) {
  const BUILD = typeof __BUILD__ !== 'undefined' ? __BUILD__ : { version: '?' };
  const info = h('p', { class: 'dim' }, `Version ${BUILD.version}`);
  const actions = h('div', { class: 'row wrap' });
  const fp = h('p', { class: 'micro faint' });
  const el = h('section', { class: 'panel col' }, h('h2', null, 'About this app'), info, fp,
    h('p', { class: 'micro dim' }, 'Updates come from your PC: when an update file is installed there, this phone offers it on its next sync.'), actions);
  app.platform.appInfo().then((r) => {
    const updated = r?.updated?.version;
    if (updated) info.textContent = `Version ${BUILD.version}, updated from your PC (the app itself came with v${r.builtIn?.version ?? '?'}).`;
    info.title = `Android build ${r?.builtIn?.phoneNative ?? BUILD.phoneNative ?? '?'}`;
    mount(fp, `Android build: ${r?.builtIn?.phoneNative || BUILD.phoneNative || '?'}`);
    mount(actions,
      app.pendingUpdate ? h('button', { class: 'btn small primary', onclick: () => { app.updating = false; app.offerUpdate(app.pendingUpdate); } }, `Install update v${app.pendingUpdate.version}`) : null,
      app.settings.hubUrl ? h('button', { class: 'btn small', onclick: async () => {
        app.local((s) => { s.settings.declinedUpdate = null; });
        try { await app.sync({ quiet: true }); } catch (e) { toast(e.message, 'err'); return; }
        const s = app.appStatus;
        if (!s) toast('Your PC app is too old to send phone updates. Install the latest update file on the PC first.', 'err');
        else if (s.state === 'none') toast('Your PC has no phone update yet. Install the update file on the PC first.');
        else if (s.state === 'current') toast(`Up to date (v${BUILD.version}).`, 'ok');
        else if (s.state === 'native') app.askUpdateAnyway();
        // 'offered': the update dialog opens by itself
      } }, 'Check for an update') : null,
      updated ? h('button', { class: 'btn small', onclick: async () => {
        if (!(await confirmDialog('Go back?', `Use v${r.builtIn?.version ?? '?'}, the version that came with the app? Your creatures and settings stay.`, { ok: 'Go back' }))) return;
        app.local((s) => { s.settings.declinedUpdate = BUILD.version; });
        await app.platform.useBuiltIn();
      } }, 'Use the built-in version') : null);
  });
  return el;
}
