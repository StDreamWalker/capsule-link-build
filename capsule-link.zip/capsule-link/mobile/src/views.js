import { chooseBall } from '../../shared/ui/ballPicker.js';
import { readBackup } from '../../shared/engine/backup.js';
// Phone screens: welcome, buddy (walking), party, capsule (NFC), battle, link.
import { brandText } from '../../shared/ui/dom.js';
import { logoMark } from '../../shared/ui/icons.js';
import { h, mount, toast, dialog, chooseDialog, confirmDialog, promptDialog, hearts, typeChip, fmtNum, timeAgo, hpBar } from '../../shared/ui/dom.js';
import { spriteCanvas } from '../../shared/ui/art.js';
import { capsuleCanvas, ballIcon, creatureBall } from '../../shared/ui/capsuleArt.js';
import { creatureSummary } from '../../shared/ui/summary.js';
import { openJournal } from '../../shared/ui/journal.js';
import { teamPanel, resultPanel, historyPanel, showdownSettingsPanel, showdownSettings } from '../../shared/ui/showdownUi.js';
import { loadShowdown, playWildBattle } from '../../shared/ui/showdownWild.js';
import { openShowdownOnline, watchReplay } from '../../shared/ui/showdownOnline.js';
import { BATTLE_PLACES, battlePlace } from '../../shared/ui/battleStage.js';
import { rollWild, wildTeams, wildOutcome } from '../../shared/engine/wildBattle.js';
import { battleBag } from '../../shared/engine/battleItems.js';
import { skySettingsBlock, threeDBlock } from '../../shared/ui/skySettings.js';
import { qualitySlider } from '../../shared/ui/quality.js';
import { sfx, playCry, setSound, creatureCry } from '../../shared/ui/audio.js';
import {
  displayName, speciesOf, friendshipTier, mood, createCreature, makeEvent, changeOptions, cryFor, calcStats, CAPSULE, MSG, tickNeeds, toId, wallet, itemInfo,
  healCost, moveChoices, famousTeam, FAMOUS_TRAINERS,
} from '../../shared/engine/index.js';
import { icon } from './icons.js';
import { transferLine } from '../../shared/ui/transfer.js';
import { idCardEl, partyForCard } from '../../shared/ui/idcard.js';
import { cardEditor } from '../../shared/ui/idcardEditor.js';

const MODE_HELP = {
  desk: 'Sits on a desk and wiggles now and then.',
  walk: 'Counts your steps together.',
  battle: 'Tap it against a friend’s capsule to battle.',
  sleep: 'Quiet and saving battery.',
};

// ---------------- welcome ----------------
export function welcomeView(app, done) {
  let step = 'intro1';
  const el = h('div', { class: 'm-welcome' });
  const starters = app.idx.ds.species.filter((s) => s.evolutions?.length).slice(0, 3);
  const dots = (k) => h('div', { class: 'w-dots' }, [0, 1, 2].map((j) => h('i', { class: j === k ? 'on' : '' })));
  function render() {
    if (step === 'intro1') {
      mount(el,
        h('div', { class: 'welcome-hero' }, capsuleCanvas({ ring: '#34d1bf', creature: starters[0]?.id, bank: app.bank }, 6)),
        h('h1', null, 'They travel with you'),
        h('p', null, 'Creatures live on your PC. When you head out, they ride along inside a capsule — this phone is how you check on them.'),
        h('p', { class: 'dim' }, 'Nobody leaves their capsule away from the PC. Here you can see how they are doing, hear what they are thinking on walks, and give the capsule a gentle tap.'),
        dots(0),
        h('button', { class: 'btn primary wide', onclick: () => { step = 'intro2'; render(); } }, 'Next'),
        h('button', { class: 'btn wide', onclick: () => { step = 'hello'; render(); } }, 'Skip'));
    } else if (step === 'intro2') {
      mount(el,
        h('div', { class: 'welcome-hero row-hero' }, icon('link', 48), capsuleCanvas({ ring: '#ffc93c' }, 5)),
        h('h1', null, 'Connecting'),
        h('p', null, 'Your PC: open Phone Link there and enter its address and six-digit code on the next screen. Same Wi-Fi, or a USB-C cable.'),
        h('p', null, 'Your capsule: hold it against the back of this phone. It syncs steps and shows who is inside. Empty capsules can pick up wild creatures on walks.'),
        dots(1),
        h('button', { class: 'btn primary wide', onclick: () => { step = 'hello'; render(); } }, 'Next'),
        h('button', { class: 'btn wide', onclick: () => { step = 'intro1'; render(); } }, 'Back'));
    } else if (step === 'hello') {
      mount(el,
        h('div', { class: 'welcome-hero' }, capsuleCanvas({ ring: '#34d1bf', creature: starters[0]?.id, bank: app.bank }, 6)),
        h('h1', null, 'Capsule Link'),
        h('p', null, 'Walk with your creatures, sync capsules with a tap, and battle friends.'),
        dots(2),
        h('label', { class: 'field' }, h('span', null, 'Your name'), h('input', { type: 'text', maxLength: 10, value: app.save.trainer.name === 'Trainer' ? '' : app.save.trainer.name, placeholder: 'Trainer', oninput: (e) => { app.save.trainer.name = e.target.value.trim() || 'Trainer'; } })),
        h('button', { class: 'btn primary wide', onclick: () => { step = 'link'; render(); } }, 'Link to my PC'),
        h('button', { class: 'btn wide', onclick: () => { step = 'starter'; render(); } }, 'Start without a PC'));
    } else if (step === 'link') {
      mount(el, h('h1', null, 'Link to your PC'), linkForm(app, async () => { done(); }), h('button', { class: 'btn wide', onclick: () => { step = 'hello'; render(); } }, 'Back'));
    } else {
      mount(el,
        h('h1', null, 'Pick a buddy'),
        h('p', { class: 'dim' }, 'You can link your PC later; this creature comes along.'),
        h('div', { class: 'starter-row' }, starters.map((s) => h('button', { class: 'starter', onclick: () => {
          const c = createCreature(app.idx, s.id, { level: 5, trainer: app.save.trainer.name, metHow: 'Chosen as a first buddy', location: { kind: 'phone', device: app.settings.deviceId } });
          app.save.creatures[c.uid] = c;
          app.settings.buddyUid = c.uid;
          app.persist();
          creatureCry(s);
          done();
        } }, spriteCanvas(app.bank, s.id, { scale: 3, animate: true }), h('span', null, s.name), h('span', { class: 'row' }, s.types.map((t) => typeChip(app.idx, t)))))),
        h('button', { class: 'btn wide', onclick: () => { step = 'hello'; render(); } }, 'Back'));
    }
  }
  render();
  return el;
}

/** Address + pairing code form, with LAN discovery on Android. */
function linkForm(app, onDone) {
  let url = app.settings.hubUrl || '';
  let code = '';
  const found = h('div', { class: 'col' });
  const urlInput = h('input', { type: 'url', value: url, placeholder: 'ws://192.168.1.20:47820', oninput: (e) => { url = e.target.value.trim(); } });
  const discover = async () => {
    mount(found, h('p', { class: 'dim' }, 'Looking for your PC on this network…'));
    const list = await app.platform.discover(4000);
    if (!list.length) { mount(found, h('p', { class: 'dim' }, app.native ? 'No PC answered. Check that Capsule Link is open on the PC and both are on the same Wi-Fi, or type the address shown on the PC’s Phone link screen.' : 'Discovery works in the Android app. Type the address shown on the PC’s Phone link screen.')); return; }
    mount(found, list.map((p) => h('button', { class: 'btn wide', onclick: () => { url = `ws://${p.address}:${p.port}`; urlInput.value = url; } }, `${p.name}  ${p.address}`)));
  };
  return h('div', { class: 'col' },
    h('p', { class: 'dim' }, 'Open Phone link on the PC to see its address and a six-digit pairing code.'),
    h('div', { class: 'row' },
      h('button', { class: 'btn grow', onclick: discover }, 'Find my PC'),
      h('button', { class: 'btn grow', onclick: () => { url = 'ws://127.0.0.1:47820'; urlInput.value = url; toast('USB cable: on the PC open Phone link → USB cable → Set up USB link first.'); } }, 'Use USB cable')),
    found,
    h('label', { class: 'field' }, h('span', null, 'PC address'), urlInput),
    h('label', { class: 'field' }, h('span', null, 'Pairing code'), h('input', { type: 'text', inputMode: 'numeric', maxLength: 6, placeholder: '123456', oninput: (e) => { code = e.target.value.trim(); } })),
    h('button', { class: 'btn primary wide', onclick: async (e) => {
      if (!/^wss?:\/\//.test(url)) url = `ws://${url.replace(/^\/+/, '')}`;
      if (!/:\d+$/.test(url.replace(/\/$/, ''))) url = `${url.replace(/\/$/, '')}:47820`;
      e.target.disabled = true;
      try { await app.connectPc(url, code); toast('Linked to your PC.', 'ok'); onDone?.(); }
      catch (err) { toast(err.code === 'pair' ? 'That pairing code did not match. Check the code on the PC.' : err.message, 'err'); }
      e.target.disabled = false;
    } }, 'Link'));
}

// ---------------- party ----------------
export function partyView(app) {
  const el = h('div', { class: 'm-party' });
  function card(c) {
    const st = calcStats(app.idx, c);
    const where = c.location?.kind === 'capsule' ? (app.save.capsules[c.location.tag]?.name ?? 'In a capsule') : 'Phone link';
    const isBuddy = app.settings.buddyUid === c.uid;
    return h('button', { class: `m-card ${isBuddy ? 'sel' : ''}`, onclick: () => open(c) },
      spriteCanvas(app.bank, c, { scale: 2 }),
      h('div', { class: 'grow' },
        h('div', { class: 'row' }, ballIcon(creatureBall(c), 12), h('span', { class: 'grow ell' }, displayName(app.idx, c)), h('span', { class: 'dim' }, `Lv${c.level}`)),
        hpBar(c.hp ?? st.hp, st.hp),
        h('div', { class: 'row' }, hearts(friendshipTier(c.friendship).hearts), h('span', { class: 'spacer' }), h('span', { class: 'micro dim' }, isBuddy ? 'Buddy' : where))));
  }
  async function open(c) {
    const inCapsule = c.location?.kind === 'capsule';
    await dialog(displayName(app.idx, c), (close) => h('div', { class: 'col' },
      creatureSummary(app.idx, app.bank, c, { compact: true, sections: ['stats', 'moves', 'care', 'walk', 'likes', 'memories'] }),
      h('div', { class: 'col' },
        // evolve / Mega Evolve / change form: only what they can do; greyed out with the reason otherwise
        (() => { const opts = changeOptions(app.idx, app.save, c); return opts.length ? h('div', { class: 'row wrap' }, opts.map((o) => h('button', { class: `btn small ${o.ok ? '' : 'off'}`, title: o.why, onclick: () => { if (!o.ok) { toast(o.why, 'err'); return; } app.record(makeEvent('change', { uid: c.uid, key: o.key })); toast(o.kind === 'evolve' ? `${displayName(app.idx, c)} is evolving!` : `${displayName(app.idx, c)} changed!`, 'ok'); close(); } }, o.label, !o.ok ? h('small', { class: 'dim', style: { display: 'block' } }, o.why) : null))) : null; })(),
        h('button', { class: 'btn primary', disabled: app.settings.buddyUid === c.uid, onclick: () => { app.local((s) => { s.settings.buddyUid = c.uid; }); close(); toast(`Watching ${displayName(app.idx, c)} on the monitor.`, 'ok'); app.go('buddy'); } }, 'Watch on the monitor'),
        !c.egg ? h('button', { class: 'btn', onclick: () => openJournal({ idx: app.idx, bank: app.bank, save: app.save }, c) }, '📖 Journal') : null,
        !inCapsule ? h('button', { class: 'btn', onclick: () => { close(); moveSheet(c); } }, 'Move to…') : null,
        h('button', { class: 'btn', onclick: async () => {
          const name = await promptDialog('Nickname', 'Leave empty to use the species name', c.nickname, { maxLength: 12 });
          if (name != null) app.record(makeEvent('rename', { uid: c.uid, nickname: name.trim() }));
          close();
        } }, 'Rename'),

        h('button', { class: 'btn', onclick: () => close() }, 'Close'))));
  }
  // one place for every way out: back to the PC, or into a ball (tap it against the phone)
  async function moveSheet(c) {
    const name = displayName(app.idx, c);
    const where = await chooseDialog(`Move ${name}`, [
      { value: 'pc', label: '🖥️ Back to the PC', detail: app.settings.hubUrl ? 'Streams home now (needs the PC app open). Everything from your walks goes with them.' : 'Link to your PC first (Link tab).' },
      { value: 'ball', label: '⚪ Into a ball', detail: 'Next, hold an empty ball (capsule tag) against the back of the phone.' },
    ]);
    if (where === 'pc') {
      if (!app.settings.hubUrl) { toast('Link to your PC first (Link tab).', 'err'); return; }
      toast(`Sending ${name} to your PC…`);
      try { await app.giveBack([c.uid]); toast(`${name} is back at your PC.`, 'ok'); sfx('transfer'); } catch (e) { toast(e.message, 'err'); }
      render();
    } else if (where === 'ball') { app.arm({ kind: 'send', uid: c.uid, mode: 'walk' }); app.go('capsule'); }
  }
  const pcWhere = (x) => { const L = x.location ?? {}; return L.kind === 'party' ? 'in your party' : L.kind === 'ranch' ? 'on the free range' : L.kind === 'box' ? (app.save.boxes?.[L.box]?.name ?? 'in a PC box') : L.kind; };
  async function takeFromPc() {
    if (!app.settings.hubUrl) { toast('Link to your PC first (Link tab).', 'err'); return; }
    try { await app.sync({ quiet: true }); } catch (e) { toast(e.message, 'err'); return; }
    const options = app.pcList.filter((x) => ['box', 'party', 'ranch'].includes(x.location?.kind));
    const uid = await chooseDialog('Bring from the PC', options.map((x) => ({
      value: x.uid, label: x.nickname || app.idx.species.get(x.speciesId)?.name || x.speciesId, detail: `Lv. ${x.level} · ${pcWhere(x)}`,
      el: spriteCanvas(app.bank, x, { scale: 1 }),
    })), { empty: 'Nobody is waiting at the PC.' });
    if (!uid) return;
    try { await app.take([uid]); { const nm = app.save.creatures[uid] ? displayName(app.idx, app.save.creatures[uid]) : 'They'; toast(transferLine('phone', nm), 'ok'); sfx('materialize'); } if (!app.settings.buddyUid) app.local((s) => { s.settings.buddyUid = uid; }); } catch (e) { toast(e.message, 'err'); }
  }
  function render() {
    const list = app.creatures().filter((c) => app.idx.species.has(c.speciesId));
    mount(el,
      h('div', { class: 'row' }, h('h1', { class: 'grow' }, 'With you'), h('button', { class: 'btn small', onclick: takeFromPc }, 'Bring from PC')),
      h('p', { class: 'micro dim' }, 'Moving someone: PC → phone with “Bring from PC” (or send them from the PC’s Boxes → Move to…; they arrive when this app syncs). Phone → PC or a ball: tap them, then “Move to…”.'),
      list.length ? h('div', { class: 'col' }, list.map(card)) : h('p', { class: 'dim' }, 'Nobody yet. Take creatures from your PC, or tap a capsule.'),
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, app.save.satchel ? 'Satchel' : 'Bag'), h('span', { class: 'dim mono-num' }, `${wallet(app.save)} coins`)),
      app.save.satchel ? h('p', { class: 'micro dim' }, 'What you packed at the PC (Phone link → Satchel for walks). Feed and heal from it in Together; kibble always comes along. Finds on walks go home to the PC’s bag.') : null,
      Object.entries(app.save.inventory).filter(([, n]) => n > 0).length
        ? h('div', { class: 'kv' }, Object.entries(app.save.inventory).filter(([, n]) => n > 0).map(([id, n]) => [h('span', null, itemInfo(app.idx, id)?.name ?? id), h('span', null, `×${n}`)]))
        : h('p', { class: 'dim' }, app.save.satchel ? 'Nothing packed. Pack food, Potions or incense at the PC before a walk.' : 'Empty. Walking turns things up.'));
  }
  render();
  return { el, update: render };
}

// ---------------- capsule ----------------
export function capsuleView(app) {
  const el = h('div', { class: 'm-capsule' });
  const off = app.on((w) => { if (w === 'capsule') render(); });
  function armText(arm) {
    if (!arm) return 'Hold a capsule against the back of your phone to sync it.';
    if (arm.kind === 'send') return `Tap a capsule to put ${displayName(app.idx, app.save.creatures[arm.uid])} inside.`;
    if (arm.kind === 'release') return 'Tap the capsule to bring its creature onto your phone.';
    if (arm.kind === 'mode') return `Tap the capsule to switch it to ${arm.mode} mode.`;
    if (arm.kind === 'format') return 'Tap the tag to format it as an empty capsule.';
    return '';
  }
  function lastPanel() {
    const t = app.lastTag;
    if (!t || Date.now() - t.at > 10 * 60 * 1000) return null;
    if (t.error) return h('section', { class: 'panel' }, h('p', { class: 'err-text' }, t.error));
    const info = t.info;
    const cap = app.save.capsules[t.uid] ?? { name: 'Capsule' };
    if (!info) return null;
    if (info.state === 'creature') {
      const c = app.save.creatures[info.rec.uid];
      return h('section', { class: 'panel col' },
        h('div', { class: 'row' }, capsuleCanvas({ skin: c?.ball ?? cap.skin, ring: app.idx.types.get(speciesOf(app.idx, c ?? { speciesId: '' })?.types?.[0])?.color, creature: c?.speciesId, bank: app.bank }, 3),
          h('div', { class: 'grow' }, h('h2', null, c ? displayName(app.idx, c) : info.rec.nickname || `#${info.rec.speciesNo}`), h('div', { class: 'dim' }, `${cap.name} · ${info.rec.mode} mode`),
            h('div', { class: 'dim' }, `${fmtNum(info.rec.totalSteps)} steps together`))),
        h('div', { class: 'row wrap' }, CAPSULE.MODES.map((m) => h('button', { class: `btn small ${m === info.rec.mode ? 'primary' : ''}`, onclick: () => app.arm({ kind: 'mode', mode: m }) }, m[0].toUpperCase() + m.slice(1)))),
        h('p', { class: 'dim' }, MODE_HELP[info.rec.mode] ?? ''),
        h('p', { class: 'micro dim' }, 'Creatures stay in their capsule until they reach your PC.'));
    }
    return h('section', { class: 'panel col' },
      h('h2', null, info.state === 'empty' ? `${cap.name} is empty` : info.state === 'blank' ? 'A new tag' : 'Not a capsule'),
      h('p', { class: 'dim' }, info.message ?? 'Choose who goes inside, then tap again.'),
      info.state === 'foreign' || info.state === 'damaged' ? h('button', { class: 'btn danger', onclick: () => app.arm({ kind: 'format' }) }, 'Format as capsule') : null,
      h('div', { class: 'col' }, app.creatures().filter((c) => c.location?.kind !== 'capsule').map((c) => h('button', { class: 'btn', style: { justifyContent: 'flex-start' }, onclick: () => app.arm({ kind: 'send', uid: c.uid, mode: 'walk' }) },
        spriteCanvas(app.bank, c, { scale: 1 }), `Put ${displayName(app.idx, c)} inside`))));
  }
  // the PC's dock, as of the last sync (this phone can't take from it; the PC can)
  if (app.settings.hubUrl && Date.now() - (app.settings.lastSync ?? 0) > 15000) app.sync({ quiet: true }).then(() => render()).catch(() => {});
  function pcDockPanel() {
    const d = app.pcDock;
    if (!app.settings.hubUrl) return null;
    // look only: what the PC's dock holds right now (the phone is told when it's lifted off)
    return h('section', { class: 'panel col pc-dock-panel' },
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, 'On your PC’s dock'), h('span', { class: `dot ${d ? 'on' : ''}` })),
      !d ? h('p', { class: 'dim' }, 'Nothing on the dock.')
        : d.state !== 'creature' ? h('p', { class: 'dim' }, d.state === 'empty' ? `${d.capsule ?? 'A ball'}, empty.` : 'A ball is being read…')
          : h('div', { class: 'row' },
            capsuleCanvas({ ring: d.speciesId ? app.idx.types.get(app.idx.species.get(String(d.speciesId).split(':')[0])?.types?.[0])?.color : '#34d1bf', lit: true, creature: d.speciesId, bank: app.bank, pulse: true }, 2),
            h('div', { class: 'grow' }, h('div', null, `${d.name ?? 'Someone'}${d.level ? ` · Lv. ${d.level}` : ''}`), h('div', { class: 'micro dim' }, d.capsule ?? 'Ball'))));
  }
  function devPanel() {
    if (app.native) return null;
    const tags = app.platform.virtualTags();
    return h('section', { class: 'panel col dev' },
      h('h2', null, 'Browser preview: no NFC here'),
      h('p', { class: 'dim' }, 'In this preview, tap a virtual capsule instead.'),
      tags.map((t) => h('div', { class: 'row' }, h('span', { class: 'grow mono-num' }, t.uid.slice(-6)),
        h('button', { class: 'btn small', onclick: () => app.platform.tapVirtual(t.uid) }, 'Tap'),
        h('button', { class: 'btn small', onclick: () => { app.platform.walkVirtual(t.uid, 2500); toast('The capsule counted 2,500 steps.'); } }, 'Walk'))),
      h('button', { class: 'btn small', onclick: () => { app.platform.newVirtualTag(); render(); } }, 'New virtual capsule'));
  }
  function render() {
    const arm = app.capsuleArm;
    mount(el,
      h('div', { class: `tap-zone ${arm ? 'armed' : ''}` },
        h('div', { class: 'tap-anim' }, capsuleCanvas({ ring: arm ? '#ffc93c' : '#34d1bf', pulse: true }, 5)),
        h('p', null, armText(arm)),
        arm ? h('button', { class: 'btn small', onclick: () => app.arm(null) }, 'Cancel') : null),
      lastPanel(),
      pcDockPanel(),
      devPanel(),
      h('section', { class: 'panel col' }, h('h2', null, 'Synced with this phone'),
        app.myBalls().length ? app.myBalls().map(([tag, cap]) => {
          const c = cap.uid ? app.save.creatures[cap.uid] : null;
          return h('div', { class: 'row' }, capsuleCanvas({ skin: c?.ball ?? cap.skin, ring: c ? app.idx.types.get(speciesOf(app.idx, c)?.types[0])?.color : '#2a2848', lit: !!c, creature: c?.speciesId, bank: app.bank }, 2),
            h('div', { class: 'grow' }, h('div', null, cap.name), h('div', { class: 'dim micro' }, c ? `${displayName(app.idx, c)} · ${cap.mode ?? ''}` : 'Empty')),
            h('span', { class: 'micro dim' }, cap.battery != null ? `${cap.battery}%` : ''),
            h('button', { class: 'btn small', onclick: async () => {
              const t = await chooseBall(cap.skin);
              if (t != null) app.record(makeEvent('capsule', { tag, skin: t }));
            } }, 'Look'));
        }) : h('p', { class: 'dim' }, 'No balls synced with this phone. Hold one to the phone to sync it; it stays listed until it goes back on your PC’s dock.')));
  }
  render();
  return { el, update: render, dispose: off };
}

// ---------------- battle (on Showdown) ----------------
export function battleView(app) {
  const el = h('div', { class: 'm-battle' });
  let client = null, waiting = null, motionOff = null, autoBumpAt = null;
  let result = app.lastResult ?? null;
  app.lastResult = null;
  const offs = [
    app.on((w) => {
      if (w === 'battle-result') { result = app.lastResult; app.lastResult = null; render(); el.parentElement?.scrollTo?.(0, 0); }
    }),
  ];

  const settings = () => showdownSettings(app.save);
  // a wild creature that found you by notification: start that battle as soon as this tab is up
  const startPending = () => { if (app.pendingWild) { app.pendingWild = false; setTimeout(() => goWild(), 300); } };
  offs.push(app.on((w) => { if (w === 'wild-tap') startPending(); }));
  setTimeout(startPending, 0);

  async function find(kind, code) {
    const s = settings();
    if (!toId(s.name)) { toast('Enter your Showdown name first.', 'err'); return; }
    if (!app.battleUrl()) { toast('Link to your PC, or set a pairing server on the Link tab.', 'err'); return; }
    try {
      client?.close();
      client = app.client(app.battleUrl());
      await client.connect();
      client.on(MSG.MATCHED, (m) => {
        stopMotion();
        waiting = null;
        app.rememberFriend(m.opponent);
        app.platform.vibrate([60, 40, 60]);
        if (document.hidden) app.platform.notify('Battle found', `${m.opponent.name} wants to battle. Tap to open Showdown.`);
        toast(m.role === 'challenge' ? `Matched with ${m.opponent.name}. Sending the challenge on Showdown…` : `Matched with ${m.opponent.name}. Accepting their challenge on Showdown…`, 'ok');
        client.close(); client = null;
        render();
        if (app.native) app.openShowdown({ action: m.role, opponent: m.opponent.showdown, format: m.format });
        else matchedNote = m;
        render();
      });
      client.on(MSG.NO_MATCH, (m) => { if (!m.cancelled) toast(m.message, 'err'); });
      client.on(MSG.ERROR, (m) => toast(m.message, 'err'));
      client.on(MSG.WAITING, (m) => {
        waiting = m; render();
        if (m.mode === 'bump') startMotion();
        if (m.mode === 'bump' && autoBumpAt) { bump(Date.now() - autoBumpAt); autoBumpAt = null; }
      });
      client.send(MSG.FIND, { mode: kind, code, name: app.save.trainer.name, showdown: s.name, format: s.format, server: s.server, capsules: app.myCapsuleIds() });
    } catch (e) { toast(e.message, 'err'); }
  }
  let matchedNote = null;

  function bump(elapsed = 0) {
    try { client?.send(MSG.BUMP, { elapsed }); app.platform.vibrate([30]); sfx('blip'); } catch { /* not connected */ }
  }
  function startMotion() {
    let last = 0;
    const onMotion = (e) => {
      const a = e.acceleration;
      const g = a && a.x != null ? Math.hypot(a.x, a.y, a.z) : Math.max(0, Math.hypot(e.accelerationIncludingGravity?.x || 0, e.accelerationIncludingGravity?.y || 0, e.accelerationIncludingGravity?.z || 0) - 9.8);
      const now = performance.now();
      if (g > 22 && now - last > 1200) { last = now; bump(0); }
    };
    window.addEventListener('devicemotion', onMotion);
    motionOff = () => window.removeEventListener('devicemotion', onMotion);
  }
  function stopMotion() { motionOff?.(); motionOff = null; }
  function cancel() {
    try { client?.send(MSG.CANCEL); } catch { /* ignore */ }
    client?.close(); client = null; waiting = null; stopMotion(); render();
  }

  function openButton(label = 'Open Showdown') {
    const s = settings();
    return app.platform.canEmbedShowdown
      ? h('button', { class: 'btn primary', disabled: !app.team().length, onclick: () => app.openShowdown({}) }, label)
      : h('a', { class: 'btn primary', href: s.server, target: '_blank', rel: 'noopener' }, label);
  }

  function friendsPanel() {
    const friends = Object.values(app.save.friends ?? {});
    return h('section', { class: 'panel col' },
      h('h2', null, 'Friends'),
      friends.length ? friends.map((f) => h('div', { class: 'row' },
        h('div', { class: 'grow' }, h('div', null, f.name), h('div', { class: 'micro dim' }, `${f.showdown} on Showdown${f.capsules?.length ? ` · ${f.capsules.length} capsule${f.capsules.length > 1 ? 's' : ''}` : ''}`)),
        h('button', { class: 'btn small', disabled: !app.platform.canEmbedShowdown, onclick: () => app.openShowdown({ action: 'challenge', opponent: f.showdown }) }, 'Challenge')))
        : h('p', { class: 'dim' }, 'Friends you battle by bump or code are saved here. After that, knocking your capsules together starts a battle with no PC or server needed.'),
      h('button', { class: 'btn small', onclick: async () => {
        const name = await promptDialog('Add a friend', 'Their Showdown name', '', { maxLength: 18, ok: 'Add' });
        if (name && toId(name)) app.rememberFriend({ name: name.trim(), showdown: name.trim(), capsules: [] });
        render();
      } }, 'Add by Showdown name'));
  }

  // ---------- wild battles, on the phone (the same 2.5D battle as the PC, laid out for a phone) ----------
  let wildBusy = false;
  async function goWild() {
    if (wildBusy) return;
    wildBusy = true; render();
    try {
      let SD;
      try { SD = await loadShowdown(); } catch (e) { toast(e.message, 'err'); return; }
      const place = app.settings.wildBiome ?? 'meadow';
      const team = app.battleTeam();
      const knowsSp = (sp) => SD.knows('species', sp.showdownName || sp.name);
      const seed = Date.now();
      const pl = battlePlace(place);
      const findIn = pl.find ? pl.find[Math.floor(Math.random() * pl.find.length)] : null;
      const w = rollWild(app.idx, app.save, { biome: findIn, seed, known: knowsSp, party: team });
      if (!w) { toast('Showdown doesn’t know any of your data set’s species yet (set their Showdown names on the PC).', 'err'); return; }
      const teams = wildTeams(app.idx, app.save, w, SD.knows, team);
      if (!teams.team.length) { toast(teams.left.length ? `Showdown doesn’t know ${teams.left.join(', ')}: set their Showdown names on the PC.` : 'Nobody with you can battle right now (they need to heal first).', 'err'); return; }
      if (teams.left.length) toast(`${teams.left.join(', ')} can’t battle on Showdown, so they sit this one out.`);
      app.platform.vibrate?.([40]);
      const res = await playWildBattle({ settings: app.save.settings ?? {}, idx: app.idx, bank: app.bank, resolve: (p) => app.textures.files[p.toLowerCase()] ?? null, trainer: app.save.trainer?.name ?? 'You',
        cardSprite: app.save.trainer?.card?.avatar?.sprite || '', sdAvatar: settings().avatar || '', sound: (app.settings.battleSound ?? app.settings.sound) !== false, volume: app.settings.battleVolume ?? app.settings.volume ?? 0.6, onVolume: (v) => app.local((st) => { st.settings.battleVolume = v; }), onSound: (on) => app.local((st) => { st.settings.battleSound = on; }), creatures: app.save.creatures, bag: battleBag(app.idx, app.save), onUseItem: (id) => app.record(makeEvent('items', { delta: { [id]: -1 } })) }, teams, { biome: place, seed });
      const r = wildOutcome(app.idx, w, res, teams.map);
      // kept here and sent to the PC on the next sync, like everything else done on the phone
      app.record(makeEvent('wild', { result: r }));
      if (r.won) toast(`Won against the wild ${teams.foeName}!`, 'ok');
      else if (!r.ran) toast('Everyone needs a rest. They heal over time.', 'err');
    } catch (e) { console.error(e); toast(`The battle stopped: ${e.message}`, 'err'); }
    finally { wildBusy = false; render(); }
  }
  function wildPanel(team) {
    const place = app.settings.wildBiome ?? 'meadow';
    return h('section', { class: 'panel col m-wild' },
      h('h2', null, 'Battle a wild creature'),
      h('p', { class: 'dim' }, 'Your team against something wild, as a 2.5D battle on Showdown’s engine. ★ places are arenas where anything can turn up. Turn your phone sideways for the full screen.'),
      h('label', { class: 'm-field' }, h('span', null, 'Where'),
        h('select', { onchange: (e) => { app.local((st) => { st.settings.wildBiome = e.target.value; }); render(); } },
          BATTLE_PLACES.map((p) => h('option', { value: p.id, selected: p.id === place }, p.label)))),
      h('button', { class: 'btn wide big', disabled: wildBusy || !team.length, onclick: goWild }, wildBusy ? 'Starting…' : 'Look for one'),
      app.platform.canWildAlerts ? h('div', { class: 'col wild-alerts' },
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!app.settings.wildAlerts?.on, onchange: async (e) => {
          const on = e.target.checked;
          if (on) await app.platform.permissions?.({ notifications: true });
          app.local((st) => { st.settings.wildAlerts = { ...(st.settings.wildAlerts ?? {}), on }; }); app.syncWildAlerts(); render();
        } }), 'Wild creatures can find me (notifications)'),
        app.settings.wildAlerts?.on ? h('label', { class: 'field' }, h('span', null, 'How often'), h('select', { onchange: (e) => { app.local((st) => { st.settings.wildAlerts = { ...(st.settings.wildAlerts ?? {}), every: e.target.value }; }); app.syncWildAlerts(); } },
          [['often', 'Often (every 30–75 min)'], ['normal', 'Now and then (every 1–3 h)'], ['rare', 'Rarely (every 3–6 h)']].map(([v, l]) => h('option', { value: v, selected: (app.settings.wildAlerts?.every ?? 'normal') === v }, l)))) : null,
        h('p', { class: 'micro dim' }, 'Even with the app closed, a notification says a wild creature has appeared; tap it to battle. None between 10 pm and 8 am.')) : null,
      (() => { const cost = healCost(app.idx, app.save, team.map((c) => c.uid)); return h('button', { class: 'btn wide', disabled: !team.length, onclick: () => { const r = app.record(makeEvent('center', { party: team.map((c) => c.uid) })); if (r && r.ok === false) toast(r.error, 'err'); else toast(r?.healed ? `Your team is fully healed${r.cost ? ` (${r.cost} coins)` : ''}. We hope to see you again!` : 'Everyone’s already in perfect health.', 'ok'); render(); } }, cost ? `Heal team (🪙 ${cost})` : 'Heal team'); })());
  }

  const battleCtx = () => ({ settings: app.save.settings ?? {}, idx: app.idx, bank: app.bank, resolve: (p) => app.textures.files[p.toLowerCase()] ?? null, trainer: app.save.trainer?.name ?? 'You',
    cardSprite: app.save.trainer?.card?.avatar?.sprite || '', sdAvatar: settings().avatar || '', sound: (app.settings.battleSound ?? app.settings.sound) !== false, volume: app.settings.battleVolume ?? app.settings.volume ?? 0.6, creatures: app.save.creatures, biome: 'stadium' });
  const goOnline = async () => {
    try {
      const SD = await loadShowdown(), team = app.battleTeam();
      await openShowdownOnline(battleCtx(), {
        party: () => wildTeams(app.idx, app.save, { speciesId: app.idx.ds.species[0].id, level: 5, seed: 1 }, SD.knows, team),
        fetchText: async (u) => { const r = await fetch(u); if (!r.ok) throw new Error(`Showdown answered ${r.status}`); return r.text(); },
        dialog, getName: () => app.settings.showdownOnlineName || settings().name || app.save.trainer?.name, setName: (n) => app.local((st) => { st.settings.showdownOnlineName = n; }),
      });
    } catch (e) { toast(e.message, 'err'); }
  };
  const goReplay = async (link = '') => {
    try { await watchReplay({ ...battleCtx(), cardSprite: '', sdAvatar: '' }, { link, fetchText: async (u) => { const r = await fetch(u); if (!r.ok) throw new Error(`the replay site answered ${r.status}`); return r.text(); }, dialog }); } catch (e) { toast(e.message, 'err'); }
  };

  // ---------- your team: the order, who fights, their moves (like the PC's “Change your party”) ----------
  function setOrder(uids) { app.local((st) => { st.settings.teamOrder = uids; }); render(); }
  function teamEditPanel(team) {
    const off = app.settings.benched ?? {};
    const move = (i, d) => { const u = team.map((c) => c.uid); const j = i + d; if (j < 0 || j >= u.length) return; [u[i], u[j]] = [u[j], u[i]]; setOrder(u); };
    return h('section', { class: 'panel col m-team-edit' },
      h('h2', null, 'Your team'),
      team.length ? h('p', { class: 'micro dim' }, 'The first one leads. Untick “Battles” to keep someone with you but out of battles.') : h('p', { class: 'dim' }, 'Nobody’s with you yet. Bring someone from the PC (With you tab).'),
      team.map((c, i) => h('div', { class: 'm-team-row', style: { display: 'flex', gap: '8px', alignItems: 'center', padding: '6px 0', borderTop: '1px solid var(--line, rgba(0,0,0,.08))' } },
        h('span', { style: { display: 'flex', flexDirection: 'column', gap: '2px', flex: 'none' } },
          h('button', { class: 'btn small icon', style: { width: '34px', minWidth: 0, padding: '2px 0' }, disabled: i === 0, 'aria-label': `Move ${displayName(app.idx, c)} up`, onclick: () => move(i, -1) }, '▲'),
          h('button', { class: 'btn small icon', style: { width: '34px', minWidth: 0, padding: '2px 0' }, disabled: i === team.length - 1, 'aria-label': `Move ${displayName(app.idx, c)} down`, onclick: () => move(i, 1) }, '▼')),
        spriteCanvas(app.bank, c, { scale: 1 }),
        h('span', { class: 'grow col', style: { gap: '2px', minWidth: 0 } }, h('strong', null, displayName(app.idx, c)), h('span', { class: 'micro dim', style: { overflow: 'hidden', textOverflow: 'ellipsis' } }, (c.moves ?? []).map((m) => app.idx.moves.get(m.id)?.name ?? m.id).join(' · ') || 'no moves')),
        h('label', { class: 'check', style: { flex: 'none', fontSize: '13px' } }, h('input', { type: 'checkbox', checked: !off[c.uid], onchange: (e) => { app.local((st) => { st.settings.benched = { ...(st.settings.benched ?? {}), [c.uid]: !e.target.checked || undefined }; }); render(); } }), 'Battles'),
        h('button', { class: 'btn small', style: { width: 'auto', flex: 'none' }, onclick: () => swapMoves(c) }, 'Moves'))));
  }
  // change a move: one it knew before, one its kind learns by its level, or a TM (sent to the PC with the next sync)
  async function swapMoves(c) {
    const ids = (c.moves ?? []).map((m) => m.id);
    const slot = await chooseDialog(`${displayName(app.idx, c)}’s moves`, [...ids.map((id, i) => ({ value: i, label: app.idx.moves.get(id)?.name ?? id, detail: 'Swap this one' })), ...(ids.length < 4 ? [{ value: ids.length, label: '+ Add a move', detail: 'There’s room for another' }] : [])]);
    if (slot == null) return;
    const opts = moveChoices(app.idx, app.save, c).filter((m) => !ids.includes(m.id));
    if (!opts.length) { toast('No other moves to pick from yet. Level up, or buy a TM at the Market on the PC.', 'err'); return; }
    const WHY = { past: 'learned before', level: 'learns by its level', tm: 'TM in your bag' };
    const pick = await chooseDialog('Pick a move', opts.map((m) => { const mv = app.idx.moves.get(m.id); return { value: m.id, label: m.name, detail: `${WHY[m.why] ?? ''} · ${mv?.type ?? ''} · ${mv?.category === 'status' ? 'status' : `${mv?.power || '—'} power`}` }; }));
    if (!pick) return;
    app.record(makeEvent('learn', { uid: c.uid, slot: Number(slot), move: pick }));
    toast(`${displayName(app.idx, c)} learned ${app.idx.moves.get(pick)?.name ?? 'it'}!`, 'ok');
    render();
  }
  // ---------- famous trainers ----------
  let trainersOpen = false;
  async function famousBattle(t) {
    if (wildBusy) return;
    const team = app.battleTeam();
    if (!team.length) { toast('Take someone along first (With you tab).', 'err'); return; }
    const top = Math.max(...team.map((c) => c.level ?? 5)), real = Math.max(...t.team.map((m) => m.level));
    const how = await chooseDialog(`${t.name} wants to battle!`, [
      { value: 'match', label: `Match their levels to yours (up to Lv. ${Math.min(100, top + 2)})`, detail: `${t.name}’s team from ${t.title}, brought to your team’s level.` },
      { value: 'real', label: `Their real levels (up to Lv. ${real})`, detail: `Exactly as in ${t.title}. Good luck.` }]);
    if (!how) return;
    wildBusy = true; render();
    try {
      const SD = await loadShowdown();
      const sets = famousTeam(t, { matchLevel: how === 'match' ? Math.min(100, top + 2) : null, knows: SD.knows });
      if (!sets.length) { toast('Showdown couldn’t field that team.', 'err'); return; }
      const anySp = app.idx.ds.species.find((sp) => SD.knows('species', sp.showdownName || sp.name)) ?? app.idx.ds.species[0];
      const w = { speciesId: anySp.id, level: sets[0].level, seed: Date.now() };
      const teams = wildTeams(app.idx, app.save, w, SD.knows, team);
      if (!teams.team.length) { toast('Nobody with you can battle right now (they need to heal first).', 'err'); return; }
      const made = new Map();
      Object.assign(teams, { foeTeam: sets, foe: sets[0], foeTrainerName: t.name, foeAvatar: t.avatar,
        foeFor: (mon, bySd) => { const k = mon.name || mon.species; if (!made.has(k)) { const sid = bySd.get(String(mon.species).toLowerCase().replace(/[^a-z0-9]+/g, '')) ?? anySp.id; made.set(k, createCreature(app.idx, sid, { level: mon.level, seed: made.size + 7, location: { kind: 'wild' } })); } return made.get(k); } });
      const res = await playWildBattle({ ...battleCtx(), foeTrainer: `https://play.pokemonshowdown.com/sprites/trainers/${t.avatar}.png` }, teams, { biome: 'stadium', seed: w.seed });
      const r = wildOutcome(app.idx, w, { ...res, won: false }, teams.map);
      app.record(makeEvent('wild', { result: r, famous: res.won ? t.name : undefined }));
      if (res.won) toast(`You beat ${t.name}! (+200 coins)`, 'ok'); else if (!res.ran) toast(`${t.name} won this time.`, 'err');
    } catch (e) { console.error(e); toast(`The battle stopped: ${e.message}`, 'err'); }
    finally { wildBusy = false; render(); }
  }
  function trainersPanel() {
    const wins = app.save.stats?.famousWins ?? {};
    return h('section', { class: 'panel col' },
      h('h2', null, 'Battle a trainer'),
      h('p', { class: 'dim' }, 'Famous trainers from the series, with their real teams. Beat one for 200 coins.'),
      (trainersOpen ? FAMOUS_TRAINERS : FAMOUS_TRAINERS.slice(0, 4)).map((t) => h('div', { class: 'row' },
        h('div', { class: 'grow' }, h('div', null, `${t.name}${wins[t.name] ? ' ✓' : ''}`), h('div', { class: 'micro dim' }, `${t.title} · ${t.team.length} Pokémon`)),
        h('button', { class: 'btn small', disabled: wildBusy || !app.battleTeam().length, onclick: () => famousBattle(t) }, 'Battle'))),
      h('button', { class: 'btn small', onclick: () => { trainersOpen = !trainersOpen; render(); } }, trainersOpen ? 'Fewer' : `Show all ${FAMOUS_TRAINERS.length}`));
  }

  function render() {
    const s = settings();
    const team = app.battleTeam();
    mount(el,
      result ? h('section', { class: 'panel col' }, result, h('button', { class: 'btn wide', onclick: () => { result = null; render(); } }, 'Done')) : null,
      h('h1', null, 'Battle'),
      h('p', { class: 'dim' }, 'Battles are played on Showdown with your creatures. Experience, friendship and new moves come back here when the battle ends.'),
      wildPanel(team),
      teamEditPanel(app.team()),
      trainersPanel(),
      matchedNote && !app.native ? h('p', { class: 'note' }, `Matched with ${matchedNote.opponent.name} (${matchedNote.opponent.showdown}). In Showdown, ${matchedNote.role === 'challenge' ? 'challenge them' : 'accept their challenge'} with your imported team.`) : null,
      h('section', { class: 'panel col' },
        h('h2', null, 'Battle online'),
        h('p', { class: 'dim' }, 'Real battles on Pokémon Showdown’s server, on the app’s battle screen: a Random Battle, your own team, or a challenge to or from anyone by name.'),
        h('button', { class: 'btn wide big', onclick: goOnline }, '🌐 Battle online'),
        h('h3', null, 'Someone nearby'),
        waiting ? [
          h('p', { class: 'waiting' }, waiting.mode === 'bump' ? 'Bump your phones together, or knock your capsules together.' : `Battle code ${waiting.code}. Your friend enters it in their app.`),
          h('button', { class: 'btn wide', onclick: cancel }, 'Stop waiting'),
        ] : [
          h('button', { class: 'btn wide', disabled: !team.length, onclick: () => find('bump') }, 'Bump to battle'),
          h('div', { class: 'row' },
            h('input', { type: 'text', placeholder: 'Code', maxLength: 8, id: 'code-in' }),
            h('button', { class: 'btn', disabled: !team.length, onclick: () => find('code', document.getElementById('code-in').value.trim().toUpperCase()) }, 'Join or host')),
          h('p', { class: 'micro dim' }, app.battleUrl() ? 'Pairing goes through your PC or pairing server; the battle itself is on Showdown.' : 'Bump and code pairing need your PC or a pairing server (Link tab). Friends below work without one.'),
        ]),
      friendsPanel(),
      showdownSettingsPanel(app.save, (fn) => { fn(app.save); app.persist(); }),
      teamPanel(app.sdCtx(), { actions: openButton() }),
      resultPanel(app.sdCtx(), (res) => { result = res; render(); }, { onWatch: (link) => goReplay(link) }),
      historyPanel(app.sdCtx()));
    void s;
  }
  render();
  return {
    el,
    update: () => render(),
    /** A capsule bump arrived (no known friend nearby): pair through the PC or pairing server. */
    autoBump(at) {
      if (!app.battleUrl()) { toast('Bump recorded. Link to your PC or a pairing server (Link tab) to find the other player.', 'err'); return; }
      if (!app.team().length) { toast('Take creatures along first (Party tab).', 'err'); return; }
      if (waiting?.mode === 'bump') { bump(Date.now() - at); return; }
      autoBumpAt = at;
      find('bump');
    },
    dispose() { stopMotion(); if (waiting) cancel(); offs.forEach((o) => o()); },
  };
}

// ---------------- link & settings ----------------
export function linkView(app) {
  const el = h('div', { class: 'm-link' });
  let tab = 'link';
  function render() {
    const s = app.settings;
    // two tabs: linking up, and this phone's settings (graphics, sound, sky)
    const tabs = h('div', { class: 'seg m-link-tabs', role: 'tablist' }, [['link', '🔗 Link'], ['settings', '⚙️ Settings']].map(([k, l]) => h('button', { role: 'tab', 'aria-pressed': String(tab === k), 'aria-selected': String(tab === k), style: { fontSize: '15px', padding: '8px 16px' }, onclick: () => { tab = k; render(); } }, l)));
    if (tab === 'settings') {
      mount(el, h('h1', null, 'Link'), tabs,
        h('section', { class: 'panel col' }, h('h2', null, 'Graphics'),
          qualitySlider(h, { onChange: () => render() }),
          h('p', { class: 'micro dim' }, 'Used everywhere on this phone: battles, activities, quality time and walks. Lower it if things feel slow or the phone gets warm.'),
          threeDBlock(),
          h('p', { class: 'micro dim' }, '3D works the phone hard: at Low or Medium quality it uses simpler models and no shadows.')),
        settingsPanel(app, s, render),
        aboutPanel(app));
      return;
    }
    mount(el,
      h('h1', null, 'Link'), tabs,
      idPanel(app, render),
      s.hubUrl ? h('section', { class: 'panel col' },
        h('div', { class: 'row' }, h('span', { class: 'dot on' }), h('span', { class: 'grow ell' }, s.hubUrl)),
        h('div', { class: 'dim' }, `Last sync ${timeAgo(s.lastSync)} · ${app.save.queue.length} change${app.save.queue.length === 1 ? '' : 's'} waiting`),
        h('button', { class: 'btn primary wide', onclick: async () => { try { await app.sync(); } catch (e) { toast(e.message, 'err'); } } }, 'Sync now'),
        h('button', { class: 'btn wide', onclick: async () => {
          if (!(await confirmDialog('Unlink this phone?', 'Creatures on the phone stay here. Link again with a new pairing code.', { ok: 'Unlink', danger: true }))) return;
          app.local((st) => { st.settings.hubUrl = ''; st.settings.token = null; });
        } }, 'Unlink')) : h('section', { class: 'panel col' }, h('h2', null, 'Link to your PC'), linkForm(app, () => render())),
      h('section', { class: 'panel col' },
        h('h2', null, 'Pairing server'),
        h('p', { class: 'dim' }, 'Used to pair phones for bump and code battles. Leave empty to pair through your PC; away from home, enter a relay address (see the README).'),
        h('input', { type: 'url', value: s.battleUrl || '', placeholder: s.hubUrl || 'ws://relay.example:47820', onchange: (e) => app.local((st) => { st.settings.battleUrl = e.target.value.trim(); }) })),
      backupPanel(app),
      h('section', { class: 'panel col' },
        h('h2', null, 'Debug tools'),
        h('p', { class: 'dim' }, 'Ball hardware and the USB-C link, for testing.'),
        h('button', { class: 'btn', onclick: () => app.go('debug') }, 'Open debug tools')),
      h('p', { class: 'micro faint center' }, `Data set: ${app.idx.ds.meta?.name ?? ''} · ${app.idx.ds.species.length} species`));
  }
  render();
  return { el, update: render };
}
function settingsPanel(app, s, render) {
  return h('section', { class: 'panel col' },
        h('h2', null, 'This phone'),
        homeIconRow(app),
        h('label', { class: 'field' }, h('span', null, 'Trainer name'), h('input', { type: 'text', maxLength: 10, value: app.save.trainer.name, onchange: (e) => app.local((st) => { st.trainer.name = e.target.value.trim().slice(0, 10) || 'Trainer'; }) })),
        h('label', { class: 'field' }, h('span', null, 'Phone name (shown on the PC)'), h('input', { type: 'text', maxLength: 20, value: s.deviceName, onchange: (e) => app.local((st) => { st.settings.deviceName = e.target.value.trim() || 'My phone'; }) })),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.sound !== false, onchange: (e) => { app.local((st) => { st.settings.sound = e.target.checked; }); setSound(e.target.checked, s.volume ?? 0.6); } }), 'Sounds and cries'),
        h('label', { class: 'field' }, h('span', null, 'Volume'), h('input', { type: 'range', class: 'big-range', min: 0, max: 1, step: 0.05, value: s.volume ?? 0.6, 'aria-label': 'Volume', onchange: (e) => { const v = Number(e.target.value); app.local((st) => { st.settings.volume = v; }); setSound(s.sound !== false, v); } })),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: (s.battleSound ?? s.sound) !== false, onchange: (e) => app.local((st) => { st.settings.battleSound = e.target.checked; }) }), 'Battle sounds and music'),
        skySettingsBlock({ settings: s, quality: false, set: (fn) => { app.local((st) => fn(st.settings)); render(); } }),
        h('label', { class: 'field' }, h('span', null, 'Battle volume'), h('input', { type: 'range', class: 'big-range', min: 0, max: 1, step: 0.05, value: s.battleVolume ?? s.volume ?? 0.6, 'aria-label': 'Battle volume', onchange: (e) => app.local((st) => { st.settings.battleVolume = Number(e.target.value); }) })),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!s.watchBumps, onchange: async (e) => {
          const on = e.target.checked;
          if (on) { const p = await app.platform.permissions({ bluetooth: true }); if (p?.bluetooth === 'denied') { toast('Allow nearby devices so the app can hear your capsules.', 'err'); e.target.checked = false; return; } await app.platform.startBeacons(); }
          else await app.platform.stopBeacons();
          app.local((st) => { st.settings.watchBumps = on; });
        } }), 'Listen for capsule bumps (Bluetooth)'));
}


/** The trainer ID card. With a PC linked, the PC's card wins; without one it can be edited here. */
function cardScale(card, tall = 0.5) {
  const avail = Math.min(window.innerWidth || 360, 520) - 72;
  const portrait = card?.design === 'badge' || card?.design === 'field';
  const w = portrait ? 150 : 240, hgt = portrait ? 240 : 150;
  const fit = Math.min(avail / w, ((window.innerHeight || 700) * tall) / hgt);
  return Math.max(1, Math.floor(fit * 2) / 2);
}
function idPanel(app, rerender) {
  const t = app.save.trainer;
  const linked = !!app.settings.hubUrl;
  return h('section', { class: 'panel col m-id' },
    h('h2', null, 'Trainer ID'),
    h('button', { class: 'm-id-card', 'aria-label': 'Show your trainer ID', onclick: () => dialog('Trainer ID', (close) => h('div', { class: 'col center-items' },
      idCardEl(t, { scale: cardScale(t.card, 0.62), party: partyForCard(app.bank, app.team(), (c) => displayName(app.idx, c)) }),
      h('p', { class: 'micro dim center' }, 'Tilt the card to catch the light; swipe it sideways to see the back.'),
      h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: () => close() }, 'Done')))) }, idCardEl(t, { scale: cardScale(t.card, 0.42), flip: false })),
    linked ? h('p', { class: 'micro dim' }, 'This card comes from your PC. Change it on the PC under Trainer ID; it updates here on the next sync.')
      : h('button', { class: 'btn wide', onclick: () => {
        let ed;
        dialog('Edit trainer ID', (close) => {
          ed = cardEditor({ trainer: t, editName: true, scale: 1, party: partyForCard(app.bank, app.team(), (c) => displayName(app.idx, c)) });
          return h('div', { class: 'col' }, ed.el, h('div', { class: 'actions' },
            h('button', { class: 'btn', onclick: () => close() }, 'Cancel'),
            h('button', { class: 'btn primary', onclick: () => { const v = ed.value(); app.local((st) => { st.trainer.name = v.name; st.trainer.card = v.card; }); close(); rerender(); } }, 'Save')));
        });
      } }, 'Edit card'));
}


/** The name and icon chosen on the PC, on this phone's home screen. */
function homeIconRow(app) {
  const files = app.textures?.files ?? {};
  const src = files['ui/app-icon.png'] ?? files['ui/logo.png'] ?? null;
  const name = brandText('Capsule Link');
  return h('div', { class: 'home-icon-row' },
    src ? h('img', { src, alt: '', class: 'home-icon' }) : logoMark(44),
    h('div', { class: 'grow' }, h('div', null, name), h('div', { class: 'micro dim' }, app.settings.hubUrl ? 'Name, pictures and wording come from your PC on every sync.' : 'Link a PC to bring over its names, pictures and wording.')),
    app.platform.canPinShortcut ? h('button', { class: 'btn small', onclick: async () => {
      try {
        await app.platform.pinShortcut(name, src ? src.split(',')[1] : null);
        toast('Look for it on your home screen. You can remove the original icon there; the app stays in your app drawer.', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    } }, 'Add to home screen') : null);
}


/** Backups of everything on this phone: download, keep on the PC, and put back. */
function downloadText(name, text) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  a.download = name;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 60000);
}
function backupPanel(app) {
  const linked = !!app.settings.hubUrl;
  const restore = async (text, label) => {
    const r = readBackup(text);
    if (!r.ok) return toast(r.error, 'err');
    if (r.kind !== 'phone') return toast(r.kind === 'pc' ? 'That is a PC backup: restore it in the PC app (Settings → Backups).' : 'That is a save from the PC, not a phone backup.', 'err');
    if (!(await confirmDialog('Put this backup back?', `${label ? `${label}: ` : ''}${r.summary}. Everything on this phone is replaced with it and the app starts over. Creatures already back on the PC stay there.`, { ok: 'Restore', danger: true }))) return;
    try { app.restoreBackup(text); toast('Restored. Starting over…', 'ok'); } catch (e) { toast(e.message, 'err'); }
  };
  const before = h('span');
  app.beforeUpdateBackup().then((b) => {
    if (b) mount(before, h('button', { class: 'btn small', onclick: () => restore(JSON.stringify(b), 'From just before the last update') }, 'Restore from before the last update'));
  });
  return h('section', { class: 'panel col' },
    h('h2', null, 'Backups'),
    h('p', { class: 'dim' }, 'Everything on this phone in one file: creatures with you, items, capsules, the PC link and steps not synced yet.'),
    h('div', { class: 'btn-group' }, h('div', { class: 'btn-group-head' }, 'Make one'),
      h('button', { class: 'btn primary', onclick: () => { downloadText(app.backupName(), app.backupText()); sfx('level'); toast(app.native ? 'Look in Downloads. If nothing arrived, use Keep on PC.' : 'Backup downloaded.', 'ok'); } }, 'Download backup'),
      linked ? h('button', { class: 'btn', onclick: async () => { try { await app.sendBackup(); sfx('level'); toast('Kept on your PC (Settings → Backups there).', 'ok'); } catch (e) { toast(e.message, 'err'); } } }, 'Keep on PC') : null),
    h('p', { class: 'micro dim' }, linked ? `Your PC also keeps one by itself each day and before every update${app.settings.lastPcBackup ? ` (last ${timeAgo(app.settings.lastPcBackup)})` : ''}.` : 'Link a PC and it keeps one each day by itself.'),
    h('div', { class: 'btn-group' }, h('div', { class: 'btn-group-head' }, 'Restore'),
      h('label', { class: 'btn small' }, 'Restore from a file', h('input', { type: 'file', accept: '.json,application/json', class: 'hidden', onchange: async (e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) restore(await f.text()); } })),
      linked ? h('button', { class: 'btn small', onclick: async () => {
        let list;
        try { list = await app.pcBackups(); } catch (e) { return toast(e.message, 'err'); }
        if (!list.length) return toast('Your PC has no phone backups yet.', 'err');
        const file = await dialog('Backups on your PC', (close) => h('div', { class: 'col' },
          list.slice(0, 12).map((b) => h('button', { class: 'btn wide left', onclick: () => close(b.file) },
            h('div', { class: 'col tight' }, h('strong', null, new Date(b.at).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })), h('span', { class: 'micro dim' }, b.summary)))),
          h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(null) }, 'Cancel'))));
        if (!file) return;
        try { restore(await app.pcBackup(file)); } catch (e) { toast(e.message, 'err'); }
      } }, 'Restore from your PC') : null,
      before));
}

/** Version, updates from the PC, and going back to the version inside the app. */
function aboutPanel(app) {
  const BUILD = typeof __BUILD__ !== 'undefined' ? __BUILD__ : { version: '?' };
  const info = h('p', { class: 'dim' }, `Version ${BUILD.version}`);
  const actions = h('div', { class: 'row wrap' });
  const fp = h('p', { class: 'micro faint' });
  const repo = h('input', { type: 'text', placeholder: 'yourname/capsule-link', value: app.settings.githubRepo ?? '', 'aria-label': 'Your GitHub repository', onchange: (e) => app.local((s) => { s.settings.githubRepo = e.target.value.trim(); }) });
  const gh = h('div', { class: 'btn-group' },
    h('div', { class: 'btn-group-head' }, 'New builds from GitHub'),
    h('p', { class: 'micro dim', style: { margin: 0 } }, 'Your GitHub repository (the one that builds the apps). The app checks it now and then, and installs a new build over this one: no uninstalling, nothing lost.'),
    repo, h('button', { class: 'btn small', onclick: () => { app.local((s) => { s.settings.githubRepo = repo.value.trim(); }); app.checkGithub(); } }, 'Check GitHub now'));
  const steps = h('div', { class: 'btn-group' },
    h('div', { class: 'btn-group-head' }, 'Steps while the app is closed'),
    h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: app.settings.backgroundSteps !== false, onchange: async (e) => { const ok = await app.setBackgroundSteps(e.target.checked); if (!ok) e.target.checked = !e.target.checked; else toast(e.target.checked ? 'Steps are counted even with the app closed.' : 'Steps are only counted with the app open or on a walk.', 'ok'); } }),
      'Keep counting steps when the app is closed'),
    h('p', { class: 'micro dim', style: { margin: 0 } }, 'Uses the phone’s own step counter (no battery-hungry tracking): your buddy gets the steps the next time you open the app.'));
  const el = h('section', { class: 'panel col' }, h('h2', null, 'About this app'), info, fp,
    h('p', { class: 'micro dim' }, 'Most updates come from your PC: when an update file is installed there, this phone offers it on its next sync. When the Android part of the app changes too, get the new build from GitHub below.'), actions, steps, gh);
  app.platform.appInfo().then((r) => {
    const updated = r?.updated?.version;
    if (updated) info.textContent = `Version ${BUILD.version}, updated from your PC (the app itself came with v${r.builtIn?.version ?? '?'}).`;
    info.title = `Android build ${r?.builtIn?.phoneNative ?? BUILD.phoneNative ?? '?'}`;
    mount(fp, `Android build: ${r?.builtIn?.phoneNative || BUILD.phoneNative || '?'}`);
    mount(actions,
      app.pendingUpdate ? h('button', { class: 'btn small primary', onclick: () => { app.updating = false; app.offerUpdate(app.pendingUpdate); } }, `Install update v${app.pendingUpdate.version}`) : null,
      app.settings.hubUrl ? h('button', { class: 'btn small', onclick: async () => {
        app.local((s) => { s.settings.declinedUpdate = null; });
        try { await app.sync({ quiet: true }); } catch (e) { toast(e.message, 'err'); return; }
        const s = app.appStatus;
        if (!s) toast('Your PC app is too old to send phone updates. Install the latest update file on the PC first.', 'err');
        else if (s.state === 'none') toast('Your PC has no phone update yet. Install the update file on the PC first.');
        else if (s.state === 'current') toast(`Up to date (v${BUILD.version}).`, 'ok');
        else if (s.state === 'native') app.askUpdateAnyway();
        // 'offered': the update dialog opens by itself
      } }, 'Check for an update') : null,
      updated ? h('button', { class: 'btn small', onclick: async () => {
        if (!(await confirmDialog('Go back?', `Use v${r.builtIn?.version ?? '?'}, the version that came with the app? Your creatures and settings stay.`, { ok: 'Go back' }))) return;
        app.local((s) => { s.settings.declinedUpdate = BUILD.version; });
        await app.platform.useBuiltIn();
      } }, 'Use the built-in version') : null);
  });
  return el;
}
