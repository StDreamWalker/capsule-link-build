// The PC's own screens on the phone: Data Lab, Friends and Trainer ID run as they are on the PC, on top of a
// stand-in for the PC app (pcFacade) that keeps everything in the phone's own save, data set and pictures.
// Changes to creatures and items go through adopt(), so they reach a linked PC with the next sync like
// anything else done on the phone. The data tools in Settings (Get everything, One thing at a time) use it too.
import { h, mount, toast } from '../../shared/ui/dom.js';
import { indexDataset, normalizeDataset } from '../../shared/engine/index.js';
import { setBrand } from '../../shared/ui/dom.js';
import { setUiArt } from '../../shared/ui/brandArt.js';
import { setCryResolver } from '../../shared/ui/audio.js';
import { dataLabView } from '../../desktop/src/renderer/views/datalab.js';
import { friendsView } from '../../desktop/src/renderer/views/friends.js';
import { trainerView } from '../../desktop/src/renderer/views/trainer.js';
import { kvGet, kvSet } from './kv.js';
import { isInnerUrl } from './innerPc.js';

const clone = (x) => JSON.parse(JSON.stringify(x));
const MIME = (p) => (/\.mp3$/i.test(p) ? 'audio/mpeg' : /\.ogg$/i.test(p) ? 'audio/ogg' : /\.wav$/i.test(p) ? 'audio/wav' : /\.gif$/i.test(p) ? 'image/gif' : 'image/png');
function toDataUrl(path, bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return `data:${MIME(path)};base64,${btoa(s)}`;
}
const fromDataUrl = (url) => { const m = /^data:[^;]+;base64,(.*)$/.exec(String(url)); if (!m) return null; const s = atob(m[1]); const out = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i); return out; };
// the PC's names for its screens → the phone's
const GO = { data: 'datalab', datalab: 'datalab', friends: 'friends', trainer: 'trainer', battle: 'battle', home: 'home', settings: 'settings', activities: 'together', atlas: 'atlas', link: 'link', phone: 'link' };

/** A stand-in for the PC app, over the phone app. */
export function pcFacade(app) {
  if (app._pcFacade) return app._pcFacade;
  let texTimer = null;
  const keepTextures = () => { clearTimeout(texTimer); texTimer = setTimeout(() => { kvSet('textures', app.textures).catch(() => toast('These pictures are too big to keep on this phone.', 'err')); kvSet('cries', app.cries).catch(() => {}); }, 1500); };
  // pictures (and cries) as the PC lists them: path → address
  const allFiles = () => ({ ...(app.textures?.files ?? {}), ...(app.cries?.files ?? {}) });
  function put(path, bytes) {
    const p = String(path).toLowerCase().replace(/\\/g, '/');
    const url = toDataUrl(p, bytes);
    if (p.startsWith('cries/')) { app.cries = { hash: 'local', files: { ...(app.cries?.files ?? {}), [p]: url } }; }
    else app.textures = { hash: 'local', files: { ...(app.textures?.files ?? {}), [p]: url } };
  }
  function applyTextures() {
    const files = app.textures.files;
    app.bank?.setResolver((q) => files[q.toLowerCase()] ?? null);
    setUiArt((q) => files[q.toLowerCase()] ?? null, () => Object.keys(files));
    setCryResolver((q) => app.cries?.files?.[q.toLowerCase()] ?? null);
    keepTextures();
  }
  const platform = {
    kind: 'phone',
    async fetchUrl(url, as = 'text') {
      // on the phone CapacitorHttp makes fetch native: no CORS
      const r = await fetch(url);
      if (!r.ok) return { ok: false, status: r.status, url: r.url };
      if (as === 'bytes') return { ok: true, status: r.status, url: r.url, bytes: new Uint8Array(await r.arrayBuffer()) };
      return { ok: true, status: r.status, url: r.url, text: await r.text() };
    },
    async importTexture(path, bytes) { put(path, bytes); applyTextures(); return allFiles(); },
    async importTextures(files) {
      const failed = [];
      for (const f of files) { try { put(f.path, f.data); } catch (e) { failed.push({ path: f.path, error: e.message }); } }
      applyTextures();
      return { list: allFiles(), failed };
    },
    async textures() { return allFiles(); },
    openTextures() { toast('On the phone, pictures are kept inside the app: add them with Choose files.'); },
    importFile(filters) {
      return new Promise((resolve) => {
        const input = document.createElement('input');
        input.type = 'file';
        const ext = (filters ?? []).flatMap((f) => f.extensions ?? []);
        if (ext.length) input.accept = ext.map((e) => `.${e}`).join(',');
        input.onchange = async () => { const f = input.files?.[0]; resolve(f ? { name: f.name, text: await f.text() } : null); };
        input.click();
      });
    },
    async exportFile(name, text) {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
      a.download = name; document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 60000);
      return { ok: true };
    },
    presets: {
      async list() { return ((await kvGet('dataPresets')) ?? []).map(({ dataset, ...p }) => { void dataset; return p; }); },
      async load(name) { return ((await kvGet('dataPresets')) ?? []).find((p) => p.name === name) ?? null; },
      async save(p) { const all = ((await kvGet('dataPresets')) ?? []).filter((x) => x.name !== p.name); all.push(p); await kvSet('dataPresets', all); },
    },
  };
  const fa = {
    phone: app,
    platform,
    get save() { return app.save; },
    get idx() { return app.idx; },
    get dataset() { return app.dataset; },
    get bank() { return app.bank; },
    get textures() { return allFiles(); },
    set textures(v) { const files = {}; const cries = {}; for (const [k, u] of Object.entries(v ?? {})) (k.startsWith('cries/') ? cries : files)[k] = u; app.textures = { hash: 'local', files }; app.cries = { hash: 'local', files: cries }; },
    applyTextures,
    homeDataset: null,
    /** A change to the save, made on a copy: creatures and items reach a linked PC with the next sync. */
    commit(fn) {
      const before = clone(app.save), after = clone(app.save);
      fn(after);
      app.adopt(before, after);
      return after;
    },
    async saveDataset(ds) {
      app.idx = indexDataset(normalizeDataset(ds));
      app.dataset = app.idx.ds; setBrand(app.dataset.brand);
      app.bank?.setDataset(app.idx);
      app.storeDataset();
      app.refresh();
    },
    useDataset(ds, label) { fa.homeDataset = fa.homeDataset ?? app.dataset; fa.saveDataset(ds); toast(`Using ${label}.`, 'ok'); },
    restoreDataset() { if (fa.homeDataset) { fa.saveDataset(fa.homeDataset); fa.homeDataset = null; } },
    say: (text, kind) => toast(text, kind),
    go(id) {
      const to = GO[id];
      if (to) { app.go(to); return; }
      if (app.fullPc) { toast('That’s one of the PC apps: opening them…'); app.openPcApps(); return; }
      toast('That’s on your PC (or turn on Full PC mode in Settings → Debug).');
    },
    refresh() { app.refresh(); },
    renderTop() { app.renderTop(); },
  };
  app._pcFacade = fa;
  return fa;
}

/** Whether the phone's data set comes from a PC (so changes made here are replaced at the next sync). */
export function linkedNote(app, what = 'data set') {
  if (!app.settings.hubUrl) return null;
  return h('p', { class: 'micro m-note' }, isInnerUrl(app.settings.hubUrl)
    ? `Full PC mode: this phone’s PC keeps the ${what}. Change it in the PC apps, or here and it’s replaced at the next sync.`
    : `Linked to your PC: its ${what} replaces this phone’s at every sync. Make changes on the PC (or unlink to use this phone on its own).`);
}

function wrap(app, cls, make, note) {
  const fa = pcFacade(app);
  const inner = make(fa);
  const el = h('div', { class: `m-pcview ${cls}` }, note, inner.el);
  return { el, update: () => inner.update?.(), mounted: () => inner.mounted?.(), dispose: () => inner.dispose?.() };
}
export const dataLabApp = (app) => wrap(app, 'm-datalab', dataLabView, linkedNote(app));
export const friendsApp = (app) => wrap(app, 'm-friends', friendsView, null);
export const trainerApp = (app) => wrap(app, 'm-trainer', trainerView, app.settings.hubUrl && !isInnerUrl(app.settings.hubUrl) ? h('p', { class: 'micro m-note' }, 'Linked to your PC: its card replaces this one at every sync. Change it on the PC under Trainer ID.') : null);
export { fromDataUrl, mount };
