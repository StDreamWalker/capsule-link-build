// Debug screen: stands in for the NFC reader. The capsules are the PC's virtual capsules (made on
// the PC: Capsule dock → Virtual dock); the phone "taps" one over the link — Wi-Fi or a USB
// cable — and everything after that is exactly what happens with a real ball.
import { h, mount, toast } from '../../shared/ui/dom.js';
import { capsuleCanvas } from '../../shared/ui/capsuleArt.js';
import { sfx } from '../../shared/ui/audio.js';
import { MSG, fromHex, toHex } from '../../shared/engine/index.js';
import { USB_URL } from './simball.js';

export function debugView(app) {
  const el = h('div', { class: 'm-debug' });
  let list = null, error = '', busy = false;
  let code = '';

  async function request(c, type, data) {
    const r = await c.request(type, data, MSG.VTAG, 15000);
    if (!r.ok) throw new Error(r.error);
    return r;
  }
  async function load() {
    if (!app.settings.hubUrl) { list = null; render(); return; }
    const c = app.client();
    try { await c.connect(); list = (await request(c, MSG.VTAG_LIST, {})).list; error = ''; }
    catch (e) { list = null; error = /Unknown message/.test(e.message) ? 'Update the PC app first: this version of it can’t share virtual capsules.' : e.message; }
    finally { c.close(); }
    render();
  }

  /** Tap a PC capsule: reads and writes go over the link while the phone does its usual work. */
  async function tap(cap) {
    if (busy) return;
    busy = true; render();
    const c = app.client();
    try {
      await c.connect();
      const tag = {
        uid: cap.uid, virtual: true, size: 504,
        readUser: async () => fromHex((await request(c, MSG.VTAG_READ, { uid: cap.uid })).hex),
        writePages: async (page, bytes) => { await request(c, MSG.VTAG_WRITE, { uid: cap.uid, page, hex: toHex(bytes) }); },
      };
      await app.onCapsule(tag, { stay: true });
      sfx('dock');
    } catch (e) { toast(e.message, 'err'); }
    finally { c.close(); busy = false; }
    await load();
  }

  async function useUsb() {
    try { await app.connectPc(USB_URL, code); toast('Linked over the USB cable.', 'ok'); load(); }
    catch (e) { toast(e.code === 'pair' ? 'Enter the pairing code from the PC’s Phone link screen first.' : /reach|answer/i.test(e.message) ? 'No answer over USB. On the PC open Phone link → USB cable → Set up USB link, then try again.' : e.message, 'err'); }
  }

  function armText() {
    const a = app.capsuleArm;
    if (!a) return 'A tap syncs the capsule, like holding a real one to the phone.';
    if (a.kind === 'send') return 'The next tap puts the chosen creature inside.';
    if (a.kind === 'release') return 'The next tap brings its creature onto your phone.';
    if (a.kind === 'mode') return `The next tap switches it to ${a.mode} mode.`;
    if (a.kind === 'format') return 'The next tap formats it as an empty capsule.';
    return '';
  }

  function render() {
    const linked = !!app.settings.hubUrl;
    mount(el,
      h('h1', null, 'Debug'),
      h('section', { class: 'panel col' },
        h('h2', null, 'Capsules on your PC'),
        h('p', { class: 'dim' }, 'Until the ball’s NFC is ready, the phone can tap the PC’s virtual capsules over the link instead. Make them on the PC: Capsule dock → Virtual dock.'),
        h('p', { class: 'micro dim' }, armText(), ' ', h('button', { class: 'btn small ghost', onclick: () => app.go('capsule') }, 'Choose what a tap does')),
        !linked ? h('p', { class: 'err-text' }, 'Link this phone to your PC first (Link tab), or use the USB cable below.')
          : error ? h('p', { class: 'err-text' }, error)
            : !list ? h('p', { class: 'dim' }, 'Looking…')
              : !list.length ? h('p', { class: 'dim' }, 'The PC has no virtual capsules yet.')
                : list.map((cap) => h('div', { class: 'row' },
                  capsuleCanvas({ ring: cap.docked ? '#ffc93c' : '#34d1bf', pulse: cap.docked }, 2),
                  h('div', { class: 'grow' }, h('div', null, cap.name), h('div', { class: 'micro dim mono-num' }, `${cap.uid.slice(-6)}${cap.docked ? ' · on the PC dock' : ''}`)),
                  h('button', { class: 'btn small primary', disabled: busy, onclick: () => tap(cap) }, busy ? '…' : 'Tap'))),
        linked ? h('button', { class: 'btn small', onclick: () => { list = null; render(); load(); } }, 'Refresh') : null),
      h('section', { class: 'panel col' },
        h('h2', null, 'Link over a USB cable'),
        h('ol', { class: 'micro dim' },
          h('li', null, 'On the phone: Settings → About phone → tap Build number 7 times, then Developer options → USB debugging on.'),
          h('li', null, 'Plug the phone into the PC with a USB-C cable and allow the PC when the phone asks.'),
          h('li', null, 'On the PC: Phone link → USB cable → Set up USB link.')),
        h('label', { class: 'field' }, h('span', null, 'Pairing code from the PC (only the first time)'), h('input', { type: 'text', inputMode: 'numeric', maxLength: 6, value: code, oninput: (e) => { code = e.target.value.trim(); } })),
        h('button', { class: 'btn', onclick: useUsb }, 'Link over USB')));
  }
  render();
  load();
  return { el, update: () => {} };
}
