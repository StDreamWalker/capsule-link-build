// Debug → Ball hardware. Stands in for the real ball until it exists, and is the only place the
// app admits a ball is emulated. Balls come from the PC (Capsule dock → Virtual capsules): this
// screen can't make one. With the phone on the PC's dock you can swap a ball (and whoever is inside)
// between the PC and the phone. Off the dock, "Sync with phone" does what tapping a real ball does;
// only then does the ball appear in the rest of the app.
import { h, mount, toast, fmtNum, chooseDialog } from '../../shared/ui/dom.js';
import { capsuleCanvas } from '../../shared/ui/capsuleArt.js';
import { sfx } from '../../shared/ui/audio.js';
import { displayName, createCreature, baseSpeciesOf, makeEgg, EGG_DEFAULT_STEPS, makeEvent } from '../../shared/engine/index.js';
import { spriteCanvas } from '../../shared/ui/art.js';
import { confirmDialog, refocus } from '../../shared/ui/dom.js';
import { openCreatureEditor } from '../../desktop/src/renderer/views/creatureEditor.js';
import { USB_URL } from './simball.js';

const MODE_HELP = {
  desk: 'Sits on a desk. Now and then it cries or wiggles (the phone vibrates).',
  walk: 'Counts steps while someone is inside.',
  battle: 'Knock it (Bump) to start a bump battle.',
  sleep: 'Quiet.',
};

export function debugView(app) {
  const em = app.emulated;
  const el = h('div', { class: 'm-debug' });
  let pcList = null, error = '', busy = false, code = '';
  const offs = [em.on(() => render())];

  async function refreshPc() {
    if (!em.docked) { pcList = null; render(); return; }
    try { pcList = await em.pcBalls(); error = ''; } catch (e) { pcList = null; error = e.message; }
    render();
  }
  async function act(fn) {
    if (busy) return;
    busy = true; render();
    try { await fn(); } catch (e) { toast(e.message, 'err'); }
    busy = false; render();
  }

  function ballRow(uid) {
    const i = em.info(uid);
    const c = i.state === 'creature' ? app.save.creatures[i.rec.uid] : null;
    const sp = i.state === 'creature' ? app.idx.speciesByNo.get(i.rec.speciesNo) : null;
    const name = c ? displayName(app.idx, c) : i.rec?.nickname || sp?.name;
    const synced = app.save.capsules?.[uid]?.holder === app.settings.deviceId;
    const wiggle = em.wiggling?.uid === uid && Date.now() - em.wiggling.at < 600;
    return h('div', { class: 'panel col emu-ball' },
      h('div', { class: 'row', style: { alignItems: 'flex-start' } },
        h('div', { class: `sim-ball ${wiggle ? 'wiggle' : ''}` }, capsuleCanvas({ ring: sp ? app.idx.types.get(sp.types[0])?.color : '#34d1bf', pose: wiggle ? 'shake1' : undefined, lit: i.state === 'creature', creature: sp?.id, bank: app.bank }, 3)),
        h('div', { class: 'grow col', style: { gap: '2px' } },
          h('strong', null, app.save.capsules?.[uid]?.name ?? 'Ball'),
          h('div', { class: 'dim' }, i.state === 'creature' ? `${name} · ${i.mode} mode` : 'Empty'),
          h('div', { class: 'micro dim mono-num' }, `${uid.slice(-6)}${i.state === 'creature' ? ` · ${fmtNum(i.pending ?? 0)} steps not synced` : ''}`),
          h('div', { class: `micro ${synced ? 'ok-text' : 'dim'}` }, synced ? 'Synced with this phone' : 'Not synced with this phone yet'))),
      i.state === 'creature' ? h('p', { class: 'micro dim' }, MODE_HELP[i.mode] ?? '') : null,
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small primary', disabled: busy, onclick: () => act(async () => { await app.onCapsule(em.asTag(uid), { stay: true }); }) }, 'Sync with phone'),
        em.docked ? h('button', { class: 'btn small', disabled: busy, onclick: () => act(async () => { await em.giveToPc(uid); sfx('transfer'); toast('The ball is back on your PC.', 'ok'); await refreshPc(); }) }, 'Swap to the PC') : null,
        !em.docked && i.state === 'creature' ? [
          h('button', { class: 'btn small', onclick: () => { if (em.addSteps(uid, 1000)) toast('The ball counted 1,000 steps.'); else toast('Only a ball in walk mode counts steps.', 'err'); } }, '+1,000 steps'),
          h('button', { class: 'btn small', onclick: () => app.simulatedBump(uid) }, 'Bump'),
          h('button', { class: 'btn small', onclick: () => em.cry(uid) }, 'Cry'),
        ] : null));
  }

  async function useUsb() {
    try { await app.connectPc(USB_URL, code); toast('Linked over the USB cable.', 'ok'); render(); }
    catch (e) { toast(e.code === 'pair' ? 'Enter the pairing code from the PC’s Phone link screen first.' : /reach|answer/i.test(e.message) ? 'No answer over USB. On the PC open Phone link → USB cable → Set up USB link, then try again.' : e.message, 'err'); }
  }

  // what to do next, as numbered steps with ticks: where the ball is, and where the creature is
  function guide(mine) {
    const withPhone = mine.length > 0, holding = mine.some((u) => em.info(u).state === 'creature'), synced = mine.some((u) => app.save.capsules?.[u]?.holder === app.settings.deviceId);
    const steps = [
      ['Put the phone on the PC dock', em.docked || withPhone, 'Button below. (Stands in for setting a real phone on the dock.)'],
      ['Swap a ball over to the phone', withPhone, 'Under “Balls on the PC”: Swap to the phone. Put someone in first if you like.'],
      ['Take the phone off the dock', withPhone && !em.docked, 'Now it carries the ball, like a real one in your pocket.'],
      ['Sync the ball with the phone', synced, 'Under “Balls with this phone”: Sync with phone. Its creature shows in With you.'],
      ['Bring it home', false, 'Put the phone back on the dock and press Swap to the PC (or send them from With you → Move to…).'],
    ];
    const next = steps.findIndex((x) => !x[1]);
    return h('section', { class: 'panel col' },
      h('h2', null, 'Moving between the PC, the phone and a ball'),
      h('div', { class: 'row wrap micro', style: { gap: '6px' } }, h('span', { class: 'chip' }, '🖥️ PC'), '⇄', h('span', { class: 'chip' }, '📱 Phone'), '⇄', h('span', { class: 'chip' }, `⚪ Ball${holding ? ' (holding someone)' : ''}`)),
      h('ol', { class: 'col', style: { gap: '4px', paddingLeft: '18px', margin: 0 } }, steps.map(([t, done, help], i) => h('li', { style: { opacity: done || i === next ? 1 : 0.55 } },
        h('span', { class: done ? 'ok-text' : i === next ? '' : 'dim', style: { fontWeight: i === next ? 700 : 400 } }, `${done ? '✓ ' : i === next ? '→ ' : ''}${t}`),
        i === next ? h('div', { class: 'micro dim' }, help) : null))));
  }

  // ---------- the PC's debug tools, for the phone: add, edit and remove creatures; care and walk shortcuts ----------
  const dbg = debugView.state ?? (debugView.state = { q: '', level: 30, shiny: false, egg: false, page: 0, open: 'add' });
  const phoneApp = { get save() { return app.save; }, get idx() { return app.idx; }, get bank() { return app.bank; }, commit: (fn) => commit(fn) };
  // (changes go through adopt(), so the PC gets them as snapshots on the next sync)
  function commit(fn) { const before = JSON.parse(JSON.stringify(app.save)), after = JSON.parse(JSON.stringify(app.save)); fn(after); app.adopt(before, after); app.persist(); app.refresh(); }
  function addOne(sp) {
    const base = baseSpeciesOf(app.idx, sp);
    const c = createCreature(app.idx, base.id, { level: Math.max(1, Math.min(app.idx.ds.rules.maxLevel ?? 100, dbg.level)), trainer: app.save.trainer?.name, metHow: 'Made with the debug tools', location: { kind: 'phone', device: app.settings.deviceId } });
    c.debug = true;
    if (base !== sp) c.formId = sp.id;
    if (dbg.shiny) c.shiny = true;
    if (dbg.egg) makeEgg(c, EGG_DEFAULT_STEPS);
    app.save.creatures[c.uid] = c;
    if (!app.buddy()) app.settings.buddyUid = c.uid;
    app.persist(); app.refresh();
    sfx('blip');
    const full = app.team().length >= (app.idx.ds.rules.partySize ?? 6) && !app.team().some((x) => x.uid === c.uid);
    toast(`${displayName(app.idx, c)} (Lv. ${c.level}) is with you now.${full ? ' (Your team is full, so they wait behind it.)' : ''}${app.settings.hubUrl ? ' They go to the PC like any phone creature when you sync.' : ''}`, 'ok');
    render();
  }
  function care(fn, msg) { const uids = app.team().map((c) => c.uid); commit((sv) => { for (const u of uids) { const c = sv.creatures[u]; if (!c) continue; c.needs = { ...(c.needs ?? {}) }; fn(c); c.needsAt = Date.now(); } }); sfx('blip'); toast(msg, 'ok'); }
  async function steps(n) {
    if (app.platform.addSteps && !app.native) { app.platform.addSteps(n); toast(`+${fmtNum(n)} steps.`, 'ok'); return; }
    const b = app.buddy(); if (!b) { toast('Pick a buddy first.', 'err'); return; }
    app.record(makeEvent('walk', { uid: b.uid, steps: n, source: 'phone', context: { env: [] } }));
    app.walk.session += n; app.emit('steps'); app.refresh();
    toast(`${displayName(app.idx, b)} walked ${fmtNum(n)} steps (the step counter isn’t touched).`, 'ok');
  }
  async function removeDebug() {
    const known = new Set((app.pcList ?? []).map((x) => x.uid));
    const doomed = Object.values(app.save.creatures).filter((c) => c.debug && c.location?.kind === 'phone' && !known.has(c.uid));
    if (!doomed.length) { toast(app.save.creatures && Object.values(app.save.creatures).some((c) => c.debug) ? 'The debug creatures here are already on your PC: remove them there (Settings → Debug).' : 'No debug creatures on this phone.'); return; }
    if (!(await confirmDialog(`Remove ${doomed.length} debug creature${doomed.length === 1 ? '' : 's'}?`, 'Only ones made on this phone that haven’t gone to the PC yet.', { ok: 'Remove', danger: true }))) return;
    for (const c of doomed) delete app.save.creatures[c.uid];
    if (!app.save.creatures[app.settings.buddyUid]) app.settings.buddyUid = app.team()[0]?.uid ?? null;
    app.persist(); app.refresh(); render();
  }
  function toolsPanels() {
    const q = dbg.q.trim().toLowerCase();
    const all = app.idx.ds.species.filter((sp) => !sp.battleOnly);
    const shown = all.filter((sp) => !q || sp.name.toLowerCase().includes(q) || String(sp.no) === q || sp.id.includes(q));
    const per = 48, pages = Math.max(1, Math.ceil(shown.length / per));
    dbg.page = Math.min(dbg.page, pages - 1);
    const mineList = app.creatures().filter((c) => ['phone', 'party'].includes(c.location?.kind));
    return [
      h('section', { class: 'panel col' },
        h('h2', null, 'Add creatures'),
        h('p', { class: 'micro dim' }, 'Tap a species to have one with you on the phone, like the PC’s debug tools. They’re marked as debug creatures.'),
        h('input', { type: 'search', class: 'dbg-q', placeholder: 'Search species, number or id…', value: dbg.q, oninput: (e) => { dbg.q = e.target.value; dbg.page = 0; render(); refocus(el.querySelector('.dbg-q')); } }),
        h('div', { class: 'row wrap' },
          h('label', { class: 'row' }, h('span', { class: 'dim' }, 'Level'), h('input', { type: 'number', min: 1, max: 255, value: dbg.level, style: { width: '72px' }, onchange: (e) => { dbg.level = Number(e.target.value) || 5; } })),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: dbg.shiny, onchange: (e) => { dbg.shiny = e.target.checked; } }), 'Shiny'),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: dbg.egg, onchange: (e) => { dbg.egg = e.target.checked; } }), 'As an egg')),
        h('div', { class: 'dex-grid m-dex' }, shown.slice(dbg.page * per, dbg.page * per + per).map((sp) => h('button', { class: 'dex-cell', title: `#${sp.no} ${sp.name}`, onclick: () => addOne(sp) },
          spriteCanvas(app.bank, sp.id, { scale: 1 }), h('span', { class: 'micro ell' }, sp.name)))),
        pages > 1 ? h('div', { class: 'row center-items' },
          h('button', { class: 'btn small', disabled: dbg.page === 0, onclick: () => { dbg.page--; render(); } }, '◀'),
          h('span', { class: 'dim micro' }, `Page ${dbg.page + 1} of ${pages}`),
          h('button', { class: 'btn small', disabled: dbg.page >= pages - 1, onclick: () => { dbg.page++; render(); } }, '▶')) : null),
      h('section', { class: 'panel col' },
        h('h2', null, 'Edit a creature'),
        h('p', { class: 'micro dim' }, 'The PC’s save editor: species and form, level, shininess, genes, moves, temperament, ability, item, needs, memories and likes.'),
        mineList.length ? h('div', { class: 'row wrap' },
          h('select', { class: 'dbg-edit grow' }, mineList.map((c) => h('option', { value: c.uid }, `${displayName(app.idx, c)} · Lv. ${c.level}${c.shiny ? ' ★' : ''}`))),
          h('button', { class: 'btn primary', onclick: async () => { const uid = el.querySelector('.dbg-edit').value; if (uid && await openCreatureEditor(phoneApp, uid)) render(); } }, 'Edit'))
          : h('p', { class: 'dim' }, 'Nobody with you to edit.')),
      h('section', { class: 'panel col' },
        h('h2', null, 'Care and walks'),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn small', onclick: () => care((c) => { Object.assign(c.needs, { energy: 100, fullness: 100, joy: 100, hygiene: 100 }); c.sleep = null; if (c.hp != null) c.hp = c.stats?.hp ?? c.hp; }, 'Everyone with you is fed, rested, happy and clean.') }, 'Fill everyone’s needs'),
          h('button', { class: 'btn small', onclick: () => care((c) => { Object.assign(c.needs, { energy: 12, fullness: 18 }); }, 'Everyone with you is tired and hungry now.') }, 'Make them tired and hungry'),
          h('button', { class: 'btn small', onclick: () => steps(1000) }, '+1,000 steps'),
          h('button', { class: 'btn small', onclick: () => { if (!app.emptyBalls().length) { toast('A wild encounter needs an empty ball with you.', 'err'); return; } app.lookAround(true); } }, 'Wild encounter now'),
          h('button', { class: 'btn small', onclick: () => { app.pendingWild = true; app.go('battle'); } }, 'Wild battle now')),
        h('p', { class: 'micro dim' }, '“Unlock everything” lives on the PC (Settings → Debug); this phone gets the items with the next sync.')),
      h('section', { class: 'panel col' },
        h('h2', null, 'Remove creatures'),
        h('button', { class: 'btn', onclick: removeDebug }, 'Remove debug creatures made here')),
    ];
  }

  function render() {
    const mine = em.list();
    mount(el,
      toolsPanels(),
      h('h2', { class: 'dbg-sep' }, 'Ball hardware'),
      guide(mine),
      h('section', { class: 'panel col' },
        h('h2', null, 'Ball hardware (emulated)'),
        h('p', { class: 'dim' }, 'Stands in for the real ball. Balls are made on the PC (Capsule dock → Virtual capsules) and handed to this phone with the phone on the PC’s dock. Then take the phone off the dock and sync, as you would with a real ball.'),
        h('div', { class: 'row' },
          h('span', { class: `dot ${em.docked ? 'on' : ''}` }), h('span', { class: 'grow' }, em.docked ? 'Phone is on the PC dock' : 'Phone is off the dock'),
          h('button', { class: `btn small ${em.docked ? '' : 'primary'}`, disabled: busy, onclick: () => act(async () => { if (em.docked) { em.undock(); sfx('undock'); } else { await em.dock(); sfx('dock'); await refreshPc(); } }) }, em.docked ? 'Take off the dock' : 'Put on the PC dock'))),
      em.docked ? h('section', { class: 'panel col' },
        h('h2', null, 'Balls on the PC'),
        error ? h('p', { class: 'err-text' }, error)
          : !pcList ? h('p', { class: 'dim' }, 'Looking…')
            : !pcList.length ? h('p', { class: 'dim' }, 'The PC has no virtual balls left. Make one there: Capsule dock → Virtual capsules → New.')
              : pcList.map((cap) => h('div', { class: 'row' },
                capsuleCanvas({ ring: cap.docked ? '#ffc93c' : '#34d1bf' }, 2),
                h('div', { class: 'grow' }, h('div', null, cap.name), h('div', { class: 'micro dim' }, `${cap.creature ? `Holds ${app.idx.species.get(cap.creature)?.name ?? cap.creature}` : 'Empty'}${cap.docked ? ' · on the PC’s own dock' : ''}`)),
                cap.creature
                  ? h('button', { class: 'btn small', disabled: busy, onclick: () => act(async () => { await app.onCapsule(em.pcTag(cap.uid), { stay: true, arm: { kind: 'release' } }); await app.sync?.({ quiet: true }).catch(() => {}); await refreshPc(); }) }, 'Take out')
                  : h('button', { class: 'btn small', disabled: busy, onclick: () => act(async () => {
                    const who = app.creatures().filter((c) => c.location?.kind === 'phone' && app.idx.species.has(c.speciesId));
                    const uid = await chooseDialog('Put someone in this ball', who.map((c) => ({ value: c.uid, label: displayName(app.idx, c), detail: `Lv. ${c.level}` })), { empty: 'Nobody is out on this phone. Bring someone from the PC first.' });
                    if (uid) { await app.onCapsule(em.pcTag(cap.uid), { stay: true, arm: { kind: 'send', uid, mode: 'walk' } }); await app.sync?.({ quiet: true }).catch(() => {}); await refreshPc(); }
                  }) }, 'Put someone in'),
                h('button', { class: 'btn small primary', disabled: busy || cap.docked, onclick: () => act(async () => { await em.takeFromPc(cap.uid); sfx('transfer'); toast('The ball is with the phone now. Take the phone off the dock, then sync it.', 'ok'); await refreshPc(); }) }, 'Swap to the phone'))),
        h('button', { class: 'btn small', onclick: refreshPc }, 'Refresh')) : null,
      h('section', { class: 'col' },
        h('h2', null, 'Balls with this phone'),
        mine.length ? mine.map(ballRow) : h('p', { class: 'dim' }, em.docked ? 'None yet: swap one over from the PC above.' : 'None. Put the phone on the PC dock to swap a ball over.')),
      h('section', { class: 'panel col' },
        h('h2', null, 'Link over a USB cable'),
        h('ol', { class: 'micro dim' },
          h('li', null, 'On the phone: Settings → About phone → tap Build number 7 times, then Developer options → USB debugging on.'),
          h('li', null, 'Plug the phone into the PC with a USB-C cable and allow the PC when the phone asks.'),
          h('li', null, 'On the PC: Phone link → USB cable → Set up USB link.')),
        h('label', { class: 'field' }, h('span', null, 'Pairing code from the PC (only the first time)'), h('input', { type: 'text', inputMode: 'numeric', maxLength: 6, value: code, oninput: (e) => { code = e.target.value.trim(); } })),
        h('button', { class: 'btn', onclick: useUsb }, 'Link over USB')));
  }
  render();
  return { el, update: () => {}, dispose: () => offs.forEach((o) => o()) };
}
