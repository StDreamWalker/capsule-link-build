// Debug screen: a simulated capsule that stands in for the real ball, and the USB-C link to the PC dock.
import { h, mount, toast, confirmDialog, chooseDialog, fmtNum } from '../../shared/ui/dom.js';
import { capsuleCanvas } from '../../shared/ui/capsuleArt.js';
import { spriteCanvas } from '../../shared/ui/art.js';
import { sfx } from '../../shared/ui/audio.js';
import { displayName, CAPSULE, toHex } from '../../shared/engine/index.js';
import { USB_URL } from './simball.js';

const MODE_HELP = {
  desk: 'Sits on a desk. Now and then it cries or wiggles (your phone vibrates).',
  walk: 'Counts your steps while your buddy is inside.',
  battle: 'Knock it (the Bump button) to start a bump battle.',
  sleep: 'Quiet.',
};

export function debugView(app) {
  const ball = app.simBall;
  const el = h('div', { class: 'm-debug' });
  let dockUrl = app.settings.simDockUrl || USB_URL;
  let pairCode = '';
  let needPair = false;
  const offs = [ball.on(() => render())];

  async function tap(arm) {
    if (arm) app.arm(arm);
    await app.onCapsule(ball.asTag(), { stay: true });
    render();
  }

  async function dock() {
    app.local((s) => { s.settings.simDockUrl = dockUrl; });
    try {
      if (needPair) {
        await app.connectPc(dockUrl, pairCode, { keepUrl: true });
        needPair = false;
      }
      const ack = await ball.dock(dockUrl);
      toast(ack.pcs ? 'The simulated capsule is on the PC dock.' : 'Connected, but the PC dock screen is not open. Open Capsule dock on the PC.', 'ok');
      sfx('dock');
    } catch (e) {
      if (e.code === 'pair') { needPair = true; render(); toast('Enter the pairing code from the PC’s Phone link screen, then press Put on the PC dock again.', 'err'); return; }
      toast(/reach|answer/i.test(e.message) && dockUrl === USB_URL
        ? 'No answer over USB. On the PC open Phone link → USB cable → Set up USB link, then try again.'
        : e.message, 'err');
    }
  }

  function ballPanel() {
    const i = ball.info();
    const c = i.state === 'creature' ? app.save.creatures[i.rec.uid] : null;
    const sp = i.state === 'creature' ? app.idx.speciesByNo.get(i.rec.speciesNo) : null;
    const ring = sp ? app.idx.types.get(sp.types[0])?.color : '#34d1bf';
    const name = c ? displayName(app.idx, c) : i.rec?.nickname || sp?.name;
    const wiggle = ball.wiggling && Date.now() - ball.wiggling < 600;
    return h('section', { class: 'panel col' },
      h('div', { class: 'row', style: { alignItems: 'flex-start' } },
        h('div', { class: `sim-ball ${wiggle ? 'wiggle' : ''}` }, capsuleCanvas({ ring, pose: wiggle ? 'shake1' : undefined, lit: i.state === 'creature', creature: sp?.id, bank: app.bank, pulse: ball.dockState === 'docked' }, 4)),
        h('div', { class: 'grow col', style: { gap: '2px' } },
          h('h2', null, i.state === 'creature' ? name : i.state === 'empty' ? 'Empty capsule' : 'Blank capsule'),
          h('div', { class: 'micro dim mono-num' }, ball.uid),
          i.state === 'creature' ? [
            h('div', { class: 'dim' }, `Lv. ${i.rec.level} · ${i.mode} mode`),
            h('div', { class: 'dim' }, `${fmtNum(i.pending)} steps since sync`),
            h('div', { class: 'dim' }, `${fmtNum(i.rec.totalSteps + i.pending)} steps together · ${i.walk?.bumpCount ?? 0} bumps`),
          ] : h('p', { class: 'dim' }, 'Put a creature in from this phone, or from the PC dock.'),
          ball.dockState === 'docked' ? h('div', { class: 'note' }, 'On the PC dock') : null)),
      i.state === 'creature' ? h('p', { class: 'dim' }, MODE_HELP[i.mode] ?? '') : null,
      h('div', { class: 'sim-actions' },
        h('button', { class: 'btn primary', onclick: () => tap(null) }, 'Tap to this phone'),
        i.state === 'creature'
          ? h('button', { class: 'btn', onclick: () => tap({ kind: 'release' }) }, 'Take creature out (dev tool)')
          : h('button', { class: 'btn', onclick: async () => {
            const options = app.creatures().filter((x) => x.location?.kind !== 'capsule');
            const uid = await chooseDialog('Put in the simulated capsule', options.map((x) => ({ value: x.uid, label: displayName(app.idx, x), detail: `Lv. ${x.level}`, el: spriteCanvas(app.bank, x.speciesId, { scale: 1 }) })), { empty: 'Nobody is on this phone. Take someone from the PC first, or put one in from the PC dock.' });
            if (uid) tap({ kind: 'send', uid, mode: 'walk' });
          } }, 'Put a creature in')),
      i.state === 'creature' ? h('div', { class: 'row wrap', role: 'radiogroup', 'aria-label': 'Capsule mode' },
        CAPSULE.MODES.map((m) => h('button', { class: `btn small ${m === i.mode ? 'primary' : ''}`, role: 'radio', 'aria-checked': m === i.mode ? 'true' : 'false', onclick: () => { if (m !== i.mode) tap({ kind: 'mode', mode: m }); } }, m[0].toUpperCase() + m.slice(1)))) : null,
      i.state === 'creature' ? h('div', { class: 'row wrap' },
        h('button', { class: 'btn small', disabled: i.mode !== 'walk', onclick: () => ball.addSteps(100) }, '+100 steps'),
        h('button', { class: 'btn small', disabled: i.mode !== 'walk', onclick: () => ball.addSteps(1000) }, '+1,000 steps'),
        h('button', { class: 'btn small', onclick: () => app.simulatedBump() }, 'Bump'),
        h('button', { class: 'btn small', onclick: () => ball.cry() }, 'Cry'),
        h('button', { class: 'btn small', onclick: () => ball.wiggle() }, 'Wiggle')) : null,
      i.state === 'creature' && i.mode === 'walk' ? h('p', { class: 'micro dim' }, 'Real steps count too: make the creature inside your buddy and start a walk.') : null);
  }

  function dockPanel() {
    const state = ball.dockState;
    return h('section', { class: 'panel col' },
      h('h2', null, 'Put it on the PC dock'),
      h('p', { class: 'dim' }, 'The PC reads and writes this capsule exactly like a real one on the dock: send creatures in, sync steps, let them out.'),
      h('ol', { class: 'steps' },
        h('li', null, 'On the phone: Settings → About phone → tap Build number 7 times, then Developer options → USB debugging on.'),
        h('li', null, 'Plug the phone into the PC with a USB-C cable and allow the PC when the phone asks.'),
        h('li', null, 'On the PC: Phone link → USB cable → Set up USB link.'),
        h('li', null, 'Here: Put on the PC dock. On the PC, open Capsule dock.')),
      h('label', { class: 'field' }, h('span', null, 'Dock address'),
        h('input', { type: 'url', id: 'sim-url', value: dockUrl, oninput: (e) => { dockUrl = e.target.value.trim() || USB_URL; } })),
      h('p', { class: 'micro faint' }, `${USB_URL} is the USB cable. Your PC’s Wi-Fi address works too.`),
      needPair ? h('label', { class: 'field' }, h('span', null, 'Pairing code from the PC'), h('input', { type: 'text', id: 'sim-code', inputMode: 'numeric', maxLength: 6, oninput: (e) => { pairCode = e.target.value.trim(); } })) : null,
      state === 'docked'
        ? h('button', { class: 'btn wide', onclick: () => { ball.undock(); sfx('undock'); } }, 'Lift off the PC dock')
        : h('button', { class: 'btn primary wide', disabled: state === 'connecting', onclick: dock }, state === 'connecting' ? 'Connecting…' : 'Put on the PC dock'));
  }

  function rawPanel() {
    const mem = ball.tag.mem.slice(0, 232);
    const lines = [];
    for (let o = 0; o < mem.length; o += 8) lines.push(`${String(o).padStart(3, '0')} ${toHex(mem.slice(o, o + 8)).replace(/(..)/g, '$1 ').trim()}${o === 32 ? '  MAIN' : o === 160 ? '  WALK' : ''}`);
    return h('section', { class: 'panel col' },
      h('details', null, h('summary', null, 'Capsule memory'), h('pre', { class: 'hexdump' }, lines.join('\n'))),
      h('button', { class: 'btn small danger', onclick: async () => {
        const i = ball.info();
        const msg = i.state === 'creature' ? 'The creature inside stays listed as being in this capsule. Take it out first if you want to keep it.' : 'The simulated capsule goes back to a blank tag.';
        if (await confirmDialog('Wipe the simulated capsule?', msg, { ok: 'Wipe', danger: true })) ball.reset();
      } }, 'Wipe the simulated capsule'));
  }

  function render() {
    mount(el,
      h('div', { class: 'row' }, h('button', { class: 'btn small', onclick: () => app.go('link') }, '◀ Link'), h('h1', { class: 'grow' }, 'Debug')),
      h('p', { class: 'dim' }, 'A capsule simulated by this phone, for testing before the real ball is built.'),
      ballPanel(), dockPanel(), rawPanel());
  }
  render();
  const tick = setInterval(() => { if (ball.wiggling && Date.now() - ball.wiggling < 900) render(); }, 300);
  return { el, update: render, dispose() { clearInterval(tick); offs.forEach((o) => o()); } };
}
