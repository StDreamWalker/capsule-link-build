// Debug → Ball hardware. Stands in for the real ball until it exists, and is the only place the
// app admits a ball is emulated. Balls come from the PC (Capsule dock → Virtual capsules): this
// screen can't make one. With the phone on the PC's dock you can swap a ball (and whoever is inside)
// between the PC and the phone. Off the dock, "Sync with phone" does what tapping a real ball does;
// only then does the ball appear in the rest of the app.
import { h, mount, toast, fmtNum } from '../../shared/ui/dom.js';
import { capsuleCanvas } from '../../shared/ui/capsuleArt.js';
import { sfx } from '../../shared/ui/audio.js';
import { displayName } from '../../shared/engine/index.js';
import { USB_URL } from './simball.js';

const MODE_HELP = {
  desk: 'Sits on a desk. Now and then it cries or wiggles (the phone vibrates).',
  walk: 'Counts steps while someone is inside.',
  battle: 'Knock it (Bump) to start a bump battle.',
  sleep: 'Quiet.',
};

export function debugView(app) {
  const em = app.emulated;
  const el = h('div', { class: 'm-debug' });
  let pcList = null, error = '', busy = false, code = '';
  const offs = [em.on(() => render())];

  async function refreshPc() {
    if (!em.docked) { pcList = null; render(); return; }
    try { pcList = await em.pcBalls(); error = ''; } catch (e) { pcList = null; error = e.message; }
    render();
  }
  async function act(fn) {
    if (busy) return;
    busy = true; render();
    try { await fn(); } catch (e) { toast(e.message, 'err'); }
    busy = false; render();
  }

  function ballRow(uid) {
    const i = em.info(uid);
    const c = i.state === 'creature' ? app.save.creatures[i.rec.uid] : null;
    const sp = i.state === 'creature' ? app.idx.speciesByNo.get(i.rec.speciesNo) : null;
    const name = c ? displayName(app.idx, c) : i.rec?.nickname || sp?.name;
    const synced = app.save.capsules?.[uid]?.holder === app.settings.deviceId;
    const wiggle = em.wiggling?.uid === uid && Date.now() - em.wiggling.at < 600;
    return h('div', { class: 'panel col emu-ball' },
      h('div', { class: 'row', style: { alignItems: 'flex-start' } },
        h('div', { class: `sim-ball ${wiggle ? 'wiggle' : ''}` }, capsuleCanvas({ ring: sp ? app.idx.types.get(sp.types[0])?.color : '#34d1bf', pose: wiggle ? 'shake1' : undefined, lit: i.state === 'creature', creature: sp?.id, bank: app.bank }, 3)),
        h('div', { class: 'grow col', style: { gap: '2px' } },
          h('strong', null, app.save.capsules?.[uid]?.name ?? 'Ball'),
          h('div', { class: 'dim' }, i.state === 'creature' ? `${name} · ${i.mode} mode` : 'Empty'),
          h('div', { class: 'micro dim mono-num' }, `${uid.slice(-6)}${i.state === 'creature' ? ` · ${fmtNum(i.pending ?? 0)} steps not synced` : ''}`),
          h('div', { class: `micro ${synced ? 'ok-text' : 'dim'}` }, synced ? 'Synced with this phone' : 'Not synced with this phone yet'))),
      i.state === 'creature' ? h('p', { class: 'micro dim' }, MODE_HELP[i.mode] ?? '') : null,
      h('div', { class: 'row wrap' },
        em.docked
          ? h('button', { class: 'btn small', disabled: busy, onclick: () => act(async () => { await em.giveToPc(uid); sfx('transfer'); toast('The ball is back on your PC.', 'ok'); await refreshPc(); }) }, 'Swap to the PC')
          : h('button', { class: 'btn small primary', disabled: busy, onclick: () => act(async () => { await app.onCapsule(em.asTag(uid), { stay: true }); }) }, 'Sync with phone'),
        !em.docked && i.state === 'creature' ? [
          h('button', { class: 'btn small', onclick: () => { if (em.addSteps(uid, 1000)) toast('The ball counted 1,000 steps.'); else toast('Only a ball in walk mode counts steps.', 'err'); } }, '+1,000 steps'),
          h('button', { class: 'btn small', onclick: () => app.simulatedBump(uid) }, 'Bump'),
          h('button', { class: 'btn small', onclick: () => em.cry(uid) }, 'Cry'),
        ] : null));
  }

  async function useUsb() {
    try { await app.connectPc(USB_URL, code); toast('Linked over the USB cable.', 'ok'); render(); }
    catch (e) { toast(e.code === 'pair' ? 'Enter the pairing code from the PC’s Phone link screen first.' : /reach|answer/i.test(e.message) ? 'No answer over USB. On the PC open Phone link → USB cable → Set up USB link, then try again.' : e.message, 'err'); }
  }

  function render() {
    const mine = em.list();
    mount(el,
      h('h1', null, 'Debug'),
      h('section', { class: 'panel col' },
        h('h2', null, 'Ball hardware (emulated)'),
        h('p', { class: 'dim' }, 'Stands in for the real ball. Balls are made on the PC (Capsule dock → Virtual capsules) and handed to this phone with the phone on the PC’s dock. Then take the phone off the dock and sync, as you would with a real ball.'),
        h('div', { class: 'row' },
          h('span', { class: `dot ${em.docked ? 'on' : ''}` }), h('span', { class: 'grow' }, em.docked ? 'Phone is on the PC dock' : 'Phone is off the dock'),
          h('button', { class: `btn small ${em.docked ? '' : 'primary'}`, disabled: busy, onclick: () => act(async () => { if (em.docked) { em.undock(); sfx('undock'); } else { await em.dock(); sfx('dock'); await refreshPc(); } }) }, em.docked ? 'Take off the dock' : 'Put on the PC dock'))),
      em.docked ? h('section', { class: 'panel col' },
        h('h2', null, 'Balls on the PC'),
        error ? h('p', { class: 'err-text' }, error)
          : !pcList ? h('p', { class: 'dim' }, 'Looking…')
            : !pcList.length ? h('p', { class: 'dim' }, 'The PC has no virtual balls left. Make one there: Capsule dock → Virtual capsules → New.')
              : pcList.map((cap) => h('div', { class: 'row' },
                capsuleCanvas({ ring: cap.docked ? '#ffc93c' : '#34d1bf' }, 2),
                h('div', { class: 'grow' }, h('div', null, cap.name), h('div', { class: 'micro dim' }, `${cap.creature ? `Holds ${app.idx.species.get(cap.creature)?.name ?? cap.creature}` : 'Empty'}${cap.docked ? ' · on the PC’s own dock' : ''}`)),
                h('button', { class: 'btn small primary', disabled: busy || cap.docked, onclick: () => act(async () => { await em.takeFromPc(cap.uid); sfx('transfer'); toast('The ball is with the phone now. Take the phone off the dock, then sync it.', 'ok'); await refreshPc(); }) }, 'Swap to the phone'))),
        h('button', { class: 'btn small', onclick: refreshPc }, 'Refresh')) : null,
      h('section', { class: 'col' },
        h('h2', null, 'Balls with this phone'),
        mine.length ? mine.map(ballRow) : h('p', { class: 'dim' }, em.docked ? 'None yet: swap one over from the PC above.' : 'None. Put the phone on the PC dock to swap a ball over.')),
      h('section', { class: 'panel col' },
        h('h2', null, 'Link over a USB cable'),
        h('ol', { class: 'micro dim' },
          h('li', null, 'On the phone: Settings → About phone → tap Build number 7 times, then Developer options → USB debugging on.'),
          h('li', null, 'Plug the phone into the PC with a USB-C cable and allow the PC when the phone asks.'),
          h('li', null, 'On the PC: Phone link → USB cable → Set up USB link.')),
        h('label', { class: 'field' }, h('span', null, 'Pairing code from the PC (only the first time)'), h('input', { type: 'text', inputMode: 'numeric', maxLength: 6, value: code, oninput: (e) => { code = e.target.value.trim(); } })),
        h('button', { class: 'btn', onclick: useUsb }, 'Link over USB')));
  }
  render();
  return { el, update: () => {}, dispose: () => offs.forEach((o) => o()) };
}
