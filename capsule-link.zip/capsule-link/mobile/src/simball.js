// A capsule simulated by the phone, for trying everything before the hardware exists.
// It holds the same tag memory as a real capsule and does what the capsule firmware does:
// counts steps in walk mode, records bumps in battle mode, cries and wiggles.
// Over a USB-C cable (or Wi-Fi) it can sit on the PC's dock, where the PC reads and writes it.
import { makeVirtualTag, toHex, fromHex, parseTagImage, pendingSteps, cryFor, MSG, CAPSULE } from '../../shared/engine/index.js';
import { playCry } from '../../shared/ui/audio.js';

const KEY = 'capsule-link-mobile:simball';
export const USB_URL = 'ws://127.0.0.1:47820';

export class SimBall {
  constructor(app) {
    this.app = app;
    this.subs = new Set();
    this.client = null;
    this.dockState = 'off'; // off | connecting | docked
    let stored = null;
    try { stored = JSON.parse(localStorage.getItem(KEY)); } catch { /* fresh */ }
    const uid = stored?.uid ?? `04${Array.from({ length: 6 }, () => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join('').toUpperCase()}`;
    this.tag = makeVirtualTag(uid, stored?.hex ? fromHex(stored.hex) : null);
    if (!stored) this.tag.mem.set([0x03, 0x00, 0xfe], 0); // a fresh, blank tag
    this.save();
    this.idleTimer = setInterval(() => this.idle(), 60000);
  }

  get uid() { return this.tag.uid; }
  on(fn) { this.subs.add(fn); return () => this.subs.delete(fn); }
  emit() { for (const fn of this.subs) fn(); }
  save() { try { localStorage.setItem(KEY, JSON.stringify({ uid: this.uid, hex: toHex(this.tag.mem) })); } catch { /* storage full */ } }

  /** The tag as the rest of the app sees a tag (same shape as NFC and the dock). */
  asTag() {
    return {
      uid: this.uid, simulated: true,
      readUser: () => this.tag.readUser(),
      writePages: async (page, bytes) => { await this.tag.writePages(page, bytes); this.save(); this.emit(); },
    };
  }

  /** What is inside: { state, rec, walk, pending } */
  info() {
    const p = parseTagImage(this.tag.mem);
    if (!p.ok) return { state: p.blank ? 'blank' : p.main?.empty ? 'empty' : 'damaged', error: p.error };
    if (p.main.empty) return { state: 'empty', mode: p.main.rec.mode, walk: p.walk?.ok ? p.walk.walk : null };
    const walk = p.walk?.ok ? p.walk.walk : null;
    return { state: 'creature', rec: p.main.rec, walk, pending: pendingSteps(p.main.rec, walk), mode: p.main.rec.mode };
  }

  // ---------- what the firmware does ----------
  addSteps(n) {
    const i = this.info();
    if (i.state !== 'creature' || i.mode !== 'walk') return false;
    const before = i.walk?.steps ?? 0;
    this.tag.addSteps(n);
    this.save();
    const after = this.info().walk?.steps ?? 0;
    // a cry and a wiggle every 1,000 steps, like the real capsule
    if (Math.floor(after / 1000) > Math.floor(before / 1000)) { this.cry(); this.wiggle(); }
    this.emit();
    return true;
  }

  bump() {
    const i = this.info();
    if (i.state !== 'creature') return { ok: false, reason: 'Put a creature in the simulated capsule first.' };
    if (i.mode !== 'battle') return { ok: false, reason: 'Set the simulated capsule to battle mode first.' };
    this.tag.addSteps(0, { bump: true, peer: 0 });
    this.save();
    this.app.platform.vibrate([60, 30, 60]);
    this.emit();
    return { ok: true };
  }

  cry() {
    const i = this.info();
    if (i.state !== 'creature' || i.mode === 'sleep') return;
    const sp = this.app.idx.speciesByNo.get(i.rec.speciesNo);
    playCry(i.rec.cry?.length ? i.rec.cry : cryFor(sp));
  }

  wiggle() {
    const i = this.info();
    if (i.state !== 'creature' || i.mode === 'sleep') return;
    this.app.platform.vibrate([90, 70, 90, 140, 60]);
    this.wiggling = Date.now();
    this.emit();
  }

  /** Desk mode: now and then the capsule calls out or wiggles. */
  idle() {
    const i = this.info();
    if (i.state !== 'creature' || i.mode !== 'desk' || document.hidden) return;
    if (Math.random() < 0.15) { if (Math.random() < 0.5) this.cry(); else this.wiggle(); }
  }

  reset() {
    this.tag.mem.fill(0);
    this.tag.mem.set([0x03, 0x00, 0xfe], 0);
    this.save();
    this.emit();
  }

  // ---------- sitting on the PC dock ----------
  async dock(url = USB_URL) {
    await this.undock();
    this.dockState = 'connecting';
    this.emit();
    const c = this.app.client(url);
    this.client = c;
    c.on(MSG.CAP_READ, async (m) => {
      try { c.send(MSG.CAP_REPLY, { rid: m.rid, hex: toHex(await this.tag.readUser()) }); }
      catch (e) { c.send(MSG.CAP_REPLY, { rid: m.rid, ok: false, error: e.message }); }
    });
    c.on(MSG.CAP_WRITE, async (m) => {
      try {
        await this.tag.writePages(m.page, fromHex(m.hex));
        this.save();
        c.send(MSG.CAP_REPLY, { rid: m.rid });
        this.emit();
      } catch (e) { c.send(MSG.CAP_REPLY, { rid: m.rid, ok: false, error: e.message }); }
    });
    c.on('status', (s) => { if (s.status === 'closed' && this.client === c) { this.dockState = 'off'; this.client = null; this.emit(); } });
    try {
      await c.connect();
      const ack = await c.request(MSG.CAP_ATTACH, { uid: this.uid }, MSG.CAP_ATTACHED);
      this.dockState = 'docked';
      this.dockPcs = ack.pcs ?? 0;
      this.emit();
      return ack;
    } catch (e) {
      this.dockState = 'off';
      this.client = null;
      c.close();
      this.emit();
      throw e;
    }
  }

  async undock() {
    const c = this.client;
    this.client = null;
    if (c) { try { c.send(MSG.CAP_DETACH, { uid: this.uid }); } catch { /* closed */ } c.close(); }
    if (this.dockState !== 'off') { this.dockState = 'off'; this.emit(); }
  }
}

export { CAPSULE };
