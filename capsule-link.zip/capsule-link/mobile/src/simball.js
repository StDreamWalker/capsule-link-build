// Emulated ball hardware (Debug → Ball hardware). Until the real ball exists, the phone can hold
// balls that were made on the PC (Capsule dock → Virtual capsules). It can't make its own.
// With the phone "docked" at the PC, a ball (and whoever is inside) can be swapped between the PC
// and the phone. Off the dock, "Sync with phone" does what tapping a real ball does, and only then
// does the ball show up in the rest of the app. The emulated ball also does what the ball firmware
// does: counts steps in walk mode, records bumps in battle mode, cries and wiggles.
import { makeVirtualTag, toHex, fromHex, parseTagImage, pendingSteps, MSG, CAPSULE } from '../../shared/engine/index.js';
import { creatureCry } from '../../shared/ui/audio.js';

const KEY = 'capsule-link-mobile:emulated-balls';
const OLD_KEY = 'capsule-link-mobile:simball';
export const USB_URL = 'ws://127.0.0.1:47820';

export class EmulatedBalls {
  constructor(app) {
    this.app = app;
    this.subs = new Set();
    this.tags = new Map();
    this.docked = false; // is the phone sitting on the PC's dock (for swapping)?
    let stored = null;
    try { stored = JSON.parse(localStorage.getItem(KEY)); } catch { /* fresh */ }
    for (const [uid, hex] of Object.entries(stored ?? {})) this.tags.set(uid, makeVirtualTag(uid, fromHex(hex)));
    try { localStorage.removeItem(OLD_KEY); } catch { /* fine */ } // the old self-made ball is gone
    this.idleTimer = setInterval(() => this.idle(), 60000);
  }

  on(fn) { this.subs.add(fn); return () => this.subs.delete(fn); }
  emit() { for (const fn of this.subs) fn(); }
  save() {
    const o = {};
    for (const [uid, t] of this.tags) o[uid] = toHex(t.mem);
    try { localStorage.setItem(KEY, JSON.stringify(o)); } catch { /* storage full */ }
  }
  has(uid) { return this.tags.has(uid); }
  list() { return [...this.tags.keys()]; }

  /** The ball as the rest of the app sees a tag (the same shape as NFC). */
  asTag(uid) {
    const t = this.tags.get(uid);
    if (!t) throw new Error('That ball is not with the phone.');
    return {
      uid, simulated: true,
      readUser: () => t.readUser(),
      writePages: async (page, bytes) => { await t.writePages(page, bytes); this.save(); this.emit(); },
    };
  }

  /** What is inside: { state, rec, walk, pending, mode } */
  info(uid) {
    const t = this.tags.get(uid);
    if (!t) return { state: 'gone' };
    const p = parseTagImage(t.mem);
    if (!p.ok) return { state: p.blank ? 'blank' : p.main?.empty ? 'empty' : 'damaged', error: p.error };
    if (p.main.empty) return { state: 'empty', mode: p.main.rec.mode, walk: p.walk?.ok ? p.walk.walk : null };
    const walk = p.walk?.ok ? p.walk.walk : null;
    return { state: 'creature', rec: p.main.rec, walk, pending: pendingSteps(p.main.rec, walk), mode: p.main.rec.mode };
  }

  // ---------- swapping with the PC (phone on the dock) ----------
  async dock() {
    if (!this.app.settings.hubUrl) throw new Error('Link this phone to your PC first.');
    const c = this.app.client();
    try { await c.connect(); } finally { c.close(); }
    this.docked = true;
    this.emit();
  }
  undock() { this.docked = false; this.emit(); }

  async request(type, data) {
    const c = this.app.client();
    try {
      await c.connect();
      const r = await c.request(type, data, MSG.VTAG, 20000);
      if (!r.ok) throw new Error(r.error);
      return r;
    } catch (e) {
      if (/Unknown message/.test(e.message)) throw new Error('Update the PC app first.');
      throw e;
    } finally { c.close(); }
  }
  async pcBalls() { return (await this.request(MSG.VTAG_LIST, {})).list ?? []; }
  /** Take a ball off the PC onto the phone. */
  async takeFromPc(uid) {
    if (!this.docked) throw new Error('Put the phone on the PC dock first.');
    const r = await this.request(MSG.VTAG_TAKE, { uid });
    this.tags.set(uid, makeVirtualTag(uid, fromHex(r.hex)));
    this.save();
    this.emit();
    return r.capsule;
  }
  /** Hand a ball back to the PC. */
  /** A ball that is on the PC, reached over the link while the phone is docked: put someone in or take them out. */
  pcTag(uid) {
    return {
      uid, simulated: true, onPc: true,
      readUser: async () => fromHex((await this.request(MSG.VTAG_READ, { uid })).hex),
      writePages: async (page, bytes) => { await this.request(MSG.VTAG_WRITE, { uid, page, hex: toHex(bytes) }); },
    };
  }
  async giveToPc(uid) {
    if (!this.docked) throw new Error('Put the phone on the PC dock first.');
    const t = this.tags.get(uid);
    if (!t) return;
    // the PC must know everything the phone did with this ball (who is inside) before it takes it back
    await this.app.sync?.({ quiet: true }).catch(() => {});
    const inside = this.info(uid);
    const c = inside.state === 'creature' ? this.app.save.creatures[inside.rec.uid] : null;
    await this.request(MSG.VTAG_GIVE, { uid, hex: toHex(t.mem), capsule: this.app.save.capsules?.[uid] ? { name: this.app.save.capsules[uid].name } : null, creature: c ? JSON.parse(JSON.stringify(c)) : null });
    this.tags.delete(uid);
    // it's no longer synced with this phone
    if (this.app.save.capsules?.[uid]) this.app.local((s) => { if (s.capsules[uid]) s.capsules[uid].holder = 'pc'; });
    this.save();
    this.emit();
  }

  // ---------- what the firmware does ----------
  addSteps(uid, n) {
    const t = this.tags.get(uid);
    const i = this.info(uid);
    if (!t || i.state !== 'creature' || i.mode !== 'walk') return false;
    const before = i.walk?.steps ?? 0;
    t.addSteps(n);
    this.save();
    const after = this.info(uid).walk?.steps ?? 0;
    // a cry and a wiggle every 1,000 steps, like the real ball
    if (Math.floor(after / 1000) > Math.floor(before / 1000)) { this.cry(uid); this.wiggle(uid); }
    this.emit();
    return true;
  }

  bump(uid) {
    const t = this.tags.get(uid);
    const i = this.info(uid);
    if (!t || i.state !== 'creature') return { ok: false, reason: 'There is nobody inside that ball.' };
    if (i.mode !== 'battle') return { ok: false, reason: 'Set the ball to battle mode first.' };
    t.addSteps(0, { bump: true, peer: 0 });
    this.save();
    this.app.platform.vibrate([60, 30, 60]);
    this.emit();
    return { ok: true };
  }

  cry(uid) {
    const i = this.info(uid);
    if (i.state !== 'creature' || i.mode === 'sleep') return;
    creatureCry(this.app.idx.speciesByNo.get(i.rec.speciesNo), this.app.save.creatures[i.rec.uid] ?? null);
  }

  wiggle(uid) {
    const i = this.info(uid);
    if (i.state !== 'creature' || i.mode === 'sleep') return;
    this.app.platform.vibrate([90, 70, 90, 140, 60]);
    this.wiggling = { uid, at: Date.now() };
    this.emit();
  }

  /** Desk mode: now and then a ball calls out or wiggles. */
  idle() {
    if (document.hidden) return;
    for (const uid of this.tags.keys()) {
      const i = this.info(uid);
      if (i.state !== 'creature' || i.mode !== 'desk') continue;
      if (Math.random() < 0.15) { if (Math.random() < 0.5) this.cry(uid); else this.wiggle(uid); }
    }
  }
}

export { CAPSULE };
