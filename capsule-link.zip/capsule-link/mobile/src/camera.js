// "Show them around": the phone's camera, full screen, with your buddy (or anyone with you) looking at it from
// the corner. Point it at something and tap Show: they react to what's on screen (its colours: green leaves,
// blue water or sky, snow-white, the dark, warm sunset colours, grey city) and to where you are (the
// PokéAtlas's reading of the place), as themselves.
import { h, toast } from '../../shared/ui/dom.js';
import { spriteCanvas } from '../../shared/ui/art.js';
import { sfx } from '../../shared/ui/audio.js';
import { displayName } from '../../shared/engine/index.js';

/** The colours in the middle of the picture, as one word: green, blue, white, dark, warm or grey. */
function colourOf(video) {
  const cv = document.createElement('canvas'); cv.width = 32; cv.height = 32;
  const x = cv.getContext('2d', { willReadFrequently: true });
  const vw = video.videoWidth || 320, vh = video.videoHeight || 240;
  x.drawImage(video, vw * 0.2, vh * 0.2, vw * 0.6, vh * 0.6, 0, 0, 32, 32);
  const d = x.getImageData(0, 0, 32, 32).data;
  let r = 0, g = 0, b = 0, n = 0, sat = 0;
  for (let i = 0; i < d.length; i += 4) { r += d[i]; g += d[i + 1]; b += d[i + 2]; n++; sat += Math.max(d[i], d[i + 1], d[i + 2]) - Math.min(d[i], d[i + 1], d[i + 2]); }
  r /= n; g /= n; b /= n; sat /= n;
  const luma = 0.299 * r + 0.587 * g + 0.114 * b;
  if (luma < 45) return 'dark';
  if (luma > 200 && sat < 30) return 'white';
  if (sat < 22) return 'grey';
  if (g > r * 1.05 && g > b * 1.02) return 'green';
  if (b > r * 1.08 && b >= g * 0.95) return 'blue';
  if (r > b * 1.2 && r >= g) return 'warm';
  return 'grey';
}

export async function showAround(app) {
  const team = app.team().filter((c) => !c.egg);
  if (!team.length) { toast('Nobody with you to show around.', 'err'); return; }
  if (!navigator.mediaDevices?.getUserMedia) { toast('This phone can’t open the camera here.', 'err'); return; }
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false }); }
  catch (e) { toast(/denied|NotAllowed/i.test(String(e?.name ?? e)) ? 'The camera is turned off for Capsule Link. Allow it in the phone’s settings to show them around.' : `Couldn’t open the camera: ${e.message ?? e}`, 'err'); return; }
  let who = team.find((c) => c.uid === app.settings.buddyUid) ?? team[0];
  const session = Date.now();
  const video = h('video', { class: 'cam-video', autoplay: true, playsinline: true, muted: true });
  video.srcObject = stream;
  const bubble = h('div', { class: 'cam-bubble' }, `Point the camera at something and tap Show ${displayName(app.idx, who)}.`);
  const mon = h('div', { class: 'cam-mon' });
  const paintMon = () => { mon.replaceChildren(spriteCanvas(app.bank, who, { scale: 3, animate: true })); showBtn.textContent = `Show ${displayName(app.idx, who)}`; };
  const close = () => { try { stream.getTracks().forEach((tr) => tr.stop()); } catch { /* fine */ } wrap.remove(); };
  const showBtn = h('button', { class: 'btn primary big' }, 'Show');
  showBtn.onclick = () => {
    const cam = colourOf(video);
    const base = app.settings.useLocation ? app.settings.atlasHere : app.settings.atlasSpot?.table;
    const t = base ? { ...base, at: `${base.at}:cam:${session}`, cam } : { at: `cam:${session}`, label: 'here', C: {}, H: {}, cam };
    const r = app.feelHere(t, { mode: 'camera', uids: [who.uid] })[0];
    if (!r) return;
    sfx('blip');
    bubble.replaceChildren(h('b', null, `${r.emoji} ${r.mood}`), h('span', null, r.line));
    mon.classList.remove('hop'); void mon.offsetWidth; mon.classList.add(['love', 'home', 'wonder', 'curious', 'splash', 'lively'].includes(r.kind) ? 'hop' : 'still');
  };
  const pickers = team.length > 1 ? h('div', { class: 'cam-who' }, team.map((c) => h('button', { class: `cam-pick ${c.uid === who.uid ? 'on' : ''}`, title: displayName(app.idx, c), onclick: (e) => {
    who = c; paintMon(); for (const b of e.currentTarget.parentElement.children) b.classList.toggle('on', b === e.currentTarget);
    bubble.textContent = `Show ${displayName(app.idx, c)} something.`;
  } }, spriteCanvas(app.bank, c, { scale: 1 })))) : null;
  const wrap = h('div', { class: 'cam-wrap' }, video,
    h('div', { class: 'cam-top' }, h('button', { class: 'btn small', onclick: close }, '✕ Done'), pickers),
    h('div', { class: 'cam-bottom' }, mon, bubble, showBtn));
  document.body.append(wrap);
  paintMon();
}
