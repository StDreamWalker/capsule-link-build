// The phone's Home: a hub like the PC's. Your trainer card, the phone's own app (Monitor: your buddy, walks and
// what's around you) and who's with you as the two big cards, then the other apps as tiles.
import { h, mount, fmtNum } from '../../shared/ui/dom.js';
import { idCardEl, partyForCard } from '../../shared/ui/idcard.js';
import { spriteCanvas } from '../../shared/ui/art.js';
import { svgIcon } from '../../shared/ui/icons.js';
import { sfx } from '../../shared/ui/audio.js';
import { displayName, mood as moodOf } from '../../shared/engine/index.js';

/** The phone's apps: id, title, line, icon, tint (the same colours as the PC's apps). */
export const PHONE_APPS = [
  { id: 'together', title: 'Activities', desc: 'Quality time, cooking, fishing, games', icon: 'activities', tint: '#2fa36b' },
  { id: 'battle', title: 'Battle Link', desc: 'Wild battles and Showdown', icon: 'battle', tint: '#e5484d' },
  { id: 'capsule', title: 'Capsules', desc: 'Tap, sync and swap your balls', icon: 'dock', tint: '#3b6cf6' },
  { id: 'atlas', title: 'PokéAtlas', desc: 'Who lives where you are', icon: 'atlas', tint: '#2a9d8f' },
  { id: 'datalab', title: 'Data Lab', desc: 'Species, moves and formulas', icon: 'lab', tint: '#f2a516' },
  { id: 'friends', title: 'Friends', desc: 'Messages, gifts, trades', icon: 'friends', tint: '#0ea5e9' },
  { id: 'trainer', title: 'Trainer ID', desc: 'Your card', icon: 'id', tint: '#8b5cf6' },
  { id: 'link', title: 'PC Link', desc: 'Link and sync with your PC', icon: 'desktop', tint: '#12b5a5' },
  { id: 'settings', title: 'Settings', desc: 'Sound, data, backups, debug', icon: 'settings', tint: '#64748b' },
];

export function homeView(app) {
  const el = h('div', { class: 'm-home' });
  const open = (id) => { sfx('blip'); app.go(id); };

  function render() {
    const t = app.save.trainer;
    const team = app.team();
    const b = app.buddy();
    const hour = new Date().getHours();
    const greet = hour < 5 ? 'Up late' : hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
    const linked = !!app.settings.hubUrl;
    const where = app.atlasTable?.()?.label ?? app.settings.surroundings?.town ?? '';
    const mood = b ? moodOf(b) : null;
    mount(el,
      h('header', { class: 'm-home-head' },
        h('h1', null, `${greet}, ${t?.name ?? 'Trainer'}`),
        h('p', { class: 'dim' }, [`${team.length} with you`, app.walk.walking ? `${fmtNum(app.walk.session)} steps this walk` : null, where ? `📍 ${where}` : null].filter(Boolean).join(' · '))),
      // the phone's own app, big
      h('button', { class: 'hero monitor', onclick: () => open('buddy') },
        h('span', { class: 'hero-top' }, h('span', { class: 'hero-icon' }, svgIcon('heart', { size: 22 })), h('span', { class: 'hero-badge' }, 'Only on your phone')),
        h('span', { class: 'hero-title' }, 'Monitor'),
        h('span', { class: 'hero-desc' }, b ? `${displayName(app.idx, b)}${mood?.label ? ` · ${mood.label.toLowerCase()}` : ''}. Walks, care, chat and what’s around you.` : 'Your buddy, walks, care, chat and what’s around you.'),
        h('span', { class: 'hero-art monitor-art' },
          h('span', { class: 'pulse' }),
          b ? spriteCanvas(app.bank, b, { scale: 2, animate: true }) : null,
          h('span', { class: 'hero-steps' }, h('b', null, fmtNum(app.walk.session)), app.walk.walking ? ' steps · walking' : ' steps'))),
      h('button', { class: 'hero party', onclick: () => open('party') },
        h('span', { class: 'hero-icon' }, svgIcon('storage', { size: 22 })),
        h('span', { class: 'hero-title' }, 'With you'),
        h('span', { class: 'hero-desc' }, team.length ? 'Who you carry: summaries, moves, items, send them home.' : 'Nobody with you yet. Bring someone from the PC, or tap a ball.'),
        h('span', { class: 'hero-art party-art' }, team.slice(0, 6).map((c) => h('span', { class: 'orb' }, spriteCanvas(app.bank, c, { scale: 1 }))))),
      // Full PC mode (Settings → Debug): every PC app, on this phone
      app.fullPc ? h('button', { class: 'hero pcmode', onclick: () => { sfx('select'); app.openPcApps(); } },
        h('span', { class: 'hero-top' }, h('span', { class: 'hero-icon' }, svgIcon('desktop', { size: 22 })), h('span', { class: 'hero-badge' }, 'Full PC mode')),
        h('span', { class: 'hero-title' }, 'PC apps'),
        h('span', { class: 'hero-desc' }, 'The R.A.N.C.H., the Market, the storage system and everything else the PC does.')) : null,
      h('div', { class: 'section-title' }, 'Apps'),
      h('div', { class: 'app-grid' }, PHONE_APPS.map((p) => h('button', { class: 'app-tile', style: { '--tint': p.tint }, onclick: () => open(p.id) },
        h('span', { class: 'app-icon' }, svgIcon(p.icon, { size: 22 })),
        h('span', { class: 'app-text' }, h('span', { class: 'app-title' }, p.title), h('span', { class: 'app-desc' }, p.id === 'link' ? (app.fullPc ? 'Linked to this phone’s own PC' : linked ? (app.save.queue.length ? `${app.save.queue.length} to sync` : 'Linked to your PC') : 'Not linked yet') : p.desc))))),
      h('div', { class: 'section-title' }, 'Your trainer card'),
      t ? h('button', { class: 'm-card-btn', title: 'Your trainer card (tap to turn it over)' }, idCardEl(t, { scale: 1, tilt: false, party: partyForCard(app.bank, team, (c) => displayName(app.idx, c)) })) : null,
      h('section', { class: 'panel stats-card' },
        h('div', null, h('div', { class: 'stat-num' }, fmtNum(app.save.stats?.battlesWon ?? 0)), h('div', { class: 'dim micro' }, 'Battles won')),
        h('div', null, h('div', { class: 'stat-num' }, fmtNum(Object.keys(app.save.capsules ?? {}).length)), h('div', { class: 'dim micro' }, 'Capsules')),
        h('div', null, h('div', { class: 'stat-num' }, fmtNum(team.length)), h('div', { class: 'dim micro' }, 'With you'))));
  }
  render();
  const offs = [app.on((w) => { if (['steps', 'surroundings', 'sync'].includes(w)) render(); })];
  return { el, update: render, dispose: () => offs.forEach((f) => f()) };
}
