// The PokéAtlas on the phone: the whole atlas (map, encounters, fauna, legends…), and what it means for your
// walks and wild battles. With location on it's anchored to where you are: it follows you, and the scan can't
// be moved by tapping or dragging the map. With location off you can look anywhere and pick a spot to use.
import { h, toast } from '../../shared/ui/dom.js';
import { atlasApp } from '../../shared/ui/atlasApp.js';
import { tableLine } from '../../shared/atlas/scan.js';

export function atlasView(app) {
  const here = () => {
    if (!app.settings.useLocation) return null;
    const s = app.lastSense?.exact ?? (app.settings.atlasHere ? { lat: app.settings.atlasHere.lat, lon: app.settings.atlasHere.lon } : null);
    return s && Number.isFinite(s.lat) ? { lat: s.lat, lon: s.lon, label: app.lastSense?.town || app.settings.atlasHere?.label || '' } : null;
  };
  const A = atlasApp({
    current: () => {
      if (app.settings.useLocation) return app.settings.atlasHere ? { label: `Where you are · ${app.settings.atlasHere.label}` } : { label: app.sensing ? 'Finding where you are…' : 'Where you are' };
      return app.settings.atlasSpot ?? null;
    },
    anchor: here,
    onLocate: () => app.lookNow({ quiet: false }),
    start: () => app.settings.atlasSpot || null,
    onSpot: async (spot) => {
      try {
        const t = await app.setAtlasSpot(spot);
        toast(`Walks and “Where you are” battles now use ${tableLine(t)}.`, 'ok');
      } catch (e) { toast(`Couldn’t read that spot: ${e.message}`, 'err'); }
    },
    onClear: app.settings.useLocation ? null : () => app.local((st) => { delete st.settings.atlasSpot; }),
    note: app.settings.useLocation ? 'Following where you are. To look around anywhere else, turn location off in Monitor → Where.' : 'Location is off: tap the map to scan anywhere, then “Use this spot” for walks and battles.',
  });
  const el = h('div', { class: 'm-atlas' }, A.el);
  const off = app.on((w) => { if (w === 'surroundings') A.refresh(); });
  return {
    el, dispose: () => { off(); A.dispose(); }, update: () => A.refresh(),
    // (with location on and no fresh reading, find where you are now)
    mounted: () => { if (app.settings.useLocation && (!app.lastSense || Date.now() - (app.lastSense.at ?? 0) > 10 * 60000)) app.lookNow({ quiet: true }).catch?.(() => {}); },
  };
}
