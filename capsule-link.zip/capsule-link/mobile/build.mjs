// Builds the phone app's web layer into mobile/www (Capacitor's webDir).
//   node build.mjs          -> www/
//   node build.mjs --web    -> dist-web/index.html (single file, runs in a desktop browser with simulated NFC/steps)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const shared = path.join(here, '..', 'shared');
let esbuild;
try { esbuild = await import('esbuild'); } catch {
  if (process.env.ESBUILD_PATH) esbuild = await import(pathToFileURL(process.env.ESBUILD_PATH).href);
  else { console.error('esbuild is missing. Run "npm install" in the mobile folder first.'); process.exit(1); }
}
const { buildInfo } = await import(pathToFileURL(path.join(here, '..', 'tools', 'buildinfo.mjs')).href);
// wild battles: Showdown's simulator and battle screen, loaded the first time a battle starts
const sd = await import(pathToFileURL(path.join(shared, 'sdbattle', 'build.mjs')).href);
const info = buildInfo();
const opts = { define: { __BUILD__: JSON.stringify(info) }, entryPoints: [path.join(here, 'src/main.js')], bundle: true, charset: 'ascii', platform: 'browser', format: 'iife', target: ['chrome80'] /* older phones' web views too */, logLevel: 'warning' };

if (process.argv.includes('--web')) {
  const r = await esbuild.build({ ...opts, write: false, minify: true });
  const css = [path.join(shared, 'ui/font/font.css'), path.join(shared, 'ui/base.css'), path.join(here, 'src/styles.css')].map((f) => fs.readFileSync(f, 'utf8')).join('\n');
  fs.mkdirSync(path.join(here, 'dist-web'), { recursive: true });
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><title>Capsule Link phone</title><style>${css}</style></head><body><script>${r.outputFiles[0].text.replace(/<\/script/gi, '<\\/script')}</script></body></html>`;
  fs.writeFileSync(path.join(here, 'dist-web/index.html'), html);
  await sd.buildShowdownBattle(esbuild, path.join(here, 'dist-web', 'showdown-battle.js'));
  fs.writeFileSync(path.join(here, 'dist-web', 'showdown.css'), sd.showdownCss());
  console.log(`Built mobile/dist-web/index.html (${Math.round(html.length / 1024)} KB)`);
} else {
  const out = path.join(here, 'www');
  fs.rmSync(out, { recursive: true, force: true });
  fs.mkdirSync(out, { recursive: true });
  await esbuild.build({ ...opts, outfile: path.join(out, 'app.js'), minify: true });
  fs.copyFileSync(path.join(here, 'src/index.html'), path.join(out, 'index.html'));
  fs.copyFileSync(path.join(here, 'src/styles.css'), path.join(out, 'styles.css'));
  fs.copyFileSync(path.join(shared, 'ui/base.css'), path.join(out, 'base.css'));
  fs.copyFileSync(path.join(shared, 'ui/font/font.css'), path.join(out, 'font.css'));
  await sd.buildShowdownBattle(esbuild, path.join(out, 'showdown-battle.js'));
  fs.writeFileSync(path.join(out, 'showdown.css'), sd.showdownCss());
  fs.writeFileSync(path.join(out, 'version.json'), JSON.stringify(info, null, 2));
  console.log(`Built mobile/www (version ${info.version})`);
}
