package com.capsulelink.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.net.wifi.WifiManager;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.MifareUltralight;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Base64;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import androidx.core.content.pm.ShortcutInfoCompat;
import androidx.core.content.pm.ShortcutManagerCompat;
import androidx.core.graphics.drawable.IconCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.SharedPreferences;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.Iterator;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Native side of the Capsule Link phone app.
 *
 *  NFC        startNfc / stopNfc / writeTag, event "nfcTag" {uid, size, data(base64 of user memory from page 4)}
 *  Walking    startWalk / stopWalk / getWalk / ackSteps, event "steps" {sessionSteps, pending}
 *  Capsules   startBleScan / stopBleScan, event "capsuleBeacon" {uid4, bumps, mode, battery, rssi}
 *  Showdown   openShowdown / takeShowdownEvents, event "showdown" (call takeShowdownEvents to read them)
 *  Bumps      setCapsuleWatch: notifies natively when one of your capsules records a bump
 *  Misc       ensurePermissions, showNotification, vibrate, discoverPc
 */
@CapacitorPlugin(
    name = "CapsuleLink",
    permissions = {
        @Permission(alias = "activity", strings = { Manifest.permission.ACTIVITY_RECOGNITION }),
        @Permission(alias = "notifications", strings = { Manifest.permission.POST_NOTIFICATIONS }),
        @Permission(alias = "bluetooth", strings = { Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT }),
        @Permission(alias = "location", strings = { Manifest.permission.ACCESS_FINE_LOCATION })
    }
)
public class CapsuleLinkPlugin extends Plugin {
    private static final int USER_BYTES = 232;           // whole capsule NDEF message
    private static final int MANUFACTURER_ID = 0xFFFF;   // "no company" id, fine for hobby hardware
    private static final String ALERT_CHANNEL = "alerts";

    private NfcAdapter nfc;
    private volatile Tag lastTag;
    private boolean readerOn = false;
    private ScanCallback scanCallback;
    private final Handler main = new Handler(Looper.getMainLooper());

    // Showdown events wait here until the web layer reads them (they can arrive while it is paused)
    private static CapsuleLinkPlugin instance;
    private static final List<String> showdownQueue = new ArrayList<>();
    private boolean resumed = true;
    private final Set<String> myCapsules = new HashSet<>();
    private final java.util.Map<String, Integer> lastBumps = new java.util.HashMap<>();

    // ---------- app updates from the PC ----------
    // A newer web layer (the app's own code) arrives with a sync; it is saved in the app's files
    // and Capacitor serves it instead of the copy inside the APK. A newer APK always wins.
    private static final String PREFS = com.getcapacitor.plugin.WebView.WEBVIEW_PREFS_NAME;
    private static final String PATH_KEY = com.getcapacitor.plugin.WebView.CAP_SERVER_PATH;

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }
    private JSObject builtInInfo() {
        try (InputStream in = getContext().getAssets().open("public/version.json")) { return new JSObject(readAll(in)); }
        catch (Exception e) { return new JSObject(); }
    }
    private static JSObject fileInfo(File dir) {
        try (InputStream in = new java.io.FileInputStream(new File(dir, "version.json"))) { return new JSObject(readAll(in)); }
        catch (Exception e) { return new JSObject(); }
    }
    private static boolean newer(String a, String b) {
        String[] pa = (a == null ? "0" : a).split("[.-]"), pb = (b == null ? "0" : b).split("[.-]");
        for (int i = 0; i < Math.max(pa.length, pb.length); i++) {
            int x = 0, y = 0;
            try { x = i < pa.length ? Integer.parseInt(pa[i]) : 0; } catch (NumberFormatException e) { x = 0; }
            try { y = i < pb.length ? Integer.parseInt(pb[i]) : 0; } catch (NumberFormatException e) { y = 0; }
            if (x != y) return x > y;
        }
        return false;
    }
    private static void deleteAll(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteAll(k);
        f.delete();
    }
    /** Drop a saved update that is older than (or doesn't fit) the installed APK. */
    private void checkSavedUpdate() {
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String path = prefs.getString(PATH_KEY, null);
        if (path == null || path.isEmpty()) return;
        JSObject mine = builtInInfo(), saved = fileInfo(new File(path));
        boolean keep = new File(path, "index.html").exists()
            && newer(saved.getString("version"), mine.getString("version"))
            && String.valueOf(saved.getString("phoneNative")).equals(String.valueOf(mine.getString("phoneNative")));
        if (!keep) {
            prefs.edit().remove(PATH_KEY).apply();
            deleteAll(new File(getContext().getFilesDir(), "web"));
            main.post(() -> getBridge().setServerAssetPath("public"));
        }
    }

    @PluginMethod
    public void appInfo(PluginCall call) {
        JSObject r = new JSObject();
        r.put("builtIn", builtInInfo());
        String path = getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PATH_KEY, "");
        r.put("updated", path != null && !path.isEmpty() ? fileInfo(new File(path)) : null);
        call.resolve(r);
    }

    @PluginMethod
    public void installWebBundle(PluginCall call) {
        String version = call.getString("version", "0").replaceAll("[^0-9A-Za-z._-]", "");
        JSObject files = call.getObject("files");
        if (files == null) { call.reject("No files in the update."); return; }
        File web = new File(getContext().getFilesDir(), "web");
        File dir = new File(web, version);
        try {
            deleteAll(dir);
            dir.mkdirs();
            Iterator<String> keys = files.keys();
            while (keys.hasNext()) {
                String rel = keys.next();
                if (rel.contains("..")) continue;
                File f = new File(dir, rel);
                f.getParentFile().mkdirs();
                try (FileOutputStream o = new FileOutputStream(f)) { o.write(Base64.decode(files.getString(rel), Base64.DEFAULT)); }
            }
        } catch (Exception e) { call.reject("Couldn't save the update: " + e.getMessage()); return; }
        File[] old = web.listFiles();
        if (old != null) for (File o : old) if (!o.equals(dir)) deleteAll(o);
        getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(PATH_KEY, dir.getAbsolutePath()).apply();
        call.resolve();
        main.postDelayed(() -> getBridge().setServerBasePath(dir.getAbsolutePath()), 400);
    }

    @PluginMethod
    public void useBuiltIn(PluginCall call) {
        getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(PATH_KEY).apply();
        deleteAll(new File(getContext().getFilesDir(), "web"));
        call.resolve();
        main.postDelayed(() -> getBridge().setServerAssetPath("public"), 400);
    }

    @Override
    public void load() {
        instance = this;
        checkSavedUpdate();
        nfc = NfcAdapter.getDefaultAdapter(getContext());
        WalkService.listener = (session, pending) -> {
            JSObject o = new JSObject();
            o.put("sessionSteps", session);
            o.put("pending", pending);
            notifyListeners("steps", o);
        };
        createAlertChannel();
        // the app may have been opened by tapping a capsule
        Intent intent = getActivity().getIntent();
        if (intent != null) handleNfcIntent(intent);
    }

    // ------------------------------------------------------------------ permissions

    @PluginMethod
    public void ensurePermissions(PluginCall call) {
        List<String> wanted = new ArrayList<>();
        if (call.getBoolean("activity", false) && Build.VERSION.SDK_INT >= 29) wanted.add("activity");
        if (call.getBoolean("notifications", false) && Build.VERSION.SDK_INT >= 33) wanted.add("notifications");
        if (call.getBoolean("bluetooth", false)) wanted.add(Build.VERSION.SDK_INT >= 31 ? "bluetooth" : "location");
        List<String> missing = new ArrayList<>();
        for (String a : wanted) if (getPermissionState(a) != PermissionState.GRANTED) missing.add(a);
        if (missing.isEmpty()) {
            call.resolve(permissionStatus());
            return;
        }
        requestPermissionForAliases(missing.toArray(new String[0]), call, "permissionsDone");
    }

    @PermissionCallback
    private void permissionsDone(PluginCall call) {
        call.resolve(permissionStatus());
    }

    private JSObject permissionStatus() {
        JSObject o = new JSObject();
        o.put("activity", Build.VERSION.SDK_INT >= 29 ? stateName(getPermissionState("activity")) : "granted");
        o.put("notifications", Build.VERSION.SDK_INT >= 33 ? stateName(getPermissionState("notifications")) : "granted");
        o.put("bluetooth", stateName(getPermissionState(Build.VERSION.SDK_INT >= 31 ? "bluetooth" : "location")));
        o.put("nfc", nfc == null ? "missing" : (nfc.isEnabled() ? "granted" : "off"));
        return o;
    }

    private static String stateName(PermissionState s) {
        if (s == PermissionState.GRANTED) return "granted";
        if (s == PermissionState.DENIED) return "denied";
        return "prompt";
    }

    // ------------------------------------------------------------------ NFC

    @PluginMethod
    public void startNfc(PluginCall call) {
        if (nfc == null) { call.reject("This phone has no NFC."); return; }
        readerOn = true;
        main.post(this::enableReader);
        JSObject o = new JSObject();
        o.put("enabled", nfc.isEnabled());
        call.resolve(o);
    }

    @PluginMethod
    public void stopNfc(PluginCall call) {
        readerOn = false;
        main.post(() -> { try { if (nfc != null) nfc.disableReaderMode(getActivity()); } catch (Exception ignored) { } });
        call.resolve();
    }

    private void enableReader() {
        if (nfc == null || getActivity() == null) return;
        try {
            Bundle opts = new Bundle();
            opts.putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 250);
            nfc.enableReaderMode(getActivity(), this::readTag,
                NfcAdapter.FLAG_READER_NFC_A | NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS | NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK, opts);
        } catch (Exception ignored) {
            // the activity is not resumed yet; handleOnResume turns it on
        }
    }

    @Override
    protected void handleOnResume() {
        super.handleOnResume();
        resumed = true;
        if (readerOn) enableReader();
        synchronized (showdownQueue) { if (!showdownQueue.isEmpty()) notifyListeners("showdown", new JSObject()); }
    }

    @Override
    protected void handleOnPause() {
        super.handleOnPause();
        resumed = false;
        try { if (nfc != null) nfc.disableReaderMode(getActivity()); } catch (Exception ignored) { }
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        handleNfcIntent(intent);
    }

    private void handleNfcIntent(Intent intent) {
        String action = intent.getAction();
        if (!NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action) && !NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)
            && !NfcAdapter.ACTION_TAG_DISCOVERED.equals(action)) return;
        Tag tag;
        if (Build.VERSION.SDK_INT >= 33) tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag.class);
        else tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (tag != null) new Thread(() -> readTag(tag)).start();
    }

    /** Reads the capsule's user memory and hands it to the web layer. */
    private void readTag(Tag tag) {
        lastTag = tag;
        JSObject out = new JSObject();
        out.put("uid", hex(tag.getId()));
        MifareUltralight mu = MifareUltralight.get(tag);
        if (mu == null) {
            out.put("error", "This tag type is not supported. Capsules use NTAG215, NTAG216 or NTAG I2C plus tags.");
            notifyListeners("nfcTag", out, true);
            return;
        }
        try {
            mu.connect();
            byte[] cc = mu.readPages(3);
            int size = (cc[2] & 0xFF) * 8;
            byte[] user = new byte[USER_BYTES];
            for (int off = 0; off < USER_BYTES; off += 16) {
                byte[] chunk = mu.readPages(4 + off / 4);
                System.arraycopy(chunk, 0, user, off, Math.min(16, USER_BYTES - off));
            }
            out.put("size", size);
            out.put("data", Base64.encodeToString(user, Base64.NO_WRAP));
        } catch (IOException e) {
            out.put("error", "Hold the capsule still against the back of the phone.");
        } finally {
            try { mu.close(); } catch (IOException ignored) { }
        }
        notifyListeners("nfcTag", out, true);
    }

    @PluginMethod
    public void writeTag(PluginCall call) {
        Tag tag = lastTag;
        Integer page = call.getInt("page");
        String data = call.getString("data");
        String uid = call.getString("uid");
        if (tag == null) { call.reject("Tap the capsule first."); return; }
        if (page == null || data == null) { call.reject("Missing page or data."); return; }
        if (uid != null && !uid.equalsIgnoreCase(hex(tag.getId()))) { call.reject("A different capsule is in range now."); return; }
        byte[] bytes = Base64.decode(data, Base64.DEFAULT);
        if (bytes.length % 4 != 0) { call.reject("Writes must be whole 4-byte pages."); return; }
        MifareUltralight mu = MifareUltralight.get(tag);
        if (mu == null) { call.reject("This tag type is not supported."); return; }
        try {
            mu.connect();
            for (int i = 0; i < bytes.length / 4; i++) {
                mu.writePage(page + i, Arrays.copyOfRange(bytes, i * 4, i * 4 + 4));
            }
            call.resolve();
        } catch (IOException e) {
            call.reject("The capsule moved away before writing finished. Hold it still and tap again.");
        } finally {
            try { mu.close(); } catch (IOException ignored) { }
        }
    }

    // ------------------------------------------------------------------ walking

    @PluginMethod
    public void startWalk(PluginCall call) {
        SensorManager sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
        if (sm == null || (sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) == null && sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) == null)) {
            call.reject("This phone has no step sensor.");
            return;
        }
        WalkService.resetSession(getContext());
        Intent i = new Intent(getContext(), WalkService.class);
        i.putExtra("title", call.getString("title", "Walking together"));
        i.putExtra("text", call.getString("text", "Steps build friendship."));
        try {
            ContextCompat.startForegroundService(getContext(), i);
            call.resolve(walkStatus());
        } catch (Exception e) {
            call.reject("Could not start counting steps: " + e.getMessage());
        }
    }

    @PluginMethod
    public void stopWalk(PluginCall call) {
        getContext().stopService(new Intent(getContext(), WalkService.class));
        JSObject o = walkStatus();
        o.put("walking", false);
        call.resolve(o);
    }

    @PluginMethod
    public void getWalk(PluginCall call) {
        call.resolve(walkStatus());
    }

    @PluginMethod
    public void ackSteps(PluginCall call) {
        WalkService.ack(getContext(), call.getInt("count", 0));
        call.resolve(walkStatus());
    }

    private JSObject walkStatus() {
        JSObject o = new JSObject();
        o.put("walking", WalkService.running);
        o.put("sessionSteps", WalkService.session(getContext()));
        o.put("pending", WalkService.pending(getContext()));
        return o;
    }

    // ------------------------------------------------------------------ capsule beacons (bumps)

    @PluginMethod
    public void startBleScan(PluginCall call) {
        BluetoothManager bm = (BluetoothManager) getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = bm != null ? bm.getAdapter() : null;
        if (adapter == null) { call.reject("This phone has no Bluetooth."); return; }
        if (!adapter.isEnabled()) { call.reject("Turn on Bluetooth to hear your capsules."); return; }
        if (scanCallback != null) { call.resolve(); return; }
        String scanPerm = Build.VERSION.SDK_INT >= 31 ? Manifest.permission.BLUETOOTH_SCAN : Manifest.permission.ACCESS_FINE_LOCATION;
        if (ContextCompat.checkSelfPermission(getContext(), scanPerm) != PackageManager.PERMISSION_GRANTED) {
            call.reject("Allow nearby devices for Capsule Link first.");
            return;
        }
        BluetoothLeScanner scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { call.reject("Bluetooth scanning is not available."); return; }
        ScanFilter filter = new ScanFilter.Builder()
            .setManufacturerData(MANUFACTURER_ID, new byte[] { 0x43, 0x4C }, new byte[] { (byte) 0xFF, (byte) 0xFF })
            .build();
        ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        scanCallback = new ScanCallback() {
            @Override public void onScanResult(int callbackType, ScanResult result) { handleBeacon(result); }
            @Override public void onBatchScanResults(List<ScanResult> results) { for (ScanResult r : results) handleBeacon(r); }
        };
        try {
            scanner.startScan(Collections.singletonList(filter), settings, scanCallback);
            call.resolve();
        } catch (SecurityException e) {
            scanCallback = null;
            call.reject("Allow nearby devices for Capsule Link in the phone settings.");
        }
    }

    @PluginMethod
    public void stopBleScan(PluginCall call) {
        BluetoothManager bm = (BluetoothManager) getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = bm != null ? bm.getAdapter() : null;
        try {
            if (adapter != null && adapter.getBluetoothLeScanner() != null && scanCallback != null) adapter.getBluetoothLeScanner().stopScan(scanCallback);
        } catch (SecurityException ignored) { }
        scanCallback = null;
        call.resolve();
    }

    /** Beacon payload after the company id: 'C' 'L' version uid4[4] bumps(u16 LE) mode battery */
    private void handleBeacon(ScanResult r) {
        ScanRecord rec = r.getScanRecord();
        if (rec == null) return;
        byte[] d = rec.getManufacturerSpecificData(MANUFACTURER_ID);
        if (d == null || d.length < 10 || d[0] != 0x43 || d[1] != 0x4C) return;
        JSObject o = new JSObject();
        o.put("version", d[2] & 0xFF);
        o.put("uid4", hex(Arrays.copyOfRange(d, 3, 7)));
        o.put("bumps", (d[7] & 0xFF) | ((d[8] & 0xFF) << 8));
        o.put("mode", d[9] & 0xFF);
        o.put("battery", d.length > 10 ? (d[10] & 0xFF) : -1);
        o.put("rssi", r.getRssi());
        notifyListeners("capsuleBeacon", o);
        String uid4 = o.getString("uid4");
        int bumps = (d[7] & 0xFF) | ((d[8] & 0xFF) << 8);
        Integer before = lastBumps.put(uid4, bumps);
        if (before != null && bumps > before && !resumed && myCapsules.contains(uid4)) {
            postAlert("Capsule bump!", "Your capsule bumped another one. Tap to battle on Showdown.", 2002);
        }
    }

    @PluginMethod
    public void setCapsuleWatch(PluginCall call) {
        myCapsules.clear();
        try {
            JSONArray arr = call.getArray("mine");
            if (arr != null) for (int i = 0; i < arr.length(); i++) myCapsules.add(arr.getString(i).toUpperCase());
        } catch (Exception ignored) { }
        call.resolve();
    }

    // ------------------------------------------------------------------ Showdown

    @PluginMethod
    public void openShowdown(PluginCall call) {
        String url = call.getString("url", "https://play.pokemonshowdown.com");
        String script = call.getString("script", "");
        Intent i = new Intent(getContext(), ShowdownActivity.class);
        i.putExtra(ShowdownActivity.EXTRA_URL, url);
        i.putExtra(ShowdownActivity.EXTRA_SCRIPT, script);
        i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        getActivity().startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void takeShowdownEvents(PluginCall call) {
        JSArray out = new JSArray();
        synchronized (showdownQueue) {
            for (String s : showdownQueue) out.put(s);
            showdownQueue.clear();
        }
        JSObject o = new JSObject();
        o.put("events", out);
        call.resolve(o);
    }

    /** Called by ShowdownActivity's bridge. */
    static void deliverShowdown(String json) {
        synchronized (showdownQueue) {
            showdownQueue.add(json);
            if (showdownQueue.size() > 200) showdownQueue.remove(0);
        }
        CapsuleLinkPlugin p = instance;
        if (p != null) p.main.post(() -> p.notifyListeners("showdown", new JSObject()));
    }

    private void postAlert(String title, String body, int id) {
        Context ctx = getContext();
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        Intent open = new Intent(ctx, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, id, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, ALERT_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_capsule).setContentTitle(title).setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi);
        try { NotificationManagerCompat.from(ctx).notify(id, b.build()); } catch (SecurityException ignored) { }
    }

    // ------------------------------------------------------------------ notifications, haptics, discovery

    private void createAlertChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(ALERT_CHANNEL, "Battles and capsules", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Battle invitations and capsule bumps");
            NotificationManager nm = getContext().getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    @PluginMethod
    public void showNotification(PluginCall call) {
        Context ctx = getContext();
        Intent open = new Intent(ctx, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, ALERT_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_capsule)
            .setContentTitle(call.getString("title", "Capsule Link"))
            .setContentText(call.getString("body", ""))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi);
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            call.reject("Notifications are turned off for Capsule Link.");
            return;
        }
        try {
            NotificationManagerCompat.from(ctx).notify(call.getInt("id", 2001), b.build());
            call.resolve();
        } catch (SecurityException e) {
            call.reject("Notifications are turned off for Capsule Link.");
        }
    }

    /** A home-screen shortcut with the name and icon chosen on the PC (Android can't rename the installed app itself). */
    @PluginMethod
    public void pinShortcut(PluginCall call) {
        Context ctx = getContext();
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) { call.reject("This home screen can't add shortcuts."); return; }
        String label = call.getString("label", "Capsule Link");
        String b64 = call.getString("icon", null);
        Intent launch = new Intent(ctx, MainActivity.class);
        launch.setAction(Intent.ACTION_MAIN);
        launch.addCategory(Intent.CATEGORY_LAUNCHER);
        ShortcutInfoCompat.Builder b = new ShortcutInfoCompat.Builder(ctx, "home-" + Math.abs(label.hashCode()))
            .setShortLabel(label).setLongLabel(label).setIntent(launch);
        Bitmap bmp = null;
        if (b64 != null) {
            try { byte[] bytes = Base64.decode(b64, Base64.DEFAULT); bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length); } catch (Exception e) { bmp = null; }
        }
        if (bmp != null) b.setIcon(IconCompat.createWithBitmap(Bitmap.createScaledBitmap(bmp, 192, 192, true)));
        else b.setIcon(IconCompat.createWithResource(ctx, R.mipmap.ic_launcher));
        boolean ok = ShortcutManagerCompat.requestPinShortcut(ctx, b.build(), null);
        JSObject r = new JSObject();
        r.put("ok", ok);
        call.resolve(r);
    }

    @PluginMethod
    public void vibrate(PluginCall call) {
        Vibrator v = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null) { call.resolve(); return; }
        long[] pattern = { 0, 40 };
        try {
            JSONArray arr = call.getArray("pattern");
            if (arr != null && arr.length() > 0) {
                pattern = new long[arr.length() + 1];
                pattern[0] = 0;
                for (int i = 0; i < arr.length(); i++) pattern[i + 1] = arr.getLong(i);
            }
        } catch (Exception ignored) { }
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1));
        else v.vibrate(pattern, -1);
        call.resolve();
    }

    /** Listens for the PC's UDP beacon (port 47821) for a few seconds. */
    @PluginMethod
    public void discoverPc(PluginCall call) {
        int timeout = call.getInt("timeout", 3500);
        new Thread(() -> {
            WifiManager wm = (WifiManager) getContext().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            WifiManager.MulticastLock lock = wm != null ? wm.createMulticastLock("capsule-link") : null;
            if (lock != null) { lock.setReferenceCounted(false); lock.acquire(); }
            JSArray found = new JSArray();
            Set<String> seen = new HashSet<>();
            DatagramSocket sock = null;
            try {
                sock = new DatagramSocket(null);
                sock.setReuseAddress(true);
                sock.setBroadcast(true);
                sock.bind(new InetSocketAddress(47821));
                sock.setSoTimeout(400);
                long end = System.currentTimeMillis() + timeout;
                byte[] buf = new byte[1024];
                while (System.currentTimeMillis() < end) {
                    try {
                        DatagramPacket pk = new DatagramPacket(buf, buf.length);
                        sock.receive(pk);
                        JSONObject j = new JSONObject(new String(pk.getData(), 0, pk.getLength(), StandardCharsets.UTF_8));
                        if (!"capsule-link".equals(j.optString("app"))) continue;
                        String addr = pk.getAddress().getHostAddress();
                        if (seen.add(addr)) {
                            JSObject o = new JSObject();
                            o.put("name", j.optString("name", "PC"));
                            o.put("address", addr);
                            o.put("port", j.optInt("port", 47820));
                            found.put(o);
                        }
                    } catch (SocketTimeoutException ignored) {
                        // keep listening until the deadline
                    }
                }
            } catch (Exception ignored) {
                // return whatever was found
            } finally {
                if (sock != null) sock.close();
                if (lock != null && lock.isHeld()) lock.release();
            }
            JSObject res = new JSObject();
            res.put("found", found);
            call.resolve(res);
        }).start();
    }

    static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02X", x));
        return sb.toString();
    }
}
