package com.capsulelink.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.util.Collections;

/**
 * Pokemon Showdown inside Capsule Link. The page is Showdown's own site; before it loads we add the
 * bridge script (shared/engine/showdown.js), which sends your team when you challenge or accept and
 * hands finished battle logs back to the app through CapsuleBridge.post().
 */
public class ShowdownActivity extends AppCompatActivity {
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_SCRIPT = "script";

    private WebView web;
    private String script;
    private boolean docStart;
    private String homeHost;

    @SuppressLint({ "SetJavaScriptEnabled", "AddJavascriptInterface" })
    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        String url = getIntent().getStringExtra(EXTRA_URL);
        script = getIntent().getStringExtra(EXTRA_SCRIPT);
        if (url == null) url = "https://play.pokemonshowdown.com";
        if (script == null) script = "";
        homeHost = Uri.parse(url).getHost();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(58, 42, 138));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int pad = dp(8);
        bar.setPadding(dp(12), pad, pad, pad);
        TextView title = new TextView(this);
        title.setText("Showdown");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button back = new Button(this);
        back.setText("Back to Capsule Link");
        back.setAllCaps(false);
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        root.addView(bar);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE); // self-hosted servers on http://
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.addJavascriptInterface(new Bridge(), "CapsuleBridge");

        docStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        if (docStart) WebViewCompat.addDocumentStartJavaScript(web, script, Collections.singleton("*"));

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String u, android.graphics.Bitmap favicon) {
                // older WebViews: inject as early as we can
                if (!docStart) view.evaluateJavascript(script, null);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String host = u.getHost() == null ? "" : u.getHost();
                boolean showdown = host.equals(homeHost) || host.endsWith("pokemonshowdown.com") || host.endsWith("psim.us");
                if (showdown) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        // keep clear of the status bar, navigation bar and keyboard
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            return WindowInsetsCompat.CONSUMED;
        });

        if (saved != null) web.restoreState(saved);
        else web.loadUrl(url);
    }

    /** A second "open" while this screen is up: hand the new config (team, challenge) to the page. */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String next = intent.getStringExtra(EXTRA_SCRIPT);
        if (next != null && web != null) {
            script = next;
            web.evaluateJavascript(next, null);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private class Bridge {
        @JavascriptInterface
        public void post(String json) {
            if (json == null || json.length() > 2_000_000) return;
            CapsuleLinkPlugin.deliverShowdown(json);
            try {
                JSONObject o = new JSONObject(json);
                String type = o.optString("type");
                if ("battle".equals(type)) {
                    runOnUiThread(() -> Toast.makeText(ShowdownActivity.this, "Battle saved to Capsule Link", Toast.LENGTH_LONG).show());
                } else if ("popup".equals(type)) {
                    String text = o.optString("text");
                    runOnUiThread(() -> Toast.makeText(ShowdownActivity.this, text, Toast.LENGTH_LONG).show());
                }
            } catch (Exception ignored) { }
        }
    }
}
