package com.capsulelink.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.core.app.NotificationCompat;

/**
 * Counts steps while you walk with your buddy, even with the screen off.
 * Steps are stored as "pending" until the app turns them into friendship (ackSteps).
 */
public class WalkService extends Service implements SensorEventListener {
    public interface StepListener { void onSteps(long session, long pending); }

    public static volatile StepListener listener;
    public static volatile boolean running = false;

    private static final String PREFS = "capsule_link_walk";
    private static final String CHANNEL = "walk";
    private static final int NOTIFICATION_ID = 1001;

    private SensorManager sensors;
    private long lastCounter = -1;
    private String title = "Walking together";
    private String text = "Steps build friendship.";
    private long lastShown = -1;
    private final Handler main = new Handler(Looper.getMainLooper());

    static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static long session(Context ctx) { return prefs(ctx).getLong("session", 0); }
    public static long pending(Context ctx) { return prefs(ctx).getLong("pending", 0); }

    public static void resetSession(Context ctx) { prefs(ctx).edit().putLong("session", 0).apply(); }

    public static synchronized void ack(Context ctx, long count) {
        SharedPreferences p = prefs(ctx);
        p.edit().putLong("pending", Math.max(0, p.getLong("pending", 0) - Math.max(0, count))).apply();
    }

    private static synchronized long[] add(Context ctx, long n) {
        SharedPreferences p = prefs(ctx);
        long s = p.getLong("session", 0) + n;
        long pend = p.getLong("pending", 0) + n;
        p.edit().putLong("session", s).putLong("pending", pend).apply();
        return new long[] { s, pend };
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Walking", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Shows your steps while you walk with your buddy");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            if (intent.getStringExtra("title") != null) title = intent.getStringExtra("title");
            if (intent.getStringExtra("text") != null) text = intent.getStringExtra("text");
        }
        Notification n = build(session(this));
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH);
        else startForeground(NOTIFICATION_ID, n);
        running = true;
        if (sensors == null) {
            sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
            Sensor counter = sensors.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            Sensor detector = sensors.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
            if (counter != null) sensors.registerListener(this, counter, SensorManager.SENSOR_DELAY_NORMAL);
            else if (detector != null) sensors.registerListener(this, detector, SensorManager.SENSOR_DELAY_NORMAL);
            else stopSelf();
        }
        return START_STICKY;
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        long added;
        if (e.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            long v = (long) e.values[0];
            if (lastCounter < 0) { lastCounter = v; return; } // first reading sets the baseline
            added = v - lastCounter;
            lastCounter = v;
            if (added <= 0 || added > 10000) return; // counter reset after a reboot
        } else {
            added = 1;
        }
        long[] r = add(this, added);
        final long s = r[0], p = r[1];
        if (lastShown < 0 || s - lastShown >= 20) {
            lastShown = s;
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIFICATION_ID, build(s));
        }
        StepListener l = listener;
        if (l != null) main.post(() -> l.onSteps(s, p));
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private Notification build(long steps) {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String line = steps > 0 ? String.format(java.util.Locale.US, "%,d steps - %s", steps, text) : text;
        return new NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_capsule)
            .setContentTitle(title)
            .setContentText(line)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build();
    }

    @Override
    public void onDestroy() {
        running = false;
        if (sensors != null) sensors.unregisterListener(this);
        sensors = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
