# The phone app's signing key

Android only installs a new version of an app over the old one when both are signed with the same key.
GitHub's build machines make a new throwaway key every time, so each new APK used to need the old app
uninstalled first. Every build is now signed with this key (`capsule-link.p12`, password `capsulelink`),
so new versions install over the old one and keep everything on the phone.

- The first APK built with this key still needs one last uninstall of the old app (it was signed with a
  throwaway key). After that, never again.
- Keep this file with the project. If it's lost, a new key means one more uninstall.
- If your GitHub repository is public and you'd rather not have the key in it, put the file's contents
  (base64) in a repository secret called ANDROID_KEYSTORE_BASE64 (Settings → Secrets → Actions) and
  delete this file: the build uses the secret instead.
