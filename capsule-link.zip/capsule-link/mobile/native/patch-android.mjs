// Adds Capsule Link's native code to the Android project that `npx cap add android` generated:
// copies the Java plugin + walking service, the launcher icons, and patches AndroidManifest.xml
// (permissions, NFC launch filter, foreground service, cleartext LAN traffic). Safe to run again.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const mobile = path.join(here, '..');
const android = path.join(mobile, 'android', 'app', 'src', 'main');
const PACKAGE = 'com.capsulelink.app';

if (!fs.existsSync(android)) {
  console.error('No Android project yet. Run "npx cap add android" in the mobile folder first.');
  process.exit(1);
}

// 1. Java sources
const javaDst = path.join(android, 'java', ...PACKAGE.split('.'));
fs.mkdirSync(javaDst, { recursive: true });
for (const f of fs.readdirSync(path.join(here, 'java', ...PACKAGE.split('.')))) {
  fs.copyFileSync(path.join(here, 'java', ...PACKAGE.split('.'), f), path.join(javaDst, f));
}
// remove a Kotlin MainActivity if the template made one
for (const f of ['MainActivity.kt']) { const p = path.join(javaDst, f); if (fs.existsSync(p)) fs.rmSync(p); }

// 2. icons
const resSrc = path.join(here, 'res');
const copyDir = (src, dst) => {
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) { fs.mkdirSync(d, { recursive: true }); copyDir(s, d); } else fs.copyFileSync(s, d);
  }
};
if (fs.existsSync(resSrc)) copyDir(resSrc, path.join(android, 'res'));
const bg = path.join(android, 'res', 'values', 'ic_launcher_background.xml');
fs.mkdirSync(path.dirname(bg), { recursive: true });
fs.writeFileSync(bg, '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#5B45C4</color>\n</resources>\n');

// 3. manifest
const manifestPath = path.join(android, 'AndroidManifest.xml');
let m = fs.readFileSync(manifestPath, 'utf8');

const PERMS = `<!-- capsule-link:permissions -->
    <uses-permission android:name="android.permission.NFC" />
    <uses-permission android:name="android.permission.ACTIVITY_RECOGNITION" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_HEALTH" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <uses-permission android:name="android.permission.CHANGE_WIFI_MULTICAST_STATE" />
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-feature android:name="android.hardware.location.gps" android:required="false" />
    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-feature android:name="android.hardware.nfc" android:required="false" />
    <uses-feature android:name="android.hardware.bluetooth_le" android:required="false" />
    <uses-feature android:name="android.hardware.sensor.stepcounter" android:required="false" />
    <!-- /capsule-link:permissions -->`;

const FILTER = `<!-- capsule-link:nfc -->
            <intent-filter>
                <action android:name="android.nfc.action.NDEF_DISCOVERED" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="application/vnd.capsulelink" />
            </intent-filter>
            <!-- /capsule-link:nfc -->`;

const SERVICE = `<!-- capsule-link:service -->
        <service android:name=".WalkService" android:exported="false" android:foregroundServiceType="health" />
        <activity
            android:name=".ShowdownActivity"
            android:exported="false"
            android:launchMode="singleTop"
            android:theme="@style/AppTheme.NoActionBar"
            android:configChanges="orientation|screenSize|smallestScreenSize|screenLayout|keyboardHidden|keyboard|uiMode"
            android:windowSoftInputMode="adjustResize" />
        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.capsuleupdates"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/capsule_update_paths" />
        </provider>
        <!-- /capsule-link:service -->`;

const block = (name) => new RegExp(`<!-- capsule-link:${name} -->[\\s\\S]*?<!-- /capsule-link:${name} -->`);
const upsert = (name, text, anchor, before = true) => {
  if (block(name).test(m)) { m = m.replace(block(name), text); return; }
  const i = m.indexOf(anchor);
  if (i < 0) throw new Error(`Could not find ${anchor} in AndroidManifest.xml`);
  m = before ? `${m.slice(0, i)}${text}\n    ${m.slice(i)}` : `${m.slice(0, i + anchor.length)}\n            ${text}${m.slice(i + anchor.length)}`;
};

upsert('permissions', PERMS, '</manifest>');
// NFC intent filter goes inside the main activity, after its first intent-filter
if (!block('nfc').test(m)) {
  const act = m.indexOf('android:name=".MainActivity"');
  if (act < 0) throw new Error('MainActivity not found in the manifest');
  const close = m.indexOf('</intent-filter>', act);
  m = `${m.slice(0, close + 16)}\n\n            ${FILTER}${m.slice(close + 16)}`;
} else m = m.replace(block('nfc'), FILTER);
upsert('service', SERVICE, '</application>');
// phones talk to the PC over plain ws:// on the home network
if (!/usesCleartextTraffic/.test(m)) m = m.replace('<application', '<application\n        android:usesCleartextTraffic="true"');
fs.writeFileSync(manifestPath, m);

// 4. Gradle: androidx.webkit lets the Showdown screen add its bridge before Showdown's own scripts run
const gradlePath = path.join(mobile, 'android', 'app', 'build.gradle');
if (fs.existsSync(gradlePath)) {
  let g = fs.readFileSync(gradlePath, 'utf8');
  if (!g.includes('capsule-link:deps')) {
    g = g.replace(/dependencies\s*\{/, (d) => `${d}\n    // capsule-link:deps\n    implementation "androidx.webkit:webkit:1.12.1"`);
    fs.writeFileSync(gradlePath, g);
  }
  // one signing key for every build (so new versions install over the old one), and a version code that grows
  g = fs.readFileSync(gradlePath, 'utf8');
  const ver = JSON.parse(fs.readFileSync(path.join(mobile, '..', 'version.json'), 'utf8')).version ?? '0.0.0';
  const [a, b, c] = ver.split('.').map((n) => parseInt(n, 10) || 0);
  const code = a * 1000000 + b * 10000 + c * 100 + Math.min(99, Number(process.env.CAPSULE_BUILD ?? 0) % 100);
  g = g.replace(/versionCode\s+\d+/, `versionCode ${code}`).replace(/versionName\s+"[^"]*"/, `versionName "${ver}"`);
  if (!g.includes('capsule-link:signing') && fs.existsSync(path.join(here, 'signing', 'capsule-link.p12'))) {
    g = g.replace(/android\s*\{/, (x) => `${x}
    // capsule-link:signing
    signingConfigs {
        capsule {
            storeFile file('../../native/signing/capsule-link.p12')
            storePassword 'capsulelink'
            keyAlias 'capsulelink'
            keyPassword 'capsulelink'
            storeType 'pkcs12'
        }
    }`);
    g = g.replace(/buildTypes\s*\{/, (x) => `${x}\n        debug { signingConfig signingConfigs.capsule }`);
  }
  fs.writeFileSync(gradlePath, g);
} else console.warn('android/app/build.gradle not found; add androidx.webkit:webkit to its dependencies by hand.');

console.log('Patched the Android project:');
console.log('  java   ->', path.relative(mobile, javaDst));
console.log('  icons  -> res/mipmap-*, res/drawable/ic_stat_capsule.png');
console.log('  manifest permissions, NFC launch filter, walking service, Showdown screen');
console.log('  gradle   androidx.webkit, signing key, version code');
