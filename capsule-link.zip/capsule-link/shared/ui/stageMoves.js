// How each move looks on the 2.5D battle stage. There are hundreds of moves and no ready-made 2.5D animations
// for them, so every move is sorted into one of a few dozen animation templates by what it does (Showdown's
// own move data: contact, multi-hit, draining, trapping, priority, powder, sound, wind, …), by words in its
// name, and by its type. Each type also has its own look (colours and particle shapes), so a Grass move and a
// Poison move using the same template still look like themselves. Pure: no drawing here.

export const TYPE_LOOK = {
  Normal: { col: '#f2efe4', col2: '#c8c2a8', shapes: ['star', 'dot'] },
  Fire: { col: '#ff7a2a', col2: '#ffd23f', shapes: ['flame', 'flame', 'ember'] },
  Water: { col: '#4aa8ff', col2: '#bfe6ff', shapes: ['drop', 'bubble'] },
  Grass: { col: '#4fd060', col2: '#b8ff7a', shapes: ['leaf', 'leaf', 'seed'] },
  Electric: { col: '#ffe03a', col2: '#fff8b0', shapes: ['spark', 'spark'] },
  Ice: { col: '#8ae8ff', col2: '#ffffff', shapes: ['shard', 'flake'] },
  Fighting: { col: '#e0603a', col2: '#ffb08a', shapes: ['star', 'shard'] },
  Poison: { col: '#b85ae0', col2: '#e8a0ff', shapes: ['bubble', 'blob'] },
  Ground: { col: '#c8a060', col2: '#e8d0a0', shapes: ['rock', 'dot'] },
  Flying: { col: '#bcd8ff', col2: '#ffffff', shapes: ['feather', 'spark'] },
  Psychic: { col: '#ff6ab8', col2: '#ffc0e0', shapes: ['orb', 'ring'] },
  Bug: { col: '#a8c838', col2: '#e0f080', shapes: ['dot', 'needle'] },
  Rock: { col: '#b8a070', col2: '#e0d0a8', shapes: ['rock', 'rock'] },
  Ghost: { col: '#7a5ac8', col2: '#c0a8ff', shapes: ['wisp', 'wisp'] },
  Dragon: { col: '#7a6aff', col2: '#c8a0ff', shapes: ['orb', 'shard'] },
  Dark: { col: '#5a4a6a', col2: '#a890c0', shapes: ['wisp', 'shard'] },
  Steel: { col: '#b8c8d8', col2: '#ffffff', shapes: ['shard', 'gear'] },
  Fairy: { col: '#ffa0d0', col2: '#fff0f8', shapes: ['star', 'heart'] },
  Stellar: { col: '#a0e8ff', col2: '#ffd0ff', shapes: ['star', 'orb'] },
  '???': { col: '#88aa99', col2: '#cceedd', shapes: ['dot'] },
};
export const lookOf = (type) => TYPE_LOOK[type] ?? TYPE_LOOK.Normal;

const has = (name, re) => re.test(name);

/**
 * move: the stage's move info (from wild.js). → { kind, travel (s from launch to hit), hits, from-sky etc. }
 * kinds — on the user: self, protect, heal, dance, charge
 *         at the target: contact, zigzag, punch, kick, bite, slash, horn, tackleSpin, dive (from the sky),
 *           burrow (from underground), phantom (from behind), projectile, volley (several), beam, pulse, wave,
 *           vortex (trapping), drain, powder, sound, wind, quake, rockfall, spikes (up from the ground), thunder,
 *           zap, psychic, rainDown, pillar, explosion, status (aimed at the target), debuff, hazard, screen,
 *           weather, terrain, field, swap
 */
export function classifyMove(m) {
  const name = String(m.name ?? '').toLowerCase(), f = m.flags ?? {};
  const cat = m.cat ?? 'Physical', type = m.type ?? 'Normal';
  const hits = Array.isArray(m.multihit) ? Math.max(2, Math.round((m.multihit[0] + m.multihit[1]) / 2)) : Number(m.multihit) || 1;
  const self = ['self', 'allySide', 'allies', 'adjacentAllyOrSelf', 'adjacentAlly'].includes(m.target);
  const out = (kind, travel = 0.6, extra = {}) => ({ kind, travel, hits, ...extra });

  // webs and silk: Sticky Web, String Shot, Spider Web, Electroweb, Toxic Thread, Silk Trap
  if (/web|string shot|toxic thread|silk trap/.test(name)) return out('web', 0.55, { ground: !!m.side, electric: type === 'Electric' });
  // moves that change the field or a side
  if (m.weather) return out('weather', 0.6);
  if (m.terrain) return out('terrain', 0.6);
  if (m.field) return out('field', 0.6);
  if (m.side) return /spikes|rock|web|steelsurge/.test(name) ? out('hazard', 0.7) : out('screen', 0.5);
  if (m.stalling) return out('protect', 0.3);
  if (m.selfdestruct && cat !== 'Status') return out('explosion', 0.3);

  if (cat === 'Status') {
    if (/^acupressure$/.test(name)) return out('self', 0.5, { pins: true });
    if (/^acid armor$/.test(name)) return out('self', 0.5, { melt: true });
    if (m.heal || /recover|roost|rest|synthesis|moonlight|morning sun|wish|heal|milk|slack|soft-boiled|shore up|life dew|jungle/.test(name)) return out(name.includes('strength sap') ? 'drain' : 'heal', 0.6);
    if (f.dance) return out('dance', 0.5);
    if (self || m.target === 'all' || m.target === 'allySide') return out('self', 0.5);
    if (f.powder) return out('powder', 0.6);
    if (f.sound) return out('sound', 0.5, { loud: /uproar|boomburst|hyper voice|screech|metal sound|noble roar|roar|growl/.test(name) && !/^growl$/.test(name) });
    if (m.status || m.volatile === 'confusion' || /attract|taunt|torment|encore|disable|yawn|curse|nightmare|leech seed|embargo|heal block/.test(name)) return out('status', 0.55);
    if (m.boosts && Object.values(m.boosts).some((v) => v < 0)) return out(/glare|leer|scary|eye|face/.test(name) ? 'glare' : 'debuff', 0.4);
    if (/swap|switcheroo|trick|skill swap|role play|transform|sketch|mimic|copycat|baton|teleport/.test(name)) return out('swap', 0.5);
    return out('status', 0.55);
  }

  // (looks set move by move, from the move lab)
  if (/^acrobatics$/.test(name)) return out('zigzag', 0.5, { acro: true });
  if (/^aerial ace$|^brave bird$/.test(name)) return out('dive', 0.35, { big: name === 'brave bird', swoop: true });
  if (/^acid spray$/.test(name)) return out('projectile', 0.5, { stream: true });
  if (/^bug bite$/.test(name)) return out('bite', 0.34, { chomp: true });
  if (/^branch poke$/.test(name)) return out('horn', 0.34, { wood: true });
  if (/^bulldoze$/.test(name)) return out('surge', 0.45);
  if (/^bubble$/.test(name)) return out('volley', 0.4, { bubbles: true, hits: 4 });
  if (/^bug buzz$/.test(name)) return out('sound', 0.5, { loud: true, buzz: true });
  // semi-invulnerable strikes (the turn they land)
  if (/^(fly|bounce|sky drop|sky attack)$/.test(name)) return out('dive', 0.35);
  if (/^dig$/.test(name)) return out('burrow', 0.3);
  if (/^dive$/.test(name)) return out('burrow', 0.3, { splash: true });
  if (/phantom force|shadow force/.test(name)) return out('phantom', 0.3);
  // the field-wide earthquakes and rockslides
  if (type === 'Ground' && (m.target === 'allAdjacent' || m.target === 'allAdjacentFoes' || /quake|magnitude|bulldoze|fissure|earth power|land/.test(name))) return out('quake', 0.45);
  if (/stone edge|precipice|spike|stalagmite|pillar|geyser|eruption|fissure|rock tomb|ceaseless|frenzy plant|hard plant|grassy glide/.test(name) && cat === 'Physical' && !f.contact) return out('spikes', 0.4);
  if (/rock slide|rockslide|meteor|avalanche|hail|icicle crash|sky uppercut/.test(name) || (type === 'Rock' && cat === 'Physical' && !f.contact)) return out('rockfall', 0.6);
  if (m.volatile === 'partiallytrapped' || /whirlpool|fire spin|sand tomb|magma storm|infestation|snap trap|thunder cage|bind|wrap|clamp/.test(name)) return out(f.contact ? 'wrap' : 'vortex', 0.5);
  if (m.drain || /absorb|drain|leech|giga drain|horn leech|parabolic|bitter blade|draining kiss|oblivion wing/.test(name)) return out('drain', 0.55);
  if (m.ohko) return out(f.contact ? 'contact' : 'beam', 0.4, { big: true });

  if (f.contact) {
    if (m.priority > 0 || /quick attack|extreme ?speed|aqua jet|mach punch|bullet punch|accelerock|jet punch|first impression|feint|sucker punch|fake out|shadow sneak/.test(name)) return out('zigzag', 0.55);
    if (/u-turn|flip turn|volt switch/.test(name) || m.switches) return out('contact', 0.32, { returnFast: true });
    if (f.punch) return out('punch', 0.34);
    if (f.bite) return out('bite', 0.34);
    if (f.slicing || /slash|cut|claw|scratch|scythe|blade|razor|fury swipes|night slash|x-scissor|cross/.test(name)) return out('slash', 0.34);
    if (/kick|stomp|jump|knee|feet|heel/.test(name)) return out('kick', 0.36);
    if (/horn|drill|peck|megahorn|smart strike|poison jab|needle|sting/.test(name)) return out('horn', 0.34);
    if (/spin|roll|rollout|ice ball|steamroller|wheel|rapid|gyro|wild charge|volt tackle|flare blitz|head smash|brave bird|double-edge|take down|giga impact|wave crash|body press|heavy slam|heat crash/.test(name)) return out('tackleSpin', 0.36, { big: m.bp >= 100 });
    return out('contact', 0.34);
  }
  if (f.sound) return out('sound', 0.5, { loud: /uproar|boomburst|hyper voice|clanging|overdrive|bug buzz|snarl|echoed|round|relic song|perish|sparkling aria|torch song|alluring/.test(name) });
  // Signal Beam: a harsh, jagged frequency wave, not a beam
  if (/signal beam/.test(name)) return out('freq', 0.4);
  // Bubble Beam, Bubble: a piercing jet of bubbles
  if (/^bubble ?beam$/.test(name)) return out('projectile', 0.5, { stream: true, bubbles: true });
  if (/twister|tornado|bleakwind storm/.test(name)) return out('tornado', 0.7);
  if (f.wind || /gust|wind|hurricane|twister|air|blizzard|tornado|storm|bleakwind|sandsear|wildbolt|springtide/.test(name)) return out(/blizzard/.test(name) ? 'wind' : /hurricane|storm/.test(name) ? 'rainDown' : 'wind', 0.45, { blizzard: /blizzard/.test(name) });
  if (type === 'Electric' && /thunder$|^thunder|zap cannon|bolt strike|bolt beak|electro shot/.test(name)) return out('thunder', 0.25);
  // a real wave of water, mud or sludge; other moves that sweep across both foes keep the sweep of particles
  if (/surf|tidal|flood|muddy water|sludge wave|origin pulse|water spout/.test(name) || (/wave|tide/.test(name) && (type === 'Water' || type === 'Ground'))) return out('wave', 0.6);
  if (/wave|tide|hydro steam/.test(name) || (m.target === 'allAdjacentFoes' && cat === 'Special' && !/beam|ray|gleam|blast|cannon/.test(name))) return out('sweep', 0.6);
  if (/dazzling gleam/.test(name)) return out('sweep', 0.6, { gleam: true });
  if (/beam|ray|laser|cannon|blast|solar|hyper|dazzling|moonblast|flash cannon|prismatic|core enforcer|roar of time|spacial|photon|astral/.test(name)) return out('beam', 0.32, { big: m.bp >= 100 });
  if (f.pulse || /pulse|aura sphere|focus blast/.test(name)) return out('pulse', 0.5);
  if (hits > 1) return out('volley', 0.4);
  if (/rain|fall|meteor|draco|hail|comet|star|fire blast|heat wave/.test(name) && cat === 'Special') return out('rainDown', 0.6);
  if (/storm|erupt|fire|flame|ember|burn|inferno/.test(name) && cat === 'Special' && type === 'Fire') return out('projectile', 0.6, { stream: true });
  if (type === 'Electric') return out('zap', 0.22);
  if (type === 'Psychic' && cat === 'Special' && !f.bullet) return out('psychic', 0.45);
  if (type === 'Ghost' && /hex|night shade|astonish|lick|spite|curse|infernal/.test(name)) return out('psychic', 0.45);
  if (type === 'Fighting' && cat === 'Physical') return out('punch', 0.34);
  return out('projectile', cat === 'Physical' ? 0.5 : 0.6, { stream: type === 'Water' || type === 'Fire', glob: type === 'Poison' });
}

/** The moves that leave their user out of reach for a turn, and how. */
export function vanishOf(m) {
  const name = String(m?.name ?? '').toLowerCase();
  if (/^(fly|bounce|sky drop)$/.test(name)) return 'up';
  if (name === 'dig') return 'under';
  if (name === 'dive') return 'water';
  if (/phantom force|shadow force/.test(name)) return 'gone';
  return null;
}
