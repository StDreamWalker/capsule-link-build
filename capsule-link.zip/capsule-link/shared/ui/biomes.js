// Procedural pixel-art environments used for box wallpapers, the ranch and battle arenas.
// Drawn at low resolution (1 canvas pixel = 1 art pixel) and scaled up with nearest-neighbour.
import { createRng, hashString } from '../engine/rng.js';

export const BIOME_INFO = {
  meadow: { ground: 0.62, particles: 'butterflies', label: 'Meadow' },
  forest: { ground: 0.66, particles: 'leaves', label: 'Forest' },
  shoreline: { ground: 0.64, particles: 'gulls', label: 'Shoreline' },
  volcano: { ground: 0.66, particles: 'embers', label: 'Volcano', dark: true },
  cavern: { ground: 0.68, particles: 'drips', label: 'Cavern', dark: true },
  tundra: { ground: 0.63, particles: 'snow', label: 'Tundra' },
  desert: { ground: 0.62, particles: 'sand', label: 'Desert' },
  skyline: { ground: 0.66, particles: 'clouds', label: 'Mountaintop' },
  seafloor: { ground: 0.74, particles: 'bubbles', label: 'Seafloor', dark: true },
  marsh: { ground: 0.62, particles: 'fireflies', label: 'Marsh' },
  starfield: { ground: 0.66, particles: 'twinkle', label: 'Starfield', dark: true },
  crystal: { ground: 0.68, particles: 'sparkles', label: 'Crystal cave', dark: true },
  outskirts: { ground: 0.64, particles: 'butterflies', label: 'City outskirts' },
  spooky: { ground: 0.66, particles: 'fireflies', label: 'Spooky forest', dark: true },
  prism: { ground: 0.64, particles: 'sparkles', label: 'Prism (abstract)' },
  synth: { ground: 0.6, particles: 'twinkle', label: 'Neon grid (abstract)', dark: true },
};
export const BIOME_IDS = Object.keys(BIOME_INFO);

function makeCanvas(w, h) {
  if (typeof OffscreenCanvas !== 'undefined') return new OffscreenCanvas(w, h);
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

// ---------- drawing helpers ----------
const P = (ctx, x, y, c) => { ctx.fillStyle = c; ctx.fillRect(Math.round(x), Math.round(y), 1, 1); };
const R = (ctx, x, y, w, h, c) => { ctx.fillStyle = c; ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); };

/** Vertical gradient in hard bands with a checker dither where bands meet. */
function bands(ctx, x0, y0, w, h, colors) {
  const n = colors.length;
  const bh = h / n;
  for (let i = 0; i < n; i++) {
    const y = y0 + Math.floor(i * bh), yh = Math.ceil(bh) + 1;
    R(ctx, x0, y, w, yh, colors[i]);
    if (i > 0) for (let x = x0; x < x0 + w; x += 2) { P(ctx, x + (y % 2), y, colors[i - 1]); P(ctx, x + ((y + 1) % 2), y + 1, colors[i - 1]); }
  }
}

function noise1d(rng, n) {
  const pts = Array.from({ length: n + 1 }, () => rng());
  return (t) => {
    const x = Math.max(0, Math.min(n - 0.0001, t * n));
    const i = Math.floor(x), f = x - i;
    const s = f * f * (3 - 2 * f);
    return pts[i] * (1 - s) + pts[i + 1] * s;
  };
}

/** A ridge line filled down to `bottom`. */
function ridge(ctx, rng, w, base, amp, bumps, color, bottom, edge) {
  const nz = noise1d(rng, bumps);
  const nz2 = noise1d(rng, bumps * 3);
  for (let x = 0; x < w; x++) {
    const y = Math.round(base - amp * (nz(x / w) * 0.8 + nz2(x / w) * 0.2));
    R(ctx, x, y, 1, bottom - y, color);
    if (edge) P(ctx, x, y, edge);
  }
}

function blob(ctx, cx, cy, rx, ry, c) {
  for (let y = -ry; y <= ry; y++) for (let x = -rx; x <= rx; x++) {
    if ((x * x) / (rx * rx + 0.3) + (y * y) / (ry * ry + 0.3) <= 1) P(ctx, cx + x, cy + y, c);
  }
}

function cloud(ctx, x, y, s, main = '#ffffff', under = '#d8ecfa') {
  blob(ctx, x, y, 4 * s, 2 * s, main);
  blob(ctx, x + 4 * s, y - 1 * s, 3 * s, 3 * s, main);
  blob(ctx, x - 4 * s, y + 0, 3 * s, 2 * s, main);
  R(ctx, x - 6 * s, y + 2 * s, 13 * s, 1, under);
}

function speckle(ctx, rng, x0, y0, w, h, colors, density) {
  const n = Math.round(w * h * density);
  for (let i = 0; i < n; i++) P(ctx, x0 + rng() * w, y0 + rng() * h, rng.pick(colors));
}

function pine(ctx, x, base, h, leaf, dark, snow) {
  R(ctx, x, base - 3, 1, 3, '#5a3b26');
  for (let i = 0; i < h; i++) {
    const half = Math.floor((i % Math.max(3, Math.floor(h / 3))) * 0.8 + i * 0.25);
    const y = base - 3 - h + i;
    R(ctx, x - half, y, half * 2 + 1, 1, i % 4 === 0 ? dark : leaf);
    if (snow && i % Math.max(3, Math.floor(h / 3)) === 0) R(ctx, x - half, y, half + 1, 1, snow);
  }
}

function roundTree(ctx, x, base, r, trunk, leaf, light, dark) {
  R(ctx, x - 1, base - r - 2, 2, r + 2, trunk);
  blob(ctx, x, base - r * 2, r, r, leaf);
  blob(ctx, x - Math.floor(r / 3), base - r * 2 - Math.floor(r / 3), Math.floor(r / 2), Math.floor(r / 2), light);
  R(ctx, x - r + 1, base - r - 1, r * 2 - 1, 1, dark);
}

// ---------- biome painters ----------
const PAINTERS = {
  meadow(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, g, ['#6fc0f0', '#86ccf3', '#a2d9f6', '#c2e7f8', '#dff3fb']);
    for (let i = 0; i < 3; i++) cloud(ctx, rng() * w, 6 + rng() * g * 0.35, 1);
    ridge(ctx, rng, w, g - 6, 12, 3, '#a9dc94', g + 2, '#c4e8b2');
    ridge(ctx, rng, w, g, 6, 5, '#83c96e', g + 2, '#9bd685');
    R(ctx, 0, g, w, h - g, '#6cba53');
    speckle(ctx, rng, 0, g, w, h - g, ['#5ca846', '#7cc55f', '#5ca846'], 0.08);
    for (let i = 0; i < w * (h - g) / 60; i++) {
      const x = rng() * w, y = g + 3 + rng() * (h - g - 4);
      P(ctx, x, y, '#4f9a3c'); P(ctx, x + 1, y - 1, '#4f9a3c'); P(ctx, x + 2, y, '#4f9a3c');
    }
    for (let i = 0; i < w * (h - g) / 90; i++) {
      const x = rng() * w, y = g + 3 + rng() * (h - g - 4);
      const c = rng.pick(['#ff8fb4', '#ffe36a', '#ffffff', '#c7a5ff']);
      P(ctx, x - 1, y, c); P(ctx, x + 1, y, c); P(ctx, x, y - 1, c); P(ctx, x, y + 1, c); P(ctx, x, y, '#ffcf40');
    }
  },

  forest(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, g, ['#a8dcc0', '#8fcdab', '#6fb48e', '#4f9470']);
    for (let x = -4; x < w + 8; x += 7 + rng.int(0, 5)) pine(ctx, x, g + 2, 18 + rng.int(0, 12), '#3b7a5a', '#2f6a4c');
    for (let x = 0; x < w + 10; x += 16 + rng.int(0, 10)) roundTree(ctx, x, g + 4, 7 + rng.int(0, 4), '#5b3d27', '#2f8048', '#46a05c', '#235f36');
    // canopy across the top
    for (let x = 0; x < w; x++) {
      const d = 6 + Math.round(Math.sin(x / 5) * 2 + rng() * 2);
      R(ctx, x, 0, 1, d, '#256b3c');
      if (rng() < 0.3) P(ctx, x, d, '#2f8048');
    }
    // light shafts
    ctx.globalAlpha = 0.18;
    for (let i = 0; i < 3; i++) {
      const x0 = rng() * w;
      for (let y = 0; y < g; y++) R(ctx, x0 + y * 0.5, y, 5, 1, '#fff7c2');
    }
    ctx.globalAlpha = 1;
    R(ctx, 0, g, w, h - g, '#4c8a3a');
    speckle(ctx, rng, 0, g, w, h - g, ['#5fa34a', '#3f7a30', '#c98a3a', '#b5743a'], 0.07);
    for (let i = 0; i < w / 25; i++) {
      const x = rng() * w, y = g + 4 + rng() * (h - g - 8);
      R(ctx, x, y, 1, 2, '#f2e8d0');
      blob(ctx, x, y - 1, 2, 1, '#d8483a'); P(ctx, x - 1, y - 2, '#ffffff'); P(ctx, x + 1, y - 1, '#ffffff');
    }
  },

  shoreline(ctx, w, h, rng, g) {
    const sea = g - 16;
    bands(ctx, 0, 0, w, sea, ['#5fb8f2', '#7cc6f4', '#9dd6f7', '#c1e6fa']);
    for (let i = 0; i < 3; i++) cloud(ctx, rng() * w, 5 + rng() * sea * 0.4, 1);
    bands(ctx, 0, sea, w, g - sea, ['#2d86cf', '#3796d9', '#46a6e2']);
    for (let i = 0; i < w / 4; i++) R(ctx, rng() * w, sea + 2 + rng() * (g - sea - 3), 3 + rng.int(0, 3), 1, '#7cc8f2');
    for (let x = 0; x < w; x++) { const y = g - 1 + Math.round(Math.sin(x / 3) * 0.8); P(ctx, x, y, '#ffffff'); P(ctx, x, y + 1, '#d4c27e'); }
    R(ctx, 0, g + 1, w, h - g - 1, '#f2d890');
    speckle(ctx, rng, 0, g + 1, w, h - g - 1, ['#e6c577', '#fbe6a8', '#e0bd6c'], 0.08);
    // palm tree
    const px = rng() < 0.5 ? Math.round(w * 0.12) : Math.round(w * 0.86);
    for (let i = 0; i < 26; i++) R(ctx, px + Math.round(Math.sin(i / 9) * 3), g + 4 - i, 3, 1, i % 3 ? '#a77846' : '#8a5f35');
    const tx = px + Math.round(Math.sin(25 / 9) * 3) + 1, ty = g - 22;
    for (const [dx, dy] of [[-9, 3], [9, 3], [-6, 6], [6, 6], [0, -3], [-8, -1], [8, -1]]) {
      for (let i = 0; i <= 8; i++) { P(ctx, tx + dx * i / 8, ty + dy * i / 8 + Math.sin(i / 2.5) * 1.5, '#3e9a4a'); P(ctx, tx + dx * i / 8, ty + dy * i / 8 + Math.sin(i / 2.5) * 1.5 + 1, '#2e7a3a'); }
    }
    blob(ctx, tx, ty + 1, 1, 1, '#7a4a2a');
    for (let i = 0; i < w / 30; i++) {
      const x = rng() * w, y = g + 5 + rng() * (h - g - 8);
      if (rng() < 0.5) { P(ctx, x, y, '#ff8a6a'); P(ctx, x - 1, y, '#ff8a6a'); P(ctx, x + 1, y, '#ff8a6a'); P(ctx, x, y - 1, '#ff8a6a'); P(ctx, x, y + 1, '#ff8a6a'); }
      else { R(ctx, x, y, 2, 1, '#fff2e0'); P(ctx, x, y - 1, '#f2c4b0'); }
    }
  },

  volcano(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, g, ['#2a1426', '#3d1a2e', '#5a2333', '#7a2f30', '#9a432e']);
    for (let i = 0; i < 4; i++) cloud(ctx, rng() * w, 6 + rng() * 14, 1, '#4c2a36', '#3a1f2b');
    const cx = Math.round(w * (0.3 + rng() * 0.4)), top = Math.round(g * 0.28);
    for (let y = top; y < g + 2; y++) {
      const half = Math.round(6 + (y - top) * 1.15);
      R(ctx, cx - half, y, half * 2, 1, '#2a1a22');
      P(ctx, cx - half, y, '#3d262f');
    }
    R(ctx, cx - 6, top, 12, 2, '#ff7a2a');
    for (let y = top + 1; y < g; y++) { const x = cx + Math.round(Math.sin(y / 5) * 3 + (y - top) * 0.25); R(ctx, x, y, 2, 1, y % 3 ? '#ff6a24' : '#ffb347'); }
    ctx.globalAlpha = 0.35; blob(ctx, cx, top - 2, 10, 4, '#ff8a3a'); ctx.globalAlpha = 1;
    ridge(ctx, rng, w, g + 1, 4, 6, '#3a2228', g + 2);
    R(ctx, 0, g, w, h - g, '#3a2828');
    speckle(ctx, rng, 0, g, w, h - g, ['#4a3434', '#2e2020', '#5a4040'], 0.12);
    for (let i = 0; i < w / 14; i++) {
      let x = rng() * w, y = g + 3 + rng() * (h - g - 5);
      for (let k = 0; k < 6; k++) { P(ctx, x, y, k % 2 ? '#ffb347' : '#ff6a24'); x += rng.int(-1, 1) || 1; y += rng.int(0, 1); }
    }
  },

  cavern(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, h, ['#15131f', '#1b1826', '#201c2d', '#252134']);
    for (let y = 0; y < g; y += 4) for (let x = (y / 4) % 2 ? 0 : 6; x < w; x += 12) if (rng() < 0.6) R(ctx, x, y, 11, 3, rng() < 0.5 ? '#221e2e' : '#1d1a28');
    // rock pillars in the distance
    for (let i = 0; i < 3; i++) {
      const x = rng() * w, pw = 6 + rng.int(0, 6);
      R(ctx, x, 0, pw, g, '#231f31'); R(ctx, x, 0, 1, g, '#2e2940'); R(ctx, x + pw - 1, 0, 1, g, '#1a1724');
    }
    // stalactites
    for (let x = 0; x < w; x += 4 + rng.int(0, 6)) {
      const len = 6 + rng.int(0, 22), wid = 2 + rng.int(0, 3);
      for (let i = 0; i < len; i++) {
        const half = Math.max(0, Math.round(wid * (1 - i / len)));
        R(ctx, x - half, i, half * 2 + 1, 1, i % 6 === 0 ? '#3a3448' : '#2d2839');
        P(ctx, x - half, i, '#3d3750');
      }
    }
    ridge(ctx, rng, w, g, 5, 6, '#2c2838', h, '#3d3750');
    // stalagmites
    for (let i = 0; i < w / 30; i++) {
      const x = rng() * w, len = 6 + rng.int(0, 12), base = g + 2;
      for (let k = 0; k < len; k++) { const half = Math.round(3 * (1 - k / len)); R(ctx, x - half, base - k, half * 2 + 1, 1, '#34304a'); P(ctx, x - half, base - k, '#4a4462'); }
    }
    speckle(ctx, rng, 0, g, w, h - g, ['#3a3548', '#24202f', '#45405a'], 0.1);
    for (let i = 0; i < w / 22; i++) {
      const cx = rng() * w, cy = g + 3 + rng() * (h - g - 6);
      ctx.globalAlpha = 0.18; blob(ctx, cx, cy - 3, 7, 5, '#5ff0c8'); ctx.globalAlpha = 1;
      for (let k = 0; k < 3; k++) {
        const x = cx + (k - 1) * 3, y = cy + (k === 1 ? 0 : 1), hgt = k === 1 ? 4 : 2;
        R(ctx, x, y - hgt, 1, hgt, '#d8f7ee');
        blob(ctx, x, y - hgt - 1, k === 1 ? 3 : 2, 1, '#5ff0c8');
        P(ctx, x - 1, y - hgt - 2, '#b8fff0');
      }
    }
    // a little underground pool
    const px = rng() * w * 0.6 + w * 0.2, py = h - 6;
    blob(ctx, px, py, 16, 3, '#1f3a4f'); R(ctx, px - 8, py - 1, 6, 1, '#3f6f8f'); R(ctx, px + 3, py + 1, 4, 1, '#3f6f8f');
  },

  tundra(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, g, ['#9fc6ea', '#b4d4f0', '#cbe2f6', '#e1eefa', '#f0f7fd']);
    const cx = rng() * w;
    for (let k = 0; k < 3; k++) {
      const mx = (cx + k * w * 0.37) % w, top = g * (0.2 + rng() * 0.2);
      for (let y = Math.round(top); y < g; y++) {
        const half = Math.round((y - top) * 1.3);
        R(ctx, mx - half, y, half, 1, '#ffffff');
        R(ctx, mx, y, half, 1, '#c6d9ee');
        if (y - top > 10 && y % 2) { P(ctx, mx - half + 2, y, '#9fb6d0'); }
      }
    }
    for (let x = 4; x < w; x += 9 + rng.int(0, 8)) pine(ctx, x, g + 1, 10 + rng.int(0, 8), '#2f5d5a', '#24494a', '#ffffff');
    R(ctx, 0, g, w, h - g, '#f5f9ff');
    for (let i = 0; i < w / 6; i++) R(ctx, rng() * w, g + 2 + rng() * (h - g - 3), 4 + rng.int(0, 6), 1, '#dae6f4');
    for (let i = 0; i < 2; i++) { const x = rng() * w, y = g + 6 + rng() * (h - g - 12); blob(ctx, x, y, 8, 2, '#bfe2f2'); R(ctx, x - 4, y - 1, 3, 1, '#ffffff'); }
  },

  desert(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, g, ['#f4b86c', '#f7c886', '#fad79f', '#fde6bd', '#fff1d6']);
    const sx = rng() * w * 0.8 + w * 0.1;
    ctx.globalAlpha = 0.4; blob(ctx, sx, 14, 11, 11, '#fff6d8'); ctx.globalAlpha = 1;
    blob(ctx, sx, 14, 7, 7, '#fffbe8');
    ridge(ctx, rng, w, g - 4, 10, 3, '#eab872', g + 2, '#f5cf8f');
    ridge(ctx, rng, w, g + 1, 6, 4, '#dfa45a', g + 2, '#efc07c');
    R(ctx, 0, g, w, h - g, '#e7b363');
    for (let y = g + 3; y < h; y += 4) for (let x = 0; x < w; x++) if (Math.sin(x / 4 + y) > 0.6) P(ctx, x, y + Math.round(Math.sin(x / 6)), '#d39a50');
    for (let i = 0; i < 2 + rng.int(0, 1); i++) {
      const x = Math.round(rng() * (w - 12) + 6), base = g + 4 + Math.round(rng() * (h - g - 10));
      R(ctx, x, base - 14, 3, 14, '#4f9a4f'); P(ctx, x + 1, base - 13, '#7fc27a');
      R(ctx, x - 3, base - 9, 3, 2, '#4f9a4f'); R(ctx, x - 3, base - 12, 2, 4, '#4f9a4f');
      R(ctx, x + 3, base - 7, 3, 2, '#4f9a4f'); R(ctx, x + 4, base - 11, 2, 5, '#4f9a4f');
      for (let k = 0; k < 4; k++) P(ctx, x + 1, base - 12 + k * 3, '#3a7a3a');
    }
    speckle(ctx, rng, 0, g, w, h - g, ['#b07a48', '#f2c27c'], 0.01);
  },

  skyline(ctx, w, h, rng, g) {
    // a mountaintop meadow above a sea of treetops
    bands(ctx, 0, 0, w, g, ['#3f86e0', '#5596e6', '#6ea8ec', '#8abcf2', '#a8d0f6', '#c8e2fa']);
    for (let i = 0; i < 3; i++) cloud(ctx, rng() * w, 8 + rng() * g * 0.3, 1);
    ridge(ctx, rng, w, g - 18, 22, 3, '#9aa8c8', g, '#ffffff');
    for (let x = -4; x < w + 4; x += 5) blob(ctx, x, g - 4 + Math.round(rng() * 3), 4, 4, rng() < 0.5 ? '#2f6b48' : '#3a7d52');
    R(ctx, 0, g, w, h - g, '#86a864');
    speckle(ctx, rng, 0, g, w, h - g, ['#7a9c58', '#93b470', '#9a98a6'], 0.1);
    for (let i = 0; i < w / 14; i++) blob(ctx, rng() * w, g + 4 + rng() * (h - g - 6), 2, 1, '#9a98a6');
  },

  outskirts(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, g, ['#5b8fd9', '#7aa2df', '#9cb6e2', '#c2c8e0', '#e8d6cc', '#ffdcb8']);
    for (let x = 0; x < w;) { const bw = 6 + rng.int(0, 10), bh = 8 + rng.int(0, Math.round(g * 0.45)); R(ctx, x, g - 6 - bh, bw, bh + 6, rng() < 0.5 ? '#8a94b4' : '#9aa4c2'); for (let y = g - 4 - bh; y < g - 8; y += 4) for (let xx = x + 1; xx < x + bw - 1; xx += 3) if (rng() < 0.4) P(ctx, xx, y, '#ffe9a8'); x += bw + rng.int(0, 3); }
    for (let x = 0; x < w; x += 18 + rng.int(0, 10)) { R(ctx, x, g - 9, 14, 9, '#e6dccc'); for (let k = 0; k < 8; k++) R(ctx, x - 1 + k, g - 9 - k * 0.6, 16 - k * 2, 1, '#b2453a'); }
    R(ctx, 0, g, w, h - g, '#6aa84f');
    speckle(ctx, rng, 0, g, w, h - g, ['#5e9a45', '#77b45a'], 0.08);
    R(ctx, 0, g + Math.round((h - g) * 0.55), w, 3, '#9a9aa6');
    for (let x = 4; x < w; x += 26) { R(ctx, x, g - 2, 1, 14, '#4a5068'); P(ctx, x + 1, g - 2, '#fff3c4'); }
  },

  spooky(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, g, ['#0d0820', '#160d2e', '#20143a', '#2c1c48', '#382454', '#45305e']);
    blob(ctx, Math.round(w * 0.75), Math.round(g * 0.28), 6, 6, '#f4ecd0'); blob(ctx, Math.round(w * 0.75) + 2, Math.round(g * 0.28) - 1, 5, 5, '#20143a');
    for (let i = 0; i < 40; i++) P(ctx, rng() * w, rng() * g * 0.7, '#cfc6ff');
    ridge(ctx, rng, w, g - 4, 8, 5, '#1d1530', g + 2, '#2a2040');
    for (let i = 0; i < 6; i++) { const x = rng() * w, b = g + 2, hh = 14 + rng.int(0, 12); R(ctx, x, b - hh, 2, hh, '#151020'); R(ctx, x - 4, b - hh + 4, 5, 1, '#151020'); R(ctx, x + 2, b - hh + 7, 5, 1, '#151020'); }
    R(ctx, 0, g, w, h - g, '#334233');
    speckle(ctx, rng, 0, g, w, h - g, ['#2c3a2c', '#405040'], 0.1);
    for (let i = 0; i < w / 22; i++) { const x = rng() * w, y = g + 6 + rng() * (h - g - 10); R(ctx, x, y - 5, 4, 5, '#8a8696'); R(ctx, x, y - 5, 4, 1, '#a8a4b4'); }
    ctx.globalAlpha = 0.25; R(ctx, 0, g - 2, w, 6, '#c8c0e0'); ctx.globalAlpha = 1;
  },

  prism(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, g, ['#ff9ad5', '#f0a8e0', '#d8b8ee', '#c0c8f6', '#a6dcfc', '#a6f6ff']);
    const cols = ['#ff7ac8', '#7ad6ff', '#ffe27a', '#b08aff'];
    for (let i = 0; i < 7; i++) { const x = rng() * w, y = 6 + rng() * g * 0.6, r = 3 + rng.int(0, 5), c = rng.pick(cols); if (i % 3 === 0) blob(ctx, x, y, r, r, c); else if (i % 3 === 1) R(ctx, x, y, r * 2, r * 2, c); else for (let k = 0; k < r * 2; k++) R(ctx, x - k / 2, y + k, k + 1, 1, c); }
    for (let y = g; y < h; y++) for (let x = 0; x < w; x++) P(ctx, x, y, ((x >> 3) + (y >> 3)) % 2 ? '#fdf0ff' : '#e6f0ff');
  },

  synth(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, g, ['#0a0220', '#1a0638', '#3a0a54', '#6a1270', '#b0207e', '#ff3d9a']);
    const sx = w / 2, sy = g - 10;
    for (let y = -12; y <= 12; y++) { if (y > 0 && y % 3 === 0) continue; const half = Math.floor(Math.sqrt(144 - y * y)); R(ctx, sx - half, sy + y, half * 2, 1, y < 0 ? '#ffe27a' : '#ff8a5a'); }
    for (let i = 0; i < 30; i++) P(ctx, rng() * w, rng() * g * 0.5, '#ffffff');
    R(ctx, 0, g, w, h - g, '#12062a');
    for (let y = g; y < h; y += Math.max(2, Math.round((y - g) / 4) + 2)) R(ctx, 0, y, w, 1, '#ff3dd0');
    for (let k = -10; k <= 10; k++) for (let y = g; y < h; y++) P(ctx, sx + k * (6 + (y - g) * 0.9), y, '#ff3dd0');
  },

  seafloor(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, h, ['#2a8cc4', '#2380b8', '#1c72a8', '#176597', '#125784', '#0f4a72']);
    ctx.globalAlpha = 0.12;
    for (let i = 0; i < 4; i++) { const x0 = rng() * w; for (let y = 0; y < g; y++) R(ctx, x0 + y * 0.35, y, 4 + y * 0.08, 1, '#ffffff'); }
    ctx.globalAlpha = 1;
    ridge(ctx, rng, w, g - 2, 10, 4, '#0f4a6a', g + 2, '#14587a');
    R(ctx, 0, g, w, h - g, '#c9b27a');
    for (let y = g + 2; y < h; y += 3) for (let x = 0; x < w; x++) if (Math.sin(x / 3 + y * 2) > 0.7) P(ctx, x, y, '#b39a64');
    for (let i = 0; i < w / 10; i++) {
      const x = rng() * w, base = g + 2 + rng() * (h - g - 4), len = 8 + rng.int(0, 14);
      for (let k = 0; k < len; k++) P(ctx, x + Math.round(Math.sin(k / 2.2) * 1.4), base - k, k % 3 ? '#2f9a6a' : '#46b47e');
    }
    for (let i = 0; i < w / 40; i++) {
      const x = rng() * w, base = g + 3 + rng() * (h - g - 6), c = rng.pick(['#ff7a8a', '#ffb36b', '#d58aff']);
      for (let k = 0; k < 6; k++) { R(ctx, x - k / 2, base - k, 1, 1, c); R(ctx, x + k / 2, base - k, 1, 1, c); R(ctx, x, base - k * 1.3, 1, 1, c); }
    }
  },

  marsh(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, g, ['#9fc4ae', '#b1d0bc', '#c3dcca', '#d5e7d9']);
    for (let x = 0; x < w; x += 10 + rng.int(0, 8)) roundTree(ctx, x, g + 1, 5 + rng.int(0, 3), '#55705a', '#6f9a80', '#82ab91', '#5f8a70');
    R(ctx, 0, g, w, h - g, '#5f7f3f');
    speckle(ctx, rng, 0, g, w, h - g, ['#6a5a3a', '#557336', '#6f8f48'], 0.08);
    for (let i = 0; i < 3; i++) {
      const x = rng() * w, y = g + 6 + rng() * (h - g - 12), rx = 10 + rng.int(0, 10);
      blob(ctx, x, y, rx, 3, '#4f7f74');
      R(ctx, x - rx / 2, y - 1, rx / 2, 1, '#78a89a');
      for (let k = 0; k < 2; k++) { const lx = x - rx / 2 + rng() * rx, ly = y - 1 + rng() * 2; blob(ctx, lx, ly, 2, 1, '#4faa5a'); if (rng() < 0.5) P(ctx, lx, ly - 1, '#ff9ec6'); }
    }
    for (let i = 0; i < w / 7; i++) {
      const x = rng() * w, base = g + 2 + rng() * (h - g - 3), len = 5 + rng.int(0, 7);
      R(ctx, x, base - len, 1, len, '#6a8a3a');
      if (rng() < 0.4) R(ctx, x, base - len - 2, 1, 3, '#7a5030');
    }
  },

  starfield(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, g, ['#0a0f2e', '#111842', '#18214f', '#22305f', '#2b3c70']);
    for (let i = 0; i < w * g / 40; i++) P(ctx, rng() * w, rng() * g, rng.pick(['#ffffff', '#fff3c4', '#bcd2ff', '#8a9ad8']));
    for (let i = 0; i < 4; i++) { const x = rng() * w, y = rng() * g * 0.7; P(ctx, x, y, '#ffffff'); P(ctx, x - 1, y, '#8a9ad8'); P(ctx, x + 1, y, '#8a9ad8'); P(ctx, x, y - 1, '#8a9ad8'); P(ctx, x, y + 1, '#8a9ad8'); }
    const mx = rng() * w * 0.6 + w * 0.2;
    blob(ctx, mx, 14, 6, 6, '#fff3c4'); blob(ctx, mx + 3, 12, 5, 5, '#111842');
    ridge(ctx, rng, w, g - 2, 8, 3, '#1a2448', g + 2, '#24305a');
    R(ctx, 0, g, w, h - g, '#22305a');
    speckle(ctx, rng, 0, g, w, h - g, ['#2e3f6e', '#1b2750'], 0.1);
    for (let i = 0; i < w / 16; i++) { const x = rng() * w, y = g + 3 + rng() * (h - g - 5); R(ctx, x, y, 1, 2, '#3f5a8a'); P(ctx, x, y - 1, '#9ff0ff'); }
  },

  crystal(ctx, w, h, rng, g) {
    bands(ctx, 0, 0, w, h, ['#1d1534', '#231a40', '#2a1f4c', '#302457', '#352960']);
    const pairs = [['#5aa6d8', '#9fe7ff', '#e8fbff'], ['#a35ad0', '#e7a6ff', '#fbeaff'], ['#4fc0b0', '#9ff7e0', '#effffb']];
    const shard = (x, base, hgt, wid, [c1, c2, edge], dir = -1, lean = 0) => {
      for (let i = 0; i < hgt; i++) {
        const half = Math.max(0, Math.round(wid * (1 - Math.pow(i / hgt, 1.4))));
        const y = base + dir * i, xx = x + Math.round(lean * i);
        R(ctx, xx - half, y, half, 1, c1); R(ctx, xx, y, half + 1, 1, c2); P(ctx, xx, y, edge);
      }
    };
    // glow behind clusters
    // faint dithered glow behind the clusters
    for (let i = 0; i < 4; i++) {
      const gx = rng() * w, gy = g - 12 - rng() * 16, c = rng.pick(['#3b2d6e', '#33407a']);
      for (let y = -10; y <= 10; y++) for (let x = -16; x <= 16; x++) if ((x * x) / 256 + (y * y) / 100 < 1 && (x + y) % 2 === 0) P(ctx, gx + x, gy + y, c);
    }
    for (let i = 0; i < w / 18; i++) shard(rng() * w, 0, 6 + rng.int(0, 16), 2 + rng.int(0, 2), rng.pick(pairs), 1, rng.range(-0.15, 0.15));
    for (let i = 0; i < w / 32; i++) {
      const cx = rng() * w, pair = rng.pick(pairs);
      shard(cx, g + 2, 18 + rng.int(0, 22), 4 + rng.int(0, 2), pair);
      shard(cx - 6, g + 2, 10 + rng.int(0, 10), 3, pair, -1, -0.25);
      shard(cx + 6, g + 2, 8 + rng.int(0, 10), 3, pair, -1, 0.3);
    }
    R(ctx, 0, g, w, h - g, '#2e2448');
    speckle(ctx, rng, 0, g, w, h - g, ['#3a2f5a', '#251c3c', '#4a3f70'], 0.1);
    for (let i = 0; i < w / 10; i++) {
      const x = rng() * w, y = g + 3 + rng() * (h - g - 4), c = rng.pick(['#9fe7ff', '#e7a6ff', '#9ff7e0']);
      P(ctx, x, y, c); P(ctx, x, y - 1, c); P(ctx, x + 1, y, '#ffffff');
    }
  },
};

const cache = new Map();

/** Static background canvas for a biome. Cached by (id, size, seed). */
export function renderBiome(id, w, h, opts = {}) {
  const biome = PAINTERS[id] ? id : 'meadow';
  const key = `${biome}:${w}x${h}:${opts.seed ?? 0}`;
  if (cache.has(key)) return cache.get(key);
  const c = makeCanvas(w, h);
  const ctx = c.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  const rng = createRng(hashString(`${biome}:${opts.seed ?? 0}`));
  const g = Math.round(h * (opts.ground ?? BIOME_INFO[biome].ground));
  PAINTERS[biome](ctx, w, h, rng, g);
  if (cache.size > 60) cache.delete(cache.keys().next().value);
  cache.set(key, c);
  return c;
}

export function groundTop(id, h) {
  return Math.round(h * (BIOME_INFO[id]?.ground ?? 0.65));
}

/** Night overlay colour for outdoor biomes based on the clock, or null. */
export function skyTint(id, date = new Date()) {
  if (BIOME_INFO[id]?.dark) return null;
  const hr = date.getHours() + date.getMinutes() / 60;
  if (hr >= 21 || hr < 5) return 'rgba(16,22,70,0.42)';
  if (hr >= 19) return 'rgba(60,30,90,0.25)';
  if (hr >= 17.5) return 'rgba(255,140,60,0.14)';
  if (hr < 6.5) return 'rgba(120,90,160,0.2)';
  return null;
}

/** Animated ambient particles for a biome. */
export class Ambient {
  constructor(id, w, h, seed = 1) {
    this.id = PAINTERS[id] ? id : 'meadow';
    this.kind = BIOME_INFO[this.id].particles;
    this.w = w; this.h = h;
    this.g = groundTop(this.id, h);
    this.rng = createRng(seed);
    this.t = 0;
    this.items = [];
    const n = { butterflies: 4, leaves: 14, gulls: 2, embers: 26, drips: 6, snow: 60, sand: 30, clouds: 4, bubbles: 18, fireflies: 14, twinkle: 30, sparkles: 14 }[this.kind] ?? 10;
    for (let i = 0; i < n; i++) this.items.push(this.spawn(true));
  }
  spawn(initial) {
    const r = this.rng, w = this.w, h = this.h, g = this.g;
    switch (this.kind) {
      case 'snow': return { x: r() * w, y: initial ? r() * h : -2, vy: 6 + r() * 8, ph: r() * 6 };
      case 'leaves': return { x: r() * w, y: initial ? r() * h : -2, vy: 5 + r() * 6, ph: r() * 6, c: r.pick(['#d9892e', '#e8b04a', '#5fa34a', '#b5562f']) };
      case 'embers': return { x: r() * w, y: initial ? r() * h : h + 2, vy: -(6 + r() * 14), ph: r() * 6, life: r() };
      case 'bubbles': return { x: r() * w, y: initial ? r() * h : h + 2, vy: -(5 + r() * 8), ph: r() * 6, s: r() < 0.3 ? 2 : 1 };
      case 'sand': return { x: initial ? r() * w : -2, y: g - 10 + r() * (h - g + 10), vx: 18 + r() * 20, ph: r() * 6 };
      case 'clouds': return { x: initial ? r() * w : -14, y: 6 + r() * g * 0.6, vx: 2 + r() * 3, s: 1 };
      case 'gulls': return { x: initial ? r() * w : -6, y: 8 + r() * g * 0.4, vx: 6 + r() * 5, ph: r() * 6 };
      case 'butterflies': return { x: r() * w, y: g - 8 + r() * (h - g), ph: r() * 6, c: r.pick(['#ffffff', '#ffd23f', '#ff9ec6', '#9fd3ff']), vx: r() < 0.5 ? -4 : 4 };
      case 'fireflies': return { x: r() * w, y: g - 20 + r() * (h - g + 10), ph: r() * 6, sp: 0.5 + r() };
      case 'twinkle': return { x: r() * w, y: r() * g, ph: r() * 6, sp: 1 + r() * 2 };
      case 'sparkles': return { x: r() * w, y: r() * h, ph: r() * 6, sp: 0.6 + r() };
      case 'drips': return { x: r() * w, y: r() * 10, vy: 0, wait: r() * 4 };
      default: return { x: r() * w, y: r() * h, ph: 0 };
    }
  }
  update(dt) {
    this.t += dt;
    const { w, h } = this;
    this.items = this.items.map((p) => {
      switch (this.kind) {
        case 'snow': case 'leaves':
          p.y += p.vy * dt; p.x += Math.sin(this.t * 1.5 + p.ph) * dt * 6;
          return p.y > h + 2 ? this.spawn(false) : p;
        case 'embers': case 'bubbles':
          p.y += p.vy * dt; p.x += Math.sin(this.t * 2 + p.ph) * dt * 4;
          return p.y < -2 ? this.spawn(false) : p;
        case 'sand': case 'clouds': case 'gulls':
          p.x += p.vx * dt;
          return p.x > w + 14 ? this.spawn(false) : p;
        case 'butterflies':
          p.x += p.vx * dt + Math.sin(this.t * 3 + p.ph) * dt * 8; p.y += Math.cos(this.t * 2.3 + p.ph) * dt * 6;
          if (p.x < -4 || p.x > w + 4) p.vx *= -1;
          return p;
        case 'fireflies':
          p.x += Math.sin(this.t * p.sp + p.ph) * dt * 5; p.y += Math.cos(this.t * p.sp * 0.7 + p.ph) * dt * 4;
          return p;
        case 'drips':
          if (p.wait > 0) { p.wait -= dt; return p; }
          p.vy += 60 * dt; p.y += p.vy * dt;
          return p.y > this.g + 4 ? this.spawn(false) : p;
        default: return p;
      }
    });
  }
  draw(ctx) {
    const t = this.t;
    for (const p of this.items) {
      const x = Math.round(p.x), y = Math.round(p.y);
      switch (this.kind) {
        case 'snow': P(ctx, x, y, '#ffffff'); break;
        case 'leaves': P(ctx, x, y, p.c); P(ctx, x + 1, y + (Math.sin(t * 4 + p.ph) > 0 ? 1 : 0), p.c); break;
        case 'embers': P(ctx, x, y, Math.sin(t * 10 + p.ph) > 0 ? '#ffb347' : '#ff6a24'); break;
        case 'bubbles':
          if (p.s === 2) { P(ctx, x, y - 1, '#bfe9ff'); P(ctx, x - 1, y, '#bfe9ff'); P(ctx, x + 1, y, '#bfe9ff'); P(ctx, x, y + 1, '#bfe9ff'); }
          else P(ctx, x, y, '#bfe9ff');
          break;
        case 'sand': P(ctx, x, y, '#f5d59a'); break;
        case 'clouds': cloud(ctx, x, y, 1, 'rgba(255,255,255,0.85)', 'rgba(219,234,255,0.85)'); break;
        case 'gulls': { const up = Math.sin(t * 6 + p.ph) > 0 ? 1 : 0; P(ctx, x - 2, y - up, '#ffffff'); P(ctx, x - 1, y, '#ffffff'); P(ctx, x, y + 1, '#555'); P(ctx, x + 1, y, '#ffffff'); P(ctx, x + 2, y - up, '#ffffff'); break; }
        case 'butterflies': { const open = Math.sin(t * 14 + p.ph) > 0; P(ctx, x, y, '#333'); if (open) { P(ctx, x - 1, y - 1, p.c); P(ctx, x + 1, y - 1, p.c); } else { P(ctx, x - 1, y, p.c); P(ctx, x + 1, y, p.c); } break; }
        case 'fireflies': if (Math.sin(t * 2 * p.sp + p.ph) > 0.2) { ctx.globalAlpha = 0.35; R(ctx, x - 1, y - 1, 3, 3, '#e8ff7a'); ctx.globalAlpha = 1; P(ctx, x, y, '#f4ffb0'); } break;
        case 'twinkle': if (Math.sin(t * p.sp + p.ph) > 0.85) { P(ctx, x, y, '#ffffff'); P(ctx, x - 1, y, '#8a9ad8'); P(ctx, x + 1, y, '#8a9ad8'); P(ctx, x, y - 1, '#8a9ad8'); P(ctx, x, y + 1, '#8a9ad8'); } break;
        case 'sparkles': { const s = Math.sin(t * 2 * p.sp + p.ph); if (s > 0.7) { P(ctx, x, y, '#ffffff'); if (s > 0.9) { P(ctx, x - 1, y, '#e7a6ff'); P(ctx, x + 1, y, '#9fe7ff'); P(ctx, x, y - 1, '#e7a6ff'); P(ctx, x, y + 1, '#9fe7ff'); } } break; }
        case 'drips': P(ctx, x, y, '#7fb8d8'); break;
        default: break;
      }
    }
  }
}
