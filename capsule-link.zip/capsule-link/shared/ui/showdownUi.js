// Showdown pieces shared by the PC and phone Battle screens.
import { h, mount, toast } from './dom.js';
import { spriteCanvas } from './art.js';
import { finishBattle } from './afterBattle.js';
import { sfx } from './audio.js';
import {
  buildTeam, parseBattleLog, findMySide, battleRewards, replayUrls, extractLog, SHOWDOWN_DEFAULTS, toId, displayName,
} from '../engine/index.js';

/**
 * ctx = {
 *   idx, bank, getSave(),
 *   commit(fn) or record(ev)   apply changes / events (see afterBattle.finishBattle)
 *   update(fn)                 a plain local change to the save (history, remembered teams)
 *   team()                     creatures to bring (max 6)
 *   fetchText(url)             fetch without browser CORS limits (null when not possible)
 * }
 */

export function showdownSettings(save) {
  const s = save.settings.showdown || {};
  return { name: s.name ?? '', server: s.server || SHOWDOWN_DEFAULTS.server, format: s.format || SHOWDOWN_DEFAULTS.format };
}

/** Build the team and remember its nicknames so the battle log can be matched back. */
export function prepareTeam(ctx) {
  const team = buildTeam(ctx.idx, ctx.team());
  ctx.update((save) => {
    save.showdownTeams = [{ at: Date.now(), map: team.map }, ...(save.showdownTeams ?? [])].slice(0, 8);
  });
  return team;
}

/** Read a finished battle and apply the in-house rewards. Returns the results element, or null. */
export async function ingestBattle(ctx, raw, { id, user } = {}) {
  const parsed = parseBattleLog(raw, { id });
  if (!parsed.ok) throw new Error(parsed.error);
  const save = ctx.getSave();
  const settings = showdownSettings(save);
  // teams sent to Showdown before, plus the team as it is now (for a team copied by hand)
  const candidates = [...(save.showdownTeams ?? []), { map: buildTeam(ctx.idx, ctx.team()).map }];
  const mine = findMySide(parsed, candidates, user || settings.name);
  if (!mine || !Object.keys(mine.map).length) {
    throw new Error('None of your creatures are in this battle. Battles count when they are played with the team Capsule Link sends to Showdown.');
  }
  const rewards = battleRewards(ctx.idx, parsed, mine, save);
  if (save.appliedEvents?.includes(rewards.eventId)) {
    toast('That battle was already counted.');
    return null;
  }
  const el = await finishBattle(ctx, rewards);
  ctx.update((s) => {
    s.showdownHistory = [{
      id: rewards.eventId, at: Date.now(), opponent: rewards.opponent, won: rewards.won, tie: rewards.tie,
      exp: rewards.results.reduce((n, r) => n + r.exp, 0), format: parsed.format,
    }, ...(s.showdownHistory ?? [])].slice(0, 30);
  });
  sfx(rewards.won ? 'win' : 'faint');
  return el;
}

export function teamPanel(ctx, { actions = null } = {}) {
  const team = buildTeam(ctx.idx, ctx.team());
  const creatures = ctx.team();
  const copy = async () => {
    const t = prepareTeam(ctx);
    try { await navigator.clipboard.writeText(t.text); toast('Team copied. In Showdown: Teambuilder, New team, Import.', 'ok'); }
    catch { toast('Copying is blocked here. Select the text under "Show the team" and copy it.', 'err'); }
  };
  return h('section', { class: 'panel col sd-team' },
    h('div', { class: 'row' }, h('h2', { class: 'grow' }, 'Your team'), h('span', { class: 'dim' }, `${team.sets.length}/6`)),
    team.sets.length
      ? h('div', { class: 'team-strip' }, creatures.filter((c) => ctx.idx.species.has(c.speciesId)).map((c) => h('div', { class: 'team-chip', title: displayName(ctx.idx, c) },
        spriteCanvas(ctx.bank, c.speciesId, { scale: 1 }), h('span', { class: 'micro' }, `Lv${c.level}`))))
      : h('p', { class: 'dim' }, 'Nobody to bring yet.'),
    h('div', { class: 'row wrap' }, actions, h('button', { class: 'btn', disabled: !team.sets.length, onclick: copy }, 'Copy team')),
    team.sets.length ? h('details', null, h('summary', null, 'Show the team as Showdown sees it'), h('pre', { class: 'sd-export' }, team.text)) : null);
}

export function resultPanel(ctx, onResult) {
  let busy = false;
  const link = h('input', { type: 'url', id: 'sd-replay', placeholder: 'https://replay.pokemonshowdown.com/…' });
  const paste = h('textarea', { id: 'sd-log', class: 'code', rows: 4, placeholder: 'Or paste the battle log here' });
  const run = async (raw, opts) => {
    if (busy) return;
    busy = true;
    try {
      const el = await ingestBattle(ctx, raw, opts);
      if (el) onResult(el);
    } catch (e) { toast(e.message, 'err'); }
    busy = false;
  };
  const fromLink = async () => {
    const u = replayUrls(link.value);
    if (!u) { toast('Paste a replay link that starts with https://', 'err'); return; }
    if (!ctx.fetchText) { toast('Replay links work in the apps. Here, paste the battle log instead.', 'err'); return; }
    let text = null;
    for (const url of [u.json, u.log]) {
      try { text = await ctx.fetchText(url); if (text) break; } catch { /* try the next form */ }
    }
    if (!text) { toast('Could not load that replay. Check the link, or paste the log instead.', 'err'); return; }
    run(text, { id: u.id });
  };
  const fromFile = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    run(await f.text(), { id: f.name.replace(/\.(html?|json|log|txt)$/i, '') });
    e.target.value = '';
  };
  return h('section', { class: 'panel col' },
    h('h2', null, 'Add a finished battle'),
    h('p', { class: 'dim' }, 'Battles in the app’s Showdown window count on their own. For a battle played somewhere else, upload the replay in Showdown and paste its link, or load the downloaded replay file.'),
    h('div', { class: 'row' }, link, h('button', { class: 'btn primary', onclick: fromLink }, 'Add')),
    h('div', { class: 'row wrap' },
      h('label', { class: 'btn small' }, 'Load a replay file', h('input', { type: 'file', accept: '.html,.htm,.json,.log,.txt', class: 'hidden', onchange: fromFile })),
      h('button', { class: 'btn small', onclick: () => { if (!extractLog(paste.value)) { toast('Paste the battle log first.', 'err'); return; } run(paste.value, {}); } }, 'Add pasted log')),
    paste);
}

export function historyPanel(ctx) {
  const list = ctx.getSave().showdownHistory ?? [];
  return h('section', { class: 'panel col' },
    h('h2', null, 'Recent battles'),
    list.length ? h('table', { class: 'grid' }, h('tbody', null, list.slice(0, 12).map((b) => h('tr', null,
      h('td', null, b.tie ? 'Draw' : b.won ? 'Won' : 'Lost'),
      h('td', { class: 'ell' }, b.opponent),
      h('td', { class: 'num' }, `+${b.exp} exp`),
      h('td', { class: 'dim' }, new Date(b.at).toLocaleDateString())))))
      : h('p', { class: 'dim' }, 'No battles yet.'));
}

export function showdownSettingsPanel(save, onChange) {
  const s = showdownSettings(save);
  const set = (k, v) => onChange((sv) => { sv.settings.showdown = { ...(sv.settings.showdown || {}), [k]: v }; });
  return h('section', { class: 'panel col' },
    h('h2', null, 'Showdown account'),
    h('label', { class: 'field' }, h('span', null, 'Your Showdown name'),
      h('input', { type: 'text', id: 'sd-name', maxLength: 18, value: s.name, placeholder: 'Log in once in the Showdown window and it fills in', onchange: (e) => set('name', e.target.value.trim()) })),
    h('details', null, h('summary', null, 'Server and format'),
      h('div', { class: 'col' },
        h('label', { class: 'field' }, h('span', null, 'Showdown server'), h('input', { type: 'url', id: 'sd-server', value: s.server, onchange: (e) => set('server', e.target.value.trim() || SHOWDOWN_DEFAULTS.server) })),
        h('label', { class: 'field' }, h('span', null, 'Battle format'), h('input', { type: 'text', id: 'sd-format', value: s.format, onchange: (e) => set('format', toId(e.target.value) || SHOWDOWN_DEFAULTS.format) })),
        h('p', { class: 'micro faint' }, 'Custom Game (gen9customgame) accepts any level and moveset. Your own made-up species only work on a Showdown server you run yourself (see the README).'))));
}

export { mount };
