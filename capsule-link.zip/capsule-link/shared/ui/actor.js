// What a creature looks like to the R.A.N.C.H. renderer (yard, care room, activities), PC and phone.
import { sizeVariant } from './creatureSize.js';
import { spriteIdOf } from './art.js';
import { displayName, mood, tickNeeds, speciesOf, friendsOf, movementOf, traitsOf } from '../engine/index.js';

/** clothesImg(idx, id) → a picture of a piece of clothing (optional: the PC's dress-up art). */
export function actorFor(idx, c, { clothesImg = null } = {}) {
  tickNeeds(idx, c);
  const sp = speciesOf(idx, c);
  const types = sp?.types ?? [];
  const typeNames = types.map((t) => idx.types.get(t)?.name ?? t);
  const all = [...types, ...typeNames].join(' ');
  const mv = movementOf(idx, sp, c);
  return {
    uid: c.uid, speciesId: spriteIdOf(c), sizeMul: sizeVariant(c).mult, name: displayName(idx, c), mood: mood(c).id,
    asleep: !!(c.sleep && (c.sleep.until ?? 0) > Date.now()),
    // speed stat sets how fast they scurry: slow ones plod, fast ones dart
    speed: c.egg ? 0 : 0.35 + (sp?.baseStats?.spe ?? 50) / 45,
    swim: mv.swim, fly: !c.egg && mv.float, canFly: !c.egg && mv.canFly, waterOnly: !mv.walk && mv.swim, prefersWater: mv.def === 'swim', fire: /fire|ember/i.test(all),
    types: [...types, ...typeNames], egg: !!c.egg,
    ...traitsOf(idx, c),
    friends: friendsOf(c).map((f) => f.uid),
    clothes: clothesImg ? (c.clothes ?? []).map((w) => ({ ...w, img: clothesImg(idx, w.id) })).filter((w) => w.img) : [],
  };
}
