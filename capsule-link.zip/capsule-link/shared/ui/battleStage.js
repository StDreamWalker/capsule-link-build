// The 2.5D battle stage: wild battles shown like the console games (Battle Revolution-style cameras, moves
// playing out between the two creatures) instead of Showdown's flat screen. Showdown still runs the battle and
// its own screen keeps going underneath, unseen, so the pace and every rule stay exactly Showdown's; each
// animation it starts arrives here as an event (see hookScene in sdbattle/wild.js) and is acted out on a Yard
// in the 'battle' scene.
//
//   createBattleStage({ idx, bank, place, resolveTexture, creatureFor(mon), speciesFor(name) }) → { el, init, event, destroy }
import { h } from './dom.js';
import { Yard, BATTLE_SPOTS, FIELD_Z, reflectFor } from './yard.js';
import { actorFor } from './actor.js';
import { classifyMove, lookOf, vanishOf } from './stageMoves.js';
import { moveFx, fxImage } from './moveFx.js';
import { creatureCry, crowdNoise } from './audio.js';
import { speciesOf } from '../engine/creature.js';

const TYPE_COL = { HyperBeam: '#ffb43a', Normal: '#ecebd8', Fire: '#ff7a2a', Water: '#3ea0ff', Electric: '#ffe03a', Grass: '#5cd65c', Ice: '#a8f2ff', Fighting: '#e8603a', Poison: '#b85ae0', Ground: '#d8b060', Flying: '#c0d0ff', Psychic: '#ff5aa8', Bug: '#a8c83a', Rock: '#c0a868', Ghost: '#8a6ad8', Dragon: '#7a6aff', Dark: '#4a3a50', Steel: '#d0d0e8', Fairy: '#ffa8e0', Stellar: '#ffffff' };
const STATUS_COL = { brn: '#f08030', par: '#f8d030', psn: '#a040a0', tox: '#7a2a8a', slp: '#8c8c9c', frz: '#98d8d8' };
const STATUS_LABEL = { brn: 'BRN', par: 'PAR', psn: 'PSN', tox: 'TOX', slp: 'SLP', frz: 'FRZ' };
const WEATHER = { raindance: 'rain', primordialsea: 'storm', sunnydays: 'clear', sunnyday: 'clear', desolateland: 'clear', sandstorm: 'windy', hail: 'snow', snow: 'snow', snowscape: 'snow', deltastream: 'windy' };
const decode = (s) => { const t = document.createElement('textarea'); t.innerHTML = String(s ?? ''); return t.value; };
const ease = (t) => (t < 0 ? 0 : t > 1 ? 1 : t * t * (3 - 2 * t));
const lerp = (a, b, t) => a + (b - a) * t;
const rnd = (a, b) => a + Math.random() * (b - a);

/** Places to battle in: natural ones (like the ranch's) and battle-only arenas. look = the yard environment. */
export const BATTLE_PLACES = [
  { id: 'meadow', label: 'Meadow', look: 'meadow', find: ['meadow'] },
  { id: 'forest', label: 'Forest', look: 'forest', find: ['forest'] },
  { id: 'shoreline', label: 'Beach', look: 'shoreline', find: ['shoreline'] },
  { id: 'marsh', label: 'Marsh', look: 'marsh', find: ['marsh'] },
  { id: 'desert', label: 'Desert', look: 'desert', find: ['desert'] },
  { id: 'tundra', label: 'Snowfield', look: 'tundra', find: ['tundra'] },
  { id: 'volcano', label: 'Volcano', look: 'volcano', find: ['volcano'] },
  { id: 'cavern', label: 'Cave', look: 'cavern', find: ['cavern'] },
  { id: 'crystal', label: 'Crystal cave', look: 'crystal', find: ['crystal', 'cavern'] },
  { id: 'skyline', label: 'Mountaintop', look: 'skyline', find: ['skyline'] },
  { id: 'seafloor', label: 'Seafloor', look: 'seafloor', find: ['seafloor'] },
  { id: 'outskirts', label: 'City park', look: 'outskirts', find: ['outskirts'] },
  { id: 'spooky', label: 'Haunted woods', look: 'spooky', find: ['spooky'] },
  { id: 'starfield', label: 'Starfield', look: 'starfield', find: ['starfield'] },
  { id: 'colosseum', label: 'Battle Colosseum ★', look: 'colosseum', find: null, arena: true },
  { id: 'stadium', label: 'Stadium (evening) ★', look: 'stadium', find: null, arena: true },
  { id: 'ruins', label: 'Ancient Ruins ★', look: 'ruins', find: ['desert', 'cavern', 'spooky', 'forest'], arena: true },
  { id: 'shrine', label: 'Mountain Shrine ★', look: 'shrine', find: ['forest', 'skyline', 'spooky'], arena: true },
  { id: 'prism', label: 'Prism Plaza ★', look: 'prism', find: null, arena: true },
  { id: 'neon', label: 'Neon Grid ★', look: 'synth', find: null, arena: true },
];
export const battlePlace = (id) => BATTLE_PLACES.find((p) => p.id === id) ?? BATTLE_PLACES[0];

export function createBattleStage({ idx, bank, place = 'meadow', resolveTexture = null, creatureFor, speciesFor, classic = null, trainers = {}, ambient = null, versus = false, practice = false, dramatic = false }) {
  const P = battlePlace(place);
  const canvas = h('canvas', { class: 'bst-canvas', 'aria-hidden': 'true' });
  // hovering a creature's HP plate shows Showdown's details for it
  const hud = [0, 1].map((side) => h('div', { class: `bst-hud has-tooltip ${side === 0 ? 'mine' : 'foe'}`, hidden: true, 'data-tooltip': `activepokemon|${side}|0`, 'data-ownheight': '1' }));
  const text = h('div', { class: 'bst-text' });
  const tips = [0, 1].map((side) => h('div', { class: 'bst-tip has-tooltip', 'data-tooltip': `activepokemon|${side}|0`, 'data-ownheight': '1' }));
  const flash = h('div', { class: 'bst-flash' });
  const bars = h('div', { class: 'bst-bars on' });
  const viewBtn = h('button', { class: 'bst-view', type: 'button', title: 'Show Showdown’s classic flat battle screen instead' }, 'Classic view');
  const camBtn = h('button', { class: 'bst-cam', type: 'button', title: 'Camera: moves with the action, or stays put' }, '🎥 Dynamic');
  const black = h('div', { class: 'bst-black on' });
  // "Pikachu used Thunderbolt!" in the move's type colour, and the announcer's running commentary
  const banner = h('div', { class: 'bst-moveban' }, h('span', { class: 'who' }), h('span', { class: 'mv' }));
  const caster = h('div', { class: 'bst-caster' });
  // what just happened (a critical hit, super effective, a stat rising or falling…): small translucent notes at
  // the side, out of the way of the creatures
  const noteBox = h('div', { class: 'bst-notes', 'aria-live': 'polite' });
  const statBox = h('div', { class: 'bst-notes bst-stats' });
  const el = h('div', { class: 'bst' }, canvas, ...tips, hud[1], hud[0], banner, caster, noteBox, statBox, text, flash, bars, black, h('div', { class: 'bst-btns' }, camBtn));
  void viewBtn;
  let dynamic = true;
  try { dynamic = localStorage.getItem('clBstCam') !== 'fixed'; } catch { /* default */ }
  camBtn.textContent = dynamic ? '🎥 Dynamic' : '🎥 Fixed';
  camBtn.onclick = () => { dynamic = !dynamic; camBtn.textContent = dynamic ? '🎥 Dynamic' : '🎥 Fixed'; try { localStorage.setItem('clBstCam', dynamic ? 'dynamic' : 'fixed'); } catch { /* fine */ } };
  viewBtn.onclick = () => classic?.();

  const fx = []; // effects (world-space), each { t, life, update(dt), draw(ctx) }
  const parts = []; // particles { x, y, z, vx, vy, vz, g, life, max, size, col, shape, spin }
  const mons = [null, null]; // { info, uid, spec, base sizeMul }
  const specs = {};
  const uidOf = (side) => (side === 0 ? 'bt-near' : 'bt-far');
  // (move practice: it stands in the middle, and the far side is wherever the target it's aiming at stands)
  let practiceAt = [0, FIELD_Z + 5], practiceHit = null;
  const spot = (side) => (practice ? (side === 0 ? [0, FIELD_Z] : practiceAt) : side === 0 ? BATTLE_SPOTS.near : BATTLE_SPOTS.far);
  let shake = 0, time = 0, last = performance.now(), started = false, destroyed = false;

  const yard = new Yard(canvas, {
    bank, scene: 'battle', biome: P.look, seed: 11, yardSize: 0, resolveTexture, res: 576,
    overlay: (ctx) => frame(ctx),
  });
  yard.inputLocked = true;
  yard.openFloor = true;
  // outdoors, the real sky where you are (Settings: battles follow the real weather and time); indoors, as built
  const indoor = ['stadium', 'synth', 'cavern', 'crystal', 'seafloor', 'starfield'].includes(P.look);
  const ambientWx = !indoor && ambient?.weather ? ambient.weather : 'clear';
  yard.setTime(indoor ? (P.look === 'stadium' || P.look === 'synth' ? 'dusk' : 'day') : ambient?.tod ?? 'day');
  yard.setWeather(ambientWx);
  yard.sunless = indoor && P.look !== 'stadium'; // (domes and caves: lamps and moves light it, no sky)
  yard.setCreatures([]);

  // ---------- the camera: a director cutting between shots, like Battle Revolution ----------
  // Every shot is worked out from where the two creatures stand (and how big they are) when it starts:
  //   main      behind your creature, a little to the side, both in view (where it rests between moves)
  //   front(s)  a close-up of one of them from the front, a touch below eye level
  //   hero(s)   a low shot looking up at one of them
  //   shoulder(s) over one's shoulder towards the other
  //   behindFoe from behind the wild one, looking at yours
  //   side      side-on to the whole field (things flying across it)
  //   overhead  from high above
  //   wide      zoomed right out, the whole place in view
  const V = (x, y, z) => ({ x, y, z });
  const pos = (side) => { const a = actor(side); const [x, z] = spot(side); return a ? { x: a.x, z: a.z } : { x, z }; };
  const tall = (side) => { const a = actor(side); return a ? Math.max(0.4, yard.heightOf(a)) : 1; };
  const axis = () => { const n = pos(0), f = pos(1); const dx = f.x - n.x, dz = f.z - n.z, l = Math.hypot(dx, dz) || 1; return { n, f, u: { x: dx / l, z: dz / l }, p: { x: dz / l, z: -dx / l }, len: l }; };
  const SHOT = {
    main() { const { n, f, u, p } = axis(); return { eye: V(n.x - u.x * 3.9 + p.x * 2.1, 2.3 + tall(0) * 0.4, n.z - u.z * 3.9 + p.z * 2.1), at: V(lerp(n.x, f.x, 0.6), 0.55, lerp(n.z, f.z, 0.6)) }; },
    front(side, wide = 1) {
      const { n, f, u, p } = axis(), me = side === 0 ? n : f, dir = side === 0 ? 1 : -1, hgt = tall(side), d = (1.5 + hgt * 1.5) * wide, off = side === 0 ? 0.55 : -0.45;
      return { eye: V(me.x + u.x * dir * d + p.x * off * d, hgt * 0.55 + 0.2, me.z + u.z * dir * d + p.z * off * d), at: V(me.x, hgt * 0.55, me.z) };
    },
    hero(side) { const { n, f, u, p } = axis(), me = side === 0 ? n : f, dir = side === 0 ? 1 : -1, hgt = tall(side), d = 1.1 + hgt * 1.25;
      return { eye: V(me.x + u.x * dir * d - p.x * dir * 0.6 * d, 0.22, me.z + u.z * dir * d - p.z * dir * 0.6 * d), at: V(me.x, hgt * 0.75, me.z) }; },
    shoulder(side) { const { n, f, u, p } = axis(), me = side === 0 ? n : f, other = side === 0 ? f : n, dir = side === 0 ? 1 : -1, hgt = tall(side), d = 1.4 + hgt * 0.8;
      return { eye: V(me.x - u.x * dir * d + p.x * dir * 1.0, hgt * 1.05 + 0.35, me.z - u.z * dir * d + p.z * dir * 1.0), at: V(lerp(me.x, other.x, 0.7), 0.6, lerp(me.z, other.z, 0.7)) }; },
    behindFoe() { const { n, f, u, p } = axis(); return { eye: V(f.x + u.x * 4.6 - p.x * 1.8, 2.2 + tall(1) * 0.4, f.z + u.z * 4.6 - p.z * 1.8), at: V(lerp(f.x, n.x, 0.62), 0.7, lerp(f.z, n.z, 0.62)) }; },
    side(k = 1) { const { n, f, p } = axis(), mx = (n.x + f.x) / 2, mz = (n.z + f.z) / 2; return { eye: V(mx + p.x * 7.5 * k, 1.5, mz + p.z * 7.5 * k), at: V(mx, 0.8, mz) }; },
    overhead() { const { n, f, u, p } = axis(), mx = (n.x + f.x) / 2, mz = (n.z + f.z) / 2; const cx2 = lerp(n.x, f.x, 0.4), cz2 = lerp(n.z, f.z, 0.4); return { eye: V(cx2 - u.x * 2.4 + p.x * 1.2, 11.5, cz2 - u.z * 2.4 + p.z * 1.2), at: V(cx2, 0, cz2) }; },
    wide() { const { n, f, u, p } = axis(), mx = (n.x + f.x) / 2, mz = (n.z + f.z) / 2; return { eye: V(mx - u.x * 19 + p.x * 9, 13.5, mz - u.z * 19 + p.z * 9), at: V(mx, 0.6, mz) }; },
    wideBack() { const { n, f, u, p } = axis(), mx = (n.x + f.x) / 2, mz = (n.z + f.z) / 2; return { eye: V(mx + u.x * 18 - p.x * 10, 13, mz + u.z * 18 - p.z * 10), at: V(mx, 0.6, mz) }; },
  };
  // from any angle round a creature (ang 0: straight in front; ±: round to either side), d away, at a height
  SHOT.around = (side, ang = 0, d = 1, hgt = 0.5) => { const { u, p } = axis(), me = pos(side), dir = side === 0 ? 1 : -1, t0 = tall(side), r = (1.6 + t0 * 1.5) * d;
    const fx0 = u.x * dir, fz0 = u.z * dir, c = Math.cos(ang), s0 = Math.sin(ang);
    return { eye: V(me.x + (fx0 * c + p.x * s0) * r, t0 * hgt + 0.15, me.z + (fz0 * c + p.z * s0) * r), at: V(me.x, t0 * 0.55, me.z) }; };
  if (practice) { // circling slowly round it, in the middle of the targets
    SHOT.main = () => { const a0 = time * 0.16, [cx, cz] = [0, FIELD_Z], r = 7.6; return { eye: V(cx + Math.cos(a0) * r, 3.3, cz + Math.sin(a0) * r), at: V(cx, 0.7, cz) }; };
  }
  // where each side's trainer stands: behind their creature and off to one side (the wild one has none)
  // (from the creatures' starting spots, so a trainer stays put while their creature runs about)
  const homeAxis = () => { const [nx, nz] = spot(0), [fx, fz] = spot(1), n = { x: nx, z: nz }, f = { x: fx, z: fz }, dx = f.x - n.x, dz = f.z - n.z, l = Math.hypot(dx, dz) || 1; return { n, f, u: { x: dx / l, z: dz / l }, p: { x: dz / l, z: -dx / l }, len: l }; };
  const trainerAt = (side) => { const { n, f, u, p } = homeAxis(), me = side === 0 ? n : f, dir = side === 0 ? 1 : -1; return { x: me.x - u.x * dir * 2.4 - p.x * dir * 1.8, z: me.z - u.z * dir * 2.4 - p.z * dir * 1.8 }; };
  // a trainer and their creature together, from the front
  SHOT.team = (side) => { const { u, p } = axis(), me = pos(side), t = trainerAt(side), dir = side === 0 ? 1 : -1, mx = (me.x + t.x) / 2, mz = (me.z + t.z) / 2, d = 5.2 + tall(side) * 0.8;
    return { eye: V(mx + u.x * dir * d - p.x * dir * 0.8, 1.35 + tall(side) * 0.2, mz + u.z * dir * d - p.z * dir * 0.8), at: V(mx, 0.85, mz) }; };
  // riding along: just behind and above a moving point, looking where it's going (a projectile in flight)
  const rideBehind = (pt, from, to, { back = 1.5, up = 0.5, side = 0.45, ahead = 2.2 } = {}) => {
    const a = chest(from), b = chest(to), dx = b.x - a.x, dz = b.z - a.z, l = Math.hypot(dx, dz) || 1, ux = dx / l, uz = dz / l, px = uz, pz = -ux, sg = from === 0 ? 1 : -1;
    return { eye: V(pt.x - ux * back + px * side * sg, pt.y + up, pt.z - uz * back + pz * side * sg), at: V(pt.x + ux * ahead, lerp(pt.y, b.y, 0.6), pt.z + uz * ahead) };
  };
  // alongside a creature on the move, low and a little ahead, keeping the target in the frame (Quick Attack's zig-zag)
  const runAlong = (side, to) => {
    const a = actor(side); if (!a) return null;
    const me = { x: a.x, y: (a.y || 0) + tall(side) * 0.5, z: a.z }, b = chest(to), dx = b.x - me.x, dz = b.z - me.z, l = Math.hypot(dx, dz) || 1, ux = dx / l, uz = dz / l, sg = side === 0 ? 1 : -1;
    const mx = lerp(me.x, b.x, 0.35), mz = lerp(me.z, b.z, 0.35), D = 4.4 + tall(side) * 1.6; // side-on to the run, far enough to keep both in view
    return { eye: V(mx + uz * D * sg - ux * 1.2, 0.9 + tall(side) * 0.3, mz - ux * D * sg - uz * 1.2), at: V(mx, Math.max(0.5, me.y * 0.8), mz) };
  };
  try { window.__bstShots = SHOT; } catch { /* no window */ }
  const cam = { eye: V(-6, 8, -9), at: V(0, 0.6, 5) };
  let cur = null, idleFor = 0, idleN = 0;
  const shots = [];
  // a shot: make() → { eye, at }; dur = time to glide there (0 = a cut); hold = time on it; drift = a slow slide
  // sideways (units/s); track() → a point to keep looking at (a move flying across)
  // follow() → { eye, at } each frame: a moving camera riding along with something (a projectile, a dash)
  const queueShot = (make, { dur = 0, hold = 1, drift = 0.25, track = null, follow = null, home: isHome = false } = {}) => { shots.push({ make, dur, hold, drift, track, follow, isHome }); };
  const cutTo = (make, opts) => { shots.length = 0; cur = null; queueShot(make, opts); idleFor = 0; };
  const home = (dur = 1.2) => queueShot(SHOT.main, { dur, hold: 0, drift: 0, home: true, ...(practice ? { follow: () => SHOT.main() } : {}) });
  try { window.__bstCut = (name, ...args) => { cutTo(() => SHOT[name](...args), { hold: 1e6, drift: 0 }); }; } catch { /* no window */ }
  const copy = (v) => ({ x: v.x, y: v.y, z: v.z });
  const mix = (a, b, k) => V(lerp(a.x, b.x, k), lerp(a.y, b.y, k), lerp(a.z, b.z, k));
  function stepCamera(dt) {
    if (!dynamic) { shots.length = 0; cur = null; const m = SHOT.main(); cam.eye = m.eye; cam.at = m.at; }
    if (!cur && shots.length) {
      const n = shots.shift();
      let to; try { to = n.make(); } catch { to = SHOT.main(); }
      const dx = to.at.x - to.eye.x, dz = to.at.z - to.eye.z, l = Math.hypot(dx, dz) || 1;
      cur = { ...n, to, from: { eye: copy(cam.eye), at: copy(cam.at) }, t: 0, side: { x: dz / l, z: -dx / l }, sgn: Math.random() < 0.5 ? -1 : 1 };
      // a glide only between nearby shots: anything else is a cut (gliding from in front of a creature to
      // behind it would pass right through it)
      if (n.dur && Math.hypot(to.eye.x - cam.eye.x, to.eye.y - cam.eye.y, to.eye.z - cam.eye.z) > 5.5) cur.dur = 0;
      if (!cur.dur) { cam.eye = copy(to.eye); cam.at = copy(to.at); }
    }
    if (cur) {
      cur.t += dt;
      const k = cur.dur ? ease(cur.t / cur.dur) : 1, sl = cur.drift * cur.t * cur.sgn;
      const eye = mix(cur.from.eye, cur.to.eye, k), at = mix(cur.from.at, cur.to.at, k);
      eye.x += cur.side.x * sl; eye.z += cur.side.z * sl;
      if (cur.track) { const tp = cur.track(); if (tp) { cur.look = cur.look ? mix(cur.look, tp, Math.min(1, dt * 9)) : tp; at.x = lerp(at.x, cur.look.x, 0.85); at.y = lerp(at.y, cur.look.y, 0.85); at.z = lerp(at.z, cur.look.z, 0.85); } }
      cam.eye = eye; cam.at = at;
      if (cur.follow) { let f = null; try { f = cur.follow(); } catch { f = null; } if (f) { cur.fEye = cur.fEye ? mix(cur.fEye, f.eye, Math.min(1, dt * 7)) : f.eye; cur.fAt = cur.fAt ? mix(cur.fAt, f.at, Math.min(1, dt * 9)) : f.at; } if (cur.fEye) { cam.eye = copy(cur.fEye); cam.at = copy(cur.fAt); } }
      if (cur.t >= cur.dur + cur.hold && (!cur.isHome || shots.length)) cur = null;
      else if (cur.isHome && cur.t >= cur.dur) { // resting on the main shot: re-aim as they move, breathe a little
        const m = SHOT.main(); cam.eye = m.eye; cam.at = m.at;
      }
    }
    // between moves (choosing what to do), the director wanders through other shots now and then
    const resting = !cur || (cur.isHome && cur.t >= cur.dur);
    if (dynamic && started && resting) {
      idleFor += dt;
      if (idleFor > 6.5) {
        idleFor = 0;
        const pick = [() => cutTo(() => SHOT.front(1), { hold: 3.2, drift: 0.22 }), () => cutTo(() => SHOT.front(0), { hold: 3.2, drift: 0.22 }), () => cutTo(SHOT.behindFoe, { hold: 3.4, drift: 0.35 }),
          () => cutTo(SHOT.wide, { hold: 4, drift: 0.9 }), () => cutTo(SHOT.overhead, { hold: 3, drift: 0.5 }), () => cutTo(() => SHOT.hero(1), { hold: 2.8, drift: 0.2 }), () => cutTo(() => SHOT.side(idleN % 2 ? 1 : -1), { hold: 3.2, drift: 0.5 })][idleN++ % 7];
        pick(); home(0);
      }
    } else idleFor = 0;
    const br = resting ? 1 : 0.25; // a gentle handheld breathing
    const e = { x: cam.eye.x + Math.sin(time * 0.37) * 0.08 * br + (Math.random() - 0.5) * shake * 0.22, y: cam.eye.y + Math.sin(time * 0.29) * 0.05 * br + (Math.random() - 0.5) * shake * 0.12, z: cam.eye.z };
    // aimed a touch low, so what the shot is about sits above the text box
    const aimDrop = Math.hypot(cam.at.x - cam.eye.x, cam.at.y - cam.eye.y, cam.at.z - cam.eye.z) * 0.085;
    const a = { x: cam.at.x + (Math.random() - 0.5) * shake * 0.12, y: cam.at.y - aimDrop, z: cam.at.z };
    yard.lookFrom(e, a);
    placeTrainers(e);
    shake = Math.max(0, shake - dt * 2.2);
    // which way round each creature is seen: its back when the camera is behind it, its front otherwise, and
    // turned to face the other on screen
    for (const side of [0, 1]) {
      const me = actor(side), other = actor(1 - side); if (!me) continue;
      const o = other ? { x: other.x, z: other.z } : (() => { const [x, z] = spot(1 - side); return { x, z }; })();
      const fx2 = o.x - me.x, fz2 = o.z - me.z;
      me.battleBack = (e.x - me.x) * fx2 + (e.z - me.z) * fz2 < 0;
      const q0 = yard.project(me.x, 0.5, me.z), q1 = yard.project(o.x, 0.5, o.z);
      if (me.battleFaceLock) me.battleFace = me.battleFaceLock;
      else if (q0 && q1 && Math.abs(q1.x - q0.x) > (me.battleFace ? 26 : 2)) me.battleFace = q1.x > q0.x ? 'right' : 'left'; // (only turns round once clearly past: no flickering while right up close)
      else if (q0 && !q1) { const q2 = yard.project(me.x + fx2 * 0.05, 0.5, me.z + fz2 * 0.05); if (q2) me.battleFace = q2.x > q0.x ? 'right' : 'left'; }
    }
  }
  // ---------- the trainers: their pictures standing behind their creatures ----------
  const trainerPics = {};
  for (const [side, url] of [[0, trainers.mine], [1, trainers.foe]]) {
    if (!url) continue;
    const img = new Image(); img.decoding = 'async';
    img.onload = () => { trainerPics[side] = img; };
    img.src = url;
  }
  yard.extras = [0, 1].map((side) => ({
    x: 0, z: 0, side,
    draw(ctx, q) {
      const img = trainerPics[side]; if (!img || this.hide || !q) return;
      // only from in front of them (from behind they'd be a flat cut-out, and they'd block the view)
      const H = 2.0 * q.k, W = (img.width / img.height) * H;
      if (H > yard.H * 1.6) return;
      ctx.save(); ctx.imageSmoothingEnabled = false; ctx.globalAlpha = this.alpha ?? 1;
      ctx.fillStyle = 'rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(q.x, q.y, W * 0.28, W * 0.08, 0, 0, Math.PI * 2); ctx.fill();
      if (this.flip) { ctx.translate(q.x, 0); ctx.scale(-1, 1); ctx.drawImage(img, Math.round(-W / 2), Math.round(q.y - H * 0.96), Math.round(W), Math.round(H)); }
      else ctx.drawImage(img, Math.round(q.x - W / 2), Math.round(q.y - H * 0.96), Math.round(W), Math.round(H));
      ctx.restore();
    },
  }));
  function placeTrainers(e) {
    const { u } = homeAxis();
    for (const t of yard.extras) {
      if (!trainerPics[t.side]) { t.hide = true; continue; }
      const p = trainerAt(t.side), dir = t.side === 0 ? 1 : -1;
      t.x = p.x; t.z = p.z;
      t.hide = (e.x - p.x) * u.x * dir + (e.z - p.z) * u.z * dir < 0.4 || Math.hypot(e.x - p.x, e.z - p.z) < 1.4;
      // turned to face the middle of the field on screen
      const q0 = yard.project(p.x, 1, p.z), q1 = yard.project(p.x + u.x * dir, 1, p.z + u.z * dir);
      if (q0 && q1) t.flip = q1.x > q0.x;
    }
  }

  // Showdown speed → how long our shots take (and the stage asks Showdown to wait for them)
  const tempo = () => { let sp = 'normal'; try { sp = localStorage.getItem('clSdSpeed') || 'normal'; } catch { /* default */ } return { slow: 2.1, normal: 1.6, fast: 0.9, hyperfast: 0.55 }[sp] ?? 1.6; };
  const PACE = { runMoveAnim: 1500, runPrepareAnim: 1000, damageAnim: 650, animFaint: 1500, animSummon: 1000, animDragIn: 1000, animUnsummon: 900, healAnim: 450, runStatusAnim: 500, runOtherAnim: 300, resultAnim: 120 };

  // ---------- creatures ----------
  const actor = (side) => yard.actors.get(uidOf(side));
  const chest = (side, k = 0.5) => { const a = actor(side); if (!a) { const [x, z] = spot(side); return { x, y: 0.6, z }; } return { x: a.x, y: (a.y || 0) + yard.heightOf(a) * k, z: a.z }; };
  function placeMon(side, info) {
    const c = creatureFor(info);
    if (!c) return null;
    const spec = { ...actorFor(idx, c), uid: uidOf(side), name: '', clothes: side === 0 ? actorFor(idx, c).clothes : [] };
    // how it gets about (it shows in how it moves when it attacks, and how it idles): flying, hovering, swimming or walking
    lastPct[side] = info?.pct ?? 1;
    gaitOf[side] = spec.hover ? 'hover' : spec.fly ? 'fly' : spec.waterOnly || spec.prefersWater ? 'swim' : 'walk';
    profiles[side] = null; posing[side] = 0; try { clearStatNotes(side); } catch { /* not set up yet */ }
    // its sprite stands on the ground (idle motion lifts fliers a little; on the seafloor, swimmers still swim)
    spec.fly = false; spec.hover = false; spec.canFly = false;
    const ownLook = spec.speciesId;
    spec.speciesId = lookFor(info, spec.speciesId);
    specs[side] = spec;
    yard.setCreatures(Object.values(specs));
    const a = actor(side);
    if (!a) return null;
    yard.puppet(a.uid);
    const [x, z] = spot(side);
    Object.assign(a, { x, z, tx: x, tz: z, appear: 1, battleBack: side === 0, battleFace: side === 0 ? 'right' : 'left', alpha: 1, hitFlash: 0, jitter: 0 });
    // battle size: everyone shown big enough to read, but big creatures still bigger than small ones
    a.sizeMul = specs[side].sizeMul ?? 1;
    const h0 = Math.max(0.05, yard.heightOf(a));
    a.baseSize = a.sizeMul * Math.max(1.15, Math.min(3.6, Math.pow((side === 0 ? 1.95 : 1.5) / h0, 0.72)));
    a.sizeMul = a.baseSize;
    specs[side].sizeMul = a.baseSize; // so later changes to the other side don't undo it
    mons[side] = { info, c, ownLook };
    return a;
  }
  // The picture for the form it's in right now. The data set's own species when it has that form; else
  // Showdown's picture of the form (Castform's weather forms, Megas, Aegislash's Blade Forme, Mimikyu's
  // busted face, Transform…), and its usual picture until that loads (or if it can't).
  const sdId = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');
  const sdSprite = (name) => { const s = String(name ?? ''), cut = s.indexOf('-'); return cut > 0 ? `${sdId(s.slice(0, cut))}-${sdId(s.slice(cut + 1))}` : sdId(s); };
  function lookFor(info, own) {
    const want = info.sprite || info.species, shiny = info.shiny ? ':shiny' : '';
    const ownBase = String(own ?? '').split(':')[0];
    // its own look when it's in its usual form
    const ownSp = idx?.species?.get?.(ownBase);
    if (!want || [ownSp?.showdownName, ownSp?.name].some((n) => n && sdId(n) === sdId(want))) return own;
    const sid = speciesFor?.(want);
    if (sid) return sid === ownBase ? own : `${sid}${shiny}`;
    // the data set doesn't know this form: is it a different look from the creature's own at all?
    if (info.species && sdId(info.species) === sdId(want)) return own;
    const sd = sdSprite(want), key = `sdform~${sd}${info.shiny ? '~shiny' : ''}`;
    const dir = info.shiny ? 'gen5-shiny' : 'gen5', bdir = info.shiny ? 'gen5-back-shiny' : 'gen5-back';
    bank.remote(key, {
      front: [resolveTexture?.(`creatures/${sd}${info.shiny ? '-shiny' : ''}.png`), `https://play.pokemonshowdown.com/sprites/${dir}/${sd}.png`, `https://play.pokemonshowdown.com/sprites/dex/${sd}.png`].filter(Boolean),
      back: [resolveTexture?.(`creatures/${sd}${info.shiny ? '-shiny' : ''}-back.png`), `https://play.pokemonshowdown.com/sprites/${bdir}/${sd}.png`].filter(Boolean),
      fallback: own,
    });
    return key;
  }
  // a form change in the middle of a battle: same creature, same size and place, new look
  function changeLook(side, info) {
    const sp = specs[side], a = actor(side);
    if (!sp || !a) return false;
    const next = lookFor(info, mons[side]?.ownLook ?? sp.speciesId);
    if (next === sp.speciesId) return false;
    sp.speciesId = next;
    yard.setCreatures(Object.values(specs));
    const a2 = actor(side); if (a2) { a2.speciesId = next; a2.sizeMul = sp.sizeMul; }
    return true;
  }
  function remove(side) { delete specs[side]; mons[side] = null; yard.setCreatures(Object.values(specs)); }

  // ---------- particles and effects ----------
  let flying = null; // whatever a move has sent across the field right now (the camera follows it)
  const project = (p) => yard.project(p.x, p.y, p.z);
  // a budget: when frames run slow (or there are already a great many), fewer new particles are made
  let frameMs = 16, lowFx = false;
  function particle(p) {
    if (parts.length > 900 || (lowFx && Math.random() < 0.45) || (parts.length > 600 && Math.random() < 0.5)) return;
    parts.push({ vx: 0, vy: 0, vz: 0, g: 0, size: 0.12, shape: 'dot', spin: 0, rot: Math.random() * 6, ...p, max: p.life, lit: p.lit ?? emitting }); }
  // ---------- light from moves ----------
  // A move that gives off light (fire, lightning, psychic power, beams, most special attacks…) lights the place
  // as it goes: its particles are a moving light (up to three, along its path), and each hit flashes.
  let emitting = null;
  const flashes = []; // { x, y, z, r, c, i, t, life }
  const rgbOf = (hexCol) => { const v = String(hexCol).replace('#', ''); const n = parseInt(v, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
  const LIGHT_TYPES = new Set(['Fire', 'Electric', 'Psychic', 'Fairy']), DIM_TYPES = new Set(['Dragon', 'Ghost', 'Stellar']);
  const LK = dramatic ? 1.75 : 1; // dramatic lighting: every light from a move stronger and wider
  function moveLight(m) {
    const L = lookOf(m.type), name = String(m.name).toLowerCase();
    const beam = /beam|ray|blast|cannon|flash|laser|pulse|nova|burst|glare|light|zap|bolt|thunder|flame|fire|ember|heat|inferno|spark|charge|aura|moon|dazzling|prism|photon|solar/.test(name);
    const special = m.cat === 'Special' && m.bp > 0;
    if (!LIGHT_TYPES.has(m.type) && !beam && !(DIM_TYPES.has(m.type) && m.bp >= 60) && !(special && m.bp >= 100) && !(m.bp >= 130)) return null;
    if (m.cat === 'Status' && !beam && !['Fire', 'Electric', 'Psychic', 'Fairy'].includes(m.type)) return null;
    const c = m.type === 'Normal' && (m.recharge || m.bp >= 120) ? [255, 190, 90] : m.type === 'Dark' ? [150, 110, 220] : rgbOf(L.col);
    const k = Math.min(2.2, (m.cat === 'Status' ? 0.6 : 0.8) + m.bp / 110 + (LIGHT_TYPES.has(m.type) ? 0.3 : 0) + (beam ? 0.25 : 0));
    return { c, k };
  }
  function lightFlash(at, c, { r = 5, i = 1.4, life = 0.35 } = {}) { flashes.push({ x: at.x, y: at.y, z: at.z, r: r * (dramatic ? 1.3 : 1), c, i: i * LK, t: 0, life, dyn: true }); }
  // this frame's lights for the yard: the moving lights of moves in flight, the flashes, burning creatures
  function stageLights(dt) {
    const out = [];
    for (let i = flashes.length - 1; i >= 0; i--) { const f = flashes[i]; f.t += dt; if (f.t >= f.life) { flashes.splice(i, 1); continue; } const k = 1 - f.t / f.life; out.push({ x: f.x, y: f.y, z: f.z, r: f.r * (0.7 + 0.3 * k), c: f.c, i: f.i * k * k, dyn: true }); }
    // particles of a lit move, gathered into up to three lights along the field (near side, middle, far side)
    const bins = new Map();
    const n0 = pos(0), n1 = pos(1), ax = n1.x - n0.x, az = n1.z - n0.z, al = ax * ax + az * az || 1;
    for (const p of parts) {
      if (!p.lit) continue;
      const t = Math.max(0, Math.min(0.999, ((p.x - n0.x) * ax + (p.z - n0.z) * az) / al)), key = Math.floor(t * 3);
      let b = bins.get(p.lit); if (!b) { b = [null, null, null]; bins.set(p.lit, b); }
      const e = b[key] ?? (b[key] = { x: 0, y: 0, z: 0, n: 0 });
      const w = Math.max(0.2, p.life / (p.max || 1));
      e.x += p.x * w; e.y += p.y * w; e.z += p.z * w; e.n += w;
    }
    for (const [lit, b] of bins) for (const e of b) {
      if (!e || e.n < 1.5) continue;
      out.push({ x: e.x / e.n, y: Math.max(0.2, e.y / e.n), z: e.z / e.n, r: (3 + Math.min(4, e.n * 0.12) * (0.6 + lit.k * 0.3)) * (dramatic ? 1.3 : 1), c: lit.c, i: lit.k * LK * Math.min(1, e.n / 10) * (0.85 + Math.random() * 0.15), dyn: true });
    }
    // the place's own lights after dark: fireflies in the fields and woods, floodlights over the stadium and the
    // colosseum (torches there too), lanterns at the shrine, the glow of lava, crystals and neon
    for (const l of nightLights()) out.push(l);
    // burning creatures flicker warm
    for (const side of [0, 1]) if (statusOf[side] === 'brn' && actor(side) && !vanished[side]) { const c = chest(side); out.push({ x: c.x, y: c.y, z: c.z, r: 2.4, c: [255, 120, 40], i: 0.45 + 0.2 * Math.sin(time * 9 + side), dyn: true }); }
    return out;
  }
  const isNight = () => (yard.light ?? 'day') === 'night' || (yard.light ?? 'day') === 'dusk';
  const flies = Array.from({ length: 14 }, (_, i) => ({ a: Math.random() * 6.3, r: 2 + Math.random() * 7, h: 0.5 + Math.random() * 1.6, sp: 0.15 + Math.random() * 0.3, ph: Math.random() * 6, i }));
  const FLY_LOOKS = ['meadow', 'forest', 'skyline', 'spooky']; // (nature only: meadow, forest, mountaintop, haunted woods)
  const flyAt = (f) => ({ x: Math.cos(f.a + time * f.sp) * f.r, y: f.h + Math.sin(time * 1.3 + f.ph) * 0.3, z: FIELD_Z + Math.sin(f.a * 1.7 + time * f.sp * 0.8) * f.r * 0.7 });
  function nightLights() {
    const out = [], night = isNight(), lk = dramatic ? 1.5 : 1;
    if (crowdy) { // floodlights: always on in the bowl, strong after dark
      const R = 9, i0 = (night ? 0.55 : 0.18) * lk;
      for (let j = 0; j < 4; j++) { const an = (j / 4) * Math.PI * 2 + 0.8; out.push({ x: Math.cos(an) * R, y: 6, z: FIELD_Z + Math.sin(an) * R * 0.8, r: 13, c: [255, 250, 235], i: i0 * (1 + hypeLvl * 0.25), dyn: true }); }
      if (P.look === 'colosseum' && night) for (let j = 0; j < 4; j++) { const an = (j / 4) * Math.PI * 2; out.push({ x: Math.cos(an) * 7, y: 2, z: FIELD_Z + Math.sin(an) * 6, r: 5, c: [255, 150, 60], i: (0.5 + 0.15 * Math.sin(time * 11 + j * 2)) * lk, dyn: true }); }
    }
    if (!night) return out;
    if (FLY_LOOKS.includes(P.look) && !indoor && !weatherNow) for (let j = 0; j < (lowFx ? 2 : 4); j++) { const q = flyAt(flies[j]); out.push({ x: q.x, y: q.y, z: q.z, r: 2.6, c: [200, 255, 120], i: (0.35 + 0.25 * Math.sin(time * 2.2 + flies[j].ph)) * lk, dyn: true }); }
    if (P.look === 'volcano') out.push({ x: 0, y: 0.3, z: FIELD_Z, r: 12, c: [255, 110, 40], i: (0.3 + 0.08 * Math.sin(time * 1.7)) * lk, dyn: true });
    if (P.look === 'shrine') for (const sx of [-4, 4]) out.push({ x: sx, y: 1.6, z: FIELD_Z, r: 5, c: [255, 190, 110], i: (0.5 + 0.08 * Math.sin(time * 7 + sx)) * lk, dyn: true });
    if (P.look === 'synth' || P.look === 'prism' || P.look === 'crystal') out.push({ x: Math.sin(time * 0.5) * 4, y: 2, z: FIELD_Z, r: 9, c: P.look === 'synth' ? [255, 80, 220] : P.look === 'prism' ? [150, 220, 255] : [150, 255, 230], i: 0.35 * lk, dyn: true });
    return out;
  }
  // (drawn over the scene: the fireflies themselves, the floodlights' glare, light smeared on wet or polished ground)
  function drawNightGlow(ctx) {
    const W = canvas.width, H = canvas.height, night = isNight();
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    if (night && FLY_LOOKS.includes(P.look) && !indoor && !weatherNow) for (const f of flies) { const q = project(flyAt(f)); if (!q) continue; const tw = 0.5 + 0.5 * Math.sin(time * 2.2 + f.ph); if (tw < 0.15) continue; ctx.globalAlpha = tw; const r = Math.max(2, q.k * 0.16); ctx.drawImage(softSprite('firefly', [[0, 'rgba(240,255,170,1)'], [0.3, 'rgba(190,255,90,.6)'], [1, 'rgba(160,255,60,0)']]), q.x - r, q.y - r, r * 2, r * 2); }
    if (crowdy && (night || dramatic)) for (let j = 0; j < 4; j++) { const an = (j / 4) * Math.PI * 2 + 0.8, q = project({ x: Math.cos(an) * 20, y: 12, z: FIELD_Z + Math.sin(an) * 17 }); if (!q) continue; const r = Math.max(10, q.k * 2.6) * (1 + hypeLvl * 0.15); ctx.globalAlpha = night ? 0.85 : 0.35; ctx.drawImage(softSprite('flood', [[0, 'rgba(255,255,245,1)'], [0.15, 'rgba(255,250,225,.6)'], [1, 'rgba(255,245,210,0)']]), q.x - r, q.y - r, r * 2, r * 2);
      if (dramatic && !lowFx) { const g0 = project({ x: 0, y: 0, z: FIELD_Z }); if (g0) { const gr = ctx.createLinearGradient(q.x, q.y, g0.x, g0.y); gr.addColorStop(0, 'rgba(255,250,225,.16)'); gr.addColorStop(1, 'rgba(255,250,225,0)'); ctx.globalAlpha = night ? 1 : 0.4; ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(q.x, q.y); ctx.lineTo(g0.x - W * 0.16, g0.y); ctx.lineTo(g0.x + W * 0.16, g0.y); ctx.closePath(); ctx.fill(); } } }
    // wet or polished ground throws every light back as a long smear beneath it
    if (yard.reflect > 0 && (dramatic || yard.reflectWater) && !lowFx) for (const l of yard.dynLights ?? []) { if (!(l.i > 0.25) || l.y < 0.05) continue; const g0 = project({ x: l.x, y: 0.02, z: l.z }); if (!g0) continue; const rw = Math.max(6, g0.k * (l.r ?? 3) * 0.16), rh = rw * 3.2; ctx.globalAlpha = Math.min(0.5, l.i * 0.28 * (yard.reflect * 2.4)); const c = l.c ?? [255, 255, 255]; const gr = ctx.createRadialGradient(g0.x, g0.y, 0, g0.x, g0.y, rh); gr.addColorStop(0, `rgba(${c[0]},${c[1]},${c[2]},.9)`); gr.addColorStop(1, `rgba(${c[0]},${c[1]},${c[2]},0)`); ctx.fillStyle = gr; ctx.save(); ctx.translate(g0.x, g0.y); ctx.scale(rw / rh, 1); ctx.beginPath(); ctx.arc(0, rh * 0.35, rh, 0, Math.PI * 2); ctx.fill(); ctx.restore(); }
    ctx.restore();
  }
  function burst(at, col, n = 14, { speed = 2.4, size = 0.13, shape = 'shard', up = 0.6, g = -3 } = {}) {
    for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, s = rnd(0.4, 1) * speed; particle({ x: at.x, y: at.y, z: at.z, vx: Math.cos(a) * s, vy: rnd(-0.3, 1) * s * up + 0.6, vz: Math.sin(a) * s * 0.6, g, life: rnd(0.35, 0.7), size, col: i % 4 ? col : '#ffffff', shape, spin: rnd(-8, 8) }); }
  }
  function ring(at, col, { r0 = 0.2, r1 = 1.6, life = 0.6, flat = false, w = 4 } = {}) {
    fx.push({ t: 0, life, draw(ctx) {
      const k = this.t / this.life, q = project(at); if (!q) return;
      const r = lerp(r0, r1, ease(k)) * q.k;
      ctx.strokeStyle = col; ctx.globalAlpha = 1 - k; ctx.lineWidth = Math.max(1, w * (1 - k * 0.5));
      ctx.beginPath(); ctx.ellipse(q.x, q.y, r, flat ? r * 0.3 : r, 0, 0, Math.PI * 2); ctx.stroke(); ctx.globalAlpha = 1;
    } });
  }
  function hitFlash(side, n = 3) { const a = actor(side); if (!a) return; fx.push({ t: 0, life: n === 1 ? 0.14 : 0.5, update() { const a2 = actor(side); if (!a2) return; a2.hitFlash = Math.floor(this.t * n * 2 / this.life) % 2 === 0 ? 1 : 0; a2.jitter = Math.sin(this.t * 60) * 4 * (1 - this.t / this.life); }, end() { const a2 = actor(side); if (a2) { a2.hitFlash = 0; a2.jitter = 0; } } }); }
  function screenFlash(col = '#ffffff', dur = 220) { flash.style.background = col; flash.classList.remove('go'); void flash.offsetWidth; flash.classList.add('go'); flash.style.animationDuration = `${dur}ms`; }
  function lunge(side, target, { dur = 0.42, depth = 0.62 } = {}) {
    const a = actor(side); if (!a) return;
    const [x0, z0] = spot(side), tp = chest(target);
    fx.push({ t: 0, life: dur, update() { const a2 = actor(side); if (!a2) return; const k = this.t / this.life, m = k < 0.45 ? ease(k / 0.45) : 1 - ease((k - 0.45) / 0.55); a2.x = lerp(x0, tp.x, m * depth); a2.z = lerp(z0, tp.z, m * depth); a2.hop = k < 0.45 ? 0.6 : 0; }, end() { const a2 = actor(side); if (a2) { a2.x = x0; a2.z = z0; } } });
  }
  // a thing flying from one creature to the other: a glowing orb with a trail (or flames, drops, leaves…)
  // in front of a creature, towards the other one: where its moves come from (not out of the middle of its picture)
  function muzzle(side, to, k = 0.5) {
    const c = chest(side, k), b = chest(to), dx = b.x - c.x, dz = b.z - c.z, l = Math.hypot(dx, dz) || 1, r = 0.45 + tall(side) * 0.32, off = 0.18 + tall(side) * 0.12;
    return { x: c.x + (dx / l) * r + (dz / l) * off, y: c.y, z: c.z + (dz / l) * r - (dx / l) * off };
  }
  // how a move's projectile travels: arcing, straight on, lobbed high, erratic, corkscrewing or zig-zagging
  function pathFor(m) {
    const n = String(m?.name ?? '').toLowerCase(), t = m?.type;
    if (/seed|bullet|ball|bomb|sludge|mud|rock|stone|egg|shell/.test(n) && !/shadow|aura|energy|focus|weather|pyro|electro|zap/.test(n)) return 'lob';
    if (t === 'Electric') return 'zig';
    if (t === 'Ghost' || t === 'Dark' || t === 'Bug') return 'wobble';
    if (t === 'Dragon') return 'spiral';
    if (t === 'Psychic' || t === 'Fairy' || t === 'Ice' || t === 'Water' || t === 'Fighting' || t === 'Steel') return 'straight';
    let hsh = 0; for (const ch of n) hsh = (hsh * 31 + ch.charCodeAt(0)) >>> 0;
    return ['arc', 'straight', 'spiral', 'arc'][hsh % 4];
  }
  function projectile(from, to, type, { dur = 0.42, shape = null, size = 0.26, onHit, miss = false, img = null, path = 'arc', bend = 0, start = null, spread = 0 } = {}) {
    const col = TYPE_COL[type] ?? '#ffffff';
    const sh = shape ?? lookOf(type).shapes[0];
    const seed = Math.random() * 6;
    fx.push({ t: 0, life: dur, update(dt) {
      this.off = this.off ?? { x: rnd(-spread, spread), z: rnd(-spread * 0.6, spread * 0.6) };
      const raw = this.t / this.life, k = path === 'straight' || path === 'zig' ? raw : ease(raw), a = start ? (typeof start === 'function' ? start() : start) : muzzle(from, to), b0 = { ...chest(to), x: chest(to).x + this.off.x, z: chest(to).z + this.off.z };
      // a miss sails past, off to one side and on beyond
      const b = miss ? (() => { const { u, p, dir } = sideOf(from); return { x: b0.x + p.x * 1.6 + u.x * dir * 2.5, y: b0.y + 0.5, z: b0.z + p.z * 1.6 + u.z * dir * 2.5 }; })() : b0;
      const env = Math.sin(k * Math.PI), { p: pp } = sideOf(from);
      let side = 0, up = 0;
      if (bend) { side = bend * env; up = Math.abs(bend) * 0.35 * env; }
      if (path === 'arc') up = env * 0.5;
      else if (path === 'high') up = env * 3;
      else if (path === 'lob') up = env * 1.5;
      else if (path === 'wobble') { side = (Math.sin(k * Math.PI * 5 + seed) * 0.32 + Math.sin(k * Math.PI * 11 + seed * 2) * 0.12) * env; up = Math.sin(k * Math.PI * 7 + seed) * 0.22 * env; }
      else if (path === 'spiral') { side = Math.cos(k * Math.PI * 6) * 0.3 * env; up = Math.sin(k * Math.PI * 6) * 0.3 * env; }
      else if (path === 'zig') { const seg = k * 6, f = seg - Math.floor(seg); side = (Math.floor(seg) % 2 ? 1 : -1) * (0.5 - Math.abs(f - 0.5)) * 0.7 * env; up = env * 0.1; }
      const p = { x: lerp(a.x, b.x, k) + pp.x * side, y: lerp(a.y, b.y, k) + up, z: lerp(a.z, b.z, k) + pp.z * side };
      this.p = p; flying = p;
      if ((this.lt = (this.lt ?? 0) - 1) <= 0) { this.lt = 4; lightFlash(p, rgbOf(col), { r: 2.6 + size * 4, i: 0.7, life: 0.14 }); }
      for (let i = 0; i < 3; i++) particle({ x: p.x + rnd(-0.08, 0.08), y: p.y + rnd(-0.08, 0.08), z: p.z, vx: rnd(-0.3, 0.3), vy: rnd(-0.2, 0.4), life: rnd(0.2, 0.4), size: size * rnd(0.4, 0.8), col: Math.random() < 0.3 ? '#ffffff' : col, shape: sh, spin: rnd(-6, 6) });
      void dt;
    }, draw(ctx) { if (!this.p) return; const q = project(this.p); if (!q) return; glow(ctx, q.x, q.y, size * q.k, col);
      // Showdown's own effect picture for the move, when it's been downloaded
      const im = img && fxImage(resolveTexture, img); if (im) { const w = size * 3.2 * q.k; ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(this.t * 6); ctx.drawImage(im, -w / 2, -w / 2, w, w); ctx.restore(); } }, end() { flying = null; onHit?.(); } });
  }
  // several shots at once, told differently by move (see volleyFor): one after another; all at once, fanning out
  // and curving back in to land one after the other; first gathered in a ring round the user, then each one
  // knocked away at the target; or thrown up high to rain down on it
  function volleyFor(m) {
    const n = String(m.name).toLowerCase();
    if (/shuriken|dragon darts|spike cannon|triple|sparkling|scatter|population|stone axe/.test(n)) return 'fan';
    if (/icicle|scale shot|bone|surging|arrow|blade/.test(n)) return 'orbit';
    if (/seed|rock blast|bomb|egg|barrage|bullet/.test(n)) return 'rain';
    return ['sequence', 'fan', 'orbit', 'rain'][n.length % 4];
  }
  function volley(from, to, type, { n, style, travel, size, shape, img, miss, path, onHit, T }) {
    if (style === 'fan') {
      for (let i = 0; i < n; i++) { const b = n > 1 ? ((i / (n - 1)) * 2 - 1) * 1.6 : 0; setTimeout(() => projectile(from, to, type, { dur: travel * (1.05 + i * 0.2), size, shape, img, miss, path: 'straight', bend: b || 0.4, onHit: () => onHit(i + 1) }), i * 40); }
      return travel * (1.05 + (n - 1) * 0.2) + n * 0.04;
    }
    if (style === 'orbit') {
      const hold = Math.max(0.5, 0.55 * T), gap = Math.max(0.1, 0.13 * T), launched = new Array(n).fill(false);
      const spot = (i, t) => { const c = chest(from, 0.55), ang = t * 5 + (i / n) * Math.PI * 2, r = 0.55 + tall(from) * 0.35; return { x: c.x + Math.cos(ang) * r, y: c.y + Math.sin(ang * 0.5) * 0.25, z: c.z + Math.sin(ang) * r * 0.6 }; };
      const col = TYPE_COL[type] ?? '#ffffff';
      fx.push({ t: 0, life: hold + gap * n, draw(ctx) { for (let i = 0; i < n; i++) { if (launched[i]) continue; const q = project(spot(i, this.t)); if (q) glow(ctx, q.x, q.y, q.k * size * 0.9 * Math.min(1, this.t * 4), col); } } });
      // (each one knocked up out of the ring in turn, arcing over onto the target)
      for (let i = 0; i < n; i++) setTimeout(() => { launched[i] = true; const tLaunch = hold + gap * i; if (actor(from)) posefx(from, 0.16, (k) => ({ sy: 1 + Math.sin(k * Math.PI) * 0.07, lean: -awayDir(from) * 0.1 * Math.sin(k * Math.PI) })); burst(spot(i, tLaunch), TYPE_COL[type] ?? '#fff', 4, { speed: 1.2, shape: 'spark' }); projectile(from, to, type, { dur: travel * 0.8, size, shape, img, miss, path: 'lob', start: spot(i, tLaunch), onHit: () => onHit(i + 1) }); }, (hold + gap * i) * 1000);
      return hold + gap * n + travel * 0.85;
    }
    const gap = Math.max(0.16, 0.26 * T);
    for (let i = 0; i < n; i++) setTimeout(() => projectile(from, to, type, { dur: style === 'rain' ? travel * 1.3 : travel, size, shape, img, miss, path: style === 'rain' ? 'high' : (i % 2 ? 'straight' : path), spread: style === 'rain' ? 0.5 : 0, onHit: () => onHit(i + 1) }), i * gap * 1000);
    return (n - 1) * gap + travel * (style === 'rain' ? 1.3 : 1);
  }
  function beam(from, to, type, { dur = 0.6, onHit, width = 1 } = {}) {
    const col = TYPE_COL[type] ?? '#ffffff';
    const cT = Math.min(0.32, 0.12 + dur * 0.18); // a moment gathering it in front of the user before it fires
    let hit = false;
    fx.push({ t: 0, life: dur + cT, update() {
      const m0 = muzzle(from, to);
      if (this.t < cT) { for (let i = 0; i < 2; i++) { const ang = Math.random() * Math.PI * 2, r = 0.7 * width; particle({ x: m0.x + Math.cos(ang) * r, y: m0.y + Math.sin(ang) * r * 0.8, z: m0.z, vx: -Math.cos(ang) * r * 4, vy: -Math.sin(ang) * r * 3.2, life: 0.22, size: 0.07, col: i ? col : '#ffffff', shape: 'dot' }); } return; }
      if (!hit && this.t > cT + 0.18) { hit = true; onHit?.(); }
      const b = chest(to); for (let i = 0; i < 2; i++) particle({ x: b.x, y: b.y, z: b.z, vx: rnd(-1.5, 1.5), vy: rnd(-0.5, 1.5), vz: rnd(-1, 1), life: 0.3, size: 0.1, col, shape: 'spark' });
      particle({ ...m0, vx: rnd(-0.6, 0.6), vy: rnd(-0.4, 0.6), life: 0.2, size: 0.12 * width, col: '#ffffff', shape: 'dot' }); // the muzzle flaring
    }, draw(ctx) {
      const a = project(muzzle(from, to)), b = project(chest(to)); if (!a || !b) return;
      if (this.t < cT) { const g = this.t / cT; glow(ctx, a.x, a.y, a.k * (0.08 + 0.22 * g) * width, col); return; }
      const t2 = this.t - cT;
      const k = Math.min(1, t2 / 0.15), fade = Math.min(1, (this.life - this.t) / 0.15);
      const ex = lerp(a.x, b.x, k), ey = lerp(a.y, b.y, k);
      const w = Math.max(3, (a.k + b.k) * 0.09) * width * fade * (1 + Math.sin(this.t * 40) * 0.15);
      // it grows out of a bright point in front of the user (so it never paints over the user itself)
      const gr = ctx.createLinearGradient(a.x, a.y, b.x, b.y);
      gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.08, col); gr.addColorStop(1, col);
      const gw = ctx.createLinearGradient(a.x, a.y, b.x, b.y); gw.addColorStop(0, 'rgba(255,255,255,0)'); gw.addColorStop(0.1, '#ffffff'); gw.addColorStop(1, '#ffffff');
      ctx.save(); ctx.lineCap = 'round';
      ctx.globalAlpha = 0.5 * fade; ctx.strokeStyle = gr; ctx.lineWidth = w * 2.4; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.globalAlpha = fade; ctx.lineWidth = w; ctx.stroke(); ctx.strokeStyle = gw; ctx.lineWidth = w * 0.4; ctx.stroke(); ctx.restore();
      glow(ctx, a.x, a.y, a.k * 0.2 * width * fade, col);
    } });
  }
  function bolts(target, { fromSky = true, from = null, onHit } = {}) {
    let hit = false;
    fx.push({ t: 0, life: 0.55, update() { if (!hit && this.t > 0.1) { hit = true; onHit?.(); } }, draw(ctx) {
      const b = project(chest(target, 0.4)); if (!b) return;
      const a = fromSky ? { x: b.x + rnd(-20, 20), y: -10 } : project(chest(from));
      if (!a) return;
      ctx.save(); ctx.strokeStyle = Math.random() < 0.5 ? '#fff8a0' : '#ffe03a'; ctx.lineWidth = Math.max(2, b.k * 0.05); ctx.shadowColor = '#ffe03a'; ctx.shadowBlur = 12;
      for (let n = 0; n < 2; n++) { ctx.beginPath(); ctx.moveTo(a.x, a.y); for (let i = 1; i <= 7; i++) { const k = i / 7; ctx.lineTo(lerp(a.x, b.x, k) + (i < 7 ? rnd(-1, 1) * b.k * 0.25 : 0), lerp(a.y, b.y, k)); } ctx.stroke(); }
      ctx.restore();
    } });
  }
  function slashes(target, col = '#ffffff') {
    fx.push({ t: 0, life: 0.35, draw(ctx) {
      const q = project(chest(target)); if (!q) return; const k = this.t / this.life, r = q.k * 0.6;
      ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = Math.max(2, q.k * 0.05); ctx.globalAlpha = 1 - k * 0.6;
      for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(q.x - r + i * r * 0.35, q.y - r); ctx.lineTo(q.x - r + i * r * 0.35 + 2 * r * Math.min(1, k * 2), q.y - r + 2 * r * Math.min(1, k * 2)); ctx.stroke(); }
      ctx.restore();
    } });
  }
  function bite(target) {
    fx.push({ t: 0, life: 0.35, draw(ctx) {
      const q = project(chest(target)); if (!q) return; const k = ease(this.t / this.life), r = q.k * 0.5, gap = r * (1 - k);
      ctx.save(); ctx.fillStyle = '#ffffff'; ctx.strokeStyle = '#30283a'; ctx.lineWidth = 2;
      for (const s of [-1, 1]) { ctx.beginPath(); for (let i = 0; i < 5; i++) { const x = q.x - r + (i * 2 * r) / 4; ctx.moveTo(x - r * 0.18, q.y + s * gap); ctx.lineTo(x, q.y + s * (gap - r * 0.35)); ctx.lineTo(x + r * 0.18, q.y + s * gap); } ctx.fill(); ctx.stroke(); }
      ctx.restore();
    } });
  }
  function quake(from) {
    const a = chest(from, 0);
    for (let i = 0; i < 3; i++) setTimeout(() => ring({ x: a.x, y: 0.02, z: a.z }, '#c8a060', { r0: 0.3, r1: 4.5, life: 0.7, flat: true, w: 5 }), i * 120);
    shake = 1.4;
    for (let i = 0; i < 18; i++) particle({ x: a.x + rnd(-3, 3), y: 0.05, z: a.z + rnd(-1, 4), vy: rnd(1, 3), g: -8, life: 0.7, size: 0.12, col: '#a88a5a', shape: 'shard' });
  }
  function rocksFall(target, col) {
    const b = chest(target, 0);
    for (let i = 0; i < 6; i++) particle({ x: b.x + rnd(-0.6, 0.6), y: 4 + i * 0.5, z: b.z + rnd(-0.4, 0.4), vy: -2, g: -12, life: 0.65, size: 0.28, col, shape: 'rock', spin: rnd(-4, 4) });
  }
  function aura(side, col, { up = true, n = 22 } = {}) {
    const a = chest(side, 0);
    const hgt = (() => { const ac = actor(side); return ac ? yard.heightOf(ac) : 1; })();
    for (let i = 0; i < n; i++) { const ang = Math.random() * Math.PI * 2, r = rnd(0.3, 0.7) * Math.max(0.6, hgt * 0.6); particle({ x: a.x + Math.cos(ang) * r, y: up ? rnd(0, 0.3) : hgt * 1.1, z: a.z + Math.sin(ang) * r * 0.5, vy: up ? rnd(1.2, 2.4) : -rnd(1.2, 2), life: rnd(0.5, 0.9), size: 0.1, col: i % 3 ? col : '#ffffff', shape: i % 2 ? 'spark' : 'wisp' }); }
  }
  function sparkleOn(side, col, shape = 'star', n = 12) {
    const b = chest(side);
    for (let i = 0; i < n; i++) particle({ x: b.x + rnd(-0.6, 0.6), y: b.y + rnd(-0.5, 0.6), z: b.z + rnd(-0.3, 0.3), vy: rnd(-0.2, 0.6), life: rnd(0.4, 0.8), size: 0.12, col, shape, spin: rnd(-5, 5) });
  }
  const floats = [0, 0];
  function floatText(side, s, col = '#ffffff') {
    const b = chest(side, 1.05);
    const lane = floats[side]++;
    b.y += lane * 0.32;
    fx.push({ t: 0, life: 1.1, end() { floats[side] = Math.max(0, floats[side] - 1); }, draw(ctx) {
      const q0 = project({ x: b.x, y: b.y + this.t * 0.6, z: b.z }); if (!q0) return;
      // kept on screen (and clear of the info boxes) even over a big creature close to the camera
      const q = { ...q0, x: Math.max(yard.W * 0.12, Math.min(yard.W * 0.88, q0.x)), y: Math.max(yard.H * 0.3 + lane * 26 - this.t * 20, q0.y) };
      ctx.save(); ctx.globalAlpha = Math.min(1, (this.life - this.t) * 3);
      ctx.font = `800 ${Math.max(12, Math.round(q.k * 0.22))}px "Segoe UI", system-ui, sans-serif`; ctx.textAlign = 'center';
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(20,16,40,.85)'; ctx.strokeText(s, q.x, q.y); ctx.fillStyle = col; ctx.fillText(s, q.x, q.y); ctx.restore();
    } });
  }
  // Soft round lights (glows, wisps, flames) are drawn from small pictures made once per colour, instead of a
  // new gradient for every one every frame: the same look for a fraction of the work, so busy moves stay smooth
  const softCache = new Map();
  function softSprite(key, stops) {
    let c = softCache.get(key);
    if (c) return c;
    c = document.createElement('canvas'); c.width = c.height = 64;
    const g2 = c.getContext('2d'), gr = g2.createRadialGradient(32, 32, 0, 32, 32, 32);
    for (const [o, col] of stops) gr.addColorStop(o, col);
    g2.fillStyle = gr; g2.fillRect(0, 0, 64, 64);
    if (softCache.size > 160) softCache.clear();
    softCache.set(key, c);
    return c;
  }
  function glow(ctx, x, y, r, col) {
    const R = r * 1.6; if (!(R > 0.3)) return;
    ctx.drawImage(softSprite(`g${col}`, [[0, '#ffffff'], [0.35, col], [1, 'rgba(0,0,0,0)']]), x - R, y - R, R * 2, R * 2);
  }
  function drawParticle(ctx, p) {
    const q = project(p); if (!q) return;
    const k = p.life / p.max, s = Math.max(1.5, p.size * q.k);
    // water, air, fire and ice let light through; rock, earth and steel don't
    const solid = p.shape === 'rock' || p.shape === 'needle' || (p.shape === 'shard' && p.solid !== false && !p.lit);
    ctx.globalAlpha = Math.min(1, k * 2) * (solid ? 1 : p.shape === 'drop' || p.shape === 'wisp' || p.shape === 'bubble' || p.shape === 'snow' ? 0.7 : 0.9);
    // emissive: a soft halo of its own light round it (stronger with dramatic lighting)
    if (p.lit && !lowFx && (dramatic || s > 4)) { const r = s * (dramatic ? 2.6 : 1.8); ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha *= dramatic ? 0.5 : 0.28; glow(ctx, q.x, q.y, r, p.col); ctx.restore(); }
    ctx.fillStyle = p.col;
    switch (p.shape) {
      case 'flame': { const r = s * (0.6 + k * 0.8); ctx.drawImage(softSprite(k > 0.5 ? 'flameA' : 'flameB', [[0, '#fff6a0'], [0.5, k > 0.5 ? '#ffb030' : '#ff5a20'], [1, 'rgba(255,60,0,0)']]), q.x - r, q.y - r, r * 2, r * 2); break; }
      case 'drop': ctx.beginPath(); ctx.ellipse(q.x, q.y, s * 0.5, s * 0.8, 0, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#ffffff'; ctx.fillRect(q.x - s * 0.2, q.y - s * 0.4, Math.max(1, s * 0.2), Math.max(1, s * 0.3)); break;
      case 'leaf': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.beginPath(); ctx.ellipse(0, 0, s, s * 0.45, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore(); break;
      case 'shard': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.beginPath(); ctx.moveTo(0, -s); ctx.lineTo(s * 0.6, 0); ctx.lineTo(0, s * 0.8); ctx.lineTo(-s * 0.5, 0); ctx.closePath(); ctx.fill(); ctx.restore(); break;
      // a rock: a lumpy, squat boulder (not a crystal), darker underneath, a pale chip on top
      case 'rock': { ctx.save(); ctx.translate(q.x, q.y); ctx.rotate((p.rot ?? 0) * 0.5); const r0 = s * 0.8, seed = (p.seed ?? (p.seed = Math.random() * 9));
        ctx.beginPath(); for (let j = 0; j < 7; j++) { const an = (j / 7) * Math.PI * 2, rr = r0 * (0.78 + 0.28 * Math.sin(seed + j * 2.4)) * (j === 2 || j === 5 ? 0.9 : 1); const px = Math.cos(an) * rr, py = Math.sin(an) * rr * 0.78; j ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.moveTo(-r0 * 0.75, r0 * 0.1); ctx.lineTo(r0 * 0.7, r0 * 0.2); ctx.lineTo(r0 * 0.45, r0 * 0.6); ctx.lineTo(-r0 * 0.4, r0 * 0.62); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.22)'; ctx.fillRect(-r0 * 0.35, -r0 * 0.5, Math.max(1, r0 * 0.4), Math.max(1, r0 * 0.22)); ctx.restore(); break; }

      case 'bubble': ctx.strokeStyle = p.col; ctx.lineWidth = Math.max(1, s * 0.2); ctx.beginPath(); ctx.arc(q.x, q.y, s * 0.6, 0, Math.PI * 2); ctx.stroke(); break;
      case 'wisp': ctx.drawImage(softSprite(`w${p.col}`, [[0, p.col], [1, 'rgba(0,0,0,0)']]), q.x - s, q.y - s, s * 2, s * 2); break;
      case 'arrowUp': case 'arrowDown': { const d = p.shape === 'arrowUp' ? -1 : 1; ctx.beginPath(); ctx.moveTo(q.x, q.y + d * s); ctx.lineTo(q.x + s * 0.6, q.y); ctx.lineTo(q.x + s * 0.25, q.y); ctx.lineTo(q.x + s * 0.25, q.y - d * s); ctx.lineTo(q.x - s * 0.25, q.y - d * s); ctx.lineTo(q.x - s * 0.25, q.y); ctx.lineTo(q.x - s * 0.6, q.y); ctx.closePath(); ctx.fill(); break; }
      case 'zzz': ctx.font = `700 ${Math.round(s * 1.6)}px system-ui`; ctx.fillText('z', q.x, q.y); break;
      case 'note': ctx.font = `700 ${Math.round(s * 1.7)}px system-ui`; ctx.fillText(p.rot > 3 ? '♪' : '♫', q.x, q.y); break;
      case 'heart': ctx.save(); ctx.translate(q.x, q.y); ctx.beginPath(); ctx.moveTo(0, s * 0.35); ctx.bezierCurveTo(-s, -s * 0.3, -s * 0.4, -s, 0, -s * 0.35); ctx.bezierCurveTo(s * 0.4, -s, s, -s * 0.3, 0, s * 0.35); ctx.fill(); ctx.restore(); break;
      case 'ember': ctx.fillStyle = k > 0.5 ? '#ffe070' : p.col; ctx.fillRect(q.x - s * 0.25, q.y - s * 0.25, s * 0.5, s * 0.5); break;
      case 'seed': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.fillStyle = '#c8a050'; ctx.beginPath(); ctx.ellipse(0, 0, s * 0.35, s * 0.55, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore(); break;
      case 'flake': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.strokeStyle = p.col; ctx.lineWidth = Math.max(1, s * 0.15); for (let i = 0; i < 3; i++) { ctx.rotate(Math.PI / 3); ctx.beginPath(); ctx.moveTo(-s * 0.6, 0); ctx.lineTo(s * 0.6, 0); ctx.stroke(); } ctx.restore(); break;
      case 'blob': ctx.beginPath(); ctx.arc(q.x, q.y, s * 0.6, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.beginPath(); ctx.arc(q.x - s * 0.2, q.y - s * 0.2, s * 0.18, 0, Math.PI * 2); ctx.fill(); break;
      case 'feather': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.beginPath(); ctx.ellipse(0, 0, s * 0.25, s * 0.7, 0, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,.2)'; ctx.beginPath(); ctx.moveTo(0, -s * 0.7); ctx.lineTo(0, s * 0.7); ctx.stroke(); ctx.restore(); break;
      case 'needle': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.fillRect(-s * 0.08, -s * 0.8, s * 0.16, s * 1.6); ctx.fillStyle = '#ffffff'; ctx.fillRect(-s * 0.08, -s * 0.8, s * 0.16, s * 0.3); ctx.restore(); break;
      case 'gear': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); for (let i = 0; i < 8; i++) { ctx.rotate(Math.PI / 4); ctx.fillRect(-s * 0.12, -s * 0.7, s * 0.24, s * 0.3); } ctx.beginPath(); ctx.arc(0, 0, s * 0.45, 0, Math.PI * 2); ctx.fill(); ctx.restore(); break;
      case 'ring': ctx.strokeStyle = p.col; ctx.lineWidth = Math.max(1.5, s * 0.18); ctx.beginPath(); ctx.ellipse(q.x, q.y, s * 0.7, s, 0, 0, Math.PI * 2); ctx.stroke(); break;
      case 'orb': { const g = ctx.createRadialGradient(q.x, q.y, 0, q.x, q.y, s * 0.7); g.addColorStop(0, '#ffffff'); g.addColorStop(0.5, p.col); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(q.x, q.y, s * 0.7, 0, Math.PI * 2); ctx.fill(); break; }
      case 'fist': ctx.save(); ctx.translate(q.x, q.y); ctx.fillStyle = '#ffffff'; ctx.strokeStyle = '#3a3040'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.roundRect?.(-s * 0.5, -s * 0.4, s, s * 0.8, s * 0.25); ctx.fill(); ctx.stroke(); ctx.restore(); break;
      default: ctx.beginPath(); ctx.arc(q.x, q.y, s * 0.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  // ---------- more effects ----------
  const sideOf = (side) => { const { u, p } = axis(); return { u, p, dir: side === 0 ? 1 : -1 }; };
  const home0 = (side) => { const [x, z] = spot(side); return { x, z }; };
  // moving a creature along a path (k: 0→1) and back to its spot at the end
  function move(side, life, at, { end, gait = false } = {}) {
    busy[side] = (busy[side] ?? 0) + 1;
    fx.push({ t: 0, life, update() { const a = actor(side); if (!a) return; let q = at(this.t / this.life, a); if (!q) return; if (gait) q = gaitify(side, this.t / this.life, q); a.x = q.x; a.z = q.z; if (q.y != null) a.y = q.y; if (q.alpha != null) a.alpha = q.alpha; }, end() { busy[side] = Math.max(0, (busy[side] ?? 1) - 1); const a = actor(side); if (a) { const h0 = home0(side); a.x = h0.x; a.z = h0.z; a.y = 0; if (!vanished[side]) a.alpha = 1; } end?.(); } });
  }
  // ---------- personality: how each creature moves ----------
  // From how it gets about (flying, hovering, swimming, walking) and how heavy and how fast it is (Showdown's own
  // weights and Speed): a Venusaur plods and shakes the ground, a Lanturn bobs, a Dragapult snaps about weightlessly.
  const gaitOf = [null, null], profiles = [null, null], busy = [0, 0], posing = [0, 0];
  function prof(side) {
    if (profiles[side]) return profiles[side];
    const info = (lastTeam ?? []).find((t) => t.side === side && t.active) ?? null;
    const dex = globalThis.BattlePokedex?.[String(info?.species ?? '').toLowerCase().replace(/[^a-z0-9]/g, '')] ?? null;
    const kg = dex?.weightkg ?? 10 * Math.max(0.3, tall(side)) ** 3, spe = dex?.baseStats?.spe ?? 60;
    const heavy = Math.max(0, Math.min(1, (Math.log10(Math.max(1, kg)) - 1) / (Math.log10(300) - 1)));
    const quick = Math.max(0, Math.min(1, (spe - 50) / 75));
    return (profiles[side] = { gait: gaitOf[side] ?? 'walk', heavy, quick, kg });
  }
  // the way it travels: flying swoops up and down, hovering glides level, swimming sways, walking steps (heavy
  // ones barely bounce but shake the ground; light quick ones skip)
  function gaitify(side, k, q) {
    const P2 = prof(side), env = Math.sin(Math.PI * Math.max(0, Math.min(1, k)));
    if (P2.gait === 'fly') return { ...q, y: (q.y ?? 0) * 0.5 + env * (0.75 + 0.35 * Math.sin(k * Math.PI * 6)) };
    if (P2.gait === 'hover') return { ...q, y: (q.y ?? 0) * 0.25 + env * (0.28 + 0.05 * Math.sin(k * Math.PI * 8)) };
    if (P2.gait === 'swim') { const { p } = sideOf(side), sw = Math.sin(k * Math.PI * 4) * 0.28 * env; return { ...q, x: q.x + p.x * sw, z: q.z + p.z * sw, y: (q.y ?? 0) * 0.3 + 0.04 }; }
    const bounce = 1 - P2.heavy * 0.7 + P2.quick * 0.3;
    if (P2.heavy > 0.6 && env > 0.2 && Math.sin(k * Math.PI * 10) > 0.97 && Math.random() < 0.6) { shake = Math.max(shake, 0.25 * P2.heavy); const a = actor(side); if (a) particle({ x: a.x, y: 0.05, z: a.z, vx: rnd(-0.6, 0.6), vy: rnd(0.2, 0.6), life: 0.5, size: 0.22, col: 'rgba(190,175,140,.55)', shape: 'wisp' }); }
    return { ...q, y: (q.y ?? 0) * bounce };
  }
  // a pose over time (fn(k) → { lean, sx, sy, dx, dy, dim } or null), on top of where it is
  function posefx(side, dur, fn, { end } = {}) {
    posing[side]++;
    fx.push({ t: 0, life: dur, update() { const a = actor(side); if (a) a.pose = fn(this.t / this.life, a) ?? null; }, end() { posing[side] = Math.max(0, posing[side] - 1); const a = actor(side); if (a) a.pose = null; end?.(); } });
  }
  // the screen direction to lean to tip away from the other side (+1 or −1, as a rotation sign)
  function awayDir(side) { const qa = project(chest(side)), qb = project(chest(1 - side)); return qa && qb ? (qb.x > qa.x ? -1 : 1) : 1; }
  // settling back into its stance: a little squash and stretch that dies away
  function settle(side, amt = 1) { const P2 = prof(side); posefx(side, 0.45 + P2.heavy * 0.25, (k) => { const d = (1 - k) * amt * (0.07 - P2.heavy * 0.03 + P2.quick * 0.02); return { sy: 1 + Math.sin(k * Math.PI * 3) * d, sx: 1 - Math.sin(k * Math.PI * 3) * d * 0.6 }; }); }
  // A hit taken, reacted to by how hard it was: a flinch, a squint, a stagger, a stumble, losing its balance, or
  // being knocked back off its feet. Heavy creatures shrug off more; light ones are thrown about.
  function react(side, sev = 0.1, crit = false) {
    if (!actor(side)) return;
    const P2 = prof(side), dir = awayDir(side), k0 = Math.max(0.35, 1 - P2.heavy * 0.5 + (1 - P2.quick) * 0.05);
    const hard = (sev + (crit ? 0.25 : 0)) * (1.25 - P2.heavy * 0.5);
    const pickR = (list) => list[Math.floor(Math.random() * list.length)];
    const kind = hard < 0.08 ? 'flinch' : hard < 0.2 ? pickR(['squint', 'flinch', 'stagger']) : hard < 0.42 ? pickR(['stagger', 'stumble', 'squint']) : pickR(['fall', 'balance', 'fall']);
    const { u, dir: d2, p } = sideOf(side), h0 = home0(side);
    switch (kind) {
      case 'flinch': posefx(side, 0.3, (k) => { const e = Math.sin(k * Math.PI); return { sy: 1 - 0.1 * e * k0, sx: 1 + 0.05 * e * k0, lean: dir * 0.06 * e, dim: 0.15 * e }; }); break;
      case 'squint': posefx(side, 0.5, (k) => { const e = k < 0.2 ? k / 0.2 : 1 - (k - 0.2) / 0.8; return { sy: 1 - 0.07 * e, sx: 1 + 0.03 * e, dim: 0.28 * e, dx: Math.sin(k * 60) * 0.01 * e }; }); break;
      case 'stagger':
        move(side, 0.5, (k) => { const b = Math.sin(k * Math.PI) * 0.35 * k0; return { x: h0.x - u.x * d2 * b, z: h0.z - u.z * d2 * b }; });
        posefx(side, 0.55, (k) => { const e = Math.sin(k * Math.PI); return { lean: dir * 0.22 * e * k0, sy: 1 - 0.05 * e }; }); break;
      case 'stumble':
        move(side, 0.6, (k) => { const s2 = Math.sin(k * Math.PI) * 0.4 * k0; return { x: h0.x + p.x * s2 - u.x * d2 * s2 * 0.4, z: h0.z + p.z * s2 - u.z * d2 * s2 * 0.4 }; });
        posefx(side, 0.7, (k) => ({ lean: Math.sin(k * Math.PI * 3) * 0.16 * (1 - k) * k0, sy: 1 - 0.04 * Math.sin(k * Math.PI) })); break;
      case 'balance': posefx(side, 0.95, (k) => ({ lean: Math.sin(k * Math.PI * 4) * 0.28 * (1 - k) * k0, sx: 1 + Math.sin(k * Math.PI * 4) * 0.03 * (1 - k) })); break;
      default: // knocked back off its feet, then back up
        move(side, 0.9, (k) => { const b = (k < 0.35 ? Math.sin((k / 0.35) * Math.PI / 2) : 1 - (k - 0.35) / 0.65) * 0.6 * k0; return { x: h0.x - u.x * d2 * b, z: h0.z - u.z * d2 * b, y: k < 0.3 ? Math.sin((k / 0.3) * Math.PI) * 0.35 : 0 }; });
        posefx(side, 1.0, (k) => { const down = k < 0.3 ? k / 0.3 : k < 0.6 ? 1 : 1 - (k - 0.6) / 0.4; return { lean: dir * 0.55 * down * k0, sy: 1 - 0.12 * down, dim: 0.12 * down }; }, { end: () => settle(side, 1.2) });
        if (P2.heavy < 0.5) { const a = actor(side); if (a) burst({ x: a.x, y: 0.1, z: a.z }, '#cdbb98', 8, { shape: 'wisp', speed: 1.2, size: 0.25 }); }
    }
  }
  // ---------- knocked back by a hit ----------
  // The strike lands and it's sent sliding back (further for a harder hit and a lighter creature), it stays back
  // while its HP drains, lets out a short cry, then hops back to its spot. A knockout still comes back first, then faints.
  const kb = [null, null];
  let faintCam = null; // the side the camera is staying on because it's about to faint
  const hitAt = [0, 0]; // when a move last struck each side (damage with no strike is residual: poison, a burn, sand…)
  const lastStatusAnim = [null, null];
  function cryOf(side, opts) { try { const c0 = creatureFor(mons[side]?.info); const BS = globalThis.__clBattleSound; if (c0 && !BS?.muted) creatureCry(speciesOf(idx, c0), c0, opts); } catch { /* no sound */ } }
  function slideBack(side, sev = 0.2, crit = false) {
    const a = actor(side); if (!a || vanished[side]) return null;
    const P2 = prof(side), k0 = Math.max(0.35, 1 - P2.heavy * 0.55 + (1 - P2.quick) * 0.04);
    const amt = Math.min(1.8, (0.5 + sev * 2.6 + (crit ? 0.35 : 0)) * k0), airy = P2.gait === 'fly' || P2.gait === 'hover';
    const { u, dir } = sideOf(side), h0 = home0(side), dA = awayDir(side), y0 = a.y ?? 0;
    if (kb[side]) kb[side].done = true;
    const st = { amt, back: 0, done: false, ret: null, t: 0 };
    kb[side] = st; busy[side]++; posing[side]++;
    fx.push({ t: 0, life: 99, update(dt) {
      const a2 = actor(side); if (!a2 || st.done || destroyed) { this.t = this.life; return; }
      st.t += dt;
      if (st.ret == null) { // thrown back, then skidding to a stop
        const k = Math.min(1, st.t / 0.34); st.back = amt * (1 - (1 - k) ** 3);
        const up = Math.sin(Math.min(1, st.t / 0.3) * Math.PI) * (sev > 0.25 ? 0.45 : 0.18) * k0;
        a2.y = airy ? y0 + up : up;
        const lean = dA * (0.25 + Math.min(0.4, sev)) * k0 * Math.max(0.35, 1 - st.t * 1.4);
        a2.pose = { lean, sy: 1 - 0.09 * Math.max(0, 1 - st.t * 2.2), sx: 1 + 0.04 * Math.max(0, 1 - st.t * 2.2), dim: Math.max(0, 0.22 - st.t * 0.6) };
        if (st.t > 0.3 && !st.dust && !airy) { st.dust = true; burst({ x: a2.x, y: 0.06, z: a2.z }, '#cdbb98', 7 + Math.round(amt * 5), { shape: 'wisp', speed: 1.1, size: 0.24 }); }
        if (st.t > 7) st.ret = st.t; // never told: come back anyway
      } else { // hopping back to the spot
        const k = Math.min(1, (st.t - st.ret) / 0.5); st.back = amt * (1 - ease(k));
        a2.y = (airy ? y0 : 0) + Math.sin(k * Math.PI) * 0.32;
        a2.pose = { sy: 1 + Math.sin(k * Math.PI) * 0.07, sx: 1 - Math.sin(k * Math.PI) * 0.04 };
        if (k >= 1) { st.done = true; this.t = this.life; }
      }
      a2.x = h0.x - u.x * dir * st.back; a2.z = h0.z - u.z * dir * st.back;
    }, end() { busy[side] = Math.max(0, busy[side] - 1); posing[side] = Math.max(0, posing[side] - 1); const a2 = actor(side); if (a2) { a2.pose = null; if (!airy) a2.y = 0; a2.x = h0.x; a2.z = h0.z; } if (kb[side] === st) kb[side] = null; if (actor(side)) settle(side, 0.8); } });
    return st;
  }
  // after `delay` seconds: a short bit of its cry, then back to its spot (how long that takes, in seconds)
  function comeBack(side, delay = 0) {
    const st = kb[side]; if (!st || st.done) return 0;
    setTimeout(() => { if (st.done || st.ret != null) return; cryOf(side, { chop: [[0, 0.28, 1, 1.12]] }); setTimeout(() => { if (st.ret == null) st.ret = st.t; }, 160); }, delay * 1000);
    return 0.7;
  }
  // after-images behind something moving fast
  function trail(side, col = '#ffffff') { const a = actor(side); if (!a) return; particle({ x: a.x, y: (a.y || 0) + tall(side) * 0.5, z: a.z, life: 0.25, size: tall(side) * 0.55, col, shape: 'wisp' }); }
  // a dash at the target: straight (or zig-zagging across the field), hit, and back
  function dash(side, target, { dur = 0.6, depth = 0.86, zig = 0, hop = 0.3, onHit, hits = 1 } = {}) {
    const a0 = home0(side), t = chest(target, 0), { p } = sideOf(side);
    let hitN = 0;
    move(side, dur, (k) => {
      const out = k < 0.55 ? ease(k / 0.55) : 1 - ease((k - 0.55) / 0.45);
      const wob = zig ? Math.sin(out * Math.PI * zig) * 1.4 * (1 - out * 0.7) : 0;
      if (zig && k < 0.55) trail(side);
      // several hits: little bounces at the target
      if (k >= 0.5 && hitN < hits && k >= 0.5 + hitN * (0.12 / hits)) { hitN++; onHit?.(hitN); }
      const extra = k > 0.5 && k < 0.62 ? Math.sin((k - 0.5) / 0.12 * Math.PI * hits) * 0.15 : 0;
      return { x: lerp(a0.x, t.x, out * depth) + p.x * wob, z: lerp(a0.z, t.z, out * depth + extra) + p.z * wob, y: Math.sin(out * Math.PI) * hop };
    });
  }
  // How a physical move gets there, chosen by what the move is (see approachFor): running up and striking,
  // a long leap, a high pounce that lands on the target, a lowered charge, a blur that reappears at the target,
  // a curving run round the side, a flurry of blows up close, a spinning roll, or Quick Attack's zig-zag.
  const APPROACH = { run: [1.05, 0.62], leap: [0.8, 0.5], pounce: [0.95, 0.55], charge: [0.95, 0.5], blink: [0.8, 0.3], arc: [1.0, 0.56], flurry: [0.95, 0.42], spin: [0.95, 0.5], zigzag: [0.85, 0.55] };
  function approachFor(m, C) {
    const n = String(m.name).toLowerCase();
    if (C.kind === 'zigzag') return 'zigzag';
    if ((m.priority ?? 0) > 0 || /quick attack|extreme ?speed|aqua jet|mach punch|bullet punch|accelerock|fake out|sucker punch|shadow sneak|jet punch|vacuum wave|first impression|feint/.test(n)) return 'blink';
    if (/rapid spin|gyro ball|rollout|ice ball|flame wheel|steel roller|spin out|mortal spin|drill run|horn drill/.test(n) || C.kind === 'tackleSpin') return 'spin';
    if (/bounce|body slam|stomp|heavy slam|heat crash|pounce|jump kick|high jump kick|dragon rush|sky drop|flying press|meteor mash|hammer arm|crabhammer|wood hammer|ice hammer|giga impact|stomping tantrum/.test(n)) return n.length % 2 ? 'pounce' : 'leap';
    if (/take down|double-edge|head charge|wild charge|flare blitz|volt tackle|head smash|skull bash|brave bird|wave crash|tackle|headbutt|horn attack|megahorn|iron head|zen headbutt|bulldoze|smart strike/.test(n) || C.kind === 'horn') return 'charge';
    if ((C.hits || 1) > 1) return 'flurry';
    if (/aerial ace|wing attack|night slash|leaf blade|x-scissor|cross chop|slash|cut|claw|psycho cut|sacred sword|aqua cutter|kowtow|air cutter|acrobatics|u-turn|fly/.test(n) || C.kind === 'slash') return ['arc', 'run'][n.length % 2];
    if (C.kind === 'kick') return ['leap', 'run', 'arc'][n.length % 3];
    if (C.kind === 'punch') return ['run', 'arc', 'charge'][n.length % 3];
    if (C.kind === 'bite') return ['pounce', 'run'][n.length % 2];
    return ['run', 'leap', 'arc', 'charge'][n.length % 4];
  }
  function approach(side, target, style, { dur, hits = 1, onHit }) {
    const a0 = home0(side), t = chest(target, 0), dx = t.x - a0.x, dz = t.z - a0.z, L = Math.hypot(dx, dz) || 1, sg = side === 0 ? 1 : -1;
    const ux = dx / L, uz = dz / L, px = uz * sg, pz = -ux * sg;
    const at = (q, sideways = 0) => ({ x: a0.x + dx * q + px * sideways, z: a0.z + dz * q + pz * sideways });
    const [, hitAt] = APPROACH[style] ?? APPROACH.run;
    const times = style === 'flurry' ? Array.from({ length: hits }, (_, i) => 0.42 + i * (0.36 / hits)) : Array.from({ length: hits }, (_, i) => hitAt + i * (0.1 / hits));
    let hitN = 0;
    const dust = (k) => { const a = actor(side); if (a && Math.random() < 0.7) particle({ x: a.x + rnd(-0.2, 0.2), y: 0.05, z: a.z + rnd(-0.1, 0.1), vx: -ux * rnd(0.5, 1.4), vy: rnd(0.3, 0.9), vz: -uz * rnd(0.5, 1.4), life: rnd(0.4, 0.7), size: rnd(0.12, 0.24) * (0.6 + k), col: 'rgba(200,184,150,.6)', shape: 'wisp' }); };
    // anticipation and follow-through: it leans back and gathers itself first (longer for heavy ones), stretches
    // into the strike, recoils off a heavy hit, and settles back into its stance
    const P2 = prof(side), pre = Math.max(0.06, Math.min(0.26, 0.13 + P2.heavy * 0.12 - P2.quick * 0.07)), dirA = awayDir(side);
    posefx(side, dur, (kr) => {
      if (kr < pre) { const w = Math.sin((kr / pre) * Math.PI / 2); return { lean: dirA * (0.2 + P2.heavy * 0.1) * w, sx: 1 + 0.07 * w, sy: 1 - 0.11 * w }; }
      const kk = (kr - pre) / (1 - pre), dh = Math.abs(kk - hitAt);
      let lean = P2.gait === 'swim' ? Math.sin(kk * Math.PI * 4) * 0.12 : P2.gait === 'fly' ? -dirA * 0.1 * Math.sin(kk * Math.PI) : 0, sx = 1, sy = 1;
      if (dh < 0.09) { const e = 1 - dh / 0.09; lean += -dirA * 0.2 * e; sx += 0.15 * e; sy -= 0.08 * e; }
      else if (kk > hitAt) { const r = Math.min(1, (kk - hitAt - 0.09) / Math.max(0.05, 0.91 - hitAt)); lean += dirA * (0.08 + P2.heavy * 0.12) * Math.sin(r * Math.PI) * (1 - r * 0.5); sy += 0.06 * Math.sin(r * Math.PI * 2.5) * (1 - r); }
      return { lean, sx, sy };
    }, { end: () => settle(side, 1 + P2.heavy * 0.5) });
    const shiftT = (k) => pre + k * (1 - pre);
    if (style === 'zigzag') { setTimeout(() => dash(side, target, { dur: dur * (1 - pre), zig: 3, hop: 0.15, onHit: () => onHit?.(1) }), dur * pre * 1000); return; }
    if (style === 'leap') { setTimeout(() => dash(side, target, { dur: dur * (1 - pre), depth: 0.86, hop: P2.gait === 'fly' ? 1.4 : 0.95, hits, onHit }), dur * pre * 1000); return; }
    void shiftT;
    move(side, dur, (kRaw) => {
      if (kRaw < pre) return { ...at(0), y: 0 };
      const k = (kRaw - pre) / (1 - pre);
      while (hitN < times.length && k >= times[hitN]) { hitN++; onHit?.(hitN); }
      return (() => {
      const a = actor(side);
      switch (style) {
        case 'run': { // runs up, strikes, hops back
          if (k < 0.55) { const r = k / 0.55; if (Math.random() < 0.35) dust(0.3); return { ...at(ease(r) * 0.78), y: Math.abs(Math.sin(r * Math.PI * 5)) * 0.12 }; }
          if (k < 0.66) { const r2 = (k - 0.55) / 0.11; return { ...at(0.78 + 0.1 * r2), y: Math.sin(r2 * Math.PI) * 0.25 }; }
          const r3 = ease((k - 0.66) / 0.34); return { ...at(0.88 * (1 - r3)), y: Math.sin(r3 * Math.PI) * 0.4 };
        }
        case 'charge': { // pulls back, then barrels in low, kicking up dust, and bounces off
          if (k < 0.15) return { ...at(-0.12 * ease(k / 0.15)), y: 0 };
          if (k < 0.5) { const r = (k - 0.15) / 0.35; dust(r); if (r > 0.4) trail(side); return { ...at(-0.12 + 1.07 * r * r), y: 0 }; }
          if (k < 0.62) { const r2 = (k - 0.5) / 0.12; return { ...at(0.95 - 0.15 * ease(r2)), y: Math.sin(r2 * Math.PI) * 0.2 }; }
          const r3 = ease((k - 0.62) / 0.38); return { ...at(0.8 * (1 - r3)), y: Math.sin(r3 * Math.PI) * 0.25 };
        }
        case 'blink': { // a flicker, gone, there, strike, gone, back
          if (k < 0.18) return { ...at(0), alpha: Math.floor(k * 40) % 2 ? 0.35 : 1 };
          if (k < 0.24) { const r = (k - 0.18) / 0.06; const q = at(0.84 * r); particle({ x: q.x, y: tall(side) * 0.5, z: q.z, life: 0.3, size: tall(side) * 0.5, col: 'rgba(255,255,255,.55)', shape: 'wisp' }); return { ...q, alpha: 0 }; }
          if (k < 0.72) { const r2 = Math.min(1, (k - 0.24) / 0.12); return { ...at(0.84 + Math.sin(r2 * Math.PI) * 0.06), alpha: 1, y: 0 }; }
          if (k < 0.8) return { ...at(0.84), alpha: Math.floor(k * 40) % 2 ? 0.2 : 0.8 };
          return { ...at(0), alpha: Math.min(1, (k - 0.8) * 6) };
        }
        case 'arc': { // round the side in a curve, then straight back
          if (k < 0.58) { const r = ease(k / 0.58); if (r > 0.2) trail(side); return { ...at(r * 0.86, Math.sin(r * Math.PI) * 2.1), y: Math.sin(r * Math.PI) * 0.3 }; }
          const r2 = ease((k - 0.58) / 0.42); return { ...at(0.86 * (1 - r2)), y: Math.sin(r2 * Math.PI) * 0.45 };
        }
        case 'pounce': { // a high jump that comes down on top of it
          if (k < 0.55) { const r = ease(k / 0.55); return { ...at(r * 0.92), y: Math.sin(r * Math.PI) * (1.6 + tall(side) * 0.5) }; }
          if (k < 0.62) return { ...at(0.92), y: 0 };
          const r2 = ease((k - 0.62) / 0.38); return { ...at(0.92 * (1 - r2)), y: Math.sin(r2 * Math.PI) * 0.6 };
        }
        case 'flurry': { // runs in, then blow after blow, shuffling about
          if (k < 0.35) { const r = k / 0.35; return { ...at(ease(r) * 0.8), y: Math.abs(Math.sin(r * Math.PI * 4)) * 0.1 }; }
          if (k < 0.82) { const r2 = (k - 0.35) / 0.47, i = Math.floor(r2 * hits), f = r2 * hits - i; return { ...at(0.8 + Math.sin(f * Math.PI) * 0.08, (i % 2 ? 0.3 : -0.3) * Math.sin(Math.min(1, f * 2) * Math.PI / 2)), y: Math.sin(f * Math.PI) * 0.15 }; }
          const r3 = ease((k - 0.82) / 0.18); return { ...at(0.8 * (1 - r3)), y: Math.sin(r3 * Math.PI) * 0.35 };
        }
        case 'spin': { // rolling in, spinning
          if (a) a.battleFaceLock = k < 0.62 ? (Math.floor(k * 24) % 2 ? 'left' : 'right') : null;
          if (k < 0.5) { const r = k / 0.5; trail(side); dust(r); return { ...at(ease(r) * 0.93, Math.sin(r * Math.PI * 3) * 0.3), y: Math.abs(Math.sin(r * Math.PI * 6)) * 0.12 }; }
          if (k < 0.62) { const r2 = (k - 0.5) / 0.12; return { ...at(0.93 - 0.2 * r2), y: Math.sin(r2 * Math.PI) * 0.35 }; }
          const r3 = ease((k - 0.62) / 0.38); return { ...at(0.73 * (1 - r3)), y: Math.sin(r3 * Math.PI) * 0.3 };
        }
        default: return { ...at(0) };
      }
      })();
    }, { gait: true, end: () => { const a = actor(side); if (a) a.battleFaceLock = null; } });
  }
  // knocked back a little by a hit
  function knock(side, amt = 0.35) { const { u, dir } = sideOf(side); const h0 = home0(side); move(side, 0.35, (k) => { const b = Math.sin(k * Math.PI) * amt; return { x: h0.x - u.x * dir * b, z: h0.z - u.z * dir * b }; }); }
  function swirl(target, type, { dur = 1.3, rise = 1.4 } = {}) { // a whirling column (Whirlpool, Fire Spin, Sand Tomb…)
    const L = lookOf(type), b = chest(target, 0), hgt = tall(target) * rise + 0.6;
    fx.push({ t: 0, life: dur, update() { for (let i = 0; i < 6; i++) { const ang = this.t * 9 + i * 1.05, y = ((this.t * 1.4 + i / 6) % 1) * hgt, r = 0.5 + y * 0.35; particle({ x: b.x + Math.cos(ang) * r, y, z: b.z + Math.sin(ang) * r * 0.6, vx: -Math.sin(ang) * 2, vz: Math.cos(ang) * 1.2, vy: 0.4, life: 0.28, size: 0.16, col: i % 2 ? L.col : L.col2, shape: L.shapes[i % L.shapes.length] }); } } });
  }
  function stream(from, to, type, { dur = 0.6, rate = 5, size = 0.16, onHit, reverse = false } = {}) { // a stream of particles (Flamethrower, Water Gun, Giga Drain back), from in front of the user
    const L = lookOf(type); let hit = false;
    fx.push({ t: 0, life: dur, update() {
      const A = reverse ? chest(to) : muzzle(from, to), B = chest(reverse ? from : to);
      if (!reverse && (this.lt = (this.lt ?? 0) - 1) <= 0) { this.lt = 3; const mid0 = { x: lerp(A.x, B.x, 0.4), y: lerp(A.y, B.y, 0.4), z: lerp(A.z, B.z, 0.4) }; const lc = rgbOf(TYPE_COL[type] ?? '#ffffff'); lightFlash(mid0, lc, { r: 4.5, i: 0.75, life: 0.16 }); lightFlash(B, lc, { r: 3, i: 0.6, life: 0.14 }); }
      for (let i = 0; i < rate; i++) { const s0 = Math.random() * 0.15; particle({ x: A.x, y: A.y, z: A.z, vx: (B.x - A.x) / 0.32 + rnd(-0.4, 0.4), vy: (B.y - A.y) / 0.32 + rnd(-0.2, 0.6), vz: (B.z - A.z) / 0.32 + rnd(-0.3, 0.3), life: 0.32 - s0, size: size * rnd(0.6, 1.2), col: Math.random() < 0.3 ? L.col2 : L.col, shape: L.shapes[Math.floor(Math.random() * L.shapes.length)], spin: rnd(-8, 8) }); }
      if (!hit && this.t > 0.3) { hit = true; onHit?.(); }
    },
    // the jet itself: a tapering, rippling band from the user to the target (a solid core, lighter edges, a
    // bright centre line), growing out over the first moments and thinning away at the end
    draw(ctx) { if (reverse) return;
      const A = muzzle(from, to), B = chest(to), reach = Math.min(1, this.t / 0.22), thin = Math.min(1, (this.life - this.t) / 0.18);
      const N = 16, top = [], bot = [], mid = [];
      const qa = project(A), qb = project(B); if (!qa || !qb) return;
      const dx = qb.x - qa.x, dy = qb.y - qa.y, l = Math.hypot(dx, dy) || 1, nx = -dy / l, ny = dx / l;
      for (let i = 0; i <= N; i++) { const f = (i / N) * reach, q = project({ x: lerp(A.x, B.x, f), y: lerp(A.y, B.y, f) + Math.sin(f * 9 - this.t * 26) * 0.05, z: lerp(A.z, B.z, f) }); if (!q) return;
        const w = q.k * size * (0.55 + f * 1.4) * thin * (1 + Math.sin(f * 14 - this.t * 30) * 0.12); top.push([q.x + nx * w, q.y + ny * w]); bot.push([q.x - nx * w, q.y - ny * w]); mid.push([q.x, q.y]); }
      ctx.save(); ctx.lineJoin = 'round';
      const band = (alpha, fill, k2) => { ctx.globalAlpha = alpha; ctx.fillStyle = fill; ctx.beginPath(); top.forEach(([x, y], i) => { const [mx, my] = mid[i]; const px = lerp(mx, x, k2), py = lerp(my, y, k2); i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }); for (let i = bot.length - 1; i >= 0; i--) { const [x, y] = bot[i], [mx, my] = mid[i]; ctx.lineTo(lerp(mx, x, k2), lerp(my, y, k2)); } ctx.closePath(); ctx.fill(); };
      band(0.45, L.col, 1); band(0.75, L.col2, 0.55);
      ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.7; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = Math.max(1.5, (qa.k ?? 30) * size * 0.25); ctx.beginPath(); mid.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.stroke();
      ctx.restore();
    } });
  }
  function powder(target, type, col) { const L = lookOf(type), b = chest(target, 1.4); for (let i = 0; i < 40; i++) particle({ x: b.x + rnd(-0.9, 0.9), y: b.y + rnd(0, 1.2), z: b.z + rnd(-0.5, 0.5), vx: rnd(-0.2, 0.2), vy: -rnd(0.5, 1.2), life: rnd(0.8, 1.4), size: 0.07, col: col ?? (i % 2 ? L.col : L.col2), shape: 'dot' }); }
  function rainOn(target, type, { n = 18, onHit } = {}) { const L = lookOf(type), b = chest(target, 0); for (let i = 0; i < n; i++) particle({ x: b.x + rnd(-1.2, 1.2), y: 5 + rnd(0, 3), z: b.z + rnd(-0.8, 0.8), vy: -9, life: 0.8, size: 0.22, col: i % 3 ? L.col : L.col2, shape: L.shapes[i % L.shapes.length], spin: rnd(-4, 4) }); setTimeout(() => onHit?.(), 520); }
  function pillar(target, type, { onHit } = {}) { const L = lookOf(type), b = chest(target, 0); for (let i = 0; i < 26; i++) particle({ x: b.x + rnd(-0.4, 0.4), y: 0.02, z: b.z + rnd(-0.3, 0.3), vy: rnd(4, 8), g: -6, life: 0.7, size: rnd(0.14, 0.3), col: i % 3 ? L.col : L.col2, shape: L.shapes[i % L.shapes.length], spin: rnd(-6, 6) }); ring({ x: b.x, y: 0.02, z: b.z }, L.col, { flat: true, r1: 1.6, life: 0.5 }); setTimeout(() => onHit?.(), 160); }
  function waveAcross(from, to, type, { onHit } = {}) { // a wall of water (or sludge) rolling across the field
    const L = lookOf(type); let hit = false;
    fx.push({ t: 0, life: 0.9, update() { const A = chest(from, 0), B = chest(to, 0), k = ease(this.t / this.life), { p } = sideOf(from);
      for (let i = -4; i <= 4; i++) { const c = { x: lerp(A.x, B.x, k) + p.x * i * 0.45, z: lerp(A.z, B.z, k) + p.z * i * 0.45 }; particle({ x: c.x, y: rnd(0, 1.1), z: c.z, vy: rnd(0.5, 1.5), life: 0.3, size: 0.24, col: Math.random() < 0.35 ? L.col2 : L.col, shape: L.shapes[0] }); }
      if (!hit && k > 0.75) { hit = true; onHit?.(); } } });
  }
  // Surf, Muddy Water, Sludge Wave…: a real wave. A wall of water rises behind the user, rears up with a foaming
  // crest and rolls right across the field and over the target, throwing spray.
  function bigWave(from, to, type, { onHit, dur = 1.35, mud = false } = {}) {
    const L = lookOf(type), c1 = mud ? '#6e4e2e' : L.col, c2 = mud ? '#b8925e' : L.col2; let hit = false;
    const ring0 = (A, B, f) => ({ x: lerp(A.x, B.x, f), z: lerp(A.z, B.z, f) });
    fx.push({ t: 0, life: dur,
      update() { const k = this.t / this.life, A = home0(from), B = home0(to), { p } = sideOf(from), fr = -0.2 + k * 1.45;
        if (k > 0.08 && k < 0.95) for (let i = 0; i < 5; i++) { const w = rnd(-3.2, 3.2), c = ring0(A, B, fr); particle({ x: c.x + p.x * w, y: this.h ?? 1.5, z: c.z + p.z * w, vx: rnd(-0.6, 0.6) + (B.x - A.x) * 0.12, vy: rnd(0.6, 2.2), vz: rnd(-0.4, 0.4) + (B.z - A.z) * 0.12, g: -7, life: 0.55, size: rnd(0.1, 0.22), col: Math.random() < 0.5 ? '#ffffff' : c2, shape: mud ? 'rock' : 'drop' }); }
        if (!hit && fr > 0.92) { hit = true; onHit?.(); shake = Math.max(shake, 0.9); lensHit(mud ? 'mud' : type === 'Poison' ? 'dropPoison' : 'drop', 14); } },
      draw(ctx) {
        const k = this.t / this.life, A = home0(from), B = home0(to), { p } = sideOf(from), fr = -0.2 + k * 1.45;
        const rise = Math.min(1, k * 2.6) * (1 - Math.max(0, (k - 0.82) / 0.18) * 0.85), H = (1.25 + tall(to) * 1.15) * rise; this.h = H;
        const N = 12, half = 3.6, fade = 1 - Math.max(0, (k - 0.85) / 0.15);
        const pt = (f, w, y) => { const c = ring0(A, B, f); return project({ x: c.x + p.x * w, y, z: c.z + p.z * w }); };
        const line = (f, y, wob = 0) => { const out = []; for (let i = -N; i <= N; i++) { const w = (i / N) * half, yy = y * (1 - Math.pow(Math.abs(i / N), 3) * 0.55) + Math.sin(i * 0.9 + this.t * 7) * wob; out.push(pt(f, w, yy)); } return out; };
        let crest = line(fr, H, 0.08 * H), lip = line(fr + 0.05, H * 0.86, 0.06 * H), base = line(fr + 0.03, 0.02), back = line(fr - 0.42, Math.max(0.02, H * 0.15)), mid = line(fr - 0.18, H * 0.55, 0.05 * H);
        // (parts behind the camera can't be drawn: keep the columns that can)
        const keep = crest.map((_, i) => crest[i] && lip[i] && base[i] && mid[i]);
        const pick2 = (arr) => arr.filter((_, i) => keep[i]);
        crest = pick2(crest); lip = pick2(lip); base = pick2(base); mid = pick2(mid); const back2 = back.filter((_, i) => keep[i] && back[i]);
        if (crest.length < 3) return;
        const poly = (top, bot, fill, a) => { ctx.globalAlpha = a; ctx.fillStyle = fill; ctx.beginPath(); top.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y))); for (let i = bot.length - 1; i >= 0; i--) ctx.lineTo(bot[i].x, bot[i].y); ctx.closePath(); ctx.fill(); };
        ctx.save();
        const yTop = Math.min(...crest.map((q) => q.y)), yBot = Math.max(...base.map((q) => q.y));
        const g = ctx.createLinearGradient(0, yTop, 0, yBot); g.addColorStop(0, c2); g.addColorStop(0.45, c1); g.addColorStop(1, mud ? '#3e2a16' : 'rgba(10,40,90,1)');
        if (back2.length === mid.length) poly(mid, back2, g, 0.55 * fade); poly(crest, mid, g, 0.62 * fade); poly(crest, base, g, 0.72 * fade);
        // the curling lip and the foam along the top
        poly(lip, crest, 'rgba(255,255,255,.9)', 0.55 * fade);
        ctx.globalAlpha = 0.95 * fade; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = Math.max(3, (crest[crest.length >> 1].k ?? 20) * 0.09); ctx.lineJoin = 'round'; ctx.beginPath(); crest.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y))); ctx.stroke();
        // streaks down its face
        ctx.globalAlpha = 0.35 * fade; ctx.lineWidth = 2;
        for (let i = 0; i < crest.length; i += 3) { const q = crest[i], b = base[i]; const off = ((this.t * 2 + i * 0.13) % 1); ctx.beginPath(); ctx.moveTo(q.x, lerp(q.y, b.y, off * 0.3)); ctx.lineTo(lerp(q.x, b.x, 0.5), lerp(q.y, b.y, 0.3 + off * 0.5)); ctx.stroke(); }
        ctx.restore();
      } });
  }
  // a tornado (Twister) or a whirlpool (Whirlpool, Fire Spin, Sand Tomb, Magma Storm): a funnel of spinning bands
  // round the target, swaying and throwing up debris (a whirlpool also churns the ground round it)
  function funnel(target, type, { mode = 'pool', dur = 1.7, from = null, travel = 0, onHit } = {}) {
    const L = lookOf(type); let hit = false; let at0 = null;
    const where = (t) => { const c = chest(target, 0); if (from == null || t >= travel) return c; const a = at0 ?? (at0 = chest(from, 0)), k = ease(t / travel); return { x: lerp(a.x, c.x, k), y: 0, z: lerp(a.z, c.z, k) }; };
    const cols = [L.col, L.col2, '#ffffff'];
    fx.push({ t: 0, life: dur + travel,
      update() { const c = where(this.t), grow = Math.min(1, this.t / 0.3), Ht = (mode === 'tornado' ? 3.4 : 1.5 + tall(target) * 0.9) * grow;
        for (let i = 0; i < 3; i++) { const f = Math.random(), ang = this.t * 8 + Math.random() * 6.3, r = mode === 'tornado' ? 0.3 + f * f * 1.7 : 1.1 - f * 0.25; particle({ x: c.x + Math.cos(ang) * r, y: f * Ht, z: c.z + Math.sin(ang) * r, vx: -Math.sin(ang) * 3, vz: Math.cos(ang) * 3, vy: mode === 'tornado' ? 1.5 : 0.6, life: 0.35, size: rnd(0.08, 0.2), col: cols[i], shape: mode === 'tornado' && type === 'Dragon' ? 'shard' : mode === 'tornado' ? (Math.random() < 0.5 ? 'leaf' : 'wisp') : L.shapes[i % L.shapes.length], spin: 8 }); }
        if (!hit && this.t >= travel + 0.15) { hit = true; onHit?.(); } },
      draw(ctx) {
        const t = this.t, c = where(t), grow = Math.min(1, t / 0.3), fade = Math.min(1, (this.life - t) / 0.35);
        const Ht = (mode === 'tornado' ? 4.2 : 1.5 + tall(target) * 0.9) * grow, rings = mode === 'tornado' ? 18 : 11, SEG = 18;
        ctx.save(); ctx.lineCap = 'round';
        if (mode === 'pool') { // the churning water on the ground
          for (let r0 = 0.5; r0 <= 2; r0 += 0.35) { const pts = []; for (let j = 0; j <= SEG; j++) { const an = (j / SEG) * Math.PI * 1.4 + t * (5 - r0) + r0 * 2; pts.push(project({ x: c.x + Math.cos(an) * r0, y: 0.03, z: c.z + Math.sin(an) * r0 })); }
            if (pts.every(Boolean)) { ctx.globalAlpha = 0.5 * fade; ctx.strokeStyle = r0 > 1.2 ? L.col2 : L.col; ctx.lineWidth = Math.max(2, pts[0].k * 0.05); ctx.beginPath(); pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y))); ctx.stroke(); } }
        }
        for (let i = 0; i < rings; i++) {
          const f = i / (rings - 1), y = f * Ht;
          const r = mode === 'tornado' ? 0.3 + f * f * 2.1 : 1.15 - f * 0.3 + Math.sin(f * 6 + t * 4) * 0.06;
          const sway = mode === 'tornado' ? Math.sin(t * 2.6 + f * 2.5) * 0.35 * f : 0, sway2 = mode === 'tornado' ? Math.cos(t * 2.1 + f * 2) * 0.2 * f : 0;
          const spin = t * (mode === 'tornado' ? 9 : 6) * (1 + f * 0.6) + i * 0.7;
          for (let b = 0; b < 3; b++) { // three bands per level, each a part of the ring
            const pts = []; for (let j = 0; j <= 6; j++) { const an = spin + b * 2.1 + (j / 6) * 1.5; pts.push(project({ x: c.x + sway + Math.cos(an) * r, y, z: c.z + sway2 + Math.sin(an) * r })); }
            if (!pts.every(Boolean)) continue;
            ctx.globalAlpha = (0.5 + 0.35 * (b === 0)) * fade; ctx.strokeStyle = cols[(i + b) % 3]; ctx.lineWidth = Math.max(2.5, pts[3].k * (mode === 'tornado' ? 0.12 : 0.11) * (0.6 + f * 0.6));
            ctx.beginPath(); pts.forEach((q, j) => (j ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y))); ctx.stroke();
          }
        }
        ctx.restore();
      } });
  }
  // Weather Ball: its trail, by what the weather has made it (flames, rain, hail, sand)
  function trailOf(type, life = 1.2) { const L = lookOf(type); fx.push({ t: 0, life, update() { const q = flying; if (!q) return; for (let i = 0; i < 4; i++) particle({ x: q.x + rnd(-0.15, 0.15), y: q.y + rnd(-0.15, 0.15), z: q.z + rnd(-0.15, 0.15), vx: rnd(-0.5, 0.5), vy: type === 'Fire' ? rnd(0.4, 1.4) : rnd(-0.8, 0.3), vz: rnd(-0.5, 0.5), g: type === 'Water' ? -4 : 0, life: 0.45, size: rnd(0.1, 0.22), col: i % 2 ? L.col : L.col2, shape: L.shapes[i % L.shapes.length], spin: 6 }); if (Math.random() < 0.3) lightFlash(q, rgbOf(L.col), { r: 3, i: 0.7, life: 0.12 }); } }); }
  // webs (String Shot, Electroweb, Sticky Web, Spider Web, Toxic Thread): a strand is shot out and opens into a
  // web as it flies; it wraps round the target and clings there (or is laid on the ground on their side)
  function webShot(from, to, type, { dur = 0.6, ground = false, electric = false, miss = false, onHit } = {}) {
    const colA = electric ? '#fff27a' : type === 'Poison' ? '#d9a0ff' : '#ffffff', colB = electric ? '#ffd23a' : type === 'Poison' ? '#a860e0' : '#cfd8e6';
    let hit = false; const stick = ground ? 1.6 : 0.9, spin0 = Math.random() * 6;
    const drawWeb = (ctx, c, R, flat, alpha, rot) => {
      const P3 = (an, r) => (flat ? { x: c.x + Math.cos(an) * r, y: 0.04, z: c.z + Math.sin(an) * r * 0.8 } : (() => { const { p } = sideOf(from); return { x: c.x + p.x * Math.cos(an) * r, y: c.y + Math.sin(an) * r, z: c.z + p.z * Math.cos(an) * r }; })());
      const qc = project(flat ? { x: c.x, y: 0.04, z: c.z } : c); if (!qc) return;
      ctx.save(); ctx.globalAlpha = alpha; ctx.lineCap = 'round'; ctx.shadowColor = colB; ctx.shadowBlur = electric ? 10 : 4;
      const spokes = 8, rings = 4, pts = [];
      for (let j = 0; j < spokes; j++) { const an = rot + (j / spokes) * Math.PI * 2, row = []; for (let r = 1; r <= rings; r++) { const q = project(P3(an, (R * r) / rings)); if (!q) { ctx.restore(); return; } row.push(q); } pts.push(row); }
      ctx.strokeStyle = colA; ctx.lineWidth = Math.max(1.2, qc.k * 0.022);
      ctx.beginPath(); for (const row of pts) { ctx.moveTo(qc.x, qc.y); ctx.lineTo(row[rings - 1].x, row[rings - 1].y); } ctx.stroke();
      ctx.strokeStyle = colB; ctx.lineWidth = Math.max(1, qc.k * 0.014);
      for (let r = 0; r < rings; r++) { ctx.beginPath(); for (let j = 0; j <= spokes; j++) { const a = pts[j % spokes][r], b = pts[(j + 1) % spokes][r]; if (j === 0) ctx.moveTo(a.x, a.y); const mx = (a.x + b.x) / 2 + (qc.x - (a.x + b.x) / 2) * 0.14, my = (a.y + b.y) / 2 + (qc.y - (a.y + b.y) / 2) * 0.14; ctx.quadraticCurveTo(mx, my, b.x, b.y); } ctx.stroke(); }
      ctx.restore();
    };
    fx.push({ t: 0, life: dur + stick,
      update() {
        if (!hit && this.t >= dur) { hit = true; onHit?.(); if (!miss) { burst(chest(to, 0.5), colA, 10, { shape: 'dot', speed: 1.4 }); if (electric) { bolts(to, { fromSky: false, from: to }); lightFlash(chest(to), [255, 240, 120], { r: 4, i: 0.9, life: 0.25 }); } } }
        if (electric && this.t > dur && !miss && Math.random() < 0.4) particle({ ...chest(to, rnd(0.2, 0.9)), x: chest(to).x + rnd(-0.5, 0.5), vx: rnd(-1, 1), vy: rnd(-1, 1), life: 0.15, size: 0.12, col: '#fff27a', shape: 'spark' });
      },
      draw(ctx) {
        const A = muzzle(from, to), B = chest(to, 0.5), t = this.t;
        if (t < dur) { // in flight: opening up as it goes, a strand trailing back to its maker
          const k = t / dur, c = { x: lerp(A.x, B.x, k), y: lerp(A.y, B.y, k) + Math.sin(k * Math.PI) * 0.7, z: lerp(A.z, B.z, k) };
          const qa = project(A), qc = project(c);
          if (qa && qc) { ctx.save(); ctx.strokeStyle = colA; ctx.globalAlpha = 0.8; ctx.lineWidth = Math.max(1, qc.k * 0.016); ctx.beginPath(); ctx.moveTo(qa.x, qa.y); ctx.quadraticCurveTo((qa.x + qc.x) / 2, Math.min(qa.y, qc.y) - 10, qc.x, qc.y); ctx.stroke(); ctx.restore(); }
          drawWeb(ctx, c, (0.25 + k * 0.85) * (0.8 + tall(to) * 0.4), false, 0.95, spin0 + t * 3);
        } else if (!miss) { // caught: clinging to it (or lying on the ground), then wearing away
          const k = (t - dur) / stick, alpha = Math.min(1, (1 - k) * 2.2);
          if (ground) { const hp = home0(to); drawWeb(ctx, { x: hp.x, y: 0, z: hp.z }, 1.9, true, 0.9 * alpha, spin0); }
          else drawWeb(ctx, chest(to, 0.5), (1.1 - Math.min(0.25, k * 2) ) * (0.8 + tall(to) * 0.4), false, 0.95 * alpha, spin0 + dur * 3);
        }
      } });
  }
  function shield(side, col = '#7affd8') { const b = chest(side); fx.push({ t: 0, life: 1.1, draw(ctx) { const q = project(b); if (!q) return; const k = this.t / this.life, r = q.k * tall(side) * 0.75 * (0.9 + Math.min(1, k * 5) * 0.1);
    ctx.save(); ctx.globalAlpha = (1 - Math.max(0, k - 0.7) / 0.3) * 0.75; const g = ctx.createRadialGradient(q.x, q.y, r * 0.6, q.x, q.y, r); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, col); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(q.x, q.y, r, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.stroke(); ctx.restore(); } }); }
  function wall(side, col) { const { u, p, dir } = sideOf(side), b = chest(side, 0); fx.push({ t: 0, life: 1.0, draw(ctx) { const c = { x: b.x + u.x * dir * 1.3, z: b.z + u.z * dir * 1.3 }; const pts = [[-1.4, 0], [1.4, 0], [1.4, 2.2], [-1.4, 2.2]].map(([w, y]) => project({ x: c.x + p.x * w, y, z: c.z + p.z * w })); if (pts.some((q) => !q)) return;
    ctx.save(); ctx.globalAlpha = Math.sin((this.t / this.life) * Math.PI) * 0.55; ctx.fillStyle = col; ctx.beginPath(); pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y))); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.stroke(); ctx.restore(); } }); }
  function explosion(side) { const b = chest(side); screenFlash('#ffffff', 420); shake = 2.2; for (let i = 0; i < 3; i++) setTimeout(() => ring(b, i % 2 ? '#ffd23f' : '#ff7a2a', { r1: 4 + i, life: 0.7, w: 8 }), i * 90); burst(b, '#ff9a3a', 40, { speed: 5, shape: 'flame', size: 0.3 }); crowdFlash(16); }
  function notes(from, col) { const a = chest(from, 0.8); for (let i = 0; i < 8; i++) particle({ x: a.x, y: a.y, z: a.z, vx: rnd(-1.5, 1.5), vy: rnd(0.3, 1.2), vz: rnd(-1, 1), life: 1, size: 0.22, col, shape: 'note' }); }
  function glare(from, to) { const a = chest(from, 0.8); for (const s2 of [-0.12, 0.12]) particle({ x: a.x + s2, y: a.y, z: a.z, life: 0.5, size: 0.3, col: '#ff3a3a', shape: 'star' }); screenFlash('rgba(255,40,40,.35)', 260); aura(to, '#6aa0ff', { up: false, n: 12 }); }
  // the crowd in the stands: camera flashes going off when something big happens (stadium and colosseum)
  function crowdFlash(n = 10) {
    if (!['stadium', 'colosseum'].includes(P.arena ?? P.id)) return;
    const big = P.id === 'stadium' ? [22, 19] : [20, 17];
    for (let i = 0; i < n; i++) setTimeout(() => { const ang = Math.random() * Math.PI * 2, r = 0.85 + Math.random() * 0.25; particle({ x: Math.cos(ang) * big[0] * r, y: 2 + Math.random() * 6, z: 5 + Math.sin(ang) * big[1] * r, life: 0.18, size: 0.5, col: '#ffffff', shape: 'star' }); }, i * 70 + Math.random() * 400);
  }

  // ---------- things on the camera lens: splashes, dirt, snow, embers, sparks, sunbeams, rain ----------
  let terrainNow = null, critNow = false;
  const lastPct = [1, 1];
  let slowmo = 0, weatherNow = null, moveExtra = 0, celebrated = false, animHits = 0, camTurn = Math.floor(Math.random() * 12), damageWait = 0;
  const lens = [];
  let m0type = '';
  // a raindrop on the lens: it hits (a little splash), clings as a bead, and the bigger ones break loose and run
  // down in fits and starts, leaving a wet trail and a few beads behind; small ones just dry up
  function newDrop(kind, x, y, t0, H) {
    const big = Math.random() < 0.35, r = big ? 7 + Math.random() * 9 : 2.5 + Math.random() * 4.5;
    return { kind, x, y, r, t: t0, life: big ? 6 + Math.random() * 4 : 2.5 + Math.random() * 3, slideAt: big ? 0.4 + Math.random() * 2.2 : 99, vy: 0, wob: Math.random() * 6, trail: [], H, rain: true };
  }
  function lensHit(kind, n = 10) {
    const W = yard.W || 960, H = yard.H || 540;
    if (kind === 'sun') { lens.push({ kind, t: 0, life: 2.2 }); return; }
    if (kind === 'mist' || kind === 'mistPink') { lens.push({ kind, t: 0, life: 1.8 }); return; }
    if (kind === 'rain') { for (let i = 0; i < 22; i++) lens.push(newDrop('drop', Math.random() * W, Math.random() * H, -Math.random() * 2.2, H)); return; }
    if (kind === 'drop' || kind === 'dropPoison') { for (let i = 0; i < Math.round(n * 0.8); i++) { const edge = Math.random() < 0.6; lens.push(newDrop(kind, edge ? (Math.random() < 0.5 ? Math.random() * W * 0.3 : W - Math.random() * W * 0.3) : Math.random() * W, Math.random() * H * 0.85, -Math.random() * 0.35, H)); } return; }
    if (kind === 'dirt' || kind === 'mud' || kind === 'snow' || kind === 'dust') n = Math.round(n * 1.7); // grit lands as often and as thickly as water does
    for (let i = 0; i < n; i++) {
      const edge = Math.random() < 0.7; // most land towards the edges
      const x = edge ? (Math.random() < 0.5 ? Math.random() * W * 0.28 : W - Math.random() * W * 0.28) : Math.random() * W, y = Math.random() * H;
      const dropLike = kind === 'drop' || kind === 'dropPoison';
      if (kind === 'scorch') { lens.push({ kind, x, y, r: 18 + Math.random() * 26, t: -Math.random() * 0.15, life: 2.4 + Math.random(), vx: 0, vy: 0, rot: Math.random() * 6 }); continue; }
      if (kind === 'smoke') { lens.push({ kind, x, y, r: 14 + Math.random() * 22, t: -Math.random() * 0.2, life: 1.6 + Math.random() * 0.8, vx: (Math.random() - 0.5) * 20, vy: -10 - Math.random() * 14, rot: 0, tint: m0type === 'Ghost' ? [120, 70, 170] : [40, 30, 50] }); continue; }
      if (kind === 'mud') { lens.push({ kind, x, y, r: 4 + Math.random() * 15, t: -Math.random() * 0.25, life: 2.8 + Math.random() * 1.2, vx: (Math.random() - 0.5) * 8, vy: 2 + Math.random() * 6, rot: Math.random() * 6 }); continue; }
      if (kind === 'dirt') { // dry dust and grit: soft puffs that drift and fade, a few specks
        const speck = Math.random() < 0.35; lens.push({ kind, speck, x, y, r: speck ? 1.5 + Math.random() * 3 : 14 + Math.random() * 26, t: -Math.random() * 0.25, life: speck ? 1.6 + Math.random() : 1.1 + Math.random() * 0.9, vx: (Math.random() - 0.5) * 26, vy: speck ? 14 + Math.random() * 20 : -4 + Math.random() * 10, rot: Math.random() * 6 }); continue; }
      lens.push({ kind, x, y, r: dropLike ? 12 + Math.random() * 34 : kind === 'leaf' || kind === 'feather' ? 8 + Math.random() * 10 : kind === 'shard' || kind === 'scale' ? 3 + Math.random() * 5 : kind === 'dirt' ? 4 + Math.random() * 15 : kind === 'snow' ? 5 + Math.random() * 12 : kind === 'dust' ? 4 + Math.random() * 10 : 3 + Math.random() * 6, t: -Math.random() * 0.25, life: dropLike ? 2.6 + Math.random() : kind === 'dirt' ? 2.8 + Math.random() * 1.2 : kind === 'snow' ? 3 + Math.random() * 1.5 : kind === 'dust' ? 2.2 + Math.random() : 1.3 + Math.random(), vx: (Math.random() - 0.5) * (kind === 'snow' || kind === 'dirt' ? 8 : 40), vy: kind === 'snow' ? 3 + Math.random() * 8 : kind === 'dirt' ? 2 + Math.random() * 6 : kind === 'leaf' || kind === 'feather' ? 50 + Math.random() * 40 : kind === 'ember' ? -40 - Math.random() * 40 : dropLike ? 8 + Math.random() * 16 : 0, rot: Math.random() * 6 });
    }
  }
  // The lens is drawn small (a fifth of the picture’s size) with hard-edged, few-step transparency, then
  // blown up without smoothing: chunky pixels like the rest of the app.
  const LENS_PX = 5;
  let lensCv = null, lensX = null;
  function stepDrop(d, dt) {
    if (d.t < 0) return;
    if (d.t >= d.slideAt && d.r > 5) { // running: speeds up, catches, lets go again; wanders a little side to side
      const stick = Math.sin(d.t * 3.1 + d.wob) > 0.55 ? 0.15 : 1;
      d.vy = Math.min(140 + d.r * 6, d.vy + (60 + d.r * 12) * dt) * stick + (1 - stick) * d.vy * 0.2;
      d.y += d.vy * dt; d.x += Math.sin(d.t * 5 + d.wob) * 6 * dt;
      const last = d.trail[d.trail.length - 1];
      if (!last || d.y - last.y > 3) { d.trail.push({ x: d.x, y: d.y - d.r * 0.4, t: d.t, gap: Math.random() < 0.22 }); if (d.trail.length > 40) d.trail.shift(); }
      // it leaves a few little beads behind, and gets a little smaller for it
      if (Math.random() < dt * 2.2 && d.r > 6) { lens.push({ kind: d.kind, x: d.x + (Math.random() - 0.5) * 2, y: d.y - d.r * 1.2, r: 1.8 + Math.random() * 2.2, t: 0.2, life: 1.8 + Math.random() * 1.5, slideAt: 99, vy: 0, wob: 0, trail: [], H: d.H, rain: true }); d.r *= 0.97; }
      if (d.y > d.H + 30) d.t = d.life;
    }
  }
  function drawRain(c2) {
    const any = lens.some((d) => d.rain && d.t >= 0); if (!any) return;
    c2.save();
    for (const d of lens) {
      if (!d.rain || d.t < 0) continue;
      const k = d.t / d.life, fade = Math.min(1, (1 - k) * 4), poison = d.kind === 'dropPoison';
      const impact = Math.min(1, d.t / 0.09), r = d.r * (0.45 + 0.55 * impact) * (d.vy > 1 || d.t < d.slideAt ? 1 : 1 - Math.max(0, k - 0.6) * 1.2);
      if (r < 0.8) continue;
      // the splash as it lands
      if (d.t < 0.18) { c2.globalAlpha = (1 - d.t / 0.18) * 0.55; c2.strokeStyle = 'rgba(235,245,255,.9)'; c2.lineWidth = 1; c2.beginPath(); c2.arc(d.x, d.y, r * (1 + d.t * 9), 0, Math.PI * 2); c2.stroke(); }
      // the wet trail behind a running drop: a faint streak that dries from the top
      if (d.trail.length > 1) { c2.lineCap = 'round'; for (let i = 1; i < d.trail.length; i++) { const a = d.trail[i - 1], b = d.trail[i], age = d.t - b.t; if (b.gap) continue; const al = Math.max(0, 0.13 - age * 0.11) * fade; if (al <= 0.01) continue; const w = Math.max(0.8, d.r * 0.28 * (1 - Math.min(0.6, age * 0.4)));
          // a thin film of water: a dark edge either side and a pale core, like a real streak on glass
          c2.globalAlpha = al * 0.8; c2.strokeStyle = 'rgba(10,20,30,1)'; c2.lineWidth = w + 1.2; c2.beginPath(); c2.moveTo(a.x, a.y); c2.lineTo(b.x, b.y); c2.stroke();
          c2.globalAlpha = al; c2.strokeStyle = poison ? 'rgba(200,150,240,1)' : 'rgba(225,238,250,1)'; c2.lineWidth = w; c2.beginPath(); c2.moveTo(a.x, a.y); c2.lineTo(b.x, b.y); c2.stroke(); } }
      // the bead itself: round when it sits, drawn out into a teardrop as it runs
      const stretch = 1 + Math.min(1.1, d.vy / 120), rx = r * (1 - Math.min(0.25, d.vy / 400)), ry = r * stretch;
      const path = () => { c2.beginPath(); c2.moveTo(d.x, d.y - ry * 1.15); c2.bezierCurveTo(d.x + rx * 0.55, d.y - ry * 0.6, d.x + rx, d.y - ry * 0.05, d.x + rx, d.y + ry * 0.25); c2.arc(d.x, d.y + ry * 0.25, rx, 0, Math.PI); c2.bezierCurveTo(d.x - rx, d.y - ry * 0.05, d.x - rx * 0.55, d.y - ry * 0.6, d.x, d.y - ry * 1.15); c2.closePath(); };
      // what's behind it, seen through it: upside down and squeezed in (real water on a lens)
      if (!lowFx && r >= 3) { try { c2.save(); path(); c2.clip(); c2.globalAlpha = 0.9 * fade; const R = Math.max(rx, ry) * 2.2, cy = d.y + ry * 0.1; c2.translate(d.x, cy); c2.scale(-1, -1); c2.drawImage(canvas, Math.max(0, d.x - R * 1.8), Math.max(0, cy - R * 1.8), R * 3.6, R * 3.6, -R, -R, R * 2, R * 2); c2.restore(); } catch { c2.restore(); } }
      // its edge: darker at the bottom, a bright rim of light at the top, a pin of highlight
      c2.globalAlpha = 0.9 * fade; const g = c2.createLinearGradient(d.x, d.y - ry, d.x, d.y + ry * 1.25); g.addColorStop(0, 'rgba(255,255,255,.55)'); g.addColorStop(0.45, poison ? 'rgba(170,90,210,.1)' : 'rgba(200,220,240,.06)'); g.addColorStop(1, poison ? 'rgba(60,20,80,.5)' : 'rgba(20,30,45,.45)');
      c2.strokeStyle = g; c2.lineWidth = Math.max(1, r * 0.2); path(); c2.stroke();
      if (poison) { c2.globalAlpha = 0.25 * fade; c2.fillStyle = '#b85ae0'; path(); c2.fill(); }
      c2.globalAlpha = 0.9 * fade; c2.fillStyle = 'rgba(255,255,255,.95)'; c2.beginPath(); c2.ellipse(d.x - rx * 0.32, d.y - ry * 0.25, Math.max(0.6, rx * 0.16), Math.max(0.5, ry * 0.11), -0.5, 0, Math.PI * 2); c2.fill();
      c2.globalAlpha = 0.45 * fade; c2.fillStyle = 'rgba(255,255,255,.8)'; c2.beginPath(); c2.ellipse(d.x + rx * 0.25, d.y + ry * 0.75, Math.max(0.5, rx * 0.3), Math.max(0.4, ry * 0.08), 0, 0, Math.PI * 2); c2.fill();
    }
    c2.restore();
  }
  function drawLens(ctxMain, dt) {
    if (!lens.length) return;
    const W = yard.W || 960, H = yard.H || 540;
    const lw = Math.max(1, Math.ceil(W / LENS_PX)), lh = Math.max(1, Math.ceil(H / LENS_PX));
    if (!lensCv) { lensCv = document.createElement('canvas'); lensX = lensCv.getContext('2d', { willReadFrequently: true }); }
    if (lensCv.width !== lw || lensCv.height !== lh) { lensCv.width = lw; lensCv.height = lh; }
    const ctx = lensX;
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, lw, lh);
    ctx.setTransform(1 / LENS_PX, 0, 0, 1 / LENS_PX, 0, 0);
    ctx.save();
    for (let i = lens.length - 1; i >= 0; i--) {
      const d = lens[i]; d.t += dt; if (d.t >= d.life) { lens.splice(i, 1); continue; } if (d.t < 0) continue;
      const k = d.t / d.life, fade = Math.min(1, (1 - k) * 3);
      if (d.vx != null && !d.rain) { d.x += d.vx * dt; d.y += d.vy * dt; }
      if (d.rain) { stepDrop(d, dt); }
      else if (d.kind === 'drop' || d.kind === 'dropPoison') { // a drop on the lens: a lens of its own, dark rim, bright highlight, sliding down
        const tint = d.kind === 'drop' ? [208, 226, 240] : [190, 110, 230];
        const tear = (c2) => { c2.beginPath(); c2.moveTo(d.x, d.y - d.r * 1.7); c2.bezierCurveTo(d.x + d.r * 0.35, d.y - d.r * 0.9, d.x + d.r, d.y - d.r * 0.25, d.x + d.r, d.y + d.r * 0.25); c2.arc(d.x, d.y + d.r * 0.25, d.r, 0, Math.PI); c2.bezierCurveTo(d.x - d.r, d.y - d.r * 0.25, d.x - d.r * 0.35, d.y - d.r * 0.9, d.x, d.y - d.r * 1.7); c2.closePath(); };
        d.tear = tear; d.fade = fade;
        ctx.globalAlpha = 0.9 * fade;
        const cy = d.y + d.r * 0.25, g = ctx.createRadialGradient(d.x - d.r * 0.25, cy - d.r * 0.3, d.r * 0.05, d.x, cy, d.r * 1.25);
        g.addColorStop(0, 'rgba(255,255,255,.55)'); g.addColorStop(0.35, `rgba(${tint},.12)`); g.addColorStop(0.78, `rgba(${tint.map((v) => Math.round(v * 0.45))},.3)`); g.addColorStop(0.95, 'rgba(255,255,255,.65)'); g.addColorStop(1, 'rgba(255,255,255,.2)');
        ctx.fillStyle = g; tear(ctx); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.85)'; ctx.beginPath(); ctx.ellipse(d.x - d.r * 0.35, cy - d.r * 0.35, d.r * 0.18, d.r * 0.1, -0.6, 0, Math.PI * 2); ctx.fill();
        if (d.vy > 0) { ctx.globalAlpha = 0.22 * fade; ctx.strokeStyle = `rgba(${tint},.8)`; ctx.lineWidth = Math.max(2, d.r * 0.2); ctx.beginPath(); ctx.moveTo(d.x, d.y - d.r * 1.7); ctx.lineTo(d.x, d.y - d.r * 1.7 - d.t * 30); ctx.stroke(); }
      } else if (d.kind === 'dust') { ctx.globalAlpha = 0.6 * fade; ctx.fillStyle = '#d8c8a8'; ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2); ctx.fill(); }
      else if (d.kind === 'leaf') { ctx.globalAlpha = fade; ctx.save(); ctx.translate(d.x, d.y); ctx.rotate(d.rot + d.t * 3); ctx.fillStyle = '#4fbf4a'; ctx.beginPath(); ctx.ellipse(0, 0, d.r, d.r * 0.45, 0, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#2a7a2a'; ctx.beginPath(); ctx.moveTo(-d.r, 0); ctx.lineTo(d.r, 0); ctx.stroke(); ctx.restore(); }
      else if (d.kind === 'mist' || d.kind === 'mistPink') { const a2 = Math.sin(k * Math.PI) * 0.55; const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.25, W / 2, H / 2, W * 0.7); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, d.kind === 'mist' ? `rgba(240,248,255,${a2})` : `rgba(255,150,220,${a2})`); ctx.globalAlpha = 1; ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); }
      else if (d.kind === 'drop0') {
        ctx.globalAlpha = 0.55 * fade; const g = ctx.createRadialGradient(d.x - d.r * 0.3, d.y - d.r * 0.3, d.r * 0.1, d.x, d.y, d.r);
        g.addColorStop(0, 'rgba(255,255,255,.55)'); g.addColorStop(0.6, 'rgba(160,210,255,.15)'); g.addColorStop(0.92, 'rgba(255,255,255,.5)'); g.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(d.x, d.y, d.r, d.r * 1.12, 0, 0, Math.PI * 2); ctx.fill();
      } else if (d.kind === 'dirt') { // dry: a pale tan haze of dust (or a speck of grit), gone in a moment
        if (d.speck) { ctx.globalAlpha = 0.8 * fade; ctx.fillStyle = '#a89068'; ctx.fillRect(d.x, d.y, Math.max(LENS_PX, d.r), Math.max(LENS_PX, d.r)); }
        else { const rr = d.r * (1 + k * 0.8); ctx.globalAlpha = 0.42 * Math.sin(Math.min(1, k * 1.15) * Math.PI); const g = ctx.createRadialGradient(d.x, d.y, 0, d.x, d.y, rr); g.addColorStop(0, 'rgba(214,196,160,.9)'); g.addColorStop(0.6, 'rgba(200,180,140,.45)'); g.addColorStop(1, 'rgba(200,180,140,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(d.x, d.y, rr, 0, Math.PI * 2); ctx.fill(); }
      } else if (d.kind === 'mud') { ctx.globalAlpha = 0.85 * fade; ctx.fillStyle = d.r > 6 ? '#6a4a2a' : '#8a6a42'; ctx.save(); ctx.translate(d.x, d.y); ctx.rotate(d.rot); ctx.beginPath(); ctx.moveTo(-d.r, 0); ctx.lineTo(0, -d.r * 0.7); ctx.lineTo(d.r * 0.9, d.r * 0.2); ctx.lineTo(0, d.r); ctx.closePath(); ctx.fill(); if (d.r > 8) { ctx.fillStyle = '#4e361e'; for (let j = 0; j < 4; j++) ctx.fillRect(Math.cos(j * 1.7 + d.rot) * d.r * 1.4, Math.sin(j * 2.3) * d.r * 1.3, LENS_PX, LENS_PX); } ctx.restore(); }
      else if (d.kind === 'scorch') { // a sooty scorch mark that fades away
        ctx.globalAlpha = 0.7 * fade; const g = ctx.createRadialGradient(d.x, d.y, 0, d.x, d.y, d.r); g.addColorStop(0, 'rgba(30,18,10,.9)'); g.addColorStop(0.55, 'rgba(70,40,20,.6)'); g.addColorStop(0.8, 'rgba(255,120,40,.35)'); g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g; ctx.save(); ctx.translate(d.x, d.y); ctx.rotate(d.rot); ctx.scale(1, 0.7); ctx.translate(-d.x, -d.y); ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2); ctx.fill(); ctx.restore(); }
      else if (d.kind === 'smoke') { ctx.globalAlpha = 0.55 * Math.sin(k * Math.PI); const g = ctx.createRadialGradient(d.x, d.y, 0, d.x, d.y, d.r * (1 + k)); g.addColorStop(0, `rgba(${d.tint},.85)`); g.addColorStop(1, `rgba(${d.tint},0)`); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(d.x, d.y, d.r * (1 + k), 0, Math.PI * 2); ctx.fill(); }
      else if (d.kind === 'feather') { ctx.globalAlpha = fade; ctx.save(); ctx.translate(d.x, d.y); ctx.rotate(d.rot + Math.sin(d.t * 4) * 0.6); ctx.fillStyle = '#f4f4f8'; ctx.beginPath(); ctx.ellipse(0, 0, d.r, d.r * 0.32, 0, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#a8b0c0'; ctx.beginPath(); ctx.moveTo(-d.r * 1.2, 0); ctx.lineTo(d.r, 0); ctx.stroke(); ctx.restore(); }
      else if (d.kind === 'shard' || d.kind === 'scale') { ctx.globalAlpha = 0.9 * fade; ctx.fillStyle = d.kind === 'shard' ? (d.r > 5 ? '#c8d0dc' : '#8a94a6') : (d.r > 5 ? '#9a7aff' : '#6ad08a'); ctx.save(); ctx.translate(d.x, d.y); ctx.rotate(d.rot); ctx.beginPath(); ctx.moveTo(0, -d.r); ctx.lineTo(d.r * 0.6, 0); ctx.lineTo(0, d.r); ctx.lineTo(-d.r * 0.6, 0); ctx.closePath(); ctx.fill(); ctx.restore(); }
      else if (d.kind === 'snow') { // a flake that sticks, then melts into a bead of water that runs down
        const melt = Math.max(0, Math.min(1, (k - 0.35) / 0.5)), arm = d.r * (1 - melt);
        if (arm > LENS_PX * 0.6) { ctx.globalAlpha = 0.95 * fade; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = Math.max(LENS_PX * 0.8, d.r * 0.22); ctx.beginPath(); for (let j = 0; j < 6; j++) { const an = d.rot + (j * Math.PI) / 3; ctx.moveTo(d.x, d.y); ctx.lineTo(d.x + Math.cos(an) * arm, d.y + Math.sin(an) * arm); } ctx.stroke(); }
        if (melt > 0) { ctx.globalAlpha = 0.7 * fade; const ry = d.y + melt * melt * d.r * 3; ctx.fillStyle = 'rgba(200,235,255,.75)'; ctx.beginPath(); ctx.arc(d.x, ry, Math.max(LENS_PX * 0.7, d.r * 0.45), 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.fillRect(d.x - d.r * 0.15, ry - d.r * 0.25, LENS_PX, LENS_PX); ctx.globalAlpha = 0.35 * fade; ctx.fillRect(d.x - LENS_PX / 2, d.y, LENS_PX, ry - d.y); } }
      else if (d.kind === 'ember') { ctx.globalAlpha = fade; const g = ctx.createRadialGradient(d.x, d.y, 0, d.x, d.y, d.r * 2.5); g.addColorStop(0, '#fff6b0'); g.addColorStop(0.4, '#ff9a2a'); g.addColorStop(1, 'rgba(255,80,20,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(d.x, d.y, d.r * 2.5, 0, Math.PI * 2); ctx.fill(); }
      else if (d.kind === 'spark') { ctx.globalAlpha = Math.random() < 0.5 ? fade : 0.2; ctx.strokeStyle = '#fff8a0'; ctx.lineWidth = LENS_PX * 1.3; ctx.beginPath(); ctx.moveTo(d.x, d.y); for (let j = 0; j < 3; j++) ctx.lineTo(d.x + (Math.random() - 0.5) * d.r * 6, d.y + (Math.random() - 0.5) * d.r * 6); ctx.stroke(); }
      else if (d.kind === 'rain') { ctx.globalAlpha = 0.45; ctx.strokeStyle = '#cfe6ff'; ctx.lineWidth = LENS_PX * 1.2; ctx.beginPath(); ctx.moveTo(d.x, d.y + k * 120); ctx.lineTo(d.x - 6, d.y + k * 120 + d.len); ctx.stroke(); }
      else if (d.kind === 'sun') { // sunbeams pouring in from the top corner, with lens flares
        const a = Math.sin(k * Math.PI) * 0.6; ctx.globalAlpha = a; ctx.globalCompositeOperation = 'lighter';
        for (let j = 0; j < 5; j++) { const ang = 0.5 + j * 0.16 + Math.sin(time + j) * 0.02; ctx.fillStyle = 'rgba(255,236,170,.18)'; ctx.beginPath(); ctx.moveTo(W * 0.92, -10); ctx.lineTo(W * 0.92 - Math.cos(ang) * W * 1.4 - 40, Math.sin(ang) * W * 1.4); ctx.lineTo(W * 0.92 - Math.cos(ang) * W * 1.4 + 40, Math.sin(ang) * W * 1.4); ctx.closePath(); ctx.fill(); }
        for (const [f, r, c] of [[0.35, 40, 'rgba(255,220,140,.25)'], [0.55, 22, 'rgba(160,255,200,.22)'], [0.75, 60, 'rgba(255,170,120,.15)']]) { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(W * 0.92 - W * 0.6 * f, H * 0.7 * f, r, 0, Math.PI * 2); ctx.fill(); }
        ctx.globalCompositeOperation = 'source-over';
      }
    }
    ctx.restore();
    // hard pixel edges: snap every pixel’s transparency to a few steps (no soft anti-aliased fringes), colours to a small palette
    try {
      const im = ctx.getImageData(0, 0, lw, lh), d = im.data;
      for (let i = 3; i < d.length; i += 4) { const a = d[i]; if (!a) continue; d[i] = a < 40 ? 0 : a < 110 ? 96 : a < 190 ? 168 : 235; d[i - 3] = (d[i - 3] & 0xe0) | 0x10; d[i - 2] = (d[i - 2] & 0xe0) | 0x10; d[i - 1] = (d[i - 1] & 0xe0) | 0x10; } // and a small palette
      ctx.putImageData(im, 0, 0);
    } catch { /* fine as it is */ }
    drawRain(ctxMain);
    ctxMain.save();
    ctxMain.imageSmoothingEnabled = false;
    ctxMain.drawImage(lensCv, 0, 0, lw * LENS_PX, lh * LENS_PX);
    ctxMain.restore();
  }
  // which moves throw things at the camera
  function lensFor(m, C, loose = false) {
    const name = String(m.name).toLowerCase(), dmg = m.cat !== 'Status', strong = m.bp >= 80 || loose;
    if (m.weather === 'sunnyday' || /solar|sunny|morning sun|synthesis/.test(name)) return 'sun';
    if (m.weather === 'raindance') return 'rain';
    if (m.weather === 'sandstorm') return 'dirt';
    if (m.weather === 'snow' || m.weather === 'hail' || m.weather === 'snowscape') return 'snow';
    if (m.terrain) return { electricterrain: 'spark', grassyterrain: 'leaf', mistyterrain: 'mist', psychicterrain: 'mistPink' }[m.terrain] ?? 'mist';
    if (!dmg) return null;
    if (m.type === 'Water') return 'drop';
    if (m.type === 'Fire') return 'ember';
    if (/mud/.test(name)) return 'mud';
    if (m.type === 'Ground' || m.type === 'Rock' || C.kind === 'quake' || (C.kind === 'burrow' && !C.splash)) return 'dirt';
    if (m.type === 'Ice') return 'snow';
    if (m.type === 'Electric' && (strong || C.kind === 'thunder')) return 'spark';
    if (m.type === 'Grass' && (strong || m.cat === 'Special')) return 'leaf';
    if (m.type === 'Poison' && (/sludge|gunk|acid/.test(name) || loose)) return 'dropPoison';
    if ((m.type === 'Psychic' || m.type === 'Fairy') && strong) return 'mistPink';
    if (C.kind === 'explosion') return 'ember';
    // up close, the rest leave their mark too: soot from Dark and Ghost, feathers, metal flecks, scales, dust
    if (loose) {
      if (m.type === 'Dark' || m.type === 'Ghost') return 'smoke';
      if (m.type === 'Flying') return 'feather';
      if (m.type === 'Steel') return 'shard';
      if (m.type === 'Dragon' || m.type === 'Bug') return 'scale';
    }
    if (m.flags?.contact && strong) return 'dust';
    return null;
  }
  // a powerful move (Hyper Beam, Giga Impact, Blast Burn, Explosion…): the scene dims, power gathers, then it lands like a bomb
  const dim = (on) => el.classList.toggle('dim', on);
  function smoke(at, n = 10) { for (let i = 0; i < n; i++) particle({ x: at.x + rnd(-0.6, 0.6), y: at.y * rnd(0.2, 1), z: at.z + rnd(-0.4, 0.4), vx: rnd(-0.6, 0.6), vy: rnd(0.2, 0.7), vz: rnd(-0.3, 0.3), life: rnd(1.4, 2.2), size: rnd(0.5, 0.9), col: 'rgba(200,196,190,.55)', shape: 'wisp' }); }
  function bigImpact(side, col) { const at = chest(side); screenFlash('#ffffff', 380); shake = Math.max(shake, 2.2); for (let i = 0; i < 3; i++) setTimeout(() => ring(at, i % 2 ? '#ffffff' : col, { r1: 3 + i * 1.3, life: 0.6, w: 7 }), i * 80); burst(at, col, 34, { speed: 4.5, size: 0.24 }); burst(at, '#ffffff', 14, { speed: 5, shape: 'star', size: 0.14 }); smoke(chest(side, 0.3), 12); crowdFlash(18); }

  // one of Showdown's effect pictures popping at a spot (an impact star, a fist, a bite, a slash)
  function fxPop(at, name, { size = 1, life = 0.35, spin = 0 } = {}) {
    if (!fxImage(resolveTexture, name)) return false;
    fx.push({ t: 0, life, draw(ctx) { const im = fxImage(resolveTexture, name), q = project(at); if (!im || !q) return; const k = this.t / this.life, w = q.k * size * (0.7 + ease(Math.min(1, k * 3)) * 0.5);
      ctx.save(); ctx.globalAlpha = 1 - Math.max(0, k - 0.6) / 0.4; ctx.translate(q.x, q.y); ctx.rotate(spin * k); ctx.drawImage(im, -w / 2, -w / 2, w, w); ctx.restore(); } });
    return true;
  }
  // a big word stamped across the screen ("CRITICAL HIT!")
  function stamp(word, col) { fx.push({ t: 0, life: 1.2, draw(ctx) { const k = this.t / this.life, W = yard.W, H = yard.H, sc = 1 + Math.max(0, 0.25 - k) * 3; ctx.save(); ctx.globalAlpha = Math.min(1, (1 - k) * 3); ctx.translate(W / 2, H * 0.42); ctx.rotate(-0.06); ctx.scale(sc, sc); ctx.font = `900 ${Math.round(H * 0.085)}px "Segoe UI", system-ui, sans-serif`; ctx.textAlign = 'center'; ctx.lineWidth = 8; ctx.strokeStyle = '#1a1020'; ctx.strokeText(word, 0, 0); ctx.fillStyle = col; ctx.fillText(word, 0, 0); ctx.restore(); } }); }
  // ---------- creatures out of reach (Fly, Dig, Dive, Phantom Force) and charging up ----------
  const vanished = [null, null];
  function vanish(side, how, type) {
    const a = actor(side); if (!a) return;
    vanished[side] = how;
    const L = lookOf(type), b = chest(side, 0);
    if (how === 'up') { move(side, 0.7, (k) => ({ ...home0(side), y: ease(k) * 9, alpha: 1 - Math.max(0, k - 0.6) * 2.5 }), { end() { const a2 = actor(side); if (a2) { a2.alpha = 0; } } }); for (let i = 0; i < 10; i++) particle({ x: b.x + rnd(-0.6, 0.6), y: 0.1, z: b.z + rnd(-0.4, 0.4), vy: rnd(1, 2), life: 0.6, size: 0.18, col: '#ffffff', shape: 'feather' }); }
    else if (how === 'under' || how === 'water') { move(side, 0.6, (k) => ({ ...home0(side), y: -ease(k) * 1.5, alpha: 1 - k }), { end() { const a2 = actor(side); if (a2) a2.alpha = 0; } }); burst({ x: b.x, y: 0.1, z: b.z }, how === 'water' ? '#6ac0ff' : '#b89060', 22, { speed: 2.5, shape: how === 'water' ? 'drop' : 'rock', up: 1.2 }); }
    else { fx.push({ t: 0, life: 0.7, update() { const a2 = actor(side); if (a2) a2.alpha = 1 - this.t / this.life; for (let i = 0; i < 2; i++) particle({ x: b.x + rnd(-0.6, 0.6), y: rnd(0, tall(side)), z: b.z + rnd(-0.3, 0.3), vy: rnd(0.3, 1), life: 0.6, size: 0.3, col: L.col, shape: 'wisp' }); }, end() { const a2 = actor(side); if (a2) a2.alpha = 0; } }); }
  }
  function unvanish(side) { vanished[side] = null; const a = actor(side); if (a) { a.alpha = 1; a.y = 0; } }
  function chargeUp(side, type) { // Solar Beam, Skull Bash, Meteor Beam… gathering power
    const L = lookOf(type), b = chest(side);
    lightFlash(b, type === 'Normal' ? [255, 200, 110] : rgbOf(L.col), { r: 3.6, i: 1, life: 1.1 }); // the power it gathers lights it up
    fx.push({ t: 0, life: 1.1, update() { for (let i = 0; i < 3; i++) { const ang = Math.random() * Math.PI * 2, r = 1.6; particle({ x: b.x + Math.cos(ang) * r, y: b.y + rnd(-0.6, 0.9), z: b.z + Math.sin(ang) * r * 0.6, vx: -Math.cos(ang) * r * 2.2, vy: 0, vz: -Math.sin(ang) * r * 1.3, life: 0.42, size: 0.07, col: i % 2 ? L.col : L.col2, shape: 'dot' }); } }, draw(ctx) { const q = project(b); if (q) { ctx.globalAlpha = 0.4; glow(ctx, q.x, q.y, q.k * 0.11 * (0.6 + this.t), L.col); ctx.globalAlpha = 1; } } });
  }

  // Power building up on the user during the close-up before a move, by type and by how strong it is:
  // flames licking up and embers flying off (Fire), a crackling yellow aura (Electric), a ball of water growing
  // in front of it and splashing (Water), debris lifting off the ground (Ground, Rock), wisps (Ghost), and so on.
  // Ranged moves gather into a glowing ball in front of the user, which is where they then fly from.
  function gather(from, to, m, C, dur) {
    if (!actor(from) || dur < 0.25) return;
    const type = m.type, L = lookOf(type), col = TYPE_COL[type] ?? L.col;
    const I = Math.max(0.45, Math.min(1.6, (m.bp || 50) / 90)), strong = I >= 0.95;
    const ranged = !['contact', 'zigzag', 'punch', 'kick', 'bite', 'slash', 'horn', 'tackleSpin', 'wrap', 'dive', 'burrow', 'phantom', 'quake', 'explosion'].includes(C.kind);
    // how it builds up, by what kind of move it is: a ball of energy only for the ones that are one (Shadow Ball,
    // Water Pulse, Aura Sphere, beams…); a breath gathering at the mouth for streams (Flamethrower, Water Gun);
    // power rising into the sky for ones that come down from it; a halo for physical ones; a quick flash for weak ones
    const nm = String(m.name).toLowerCase();
    const gs = /ball|sphere|pulse|bomb|blast|cannon|beam|orb|moonblast|aura|weather ball|mist ball|focus|zap|charge beam|signal/.test(nm) && ranged ? 'orb'
      : (C.stream || /breath|thrower|gun|pump|spray|jet|spit|smog|bubble|ember|flame|fire spin|scald|surf|muddy|hydro/.test(nm)) && ranged ? 'breath'
        : ['thunder', 'rockfall', 'rainDown', 'spikes', 'hazard'].includes(C.kind) ? 'sky'
          : (m.bp || 0) <= 40 && m.cat !== 'Status' ? 'quick'
            : C.kind === 'status' ? 'eyes' : 'halo';
    if (gs === 'quick') dur = Math.min(dur, 0.5);
    const motion = { Fire: 'rise', Ghost: 'rise', Poison: 'rise', Dark: 'rise', Electric: 'crackle', Steel: 'out', Fighting: 'out', Ground: 'debris', Rock: 'debris', Psychic: 'rings', Fairy: 'rings' }[type] ?? 'in';
    const ballCol = col, hgt = tall(from);
    let lensDone = false;
    fx.push({ t: 0, life: dur * 0.95, update(dt) {
      const k = this.t / this.life, g = Math.min(1, k * 1.25), rate = (6 + 18 * I) * dt * (0.5 + g) * (gs === 'quick' ? 0.35 : gs === 'breath' || gs === 'eyes' ? 0.3 : gs === 'sky' ? 0.5 : 1);
      const a = actor(from); if (!a) return;
      const base = { x: a.x, y: a.y || 0, z: a.z }, mid = chest(from, 0.5), M = muzzle(from, to);
      const n = Math.floor(rate) + (Math.random() < rate % 1 ? 1 : 0);
      for (let i = 0; i < n; i++) {
        const ang = Math.random() * Math.PI * 2, rr = 0.25 + hgt * 0.3;
        if (motion === 'rise') particle({ x: base.x + Math.cos(ang) * rr, y: base.y + rnd(0, hgt * 0.5), z: base.z + Math.sin(ang) * rr * 0.6, vx: rnd(-0.2, 0.2), vy: rnd(1, 2.2) * (type === 'Fire' ? 1.2 : 0.6), life: rnd(0.35, 0.7), size: rnd(0.1, 0.2) * (0.7 + I * 0.4), col: Math.random() < 0.35 ? L.col2 : col, shape: type === 'Fire' ? 'flame' : type === 'Poison' ? 'bubble' : 'wisp', g: type === 'Fire' ? 0.6 : 0 });
        else if (motion === 'crackle') particle({ x: mid.x, y: mid.y + rnd(-hgt * 0.3, hgt * 0.3), z: mid.z, vx: Math.cos(ang) * rnd(2, 3.5), vy: Math.sin(ang) * rnd(2, 3.5), vz: rnd(-0.5, 0.5), life: rnd(0.12, 0.25), size: 0.08, col: Math.random() < 0.4 ? '#ffffff' : col, shape: 'spark' });
        else if (motion === 'out') particle({ x: mid.x, y: mid.y, z: mid.z, vx: Math.cos(ang) * rnd(1.2, 2.2), vy: Math.sin(ang) * rnd(1.2, 2.2), life: 0.3, size: 0.1, col: Math.random() < 0.4 ? '#ffffff' : col, shape: 'star' });
        else if (motion === 'debris') particle({ x: base.x + Math.cos(ang) * (rr + 0.4), y: 0.05, z: base.z + Math.sin(ang) * (rr + 0.3) * 0.6, vx: rnd(-0.3, 0.3), vy: rnd(1.2, 2.6) * (0.6 + I * 0.4), g: 4.5, life: rnd(0.5, 0.8), size: rnd(0.08, 0.18), col: Math.random() < 0.5 ? L.col2 : col, shape: 'rock', spin: rnd(-6, 6) });
        else if (motion === 'rings') { if (Math.random() < 0.18) ring(mid, col, { r0: 0.2, r1: 1.2 + I * 0.5, life: 0.45, w: 2 }); particle({ x: mid.x + Math.cos(ang) * 1.1, y: mid.y + Math.sin(ang) * 0.8, z: mid.z, vx: -Math.cos(ang) * 2.4, vy: -Math.sin(ang) * 1.8, life: 0.45, size: 0.08, col, shape: type === 'Fairy' ? 'heart' : 'dot' }); }
        else { const tgt = ranged ? M : mid, r0 = 0.9 + I * 0.4; particle({ x: tgt.x + Math.cos(ang) * r0, y: tgt.y + Math.sin(ang) * r0 * 0.8, z: tgt.z + rnd(-0.3, 0.3), vx: -Math.cos(ang) * r0 * 2.6, vy: -Math.sin(ang) * r0 * 2.1, life: 0.38, size: rnd(0.07, 0.13), col: Math.random() < 0.35 ? L.col2 : col, shape: L.shapes[Math.floor(Math.random() * L.shapes.length)], spin: rnd(-6, 6) }); }
      }
      // power rising off it into the sky (it comes back down on the target)
      if (gs === 'sky' && Math.random() < 6 * I * dt) particle({ x: mid.x + rnd(-0.3, 0.3), y: mid.y + hgt * 0.4, z: mid.z, vx: rnd(-0.3, 0.3), vy: rnd(5, 8), life: 0.7, size: rnd(0.08, 0.14), col: Math.random() < 0.4 ? '#ffffff' : col, shape: type === 'Rock' || type === 'Ground' ? 'rock' : 'dot' });
      // a stream move breathes in: bits drawn into its mouth
      if (gs === 'breath' && Math.random() < 9 * dt) { const ang = Math.random() * Math.PI * 2, r0 = 0.7; particle({ x: M.x + Math.cos(ang) * r0, y: M.y + Math.sin(ang) * r0 * 0.7, z: M.z, vx: -Math.cos(ang) * r0 * 3.4, vy: -Math.sin(ang) * r0 * 2.4, life: 0.26, size: 0.06, col: Math.random() < 0.4 ? '#ffffff' : col, shape: L.shapes[0] }); }
      // a ranged move's ball of power in front of it: growing, with bits flying off it (water splashing)
      if (gs === 'orb') {
        const sp = (type === 'Water' ? 7 : 3) * I * g * dt;
        if (Math.random() < sp) particle({ ...M, vx: rnd(-2, 2), vy: rnd(0.4, 2.4), vz: rnd(-1.6, 0.6), g: type === 'Water' ? 7 : 2, life: rnd(0.35, 0.6), size: rnd(0.06, 0.12), col: Math.random() < 0.4 ? '#ffffff' : ballCol, shape: type === 'Water' ? 'drop' : L.shapes[0] });
      }
      // strong ones throw debris up from the ground around its feet too
      if (strong && motion !== 'debris' && Math.random() < 3 * dt * g) particle({ x: base.x + rnd(-0.8, 0.8), y: 0.05, z: base.z + rnd(-0.5, 0.5), vx: rnd(-0.6, 0.6), vy: rnd(1.4, 2.6), g: 6, life: 0.6, size: rnd(0.06, 0.12), col: '#9a8468', shape: 'rock', spin: rnd(-6, 6) });
      // right before it goes, a strong one splashes, scorches or sparks the camera that's up close
      if (!lensDone && k > 0.82 && strong && dynamic && (gs === 'orb' || gs === 'breath' || gs === 'halo')) { lensDone = true; const kind = { Water: 'drop', Fire: 'ember', Electric: 'spark', Ground: 'dirt', Rock: 'dirt', Ice: 'snow', Grass: 'leaf' }[type]; if (kind) lensHit(kind, Math.round(3 + I * 4)); }
      if (k > 0.5) shake = Math.max(shake, 0.12 * I);
    }, draw(ctx) {
      const k = this.t / this.life, g = Math.min(1, k * 1.25);
      const q = project(chest(from, 0.5)); if (!q) return;
      // the aura building round it
      // a halo, hollow in the middle so the creature itself stays clear (not for a quick move, or a breath)
      if (gs === 'eyes') { const e = project(chest(from, 0.78)); if (e) { ctx.save(); ctx.globalAlpha = Math.min(1, g * 1.5); glow(ctx, e.x - e.k * 0.08, e.y, e.k * 0.05, col); glow(ctx, e.x + e.k * 0.08, e.y, e.k * 0.05, col); ctx.restore(); } }
      if (gs === 'halo' || gs === 'orb' || gs === 'sky' || (gs === 'quick' && k > 0.5)) { const R = q.k * hgt * (0.5 + 0.3 * g), gr = ctx.createRadialGradient(q.x, q.y, R * 0.35, q.x, q.y, R), [r0, g0, b0] = rgbOf(col);
        const al = (type === 'Electric' ? 0.45 + Math.random() * 0.3 : 0.4) * g * Math.min(1, I);
        gr.addColorStop(0, `rgba(${r0},${g0},${b0},0)`); gr.addColorStop(0.6, `rgba(${r0},${g0},${b0},${al.toFixed(3)})`); gr.addColorStop(1, `rgba(${r0},${g0},${b0},0)`);
        ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(q.x, q.y, R, 0, Math.PI * 2); ctx.fill(); ctx.restore(); }
      if (motion === 'crackle' && Math.random() < 0.6) { // little arcs of electricity over it
        const r = q.k * hgt * 0.5; ctx.save(); ctx.strokeStyle = Math.random() < 0.5 ? '#fffbd0' : col; ctx.lineWidth = Math.max(1.2, q.k * 0.03); ctx.shadowColor = col; ctx.shadowBlur = 8;
        for (let j = 0; j < 1 + Math.round(I); j++) { let x = q.x + rnd(-r, r), y = q.y + rnd(-r, r); ctx.beginPath(); ctx.moveTo(x, y); for (let s2 = 0; s2 < 4; s2++) { x += rnd(-r * 0.45, r * 0.45); y += rnd(-r * 0.45, r * 0.45); ctx.lineTo(x, y); } ctx.stroke(); }
        ctx.restore();
      }
      if (gs === 'breath') { const mq = project(muzzle(from, to)); if (mq) { ctx.save(); ctx.globalAlpha = 0.7 * g; glow(ctx, mq.x, mq.y, mq.k * 0.05 * (1 + g), col); ctx.restore(); } }
      if (gs === 'orb') { const mq = project(muzzle(from, to)); if (mq) { const rad = mq.k * (0.04 + (0.07 + 0.04 * Math.min(1.2, I)) * g) * (1 + Math.sin(this.t * 30) * 0.06); glow(ctx, mq.x, mq.y, rad, col); if (type === 'Water') { ctx.save(); ctx.strokeStyle = 'rgba(220,245,255,.85)'; ctx.lineWidth = Math.max(1, rad * 0.12); ctx.beginPath(); ctx.arc(mq.x, mq.y, rad * 0.9, 0, Math.PI * 2); ctx.stroke(); ctx.restore(); } } }
    } });
    lightFlash(chest(from, 0.5), type === 'Normal' ? [255, 240, 220] : rgbOf(col), { r: 2.5 + I, i: Math.min(0.75, 0.35 + I * 0.25), life: dur * 0.9 });
  }

  // ---------- the move announcement and the announcer ----------
  let banTimer = null, castTimer = null, lastCast = 0;
  const nameOf = (side) => { const m = mons[side]?.info; const n = m?.name || m?.species || ''; return side === 1 && intro !== 'trainer' ? `The wild ${n}` : n; };
  let lastAnnounce = '';
  function announce(side, mv) {
    const key = `${side}|${mv.id}|${lastTurn}`;
    if (key === lastAnnounce) return; // once per move per turn (Dragon Darts' second dart isn't announced again)
    lastAnnounce = key;
    banner.querySelector('.who').textContent = `${nameOf(side)} used`;
    banner.querySelector('.mv').textContent = mv.name;
    banner.style.setProperty('--tc', lookOf(mv.type).col);
    banner.className = `bst-moveban on side${side}`;
    clearTimeout(banTimer); banTimer = setTimeout(() => banner.classList.remove("on"), 700 * Math.min(1.2, tempo()));
  }
  function cast(line, { force = false } = {}) {
    return; // the announcer's remarks are switched off
    // eslint-disable-next-line no-unreachable
    const now = performance.now();
    if (!force && now - lastCast < 2500) return;
    lastCast = now;
    caster.textContent = line;
    caster.classList.remove('on'); void caster.offsetWidth; caster.classList.add('on');
    clearTimeout(castTimer); castTimer = setTimeout(() => caster.classList.remove('on'), 3000);
  }
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  function notify(side, text, kind = 'info', col = null) {
    if (!text) return;
    const who = mons[side]?.info ? nameOf(side) : '';
    const n = h('div', { class: `bst-note ${kind} side${side ?? 'x'}` }, col ? h('i', { class: 'dot', style: { background: col } }) : null, h('span', {}, text), who && kind !== 'big' ? h('small', {}, who) : null);
    noteBox.append(n); while (noteBox.children.length > 4) noteBox.firstElementChild.remove();
    requestAnimationFrame(() => n.classList.add('on'));
    setTimeout(() => { n.classList.remove('on'); setTimeout(() => n.remove(), 300); }, 1900 * Math.min(1.3, tempo()));
  }
  // stat changes stay up (one note per stat per side, updated as it changes) until it's back to normal or it leaves
  const statNow = [{}, {}], statEls = [{}, {}];
  const STAT_NAME = { atk: 'Atk', def: 'Def', spa: 'Sp. Atk', spd: 'Sp. Def', spe: 'Speed', accuracy: 'Accuracy', evasion: 'Evasion' };
  function statNote(side, stat, mult, text, up) {
    const key = String(stat);
    statEls[side][key]?.remove(); delete statEls[side][key];
    if (mult != null) statNow[side][key] = mult;
    if (mult === 1) { delete statNow[side][key]; notify(side, `${STAT_NAME[key] ?? key} back to normal`, 'info', STAT_COL[key] ?? null); return; }
    const good = mult != null ? mult > 1 : up;
    const n = h('div', { class: `bst-note stat ${good ? 'good' : 'bad'} side${side}` }, h('i', { class: 'dot', style: { background: STAT_COL[key] ?? '#fff' } }), h('span', {}, mult != null ? `${STAT_NAME[key] ?? key} ${good ? '▲' : '▼'} ×${mult}` : text), h('small', {}, nameOf(side)));
    statBox.append(n); statEls[side][key] = n; requestAnimationFrame(() => n.classList.add('on'));
  }
  function clearStatNotes(side) { for (const k of Object.keys(statEls[side])) statEls[side][k].remove(); statEls[side] = {}; statNow[side] = {}; }
  const STAT_COL = { atk: '#ff5a4a', def: '#ff9f3a', spa: '#4a8cff', spd: '#5ad070', spe: '#ff6ad0', accuracy: '#e8e8e8', evasion: '#c8b8ff' };
  const STAT_OF = (t) => { const x = t.toLowerCase(); return /sp\.? ?atk|special attack|spa\b/.test(x) ? 'spa' : /sp\.? ?def|special defense|spd\b/.test(x) ? 'spd' : /atk|attack/.test(x) ? 'atk' : /def/.test(x) ? 'def' : /spe|speed/.test(x) ? 'spe' : /acc/.test(x) ? 'accuracy' : /eva/.test(x) ? 'evasion' : null; };
  function chevrons(side, up, stat) { const a = actor(side); if (!a) return; a.chev = { up, col: STAT_COL[stat] ?? (up ? '#ff5a4a' : '#4a8cff'), from: yard.time ?? 0, until: (yard.time ?? 0) + 1.8 }; }

  // ---------- acting out a move ----------
  const WB_TYPE = { sunnyday: 'Fire', desolateland: 'Fire', raindance: 'Water', primordialsea: 'Water', sandstorm: 'Rock', hail: 'Ice', snow: 'Ice', snowscape: 'Ice' };
  function playMove(ev) {
    let m = ev.move; const from = ev.from?.side;
    const weatherBall = /^weather ball$/i.test(m?.name ?? '');
    if (weatherBall && WB_TYPE[weatherNow]) m = { ...m, type: WB_TYPE[weatherNow], bp: 100 };
    if (from == null || !actor(from) && !vanished[from]) return;
    const to = ev.to?.side ?? (from === 0 ? 1 : 0), miss = !!ev.miss;
    const C = classifyMove(m), L = lookOf(m.type), col = L.col;
    if (weatherBall) { C.kind = 'projectile'; C.stream = false; C.glob = false; }
    C.travel *= 1.3; // (the two stand further apart now: time to watch it fly across)
    // what really happens, read ahead from the battle log: how many hits land, a critical hit, a knockout…
    const O = ev.outcome ?? null;
    if (O && O.hits > 0 && (C.hits > 1 || O.hits > 1)) C.hits = O.hits;
    const blocked = O?.blocked ?? null, immune = !!O?.immune && !O.hits;
    const power = m.bp >= 120 || (m.recharge && m.cat !== 'Status') || m.ohko || (m.selfdestruct && m.cat !== 'Status') || (C.big && m.bp >= 100);
    const lensKind = lensFor(m, C); m0type = m.type;
    // a move shown in several parts (Dragon Darts' darts): count them, and say how many hit at the end
    animHits = ev.again ? animHits + (O?.hits ? 1 : 0) : (O?.hits ? 1 : 0);
    if (ev.again && !O?.moreAnim && animHits > 1) { const n = animHits; setTimeout(() => say(`Hit ${n} times!`), (C.travel * T + 0.6) * 1000); }
    const beamType = power && m.type === 'Normal' ? 'HyperBeam' : m.type; // Hyper Beam's famous orange-gold
    moveExtra = (power ? 1100 : 0) + Math.max(0, (C.hits || 1) - 1) * 260; // Showdown waits longer for these
    const SF = moveFx(null, { name: m.name, type: String(m.type).toLowerCase(), category: String(m.cat).toLowerCase(), power: m.bp }); // Showdown's picture for it
    if (vanished[from]) unvanish(from); // coming back for the strike
    const targetGone = !!vanished[to];
    const T = tempo(), cine = dynamic && T >= 0.5;
    announce(from, m);
    // a move that gives off light: everything it makes lights the place while it plays
    const glow = moveLight(m);
    if (glow) { const mine = glow; emitting = mine; setTimeout(() => { if (emitting === mine) emitting = null; }, ((ev.again ? 0.05 : cine ? (power ? 1.9 : 1.05) * T : 0.1) + C.travel * T * 1.2 + 1.4) * 1000); if (power) setTimeout(() => lightFlash(chest(from, 0.6), glow.c, { r: 4, i: glow.k * 0.8, life: 0.9 }), 200); }
    // the target reacting to being hit (unless it missed, or the target is out of reach)
    let hitOnce = false;
    const hitIt = (big = C.big || m.bp >= 100, n = 1) => {
      if (blocked && actor(to)) { if (n === 1) { shield(to, blocked === 'Protect' || blocked === 'Detect' ? 'rgba(120,255,210,.8)' : col); const { u, dir } = sideOf(from); ring(chest(to), '#ffffff', { r1: 1.4, life: 0.3 }); void u; void dir; } return; }
      if (immune && actor(to)) { if (n === 1) ring(chest(to), 'rgba(255,255,255,.7)', { r1: 1.2, life: 0.5, w: 2 }); return; }
      if (miss || targetGone || !actor(to)) { if (n === 1 && actor(to) && !targetGone) { const { p } = sideOf(to), h0 = home0(to); move(to, 0.4, (k) => { const s2 = Math.sin(k * Math.PI) * 0.8; return { x: h0.x + p.x * s2, z: h0.z + p.z * s2 }; }); } return; }
      const at = chest(to);
      if (glow) lightFlash(at, glow.c, { r: big ? 7 : 5, i: glow.k * (big ? 1.6 : 1.1), life: big ? 0.55 : 0.35 });
      else if (big) lightFlash(at, [255, 245, 225], { r: 4, i: 0.7, life: 0.25 });
      burst(at, col, big ? 22 : 14, { speed: big ? 3.2 : 2.4, shape: L.shapes[0] });
      burst(at, '#ffffff', 6, { speed: 3, shape: 'star', size: 0.1 });
      fxPop(at, contactKinds.includes(C.kind) && ['fist', 'foot', 'leftslash', 'topbite', 'sword'].includes(SF.img) ? SF.img : 'impact', { size: big ? 1.3 : 0.9 });
      typeHit(m.type, at, big);
      if (dashKinds.includes(C.kind)) contactHit(to, big);
      ring(at, col, { r1: big ? 1.9 : 1.2, life: 0.4 });
      if (n >= (C.hits || 1)) slideBack(to, (big ? 0.3 : 0.12) + (O?.superEff ? 0.25 : 0) + (O?.ko ? 0.3 : 0) - (O?.resisted ? 0.1 : 0), !!O?.crit);
      else if (actor(to) && !vanished[to]) posefx(to, 0.14, (k) => ({ lean: awayDir(to) * 0.12 * Math.sin(k * Math.PI), sx: 1 - 0.04 * Math.sin(k * Math.PI), dim: 0.12 * (1 - k) })); // (a flinch for each hit; only the last sends it back)
      shake = Math.max(shake, big ? 1.1 : O?.resisted ? 0.3 : 0.6);
      if (big) crowdFlash(8);
      const last = n >= (C.hits || 1);
      hitAt[to] = performance.now();
      if (last && practiceHit) { const f = practiceHit; practiceHit = null; f(); }
      if (!hitOnce || last) {
        hitOnce = true;
        if (power && last) bigImpact(to, col);
        // things hitting the lens: always for the big ones; for any other move when the camera is up close
        const camNear = Math.hypot(cam.eye.x - chest(to).x, cam.eye.y - chest(to).y, cam.eye.z - chest(to).z) < 3.4;
        const lk = lensKind ?? (camNear ? lensFor(m, C, true) : null);
        if (lk && lk !== 'sun' && lk !== 'rain' && last) { lensHit(lk, Math.round(6 + m.bp / 9 + (power ? 10 : 0) + (O?.superEff ? 6 : 0))); if (lk === 'ember' && camNear) lensHit('scorch', 2 + (power ? 2 : 0)); }
        if (last) shake = Math.max(shake, 0.45 + m.bp / 110 + (O?.superEff ? 0.5 : 0) + (O?.crit ? 0.6 : 0));
        if (last && shake >= 1.2) { el.classList.remove('cry'); void el.offsetWidth; el.classList.add('cry'); setTimeout(() => el.classList.remove('cry'), 650); }
        if (O?.superEff && last) { ring(at, '#ffffff', { r1: 2.6, life: 0.5, w: 6 }); burst(at, col, 18, { speed: 4 }); }
        // a critical hit or the final blow: everything slows for a moment
        if ((O?.crit || O?.ko) && last) { slowmo = O.ko ? 0.9 : 0.6; screenFlash('#ffffff', 200); if (O.crit) notify(to, 'Critical hit!', 'big', '#ffd23f'); }
      }
    };
    const contactKinds = ['contact', 'zigzag', 'punch', 'kick', 'bite', 'slash', 'horn', 'tackleSpin', 'wrap'];
    const selfKinds = ['self', 'protect', 'heal', 'dance', 'weather', 'terrain', 'field', 'screen'];
    const windup = ev.again ? 0.05 : cine ? (power ? 1.9 : 1.05) * T : 0.1;
    // which way the camera tells this one: varied from move to move, like Battle Revolution
    const flyKinds = ['projectile', 'status', 'vortex', 'drain'], dashKinds = ['zigzag', 'tackleSpin', 'contact', 'punch', 'kick', 'bite', 'slash', 'horn', 'wrap'];
    const appr = dashKinds.includes(C.kind) ? approachFor(m, C) : null;
    const apprDur = appr ? ((APPROACH[appr]?.[0] ?? 1) * 1.2 + (appr === 'flurry' ? ((C.hits || 1) - 1) * 0.14 : 0)) * Math.max(0.8, T) : 0;
    const vol = C.kind === 'volley' ? volleyFor(m) : null;
    // the camera for each way of getting there (a few to choose from, so the same move isn't always shot the same)
    const APPR_CAM = { run: ['run', 'shoulder', 'side'], leap: ['side', 'incoming'], pounce: ['side', 'incoming', 'run'], charge: ['charge', 'incoming', 'shoulder'], blink: ['incoming', 'shoulder'], arc: ['aerial', 'side', 'run'], flurry: ['run', 'shoulder'], spin: ['side', 'run'], zigzag: ['side', 'run', 'run'] };
    const VOL_CAM = { sequence: ['side', 'incoming'], fan: ['wideSide', 'incoming'], orbit: ['orbit', 'orbit'], rain: ['aerial', 'side'] };
    const pickOf = (list) => list[camTurn++ % list.length];
    // the winning strike (it knocks out their last one): up close, riding with a projectile or charging in with an attack
    const finale = !!O?.ko && ((lastTeam?.[to] ?? []).filter((x) => !x.fainted).length <= 1);
    // (projectiles look best from the side or coming in at the target; from behind only for one the camera can ride along with, never a jet or beam)
    const style = !cine || ev.again ? 'plain' : finale && flyKinds.includes(C.kind) ? (C.stream ? 'incoming' : 'ride') : finale && appr ? (APPR_CAM[appr]?.includes('charge') ? 'charge' : 'incoming') : flyKinds.includes(C.kind) ? pickOf(C.stream ? ['side', 'incoming'] : ['side', 'incoming', 'side', 'ride', 'incoming'])
      : vol ? pickOf(VOL_CAM[vol]) : C.kind === 'pulse' ? pickOf(['side', 'incoming'])
        : appr ? pickOf(APPR_CAM[appr] ?? ['shoulder']) : 'plain';
    if (appr) moveExtra += Math.max(0, apprDur - 0.96) * 1000;
    if (vol === 'orbit') moveExtra += 900; else if (vol === 'fan' || vol === 'rain') moveExtra += 300;
    if (C.kind === 'thunder') moveExtra += 1000;
    // riding along with a projectile takes a touch longer, so there's time to see it go
    const travel = C.travel * (cine ? T : 0.7) * (style === 'ride' ? 1.45 : 1);
    // the camera, Battle Revolution style: the one using the move up close as it's announced, then it follows
    // the move across, then the one it hits
    if (cine && !ev.again) {
      const big = m.bp >= 90;
      if (style === 'charge') { // a close-up pushing in on it as it gathers itself to charge
        cutTo(() => SHOT.front(from, 1.2), { hold: 0.05, drift: 0 });
        queueShot(() => SHOT.front(from, 0.62), { dur: windup * 0.9, hold: windup * 0.1, drift: 0.05 });
      } else cutTo(() => (big && !contactKinds.includes(C.kind) ? SHOT.hero(from) : SHOT.front(from, 1.05)), { hold: windup, drift: 0.28 });
      if (selfKinds.includes(C.kind)) queueShot(() => (C.kind === 'weather' || C.kind === 'field' || C.kind === 'terrain' ? SHOT.wide() : SHOT.front(from, 1.5)), { dur: 0.5 * T, hold: 1.2 * T, drift: 0.25 });
      else if (style === 'ride') // riding along behind the projectile until it lands, then on the one it hit
        queueShot(() => rideBehind(chest(from, 0.6), from, to), { hold: travel + 0.15, drift: 0, follow: () => (flying ? rideBehind(flying, from, to) : null) });
      else if (style === 'incoming') // from behind the target, watching it come in
        queueShot(() => SHOT.shoulder(to), { hold: (appr ? apprDur * (APPROACH[appr]?.[1] ?? 0.6) : travel * (C.kind === 'volley' ? C.hits * 0.75 : 1)) + 0.15, drift: 0.05, track: () => flying ?? (dashKinds.includes(C.kind) ? chest(from) : null) });
      else if (style === 'run') // running along beside it as it dashes across the field
        queueShot(() => runAlong(from, to) ?? SHOT.side(from === 0 ? 1 : -1), { hold: apprDur * (APPROACH[appr]?.[1] ?? 0.58) + 0.08, drift: 0, follow: () => runAlong(from, to) });
      else if (style === 'aerial') // from high above, following it round (or the shots raining down)
        queueShot(SHOT.overhead, { hold: (appr ? apprDur * (APPROACH[appr]?.[1] ?? 0.6) : travel * 1.3 + C.hits * 0.26 * T) + 0.1, drift: 0.3, track: () => (appr ? chest(from) : flying) });
      else if (style === 'wideSide') // pulled back side-on: the whole fan of shots curving across
        queueShot(() => SHOT.side((from === 0 ? 1 : -1) * 1.35), { hold: travel * (1.05 + (C.hits - 1) * 0.2) + 0.2, drift: 0.1 });
      else if (style === 'orbit') { // up close as the shots gather round it, then side-on as they're knocked away
        queueShot(() => SHOT.front(from, 1.35), { hold: Math.max(0.5, 0.55 * T) + 0.1, drift: 0.2 });
        queueShot(() => SHOT.side(from === 0 ? 1 : -1), { hold: Math.max(0.14, 0.2 * T) * C.hits + travel * 0.85, drift: 0.15, track: () => flying });
      }
      if (selfKinds.includes(C.kind) || ['ride', 'incoming', 'run', 'aerial', 'wideSide', 'orbit'].includes(style)) { if (!selfKinds.includes(C.kind)) queueShot(() => SHOT.front(to, C.kind === 'vortex' || C.kind === 'wrap' ? 1.5 : finale ? 0.8 : 1.25), { hold: (C.kind === 'vortex' ? 1.6 : 1.15) * T, drift: 0.22 }); }
      else {
        if (appr && style === 'side') queueShot(() => SHOT.side(from === 0 ? 1 : -1), { hold: apprDur * (APPROACH[appr]?.[1] ?? 0.6) + 0.1, drift: 0.2, track: () => chest(from) });
        else if (appr) queueShot(() => SHOT.shoulder(from), { hold: apprDur * (APPROACH[appr]?.[1] ?? 0.6), drift: 0 });
        else if (['projectile', 'volley', 'status', 'drain', 'pulse', 'psychic'].includes(C.kind)) queueShot(() => SHOT.side(from === 0 ? 1 : -1), { hold: travel * (C.kind === 'volley' ? C.hits * 0.75 : 1), drift: 0.15, track: () => flying });
        else if (C.kind === 'beam') queueShot(camTurn++ % 2 ? () => SHOT.side(from === 0 ? 1 : -1) : () => SHOT.shoulder(to), { hold: travel + 0.35, drift: 0.1 });
        else if (['wave', 'sweep', 'web', 'tornado'].includes(C.kind)) queueShot(() => SHOT.side((from === 0 ? 1 : -1) * 1.2), { hold: travel + (C.kind === 'wave' ? 0.9 : 0.35), drift: 0.12 });
        else if (finale && ['quake', 'rockfall', 'thunder', 'rainDown', 'explosion', 'hazard'].includes(C.kind)) queueShot(() => SHOT.front(to, 0.9), { hold: travel + 0.3, drift: 0.15 });
        else if (['quake', 'rockfall', 'thunder', 'rainDown', 'explosion', 'hazard'].includes(C.kind)) queueShot(C.kind === 'thunder' || Math.random() < 0.5 ? SHOT.wide : SHOT.overhead, { hold: travel + (C.kind === 'thunder' ? 0.75 * T : 0.3), drift: 0.6 });
        else if (C.kind === 'dive') queueShot(SHOT.overhead, { hold: travel + 0.1, drift: 0.3 });
        else if (C.kind === 'phantom' || C.kind === 'burrow') queueShot(() => SHOT.behindFoe(), { hold: travel + 0.1, drift: 0.2 });
        queueShot(() => SHOT.front(to, C.kind === 'vortex' || C.kind === 'wrap' ? 1.5 : finale ? 0.8 : 1.25), { hold: (C.kind === 'vortex' ? 1.6 : 1.15) * T, drift: 0.22 });
      }
      home(0);
    }
    // a powerful move: the stage darkens and power gathers before it's unleashed
    if (power && cine) { dim(true); chargeUp(from, m.type); setTimeout(() => chargeUp(from, m.type), 700 * T); setTimeout(() => dim(false), (windup + travel + 0.6) * 1000); shake = Math.max(shake, 0.3); setTimeout(() => { shake = Math.max(shake, 0.5); }, 900 * T); }
    if (lensKind && (lensKind === 'sun' || lensKind === 'rain' || m.cat === 'Status')) setTimeout(() => { lensHit(lensKind, 16); shake = Math.max(shake, 0.5); }, windup * 1000 + 300);
    // gathering itself while the name is up
    if (cine && !ev.again && !selfKinds.includes(C.kind)) {
      gather(from, to, m, C, windup);
      if (!dashKinds.includes(C.kind)) { // gathering itself: rearing back a little (heavy ones further, slower)
        const P2 = prof(from), dA = awayDir(from);
        posefx(from, windup, (k) => { const w = Math.sin(Math.min(1, k * 1.2) * Math.PI / 2); return { lean: dA * (0.1 + P2.heavy * 0.08) * w, sy: 1 - 0.06 * w, sx: 1 + 0.03 * w }; });
      }
    }
    const go = () => {
      // letting it go: a kick back from the release (bigger for big moves), then settling
      if (cine && !dashKinds.includes(C.kind) && !selfKinds.includes(C.kind) && actor(from)) { const dA = awayDir(from), kb = (m.bp >= 100 || C.kind === 'beam' ? 0.24 : 0.12) * (1 - prof(from).heavy * 0.4); posefx(from, 0.4, (k) => ({ lean: dA * kb * Math.sin(k * Math.PI) * (1 - k * 0.3), sx: 1 - 0.05 * Math.sin(k * Math.PI), sy: 1 + 0.06 * Math.sin(k * Math.PI) }), { end: () => settle(from, 0.8) }); }
      if (destroyed) return;
      const big = C.big || m.bp >= 100;
      switch (C.kind) {
        // on the user
        case 'self': aura(from, col, { up: true }); ring(chest(from, 0.05), col, { flat: true, r1: 1.6, life: 0.7 }); sparkleOn(from, L.col2, L.shapes.includes('heart') ? 'heart' : 'star', 10); return;
        case 'dance': { const a = actor(from); for (let i = 0; i < 6; i++) setTimeout(() => { const a2 = actor(from); if (a2) { a2.battleFaceLock = i % 2 ? 'left' : 'right'; a2.hop = 0.6; } }, i * 160); setTimeout(() => { const a2 = actor(from); if (a2) a2.battleFaceLock = null; }, 1000); void a; aura(from, col, { up: true }); notes(from, L.col2); return; }
        case 'heal': sparkleOn(from, '#9dffb8', 'star', 16); aura(from, '#7dffa0'); ring(chest(from, 0.05), '#9dffb8', { flat: true, r1: 1.5, life: 0.8 }); return;
        case 'protect': shield(from, m.type === 'Normal' ? 'rgba(120,255,210,.8)' : col); return;
        case 'weather': case 'terrain': case 'field': screenFlash(m.weather === 'sunnyday' ? 'rgba(255,220,120,.5)' : 'rgba(255,255,255,.4)', 500); ring(chest(from, 0.02), col, { flat: true, r1: 9, life: 1.1, w: 6 }); for (let i = 0; i < 30; i++) particle({ x: rnd(-6, 6), y: rnd(0.2, 3), z: 5 + rnd(-5, 5), vy: rnd(0.2, 1), life: 1, size: 0.15, col: i % 2 ? L.col : L.col2, shape: L.shapes[0] }); return;
        case 'screen': wall(from, col); sparkleOn(from, L.col2, 'star', 8); return;
        // aimed at the target, from where it stands
        case 'status': projectile(from, to, m.type, { dur: travel, shape: m.status === 'slp' || m.flags.sound ? 'note' : m.type === 'Poison' || m.status === 'psn' || m.status === 'tox' ? 'blob' : m.type === 'Water' ? 'drop' : m.type === 'Fire' || m.status === 'brn' ? 'flame' : 'star', size: 0.18, miss, path: 'wobble', onHit: () => { if (miss) return; sparkleOn(to, col); ring(chest(to), col, { life: 0.5 }); if (m.status === 'par') bolts(to, { fromSky: false, from: to }); if (m.status === 'psn' || m.status === 'tox') powder(to, 'Poison'); if (m.status === 'brn') burst(chest(to), '#ff7a2a', 12, { shape: 'flame', up: 1.5, g: 1 }); } }); return;
        case 'powder': powder(to, m.type); return;
        case 'debuff': for (let i = 0; i < 3; i++) setTimeout(() => ring(chest(from, 0.7), col, { r1: 2.4, life: 0.5, w: 3 }), i * 120); setTimeout(() => !miss && aura(to, '#6aa0ff', { up: false, n: 14 }), 400); return;
        case 'glare': glare(from, to); return;
        case 'swap': projectile(from, to, m.type, { dur: travel * 0.7, shape: 'orb', size: 0.15 }); setTimeout(() => projectile(to, from, m.type, { dur: travel * 0.7, shape: 'orb', size: 0.15 }), 200); return;
        case 'hazard': for (let i = 0; i < 8; i++) particle({ ...chest(from), vx: (chest(to).x - chest(from).x) / 0.6 + rnd(-1.5, 1.5), vy: 3, vz: (chest(to).z - chest(from).z) / 0.6 + rnd(-1, 1), g: -10, life: 0.8, size: 0.2, col, shape: L.shapes[0], spin: rnd(-5, 5) }); return;
        // physical, at the target
        case 'zigzag': approach(from, to, 'zigzag', { dur: apprDur, onHit: () => hitIt(false) }); return;
        case 'contact': case 'punch': case 'kick': case 'bite': case 'slash': case 'horn': case 'tackleSpin': case 'wrap': {
          const hits = C.hits;
          approach(from, to, appr, { dur: apprDur, hits, onHit: (n) => {
            hitIt(big, n);
            if (appr === 'pounce' && n === 1) { shake = Math.max(shake, 0.9); ring({ ...chest(to, 0), y: 0.03 }, '#e8dcc0', { flat: true, r1: 2, life: 0.45 }); }
            if (appr === 'charge' && n === 1) { shake = Math.max(shake, 0.8); burst(chest(to, 0.2), '#d8c8a8', 10, { shape: 'rock', speed: 2.4 }); }
            if (miss || targetGone) return;
            if (C.kind === 'punch') burst(chest(to), '#ffffff', 8, { shape: 'fist', speed: 1.5, size: 0.3 });
            if (C.kind === 'kick') burst(chest(to, 0.3), '#ffe48a', 10, { shape: 'star', speed: 2 });
            if (C.kind === 'bite') bite(to);
            if (C.kind === 'slash') slashes(to, m.type === 'Normal' ? '#ffffff' : col);
            if (C.kind === 'horn') ring(chest(to), '#ffffff', { r0: 0.1, r1: 0.7, life: 0.25, w: 6 });
            if (C.kind === 'wrap') swirl(to, m.type, { dur: 1.1 });
            if (m.type !== 'Normal' && m.type !== 'Fighting') burst(chest(to), col, 10, { shape: L.shapes[0] });
          } });
          if (C.kind === 'tackleSpin') for (let i = 0; i < 6; i++) setTimeout(() => trail(from, col), i * 60);
          return;
        }
        // out of reach, coming back for the strike
        case 'dive': { const t = chest(to, 0); const a = actor(from); if (a) a.alpha = 1;
          move(from, 0.6, (k) => (k < 0.55 ? { x: t.x, z: t.z, y: 9 * (1 - ease(k / 0.55)), alpha: 1 } : { x: lerp(t.x, home0(from).x, ease((k - 0.55) / 0.45)), z: lerp(t.z, home0(from).z, ease((k - 0.55) / 0.45)), y: Math.sin(((k - 0.55) / 0.45) * Math.PI) * 1.2 }));
          setTimeout(() => { hitIt(true); burst({ ...t, y: 0.1 }, '#ffffff', 16, { speed: 3, shape: 'feather' }); }, 330); return; }
        case 'burrow': { const t = chest(to, 0);
          move(from, 0.7, (k) => (k < 0.4 ? { x: t.x, z: t.z, y: -1.4 + ease(k / 0.4) * 1.6, alpha: 1 } : { x: lerp(t.x, home0(from).x, ease((k - 0.4) / 0.6)), z: lerp(t.z, home0(from).z, ease((k - 0.4) / 0.6)), y: Math.sin(((k - 0.4) / 0.6) * Math.PI) * 1.4 }));
          setTimeout(() => { burst({ ...t, y: 0.1 }, C.splash ? '#6ac0ff' : '#b89060', 24, { speed: 3.5, shape: C.splash ? 'drop' : 'rock', up: 1.6 }); hitIt(true); }, 260); return; }
        case 'phantom': { const t = chest(to, 0), { u, dir } = sideOf(from), behind = { x: t.x + u.x * dir * 1.3, z: t.z + u.z * dir * 1.3 };
          move(from, 0.75, (k) => (k < 0.45 ? { ...behind, alpha: Math.min(1, k * 4) } : { x: lerp(behind.x, home0(from).x, ease((k - 0.45) / 0.55)), z: lerp(behind.z, home0(from).z, ease((k - 0.45) / 0.55)), alpha: 1 - Math.sin(((k - 0.45) / 0.55) * Math.PI) * 0.8 }));
          setTimeout(() => { slashes(to, '#c0a8ff'); hitIt(true); }, 250); return; }
        // the whole field
        case 'quake': quake(from); setTimeout(() => hitIt(true), 300); return;
        case 'rockfall': rocksFall(to, col); setTimeout(() => hitIt(), 520); return;
        case 'spikes': pillar(to, m.type, { onHit: () => hitIt(big) }); return;
        case 'rainDown': rainOn(to, m.type, { onHit: () => hitIt(big) }); return;
        case 'explosion': explosion(from); setTimeout(() => hitIt(true), 250); return;
        case 'thunder': {
          for (let i = 0; i < 6; i++) setTimeout(() => { if (destroyed) return; const { n: a, f: b } = axis(), w = { x: lerp(a.x, b.x, Math.random()) + rnd(-3, 3), y: 0.1, z: lerp(a.z, b.z, Math.random()) + rnd(-2, 2) }; burst(w, '#ffe03a', 5, { shape: 'spark', speed: 2, up: 2 }); lightFlash(w, [255, 240, 140], { r: 5, i: 0.9, life: 0.18 }); if (i % 2 === 0) screenFlash('#fff8c0', 60); }, i * 110);
          const gap = 0.75 * T;
          setTimeout(() => { if (destroyed) return; if (dynamic && cine && !ev.again) { shots.length = 0; cutTo(() => SHOT.around(to, 0.75, 1.2, 0.7), { hold: 1.3 * T, drift: 0.12 }); home(1.0); }
            setTimeout(() => { bolts(to, { fromSky: true, onHit: () => hitIt(true) }); screenFlash('#fff8c0', 180); }, 260); }, gap * 1000);
          return;
        }
        case 'zap': bolts(to, { fromSky: false, from, onHit: () => hitIt() }); return;
        case 'beam': beam(from, to, beamType, { dur: power ? 1.4 : 0.85, width: power ? 2.4 : 1, onHit: () => hitIt(big) }); if (big) screenFlash(col, 260); if (power) { shake = 1.6; for (let i = 0; i < 6; i++) setTimeout(() => ring(chest(from), '#ffffff', { r0: 0.3, r1: 1.4, life: 0.3, w: 3 }), i * 120); } return;
        case 'sweep': waveAcross(from, to, m.type, { onHit: () => hitIt(big) }); if (C.gleam) { screenFlash('#fff0fa', 220); for (let i = 0; i < 5; i++) setTimeout(() => sparkleOn(to, '#ffd0f0', 'star', 6), 200 + i * 90); } return;
        case 'web': webShot(from, to, m.type, { dur: travel * 1.2, ground: C.ground, electric: C.electric, miss, onHit: () => { if (m.cat !== 'Status') hitIt(big); else if (!miss) sparkleOn(to, '#ffffff', 'dot', 6); } }); return;
        case 'wave': bigWave(from, to, m.type, { mud: /mud/i.test(m.name), onHit: () => hitIt(big) }); return;
        case 'tornado': funnel(to, m.type, { mode: 'tornado', from, travel: travel * 1.2, dur: 1.5, onHit: () => { hitIt(big); if (!miss && actor(to)) move(to, 0.8, (k) => ({ ...home0(to), y: Math.sin(k * Math.PI) * 1.1 })); } }); return;
        case 'pulse': for (let i = 0; i < 4; i++) setTimeout(() => projectile(from, to, m.type, { dur: travel, shape: 'ring', size: 0.3 + i * 0.05, onHit: i === 3 ? () => hitIt(big) : null, miss }), i * 90); return;
        case 'psychic': for (let i = 0; i < 3; i++) setTimeout(() => ring(chest(to), col, { r0: 1.6, r1: 0.2, life: 0.5, w: 4 }), i * 120); setTimeout(() => { hitIt(); if (!miss && actor(to)) move(to, 0.6, (k) => ({ ...home0(to), y: Math.sin(k * Math.PI) * 0.7 })); }, 380); return;
        case 'sound': for (let i = 0; i < 4; i++) setTimeout(() => ring(chest(from, 0.7), col, { r1: 3.2, life: 0.6, w: 4 }), i * 110); notes(from, L.col2); setTimeout(() => hitIt(), 400); return;
        case 'wind': for (let i = 0; i < 24; i++) setTimeout(() => particle({ ...chest(from), vx: (chest(to).x - chest(from).x) / 0.4 + rnd(-1, 1), vy: rnd(-0.3, 0.6), vz: (chest(to).z - chest(from).z) / 0.4 + rnd(-1, 1), life: 0.45, size: 0.2, col: i % 3 ? '#ffffff' : col, shape: m.type === 'Flying' ? 'feather' : L.shapes[0], spin: 8 }), i * 12); setTimeout(() => { hitIt(); if (!miss) swirl(to, 'Flying', { dur: 0.6, rise: 1 }); }, 380); return;
        case 'vortex': projectile(from, to, m.type, { dur: travel, size: 0.24, miss, img: SF.img, path: pathFor(m), onHit: () => { hitIt(); if (!miss && !targetGone) funnel(to, m.type, { mode: /twister|tornado/i.test(m.name) ? 'tornado' : 'pool', dur: 1.8 }); } }); return;
        case 'drain': { // from the target to the user: the life it takes
          if (m.cat !== 'Status') projectile(from, to, m.type, { dur: travel * 0.6, size: 0.18, miss, onHit: () => hitIt() });
          if (miss) return;
          setTimeout(() => { stream(from, to, m.type, { dur: 0.7, rate: 3, size: 0.12, reverse: true }); for (let i = 0; i < 12; i++) particle({ ...chest(to), vx: (chest(from).x - chest(to).x) / 0.7 + rnd(-0.5, 0.5), vy: rnd(0.3, 1.2), vz: (chest(from).z - chest(to).z) / 0.7 + rnd(-0.4, 0.4), life: 0.7, size: 0.12, col: '#9dffb8', shape: 'dot' }); }, travel * 600 + 150);
          setTimeout(() => sparkleOn(from, '#9dffb8', 'star', 10), travel * 600 + 850);
          return;
        }
        case 'volley': { // several shots: Dragon Darts, Bullet Seed, Pin Missile, Water Shuriken…
          volley(from, to, m.type, { n: C.hits, style: vol, travel, size: m.name === 'Dragon Darts' ? 0.22 : 0.16, shape: /dart|missile|needle|pin|shuriken/i.test(m.name) ? 'needle' : /icicle/i.test(m.name) ? 'shard' : null, img: SF.img, miss, path: pathFor(m), T, onHit: (i) => hitIt(false, i) });
          return;
        }
        default:
          if (C.stream) stream(from, to, m.type, { dur: 0.75, rate: 5, onHit: () => hitIt(big) });
          else if (C.glob) { // Acid, Sludge, Sludge Bomb, Gunk Shot: blobs of goo lobbed over, splatting on it
            const n = m.bp >= 90 ? 3 : 2;
            for (let i = 0; i < n; i++) setTimeout(() => projectile(from, to, m.type, { dur: travel, size: (m.bp >= 90 ? 0.32 : 0.22) * (1 - i * 0.15), miss, shape: 'bubble', path: 'lob', onHit: i === n - 1 ? () => { hitIt(big); if (!miss) { burst(chest(to, 0.6), '#c070e8', 16, { shape: 'drop', speed: 2.2, up: 1.2, g: -6 }); for (let j = 0; j < 8; j++) particle({ ...chest(to, 0.7), x: chest(to).x + rnd(-0.4, 0.4), vy: -rnd(0.2, 0.6), life: 1, size: 0.12, col: '#9a4ad0', shape: 'drop' }); } } : null }), i * 140);
          } else { projectile(from, to, m.type, { dur: travel, size: weatherBall ? 0.46 : m.bp >= 90 ? 0.34 : 0.24, miss, img: weatherBall ? null : SF.img, path: pathFor(m), onHit: () => { hitIt(big); if (weatherBall) { burst(chest(to), col, 26, { speed: 3.4, shape: L.shapes[0] }); ring(chest(to), L.col2, { r1: 2.2, life: 0.5, w: 5 }); } } }); if (weatherBall) trailOf(m.type, travel + 0.1); }
      }
    };
    setTimeout(go, windup * 1000);
  }

  const statusOf = [null, null], pinched = [false, false];
  function renderHud(side, info, team) {
    const box = hud[side];
    if (info) { statusOf[side] = info.fainted ? null : info.status || null; if (info.pct >= 0.25) pinched[side] = false; }
    if (!info) { box.hidden = true; return; }
    box.hidden = !introOver && !!intro; // the plates come in once the opening is over
    const pct = Math.max(0, Math.min(1, info.pct ?? 0));
    const col = pct > 0.5 ? 'g' : pct > 0.2 ? 'y' : 'r';
    const gender = info.gender === 'M' ? h('b', { class: 'm' }, '♂') : info.gender === 'F' ? h('b', { class: 'f' }, '♀') : null;
    const balls = (team?.[side] ?? []).map((t) => h('i', { class: `ball ${!t.seen ? 'unknown' : t.fainted ? 'out' : t.status ? 'st' : ''}` }));
    let bar = box.querySelector('.bst-hpfill');
    // Battle Revolution's plate: name and gender over "Lv." and the HP bar (and your HP), with a P1/CPU tag
    if (!box.firstChild || box.dataset.ident !== info.ident) {
      box.dataset.ident = info.ident;
      const tag = h('span', { class: 'tag' }, side === 0 ? 'P1' : versus ? 'P2' : intro === 'trainer' || trainers.foe ? 'CPU' : 'WILD');
      box.replaceChildren(
        h('div', { class: 'bst-balls' }),
        h('div', { class: 'bst-name' }, side === 1 ? tag : null, h('span', { class: 'n' }, String(info.name || info.species).toUpperCase()), gender, side === 0 ? tag : null),
        h('div', { class: 'bst-hprow' }, h('span', { class: 'lv' }, `Lv. ${info.level}`), h('span', { class: 'bst-status' }), h('div', { class: 'bst-hpbar' }, h('div', { class: 'bst-hpghost' }), h('div', { class: 'bst-hpfill' })), h('span', { class: 'bst-hpnum' })));
      bar = box.querySelector('.bst-hpfill');
      bar.style.transition = 'none'; bar.style.width = `${pct * 100}%`; void bar.offsetWidth; bar.style.transition = '';
      box.shownPct = pct; box.shownHp = info.hp;
    }
    // the bar drains (or fills) at a steady pace, the number counting with it, like Battle Revolution
    const from = box.shownPct ?? pct, dPct = pct - from;
    const drainFor = Math.abs(dPct) < 0.002 ? 0 : Math.min(2.4, Math.max(0.45, Math.abs(dPct) * 2.6)) * Math.min(1.3, Math.max(0.5, tempo() / 1.6));
    cancelAnimationFrame(box.drainRaf);
    const hpFrom = box.shownHp ?? info.hp, hpTo = info.hp;
    const paint = (k) => {
      const p2 = from + dPct * k;
      bar.style.width = `${p2 * 100}%`;
      bar.className = `bst-hpfill ${p2 > 0.5 ? 'g' : p2 > 0.2 ? 'y' : 'r'}${k < 1 ? ' moving' : ''}`;
      box.shownPct = p2;
      if (side === 0 && info.maxhp) { const hpNow = Math.round(lerp(hpFrom ?? hpTo, hpTo, k)); box.shownHp = hpNow; const num = box.querySelector('.bst-hpnum'); if (num) num.textContent = `${Math.max(0, hpNow)}/${info.maxhp}`; }
    };
    bar.style.transition = 'background-color .3s';
    // Battle Revolution's bar: what's lost shows as a bright chunk the bar drains away from (and the plate jolts);
    // what's healed glows in ahead of the bar as it fills
    const ghost = box.querySelector('.bst-hpghost');
    if (ghost && drainFor) {
      clearTimeout(box.ghostT);
      ghost.style.transition = 'none';
      ghost.className = `bst-hpghost ${dPct < 0 ? 'lost' : 'gain'}`;
      ghost.style.width = `${(dPct < 0 ? from : pct) * 100}%`;
      void ghost.offsetWidth;
      box.classList.remove('hurt', 'healed'); void box.offsetWidth; box.classList.add(dPct < 0 ? 'hurt' : 'healed');
      bar.classList.add('moving');
      box.ghostT = setTimeout(() => { ghost.style.transition = 'width .32s ease-in, opacity .4s'; ghost.style.width = `${pct * 100}%`; ghost.style.opacity = '0'; bar.classList.remove('moving'); }, drainFor * 1000 + 120);
      ghost.style.opacity = '1';
    }
    if (!drainFor) paint(1);
    else { const t0 = performance.now(); const tick = () => { const k = Math.min(1, (performance.now() - t0) / (drainFor * 1000)); paint(k); if (k < 1 && !destroyed) box.drainRaf = requestAnimationFrame(tick); }; tick(); }
    void col;
    const st = box.querySelector('.bst-status');
    st.textContent = info.fainted ? 'FNT' : STATUS_LABEL[info.status] ?? '';
    st.style.background = info.fainted ? '#a04040' : STATUS_COL[info.status] ?? 'transparent';
    st.hidden = !st.textContent;
    if (!(side === 0 && info.maxhp)) box.querySelector('.bst-hpnum').textContent = '';
    else if (!drainFor) box.querySelector('.bst-hpnum').textContent = `${Math.max(0, Math.round(info.hp))}/${info.maxhp}`;
    box.querySelector('.bst-balls').replaceChildren(...balls);
    return drainFor;
  }

  // ---------- the text box ----------
  let typing = null;
  function say(s) {
    if (!s) return;
    if (/ used .+!$/.test(s) && banner.classList.contains('on')) { text.classList.remove('on'); return; } // the banner says it
    clearInterval(typing);
    text.classList.add('on');
    let i = 0;
    text.textContent = '';
    typing = setInterval(() => { i += 2; text.textContent = s.slice(0, i); if (i >= s.length) clearInterval(typing); }, 16);
  }

  // ---------- each frame ----------
  function frame(ctx) {
    const now = performance.now(), dt0 = Math.min(0.05, (now - last) / 1000); last = now;
    frameMs = frameMs * 0.92 + dt0 * 1000 * 0.08; lowFx = frameMs > 26; yard.lowFx = frameMs > 45;
    // slow motion for a critical hit or a knockout blow
    slowmo = Math.max(0, slowmo - dt0); const dt = slowmo > 0 ? dt0 * 0.28 : dt0; time += dt;
    stepCamera(dt);
    // statuses show all the time, gently: Zzz, bubbles, embers, sparks, frost, and stars for confusion
    for (const side of [0, 1]) {
      const st = statusOf[side], a = actor(side); if (!a || vanished[side]) continue;
      const top = chest(side, 1), mid = chest(side, 0.5), r0 = Math.random();
      if (st === 'slp' && r0 < dt * 1.3) particle({ ...top, x: top.x + 0.2, vy: 0.5, vx: 0.25, life: 1.4, size: 0.2, col: '#ffffff', shape: 'zzz' });
      else if ((st === 'psn' || st === 'tox') && r0 < dt * 2) particle({ ...mid, x: mid.x + rnd(-0.4, 0.4), vy: rnd(0.3, 0.7), life: 0.9, size: 0.12, col: '#c070f0', shape: 'bubble' });
      else if (st === 'brn' && r0 < dt * 3) particle({ ...mid, x: mid.x + rnd(-0.4, 0.4), y: mid.y * rnd(0.3, 1.4), vy: rnd(0.5, 1), life: 0.6, size: 0.14, col: '#ff7a2a', shape: 'flame' });
      else if (st === 'par' && r0 < dt * 1.5) particle({ ...mid, x: mid.x + rnd(-0.5, 0.5), y: mid.y * rnd(0.4, 1.5), life: 0.2, size: 0.3, col: '#ffe03a', shape: 'spark' });
      else if (st === 'frz' && r0 < dt * 2) particle({ ...mid, x: mid.x + rnd(-0.5, 0.5), y: mid.y * rnd(0.2, 1.6), vy: 0.1, life: 0.8, size: 0.14, col: '#c8f4ff', shape: 'flake' });
      const vol = mons[side]?.info?.vol ?? [];
      if (vol.includes('confusion') && r0 < dt * 4) { const ang = time * 4 + Math.random(); particle({ x: top.x + Math.cos(ang) * 0.4, y: top.y + 0.15, z: top.z + Math.sin(ang) * 0.25, vx: -Math.sin(ang) * 1.6, vz: Math.cos(ang), life: 0.35, size: 0.12, col: '#ffe86a', shape: 'star' }); }
      a.tint = st === 'frz' ? 'frz' : st === 'par' && Math.sin(time * 9) > 0.92 ? 'par' : null;
    }
    idleTick(dt);
    ambientTick(dt);
    for (const e of fx) { e.t += dt; e.update?.(dt); }
    for (let i = fx.length - 1; i >= 0; i--) if (fx[i].t >= fx[i].life) { fx[i].end?.(); fx.splice(i, 1); }
    for (const p of parts) { p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.vy += p.g * dt; p.rot += p.spin * dt; if (p.y < 0 && p.g < 0) { p.y = 0; p.vy *= -0.3; p.vx *= 0.6; } }
    for (let i = parts.length - 1; i >= 0; i--) if (parts[i].life <= 0) parts.splice(i, 1);
    yard.dynLights = stageLights(dt);
    ctx.save();
    for (const e of fx) e.draw?.(ctx);
    for (const p of parts) drawParticle(ctx, p);
    ctx.restore();
    drawBattleWeather(ctx, dt0);
    postFx(ctx);
    // weather on the lens now and then: raindrops, a flake of snow, a sunbeam, grit in a sandstorm
    if (weatherNow && Math.random() < dt0 * 0.9) { const wk = { raindance: 'drop', primordialsea: 'drop', sunnyday: 'sun', desolateland: 'sun', sandstorm: 'dirt', hail: 'snow', snow: 'snow', snowscape: 'snow' }[weatherNow]; if (wk) lensHit(wk, wk === 'sun' ? 1 : 3); }
    if (!lowFx && !practice) { const wetNow = weatherNow === 'raindance' || weatherNow === 'primordialsea' || (!weatherNow && !indoor && (ambientWx === 'rain' || ambientWx === 'storm')); // rain keeps landing on the lens and running down it
      if (wetNow && Math.random() < dt0 * (weatherNow === 'primordialsea' || ambientWx === 'storm' ? 5 : 3)) { const W = yard.W || 960, H = yard.H || 540; lens.push(newDrop('drop', Math.random() * W, Math.random() * H * 0.8, 0, H)); } }
    drawLens(ctx, dt0);
    // hover areas for Showdown's tooltips, over each creature
    const r = canvas.getBoundingClientRect(), sx = r.width / (canvas.width || 1), sy = r.height / (canvas.height || 1);
    for (const side of [0, 1]) {
      const b = actor(side) && yard.actorBox(uidOf(side));
      const t = tips[side]; t.style.display = 'none'; continue; // (the plates have the tooltips now)
      if (!b) { t.style.display = 'none'; continue; }
      t.style.display = 'block';
      Object.assign(t.style, { left: `${b.x0 * sx}px`, top: `${b.y0 * sy}px`, width: `${Math.max(20, (b.x1 - b.x0) * sx)}px`, height: `${Math.max(20, (b.y1 - b.y0) * sy)}px` });
    }
  }

  // ---------- idling: each in its own way ----------
  // Fliers hover a little off the ground with a flap-like bob, hoverers float level, swimmers sway, walkers
  // breathe (heavy ones slowly, quick ones with a nervous bounce).
  function idleTick() {
    for (const side of [0, 1]) {
      const a = actor(side); if (!a || vanished[side] || busy[side] || (a.alpha ?? 1) < 0.5) continue;
      const P2 = prof(side), t2 = time + side * 1.7;
      if (P.look !== 'seafloor') {
        if (P2.gait === 'fly') a.y = 0.32 + 0.13 * Math.sin(t2 * (2.2 + P2.quick * 1.5));
        else if (P2.gait === 'hover') a.y = 0.14 + 0.04 * Math.sin(t2 * 1.6);
      }
      if (posing[side]) continue;
      if (P2.gait === 'swim') a.pose = { lean: Math.sin(t2 * 1.3) * 0.05, sy: 1 + Math.sin(t2 * 2.6) * 0.012 };
      else if (P2.gait === 'fly') a.pose = { sy: 1 + Math.sin(t2 * (4.4 + P2.quick * 3)) * 0.035, sx: 1 - Math.sin(t2 * (4.4 + P2.quick * 3)) * 0.02 };
      else a.pose = { sy: 1 + Math.sin(t2 * (1.6 - P2.heavy * 0.7 + P2.quick * 1.4)) * (0.018 - P2.heavy * 0.006), sx: 1 - Math.sin(t2 * (1.6 - P2.heavy * 0.7 + P2.quick * 1.4)) * 0.008, dy: P2.quick > 0.6 ? -Math.abs(Math.sin(t2 * 5)) * 0.008 : 0 };
    }
  }
  // ---------- winning: each celebrates its own way ----------
  // Big heavy ones roar, fliers flutter about, quick small ones dance, and the rest stretch or look around proudly.
  function victoryDance(side) {
    const a = actor(side); if (!a) return;
    const P2 = prof(side), dir = awayDir(side), h0 = home0(side), { p } = sideOf(side);
    const seedV = String(a.speciesId ?? '').length;
    const kind = P2.gait === 'fly' ? 'flutter' : P2.heavy > 0.62 ? 'roar' : P2.quick > 0.55 && P2.heavy < 0.4 ? 'dance' : ['stretch', 'proud', 'dance', 'roar'][seedV % 4];
    if (kind === 'roar') {
      posefx(side, 1.6, (k) => { const up = k < 0.3 ? k / 0.3 : k < 0.8 ? 1 : 1 - (k - 0.8) / 0.2; return { lean: dir * 0.22 * up, sy: 1 + 0.12 * up, sx: 1 + 0.05 * up + Math.sin(k * 80) * 0.01 * up, dx: Math.sin(k * 70) * 0.006 * up }; }, { end: () => settle(side) });
      for (let i = 0; i < 4; i++) setTimeout(() => { ring(chest(side, 0.75), 'rgba(255,255,255,.75)', { r1: 2.5 + i * 0.6, life: 0.6, w: 3 }); shake = Math.max(shake, 0.6); }, 450 + i * 180);
    } else if (kind === 'flutter') {
      busy[side]++;
      fx.push({ t: 0, life: 2.2, update() { const a2 = actor(side); if (!a2) return; const k = this.t / this.life; a2.y = 0.4 + Math.abs(Math.sin(k * Math.PI * 5)) * 0.9 * Math.sin(k * Math.PI); a2.x = h0.x + p.x * Math.sin(k * Math.PI * 2) * 0.6; a2.z = h0.z + p.z * Math.sin(k * Math.PI * 2) * 0.6; if (Math.random() < 0.3) particle({ x: a2.x, y: a2.y + tall(side) * 0.5, z: a2.z, vy: -0.3, vx: rnd(-0.5, 0.5), life: 0.8, size: 0.1, col: '#fff3b0', shape: 'star' }); }, end() { busy[side]--; const a2 = actor(side); if (a2) { a2.x = h0.x; a2.z = h0.z; } } });
      posefx(side, 2.2, (k) => ({ sy: 1 + Math.sin(k * 60) * 0.05, lean: Math.sin(k * Math.PI * 2) * 0.12 }));
    } else if (kind === 'dance') {
      move(side, 2.0, (k) => { const i = Math.floor(k * 6), f = k * 6 - i, s2 = (i % 2 ? 1 : -1) * 0.45 * Math.sin(f * Math.PI); return { x: h0.x + p.x * s2, z: h0.z + p.z * s2, y: Math.abs(Math.sin(f * Math.PI)) * 0.35 }; }, { end: () => { const a2 = actor(side); if (a2) a2.battleFaceLock = null; } });
      posefx(side, 2.0, (k) => { const a2 = actor(side); if (a2) a2.battleFaceLock = Math.floor(k * 6) % 2 ? 'left' : 'right'; return { lean: Math.sin(k * Math.PI * 6) * 0.15, sy: 1 + Math.abs(Math.sin(k * Math.PI * 6)) * 0.06 }; }, { end: () => settle(side) });
    } else if (kind === 'stretch') {
      posefx(side, 2.0, (k) => { const up = Math.sin(Math.min(1, k * 1.4) * Math.PI); return { sy: 1 + 0.17 * up, sx: 1 - 0.07 * up, lean: Math.sin(k * Math.PI * 2) * 0.05 }; }, { end: () => settle(side) });
    } else { // looking around proudly, chest out
      posefx(side, 2.2, (k) => { const a2 = actor(side); if (a2) a2.battleFaceLock = k < 0.33 ? 'left' : k < 0.66 ? 'right' : null; return { sy: 1.06, sx: 1.02, lean: dir * 0.06 }; }, { end: () => { const a2 = actor(side); if (a2) a2.battleFaceLock = null; settle(side); } });
    }
  }

  // ---------- the place around the battle, alive ----------
  // Outdoors: birds crossing the sky and leaves blowing past. Stadium and Colosseum: a crowd of silhouettes in the
  // stands that bob, cheer and wave (more when something big happens), camera flashes going off, flags waving and
  // the floodlights pulsing. Reflections on water, ice, polished floors, and anything soaked by rain.
  const crowdy = ['stadium', 'colosseum'].includes(P.look);
  let hypeLvl = 0.2, birdT = 6 + Math.random() * 8;
  // the crowd: a murmur all through, cheering (and people leaping up, a few at a time) at the big moments
  let crowdSnd = null;
  function hype(n) {
    hypeLvl = Math.min(1.5, hypeLvl + n);
    if (!crowdy) return;
    try { crowdSnd ??= crowdNoise({ volume: 0.9, muted: () => !!globalThis.__clBattleSound?.muted }); crowdSnd?.cheer(n); } catch { /* no sound */ }
  }
  const sil = [];
  if (crowdy) {
    const R = P.look === 'stadium' ? [21, 18] : [19, 16];
    for (let i = 0; i < 0; i++) {
      const ang = (i / 220) * Math.PI * 2 + Math.random() * 0.02, tier = i % 4, r = 0.86 + tier * 0.055;
      sil.push({ x: Math.cos(ang) * R[0] * r, z: 5 + Math.sin(ang) * R[1] * r, y: 1.2 + tier * 1.25, ph: Math.random() * 6, col: ['#232634', '#2b2f40', '#1d2030', '#30344a'][i % 4], wave: Math.random() < 0.25, hue: ['#e05050', '#4a8ae0', '#e0c040', '#50c080', null, null][i % 6] });
    }
    // (no silhouettes in the stands: the stadium's own crowd picture is the crowd)
    // (no added flags either: the stadium as it was)
    for (let i = 0; i < 0; i++) { const ang = (i / 8) * Math.PI * 2 + 0.2, x = Math.cos(ang) * R[0] * 1.08, z = 5 + Math.sin(ang) * R[1] * 1.08, col = ['#e04848', '#3c7ae0', '#f0c040', '#48c078'][i % 4];
      yard.extras.push({ x, y: 7, z, draw(ctx, q) { if (!q) return; const q0 = project({ x, y: 4.5, z }), q1 = project({ x, y: 9.5, z }); if (!q0 || !q1) return; ctx.strokeStyle = '#ccd'; ctx.lineWidth = Math.max(1, q.k * 0.05); ctx.beginPath(); ctx.moveTo(q0.x, q0.y); ctx.lineTo(q1.x, q1.y); ctx.stroke(); const L2 = q.k * 1.4, H2 = q.k * 0.8; ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(q1.x, q1.y); for (let j = 0; j <= 8; j++) { const fx2 = j / 8; ctx.lineTo(q1.x + L2 * fx2, q1.y + Math.sin(time * 5 + fx2 * 5 + i) * H2 * 0.18 * fx2); } for (let j = 8; j >= 0; j--) { const fx2 = j / 8; ctx.lineTo(q1.x + L2 * fx2, q1.y + H2 + Math.sin(time * 5 + fx2 * 5 + i) * H2 * 0.18 * fx2); } ctx.closePath(); ctx.fill(); } });
    }
  }
  if (crowdy) setTimeout(() => { if (!destroyed) hype(0.25); }, 1200);
  const outdoorsLook = ['meadow', 'forest', 'shoreline', 'marsh', 'skyline', 'outskirts', 'desert', 'tundra', 'shrine', 'ruins', 'spooky', 'volcano'].includes(P.look);
  // hail and snow: the ground round each of them frozen over, icy blue and glinting (it grows in, and thaws away)
  let iceK = 0;
  const icyNow = () => ['hail', 'snow', 'snowscape'].includes(weatherNow);
  const iceDiscs = [0, 1].map((side) => ({ side, x: 0, y: 0, z: 0, draw(ctx) {
    if (iceK <= 0.01) return;
    const a = actor(side), c = a ? { x: a.x, z: a.z } : home0(side), r = 1.5 * (0.4 + 0.6 * iceK), pts = [];
    for (let j = 0; j < 22; j++) { const an = (j / 22) * Math.PI * 2, wob = 1 + Math.sin(j * 2.7 + side) * 0.08; const q = project({ x: c.x + Math.cos(an) * r * wob, y: 0.015, z: c.z + Math.sin(an) * r * 0.85 * wob }); if (!q) return; pts.push(q); }
    const qc = project({ x: c.x, y: 0.015, z: c.z }); if (!qc) return;
    const rx = Math.max(...pts.map((q) => Math.abs(q.x - qc.x)));
    ctx.save(); ctx.globalAlpha = 0.75 * iceK;
    const g = ctx.createRadialGradient(qc.x, qc.y, 0, qc.x, qc.y, rx); g.addColorStop(0, 'rgba(225,245,255,.85)'); g.addColorStop(0.6, 'rgba(150,210,245,.7)'); g.addColorStop(1, 'rgba(120,190,240,.15)');
    ctx.fillStyle = g; ctx.beginPath(); pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y))); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = Math.max(1.5, rx * 0.025); ctx.stroke();
    // cracks and glints
    ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 1; ctx.beginPath(); for (let j = 0; j < 5; j++) { const q = pts[(j * 5 + side) % pts.length]; ctx.moveTo(lerp(qc.x, q.x, 0.25), lerp(qc.y, q.y, 0.25)); ctx.lineTo(lerp(qc.x, q.x, 0.8), lerp(qc.y, q.y, 0.8)); } ctx.stroke();
    ctx.globalCompositeOperation = 'lighter'; for (let j = 0; j < 3; j++) { const ph = (time * 0.7 + j * 0.37 + side * 0.2) % 1; if (ph > 0.25) continue; const q = pts[(j * 7 + 3) % pts.length], gx = lerp(qc.x, q.x, 0.55), gy = lerp(qc.y, q.y, 0.55), sz = rx * 0.08 * Math.sin((ph / 0.25) * Math.PI); ctx.fillStyle = 'rgba(255,255,255,.95)'; ctx.fillRect(gx - sz, gy - 1, sz * 2, 2); ctx.fillRect(gx - 1, gy - sz, 2, sz * 2); }
    ctx.restore();
  } }));
  (yard.extras ??= []).push(...iceDiscs);
  function ambientTick(dt) {
    iceK = Math.max(0, Math.min(1, iceK + (icyNow() ? dt * 0.8 : -dt * 0.4)));
    // the frozen patches sort just behind each creature (so they're drawn under it)
    for (const d of iceDiscs) { const hp = home0(d.side), dx = hp.x - cam.eye.x, dz = hp.z - cam.eye.z, l = Math.hypot(dx, dz) || 1; d.x = hp.x + (dx / l) * 2.4; d.z = hp.z + (dz / l) * 2.4; }
    hypeLvl = Math.max(0.15, hypeLvl - dt * 0.12);
    if (crowdy && Math.random() < dt * (0.6 + hypeLvl * 3)) crowdFlash(1);
    if (crowdy && Math.random() < dt * 0.25) lightFlash({ x: rnd(-12, 12), y: 9, z: rnd(-4, 16) }, [255, 244, 220], { r: 10, i: 0.25, life: 1.2 }); // the floodlights breathing
    if (!outdoorsLook || lowFx) return;
    // leaves and petals blowing through (snow or ash where that fits)
    if (Math.random() < dt * (P.look === 'forest' ? 3 : 1.4)) {
      const { n, f } = axis(), wind = 1.2 + Math.sin(time * 0.3) * 0.6, z0 = lerp(n.z, f.z, Math.random()) + rnd(-4, 4);
      const kind = P.look === 'tundra' ? ['flake', '#ffffff'] : P.look === 'volcano' ? ['ember', '#ff8a3a'] : P.look === 'desert' ? ['dot', '#e0c890'] : P.look === 'spooky' ? ['leaf', '#7a5a8a'] : ['leaf', Math.random() < 0.5 ? '#9ac850' : '#d8b048'];
      particle({ x: -14, y: rnd(1, 5), z: z0, vx: wind * rnd(1.5, 2.6), vy: rnd(-0.3, 0.2), vz: rnd(-0.3, 0.3), life: 9, size: 0.12, col: kind[1], shape: kind[0], spin: rnd(-3, 3) });
    }
    // birds crossing the sky now and then
    if ((birdT -= dt) <= 0 && !['spooky', 'volcano'].includes(P.look)) {
      birdT = 10 + Math.random() * 16;
      const n2 = 2 + Math.floor(Math.random() * 4), y0 = rnd(9, 14), z0 = rnd(18, 30), dir = Math.random() < 0.5 ? 1 : -1;
      for (let i = 0; i < n2; i++) { const b = { x: -dir * 34 - dir * i * 1.4, y: y0 + rnd(-0.6, 0.6) + Math.abs(i - n2 / 2) * 0.4, z: z0 + i * 0.8, ph: Math.random() * 6 };
        fx.push({ t: 0, life: 16, update(dt2) { b.x += dir * 4.2 * dt2; }, draw(ctx) { const q = project(b); if (!q) return; const w2 = q.k * 0.35, fl = Math.sin(time * 9 + b.ph) * w2 * 0.45; ctx.strokeStyle = 'rgba(30,34,46,.75)'; ctx.lineWidth = Math.max(1, q.k * 0.04); ctx.beginPath(); ctx.moveTo(q.x - w2, q.y - fl); ctx.quadraticCurveTo(q.x - w2 * 0.4, q.y - fl * 0.3 - w2 * 0.2, q.x, q.y); ctx.quadraticCurveTo(q.x + w2 * 0.4, q.y - fl * 0.3 - w2 * 0.2, q.x + w2, q.y - fl); ctx.stroke(); } }); }
    }
  }
  // reflections: what the floor is made of (and whether it's soaked)
  function setReflect() {
    const wet = ['raindance', 'primordialsea'].includes(weatherNow) || (!weatherNow && !indoor && (ambientWx === 'rain' || ambientWx === 'storm'));
    const icy = ['snow', 'snowscape', 'hail'].includes(weatherNow) || P.look === 'tundra' || (!weatherNow && !indoor && ambientWx === 'snow');
    const f = reflectFor(P.look, { wet, icy });
    if (['snow', 'snowscape', 'hail'].includes(weatherNow)) f.reflect = Math.max(f.reflect, 0.26); // standing on the ice patches
    yard.reflect = f.reflect; yard.reflectWater = f.water;
  }
  setTimeout(setReflect, 0);

  // ---------- each type's own look when it lands ----------
  // Water ripples and splashes, electricity arcs over the target, leaves swirl round it, ice crystals shatter,
  // ghostly smoke rises, flames lick up, psychic waves warp, poison bubbles, rocks and dust fly, steel sparks,
  // dragon energy streaks, fairy sparkles, a fighting shockwave, a dark burst, wind for flying, a bug swarm.
  function typeHit(type, at, big) {
    const s2 = big ? 1.5 : 1, a = at;
    switch (type) {
      case 'Water': for (let i = 0; i < 3; i++) setTimeout(() => ring({ ...a, y: 0.04 }, 'rgba(160,210,255,.8)', { flat: true, r1: 1.4 + i * 0.6, life: 0.6, w: 2 }), i * 90); burst(a, '#8cc8ff', 14 * s2, { shape: 'drop', speed: 3, size: 0.12 }); { const sd = a === chest(1) ? 1 : 0; void sd; } break;
      case 'Electric': for (let i = 0; i < 4 * s2; i++) setTimeout(() => particle({ ...a, x: a.x + rnd(-0.6, 0.6), y: a.y + rnd(-0.6, 0.6), life: 0.14, size: 0.3, col: '#fff36a', shape: 'spark' }), i * 40); burst(a, '#ffe23a', 10, { shape: 'spark', speed: 4, size: 0.1 }); break;
      case 'Grass': for (let i = 0; i < 14 * s2; i++) { const ang = (i / 14) * Math.PI * 2; particle({ x: a.x + Math.cos(ang) * 0.9, y: a.y - 0.4 + i * 0.05, z: a.z + Math.sin(ang) * 0.6, vx: -Math.sin(ang) * 2.2, vy: 0.9, vz: Math.cos(ang) * 1.6, life: 0.8, size: 0.14, col: i % 2 ? '#78c850' : '#b8e070', shape: 'leaf', spin: 6 }); } break;
      case 'Ice': burst(a, '#d8f6ff', 16 * s2, { shape: 'shard', speed: 3.4, size: 0.16 }); for (let i = 0; i < 6; i++) particle({ ...a, x: a.x + rnd(-0.5, 0.5), y: a.y + rnd(-0.5, 0.5), life: 0.9, size: 0.2, col: '#ffffff', shape: 'star' }); break;
      case 'Ghost': for (let i = 0; i < 10 * s2; i++) particle({ ...a, x: a.x + rnd(-0.5, 0.5), y: a.y + rnd(-0.3, 0.3), vy: rnd(0.4, 1.1), vx: rnd(-0.3, 0.3), life: 1.2, size: rnd(0.3, 0.55), col: 'rgba(110,70,160,.55)', shape: 'wisp' }); break;
      case 'Fire': for (let i = 0; i < 12 * s2; i++) particle({ ...a, x: a.x + rnd(-0.5, 0.5), y: a.y - 0.4 + rnd(0, 0.4), vy: rnd(1, 2.4), vx: rnd(-0.4, 0.4), life: 0.6, size: rnd(0.16, 0.3), col: '#ff8a2a', shape: 'flame', g: 0.6 }); break;
      case 'Psychic': for (let i = 0; i < 3; i++) setTimeout(() => ring(a, i % 2 ? '#ff7ad8' : '#c070ff', { r1: 1.6 + i * 0.4, life: 0.5, w: 3 }), i * 100); break;
      case 'Poison': for (let i = 0; i < 10 * s2; i++) particle({ ...a, x: a.x + rnd(-0.5, 0.5), y: a.y + rnd(-0.4, 0.2), vy: rnd(0.3, 0.9), life: 0.9, size: rnd(0.1, 0.18), col: '#b060d0', shape: 'bubble' }); break;
      case 'Rock': case 'Ground': burst({ ...a, y: 0.2 }, type === 'Rock' ? '#a89070' : '#c0a060', 14 * s2, { shape: 'rock', speed: 3, size: 0.16 }); smoke({ ...a, y: 0.3 }, 6); break;
      case 'Steel': burst(a, '#e8eef8', 14 * s2, { shape: 'spark', speed: 4.5, size: 0.08 }); particle({ ...a, life: 0.18, size: 0.45, col: '#ffffff', shape: 'star' }); break;
      case 'Dragon': for (let i = 0; i < 8 * s2; i++) { const ang = Math.random() * Math.PI * 2; particle({ ...a, vx: Math.cos(ang) * 3.5, vy: Math.sin(ang) * 3.5, life: 0.4, size: 0.12, col: i % 2 ? '#8a6aff' : '#5ad0ff', shape: 'spark' }); } break;
      case 'Fairy': burst(a, '#ffb0e0', 12 * s2, { shape: 'heart', speed: 2, size: 0.12 }); burst(a, '#ffffff', 8, { shape: 'star', speed: 2.6, size: 0.1 }); break;
      case 'Fighting': ring({ ...a, y: 0.05 }, '#ffffff', { flat: true, r1: 2.6 * s2, life: 0.45, w: 4 }); particle({ ...a, life: 0.16, size: 0.5, col: '#ffe8c0', shape: 'star' }); break;
      case 'Dark': ring(a, 'rgba(40,20,60,.9)', { r1: 1.8 * s2, life: 0.45, w: 6 }); for (let i = 0; i < 8; i++) particle({ ...a, x: a.x + rnd(-0.4, 0.4), vy: rnd(0.3, 0.8), life: 0.8, size: 0.35, col: 'rgba(30,20,40,.6)', shape: 'wisp' }); break;
      case 'Flying': for (let i = 0; i < 3; i++) setTimeout(() => ring(a, 'rgba(230,240,255,.7)', { r1: 1.2 + i * 0.5, life: 0.4, w: 2 }), i * 60); burst(a, '#e8f0ff', 8, { shape: 'feather', speed: 2.4, size: 0.14 }); break;
      case 'Bug': for (let i = 0; i < 14 * s2; i++) { const ang = Math.random() * Math.PI * 2; particle({ ...a, x: a.x + Math.cos(ang) * 0.7, z: a.z + Math.sin(ang) * 0.5, vx: -Math.sin(ang) * 2, vz: Math.cos(ang) * 2, vy: rnd(-0.3, 0.3), life: 0.6, size: 0.05, col: '#a8b820', shape: 'dot' }); } break;
      default: particle({ ...a, life: 0.14, size: 0.42 * s2, col: '#ffffff', shape: 'star' });
    }
  }
  // the moment a physical move connects: a dust cloud and a shockwave on the ground, sparks, a flash, a hitch
  function contactHit(to, big) {
    const a = actor(to); if (!a) return;
    const feet = { x: a.x, y: 0.06, z: a.z };
    ring(feet, 'rgba(255,248,230,.85)', { flat: true, r1: big ? 2.8 : 1.8, life: 0.4, w: big ? 5 : 3 });
    burst(feet, '#cfbf9e', big ? 16 : 9, { shape: 'wisp', speed: 1.6, size: big ? 0.38 : 0.26 });
    burst(chest(to), '#fff6d0', big ? 12 : 7, { shape: 'spark', speed: 4, size: 0.08 });
    if (big) burst(feet, '#a08868', 8, { shape: 'rock', speed: 2.6, size: 0.12 });
    slowmo = Math.max(slowmo, big ? 0.14 : 0.07); // hit-stop: the world catches for an instant
    hype(big ? 0.35 : 0.15);
  }

  // ---------- a finishing pass over the picture ----------
  // A soft bloom on the brightest things (move effects, the sun), gentle colour grading by place and time, and a
  // vignette. Kept light so the creatures are never hidden; dropped when frames run slow.
  const post = { c: null, g: null };
  const GRADE = { volcano: 'rgba(255,120,40,.07)', tundra: 'rgba(150,200,255,.07)', spooky: 'rgba(90,60,140,.1)', desert: 'rgba(255,200,120,.06)', seafloor: 'rgba(40,120,200,.08)', synth: 'rgba(200,60,255,.06)', starfield: 'rgba(60,60,160,.08)', stadium: 'rgba(255,190,120,.05)' };
  let dimK = 0;
  function postFx(ctx) {
    const W = canvas.width, H = canvas.height;
    try { drawNightGlow(ctx); } catch { /* skip */ }
    if (dramatic) { // the place falls dark round a move that glows, so its light carries
      const lit = (yard.dynLights ?? []).reduce((a, l) => a + (l.dyn && l.i > 0.5 ? l.i : 0), 0); dimK += ((lit > 0.8 ? Math.min(0.34, 0.14 + lit * 0.05) : 0) - dimK) * 0.12;
      const base = isNight() ? 0.1 : 0.04;
      ctx.save(); ctx.globalCompositeOperation = 'multiply'; const v = Math.round(255 * (1 - base - dimK)); ctx.fillStyle = `rgb(${v},${v},${Math.min(255, v + 8)})`; ctx.fillRect(0, 0, W, H); ctx.restore();
      // and the lights themselves put back on top, so they stay bright against it
      if (dimK > 0.03 && !lowFx) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; for (const l of yard.dynLights ?? []) { if (!(l.dyn && l.i > 0.5)) continue; const q = project(l); if (!q) continue; const r = Math.max(8, q.k * (l.r ?? 3) * 0.55), c = l.c ?? [255, 255, 255]; ctx.globalAlpha = Math.min(0.5, l.i * 0.16); const gr = ctx.createRadialGradient(q.x, q.y, 0, q.x, q.y, r); gr.addColorStop(0, `rgba(${c[0]},${c[1]},${c[2]},.85)`); gr.addColorStop(1, `rgba(${c[0]},${c[1]},${c[2]},0)`); ctx.fillStyle = gr; ctx.fillRect(q.x - r, q.y - r, r * 2, r * 2); } ctx.restore(); }
    }
    if (!lowFx && W > 0) {
      if (!post.c) { post.c = document.createElement('canvas'); post.g = post.c.getContext('2d'); }
      const bw = Math.max(1, Math.round(W / 6)), bh = Math.max(1, Math.round(H / 6));
      if (post.c.width !== bw) { post.c.width = bw; post.c.height = bh; }
      post.g.filter = 'brightness(0.55) contrast(2.6) blur(2px)'; post.g.clearRect(0, 0, bw, bh); post.g.drawImage(canvas, 0, 0, bw, bh); post.g.filter = 'none';
      ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = dramatic ? 0.4 : 0.22; ctx.imageSmoothingEnabled = true; ctx.drawImage(post.c, 0, 0, W, H); ctx.restore();
    }
    const grade = GRADE[P.look] ?? (yard.tod === 'dusk' ? 'rgba(255,140,80,.06)' : yard.tod === 'night' ? 'rgba(40,60,140,.08)' : null);
    if (grade) { ctx.save(); ctx.globalCompositeOperation = 'soft-light'; ctx.fillStyle = grade.replace(/[\d.]+\)$/, '0.5)'); ctx.globalAlpha = 0.35; ctx.fillRect(0, 0, W, H); ctx.restore(); }
    ctx.drawImage(softSprite('vignette', [[0, 'rgba(0,0,0,0)'], [0.62, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,.42)']]), -W * 0.12, -H * 0.3, W * 1.24, H * 1.6);
    if (dramatic) ctx.drawImage(softSprite('vignette', [[0, 'rgba(0,0,0,0)'], [0.62, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,.42)']]), -W * 0.05, -H * 0.2, W * 1.1, H * 1.4);
  }

  // ---------- weather and terrain you can't miss ----------
  // Rain: the sky darkens with cloud, heavy slanting rain blown by the wind, ripples spreading on the ground.
  // Harsh sunlight: a warm glare, yellow sunbeams fanning down and heat shimmering off the ground. Sandstorm:
  // a brown haze with grit racing across. Snow: big flakes in front of the camera and a white haze. Terrains
  // cover the field: crackling yellow light (Electric), green with blades and drifting leaves (Grassy), pink
  // mist (Misty), purple pulses (Psychic).
  const WX = { streaks: [], ripples: [], flakes: [], grit: [], t: 0 };
  function fieldPoly(r, y = 0.02) { const { n, f } = axis(), cx = (n.x + f.x) / 2, cz = (n.z + f.z) / 2, pts = []; for (let i = 0; i < 20; i++) { const a = (i / 20) * Math.PI * 2, q = project({ x: cx + Math.cos(a) * r, y, z: cz + Math.sin(a) * r * 0.75 }); if (q) pts.push(q); } return pts; }
  function fillField(ctx, r, fill) { const pts = fieldPoly(r); if (pts.length < 3) return; ctx.beginPath(); pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y))); ctx.closePath(); ctx.fillStyle = fill; ctx.fill(); }
  function drawBattleWeather(ctx, dt) {
    const W = canvas.width, H = canvas.height, w = weatherNow, T2 = (WX.t += dt);
    const amb = !w && !indoor ? ambientWx : null;
    const rainy = w === 'raindance' || w === 'primordialsea' || amb === 'rain' || amb === 'storm';
    const sunny = w === 'sunnyday' || w === 'desolateland';
    const sandy = w === 'sandstorm';
    const snowy = w === 'snow' || w === 'snowscape' || w === 'hail' || amb === 'snow';
    const heavy = !!w; // a move's weather is laid on thick; the real sky's a little lighter
    ctx.save();
    if (rainy) {
      // the sky darkens with cloud
      const g = ctx.createLinearGradient(0, 0, 0, H * 0.7); g.addColorStop(0, `rgba(18,24,38,${heavy ? 0.55 : 0.35})`); g.addColorStop(1, 'rgba(18,24,38,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = `rgba(30,38,58,${heavy ? 0.16 : 0.1})`; ctx.fillRect(0, 0, W, H);
      // heavy rain slanting in the wind (gusting)
      const gust = Math.max(0, Math.sin(T2 * 0.55)) ** 3, wind = (heavy ? 0.45 : 0.3) + Math.sin(T2 * 0.7) * 0.14 + gust * 0.45, n = lowFx ? 120 : heavy ? 420 : 160;
      while (WX.streaks.length < n) WX.streaks.push({ x: Math.random() * W * 1.6 - W * 0.4, y: Math.random() * H, v: H * (2.0 + Math.random() * 1.1), l: H * (0.05 + Math.random() * 0.07), a: 0.25 + Math.random() * 0.35 });
      if (WX.streaks.length > n) WX.streaks.length = n;
      // sheets of rain blown across in the gusts
      if (heavy && !lowFx) for (let i = 0; i < 3; i++) { const x = ((T2 * W * (0.5 + gust) + i * W * 0.45) % (W * 1.8)) - W * 0.4; const g2 = ctx.createLinearGradient(x - W * 0.2, 0, x + W * 0.2, 0); g2.addColorStop(0, 'rgba(190,205,230,0)'); g2.addColorStop(0.5, `rgba(190,205,230,${(0.07 + gust * 0.1).toFixed(3)})`); g2.addColorStop(1, 'rgba(190,205,230,0)'); ctx.fillStyle = g2; ctx.fillRect(x - W * 0.2, 0, W * 0.4, H); }
      ctx.lineWidth = Math.max(1.2, W / (heavy ? 520 : 700)); ctx.strokeStyle = `rgba(205,220,245,${heavy ? 0.6 : 0.45})`; ctx.beginPath();
      for (const d of WX.streaks) { d.y += d.v * dt; d.x += d.v * dt * wind; if (d.y > H) { d.y = -d.l; d.x = Math.random() * W * 1.6 - W * 0.6; } ctx.moveTo(d.x, d.y); ctx.lineTo(d.x - d.l * wind, d.y - d.l); }
      ctx.stroke();
      // ripples spreading on the field
      if (Math.random() < dt * (heavy ? 26 : 14)) { const { n: a, f: b } = axis(); WX.ripples.push({ x: lerp(a.x, b.x, Math.random()) + rnd(-4, 4), z: lerp(a.z, b.z, Math.random()) + rnd(-3, 3), t: 0 }); }
      ctx.strokeStyle = 'rgba(220,235,255,.5)'; ctx.lineWidth = 1;
      for (let i = WX.ripples.length - 1; i >= 0; i--) { const r = WX.ripples[i]; r.t += dt; if (r.t > 0.7) { WX.ripples.splice(i, 1); continue; } const q = project({ x: r.x, y: 0.02, z: r.z }); if (!q) continue; const rad = q.k * (0.05 + r.t * 0.5); ctx.globalAlpha = 1 - r.t / 0.7; ctx.beginPath(); ctx.ellipse(q.x, q.y, rad, rad * 0.35, 0, 0, Math.PI * 2); ctx.stroke(); }
      ctx.globalAlpha = 1;
      // mist hanging low
      const m = ctx.createLinearGradient(0, H * 0.55, 0, H); m.addColorStop(0, 'rgba(190,205,225,0)'); m.addColorStop(1, `rgba(190,205,225,${heavy ? 0.22 : 0.14})`); ctx.fillStyle = m; ctx.fillRect(0, H * 0.5, W, H * 0.5);
    }
    if (sunny) {
      // heat haze: the lower part of the picture wavering in the rising heat
      if (!lowFx && heavy) { const sh = Math.max(2, Math.round(H / 90)); for (let y = Math.round(H * 0.45); y < H; y += sh) { const off = Math.sin(y * 0.09 + T2 * 7) * H * 0.0035 * (0.5 + (y / H)); ctx.drawImage(canvas, 0, y, W, sh, off, y, W, sh); } }
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = `rgba(255,175,70,${heavy ? 0.16 : 0.08})`; ctx.fillRect(0, 0, W, H);
      if (heavy) { const gl = ctx.createRadialGradient(W * 0.82, 0, 0, W * 0.82, 0, W * 0.9); gl.addColorStop(0, 'rgba(255,245,200,.35)'); gl.addColorStop(1, 'rgba(255,230,160,0)'); ctx.fillStyle = gl; ctx.fillRect(0, 0, W, H); WX.glare = (WX.glare ?? 2) - dt; if (WX.glare <= 0) { WX.glare = 3.5 + Math.random() * 3; lensHit('sun', 1); } }
      // sunbeams fanning down from the sun, slowly turning and breathing
      const sx = W * 0.82, sy = -H * 0.08;
      for (let i = 0; i < 7; i++) {
        const a = Math.PI * 0.62 + i * 0.13 + Math.sin(T2 * 0.25 + i) * 0.03, len = H * 1.5, wdt = 0.035 + (i % 3) * 0.012;
        const al = 0.1 + 0.07 * Math.sin(T2 * 0.9 + i * 1.7);
        const g = ctx.createLinearGradient(sx, sy, sx + Math.cos(a) * len, sy + Math.sin(a) * len); g.addColorStop(0, `rgba(255,236,150,${(al + 0.08).toFixed(3)})`); g.addColorStop(1, 'rgba(255,220,120,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx + Math.cos(a - wdt) * len, sy + Math.sin(a - wdt) * len); ctx.lineTo(sx + Math.cos(a + wdt) * len, sy + Math.sin(a + wdt) * len); ctx.closePath(); ctx.fill();
      }
      ctx.drawImage(softSprite('sunDisc', [[0, 'rgba(255,255,235,1)'], [0.25, 'rgba(255,230,140,.85)'], [1, 'rgba(255,200,80,0)']]), sx - H * 0.3, sy - H * 0.3, H * 0.6, H * 0.6);
      ctx.globalCompositeOperation = 'source-over';
      // heat shimmering off the ground
      ctx.strokeStyle = `rgba(255,250,235,${heavy ? 0.16 : 0.09})`; ctx.lineWidth = Math.max(1.5, H / 260);
      for (let i = 0; i < (lowFx ? 6 : 12); i++) { const y0 = H * (0.98 - ((T2 * 0.06 + i / 12) % 1) * 0.5); ctx.beginPath(); for (let x = 0; x <= W; x += W / 24) { const y = y0 + Math.sin(x * 0.03 + T2 * 4 + i) * H * 0.006; x ? ctx.lineTo(x, y) : ctx.moveTo(x, y); } ctx.stroke(); }
    }
    if (sandy) {
      ctx.fillStyle = 'rgba(176,136,80,.26)'; ctx.fillRect(0, 0, W, H);
      while (WX.grit.length < (lowFx ? 80 : 160)) WX.grit.push({ x: Math.random() * W, y: Math.random() * H, v: W * (0.9 + Math.random() * 0.9), l: W * (0.01 + Math.random() * 0.03) });
      ctx.strokeStyle = 'rgba(232,200,140,.55)'; ctx.lineWidth = Math.max(1, W / 800); ctx.beginPath();
      for (const gq of WX.grit) { gq.x += gq.v * dt; gq.y += Math.sin(T2 * 3 + gq.x * 0.01) * 20 * dt; if (gq.x > W + gq.l) { gq.x = -gq.l; gq.y = Math.random() * H; } ctx.moveTo(gq.x, gq.y); ctx.lineTo(gq.x - gq.l, gq.y + gq.l * 0.08); }
      ctx.stroke();
      for (let i = 0; i < 4; i++) { const x = ((T2 * W * 0.3 + i * W * 0.37) % (W * 1.6)) - W * 0.3; ctx.drawImage(softSprite('dust', [[0, 'rgba(210,170,110,.35)'], [1, 'rgba(210,170,110,0)']]), x - W * 0.25, H * (0.35 + i * 0.12) - H * 0.2, W * 0.5, H * 0.4); }
    }
    if (snowy) {
      const m = ctx.createLinearGradient(0, H * 0.35, 0, H); m.addColorStop(0, 'rgba(235,242,255,0)'); m.addColorStop(1, `rgba(235,242,255,${heavy ? 0.32 : 0.2})`); ctx.fillStyle = m; ctx.fillRect(0, 0, W, H);
      const hail = w === 'hail';
      const nF = (lowFx ? 40 : 80) * (heavy ? 2 : 1);
      while (WX.flakes.length < nF) WX.flakes.push({ x: Math.random() * W, y: Math.random() * H, v: H * (0.12 + Math.random() * 0.2), r: H * (0.004 + Math.random() * 0.012), ph: Math.random() * 6 });
      if (WX.flakes.length > nF) WX.flakes.length = nF;
      for (const fl of WX.flakes) {
        const v = hail ? fl.v * 6 : heavy ? fl.v * 1.6 : fl.v;
        fl.y += v * dt; fl.x += Math.sin(T2 * 1.4 + fl.ph) * H * 0.04 * dt + (hail ? v * 0.25 * dt : heavy ? H * 0.12 * dt : 0); if (fl.y > H + fl.r) { fl.y = -fl.r; fl.x = Math.random() * W * 1.2 - W * 0.2; }
        if (hail) { ctx.fillStyle = 'rgba(225,240,255,.9)'; ctx.fillRect(fl.x, fl.y, fl.r * 1.1, fl.r * 1.6); ctx.fillStyle = 'rgba(200,225,255,.35)'; ctx.fillRect(fl.x - v * dt * 0.25, fl.y - v * dt, fl.r * 0.7, v * dt); }
        else ctx.drawImage(softSprite('flake', [[0, 'rgba(255,255,255,.95)'], [0.6, 'rgba(255,255,255,.6)'], [1, 'rgba(255,255,255,0)']]), fl.x - fl.r, fl.y - fl.r, fl.r * 2, fl.r * 2);
      }
      // hailstones bouncing off the ground
      if (hail && Math.random() < dt * (lowFx ? 12 : 30)) { const { n: a, f: b } = axis(); const x = lerp(a.x, b.x, Math.random()) + rnd(-4, 4), z = lerp(a.z, b.z, Math.random()) + rnd(-3, 3); particle({ x, y: 0.05, z, vx: rnd(-1, 1), vy: rnd(1.5, 3), vz: rnd(-1, 1), g: -14, bounce: true, life: 0.7, size: rnd(0.06, 0.12), col: '#e8f6ff', shape: 'shard', spin: rnd(-10, 10) }); }
      // snowflakes landing on the lens, then melting off
      if (heavy || amb === 'snow') { WX.lensSnow = (WX.lensSnow ?? 1) - dt; if (WX.lensSnow <= 0) { WX.lensSnow = hail ? 0.9 : heavy ? 1.3 : 3; lensHit('snow', hail ? 2 : 2 + Math.floor(Math.random() * 2)); } }
    }
    // terrains, laid over the whole field
    if (terrainNow) {
      const pulse = 0.5 + 0.5 * Math.sin(T2 * 2.4);
      const look = { electricterrain: ['rgba(255,226,60,', 0.22], grassyterrain: ['rgba(90,200,80,', 0.24], mistyterrain: ['rgba(255,170,220,', 0.2], psychicterrain: ['rgba(190,90,255,', 0.22] }[terrainNow];
      if (look) {
        ctx.globalCompositeOperation = terrainNow === 'mistyterrain' ? 'source-over' : 'lighter';
        fillField(ctx, 8.5, `${look[0]}${(look[1] * (0.75 + 0.25 * pulse)).toFixed(3)})`);
        ctx.globalCompositeOperation = 'source-over';
        if (terrainNow === 'electricterrain' && Math.random() < dt * 9) { // crackles running along the ground
          const pts = fieldPoly(rnd(1, 7.5)); if (pts.length) { const a = pts[Math.floor(Math.random() * pts.length)]; ctx.strokeStyle = 'rgba(255,250,190,.9)'; ctx.lineWidth = 1.6; ctx.beginPath(); let x = a.x, y = a.y; ctx.moveTo(x, y); for (let i = 0; i < 6; i++) { x += rnd(-W * 0.03, W * 0.03); y += rnd(-H * 0.01, H * 0.01); ctx.lineTo(x, y); } ctx.stroke(); }
        }
        if (terrainNow === 'grassyterrain' && Math.random() < dt * 6) { const { n: a, f: b } = axis(); particle({ x: lerp(a.x, b.x, Math.random()) + rnd(-4, 4), y: 0.1, z: lerp(a.z, b.z, Math.random()) + rnd(-3, 3), vy: rnd(0.3, 0.8), vx: rnd(-0.4, 0.4), life: 1.6, size: 0.14, col: Math.random() < 0.5 ? '#78c850' : '#a8e070', shape: 'leaf', spin: rnd(-3, 3) }); }
        if (terrainNow === 'mistyterrain') { const m = ctx.createLinearGradient(0, H * 0.5, 0, H); m.addColorStop(0, 'rgba(255,220,240,0)'); m.addColorStop(1, `rgba(255,220,240,${(0.22 + 0.06 * pulse).toFixed(3)})`); ctx.fillStyle = m; ctx.fillRect(0, H * 0.45, W, H * 0.55); }
        if (terrainNow === 'psychicterrain' && Math.random() < dt * 1.6) ring(chest(0, 0.02), '#c070ff', { flat: true, r1: 9, life: 1.4, w: 3 });
      }
    }
    ctx.restore();
  }

  // ---------- Showdown's events ----------
  let lastTeam = null, summons = 0, lastTurn = 0;
  let intro = null, revealed = false, waitingNear = false, introOver = false;
  const lastLookChange = [0, 0];
  const changedJustNow = (side) => performance.now() - lastLookChange[side] < 600;
  const leaving = [0, 0]; // when the one going out on each side will be gone (performance.now ms)
  // while the opening plays, Showdown's buttons and log stay hidden (they'd spoil it)
  function setIntro(on) { if (!on) introOver = true; const host = el.closest('.cl-sd'); if (host) host.classList.toggle('cl-sd-intro', on); }
  setTimeout(() => { setIntro(false); hud[0].hidden = !mons[0]; hud[1].hidden = !mons[1]; }, 20000);
  // a ball pops open: white flash, and they grow into place
  // sent out: a streak of white light from the trainer to the spot, a shape of white light growing there, then
  // the light falls away and it's itself
  function popOut(side, { streak = !!trainerPics[side] } = {}) { // (no trainer to be seen: it just forms out of white light)
    const a = actor(side); if (!a) return;
    const base = a.baseSize ?? 1;
    a.alpha = 1; a.hitFlash = 1; a.redLight = 0; a.sizeMul = base * 0.1;
    const tp = trainerAt(side), from = { x: tp.x, y: 1.2, z: tp.z }, to = chest(side, 0.4);
    if (streak) fx.push({ t: 0, life: 0.3, draw(ctx) { const k = Math.min(1, this.t / this.life), a1 = project(from), b1 = project(to); if (!a1 || !b1) return; ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = `rgba(255,255,255,${0.9 * (1 - k * 0.5)})`; ctx.lineWidth = 5; ctx.shadowColor = '#bfe4ff'; ctx.shadowBlur = 16; ctx.beginPath(); ctx.moveTo(a1.x, a1.y); ctx.lineTo(lerp(a1.x, b1.x, Math.min(1, k * 1.6)), lerp(a1.y, b1.y, Math.min(1, k * 1.6))); ctx.stroke(); ctx.restore(); } });
    fx.push({ t: 0, life: 0.85, update() { const a2 = actor(side); if (!a2) return; const k = this.t / this.life; a2.sizeMul = base * lerp(0.1, 1, ease(Math.min(1, Math.max(0, k - 0.15) / 0.5))); if (k > 0.72 && a2.hitFlash) { a2.hitFlash = 0; burst(chest(side, 0.5), '#ffffff', 14, { speed: 2.4, shape: 'star', size: 0.1 }); } },
      end() { const a2 = actor(side); if (a2) { a2.sizeMul = base; a2.hitFlash = 0; } } });
    setTimeout(() => { if (!actor(side)) return; burst(chest(side, 0.3), '#ffffff', 16, { speed: 2, shape: 'star', size: 0.1 }); ring(chest(side, 0.02), '#ffffff', { flat: true, r1: 1.6, life: 0.5 }); lightFlash(chest(side, 0.5), [230, 240, 255], { r: 4, i: 0.9, life: 0.4 }); }, streak ? 260 : 0);
  }
  // the wild one's entrance: out of the dark, up close, it cries out and the screen shakes; then yours is
  // sent out (with you behind it) and the battle begins
  function wildReveal(side) {
    if (revealed) return;
    revealed = true;
    const T = tempo();
    cutTo(() => SHOT.front(side, 0.95), { hold: 2.5 * T, drift: 0.1 });
    black.classList.remove('on');
    hud[1].hidden = true;
    setTimeout(() => {
      if (destroyed) return;
      const a = actor(side); if (a) a.hop = 1.2;
      shake = Math.max(shake, 2.2);
      const head = chest(side, 0.85);
      for (let i = 0; i < 3; i++) setTimeout(() => ring(head, '#ffffff', { r0: 0.3, r1: 3.2, life: 0.55, w: 5 }), i * 150);
      el.classList.add('cry'); setTimeout(() => el.classList.remove('cry'), 700);
    }, 1000 * T);
    queueShot(() => (trainerPics[0] ? SHOT.team(0) : SHOT.shoulder(0)), { hold: 1.9 * T, drift: 0.25 });
    setTimeout(() => {
      if (destroyed) return;
      waitingNear = false;
      if (actor(0)) popOut(0);
    }, 2700 * T);
    home(1.4);
    setTimeout(() => { bars.classList.remove('on'); setIntro(false); hud[0].hidden = !mons[0]; hud[1].hidden = !mons[1]; }, 5000 * T);
  }

  function event(ev) {
    if (ev && typeof ev.terrain === 'string') terrainNow = ev.terrain || null;
    if (destroyed) return;
    lastTeam = ev.team ?? lastTeam;
    const m = ev.mon;
    if (m && mons[m.side]) mons[m.side].info = { ...mons[m.side].info, ...m };
    switch (ev.t) {
      case 'animSummon': case 'animDragIn': {
        if (!m) break;
        // blown out and replaced in the same moment (Whirlwind, Roar, Dragon Tail, Circle Throw, Red Card…):
        // the one leaving finishes going first, then the new one is dragged in
        const wait = leaving[m.side] ? leaving[m.side] - performance.now() : 0;
        if (wait > 0) { const ev2 = { ...ev }; setTimeout(() => { if (!destroyed) event(ev2); }, wait + 40); leaving[m.side] = 0; break; }
        const a = placeMon(m.side, m);
        if (!a) break;
        summons++;
        renderHud(m.side, m, lastTeam);
        if (!introOver && intro !== 'trainer' && m.side === 1) hud[1].hidden = true;
        const T = tempo();
        if (!started) {
          setIntro(true);
          started = true;
          if (trainers.foe || versus) {
            // a trainer battle (or a battle against someone online): from far out over the whole place, then each trainer with their creature
            intro = 'trainer';
            popOut(m.side);
            black.classList.remove('on');
            cutTo(SHOT.wide, { hold: 1.8 * T, drift: 1.3 });
            queueShot(() => SHOT.team(1), { hold: 2 * T, drift: 0.25 });
            queueShot(() => SHOT.team(0), { hold: 2 * T, drift: 0.25 });
            home(1.4);
            setTimeout(() => { bars.classList.remove('on'); setIntro(false); hud[0].hidden = !mons[0]; hud[1].hidden = !mons[1]; }, 6000 * T);
          } else {
            // a wild battle: it stays dark until the wild one is there
            intro = 'wild';
            if (m.side === 0) { a.alpha = 0; hud[0].hidden = true; waitingNear = true; cutTo(() => SHOT.front(1, 0.95), { hold: 30, drift: 0 }); setTimeout(() => { if (!revealed) wildReveal(1); }, 4000); }
            else wildReveal(m.side);
          }
        } else if (intro === 'wild' && !revealed && m.side === 1) wildReveal(1);
        else {
          popOut(m.side);
          if (dynamic && summons > 2) { cutTo(() => (trainerPics[m.side] ? SHOT.team(m.side) : SHOT.front(m.side, 1.2)), { hold: 1.3 * T, drift: 0.25 }); home(1); }
        }
        if (waitingNear && m.side === 0) hud[0].hidden = true;
        break;
      }
      case 'animUnsummon': case 'animDragOut': {
        if (!m || !actor(m.side)) break;
        const side = m.side, base = actor(side).baseSize ?? 1, sp = specs[side], dragged = ev.t === 'animDragOut';
        const life = dragged ? 0.55 : 0.75;
        leaving[side] = performance.now() + life * 1000;
        if (!dragged && dynamic) { cutTo(() => (trainerPics[side] ? SHOT.team(side) : SHOT.front(side, 1.5)), { hold: life + 0.2, drift: 0.2 }); }
        // only ever acts on the one leaving: whoever comes in next is left alone
        fx.push({ t: 0, life, update() { if (specs[side] !== sp) return; const a2 = actor(side); if (!a2) return; const k = ease(this.t / this.life); a2.sizeMul = base * (1 - k * 0.9); if (dragged) a2.hitFlash = 1; else { a2.redLight = 1; a2.y = k * 0.5; } a2.alpha = 1 - k * k; if (dragged) { const { u } = axis(), dir = side === 0 ? -1 : 1; a2.x = a2.tx + u.x * dir * k * 2.2; a2.z = a2.tz + u.z * dir * k * 2.2; a2.y = k * 0.8; } },
          end() { if (specs[side] === sp) remove(side); const a2 = actor(side); if (a2 && dragged) a2.y = 0; } });
        if (dragged) { const c = chest(side, 0.4); for (let i = 0; i < 18; i++) particle({ ...c, x: c.x + rnd(-0.6, 0.6), vx: rnd(-2.5, 2.5), vy: rnd(0.3, 1.6), vz: rnd(-1.5, 1.5), life: 0.6, size: 0.18, col: 'rgba(230,240,255,.8)', shape: 'wisp' }); }
        else { ring(chest(side, 0.4), '#ff6a6a', { r1: 0.8, life: 0.4 }); // the red beam back to the trainer (when there's one to be seen)
          if (trainerPics[side]) fx.push({ t: 0, life, draw(ctx) { const a1 = project(chest(side, 0.45)), tp = trainerAt(side), b1 = project({ x: tp.x, y: 1.1, z: tp.z }); if (!a1 || !b1) return; const k = this.t / this.life; ctx.save(); ctx.strokeStyle = `rgba(255,70,70,${0.9 * Math.sin(k * Math.PI)})`; ctx.lineWidth = 6; ctx.shadowColor = '#ff3a3a'; ctx.shadowBlur = 14; ctx.beginPath(); ctx.moveTo(a1.x, a1.y); ctx.lineTo(b1.x, b1.y); ctx.stroke(); ctx.restore(); } }); }
        break;
      }
      case 'animFaint': {
        if (!m || !actor(m.side)) break;
        const side = m.side, base = actor(side).baseSize ?? 1;
        if (dynamic) { if (faintCam === side && cur && !cur.isHome) { shots.length = 0; cur.hold = Math.max(0, cur.t - cur.dur) + 1.9 * tempo(); home(1.2); } else { cutTo(() => SHOT.front(side, 1.35), { hold: 1.9 * tempo(), drift: 0.15 }); home(1.2); } faintCam = null; }
        cast(pick([`${nameOf(side)} is down!`, `${nameOf(side)} can’t go on!`, 'And it’s over for that one!']), { force: true });
        crowdFlash(12);
        vanished[side] = null;
        // an exaggerated cry as it rears back and lets out a burst, a sag, then down (yours goes back to its ball in a red beam)
        const st = performance.now();
        try { const c0 = creatureFor(mons[side]?.info ?? m); const BS = globalThis.__clBattleSound; if (c0 && !BS?.muted) creatureCry(speciesOf(idx, c0), c0, { faint: true, mood: 'sad' }); } catch { /* no sound */ }
        { const ch = chest(side, 0.5), tcol = lookOf((mons[side]?.info?.types ?? m.types ?? [])[0] || 'Normal').col ?? '#ffffff';
          burst(ch, tcol, 22, { speed: 3.2, shape: 'star', size: 0.12 }); burst(ch, '#ffffff', 10, { speed: 2.2, shape: 'spark', size: 0.1 });
          ring(chest(side, 0.04), tcol, { flat: true, r1: 2, life: 0.6 }); shake = Math.max(shake, 0.8); }
        posing[side]++; // (idle breathing leaves it alone now)
        const owned = side === 0 || intro === 'trainer';
        fx.push({ t: 0, life: 1.9, update() { const a2 = actor(side); if (!a2) return; const k = this.t / this.life;
          if (k < 0.22) { const r = Math.sin((k / 0.22) * Math.PI); a2.pose = { lean: 0.28 * r * awayDir(side), sy: 1 + 0.18 * r, sx: 1 - 0.08 * r }; a2.jitter = Math.sin(this.t * 60) * 2.5 * r; a2.y = 0; }
          else if (k < 0.4) { a2.pose = null; a2.jitter = Math.sin(this.t * 50) * 3; a2.y = 0; }
          else if (owned) { // turned to red light and drawn back into its ball
            a2.jitter = 0; a2.pose = null; const k2 = ease((k - 0.4) / 0.6); a2.hitFlash = 1; a2.redLight = 1; a2.sizeMul = base * (1 - k2 * 0.9); a2.y = k2 * 0.5; a2.alpha = 1 - k2 * k2;
            if (Math.random() < 0.5) particle({ ...chest(side, 0.5), vx: rnd(-0.6, 0.6), vy: rnd(0.2, 1), life: 0.4, size: 0.12, col: '#ff5a5a', shape: 'spark' }); }
          else { a2.jitter = 0; const k2 = ease((k - 0.4) / 0.6); a2.pose = { lean: awayDir(side) * 1.1 * k2, sy: 1 - 0.15 * k2 }; a2.sizeMul = base * (1 - k2 * 0.25); a2.y = -k2 * 0.35; a2.alpha = 1 - k2; } }, // a wild one just falls
          draw(ctx) { if (!owned || !trainerPics[side] || this.t < 0.45) return; const a = project(chest(side)), tp = trainerAt(side), b = project({ x: tp.x, y: 1.1, z: tp.z }); if (!a || !b) return; ctx.save(); ctx.strokeStyle = 'rgba(255,60,60,.85)'; ctx.lineWidth = 6; ctx.shadowColor = '#ff3a3a'; ctx.shadowBlur = 14; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.restore(); },
          end() { remove(side); } });
        void st;
        for (let i = 0; i < 14; i++) particle({ ...chest(side, 0.05), x: chest(side, 0).x + rnd(-0.8, 0.8), vy: rnd(0.2, 0.8), vx: rnd(-0.5, 0.5), life: 0.9, size: 0.2, col: 'rgba(220,210,190,.8)', shape: 'wisp' });
        renderHud(side, { ...m, pct: 0, fainted: true }, lastTeam);
        break;
      }
      case 'damageAnim': {
        if (!m) break;
        const direct = !!kb[m.side] || performance.now() - hitAt[m.side] < 2600;
        { const was = lastPct[m.side] ?? 1, sev = Math.max(0, was - (m.pct ?? was)); lastPct[m.side] = m.pct;
          if (direct) { hitFlash(m.side, 1); if (!kb[m.side]) { if (sev > 0.06 && !vanished[m.side]) slideBack(m.side, sev, critNow); else react(m.side, sev, critNow); } }
          else { // residual damage (poison, a burn, the weather, being bound…): no knockback, just a wince, tinted by what's hurting it
            const sa = lastStatusAnim[m.side], why = sa && performance.now() - sa.at < 2500 ? sa.id : null, a0 = actor(m.side);
            const tint = why === 'brn' ? 'brn' : why === 'psn' || why === 'tox' ? 'psn' : null;
            if (a0) { const prev = a0.tint; if (tint) a0.tint = tint; else hitFlash(m.side, 0.5); const s0 = m.side; posefx(s0, 0.5, (k) => ({ sx: 1 + Math.sin(k * Math.PI * 4) * 0.03, sy: 1 - Math.sin(k * Math.PI) * 0.05, dx: Math.sin(k * Math.PI * 6) * 0.03 })); if (tint) setTimeout(() => { const a1 = actor(s0); if (a1 && a1.tint === tint) a1.tint = prev ?? null; }, 900); }
          }
          critNow = false;
          // a finishing blow gets room to breathe: a slow beat on it before it goes down
          if (m.pct === 0 && dynamic) { slowmo = Math.max(slowmo, 0.9); damageWait = Math.max(damageWait, 0) + 600; screenFlash('#ffffff', 140); hype(1); } }
        const drain = renderHud(m.side, m, lastTeam) || 0;
        // stay on the one that was hurt while its HP drains, then a beat more (Battle Revolution)
        if (dynamic && drain && tempo() >= 0.5 && actor(m.side)) {
          const sd = m.side, onIt = cur && !cur.isHome && cur.follow == null && cur.make && (() => { try { const a = cur.make(), b = SHOT.front(sd, 1.25); return Math.hypot(a.eye.x - b.eye.x, a.eye.z - b.eye.z) < 2.5; } catch { return false; } })();
          shots.length = 0; if (!onIt) cur = null;
          if (crowdy && m.pct > 0 && m.pct < 0.25) { try { crowdSnd?.gasp(); } catch { /* fine */ } }
          const back = comeBack(sd, drain + 0.15);
          // (about to faint: the camera stays right here until it does, no cutting away and back)
          queueShot(() => SHOT.front(sd, m.pct === 0 ? 1.35 : 1.6), { dur: 0.45, hold: m.pct === 0 ? 12 : drain + 0.4 + back, drift: 0.12 });
          if (onIt) cur = null; // glide from where it is to the hurt shot
          if (m.pct === 0) faintCam = sd; else home(1.0);
          damageWait = (drain + 0.65 + back + (m.pct === 0 ? 0.35 : 0)) * 1000;
        } else { const back = comeBack(m.side, 0.5); damageWait = back ? (0.6 + back) * 1000 : 0; }
        if (m.pct > 0 && m.pct < 0.25 && !pinched[m.side]) { pinched[m.side] = true; cast(pick([`${nameOf(m.side)} is in a real pinch!`, `${nameOf(m.side)} is hanging on by a thread!`, 'One more hit could do it!']), { force: true }); }
        break;
      }
      case 'healAnim': {
        if (!m) break;
        sparkleOn(m.side, '#9dffb8', 'star', 14); aura(m.side, '#7dffa0');
        renderHud(m.side, m, lastTeam);
        break;
      }
      case 'updateStatbar': case 'animTransform': {
        if (!m) break;
        // a new form (Castform with the weather, Mega Evolution, Transform, Zen Mode, Blade Forme…), and turning
        // back when a weather ends or an ability is lost
        if (actor(m.side) && changeLook(m.side, m) || (ev.t === 'animTransform' && actor(m.side) && !changedJustNow(m.side))) {
          const s0 = m.side, c0 = chest(s0); screenFlash('#ffffff', 300); burst(c0, '#ffffff', 24, { shape: 'star' }); ring(c0, '#ffffff', { r1: 2.2, life: 0.5, w: 5 });
          const a0 = actor(s0); if (a0) { a0.hitFlash = 1; setTimeout(() => { const a1 = actor(s0); if (a1) a1.hitFlash = 0; }, 260); }
          if (dynamic && ev.t === 'animTransform') { cutTo(() => SHOT.front(s0, 1.15), { hold: 1.3 * tempo(), drift: 0.15 }); home(0.9); }
          lastLookChange[s0] = performance.now();
        }
        renderHud(m.side, m, lastTeam);
        break;
      }
      case 'incrementTurn': lastTurn = ev.turn ?? lastTurn + 1; break;
      case 'runMoveAnim': playMove(ev); break;
      case 'runPrepareAnim': {
        // the first turn of a two-turn move: flying up, digging down, vanishing, or gathering power
        if (!ev.from) break;
        const side = ev.from.side, how = vanishOf(ev.move), T = tempo();
        announce(side, ev.move);
        if (dynamic && T >= 0.5) { cutTo(() => SHOT.front(side, 1.2), { hold: 1.5 * T, drift: 0.2 }); home(0.8); }
        setTimeout(() => { if (destroyed) return; if (how) vanish(side, how, ev.move.type); else chargeUp(side, ev.move.type); }, 500 * T);
        if (how) cast(pick(how === 'up' ? ['Up, up and away!', 'It’s taken to the skies!'] : how === 'gone' ? ['It’s vanished into thin air!', 'Where did it go?!'] : ['It’s gone underground!', 'It’s hidden itself away!']), { force: true });
        else cast(pick(['It’s gathering power…', 'Something big is coming!']), { force: true });
        break;
      }
      case 'runStatusAnim': {
        if (!m) break;
        const id = ev.id; lastStatusAnim[m.side] = { id, at: performance.now() };
        if (id === 'brn') burst(chest(m.side), '#ff7a2a', 10, { shape: 'flame', speed: 1, up: 1.5, g: 1 });
        else if (id === 'par') bolts(m.side, { fromSky: false, from: m.side });
        else if (id === 'psn' || id === 'tox') for (let i = 0; i < 10; i++) particle({ ...chest(m.side), x: chest(m.side).x + rnd(-0.5, 0.5), vy: rnd(0.4, 1), life: 0.8, size: 0.14, col: '#b85ae0', shape: 'bubble' });
        else if (id === 'slp') for (let i = 0; i < 3; i++) particle({ ...chest(m.side, 1), x: chest(m.side, 1).x + i * 0.2, vy: 0.6, vx: 0.3, life: 1.2, size: 0.18, col: '#ffffff', shape: 'zzz' });
        else if (id === 'frz') burst(chest(m.side), '#a8f2ff', 14, { shape: 'shard', speed: 1.2 });
        else if (id === 'confused') sparkleOn(m.side, '#ffe86a', 'star', 8);
        else sparkleOn(m.side, '#ffffff', 'star', 6);
        break;
      }
      case 'resultAnim': {
        if (!m) break;
        const t = decode(ev.text);
        if (!t) break;
        const good = ev.kind === 'good';
        const pctText = /%/.test(t); // damage and healing show as percentages; stat changes don't
        const mult = t.match(/([\d.]+)\s*[×x]\s*(.+)/i), mv = mult ? Number(mult[1]) : NaN;
        const upS = !pctText && (mult ? mv > 1 || (mv === 1 && ev.kind !== 'bad' && false) : /[+]\d|↑|rose|raised/i.test(t)), downS = !pctText && (mult ? mv < 1 : /[-−]\d|↓|fell|lowered/i.test(t));
        if (upS || downS || mult) { const st2 = STAT_OF(mult ? mult[2] : t), wentUp = mult ? (statNow[m.side][st2] ?? 1) < mv : upS; chevrons(m.side, wentUp, st2); statNote(m.side, st2 ?? t, mult ? mv : null, t, wentUp); }
        else if (/effective/i.test(t)) { /* (said once, from the message) */ }
        else if (!pctText || /crit/i.test(t)) notify(m.side, t.replace(/\s*[-−+]?\d+%/, '').trim() || t, good ? 'good' : ev.kind === 'bad' ? 'bad' : 'info');
        if (/crit/i.test(t)) { screenFlash('#ffffff', 160); shake = Math.max(shake, 1); }
        if (!pctText && /[+]\d/.test(t)) cast(pick([`${nameOf(m.side)} is powering up!`, `${nameOf(m.side)} is getting fired up!`]));
        if (/miss|avoid/i.test(t)) cast(pick(['It missed! What a dodge!', 'Just out of reach!', 'Not even close!']), { force: true });
        break;
      }
      case 'abilityActivateAnim': if (m) notify(m.side, decode(ev.text), 'ability', '#ffe48a'); break;
      case 'updateWeather': {
        if ((ev.weather || null) !== weatherNow && ev.weather) { const wk = { raindance: 'rain', primordialsea: 'rain', sunnyday: 'sun', desolateland: 'sun', sandstorm: 'dirt', hail: 'snow', snow: 'snow', snowscape: 'snow' }[ev.weather]; if (wk) { lensHit(wk, 18); shake = Math.max(shake, 0.4); } }
        weatherNow = ev.weather || null;
        const w = WEATHER[ev.weather] ?? null;
        yard.setWeather(w ?? ambientWx);
        setReflect();
        if (ev.weather === 'sunnyday' || ev.weather === 'desolateland') { el.classList.add('sunny'); } else el.classList.remove('sunny');
        el.classList.toggle('sandy', ev.weather === 'sandstorm');
        break;
      }
      case 'message': {
        ev.text = decode(ev.text);
        say(ev.text);
        if (/won the battle|got away safely/i.test(ev.text) && !celebrated) {
          // the end of the match: the winner up close, confetti, the crowd's cameras going off
          celebrated = true;
          const won = !/wild/i.test(ev.text.split(' won')[0]) && !/got away/i.test(ev.text);
          if (won && actor(0)) {
            // quick cuts round it as it celebrates (and its trainer, if there is one), then settling on them
            if (dynamic) { cutTo(() => SHOT.hero(0), { hold: 1.0, drift: 0.3 }); queueShot(() => SHOT.around(0, 0.9, 0.85, 0.35), { hold: 0.75, drift: 0.25 }); queueShot(() => SHOT.around(0, -0.8, 0.7, 0.9), { hold: 0.75, drift: 0.25 });
              if (trainerPics[0]) { queueShot(() => SHOT.team(0), { hold: 1.1, drift: 0.15 }); queueShot(() => SHOT.around(0, 0.3, 1.05, 0.5), { hold: 0.7, drift: 0.2 }); }
              queueShot(() => (trainerPics[0] ? SHOT.team(0) : SHOT.front(0, 1.4)), { hold: 30, drift: 0.2 }); }
            setTimeout(() => { if (!destroyed && actor(0)) victoryDance(0); }, 2400); // and again for the next shots
            victoryDance(0);
            for (let i = 0; i < 60; i++) setTimeout(() => particle({ x: rnd(-6, 6), y: 6 + rnd(0, 3), z: 5 + rnd(-6, 6), vx: rnd(-0.5, 0.5), vy: -rnd(1, 2), life: 3, size: 0.12, col: ['#ff5a5a', '#ffd23f', '#4ab8ff', '#7affb0', '#ff8ad0'][i % 5], shape: 'shard', spin: rnd(-8, 8) }), i * 40);
            crowdFlash(30);
            cast(pick(['And that\u2019s the match! What a battle!', 'Victory! The crowd is on its feet!']), { force: true });
          }
        }
        if (/must recharge/i.test(ev.text)) { const sd = /wild|foe|opposing/i.test(ev.text) ? 1 : 0; const top = chest(sd, 1); for (let i = 0; i < 6; i++) setTimeout(() => particle({ ...top, x: top.x + rnd(-0.3, 0.3), vy: rnd(0.5, 1), vx: rnd(-0.6, 0.6), g: -3, life: 0.8, size: 0.16, col: '#9ad8ff', shape: 'drop' }), i * 120); cast(pick(['It needs a breather after that!', 'All that power took it out of it!']), { force: true }); }
        if (/critical hit/i.test(ev.text)) { critNow = true; slowmo = Math.max(slowmo, 0.45); hype(0.8); screenFlash('#ffffff', 160); shake = Math.max(shake, 1); crowdFlash(14); cast(pick(['A critical hit! The crowd goes wild!', 'Right on the weak spot!', 'What a blow!']), { force: true }); }
        if (/super effective/i.test(ev.text)) notify(null, 'Super effective!', 'big', '#ff8a3a'); else if (/not very effective/i.test(ev.text)) notify(null, 'Not very effective…', 'info', '#9aa4b8');
        if (/super effective/i.test(ev.text)) { shake = Math.max(shake, 0.8); crowdFlash(10); cast(pick(['That’s super effective! What a hit!', 'Oh, that one really hurt!', 'A direct hit! Super effective!']), { force: true }); }
        else if (/not very effective/i.test(ev.text)) cast(pick(['It’s barely scratched!', 'That didn’t do much at all…', 'It’s shrugging that off!']), { force: true });
        else if (/doesn.t affect|no effect|unaffected/i.test(ev.text)) cast(pick(['No effect at all!', 'It went straight through!']), { force: true });
        else if (/was burned|was poisoned|badly poisoned|paralyzed|fell asleep|was frozen|became confused/i.test(ev.text)) cast(pick(['That could change everything!', 'A nasty status for that one!', 'Trouble now!']), { force: true });
        else if (/protected itself/i.test(ev.text)) cast('A perfect block!', { force: true });
        else if (/^turn 1$/i.test(ev.text.trim())) cast('And the battle begins!', { force: true });
        break;
      }
      default: break;
    }
    if (ev.team && ev.t !== 'message') { for (const side of [0, 1]) { const b = hud[side]; if (!b.hidden && mons[side]) b.querySelector('.bst-balls')?.replaceChildren(...(ev.team[side] ?? []).map((t) => h('i', { class: `ball ${!t.seen ? 'unknown' : t.fainted ? 'out' : t.status ? 'st' : ''}` }))); } }
  }

  try { window.__bstEvent = (ev) => event(ev); } catch { /* no window */ }
  yard.start();

  return {
    el,
    init(api) { api.listenTooltips?.(el); setIntro(true); },
    // how much longer Showdown should linger on each kind of moment (only while this stage is on show)
    pace() { if (!el.offsetParent || !dynamic) return null; const T = tempo(); if (T < 0.5) return null; const P = {}; for (const [k, v] of Object.entries(PACE)) P[k] = v * T; P.runMoveAnim += moveExtra * T; if (damageWait) { P.damageAnim = Math.max(P.damageAnim, damageWait); damageWait = 0; } if (summons === 1) { P.animSummon = 300 * T; P.animDragIn = 300 * T; } else if (summons === 2) { const k = intro === 'trainer' ? 5200 : 5000; P.animSummon = k * T; P.animDragIn = k * T; } return P; },
    event,
    // move practice: set up (it in the middle, an invisible stand-in for whatever it aims at), then each move at a spot
    practiceStart(name = '') {
      const a = placeMon(0, { side: 0, name, pct: 1 }); placeMon(1, { side: 1, name: '', pct: 1 });
      const g = actor(1); if (g) g.ghost = true;
      started = true; introOver = true; intro = 'wild'; revealed = true; summons = 2;
      black.classList.remove('on'); bars.classList.remove('on'); setIntro(false); hud[0].hidden = true; hud[1].hidden = true;
      if (a) popOut(0, { streak: false });
      home(0);
    },
    practiceMove(move, at, onHit) {
      practiceAt = [at.x, at.z];
      const g = actor(1); if (g) { g.x = at.x; g.z = at.z; g.tx = at.x; g.tz = at.z; g.ghost = true; }
      practiceHit = onHit ?? null;
      lastTurn++; playMove({ move, from: { side: 0 }, to: { side: 1 }, outcome: { hits: 1 } });
      // (and back to circling afterwards)
      setTimeout(() => { if (!destroyed) home(1.2); }, 4200);
    },
    destroy() { destroyed = true; try { crowdSnd?.stop(); } catch { /* gone */ } clearInterval(typing); try { yard.destroy(); } catch { /* gone */ } },
    yard,
  };
}
