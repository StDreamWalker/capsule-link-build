// The 2.5D battle stage: wild battles shown like the console games (Battle Revolution-style cameras, moves
// playing out between the two creatures) instead of Showdown's flat screen. Showdown still runs the battle and
// its own screen keeps going underneath, unseen, so the pace and every rule stay exactly Showdown's; each
// animation it starts arrives here as an event (see hookScene in sdbattle/wild.js) and is acted out on a Yard
// in the 'battle' scene.
//
//   createBattleStage({ idx, bank, place, resolveTexture, creatureFor(mon), speciesFor(name) }) → { el, init, event, destroy }
import { h } from './dom.js';
import { Yard, BATTLE_SPOTS } from './yard.js';
import { actorFor } from './actor.js';
import { classifyMove, lookOf, vanishOf } from './stageMoves.js';
import { moveFx, fxImage } from './moveFx.js';

const TYPE_COL = { HyperBeam: '#ffb43a', Normal: '#ecebd8', Fire: '#ff7a2a', Water: '#3ea0ff', Electric: '#ffe03a', Grass: '#5cd65c', Ice: '#a8f2ff', Fighting: '#e8603a', Poison: '#b85ae0', Ground: '#d8b060', Flying: '#c0d0ff', Psychic: '#ff5aa8', Bug: '#a8c83a', Rock: '#c0a868', Ghost: '#8a6ad8', Dragon: '#7a6aff', Dark: '#4a3a50', Steel: '#d0d0e8', Fairy: '#ffa8e0', Stellar: '#ffffff' };
const STATUS_COL = { brn: '#f08030', par: '#f8d030', psn: '#a040a0', tox: '#7a2a8a', slp: '#8c8c9c', frz: '#98d8d8' };
const STATUS_LABEL = { brn: 'BRN', par: 'PAR', psn: 'PSN', tox: 'TOX', slp: 'SLP', frz: 'FRZ' };
const WEATHER = { raindance: 'rain', primordialsea: 'storm', sunnydays: 'clear', sunnyday: 'clear', desolateland: 'clear', sandstorm: 'windy', hail: 'snow', snow: 'snow', snowscape: 'snow', deltastream: 'windy' };
const decode = (s) => { const t = document.createElement('textarea'); t.innerHTML = String(s ?? ''); return t.value; };
const ease = (t) => (t < 0 ? 0 : t > 1 ? 1 : t * t * (3 - 2 * t));
const lerp = (a, b, t) => a + (b - a) * t;
const rnd = (a, b) => a + Math.random() * (b - a);

/** Places to battle in: natural ones (like the ranch's) and battle-only arenas. look = the yard environment. */
export const BATTLE_PLACES = [
  { id: 'meadow', label: 'Meadow', look: 'meadow', find: ['meadow'] },
  { id: 'forest', label: 'Forest', look: 'forest', find: ['forest'] },
  { id: 'shoreline', label: 'Beach', look: 'shoreline', find: ['shoreline'] },
  { id: 'marsh', label: 'Marsh', look: 'marsh', find: ['marsh'] },
  { id: 'desert', label: 'Desert', look: 'desert', find: ['desert'] },
  { id: 'tundra', label: 'Snowfield', look: 'tundra', find: ['tundra'] },
  { id: 'volcano', label: 'Volcano', look: 'volcano', find: ['volcano'] },
  { id: 'cavern', label: 'Cave', look: 'cavern', find: ['cavern'] },
  { id: 'crystal', label: 'Crystal cave', look: 'crystal', find: ['crystal', 'cavern'] },
  { id: 'skyline', label: 'Mountaintop', look: 'skyline', find: ['skyline'] },
  { id: 'seafloor', label: 'Seafloor', look: 'seafloor', find: ['seafloor'] },
  { id: 'outskirts', label: 'City park', look: 'outskirts', find: ['outskirts'] },
  { id: 'spooky', label: 'Haunted woods', look: 'spooky', find: ['spooky'] },
  { id: 'starfield', label: 'Starfield', look: 'starfield', find: ['starfield'] },
  { id: 'colosseum', label: 'Battle Colosseum ★', look: 'colosseum', find: null, arena: true },
  { id: 'stadium', label: 'Stadium (evening) ★', look: 'stadium', find: null, arena: true },
  { id: 'ruins', label: 'Ancient Ruins ★', look: 'ruins', find: ['desert', 'cavern', 'spooky', 'forest'], arena: true },
  { id: 'shrine', label: 'Mountain Shrine ★', look: 'shrine', find: ['forest', 'skyline', 'spooky'], arena: true },
];
export const battlePlace = (id) => BATTLE_PLACES.find((p) => p.id === id) ?? BATTLE_PLACES[0];

export function createBattleStage({ idx, bank, place = 'meadow', resolveTexture = null, creatureFor, speciesFor, classic = null, trainers = {} }) {
  const P = battlePlace(place);
  const canvas = h('canvas', { class: 'bst-canvas', 'aria-hidden': 'true' });
  // hovering a creature's HP plate shows Showdown's details for it
  const hud = [0, 1].map((side) => h('div', { class: `bst-hud has-tooltip ${side === 0 ? 'mine' : 'foe'}`, hidden: true, 'data-tooltip': `activepokemon|${side}|0`, 'data-ownheight': '1' }));
  const text = h('div', { class: 'bst-text' });
  const tips = [0, 1].map((side) => h('div', { class: 'bst-tip has-tooltip', 'data-tooltip': `activepokemon|${side}|0`, 'data-ownheight': '1' }));
  const flash = h('div', { class: 'bst-flash' });
  const bars = h('div', { class: 'bst-bars on' });
  const viewBtn = h('button', { class: 'bst-view', type: 'button', title: 'Show Showdown’s classic flat battle screen instead' }, 'Classic view');
  const camBtn = h('button', { class: 'bst-cam', type: 'button', title: 'Camera: moves with the action, or stays put' }, '🎥 Dynamic');
  const black = h('div', { class: 'bst-black on' });
  // "Pikachu used Thunderbolt!" in the move's type colour, and the announcer's running commentary
  const banner = h('div', { class: 'bst-moveban' }, h('span', { class: 'who' }), h('span', { class: 'mv' }));
  const caster = h('div', { class: 'bst-caster' });
  const el = h('div', { class: 'bst' }, canvas, ...tips, hud[1], hud[0], banner, caster, text, flash, bars, black, h('div', { class: 'bst-btns' }, camBtn));
  void viewBtn;
  let dynamic = true;
  try { dynamic = localStorage.getItem('clBstCam') !== 'fixed'; } catch { /* default */ }
  camBtn.textContent = dynamic ? '🎥 Dynamic' : '🎥 Fixed';
  camBtn.onclick = () => { dynamic = !dynamic; camBtn.textContent = dynamic ? '🎥 Dynamic' : '🎥 Fixed'; try { localStorage.setItem('clBstCam', dynamic ? 'dynamic' : 'fixed'); } catch { /* fine */ } };
  viewBtn.onclick = () => classic?.();

  const fx = []; // effects (world-space), each { t, life, update(dt), draw(ctx) }
  const parts = []; // particles { x, y, z, vx, vy, vz, g, life, max, size, col, shape, spin }
  const mons = [null, null]; // { info, uid, spec, base sizeMul }
  const specs = {};
  const uidOf = (side) => (side === 0 ? 'bt-near' : 'bt-far');
  const spot = (side) => (side === 0 ? BATTLE_SPOTS.near : BATTLE_SPOTS.far);
  let shake = 0, time = 0, last = performance.now(), started = false, destroyed = false;

  const yard = new Yard(canvas, {
    bank, scene: 'battle', biome: P.look, seed: 11, yardSize: 0, resolveTexture, res: 576,
    overlay: (ctx) => frame(ctx),
  });
  yard.inputLocked = true;
  yard.openFloor = true;
  yard.setTime(P.look === 'stadium' ? 'dusk' : 'day');
  yard.setWeather('clear');
  yard.setCreatures([]);

  // ---------- the camera: a director cutting between shots, like Battle Revolution ----------
  // Every shot is worked out from where the two creatures stand (and how big they are) when it starts:
  //   main      behind your creature, a little to the side, both in view (where it rests between moves)
  //   front(s)  a close-up of one of them from the front, a touch below eye level
  //   hero(s)   a low shot looking up at one of them
  //   shoulder(s) over one's shoulder towards the other
  //   behindFoe from behind the wild one, looking at yours
  //   side      side-on to the whole field (things flying across it)
  //   overhead  from high above
  //   wide      zoomed right out, the whole place in view
  const V = (x, y, z) => ({ x, y, z });
  const pos = (side) => { const a = actor(side); const [x, z] = spot(side); return a ? { x: a.x, z: a.z } : { x, z }; };
  const tall = (side) => { const a = actor(side); return a ? Math.max(0.4, yard.heightOf(a)) : 1; };
  const axis = () => { const n = pos(0), f = pos(1); const dx = f.x - n.x, dz = f.z - n.z, l = Math.hypot(dx, dz) || 1; return { n, f, u: { x: dx / l, z: dz / l }, p: { x: dz / l, z: -dx / l }, len: l }; };
  const SHOT = {
    main() { const { n, f, u, p } = axis(); return { eye: V(n.x - u.x * 5.4 + p.x * 2.6, 2.9 + tall(0) * 0.4, n.z - u.z * 5.4 + p.z * 2.6), at: V(lerp(n.x, f.x, 0.55), 0.5, lerp(n.z, f.z, 0.55)) }; },
    front(side, wide = 1) {
      const { n, f, u, p } = axis(), me = side === 0 ? n : f, dir = side === 0 ? 1 : -1, hgt = tall(side), d = (1.5 + hgt * 1.5) * wide, off = side === 0 ? 0.55 : -0.45;
      return { eye: V(me.x + u.x * dir * d + p.x * off * d, hgt * 0.55 + 0.2, me.z + u.z * dir * d + p.z * off * d), at: V(me.x, hgt * 0.55, me.z) };
    },
    hero(side) { const { n, f, u, p } = axis(), me = side === 0 ? n : f, dir = side === 0 ? 1 : -1, hgt = tall(side), d = 1.1 + hgt * 1.25;
      return { eye: V(me.x + u.x * dir * d - p.x * dir * 0.6 * d, 0.22, me.z + u.z * dir * d - p.z * dir * 0.6 * d), at: V(me.x, hgt * 0.75, me.z) }; },
    shoulder(side) { const { n, f, u, p } = axis(), me = side === 0 ? n : f, other = side === 0 ? f : n, dir = side === 0 ? 1 : -1, hgt = tall(side), d = 1.4 + hgt * 0.8;
      return { eye: V(me.x - u.x * dir * d + p.x * dir * 1.0, hgt * 1.05 + 0.35, me.z - u.z * dir * d + p.z * dir * 1.0), at: V(lerp(me.x, other.x, 0.7), 0.6, lerp(me.z, other.z, 0.7)) }; },
    behindFoe() { const { n, f, u, p } = axis(); return { eye: V(f.x + u.x * 4.6 - p.x * 1.8, 2.2 + tall(1) * 0.4, f.z + u.z * 4.6 - p.z * 1.8), at: V(lerp(f.x, n.x, 0.62), 0.7, lerp(f.z, n.z, 0.62)) }; },
    side(k = 1) { const { n, f, p } = axis(), mx = (n.x + f.x) / 2, mz = (n.z + f.z) / 2; return { eye: V(mx + p.x * 7.5 * k, 1.5, mz + p.z * 7.5 * k), at: V(mx, 0.8, mz) }; },
    overhead() { const { n, f, u, p } = axis(), mx = (n.x + f.x) / 2, mz = (n.z + f.z) / 2; const cx2 = lerp(n.x, f.x, 0.4), cz2 = lerp(n.z, f.z, 0.4); return { eye: V(cx2 - u.x * 2.4 + p.x * 1.2, 11.5, cz2 - u.z * 2.4 + p.z * 1.2), at: V(cx2, 0, cz2) }; },
    wide() { const { n, f, u, p } = axis(), mx = (n.x + f.x) / 2, mz = (n.z + f.z) / 2; return { eye: V(mx - u.x * 19 + p.x * 9, 13.5, mz - u.z * 19 + p.z * 9), at: V(mx, 0.6, mz) }; },
    wideBack() { const { n, f, u, p } = axis(), mx = (n.x + f.x) / 2, mz = (n.z + f.z) / 2; return { eye: V(mx + u.x * 18 - p.x * 10, 13, mz + u.z * 18 - p.z * 10), at: V(mx, 0.6, mz) }; },
  };
  // where each side's trainer stands: behind their creature and off to one side (the wild one has none)
  const trainerAt = (side) => { const { n, f, u, p } = axis(), me = side === 0 ? n : f, dir = side === 0 ? 1 : -1; return { x: me.x - u.x * dir * 2.4 - p.x * dir * 1.8, z: me.z - u.z * dir * 2.4 - p.z * dir * 1.8 }; };
  // a trainer and their creature together, from the front
  SHOT.team = (side) => { const { u, p } = axis(), me = pos(side), t = trainerAt(side), dir = side === 0 ? 1 : -1, mx = (me.x + t.x) / 2, mz = (me.z + t.z) / 2, d = 5.2 + tall(side) * 0.8;
    return { eye: V(mx + u.x * dir * d - p.x * dir * 0.8, 1.35 + tall(side) * 0.2, mz + u.z * dir * d - p.z * dir * 0.8), at: V(mx, 0.85, mz) }; };
  try { window.__bstShots = SHOT; } catch { /* no window */ }
  const cam = { eye: V(-6, 8, -9), at: V(0, 0.6, 5) };
  let cur = null, idleFor = 0, idleN = 0;
  const shots = [];
  // a shot: make() → { eye, at }; dur = time to glide there (0 = a cut); hold = time on it; drift = a slow slide
  // sideways (units/s); track() → a point to keep looking at (a move flying across)
  const queueShot = (make, { dur = 0, hold = 1, drift = 0.25, track = null, home: isHome = false } = {}) => { shots.push({ make, dur, hold, drift, track, isHome }); };
  const cutTo = (make, opts) => { shots.length = 0; cur = null; queueShot(make, opts); idleFor = 0; };
  const home = (dur = 1.2) => queueShot(SHOT.main, { dur, hold: 0, drift: 0, home: true });
  try { window.__bstCut = (name, ...args) => { cutTo(() => SHOT[name](...args), { hold: 1e6, drift: 0 }); }; } catch { /* no window */ }
  const copy = (v) => ({ x: v.x, y: v.y, z: v.z });
  const mix = (a, b, k) => V(lerp(a.x, b.x, k), lerp(a.y, b.y, k), lerp(a.z, b.z, k));
  function stepCamera(dt) {
    if (!dynamic) { shots.length = 0; cur = null; const m = SHOT.main(); cam.eye = m.eye; cam.at = m.at; }
    if (!cur && shots.length) {
      const n = shots.shift();
      let to; try { to = n.make(); } catch { to = SHOT.main(); }
      const dx = to.at.x - to.eye.x, dz = to.at.z - to.eye.z, l = Math.hypot(dx, dz) || 1;
      cur = { ...n, to, from: { eye: copy(cam.eye), at: copy(cam.at) }, t: 0, side: { x: dz / l, z: -dx / l }, sgn: Math.random() < 0.5 ? -1 : 1 };
      // a glide only between nearby shots: anything else is a cut (gliding from in front of a creature to
      // behind it would pass right through it)
      if (n.dur && Math.hypot(to.eye.x - cam.eye.x, to.eye.y - cam.eye.y, to.eye.z - cam.eye.z) > 5.5) cur.dur = 0;
      if (!cur.dur) { cam.eye = copy(to.eye); cam.at = copy(to.at); }
    }
    if (cur) {
      cur.t += dt;
      const k = cur.dur ? ease(cur.t / cur.dur) : 1, sl = cur.drift * cur.t * cur.sgn;
      const eye = mix(cur.from.eye, cur.to.eye, k), at = mix(cur.from.at, cur.to.at, k);
      eye.x += cur.side.x * sl; eye.z += cur.side.z * sl;
      if (cur.track) { const tp = cur.track(); if (tp) { cur.look = cur.look ? mix(cur.look, tp, Math.min(1, dt * 9)) : tp; at.x = lerp(at.x, cur.look.x, 0.85); at.y = lerp(at.y, cur.look.y, 0.85); at.z = lerp(at.z, cur.look.z, 0.85); } }
      cam.eye = eye; cam.at = at;
      if (cur.t >= cur.dur + cur.hold && (!cur.isHome || shots.length)) cur = null;
      else if (cur.isHome && cur.t >= cur.dur) { // resting on the main shot: re-aim as they move, breathe a little
        const m = SHOT.main(); cam.eye = m.eye; cam.at = m.at;
      }
    }
    // between moves (choosing what to do), the director wanders through other shots now and then
    const resting = !cur || (cur.isHome && cur.t >= cur.dur);
    if (dynamic && started && resting) {
      idleFor += dt;
      if (idleFor > 6.5) {
        idleFor = 0;
        const pick = [() => cutTo(() => SHOT.front(1), { hold: 3.2, drift: 0.22 }), () => cutTo(() => SHOT.front(0), { hold: 3.2, drift: 0.22 }), () => cutTo(SHOT.behindFoe, { hold: 3.4, drift: 0.35 }),
          () => cutTo(SHOT.wide, { hold: 4, drift: 0.9 }), () => cutTo(SHOT.overhead, { hold: 3, drift: 0.5 }), () => cutTo(() => SHOT.hero(1), { hold: 2.8, drift: 0.2 }), () => cutTo(() => SHOT.side(idleN % 2 ? 1 : -1), { hold: 3.2, drift: 0.5 })][idleN++ % 7];
        pick(); home(0);
      }
    } else idleFor = 0;
    const br = resting ? 1 : 0.25; // a gentle handheld breathing
    const e = { x: cam.eye.x + Math.sin(time * 0.37) * 0.08 * br + (Math.random() - 0.5) * shake * 0.22, y: cam.eye.y + Math.sin(time * 0.29) * 0.05 * br + (Math.random() - 0.5) * shake * 0.12, z: cam.eye.z };
    // aimed a touch low, so what the shot is about sits above the text box
    const aimDrop = Math.hypot(cam.at.x - cam.eye.x, cam.at.y - cam.eye.y, cam.at.z - cam.eye.z) * 0.085;
    const a = { x: cam.at.x + (Math.random() - 0.5) * shake * 0.12, y: cam.at.y - aimDrop, z: cam.at.z };
    yard.lookFrom(e, a);
    placeTrainers(e);
    shake = Math.max(0, shake - dt * 2.2);
    // which way round each creature is seen: its back when the camera is behind it, its front otherwise, and
    // turned to face the other on screen
    for (const side of [0, 1]) {
      const me = actor(side), other = actor(1 - side); if (!me) continue;
      const o = other ? { x: other.x, z: other.z } : (() => { const [x, z] = spot(1 - side); return { x, z }; })();
      const fx2 = o.x - me.x, fz2 = o.z - me.z;
      me.battleBack = (e.x - me.x) * fx2 + (e.z - me.z) * fz2 < 0;
      const q0 = yard.project(me.x, 0.5, me.z), q1 = yard.project(o.x, 0.5, o.z);
      if (me.battleFaceLock) me.battleFace = me.battleFaceLock;
      else if (q0 && q1 && Math.abs(q1.x - q0.x) > 2) me.battleFace = q1.x > q0.x ? 'right' : 'left';
      else if (q0 && !q1) { const q2 = yard.project(me.x + fx2 * 0.05, 0.5, me.z + fz2 * 0.05); if (q2) me.battleFace = q2.x > q0.x ? 'right' : 'left'; }
    }
  }
  // ---------- the trainers: their pictures standing behind their creatures ----------
  const trainerPics = {};
  for (const [side, url] of [[0, trainers.mine], [1, trainers.foe]]) {
    if (!url) continue;
    const img = new Image(); img.decoding = 'async';
    img.onload = () => { trainerPics[side] = img; };
    img.src = url;
  }
  yard.extras = [0, 1].map((side) => ({
    x: 0, z: 0, side,
    draw(ctx, q) {
      const img = trainerPics[side]; if (!img || this.hide || !q) return;
      // only from in front of them (from behind they'd be a flat cut-out, and they'd block the view)
      const H = 2.0 * q.k, W = (img.width / img.height) * H;
      if (H > yard.H * 1.6) return;
      ctx.save(); ctx.imageSmoothingEnabled = false; ctx.globalAlpha = this.alpha ?? 1;
      ctx.fillStyle = 'rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(q.x, q.y, W * 0.28, W * 0.08, 0, 0, Math.PI * 2); ctx.fill();
      if (this.flip) { ctx.translate(q.x, 0); ctx.scale(-1, 1); ctx.drawImage(img, Math.round(-W / 2), Math.round(q.y - H * 0.96), Math.round(W), Math.round(H)); }
      else ctx.drawImage(img, Math.round(q.x - W / 2), Math.round(q.y - H * 0.96), Math.round(W), Math.round(H));
      ctx.restore();
    },
  }));
  function placeTrainers(e) {
    const { u } = axis();
    for (const t of yard.extras) {
      if (!trainerPics[t.side]) { t.hide = true; continue; }
      const p = trainerAt(t.side), dir = t.side === 0 ? 1 : -1;
      t.x = p.x; t.z = p.z;
      t.hide = (e.x - p.x) * u.x * dir + (e.z - p.z) * u.z * dir < 0.4 || Math.hypot(e.x - p.x, e.z - p.z) < 1.4;
      // turned to face the middle of the field on screen
      const q0 = yard.project(p.x, 1, p.z), q1 = yard.project(p.x + u.x * dir, 1, p.z + u.z * dir);
      if (q0 && q1) t.flip = q1.x > q0.x;
    }
  }

  // Showdown speed → how long our shots take (and the stage asks Showdown to wait for them)
  const tempo = () => { let sp = 'normal'; try { sp = localStorage.getItem('clSdSpeed') || 'normal'; } catch { /* default */ } return { slow: 2.1, normal: 1.6, fast: 0.9, hyperfast: 0.55 }[sp] ?? 1.6; };
  const PACE = { runMoveAnim: 1500, runPrepareAnim: 1000, damageAnim: 650, animFaint: 1500, animSummon: 1000, animDragIn: 1000, animUnsummon: 600, healAnim: 450, runStatusAnim: 500, runOtherAnim: 300, resultAnim: 120 };

  // ---------- creatures ----------
  const actor = (side) => yard.actors.get(uidOf(side));
  const chest = (side, k = 0.5) => { const a = actor(side); if (!a) { const [x, z] = spot(side); return { x, y: 0.6, z }; } return { x: a.x, y: (a.y || 0) + yard.heightOf(a) * k, z: a.z }; };
  function placeMon(side, info) {
    const c = creatureFor(info);
    if (!c) return null;
    const spec = { ...actorFor(idx, c), uid: uidOf(side), name: '', clothes: side === 0 ? actorFor(idx, c).clothes : [] };
    const sid = speciesFor?.(info.species);
    if (sid && !String(spec.speciesId).startsWith(sid)) spec.speciesId = `${sid}${info.shiny ? ':shiny' : ''}`;
    specs[side] = spec;
    yard.setCreatures(Object.values(specs));
    const a = actor(side);
    if (!a) return null;
    yard.puppet(a.uid);
    const [x, z] = spot(side);
    Object.assign(a, { x, z, tx: x, tz: z, appear: 1, battleBack: side === 0, battleFace: side === 0 ? 'right' : 'left', alpha: 1, hitFlash: 0, jitter: 0 });
    // battle size: everyone shown big enough to read, but big creatures still bigger than small ones
    a.sizeMul = specs[side].sizeMul ?? 1;
    const h0 = Math.max(0.05, yard.heightOf(a));
    a.baseSize = a.sizeMul * Math.max(1.15, Math.min(3.6, Math.pow((side === 0 ? 1.95 : 1.5) / h0, 0.72)));
    a.sizeMul = a.baseSize;
    specs[side].sizeMul = a.baseSize; // so later changes to the other side don't undo it
    mons[side] = { info, c };
    return a;
  }
  function remove(side) { delete specs[side]; mons[side] = null; yard.setCreatures(Object.values(specs)); }

  // ---------- particles and effects ----------
  let flying = null; // whatever a move has sent across the field right now (the camera follows it)
  const project = (p) => yard.project(p.x, p.y, p.z);
  function particle(p) { parts.push({ vx: 0, vy: 0, vz: 0, g: 0, size: 0.12, shape: 'dot', spin: 0, rot: Math.random() * 6, ...p, max: p.life }); }
  function burst(at, col, n = 14, { speed = 2.4, size = 0.13, shape = 'shard', up = 0.6, g = -3 } = {}) {
    for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, s = rnd(0.4, 1) * speed; particle({ x: at.x, y: at.y, z: at.z, vx: Math.cos(a) * s, vy: rnd(-0.3, 1) * s * up + 0.6, vz: Math.sin(a) * s * 0.6, g, life: rnd(0.35, 0.7), size, col: i % 4 ? col : '#ffffff', shape, spin: rnd(-8, 8) }); }
  }
  function ring(at, col, { r0 = 0.2, r1 = 1.6, life = 0.6, flat = false, w = 4 } = {}) {
    fx.push({ t: 0, life, draw(ctx) {
      const k = this.t / this.life, q = project(at); if (!q) return;
      const r = lerp(r0, r1, ease(k)) * q.k;
      ctx.strokeStyle = col; ctx.globalAlpha = 1 - k; ctx.lineWidth = Math.max(1, w * (1 - k * 0.5));
      ctx.beginPath(); ctx.ellipse(q.x, q.y, r, flat ? r * 0.3 : r, 0, 0, Math.PI * 2); ctx.stroke(); ctx.globalAlpha = 1;
    } });
  }
  function hitFlash(side, n = 3) { const a = actor(side); if (!a) return; fx.push({ t: 0, life: 0.5, update() { const a2 = actor(side); if (!a2) return; a2.hitFlash = Math.floor(this.t * n * 2 / this.life) % 2 === 0 ? 1 : 0; a2.jitter = Math.sin(this.t * 60) * 4 * (1 - this.t / this.life); }, end() { const a2 = actor(side); if (a2) { a2.hitFlash = 0; a2.jitter = 0; } } }); }
  function screenFlash(col = '#ffffff', dur = 220) { flash.style.background = col; flash.classList.remove('go'); void flash.offsetWidth; flash.classList.add('go'); flash.style.animationDuration = `${dur}ms`; }
  function lunge(side, target, { dur = 0.42, depth = 0.62 } = {}) {
    const a = actor(side); if (!a) return;
    const [x0, z0] = spot(side), tp = chest(target);
    fx.push({ t: 0, life: dur, update() { const a2 = actor(side); if (!a2) return; const k = this.t / this.life, m = k < 0.45 ? ease(k / 0.45) : 1 - ease((k - 0.45) / 0.55); a2.x = lerp(x0, tp.x, m * depth); a2.z = lerp(z0, tp.z, m * depth); a2.hop = k < 0.45 ? 0.6 : 0; }, end() { const a2 = actor(side); if (a2) { a2.x = x0; a2.z = z0; } } });
  }
  // a thing flying from one creature to the other: a glowing orb with a trail (or flames, drops, leaves…)
  function projectile(from, to, type, { dur = 0.42, shape = null, size = 0.26, onHit, miss = false, img = null } = {}) {
    const col = TYPE_COL[type] ?? '#ffffff';
    const sh = shape ?? lookOf(type).shapes[0];
    fx.push({ t: 0, life: dur, update(dt) {
      const k = ease(this.t / this.life), a = chest(from), b0 = chest(to);
      // a miss sails past, off to one side and on beyond
      const b = miss ? (() => { const { u, p, dir } = sideOf(from); return { x: b0.x + p.x * 1.6 + u.x * dir * 2.5, y: b0.y + 0.5, z: b0.z + p.z * 1.6 + u.z * dir * 2.5 }; })() : b0;
      const p = { x: lerp(a.x, b.x, k), y: lerp(a.y, b.y, k) + Math.sin(k * Math.PI) * 0.5, z: lerp(a.z, b.z, k) };
      this.p = p; flying = p;
      for (let i = 0; i < 3; i++) particle({ x: p.x + rnd(-0.08, 0.08), y: p.y + rnd(-0.08, 0.08), z: p.z, vx: rnd(-0.3, 0.3), vy: rnd(-0.2, 0.4), life: rnd(0.2, 0.4), size: size * rnd(0.4, 0.8), col: Math.random() < 0.3 ? '#ffffff' : col, shape: sh, spin: rnd(-6, 6) });
      void dt;
    }, draw(ctx) { if (!this.p) return; const q = project(this.p); if (!q) return; glow(ctx, q.x, q.y, size * q.k, col);
      // Showdown's own effect picture for the move, when it's been downloaded
      const im = img && fxImage(resolveTexture, img); if (im) { const w = size * 3.2 * q.k; ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(this.t * 6); ctx.drawImage(im, -w / 2, -w / 2, w, w); ctx.restore(); } }, end() { flying = null; onHit?.(); } });
  }
  function beam(from, to, type, { dur = 0.6, onHit, width = 1 } = {}) {
    const col = TYPE_COL[type] ?? '#ffffff';
    let hit = false;
    fx.push({ t: 0, life: dur, update() { if (!hit && this.t > 0.18) { hit = true; onHit?.(); } const b = chest(to); for (let i = 0; i < 2; i++) particle({ x: b.x, y: b.y, z: b.z, vx: rnd(-1.5, 1.5), vy: rnd(-0.5, 1.5), vz: rnd(-1, 1), life: 0.3, size: 0.1, col, shape: 'spark' }); }, draw(ctx) {
      const a = project(chest(from)), b = project(chest(to)); if (!a || !b) return;
      const k = Math.min(1, this.t / 0.15), fade = Math.min(1, (this.life - this.t) / 0.15);
      const ex = lerp(a.x, b.x, k), ey = lerp(a.y, b.y, k);
      const w = Math.max(3, (a.k + b.k) * 0.09) * width * fade * (1 + Math.sin(this.t * 40) * 0.15);
      ctx.save(); ctx.lineCap = 'round';
      ctx.globalAlpha = 0.5 * fade; ctx.strokeStyle = col; ctx.lineWidth = w * 2.4; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.globalAlpha = fade; ctx.lineWidth = w; ctx.stroke(); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = w * 0.4; ctx.stroke(); ctx.restore();
    } });
  }
  function bolts(target, { fromSky = true, from = null, onHit } = {}) {
    let hit = false;
    fx.push({ t: 0, life: 0.55, update() { if (!hit && this.t > 0.1) { hit = true; onHit?.(); } }, draw(ctx) {
      const b = project(chest(target, 0.4)); if (!b) return;
      const a = fromSky ? { x: b.x + rnd(-20, 20), y: -10 } : project(chest(from));
      if (!a) return;
      ctx.save(); ctx.strokeStyle = Math.random() < 0.5 ? '#fff8a0' : '#ffe03a'; ctx.lineWidth = Math.max(2, b.k * 0.05); ctx.shadowColor = '#ffe03a'; ctx.shadowBlur = 12;
      for (let n = 0; n < 2; n++) { ctx.beginPath(); ctx.moveTo(a.x, a.y); for (let i = 1; i <= 7; i++) { const k = i / 7; ctx.lineTo(lerp(a.x, b.x, k) + (i < 7 ? rnd(-1, 1) * b.k * 0.25 : 0), lerp(a.y, b.y, k)); } ctx.stroke(); }
      ctx.restore();
    } });
  }
  function slashes(target, col = '#ffffff') {
    fx.push({ t: 0, life: 0.35, draw(ctx) {
      const q = project(chest(target)); if (!q) return; const k = this.t / this.life, r = q.k * 0.6;
      ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = Math.max(2, q.k * 0.05); ctx.globalAlpha = 1 - k * 0.6;
      for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(q.x - r + i * r * 0.35, q.y - r); ctx.lineTo(q.x - r + i * r * 0.35 + 2 * r * Math.min(1, k * 2), q.y - r + 2 * r * Math.min(1, k * 2)); ctx.stroke(); }
      ctx.restore();
    } });
  }
  function bite(target) {
    fx.push({ t: 0, life: 0.35, draw(ctx) {
      const q = project(chest(target)); if (!q) return; const k = ease(this.t / this.life), r = q.k * 0.5, gap = r * (1 - k);
      ctx.save(); ctx.fillStyle = '#ffffff'; ctx.strokeStyle = '#30283a'; ctx.lineWidth = 2;
      for (const s of [-1, 1]) { ctx.beginPath(); for (let i = 0; i < 5; i++) { const x = q.x - r + (i * 2 * r) / 4; ctx.moveTo(x - r * 0.18, q.y + s * gap); ctx.lineTo(x, q.y + s * (gap - r * 0.35)); ctx.lineTo(x + r * 0.18, q.y + s * gap); } ctx.fill(); ctx.stroke(); }
      ctx.restore();
    } });
  }
  function quake(from) {
    const a = chest(from, 0);
    for (let i = 0; i < 3; i++) setTimeout(() => ring({ x: a.x, y: 0.02, z: a.z }, '#c8a060', { r0: 0.3, r1: 4.5, life: 0.7, flat: true, w: 5 }), i * 120);
    shake = 1.4;
    for (let i = 0; i < 18; i++) particle({ x: a.x + rnd(-3, 3), y: 0.05, z: a.z + rnd(-1, 4), vy: rnd(1, 3), g: -8, life: 0.7, size: 0.12, col: '#a88a5a', shape: 'shard' });
  }
  function rocksFall(target, col) {
    const b = chest(target, 0);
    for (let i = 0; i < 6; i++) particle({ x: b.x + rnd(-0.6, 0.6), y: 4 + i * 0.5, z: b.z + rnd(-0.4, 0.4), vy: -2, g: -12, life: 0.65, size: 0.28, col, shape: 'rock', spin: rnd(-4, 4) });
  }
  function aura(side, col, { up = true, n = 22 } = {}) {
    const a = chest(side, 0);
    const hgt = (() => { const ac = actor(side); return ac ? yard.heightOf(ac) : 1; })();
    for (let i = 0; i < n; i++) { const ang = Math.random() * Math.PI * 2, r = rnd(0.3, 0.7) * Math.max(0.6, hgt * 0.6); particle({ x: a.x + Math.cos(ang) * r, y: up ? rnd(0, 0.3) : hgt * 1.1, z: a.z + Math.sin(ang) * r * 0.5, vy: up ? rnd(1.2, 2.4) : -rnd(1.2, 2), life: rnd(0.5, 0.9), size: 0.1, col: i % 3 ? col : '#ffffff', shape: up ? 'arrowUp' : 'arrowDown' }); }
  }
  function sparkleOn(side, col, shape = 'star', n = 12) {
    const b = chest(side);
    for (let i = 0; i < n; i++) particle({ x: b.x + rnd(-0.6, 0.6), y: b.y + rnd(-0.5, 0.6), z: b.z + rnd(-0.3, 0.3), vy: rnd(-0.2, 0.6), life: rnd(0.4, 0.8), size: 0.12, col, shape, spin: rnd(-5, 5) });
  }
  const floats = [0, 0];
  function floatText(side, s, col = '#ffffff') {
    const b = chest(side, 1.05);
    const lane = floats[side]++;
    b.y += lane * 0.32;
    fx.push({ t: 0, life: 1.1, end() { floats[side] = Math.max(0, floats[side] - 1); }, draw(ctx) {
      const q0 = project({ x: b.x, y: b.y + this.t * 0.6, z: b.z }); if (!q0) return;
      // kept on screen (and clear of the info boxes) even over a big creature close to the camera
      const q = { ...q0, x: Math.max(yard.W * 0.12, Math.min(yard.W * 0.88, q0.x)), y: Math.max(yard.H * 0.3 + lane * 26 - this.t * 20, q0.y) };
      ctx.save(); ctx.globalAlpha = Math.min(1, (this.life - this.t) * 3);
      ctx.font = `800 ${Math.max(12, Math.round(q.k * 0.22))}px "Segoe UI", system-ui, sans-serif`; ctx.textAlign = 'center';
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(20,16,40,.85)'; ctx.strokeText(s, q.x, q.y); ctx.fillStyle = col; ctx.fillText(s, q.x, q.y); ctx.restore();
    } });
  }
  function glow(ctx, x, y, r, col) {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r * 1.6);
    g.addColorStop(0, '#ffffff'); g.addColorStop(0.35, col); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 1.6, 0, Math.PI * 2); ctx.fill();
  }
  function drawParticle(ctx, p) {
    const q = project(p); if (!q) return;
    const k = p.life / p.max, s = Math.max(1.5, p.size * q.k);
    ctx.globalAlpha = Math.min(1, k * 2);
    ctx.fillStyle = p.col;
    switch (p.shape) {
      case 'flame': { const r = s * (0.6 + k * 0.8); const g = ctx.createRadialGradient(q.x, q.y, 0, q.x, q.y, r); g.addColorStop(0, '#fff6a0'); g.addColorStop(0.5, k > 0.5 ? '#ffb030' : '#ff5a20'); g.addColorStop(1, 'rgba(255,60,20,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(q.x, q.y, r, 0, Math.PI * 2); ctx.fill(); break; }
      case 'drop': ctx.beginPath(); ctx.ellipse(q.x, q.y, s * 0.5, s * 0.8, 0, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#ffffff'; ctx.fillRect(q.x - s * 0.2, q.y - s * 0.4, Math.max(1, s * 0.2), Math.max(1, s * 0.3)); break;
      case 'leaf': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.beginPath(); ctx.ellipse(0, 0, s, s * 0.45, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore(); break;
      case 'shard': case 'rock': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.beginPath(); ctx.moveTo(0, -s); ctx.lineTo(s * 0.6, 0); ctx.lineTo(0, s * 0.8); ctx.lineTo(-s * 0.5, 0); ctx.closePath(); ctx.fill(); if (p.shape === 'rock') { ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(0, 0, s * 0.4, s * 0.4); } ctx.restore(); break;
      case 'spark': ctx.fillRect(q.x - s * 0.5, q.y - 1, s, 2); ctx.fillRect(q.x - 1, q.y - s * 0.5, 2, s); break;
      case 'star': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.beginPath(); for (let i = 0; i < 10; i++) { const r = i % 2 ? s * 0.4 : s; ctx.lineTo(Math.cos((i * Math.PI) / 5) * r, Math.sin((i * Math.PI) / 5) * r); } ctx.closePath(); ctx.fill(); ctx.restore(); break;
      case 'bubble': ctx.strokeStyle = p.col; ctx.lineWidth = Math.max(1, s * 0.2); ctx.beginPath(); ctx.arc(q.x, q.y, s * 0.6, 0, Math.PI * 2); ctx.stroke(); break;
      case 'wisp': { const g = ctx.createRadialGradient(q.x, q.y, 0, q.x, q.y, s); g.addColorStop(0, p.col); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(q.x, q.y, s, 0, Math.PI * 2); ctx.fill(); break; }
      case 'arrowUp': case 'arrowDown': { const d = p.shape === 'arrowUp' ? -1 : 1; ctx.beginPath(); ctx.moveTo(q.x, q.y + d * s); ctx.lineTo(q.x + s * 0.6, q.y); ctx.lineTo(q.x + s * 0.25, q.y); ctx.lineTo(q.x + s * 0.25, q.y - d * s); ctx.lineTo(q.x - s * 0.25, q.y - d * s); ctx.lineTo(q.x - s * 0.25, q.y); ctx.lineTo(q.x - s * 0.6, q.y); ctx.closePath(); ctx.fill(); break; }
      case 'zzz': ctx.font = `700 ${Math.round(s * 1.6)}px system-ui`; ctx.fillText('z', q.x, q.y); break;
      case 'note': ctx.font = `700 ${Math.round(s * 1.7)}px system-ui`; ctx.fillText(p.rot > 3 ? '♪' : '♫', q.x, q.y); break;
      case 'heart': ctx.save(); ctx.translate(q.x, q.y); ctx.beginPath(); ctx.moveTo(0, s * 0.35); ctx.bezierCurveTo(-s, -s * 0.3, -s * 0.4, -s, 0, -s * 0.35); ctx.bezierCurveTo(s * 0.4, -s, s, -s * 0.3, 0, s * 0.35); ctx.fill(); ctx.restore(); break;
      case 'ember': ctx.fillStyle = k > 0.5 ? '#ffe070' : p.col; ctx.fillRect(q.x - s * 0.25, q.y - s * 0.25, s * 0.5, s * 0.5); break;
      case 'seed': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.fillStyle = '#c8a050'; ctx.beginPath(); ctx.ellipse(0, 0, s * 0.35, s * 0.55, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore(); break;
      case 'flake': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.strokeStyle = p.col; ctx.lineWidth = Math.max(1, s * 0.15); for (let i = 0; i < 3; i++) { ctx.rotate(Math.PI / 3); ctx.beginPath(); ctx.moveTo(-s * 0.6, 0); ctx.lineTo(s * 0.6, 0); ctx.stroke(); } ctx.restore(); break;
      case 'blob': ctx.beginPath(); ctx.arc(q.x, q.y, s * 0.6, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.beginPath(); ctx.arc(q.x - s * 0.2, q.y - s * 0.2, s * 0.18, 0, Math.PI * 2); ctx.fill(); break;
      case 'feather': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.beginPath(); ctx.ellipse(0, 0, s * 0.25, s * 0.7, 0, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,.2)'; ctx.beginPath(); ctx.moveTo(0, -s * 0.7); ctx.lineTo(0, s * 0.7); ctx.stroke(); ctx.restore(); break;
      case 'needle': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); ctx.fillRect(-s * 0.08, -s * 0.8, s * 0.16, s * 1.6); ctx.fillStyle = '#ffffff'; ctx.fillRect(-s * 0.08, -s * 0.8, s * 0.16, s * 0.3); ctx.restore(); break;
      case 'gear': ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(p.rot); for (let i = 0; i < 8; i++) { ctx.rotate(Math.PI / 4); ctx.fillRect(-s * 0.12, -s * 0.7, s * 0.24, s * 0.3); } ctx.beginPath(); ctx.arc(0, 0, s * 0.45, 0, Math.PI * 2); ctx.fill(); ctx.restore(); break;
      case 'ring': ctx.strokeStyle = p.col; ctx.lineWidth = Math.max(1.5, s * 0.18); ctx.beginPath(); ctx.ellipse(q.x, q.y, s * 0.7, s, 0, 0, Math.PI * 2); ctx.stroke(); break;
      case 'orb': { const g = ctx.createRadialGradient(q.x, q.y, 0, q.x, q.y, s * 0.7); g.addColorStop(0, '#ffffff'); g.addColorStop(0.5, p.col); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(q.x, q.y, s * 0.7, 0, Math.PI * 2); ctx.fill(); break; }
      case 'fist': ctx.save(); ctx.translate(q.x, q.y); ctx.fillStyle = '#ffffff'; ctx.strokeStyle = '#3a3040'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.roundRect?.(-s * 0.5, -s * 0.4, s, s * 0.8, s * 0.25); ctx.fill(); ctx.stroke(); ctx.restore(); break;
      default: ctx.beginPath(); ctx.arc(q.x, q.y, s * 0.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  // ---------- more effects ----------
  const sideOf = (side) => { const { u, p } = axis(); return { u, p, dir: side === 0 ? 1 : -1 }; };
  const home0 = (side) => { const [x, z] = spot(side); return { x, z }; };
  // moving a creature along a path (k: 0→1) and back to its spot at the end
  function move(side, life, at, { end } = {}) {
    fx.push({ t: 0, life, update() { const a = actor(side); if (!a) return; const q = at(this.t / this.life, a); if (!q) return; a.x = q.x; a.z = q.z; if (q.y != null) a.y = q.y; if (q.alpha != null) a.alpha = q.alpha; }, end() { const a = actor(side); if (a) { const h0 = home0(side); a.x = h0.x; a.z = h0.z; a.y = 0; if (!vanished[side]) a.alpha = 1; } end?.(); } });
  }
  // after-images behind something moving fast
  function trail(side, col = '#ffffff') { const a = actor(side); if (!a) return; particle({ x: a.x, y: (a.y || 0) + tall(side) * 0.5, z: a.z, life: 0.25, size: tall(side) * 0.55, col, shape: 'wisp' }); }
  // a dash at the target: straight (or zig-zagging across the field), hit, and back
  function dash(side, target, { dur = 0.6, depth = 0.86, zig = 0, hop = 0.3, onHit, hits = 1 } = {}) {
    const a0 = home0(side), t = chest(target, 0), { p } = sideOf(side);
    let hitN = 0;
    move(side, dur, (k) => {
      const out = k < 0.55 ? ease(k / 0.55) : 1 - ease((k - 0.55) / 0.45);
      const wob = zig ? Math.sin(out * Math.PI * zig) * 1.4 * (1 - out * 0.7) : 0;
      if (zig && k < 0.55) trail(side);
      // several hits: little bounces at the target
      if (k >= 0.5 && hitN < hits && k >= 0.5 + hitN * (0.12 / hits)) { hitN++; onHit?.(hitN); }
      const extra = k > 0.5 && k < 0.62 ? Math.sin((k - 0.5) / 0.12 * Math.PI * hits) * 0.15 : 0;
      return { x: lerp(a0.x, t.x, out * depth) + p.x * wob, z: lerp(a0.z, t.z, out * depth + extra) + p.z * wob, y: Math.sin(out * Math.PI) * hop };
    });
  }
  // knocked back a little by a hit
  function knock(side, amt = 0.35) { const { u, dir } = sideOf(side); const h0 = home0(side); move(side, 0.35, (k) => { const b = Math.sin(k * Math.PI) * amt; return { x: h0.x - u.x * dir * b, z: h0.z - u.z * dir * b }; }); }
  function swirl(target, type, { dur = 1.3, rise = 1.4 } = {}) { // a whirling column (Whirlpool, Fire Spin, Sand Tomb…)
    const L = lookOf(type), b = chest(target, 0), hgt = tall(target) * rise + 0.6;
    fx.push({ t: 0, life: dur, update() { for (let i = 0; i < 6; i++) { const ang = this.t * 9 + i * 1.05, y = ((this.t * 1.4 + i / 6) % 1) * hgt, r = 0.5 + y * 0.35; particle({ x: b.x + Math.cos(ang) * r, y, z: b.z + Math.sin(ang) * r * 0.6, vx: -Math.sin(ang) * 2, vz: Math.cos(ang) * 1.2, vy: 0.4, life: 0.28, size: 0.16, col: i % 2 ? L.col : L.col2, shape: L.shapes[i % L.shapes.length] }); } } });
  }
  function stream(from, to, type, { dur = 0.6, rate = 5, size = 0.16, onHit, reverse = false } = {}) { // a stream of particles (Flamethrower, Water Gun, Giga Drain back)
    const L = lookOf(type); let hit = false;
    fx.push({ t: 0, life: dur, update() {
      const A = chest(reverse ? to : from), B = chest(reverse ? from : to);
      for (let i = 0; i < rate; i++) { const s0 = Math.random() * 0.15; particle({ x: A.x, y: A.y, z: A.z, vx: (B.x - A.x) / 0.32 + rnd(-0.4, 0.4), vy: (B.y - A.y) / 0.32 + rnd(-0.2, 0.6), vz: (B.z - A.z) / 0.32 + rnd(-0.3, 0.3), life: 0.32 - s0, size: size * rnd(0.6, 1.2), col: Math.random() < 0.3 ? L.col2 : L.col, shape: L.shapes[Math.floor(Math.random() * L.shapes.length)], spin: rnd(-8, 8) }); }
      if (!hit && this.t > 0.3) { hit = true; onHit?.(); }
    } });
  }
  function powder(target, type, col) { const L = lookOf(type), b = chest(target, 1.4); for (let i = 0; i < 40; i++) particle({ x: b.x + rnd(-0.9, 0.9), y: b.y + rnd(0, 1.2), z: b.z + rnd(-0.5, 0.5), vx: rnd(-0.2, 0.2), vy: -rnd(0.5, 1.2), life: rnd(0.8, 1.4), size: 0.07, col: col ?? (i % 2 ? L.col : L.col2), shape: 'dot' }); }
  function rainOn(target, type, { n = 18, onHit } = {}) { const L = lookOf(type), b = chest(target, 0); for (let i = 0; i < n; i++) particle({ x: b.x + rnd(-1.2, 1.2), y: 5 + rnd(0, 3), z: b.z + rnd(-0.8, 0.8), vy: -9, life: 0.8, size: 0.22, col: i % 3 ? L.col : L.col2, shape: L.shapes[i % L.shapes.length], spin: rnd(-4, 4) }); setTimeout(() => onHit?.(), 520); }
  function pillar(target, type, { onHit } = {}) { const L = lookOf(type), b = chest(target, 0); for (let i = 0; i < 26; i++) particle({ x: b.x + rnd(-0.4, 0.4), y: 0.02, z: b.z + rnd(-0.3, 0.3), vy: rnd(4, 8), g: -6, life: 0.7, size: rnd(0.14, 0.3), col: i % 3 ? L.col : L.col2, shape: L.shapes[i % L.shapes.length], spin: rnd(-6, 6) }); ring({ x: b.x, y: 0.02, z: b.z }, L.col, { flat: true, r1: 1.6, life: 0.5 }); setTimeout(() => onHit?.(), 160); }
  function waveAcross(from, to, type, { onHit } = {}) { // a wall of water (or sludge) rolling across the field
    const L = lookOf(type); let hit = false;
    fx.push({ t: 0, life: 0.9, update() { const A = chest(from, 0), B = chest(to, 0), k = ease(this.t / this.life), { p } = sideOf(from);
      for (let i = -4; i <= 4; i++) { const c = { x: lerp(A.x, B.x, k) + p.x * i * 0.45, z: lerp(A.z, B.z, k) + p.z * i * 0.45 }; particle({ x: c.x, y: rnd(0, 1.1), z: c.z, vy: rnd(0.5, 1.5), life: 0.3, size: 0.24, col: Math.random() < 0.35 ? L.col2 : L.col, shape: L.shapes[0] }); }
      if (!hit && k > 0.75) { hit = true; onHit?.(); } } });
  }
  function shield(side, col = '#7affd8') { const b = chest(side); fx.push({ t: 0, life: 1.1, draw(ctx) { const q = project(b); if (!q) return; const k = this.t / this.life, r = q.k * tall(side) * 0.75 * (0.9 + Math.min(1, k * 5) * 0.1);
    ctx.save(); ctx.globalAlpha = (1 - Math.max(0, k - 0.7) / 0.3) * 0.75; const g = ctx.createRadialGradient(q.x, q.y, r * 0.6, q.x, q.y, r); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, col); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(q.x, q.y, r, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.stroke(); ctx.restore(); } }); }
  function wall(side, col) { const { u, p, dir } = sideOf(side), b = chest(side, 0); fx.push({ t: 0, life: 1.0, draw(ctx) { const c = { x: b.x + u.x * dir * 1.3, z: b.z + u.z * dir * 1.3 }; const pts = [[-1.4, 0], [1.4, 0], [1.4, 2.2], [-1.4, 2.2]].map(([w, y]) => project({ x: c.x + p.x * w, y, z: c.z + p.z * w })); if (pts.some((q) => !q)) return;
    ctx.save(); ctx.globalAlpha = Math.sin((this.t / this.life) * Math.PI) * 0.55; ctx.fillStyle = col; ctx.beginPath(); pts.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y))); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.stroke(); ctx.restore(); } }); }
  function explosion(side) { const b = chest(side); screenFlash('#ffffff', 420); shake = 2.2; for (let i = 0; i < 3; i++) setTimeout(() => ring(b, i % 2 ? '#ffd23f' : '#ff7a2a', { r1: 4 + i, life: 0.7, w: 8 }), i * 90); burst(b, '#ff9a3a', 40, { speed: 5, shape: 'flame', size: 0.3 }); crowdFlash(16); }
  function notes(from, col) { const a = chest(from, 0.8); for (let i = 0; i < 8; i++) particle({ x: a.x, y: a.y, z: a.z, vx: rnd(-1.5, 1.5), vy: rnd(0.3, 1.2), vz: rnd(-1, 1), life: 1, size: 0.22, col, shape: 'note' }); }
  function glare(from, to) { const a = chest(from, 0.8); for (const s2 of [-0.12, 0.12]) particle({ x: a.x + s2, y: a.y, z: a.z, life: 0.5, size: 0.3, col: '#ff3a3a', shape: 'star' }); screenFlash('rgba(255,40,40,.35)', 260); aura(to, '#6aa0ff', { up: false, n: 12 }); }
  // the crowd in the stands: camera flashes going off when something big happens (stadium and colosseum)
  function crowdFlash(n = 10) {
    if (!['stadium', 'colosseum'].includes(P.arena ?? P.id)) return;
    const big = P.id === 'stadium' ? [22, 19] : [20, 17];
    for (let i = 0; i < n; i++) setTimeout(() => { const ang = Math.random() * Math.PI * 2, r = 0.85 + Math.random() * 0.25; particle({ x: Math.cos(ang) * big[0] * r, y: 2 + Math.random() * 6, z: 5 + Math.sin(ang) * big[1] * r, life: 0.18, size: 0.5, col: '#ffffff', shape: 'star' }); }, i * 70 + Math.random() * 400);
  }

  // ---------- things on the camera lens: splashes, dirt, snow, embers, sparks, sunbeams, rain ----------
  let slowmo = 0, weatherNow = null, moveExtra = 0, celebrated = false, animHits = 0;
  const lens = [];
  function lensHit(kind, n = 10) {
    const W = yard.W || 960, H = yard.H || 540;
    if (kind === 'sun') { lens.push({ kind, t: 0, life: 2.2 }); return; }
    if (kind === 'mist' || kind === 'mistPink') { lens.push({ kind, t: 0, life: 1.8 }); return; }
    if (kind === 'rain') { for (let i = 0; i < 12; i++) lens.push({ kind: 'drop', x: Math.random() * W, y: Math.random() * H, r: 10 + Math.random() * 22, t: -Math.random() * 1.5, life: 3, vx: 0, vy: 10 + Math.random() * 10, rot: 0 }); }
    if (kind === 'rain') { for (let i = 0; i < 60; i++) lens.push({ kind, x: Math.random() * W, y: Math.random() * H, t: -Math.random() * 1.5, life: 0.35, len: 30 + Math.random() * 30 }); return; }
    for (let i = 0; i < n; i++) {
      const edge = Math.random() < 0.7; // most land towards the edges
      const x = edge ? (Math.random() < 0.5 ? Math.random() * W * 0.28 : W - Math.random() * W * 0.28) : Math.random() * W, y = Math.random() * H;
      const dropLike = kind === 'drop' || kind === 'dropPoison';
      lens.push({ kind, x, y, r: dropLike ? 12 + Math.random() * 34 : kind === 'leaf' ? 8 + Math.random() * 10 : kind === 'dirt' ? 2 + Math.random() * 7 : 3 + Math.random() * 6, t: -Math.random() * 0.25, life: dropLike ? 2.6 + Math.random() : kind === 'dirt' || kind === 'dust' ? 1.8 + Math.random() : 1.3 + Math.random(), vx: (Math.random() - 0.5) * 40, vy: kind === 'snow' ? 30 + Math.random() * 40 : kind === 'leaf' ? 50 + Math.random() * 40 : kind === 'ember' ? -40 - Math.random() * 40 : dropLike ? 8 + Math.random() * 16 : 0, rot: Math.random() * 6 });
    }
  }
  function drawLens(ctx, dt) {
    if (!lens.length) return;
    const W = yard.W || 960, H = yard.H || 540;
    ctx.save();
    for (let i = lens.length - 1; i >= 0; i--) {
      const d = lens[i]; d.t += dt; if (d.t >= d.life) { lens.splice(i, 1); continue; } if (d.t < 0) continue;
      const k = d.t / d.life, fade = Math.min(1, (1 - k) * 3);
      if (d.vx != null) { d.x += d.vx * dt; d.y += d.vy * dt; }
      if (d.kind === 'drop' || d.kind === 'dropPoison') { // a drop on the lens: a lens of its own, dark rim, bright highlight, sliding down
        const tint = d.kind === 'drop' ? [150, 205, 255] : [190, 110, 230];
        ctx.globalAlpha = 0.9 * fade;
        const g = ctx.createRadialGradient(d.x - d.r * 0.25, d.y - d.r * 0.3, d.r * 0.05, d.x, d.y, d.r);
        g.addColorStop(0, 'rgba(255,255,255,.75)'); g.addColorStop(0.35, `rgba(${tint},.28)`); g.addColorStop(0.8, `rgba(${tint.map((v) => v * 0.5)},.35)`); g.addColorStop(0.93, 'rgba(255,255,255,.7)'); g.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(d.x, d.y, d.r, d.r * 1.15, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.85)'; ctx.beginPath(); ctx.ellipse(d.x - d.r * 0.35, d.y - d.r * 0.4, d.r * 0.18, d.r * 0.1, -0.6, 0, Math.PI * 2); ctx.fill();
        if (d.vy > 0) { ctx.globalAlpha = 0.35 * fade; ctx.strokeStyle = `rgba(${tint},.8)`; ctx.lineWidth = Math.max(2, d.r * 0.25); ctx.beginPath(); ctx.moveTo(d.x, d.y - d.r); ctx.lineTo(d.x, d.y - d.r - d.t * 30); ctx.stroke(); }
      } else if (d.kind === 'dust') { ctx.globalAlpha = 0.6 * fade; ctx.fillStyle = '#d8c8a8'; ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2); ctx.fill(); }
      else if (d.kind === 'leaf') { ctx.globalAlpha = fade; ctx.save(); ctx.translate(d.x, d.y); ctx.rotate(d.rot + d.t * 3); ctx.fillStyle = '#4fbf4a'; ctx.beginPath(); ctx.ellipse(0, 0, d.r, d.r * 0.45, 0, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#2a7a2a'; ctx.beginPath(); ctx.moveTo(-d.r, 0); ctx.lineTo(d.r, 0); ctx.stroke(); ctx.restore(); }
      else if (d.kind === 'mist' || d.kind === 'mistPink') { const a2 = Math.sin(k * Math.PI) * 0.55; const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.25, W / 2, H / 2, W * 0.7); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, d.kind === 'mist' ? `rgba(240,248,255,${a2})` : `rgba(255,150,220,${a2})`); ctx.globalAlpha = 1; ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); }
      else if (d.kind === 'drop0') {
        ctx.globalAlpha = 0.55 * fade; const g = ctx.createRadialGradient(d.x - d.r * 0.3, d.y - d.r * 0.3, d.r * 0.1, d.x, d.y, d.r);
        g.addColorStop(0, 'rgba(255,255,255,.55)'); g.addColorStop(0.6, 'rgba(160,210,255,.15)'); g.addColorStop(0.92, 'rgba(255,255,255,.5)'); g.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(d.x, d.y, d.r, d.r * 1.12, 0, 0, Math.PI * 2); ctx.fill();
      } else if (d.kind === 'dirt') { ctx.globalAlpha = 0.85 * fade; ctx.fillStyle = d.r > 6 ? '#6a4a2a' : '#8a6a42'; ctx.save(); ctx.translate(d.x, d.y); ctx.rotate(d.rot); ctx.beginPath(); ctx.moveTo(-d.r, 0); ctx.lineTo(0, -d.r * 0.7); ctx.lineTo(d.r * 0.9, d.r * 0.2); ctx.lineTo(0, d.r); ctx.closePath(); ctx.fill(); ctx.restore(); }
      else if (d.kind === 'snow') { ctx.globalAlpha = 0.95 * fade; ctx.fillStyle = '#ffffff'; ctx.shadowColor = '#bfe8ff'; ctx.shadowBlur = 6; ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0; }
      else if (d.kind === 'ember') { ctx.globalAlpha = fade; const g = ctx.createRadialGradient(d.x, d.y, 0, d.x, d.y, d.r * 2.5); g.addColorStop(0, '#fff6b0'); g.addColorStop(0.4, '#ff9a2a'); g.addColorStop(1, 'rgba(255,80,20,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(d.x, d.y, d.r * 2.5, 0, Math.PI * 2); ctx.fill(); }
      else if (d.kind === 'spark') { ctx.globalAlpha = Math.random() < 0.5 ? fade : 0.2; ctx.strokeStyle = '#fff8a0'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(d.x, d.y); for (let j = 0; j < 3; j++) ctx.lineTo(d.x + (Math.random() - 0.5) * d.r * 6, d.y + (Math.random() - 0.5) * d.r * 6); ctx.stroke(); }
      else if (d.kind === 'rain') { ctx.globalAlpha = 0.35; ctx.strokeStyle = '#cfe6ff'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(d.x, d.y + k * 120); ctx.lineTo(d.x - 6, d.y + k * 120 + d.len); ctx.stroke(); }
      else if (d.kind === 'sun') { // sunbeams pouring in from the top corner, with lens flares
        const a = Math.sin(k * Math.PI) * 0.6; ctx.globalAlpha = a; ctx.globalCompositeOperation = 'lighter';
        for (let j = 0; j < 5; j++) { const ang = 0.5 + j * 0.16 + Math.sin(time + j) * 0.02; ctx.fillStyle = 'rgba(255,236,170,.18)'; ctx.beginPath(); ctx.moveTo(W * 0.92, -10); ctx.lineTo(W * 0.92 - Math.cos(ang) * W * 1.4 - 40, Math.sin(ang) * W * 1.4); ctx.lineTo(W * 0.92 - Math.cos(ang) * W * 1.4 + 40, Math.sin(ang) * W * 1.4); ctx.closePath(); ctx.fill(); }
        for (const [f, r, c] of [[0.35, 40, 'rgba(255,220,140,.25)'], [0.55, 22, 'rgba(160,255,200,.22)'], [0.75, 60, 'rgba(255,170,120,.15)']]) { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(W * 0.92 - W * 0.6 * f, H * 0.7 * f, r, 0, Math.PI * 2); ctx.fill(); }
        ctx.globalCompositeOperation = 'source-over';
      }
    }
    ctx.restore();
  }
  // which moves throw things at the camera
  function lensFor(m, C) {
    const name = String(m.name).toLowerCase(), dmg = m.cat !== 'Status', strong = m.bp >= 80;
    if (m.weather === 'sunnyday' || /solar|sunny|morning sun|synthesis/.test(name)) return 'sun';
    if (m.weather === 'raindance') return 'rain';
    if (m.weather === 'sandstorm') return 'dirt';
    if (m.weather === 'snow' || m.weather === 'hail' || m.weather === 'snowscape') return 'snow';
    if (m.terrain) return { electricterrain: 'spark', grassyterrain: 'leaf', mistyterrain: 'mist', psychicterrain: 'mistPink' }[m.terrain] ?? 'mist';
    if (!dmg) return null;
    if (m.type === 'Water') return 'drop';
    if (m.type === 'Fire') return 'ember';
    if (m.type === 'Ground' || m.type === 'Rock' || C.kind === 'quake' || (C.kind === 'burrow' && !C.splash)) return 'dirt';
    if (m.type === 'Ice') return 'snow';
    if (m.type === 'Electric' && (strong || C.kind === 'thunder')) return 'spark';
    if (m.type === 'Grass' && (strong || m.cat === 'Special')) return 'leaf';
    if (m.type === 'Poison' && /sludge|gunk|acid/.test(name)) return 'dropPoison';
    if ((m.type === 'Psychic' || m.type === 'Fairy') && strong) return 'mistPink';
    if (C.kind === 'explosion') return 'ember';
    if (m.flags?.contact && strong) return 'dust';
    return null;
  }
  // a powerful move (Hyper Beam, Giga Impact, Blast Burn, Explosion…): the scene dims, power gathers, then it lands like a bomb
  const dim = (on) => el.classList.toggle('dim', on);
  function smoke(at, n = 10) { for (let i = 0; i < n; i++) particle({ x: at.x + rnd(-0.6, 0.6), y: at.y * rnd(0.2, 1), z: at.z + rnd(-0.4, 0.4), vx: rnd(-0.6, 0.6), vy: rnd(0.2, 0.7), vz: rnd(-0.3, 0.3), life: rnd(1.4, 2.2), size: rnd(0.5, 0.9), col: 'rgba(200,196,190,.55)', shape: 'wisp' }); }
  function bigImpact(side, col) { const at = chest(side); screenFlash('#ffffff', 380); shake = Math.max(shake, 2.2); for (let i = 0; i < 3; i++) setTimeout(() => ring(at, i % 2 ? '#ffffff' : col, { r1: 3 + i * 1.3, life: 0.6, w: 7 }), i * 80); burst(at, col, 34, { speed: 4.5, size: 0.24 }); burst(at, '#ffffff', 14, { speed: 5, shape: 'star', size: 0.14 }); smoke(chest(side, 0.3), 12); crowdFlash(18); }

  // one of Showdown's effect pictures popping at a spot (an impact star, a fist, a bite, a slash)
  function fxPop(at, name, { size = 1, life = 0.35, spin = 0 } = {}) {
    if (!fxImage(resolveTexture, name)) return false;
    fx.push({ t: 0, life, draw(ctx) { const im = fxImage(resolveTexture, name), q = project(at); if (!im || !q) return; const k = this.t / this.life, w = q.k * size * (0.7 + ease(Math.min(1, k * 3)) * 0.5);
      ctx.save(); ctx.globalAlpha = 1 - Math.max(0, k - 0.6) / 0.4; ctx.translate(q.x, q.y); ctx.rotate(spin * k); ctx.drawImage(im, -w / 2, -w / 2, w, w); ctx.restore(); } });
    return true;
  }
  // a big word stamped across the screen ("CRITICAL HIT!")
  function stamp(word, col) { fx.push({ t: 0, life: 1.2, draw(ctx) { const k = this.t / this.life, W = yard.W, H = yard.H, sc = 1 + Math.max(0, 0.25 - k) * 3; ctx.save(); ctx.globalAlpha = Math.min(1, (1 - k) * 3); ctx.translate(W / 2, H * 0.42); ctx.rotate(-0.06); ctx.scale(sc, sc); ctx.font = `900 ${Math.round(H * 0.085)}px "Segoe UI", system-ui, sans-serif`; ctx.textAlign = 'center'; ctx.lineWidth = 8; ctx.strokeStyle = '#1a1020'; ctx.strokeText(word, 0, 0); ctx.fillStyle = col; ctx.fillText(word, 0, 0); ctx.restore(); } }); }
  // ---------- creatures out of reach (Fly, Dig, Dive, Phantom Force) and charging up ----------
  const vanished = [null, null];
  function vanish(side, how, type) {
    const a = actor(side); if (!a) return;
    vanished[side] = how;
    const L = lookOf(type), b = chest(side, 0);
    if (how === 'up') { move(side, 0.7, (k) => ({ ...home0(side), y: ease(k) * 9, alpha: 1 - Math.max(0, k - 0.6) * 2.5 }), { end() { const a2 = actor(side); if (a2) { a2.alpha = 0; } } }); for (let i = 0; i < 10; i++) particle({ x: b.x + rnd(-0.6, 0.6), y: 0.1, z: b.z + rnd(-0.4, 0.4), vy: rnd(1, 2), life: 0.6, size: 0.18, col: '#ffffff', shape: 'feather' }); }
    else if (how === 'under' || how === 'water') { move(side, 0.6, (k) => ({ ...home0(side), y: -ease(k) * 1.5, alpha: 1 - k }), { end() { const a2 = actor(side); if (a2) a2.alpha = 0; } }); burst({ x: b.x, y: 0.1, z: b.z }, how === 'water' ? '#6ac0ff' : '#b89060', 22, { speed: 2.5, shape: how === 'water' ? 'drop' : 'rock', up: 1.2 }); }
    else { fx.push({ t: 0, life: 0.7, update() { const a2 = actor(side); if (a2) a2.alpha = 1 - this.t / this.life; for (let i = 0; i < 2; i++) particle({ x: b.x + rnd(-0.6, 0.6), y: rnd(0, tall(side)), z: b.z + rnd(-0.3, 0.3), vy: rnd(0.3, 1), life: 0.6, size: 0.3, col: L.col, shape: 'wisp' }); }, end() { const a2 = actor(side); if (a2) a2.alpha = 0; } }); }
  }
  function unvanish(side) { vanished[side] = null; const a = actor(side); if (a) { a.alpha = 1; a.y = 0; } }
  function chargeUp(side, type) { // Solar Beam, Skull Bash, Meteor Beam… gathering power
    const L = lookOf(type), b = chest(side);
    fx.push({ t: 0, life: 1.1, update() { for (let i = 0; i < 3; i++) { const ang = Math.random() * Math.PI * 2, r = 1.6; particle({ x: b.x + Math.cos(ang) * r, y: b.y + rnd(-0.6, 0.9), z: b.z + Math.sin(ang) * r * 0.6, vx: -Math.cos(ang) * r * 2.2, vy: 0, vz: -Math.sin(ang) * r * 1.3, life: 0.42, size: 0.07, col: i % 2 ? L.col : L.col2, shape: 'dot' }); } }, draw(ctx) { const q = project(b); if (q) { ctx.globalAlpha = 0.6; glow(ctx, q.x, q.y, q.k * 0.25 * (0.6 + this.t), L.col); ctx.globalAlpha = 1; } } });
  }

  // ---------- the move announcement and the announcer ----------
  let banTimer = null, castTimer = null, lastCast = 0;
  const nameOf = (side) => { const m = mons[side]?.info; const n = m?.name || m?.species || ''; return side === 1 && intro !== 'trainer' ? `The wild ${n}` : n; };
  let lastAnnounce = '';
  function announce(side, mv) {
    const key = `${side}|${mv.id}|${lastTurn}`;
    if (key === lastAnnounce) return; // once per move per turn (Dragon Darts' second dart isn't announced again)
    lastAnnounce = key;
    banner.querySelector('.who').textContent = `${nameOf(side)} used`;
    banner.querySelector('.mv').textContent = mv.name;
    banner.style.setProperty('--tc', lookOf(mv.type).col);
    banner.className = `bst-moveban on side${side}`;
    clearTimeout(banTimer); banTimer = setTimeout(() => banner.classList.remove('on'), 1100 * Math.min(1.2, tempo()));
  }
  function cast(line, { force = false } = {}) {
    return; // the announcer's remarks are switched off
    // eslint-disable-next-line no-unreachable
    const now = performance.now();
    if (!force && now - lastCast < 2500) return;
    lastCast = now;
    caster.textContent = line;
    caster.classList.remove('on'); void caster.offsetWidth; caster.classList.add('on');
    clearTimeout(castTimer); castTimer = setTimeout(() => caster.classList.remove('on'), 3000);
  }
  const pick = (a) => a[Math.floor(Math.random() * a.length)];

  // ---------- acting out a move ----------
  function playMove(ev) {
    const m = ev.move, from = ev.from?.side;
    if (from == null || !actor(from) && !vanished[from]) return;
    const to = ev.to?.side ?? (from === 0 ? 1 : 0), miss = !!ev.miss;
    const C = classifyMove(m), L = lookOf(m.type), col = L.col;
    // what really happens, read ahead from the battle log: how many hits land, a critical hit, a knockout…
    const O = ev.outcome ?? null;
    if (O && O.hits > 0 && (C.hits > 1 || O.hits > 1)) C.hits = O.hits;
    const blocked = O?.blocked ?? null, immune = !!O?.immune && !O.hits;
    const power = m.bp >= 120 || (m.recharge && m.cat !== 'Status') || m.ohko || (m.selfdestruct && m.cat !== 'Status') || (C.big && m.bp >= 100);
    const lensKind = lensFor(m, C);
    // a move shown in several parts (Dragon Darts' darts): count them, and say how many hit at the end
    animHits = ev.again ? animHits + (O?.hits ? 1 : 0) : (O?.hits ? 1 : 0);
    if (ev.again && !O?.moreAnim && animHits > 1) { const n = animHits; setTimeout(() => say(`Hit ${n} times!`), (C.travel * T + 0.6) * 1000); }
    const beamType = power && m.type === 'Normal' ? 'HyperBeam' : m.type; // Hyper Beam's famous orange-gold
    moveExtra = (power ? 1100 : 0) + Math.max(0, (C.hits || 1) - 1) * 260; // Showdown waits longer for these
    const SF = moveFx(null, { name: m.name, type: String(m.type).toLowerCase(), category: String(m.cat).toLowerCase(), power: m.bp }); // Showdown's picture for it
    if (vanished[from]) unvanish(from); // coming back for the strike
    const targetGone = !!vanished[to];
    const T = tempo(), cine = dynamic && T >= 0.5;
    announce(from, m);
    // the target reacting to being hit (unless it missed, or the target is out of reach)
    let hitOnce = false;
    const hitIt = (big = C.big || m.bp >= 100, n = 1) => {
      if (blocked && actor(to)) { if (n === 1) { shield(to, blocked === 'Protect' || blocked === 'Detect' ? 'rgba(120,255,210,.8)' : col); const { u, dir } = sideOf(from); ring(chest(to), '#ffffff', { r1: 1.4, life: 0.3 }); void u; void dir; } return; }
      if (immune && actor(to)) { if (n === 1) ring(chest(to), 'rgba(255,255,255,.7)', { r1: 1.2, life: 0.5, w: 2 }); return; }
      if (miss || targetGone || !actor(to)) { if (n === 1 && actor(to) && !targetGone) { const { p } = sideOf(to), h0 = home0(to); move(to, 0.4, (k) => { const s2 = Math.sin(k * Math.PI) * 0.8; return { x: h0.x + p.x * s2, z: h0.z + p.z * s2 }; }); } return; }
      const at = chest(to);
      burst(at, col, big ? 22 : 14, { speed: big ? 3.2 : 2.4, shape: L.shapes[0] });
      burst(at, '#ffffff', 6, { speed: 3, shape: 'star', size: 0.1 });
      fxPop(at, contactKinds.includes(C.kind) && ['fist', 'foot', 'leftslash', 'topbite', 'sword'].includes(SF.img) ? SF.img : 'impact', { size: big ? 1.3 : 0.9 });
      ring(at, col, { r1: big ? 1.9 : 1.2, life: 0.4 });
      knock(to, big || O?.superEff ? 0.55 : O?.resisted ? 0.15 : 0.3);
      shake = Math.max(shake, big ? 1.1 : O?.resisted ? 0.3 : 0.6);
      if (big) crowdFlash(8);
      const last = n >= (C.hits || 1);
      if (!hitOnce || last) {
        hitOnce = true;
        if (power && last) bigImpact(to, col);
        if (lensKind && lensKind !== 'sun' && lensKind !== 'rain' && last) lensHit(lensKind, Math.round(6 + m.bp / 9 + (power ? 10 : 0) + (O?.superEff ? 6 : 0)));
        if (last) shake = Math.max(shake, 0.45 + m.bp / 110 + (O?.superEff ? 0.5 : 0) + (O?.crit ? 0.6 : 0));
        if (last && shake >= 1.2) { el.classList.remove('cry'); void el.offsetWidth; el.classList.add('cry'); setTimeout(() => el.classList.remove('cry'), 650); }
        if (O?.superEff && last) { ring(at, '#ffffff', { r1: 2.6, life: 0.5, w: 6 }); burst(at, col, 18, { speed: 4 }); }
        // a critical hit or the final blow: everything slows for a moment
        if ((O?.crit || O?.ko) && last) { slowmo = O.ko ? 0.9 : 0.6; screenFlash('#ffffff', 200); if (O.crit) stamp('CRITICAL HIT!', '#ffd23f'); }
      }
    };
    const contactKinds = ['contact', 'zigzag', 'punch', 'kick', 'bite', 'slash', 'horn', 'tackleSpin', 'wrap'];
    const selfKinds = ['self', 'protect', 'heal', 'dance', 'weather', 'terrain', 'field', 'screen'];
    const windup = ev.again ? 0.05 : cine ? (power ? 1.9 : 1.05) * T : 0.1;
    const travel = C.travel * (cine ? T : 0.7);
    // the camera, Battle Revolution style: the one using the move up close as it's announced, then it follows
    // the move across, then the one it hits
    if (cine && !ev.again) {
      const big = m.bp >= 90;
      cutTo(() => (big && !contactKinds.includes(C.kind) ? SHOT.hero(from) : SHOT.front(from, 1.05)), { hold: windup, drift: 0.28 });
      if (selfKinds.includes(C.kind)) queueShot(() => (C.kind === 'weather' || C.kind === 'field' || C.kind === 'terrain' ? SHOT.wide() : SHOT.front(from, 1.5)), { dur: 0.5 * T, hold: 1.2 * T, drift: 0.25 });
      else {
        if (C.kind === 'zigzag' || C.kind === 'tackleSpin') queueShot(() => SHOT.side(from === 0 ? 1 : -1), { hold: travel + 0.1, drift: 0.2 });
        else if (contactKinds.includes(C.kind)) queueShot(() => SHOT.shoulder(from), { hold: travel, drift: 0 });
        else if (['projectile', 'volley', 'status', 'drain', 'pulse', 'psychic'].includes(C.kind)) queueShot(() => SHOT.side(from === 0 ? 1 : -1), { hold: travel * (C.kind === 'volley' ? C.hits * 0.75 : 1), drift: 0.15, track: () => flying });
        else if (C.kind === 'beam' || C.kind === 'wave') queueShot(() => SHOT.shoulder(from), { hold: travel + 0.35, drift: 0.1 });
        else if (['quake', 'rockfall', 'thunder', 'rainDown', 'explosion', 'hazard'].includes(C.kind)) queueShot(Math.random() < 0.5 ? SHOT.wide : SHOT.overhead, { hold: travel + 0.3, drift: 0.6 });
        else if (C.kind === 'dive') queueShot(SHOT.overhead, { hold: travel + 0.1, drift: 0.3 });
        else if (C.kind === 'phantom' || C.kind === 'burrow') queueShot(() => SHOT.behindFoe(), { hold: travel + 0.1, drift: 0.2 });
        queueShot(() => SHOT.front(to, C.kind === 'vortex' || C.kind === 'wrap' ? 1.5 : 1.25), { hold: (C.kind === 'vortex' ? 1.6 : 1.15) * T, drift: 0.22 });
      }
      home(0);
    }
    // a powerful move: the stage darkens and power gathers before it's unleashed
    if (power && cine) { dim(true); chargeUp(from, m.type); setTimeout(() => chargeUp(from, m.type), 700 * T); setTimeout(() => dim(false), (windup + travel + 0.6) * 1000); shake = Math.max(shake, 0.3); setTimeout(() => { shake = Math.max(shake, 0.5); }, 900 * T); }
    if (lensKind && (lensKind === 'sun' || lensKind === 'rain' || m.cat === 'Status')) setTimeout(() => { lensHit(lensKind, 16); shake = Math.max(shake, 0.5); }, windup * 1000 + 300);
    // gathering itself while the name is up
    if (cine && !selfKinds.includes(C.kind)) { const a = actor(from); if (a) a.hop = 0.8; const b = chest(from); for (let i = 0; i < 14; i++) { const ang = Math.random() * Math.PI * 2; particle({ x: b.x + Math.cos(ang) * 0.9, y: b.y + rnd(-0.5, 0.6), z: b.z + Math.sin(ang) * 0.5, vx: -Math.cos(ang) * 1.6, vz: -Math.sin(ang) * 0.9, life: 0.5, size: 0.1, col: i % 2 ? col : L.col2, shape: 'dot' }); } }
    const go = () => {
      if (destroyed) return;
      const big = C.big || m.bp >= 100;
      switch (C.kind) {
        // on the user
        case 'self': aura(from, col, { up: true }); ring(chest(from, 0.05), col, { flat: true, r1: 1.6, life: 0.7 }); sparkleOn(from, L.col2, L.shapes.includes('heart') ? 'heart' : 'star', 10); return;
        case 'dance': { const a = actor(from); for (let i = 0; i < 6; i++) setTimeout(() => { const a2 = actor(from); if (a2) { a2.battleFaceLock = i % 2 ? 'left' : 'right'; a2.hop = 0.6; } }, i * 160); setTimeout(() => { const a2 = actor(from); if (a2) a2.battleFaceLock = null; }, 1000); void a; aura(from, col, { up: true }); notes(from, L.col2); return; }
        case 'heal': sparkleOn(from, '#9dffb8', 'star', 16); aura(from, '#7dffa0'); ring(chest(from, 0.05), '#9dffb8', { flat: true, r1: 1.5, life: 0.8 }); return;
        case 'protect': shield(from, m.type === 'Normal' ? 'rgba(120,255,210,.8)' : col); return;
        case 'weather': case 'terrain': case 'field': screenFlash(m.weather === 'sunnyday' ? 'rgba(255,220,120,.5)' : 'rgba(255,255,255,.4)', 500); ring(chest(from, 0.02), col, { flat: true, r1: 9, life: 1.1, w: 6 }); for (let i = 0; i < 30; i++) particle({ x: rnd(-6, 6), y: rnd(0.2, 3), z: 5 + rnd(-5, 5), vy: rnd(0.2, 1), life: 1, size: 0.15, col: i % 2 ? L.col : L.col2, shape: L.shapes[0] }); return;
        case 'screen': wall(from, col); sparkleOn(from, L.col2, 'star', 8); return;
        // aimed at the target, from where it stands
        case 'status': projectile(from, to, m.type, { dur: travel, shape: m.status === 'slp' || m.flags.sound ? 'note' : 'star', size: 0.18, miss, onHit: () => { if (miss) return; sparkleOn(to, col); ring(chest(to), col, { life: 0.5 }); if (m.status === 'par') bolts(to, { fromSky: false, from: to }); if (m.status === 'psn' || m.status === 'tox') powder(to, 'Poison'); if (m.status === 'brn') burst(chest(to), '#ff7a2a', 12, { shape: 'flame', up: 1.5, g: 1 }); } }); return;
        case 'powder': powder(to, m.type); return;
        case 'debuff': for (let i = 0; i < 3; i++) setTimeout(() => ring(chest(from, 0.7), col, { r1: 2.4, life: 0.5, w: 3 }), i * 120); setTimeout(() => !miss && aura(to, '#6aa0ff', { up: false, n: 14 }), 400); return;
        case 'glare': glare(from, to); return;
        case 'swap': projectile(from, to, m.type, { dur: travel * 0.7, shape: 'orb', size: 0.15 }); setTimeout(() => projectile(to, from, m.type, { dur: travel * 0.7, shape: 'orb', size: 0.15 }), 200); return;
        case 'hazard': for (let i = 0; i < 8; i++) particle({ ...chest(from), vx: (chest(to).x - chest(from).x) / 0.6 + rnd(-1.5, 1.5), vy: 3, vz: (chest(to).z - chest(from).z) / 0.6 + rnd(-1, 1), g: -10, life: 0.8, size: 0.2, col, shape: L.shapes[0], spin: rnd(-5, 5) }); return;
        // physical, at the target
        case 'zigzag': dash(from, to, { dur: 0.75 * Math.max(0.8, T), zig: 3, hop: 0.15, onHit: () => hitIt(false) }); return;
        case 'contact': case 'punch': case 'kick': case 'bite': case 'slash': case 'horn': case 'tackleSpin': case 'wrap': {
          const hits = C.hits;
          dash(from, to, { dur: (0.6 + (hits - 1) * 0.12) * Math.max(0.8, T), depth: C.kind === 'tackleSpin' ? 0.92 : 0.86, hop: C.kind === 'kick' ? 0.9 : C.kind === 'tackleSpin' ? 0.5 : 0.3, hits, onHit: (n) => {
            hitIt(big, n);
            if (miss || targetGone) return;
            if (C.kind === 'punch') burst(chest(to), '#ffffff', 8, { shape: 'fist', speed: 1.5, size: 0.3 });
            if (C.kind === 'kick') burst(chest(to, 0.3), '#ffe48a', 10, { shape: 'star', speed: 2 });
            if (C.kind === 'bite') bite(to);
            if (C.kind === 'slash') slashes(to, m.type === 'Normal' ? '#ffffff' : col);
            if (C.kind === 'horn') ring(chest(to), '#ffffff', { r0: 0.1, r1: 0.7, life: 0.25, w: 6 });
            if (C.kind === 'wrap') swirl(to, m.type, { dur: 1.1 });
            if (m.type !== 'Normal' && m.type !== 'Fighting') burst(chest(to), col, 10, { shape: L.shapes[0] });
          } });
          if (C.kind === 'tackleSpin') for (let i = 0; i < 6; i++) setTimeout(() => trail(from, col), i * 60);
          return;
        }
        // out of reach, coming back for the strike
        case 'dive': { const t = chest(to, 0); const a = actor(from); if (a) a.alpha = 1;
          move(from, 0.6, (k) => (k < 0.55 ? { x: t.x, z: t.z, y: 9 * (1 - ease(k / 0.55)), alpha: 1 } : { x: lerp(t.x, home0(from).x, ease((k - 0.55) / 0.45)), z: lerp(t.z, home0(from).z, ease((k - 0.55) / 0.45)), y: Math.sin(((k - 0.55) / 0.45) * Math.PI) * 1.2 }));
          setTimeout(() => { hitIt(true); burst({ ...t, y: 0.1 }, '#ffffff', 16, { speed: 3, shape: 'feather' }); }, 330); return; }
        case 'burrow': { const t = chest(to, 0);
          move(from, 0.7, (k) => (k < 0.4 ? { x: t.x, z: t.z, y: -1.4 + ease(k / 0.4) * 1.6, alpha: 1 } : { x: lerp(t.x, home0(from).x, ease((k - 0.4) / 0.6)), z: lerp(t.z, home0(from).z, ease((k - 0.4) / 0.6)), y: Math.sin(((k - 0.4) / 0.6) * Math.PI) * 1.4 }));
          setTimeout(() => { burst({ ...t, y: 0.1 }, C.splash ? '#6ac0ff' : '#b89060', 24, { speed: 3.5, shape: C.splash ? 'drop' : 'rock', up: 1.6 }); hitIt(true); }, 260); return; }
        case 'phantom': { const t = chest(to, 0), { u, dir } = sideOf(from), behind = { x: t.x + u.x * dir * 1.3, z: t.z + u.z * dir * 1.3 };
          move(from, 0.75, (k) => (k < 0.45 ? { ...behind, alpha: Math.min(1, k * 4) } : { x: lerp(behind.x, home0(from).x, ease((k - 0.45) / 0.55)), z: lerp(behind.z, home0(from).z, ease((k - 0.45) / 0.55)), alpha: 1 - Math.sin(((k - 0.45) / 0.55) * Math.PI) * 0.8 }));
          setTimeout(() => { slashes(to, '#c0a8ff'); hitIt(true); }, 250); return; }
        // the whole field
        case 'quake': quake(from); setTimeout(() => hitIt(true), 300); return;
        case 'rockfall': rocksFall(to, col); setTimeout(() => hitIt(), 520); return;
        case 'spikes': pillar(to, m.type, { onHit: () => hitIt(big) }); return;
        case 'rainDown': rainOn(to, m.type, { onHit: () => hitIt(big) }); return;
        case 'explosion': explosion(from); setTimeout(() => hitIt(true), 250); return;
        case 'thunder': bolts(to, { fromSky: true, onHit: () => hitIt(true) }); screenFlash('#fff8c0', 180); return;
        case 'zap': bolts(to, { fromSky: false, from, onHit: () => hitIt() }); return;
        case 'beam': beam(from, to, beamType, { dur: power ? 1.4 : 0.85, width: power ? 2.4 : 1, onHit: () => hitIt(big) }); if (big) screenFlash(col, 260); if (power) { shake = 1.6; for (let i = 0; i < 6; i++) setTimeout(() => ring(chest(from), '#ffffff', { r0: 0.3, r1: 1.4, life: 0.3, w: 3 }), i * 120); } return;
        case 'wave': waveAcross(from, to, m.type, { onHit: () => hitIt(big) }); return;
        case 'pulse': for (let i = 0; i < 4; i++) setTimeout(() => projectile(from, to, m.type, { dur: travel, shape: 'ring', size: 0.3 + i * 0.05, onHit: i === 3 ? () => hitIt(big) : null, miss }), i * 90); return;
        case 'psychic': for (let i = 0; i < 3; i++) setTimeout(() => ring(chest(to), col, { r0: 1.6, r1: 0.2, life: 0.5, w: 4 }), i * 120); setTimeout(() => { hitIt(); if (!miss && actor(to)) move(to, 0.6, (k) => ({ ...home0(to), y: Math.sin(k * Math.PI) * 0.7 })); }, 380); return;
        case 'sound': for (let i = 0; i < 4; i++) setTimeout(() => ring(chest(from, 0.7), col, { r1: 3.2, life: 0.6, w: 4 }), i * 110); notes(from, L.col2); setTimeout(() => hitIt(), 400); return;
        case 'wind': for (let i = 0; i < 24; i++) setTimeout(() => particle({ ...chest(from), vx: (chest(to).x - chest(from).x) / 0.4 + rnd(-1, 1), vy: rnd(-0.3, 0.6), vz: (chest(to).z - chest(from).z) / 0.4 + rnd(-1, 1), life: 0.45, size: 0.2, col: i % 3 ? '#ffffff' : col, shape: m.type === 'Flying' ? 'feather' : L.shapes[0], spin: 8 }), i * 12); setTimeout(() => { hitIt(); if (!miss) swirl(to, 'Flying', { dur: 0.6, rise: 1 }); }, 380); return;
        case 'vortex': projectile(from, to, m.type, { dur: travel, size: 0.24, miss, img: SF.img, onHit: () => { hitIt(); if (!miss && !targetGone) swirl(to, m.type, { dur: 1.6 }); } }); return;
        case 'drain': { // from the target to the user: the life it takes
          if (m.cat !== 'Status') projectile(from, to, m.type, { dur: travel * 0.6, size: 0.18, miss, onHit: () => hitIt() });
          if (miss) return;
          setTimeout(() => { stream(from, to, m.type, { dur: 0.7, rate: 3, size: 0.12, reverse: true }); for (let i = 0; i < 12; i++) particle({ ...chest(to), vx: (chest(from).x - chest(to).x) / 0.7 + rnd(-0.5, 0.5), vy: rnd(0.3, 1.2), vz: (chest(from).z - chest(to).z) / 0.7 + rnd(-0.4, 0.4), life: 0.7, size: 0.12, col: '#9dffb8', shape: 'dot' }); }, travel * 600 + 150);
          setTimeout(() => sparkleOn(from, '#9dffb8', 'star', 10), travel * 600 + 850);
          return;
        }
        case 'volley': { // several shots: Dragon Darts, Bullet Seed, Pin Missile, Water Shuriken…
          const n = C.hits, gap = Math.max(0.16, 0.26 * T);
          for (let i = 0; i < n; i++) setTimeout(() => projectile(from, to, m.type, { dur: travel, size: m.name === 'Dragon Darts' ? 0.22 : 0.16, shape: /dart|missile|needle|pin/i.test(m.name) ? 'needle' : null, miss, img: SF.img, onHit: () => hitIt(false, i + 1) }), i * gap * 1000);
          return;
        }
        default:
          if (C.stream) stream(from, to, m.type, { dur: 0.75, rate: 5, onHit: () => hitIt(big) });
          else projectile(from, to, m.type, { dur: travel, size: m.bp >= 90 ? 0.34 : 0.24, miss, img: SF.img, onHit: () => hitIt(big) });
      }
    };
    setTimeout(go, windup * 1000);
  }

  const statusOf = [null, null], pinched = [false, false];
  function renderHud(side, info, team) {
    const box = hud[side];
    if (info) { statusOf[side] = info.fainted ? null : info.status || null; if (info.pct >= 0.25) pinched[side] = false; }
    if (!info) { box.hidden = true; return; }
    box.hidden = !introOver && !!intro; // the plates come in once the opening is over
    const pct = Math.max(0, Math.min(1, info.pct ?? 0));
    const col = pct > 0.5 ? 'g' : pct > 0.2 ? 'y' : 'r';
    const gender = info.gender === 'M' ? h('b', { class: 'm' }, '♂') : info.gender === 'F' ? h('b', { class: 'f' }, '♀') : null;
    const balls = (team?.[side] ?? []).map((t) => h('i', { class: `ball ${!t.seen ? 'unknown' : t.fainted ? 'out' : t.status ? 'st' : ''}` }));
    let bar = box.querySelector('.bst-hpfill');
    // Battle Revolution's plate: name and gender over "Lv." and the HP bar (and your HP), with a P1/CPU tag
    if (!box.firstChild || box.dataset.ident !== info.ident) {
      box.dataset.ident = info.ident;
      const tag = h('span', { class: 'tag' }, side === 0 ? 'P1' : intro === 'trainer' ? 'CPU' : 'WILD');
      box.replaceChildren(
        h('div', { class: 'bst-balls' }),
        h('div', { class: 'bst-name' }, side === 1 ? tag : null, h('span', { class: 'n' }, String(info.name || info.species).toUpperCase()), gender, side === 0 ? tag : null),
        h('div', { class: 'bst-hprow' }, h('span', { class: 'lv' }, `Lv. ${info.level}`), h('span', { class: 'bst-status' }), h('div', { class: 'bst-hpbar' }, h('div', { class: 'bst-hpfill' })), h('span', { class: 'bst-hpnum' })));
      bar = box.querySelector('.bst-hpfill');
      bar.style.transition = 'none'; bar.style.width = `${pct * 100}%`; void bar.offsetWidth; bar.style.transition = '';
    }
    bar.style.width = `${pct * 100}%`;
    bar.className = `bst-hpfill ${col}`;
    const st = box.querySelector('.bst-status');
    st.textContent = info.fainted ? 'FNT' : STATUS_LABEL[info.status] ?? '';
    st.style.background = info.fainted ? '#a04040' : STATUS_COL[info.status] ?? 'transparent';
    st.hidden = !st.textContent;
    box.querySelector('.bst-hpnum').textContent = side === 0 && info.maxhp ? `${Math.max(0, Math.round(info.hp))}/${info.maxhp}` : '';
    box.querySelector('.bst-balls').replaceChildren(...balls);
  }

  // ---------- the text box ----------
  let typing = null;
  function say(s) {
    if (!s) return;
    if (/ used .+!$/.test(s) && banner.classList.contains('on')) { text.classList.remove('on'); return; } // the banner says it
    clearInterval(typing);
    text.classList.add('on');
    let i = 0;
    text.textContent = '';
    typing = setInterval(() => { i += 2; text.textContent = s.slice(0, i); if (i >= s.length) clearInterval(typing); }, 16);
  }

  // ---------- each frame ----------
  function frame(ctx) {
    const now = performance.now(), dt0 = Math.min(0.05, (now - last) / 1000); last = now;
    // slow motion for a critical hit or a knockout blow
    slowmo = Math.max(0, slowmo - dt0); const dt = slowmo > 0 ? dt0 * 0.28 : dt0; time += dt;
    stepCamera(dt);
    // statuses show all the time, gently: Zzz, bubbles, embers, sparks, frost, and stars for confusion
    for (const side of [0, 1]) {
      const st = statusOf[side], a = actor(side); if (!a || vanished[side]) continue;
      const top = chest(side, 1), mid = chest(side, 0.5), r0 = Math.random();
      if (st === 'slp' && r0 < dt * 1.3) particle({ ...top, x: top.x + 0.2, vy: 0.5, vx: 0.25, life: 1.4, size: 0.2, col: '#ffffff', shape: 'zzz' });
      else if ((st === 'psn' || st === 'tox') && r0 < dt * 2) particle({ ...mid, x: mid.x + rnd(-0.4, 0.4), vy: rnd(0.3, 0.7), life: 0.9, size: 0.12, col: '#c070f0', shape: 'bubble' });
      else if (st === 'brn' && r0 < dt * 3) particle({ ...mid, x: mid.x + rnd(-0.4, 0.4), y: mid.y * rnd(0.3, 1.4), vy: rnd(0.5, 1), life: 0.6, size: 0.14, col: '#ff7a2a', shape: 'flame' });
      else if (st === 'par' && r0 < dt * 1.5) particle({ ...mid, x: mid.x + rnd(-0.5, 0.5), y: mid.y * rnd(0.4, 1.5), life: 0.2, size: 0.3, col: '#ffe03a', shape: 'spark' });
      else if (st === 'frz' && r0 < dt * 2) particle({ ...mid, x: mid.x + rnd(-0.5, 0.5), y: mid.y * rnd(0.2, 1.6), vy: 0.1, life: 0.8, size: 0.14, col: '#c8f4ff', shape: 'flake' });
      const vol = mons[side]?.info?.vol ?? [];
      if (vol.includes('confusion') && r0 < dt * 4) { const ang = time * 4 + Math.random(); particle({ x: top.x + Math.cos(ang) * 0.4, y: top.y + 0.15, z: top.z + Math.sin(ang) * 0.25, vx: -Math.sin(ang) * 1.6, vz: Math.cos(ang), life: 0.35, size: 0.12, col: '#ffe86a', shape: 'star' }); }
      a.tint = st === 'frz' ? 'frz' : st === 'par' && Math.sin(time * 9) > 0.92 ? 'par' : null;
    }
    for (const e of fx) { e.t += dt; e.update?.(dt); }
    for (let i = fx.length - 1; i >= 0; i--) if (fx[i].t >= fx[i].life) { fx[i].end?.(); fx.splice(i, 1); }
    for (const p of parts) { p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.vy += p.g * dt; p.rot += p.spin * dt; if (p.y < 0 && p.g < 0) { p.y = 0; p.vy *= -0.3; p.vx *= 0.6; } }
    for (let i = parts.length - 1; i >= 0; i--) if (parts[i].life <= 0) parts.splice(i, 1);
    ctx.save();
    for (const e of fx) e.draw?.(ctx);
    for (const p of parts) drawParticle(ctx, p);
    ctx.restore();
    // weather on the lens now and then: raindrops, a flake of snow, a sunbeam, grit in a sandstorm
    if (weatherNow && Math.random() < dt0 * 0.9) { const wk = { raindance: 'drop', primordialsea: 'drop', sunnyday: 'sun', desolateland: 'sun', sandstorm: 'dirt', hail: 'snow', snow: 'snow', snowscape: 'snow' }[weatherNow]; if (wk) lensHit(wk, wk === 'sun' ? 1 : 3); }
    drawLens(ctx, dt0);
    // hover areas for Showdown's tooltips, over each creature
    const r = canvas.getBoundingClientRect(), sx = r.width / (canvas.width || 1), sy = r.height / (canvas.height || 1);
    for (const side of [0, 1]) {
      const b = actor(side) && yard.actorBox(uidOf(side));
      const t = tips[side]; t.style.display = 'none'; continue; // (the plates have the tooltips now)
      if (!b) { t.style.display = 'none'; continue; }
      t.style.display = 'block';
      Object.assign(t.style, { left: `${b.x0 * sx}px`, top: `${b.y0 * sy}px`, width: `${Math.max(20, (b.x1 - b.x0) * sx)}px`, height: `${Math.max(20, (b.y1 - b.y0) * sy)}px` });
    }
  }

  // ---------- Showdown's events ----------
  let lastTeam = null, summons = 0, lastTurn = 0;
  let intro = null, revealed = false, waitingNear = false, introOver = false;
  // while the opening plays, Showdown's buttons and log stay hidden (they'd spoil it)
  function setIntro(on) { if (!on) introOver = true; const host = el.closest('.cl-sd'); if (host) host.classList.toggle('cl-sd-intro', on); }
  setTimeout(() => { setIntro(false); hud[0].hidden = !mons[0]; hud[1].hidden = !mons[1]; }, 20000);
  // a ball pops open: white flash, and they grow into place
  function popOut(side) {
    const a = actor(side); if (!a) return;
    const base = a.baseSize ?? 1;
    a.alpha = 1; a.hitFlash = 1; a.sizeMul = base * 0.15;
    fx.push({ t: 0, life: 0.45, update() { const a2 = actor(side); if (!a2) return; a2.sizeMul = base * lerp(0.15, 1, ease(this.t / this.life)); }, end() { const a2 = actor(side); if (a2) { a2.sizeMul = base; a2.hitFlash = 0; } } });
    burst(chest(side, 0.3), '#ffffff', 16, { speed: 2, shape: 'star', size: 0.1 });
    ring(chest(side, 0.02), '#ffffff', { flat: true, r1: 1.6, life: 0.5 });
  }
  // the wild one's entrance: out of the dark, up close, it cries out and the screen shakes; then yours is
  // sent out (with you behind it) and the battle begins
  function wildReveal(side) {
    if (revealed) return;
    revealed = true;
    const T = tempo();
    cutTo(() => SHOT.front(side, 0.95), { hold: 2.5 * T, drift: 0.1 });
    black.classList.remove('on');
    hud[1].hidden = true;
    setTimeout(() => {
      if (destroyed) return;
      const a = actor(side); if (a) a.hop = 1.2;
      shake = Math.max(shake, 2.2);
      const head = chest(side, 0.85);
      for (let i = 0; i < 3; i++) setTimeout(() => ring(head, '#ffffff', { r0: 0.3, r1: 3.2, life: 0.55, w: 5 }), i * 150);
      el.classList.add('cry'); setTimeout(() => el.classList.remove('cry'), 700);
    }, 1000 * T);
    queueShot(() => (trainerPics[0] ? SHOT.team(0) : SHOT.shoulder(0)), { hold: 1.9 * T, drift: 0.25 });
    setTimeout(() => {
      if (destroyed) return;
      waitingNear = false;
      if (actor(0)) popOut(0);
    }, 2700 * T);
    home(1.4);
    setTimeout(() => { bars.classList.remove('on'); setIntro(false); hud[0].hidden = !mons[0]; hud[1].hidden = !mons[1]; }, 5000 * T);
  }

  function event(ev) {
    if (destroyed) return;
    lastTeam = ev.team ?? lastTeam;
    const m = ev.mon;
    if (m && mons[m.side]) mons[m.side].info = { ...mons[m.side].info, ...m };
    switch (ev.t) {
      case 'animSummon': case 'animDragIn': {
        if (!m) break;
        const a = placeMon(m.side, m);
        if (!a) break;
        summons++;
        renderHud(m.side, m, lastTeam);
        if (!introOver && intro !== 'trainer' && m.side === 1) hud[1].hidden = true;
        const T = tempo();
        if (!started) {
          setIntro(true);
          started = true;
          if (trainers.foe) {
            // a trainer battle: from far out over the whole place, then each trainer with their creature
            intro = 'trainer';
            popOut(m.side);
            black.classList.remove('on');
            cutTo(SHOT.wide, { hold: 1.8 * T, drift: 1.3 });
            queueShot(() => SHOT.team(1), { hold: 2 * T, drift: 0.25 });
            queueShot(() => SHOT.team(0), { hold: 2 * T, drift: 0.25 });
            home(1.4);
            setTimeout(() => { bars.classList.remove('on'); setIntro(false); hud[0].hidden = !mons[0]; hud[1].hidden = !mons[1]; }, 6000 * T);
          } else {
            // a wild battle: it stays dark until the wild one is there
            intro = 'wild';
            if (m.side === 0) { a.alpha = 0; hud[0].hidden = true; waitingNear = true; cutTo(() => SHOT.front(1, 0.95), { hold: 30, drift: 0 }); setTimeout(() => { if (!revealed) wildReveal(1); }, 4000); }
            else wildReveal(m.side);
          }
        } else if (intro === 'wild' && !revealed && m.side === 1) wildReveal(1);
        else {
          popOut(m.side);
          if (dynamic && summons > 2) { cutTo(() => (trainerPics[m.side] ? SHOT.team(m.side) : SHOT.front(m.side, 1.2)), { hold: 1.3 * T, drift: 0.25 }); home(1); }
        }
        if (waitingNear && m.side === 0) hud[0].hidden = true;
        break;
      }
      case 'animUnsummon': case 'animDragOut': {
        if (!m || !actor(m.side)) break;
        const side = m.side, base = actor(side).baseSize ?? 1;
        fx.push({ t: 0, life: 0.4, update() { const a2 = actor(side); if (!a2) return; a2.sizeMul = base * (1 - ease(this.t / this.life) * 0.85); a2.hitFlash = 1; a2.alpha = 1 - ease(this.t / this.life); }, end() { remove(side); } });
        ring(chest(side, 0.4), '#ff6a6a', { r1: 0.8, life: 0.4 });
        break;
      }
      case 'animFaint': {
        if (!m || !actor(m.side)) break;
        const side = m.side, base = actor(side).baseSize ?? 1;
        if (dynamic) { cutTo(() => SHOT.front(side, 1.35), { hold: 1.9 * tempo(), drift: 0.15 }); home(1.2); }
        cast(pick([`${nameOf(side)} is down!`, `${nameOf(side)} can’t go on!`, 'And it’s over for that one!']), { force: true });
        crowdFlash(12);
        vanished[side] = null;
        // a cry, a sag, then down (yours goes back to its ball in a red beam)
        const st = performance.now();
        fx.push({ t: 0, life: 1.5, update() { const a2 = actor(side); if (!a2) return; const k = this.t / this.life;
          if (k < 0.3) { a2.jitter = Math.sin(this.t * 50) * 3; a2.y = 0; }
          else { a2.jitter = 0; const k2 = ease((k - 0.3) / 0.7); a2.sizeMul = base * (1 - k2 * 0.4); a2.y = -k2 * 0.6; a2.alpha = 1 - k2; if (side === 0 && trainerPics[0]) a2.hitFlash = 1; } },
          draw(ctx) { if (side !== 0 || !trainerPics[0] || this.t < 0.45) return; const a = project(chest(0)), tp = trainerAt(0), b = project({ x: tp.x, y: 1.1, z: tp.z }); if (!a || !b) return; ctx.save(); ctx.strokeStyle = 'rgba(255,60,60,.85)'; ctx.lineWidth = 6; ctx.shadowColor = '#ff3a3a'; ctx.shadowBlur = 14; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.restore(); },
          end() { remove(side); } });
        void st;
        for (let i = 0; i < 14; i++) particle({ ...chest(side, 0.05), x: chest(side, 0).x + rnd(-0.8, 0.8), vy: rnd(0.2, 0.8), vx: rnd(-0.5, 0.5), life: 0.9, size: 0.2, col: 'rgba(220,210,190,.8)', shape: 'wisp' });
        renderHud(side, { ...m, pct: 0, fainted: true }, lastTeam);
        break;
      }
      case 'damageAnim': {
        if (!m) break;
        hitFlash(m.side);
        renderHud(m.side, m, lastTeam);
        if (m.pct > 0 && m.pct < 0.25 && !pinched[m.side]) { pinched[m.side] = true; cast(pick([`${nameOf(m.side)} is in a real pinch!`, `${nameOf(m.side)} is hanging on by a thread!`, 'One more hit could do it!']), { force: true }); }
        break;
      }
      case 'healAnim': {
        if (!m) break;
        sparkleOn(m.side, '#9dffb8', 'star', 14); aura(m.side, '#7dffa0');
        renderHud(m.side, m, lastTeam);
        break;
      }
      case 'updateStatbar': case 'animTransform': {
        if (!m) break;
        if (ev.t === 'animTransform' && actor(m.side)) { placeMon(m.side, m); screenFlash('#ffffff', 300); burst(chest(m.side), '#ffffff', 24, { shape: 'star' }); }
        renderHud(m.side, m, lastTeam);
        break;
      }
      case 'incrementTurn': lastTurn = ev.turn ?? lastTurn + 1; break;
      case 'runMoveAnim': playMove(ev); break;
      case 'runPrepareAnim': {
        // the first turn of a two-turn move: flying up, digging down, vanishing, or gathering power
        if (!ev.from) break;
        const side = ev.from.side, how = vanishOf(ev.move), T = tempo();
        announce(side, ev.move);
        if (dynamic && T >= 0.5) { cutTo(() => SHOT.front(side, 1.2), { hold: 1.5 * T, drift: 0.2 }); home(0.8); }
        setTimeout(() => { if (destroyed) return; if (how) vanish(side, how, ev.move.type); else chargeUp(side, ev.move.type); }, 500 * T);
        if (how) cast(pick(how === 'up' ? ['Up, up and away!', 'It’s taken to the skies!'] : how === 'gone' ? ['It’s vanished into thin air!', 'Where did it go?!'] : ['It’s gone underground!', 'It’s hidden itself away!']), { force: true });
        else cast(pick(['It’s gathering power…', 'Something big is coming!']), { force: true });
        break;
      }
      case 'runStatusAnim': {
        if (!m) break;
        const id = ev.id;
        if (id === 'brn') burst(chest(m.side), '#ff7a2a', 10, { shape: 'flame', speed: 1, up: 1.5, g: 1 });
        else if (id === 'par') bolts(m.side, { fromSky: false, from: m.side });
        else if (id === 'psn' || id === 'tox') for (let i = 0; i < 10; i++) particle({ ...chest(m.side), x: chest(m.side).x + rnd(-0.5, 0.5), vy: rnd(0.4, 1), life: 0.8, size: 0.14, col: '#b85ae0', shape: 'bubble' });
        else if (id === 'slp') for (let i = 0; i < 3; i++) particle({ ...chest(m.side, 1), x: chest(m.side, 1).x + i * 0.2, vy: 0.6, vx: 0.3, life: 1.2, size: 0.18, col: '#ffffff', shape: 'zzz' });
        else if (id === 'frz') burst(chest(m.side), '#a8f2ff', 14, { shape: 'shard', speed: 1.2 });
        else if (id === 'confused') sparkleOn(m.side, '#ffe86a', 'star', 8);
        else sparkleOn(m.side, '#ffffff', 'star', 6);
        break;
      }
      case 'resultAnim': {
        if (!m) break;
        const t = decode(ev.text);
        if (!t) break;
        const good = ev.kind === 'good';
        floatText(m.side, t, good ? '#9dffb8' : ev.kind === 'bad' ? '#ff9a9a' : '#ffffff');
        const pctText = /%/.test(t); // damage and healing show as percentages; stat changes don't
        if (!pctText && /[+]\d/.test(t)) aura(m.side, '#ff7a6a', { up: true, n: 14 });
        else if (!pctText && /[-−]\d/.test(t)) aura(m.side, '#6aa0ff', { up: false, n: 14 });
        if (/crit/i.test(t)) { screenFlash('#ffffff', 160); shake = Math.max(shake, 1); }
        if (!pctText && /[+]\d/.test(t)) cast(pick([`${nameOf(m.side)} is powering up!`, `${nameOf(m.side)} is getting fired up!`]));
        if (/miss|avoid/i.test(t)) cast(pick(['It missed! What a dodge!', 'Just out of reach!', 'Not even close!']), { force: true });
        break;
      }
      case 'abilityActivateAnim': if (m) floatText(m.side, `[${decode(ev.text)}]`, '#ffe48a'); break;
      case 'updateWeather': {
        if ((ev.weather || null) !== weatherNow && ev.weather) { const wk = { raindance: 'rain', primordialsea: 'rain', sunnyday: 'sun', desolateland: 'sun', sandstorm: 'dirt', hail: 'snow', snow: 'snow', snowscape: 'snow' }[ev.weather]; if (wk) { lensHit(wk, 18); shake = Math.max(shake, 0.4); } }
        weatherNow = ev.weather || null;
        const w = WEATHER[ev.weather] ?? null;
        yard.setWeather(w ?? 'clear');
        if (ev.weather === 'sunnyday' || ev.weather === 'desolateland') { el.classList.add('sunny'); } else el.classList.remove('sunny');
        el.classList.toggle('sandy', ev.weather === 'sandstorm');
        break;
      }
      case 'message': {
        ev.text = decode(ev.text);
        say(ev.text);
        if (/won the battle|got away safely/i.test(ev.text) && !celebrated) {
          // the end of the match: the winner up close, confetti, the crowd's cameras going off
          celebrated = true;
          const won = !/wild/i.test(ev.text.split(' won')[0]) && !/got away/i.test(ev.text);
          if (won && actor(0)) {
            if (dynamic) { cutTo(() => SHOT.hero(0), { hold: 2.4, drift: 0.3 }); queueShot(() => (trainerPics[0] ? SHOT.team(0) : SHOT.front(0, 1.4)), { hold: 30, drift: 0.2 }); }
            const a0 = actor(0); if (a0) a0.hop = 1;
            for (let i = 0; i < 60; i++) setTimeout(() => particle({ x: rnd(-6, 6), y: 6 + rnd(0, 3), z: 5 + rnd(-6, 6), vx: rnd(-0.5, 0.5), vy: -rnd(1, 2), life: 3, size: 0.12, col: ['#ff5a5a', '#ffd23f', '#4ab8ff', '#7affb0', '#ff8ad0'][i % 5], shape: 'shard', spin: rnd(-8, 8) }), i * 40);
            crowdFlash(30);
            cast(pick(['And that\u2019s the match! What a battle!', 'Victory! The crowd is on its feet!']), { force: true });
          }
        }
        if (/must recharge/i.test(ev.text)) { const sd = /wild|foe|opposing/i.test(ev.text) ? 1 : 0; const top = chest(sd, 1); for (let i = 0; i < 6; i++) setTimeout(() => particle({ ...top, x: top.x + rnd(-0.3, 0.3), vy: rnd(0.5, 1), vx: rnd(-0.6, 0.6), g: -3, life: 0.8, size: 0.16, col: '#9ad8ff', shape: 'drop' }), i * 120); cast(pick(['It needs a breather after that!', 'All that power took it out of it!']), { force: true }); }
        if (/critical hit/i.test(ev.text)) { screenFlash('#ffffff', 160); shake = Math.max(shake, 1); crowdFlash(14); cast(pick(['A critical hit! The crowd goes wild!', 'Right on the weak spot!', 'What a blow!']), { force: true }); }
        if (/super effective/i.test(ev.text)) { shake = Math.max(shake, 0.8); crowdFlash(10); cast(pick(['That’s super effective! What a hit!', 'Oh, that one really hurt!', 'A direct hit! Super effective!']), { force: true }); }
        else if (/not very effective/i.test(ev.text)) cast(pick(['It’s barely scratched!', 'That didn’t do much at all…', 'It’s shrugging that off!']), { force: true });
        else if (/doesn.t affect|no effect|unaffected/i.test(ev.text)) cast(pick(['No effect at all!', 'It went straight through!']), { force: true });
        else if (/was burned|was poisoned|badly poisoned|paralyzed|fell asleep|was frozen|became confused/i.test(ev.text)) cast(pick(['That could change everything!', 'A nasty status for that one!', 'Trouble now!']), { force: true });
        else if (/protected itself/i.test(ev.text)) cast('A perfect block!', { force: true });
        else if (/^turn 1$/i.test(ev.text.trim())) cast('And the battle begins!', { force: true });
        break;
      }
      default: break;
    }
    if (ev.team && ev.t !== 'message') { for (const side of [0, 1]) { const b = hud[side]; if (!b.hidden && mons[side]) b.querySelector('.bst-balls')?.replaceChildren(...(ev.team[side] ?? []).map((t) => h('i', { class: `ball ${!t.seen ? 'unknown' : t.fainted ? 'out' : t.status ? 'st' : ''}` }))); } }
  }

  try { window.__bstEvent = (ev) => event(ev); } catch { /* no window */ }
  yard.start();

  return {
    el,
    init(api) { api.listenTooltips?.(el); setIntro(true); },
    // how much longer Showdown should linger on each kind of moment (only while this stage is on show)
    pace() { if (!el.offsetParent || !dynamic) return null; const T = tempo(); if (T < 0.5) return null; const P = {}; for (const [k, v] of Object.entries(PACE)) P[k] = v * T; P.runMoveAnim += moveExtra * T; if (summons === 1) { P.animSummon = 300 * T; P.animDragIn = 300 * T; } else if (summons === 2) { const k = intro === 'trainer' ? 5200 : 5000; P.animSummon = k * T; P.animDragIn = k * T; } return P; },
    event,
    destroy() { destroyed = true; clearInterval(typing); try { yard.destroy(); } catch { /* gone */ } },
    yard,
  };
}
