// Move effects for Training (and anywhere a move should look like something): which little picture a move
// throws, what colour its sparks are, and whether it's thrown (special) or a hit up close (physical).
// The pictures are Showdown's battle effect sprites (fx/<name>.png), downloaded into the textures folder by
// "Download everything". Without them, every move still works: it falls back to coloured particles for its
// type (a water move with no picture of its own looks like Water Gun).

export const FX_SOURCE = 'https://play.pokemonshowdown.com/fx/{name}.png';
/** Every effect picture the app uses. */
export const FX_NAMES = [
  'waterwisp', 'fireball', 'flareball', 'electroball', 'lightning', 'energyball', 'leaf1', 'leaf2', 'petal', 'iceball', 'icicle',
  'rock1', 'rock2', 'mudwisp', 'poisonwisp', 'shadowball', 'blackwisp', 'mistball', 'wisp', 'feather', 'impact', 'shine',
  'heart', 'moon', 'web', 'bone', 'fist', 'foot', 'sword', 'leftslash', 'rightslash', 'leftclaw', 'topbite', 'bottombite', 'gear', 'caltrop',
];

/** Per type: the picture to use, spark colours, and what kind of trail. */
export const TYPE_FX = {
  normal: { img: 'impact', col: ['#ffffff', '#d8d2c0'], trail: 'spark' },
  fire: { img: 'fireball', col: ['#ff7a2a', '#ffd23f'], trail: 'ember' },
  water: { img: 'waterwisp', col: ['#6ac8ff', '#e0f6ff'], trail: 'drop' },
  electric: { img: 'electroball', col: ['#ffe14a', '#fffbe0'], trail: 'spark' },
  grass: { img: 'leaf1', col: ['#5cbf4a', '#b8f08a'], trail: 'leaf' },
  ice: { img: 'iceball', col: ['#a8ecff', '#ffffff'], trail: 'glint' },
  fighting: { img: 'fist', col: ['#d0583a', '#ffcf9a'], trail: 'spark' },
  poison: { img: 'poisonwisp', col: ['#a34fd0', '#e0a8ff'], trail: 'bubble' },
  ground: { img: 'mudwisp', col: ['#b8894a', '#e8c890'], trail: 'pebble' },
  flying: { img: 'feather', col: ['#c8d8ff', '#ffffff'], trail: 'gust' },
  psychic: { img: 'mistball', col: ['#ff6aa8', '#ffd0e8'], trail: 'ring' },
  bug: { img: 'web', col: ['#a8c030', '#e0f070'], trail: 'mote' },
  rock: { img: 'rock1', col: ['#b8a070', '#e0d0a8'], trail: 'pebble' },
  ghost: { img: 'shadowball', col: ['#6a4fb0', '#c0a8ff'], trail: 'wisp' },
  dragon: { img: 'flareball', col: ['#6a5cff', '#c8c0ff'], trail: 'scale' },
  dark: { img: 'blackwisp', col: ['#3a3048', '#a090c0'], trail: 'wisp' },
  steel: { img: 'gear', col: ['#b8c0d0', '#ffffff'], trail: 'glint' },
  fairy: { img: 'heart', col: ['#ff9ad0', '#fff0f8'], trail: 'glitter' },
};
// the starter set's own type names
const ALIAS = { sprout: 'grass', ember: 'fire', tide: 'water', spark: 'electric', volt: 'electric', frost: 'ice', spirit: 'ghost', stone: 'rock', gale: 'flying', shade: 'dark', mind: 'psychic', metal: 'steel', wild: 'normal', plain: 'normal', brawl: 'fighting', wyrm: 'dragon', insect: 'bug' };
export function fxType(idx, t) {
  const k = String(t ?? '').toLowerCase(), n = String(idx?.types?.get?.(t)?.name ?? '').toLowerCase();
  return TYPE_FX[k] ? k : TYPE_FX[n] ? n : ALIAS[k] ?? ALIAS[n] ?? 'normal';
}

// moves whose names say what they look like
const BY_NAME = [
  [/punch|fist|hammer arm|mach|uppercut|jab/, 'fist', 'hit'], [/kick|stomp|foot|hi jump|jump kick/, 'foot', 'hit'],
  [/slash|cut|blade|claw|scratch|fury swipes|x-scissor|night slash|leaf blade|psycho cut/, 'leftslash', 'hit'],
  [/bite|fang|crunch|jaw/, 'topbite', 'hit'], [/sword|smart strike|sacred sword/, 'sword', 'hit'], [/bone/, 'bone', 'throw'],
  [/thunder|bolt|shock|spark|discharge|zap/, 'lightning', 'bolt'], [/petal|blossom|flower/, 'petal', 'throw'],
  [/leaf|razor leaf|magical leaf|seed/, 'leaf1', 'throw'], [/icicle|ice shard|ice spinner/, 'icicle', 'throw'],
  [/rock|stone|boulder|meteor|smack down/, 'rock1', 'throw'], [/mud|sand|earth|dig|bulldoze/, 'mudwisp', 'throw'],
  [/shadow ball|shadow/, 'shadowball', 'throw'], [/moon|lunar/, 'moon', 'throw'], [/charm|sweet kiss|draining kiss|heart/, 'heart', 'throw'],
  [/web|string/, 'web', 'throw'], [/gear|gyro|flash cannon/, 'gear', 'throw'], [/spike|caltrop/, 'caltrop', 'throw'],
  [/gun|pump|hydro|surf|bubble|water pulse|scald|aqua/, 'waterwisp', 'beam'], [/beam|ray|cannon|blast|pulse/, null, 'beam'],
  [/ember|flame|fire|flare|blaze|heat|inferno/, 'fireball', 'throw'], [/tackle|slam|body|headbutt|ram|rush|charge|take down|double-edge|quick attack|extreme speed|strike|smash|crash/, 'impact', 'hit'],
];

/**
 * How a move looks: { type, img, col: [a, b], trail, how: 'throw' | 'beam' | 'bolt' | 'hit' | 'buff', power, category }
 * mv: a move from the data set.
 */
export function moveFx(idx, mv) {
  const type = fxType(idx, mv?.type);
  const base = TYPE_FX[type];
  const name = String(mv?.name ?? '').toLowerCase();
  const cat = mv?.category ?? 'physical';
  let img = base.img, how = cat === 'status' ? 'buff' : cat === 'special' ? 'throw' : 'hit';
  if (cat !== 'status') for (const [re, im, h2] of BY_NAME) if (re.test(name)) { if (im) img = im; how = h2 === 'hit' && cat === 'special' ? 'throw' : h2; break; }
  return { type, img, col: base.col, trail: base.trail, how, power: Number(mv?.power) || 0, category: cat };
}

/** The effect picture (an Image once loaded), or null: falls back to particles. resolve(path) → url. */
const cache = new Map();
export function fxImage(resolve, name) {
  if (!name) return null;
  const url = resolve?.(`fx/${name}.png`);
  if (!url) return null;
  let rec = cache.get(url);
  if (!rec) { const img = new Image(); rec = { img, ok: false }; img.onload = () => { rec.ok = true; }; img.src = url; cache.set(url, rec); }
  return rec.ok ? rec.img : null;
}
