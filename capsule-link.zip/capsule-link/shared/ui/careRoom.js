// Quality time: one creature, up close, in a small corner of its R.A.N.C.H. environment (the same
// 3D scene as the yard, closer in). Pick a tool and rub it over them: wash with the sponge, dry with
// the towel and the dryer, brush and comb, or just pet with your hand (and pick them up).
// Hold food in front of their mouth to feed it bite by bite, wave a toy to play, or throw a toy or
// a berry: they run after it and bring it back to you.
// Everyone has a favourite berry and toy (engine: favorites) and lights up when they get them.
import { h, mount } from './dom.js';
import { itemIcon, itemPicture } from './itemIcon.js';
import { Yard, toyKindOf, EXTRA_TOYS } from './yard.js';
import { sfx, creatureCry } from './audio.js';
import * as Paint from './paint.js';
import { displayName, speciesOf, favorites, CARE_TOYS, mood, avoidsWater, journalOf, allFoods } from '../engine/index.js';
import { actorFor } from './actor.js';

const TOOLS = [
  ['hand', 'Hand', 'Rub to pet · drag them to pick them up'],
  ['sponge', 'Wash', 'Scrub them clean'],
  ['towel', 'Towel', 'Rub them dry'],
  ['dryer', 'Dryer', 'Blow-dry the last of the damp'],
  ['brush', 'Brush', 'Brush their coat'],
  ['comb', 'Comb', 'Comb out the tangles'],
];

/**
 * Shared by the PC (R.A.N.C.H.) and the phone (creatures with you).
 * app: { idx, bank, save }; uid: the creature; doCare(action, opts) applies care and returns its result.
 * resolveTexture(path) → url of your own art; clothesImg(idx, id) → a clothing picture (optional).
 * Returns a promise that resolves when the room is closed.
 */
export function openCareRoom(app, uid, { biome = 'meadow', seed = 1, doCare, resolveTexture = () => null, clothesImg = null }) {
  return new Promise((resolve) => {
    const c = () => app.save.creatures[uid];
    if (!c()) { resolve(); return; }
    const fav = favorites(app.idx, c());
    // fire-natured creatures: no water, just brushing and combing
    const dryOnly = avoidsWater(app.idx, c());
    const tools = TOOLS.filter(([id]) => !(dryOnly && ['sponge', 'towel', 'dryer'].includes(id)));
    const toys = [...CARE_TOYS, ...EXTRA_TOYS, ...app.idx.ds.items.filter((i) => i.kind === 'toy' && (i.unlimited || (app.save.inventory[i.id] ?? 0) > 0))];
    const foods = () => allFoods(app.idx).filter((i) => i.unlimited || (app.save.inventory[i.id] ?? 0) > 0);
    const st = {
      tool: 'hand', held: null, // held: { kind: 'toy'|'food', item }
      // dirt spots from how grubby they are; wet after a wash
      dirt: Math.max(0, Math.round((100 - (c().needs?.hygiene ?? 90)) / 12)), wet: 0, stroke: 0, play: 0,
      fx: [], words: [], cursor: null, down: false, t: 0,
    };
    const spots = Array.from({ length: 8 }, (_, i) => ({ fx: 0.25 + ((i * 37) % 50) / 100, fy: 0.3 + ((i * 53) % 55) / 100, r: 3 + (i % 3) }));

    const canvas = h('canvas', { class: 'care-canvas', tabindex: '0', 'aria-label': `Quality time with ${displayName(app.idx, c())}` });
    const status = h('div', { class: 'care-status' });
    const bar = h('div', { class: 'care-tools' });
    const root = h('div', { class: 'care-room' }, h('div', { class: 'care-title' }, 'Quality time'), canvas, status, bar);
    document.body.append(root);
    sfx('warp');

    const yard = new Yard(canvas, {
      bank: app.bank, scene: 'room', biome, seed,
      resolveTexture,
      sizeScale: app.save.settings?.ranchScale ?? 1,
      onPet: () => { const now = performance.now(); if (now - (st.lastPet ?? 0) < 300) return; st.lastPet = now; const out = care('pet'); if (out?.ok) { sfx('heart'); yard.react(uid, 'hearts', 2); } },
      onDrop: (u, speed) => { if (speed > 4) { yard.react(uid, 'dizzy', 2); sfx('miss'); } else yard.react(uid, 'sparkle', 2); },
      onEat: (u, item) => { if (!item?.id) return; sfx('munch'); const out = care('feed', { item: item.id, favorite: item.id === fav.berry }); if (out?.ok) yard.react(uid, out.reaction === 'delighted' ? 'hearts' : out.reaction === 'full' ? 'sad' : 'munch', 3); renderTools(); },
      onPlay: (u, kind, item) => { const id = item?.id ?? kind; const out = care('play', { toy: id, toyName: item?.name, favorite: id === fav.toy, fetch: true }); if (out?.ok && out.reaction !== 'tired') burst('note', 3); },
      overlay: (ctx) => drawOverlay(ctx),
    });
    yard.setCreatures([actorFor(app.idx, c(), { clothesImg })]);
    yard.materialize();
    yard.start();
    const actor = () => yard.actors.get(uid);
    const box = () => yard.actorBox(uid);

    function say(text, color = '#ffffff') { const b = box(); st.words.push({ text, x: b ? (b.x0 + b.x1) / 2 : yard.W / 2, y: b ? b.y0 - 14 : 60, life: 1.8, color }); }
    function burst(kind, n = 4, at = null) {
      const b = box(); if (!b && !at) return;
      const x = at?.x ?? (b.x0 + b.x1) / 2, y = at?.y ?? b.y0 + 10;
      for (let i = 0; i < n; i++) st.fx.push({ kind, x: x + (Math.random() - 0.5) * 20, y: y + (Math.random() - 0.5) * 12, vx: (Math.random() - 0.5) * 40, vy: kind === 'drip' ? 30 : -30 - Math.random() * 30, life: 1 + Math.random() * 0.6 });
    }
    function care(action, opts = {}) {
      const out = doCare(action, opts);
      renderStatus();
      if (!out?.ok) return out;
      if (out.reaction === 'delighted') { say('♥ Favourite!', '#ff8fb8'); burst('heart', 6); creatureCry(speciesOf(app.idx, c()), c(), { mood: 'happy' }); }
      else if (out.reaction === 'full') say('Full…', '#cde');
      else if (out.reaction === 'tired') say('Too tired…', '#cde');
      else if (out.reaction === 'annoyed') { say('Had enough!', '#ff9a9a'); yard.emote(uid, 'angry', false); creatureCry(speciesOf(app.idx, c()), c(), { mood: 'upset' }); }
      else if (out.reaction === 'awake') say('Not sleepy', '#cde');
      else if (out.reaction === 'meh') say('Getting a bit much…', '#cde');
      return out;
    }
    const over = (p, b = box()) => b && p && p.x > b.x0 - 6 && p.x < b.x1 + 6 && p.y > b.y0 - 6 && p.y < b.y1 + 4;
    const mouth = (b = box()) => { const a = actor(); return { x: (b.x0 + b.x1) / 2 + (a?.flip ? -1 : 1) * (b.x1 - b.x0) * 0.25, y: b.y0 + (b.y1 - b.y0) * 0.38 }; };

    // ---------- tools ----------
    function useTool(p, dist) {
      if (!over(p)) return;
      st.stroke += dist;
      const tool = st.tool;
      if (tool === 'sponge') {
        if (Math.random() < 0.5) burst('bubble', 1, p);
        if (st.stroke > 160) { st.stroke = 0; st.dirt = Math.max(0, st.dirt - 1); st.wet = 1; sfx('blip'); if (st.dirt === 0 && !st.washed) { st.washed = true; care('wash'); say('Squeaky clean!'); } }
        return;
      }
      if (tool === 'towel') {
        if (!st.wet) { if (st.stroke > 220) { st.stroke = 0; say('Already dry'); } return; }
        if (st.stroke > 140) { st.stroke = 0; const was = st.wet; st.wet = Math.max(0.3, st.wet - 0.35); if (st.wet <= 0.3 && was > 0.3) { care('towel'); say('Nearly dry — try the dryer'); } }
        return;
      }
      if (tool === 'dryer') {
        burst('air', 1, { x: p.x - 16, y: p.y });
        if (!st.wet) return;
        if (st.stroke > 180) { st.stroke = 0; st.wet = Math.max(0, st.wet - 0.2); if (st.wet <= 0) { st.washed = false; care('dry'); say('Fluffy!'); burst('sparkle', 5); } }
        return;
      }
      if (tool === 'brush' || tool === 'comb') {
        if (st.wet > 0.3) { if (st.stroke > 220) { st.stroke = 0; say('Dry them first'); } return; }
        if (Math.random() < 0.3) burst('sparkle', 1, p);
        if (st.stroke > 200) {
          st.stroke = 0; sfx('heal');
          // no bath for these ones: the brush and the comb get the dirt out
          if (dryOnly && st.dirt > 0) { st.dirt--; burst('dust', 2, p); if (st.dirt === 0) say('All clean, no water needed!'); }
          care(tool); yard.react(uid, 'sparkle', 2);
        }
      }
    }

    // ---------- every frame (drawn on top of the scene) ----------
    function drawOverlay(ctx) {
      const dt = 1 / 45;
      st.t += dt;
      const a = actor(), b = box();
      if (b && a) {
        if (st.wet > 0 && Math.random() < dt * 4 * st.wet) burst('drip', 1, { x: b.x0 + Math.random() * (b.x1 - b.x0), y: b.y0 + (b.y1 - b.y0) * 0.6 });
        // holding food in front of their mouth: bite by bite
        if (st.held?.kind === 'food' && st.cursor && a.state !== 'chase' && a.state !== 'return') {
          const near = st.cursor.x > b.x0 - 30 && st.cursor.x < b.x1 + 30 && st.cursor.y > b.y0 - 36 && st.cursor.y < b.y0 + (b.y1 - b.y0) * 0.65;
          a.flip = st.cursor.x < (b.x0 + b.x1) / 2;
          if (near) {
            st.feedT = (st.feedT ?? 0) + dt;
            if (st.feedT > 0.6) {
              st.feedT = 0; st.held.bites = (st.held.bites ?? 0) + 1; sfx('munch'); const m = mouth(b); burst('crumb', 2, m);
              if (st.held.bites >= 3) { const it = st.held.item; st.held = null; const out = care('feed', { item: it.id, favorite: it.id === fav.berry }); if (out?.ok) yard.react(uid, out.reaction === 'delighted' ? 'hearts' : 'munch', 3); renderTools(); }
            }
          }
        }
        // waving a toy: they follow it about and bat at it
        if (st.held?.kind === 'toy' && st.cursor && a.state !== 'held' && a.state !== 'falling') {
          const fp = yard.floorAt(st.cursor.x, Math.min(yard.H - 1, st.cursor.y + 60));
          if (fp) { a.tx = yard.clampX(fp.x); a.tz = yard.clampZ(fp.z); if (Math.hypot(a.tx - a.x, a.tz - a.z) > 0.5) { a.state = 'walk'; a.timer = 2; } }
          if (Math.abs(st.cursor.x - (b.x0 + b.x1) / 2) < (b.x1 - b.x0) && st.cursor.y > b.y0 - 40) {
            st.play += dt;
            if (Math.random() < dt * 3) a.hop = 0.8;
            if (st.play > 2.5) { st.play = 0; const it = st.held.item; const out = care('play', { toy: it.id, toyName: it.name, favorite: it.id === fav.toy }); if (out?.ok) burst('note', 2); }
          }
        }
        // dirt and damp on their coat
        const hop = 0;
        for (let i = 0; i < st.dirt; i++) {
          const s = spots[i % spots.length];
          ctx.fillStyle = 'rgba(96,70,40,.55)';
          ctx.beginPath(); ctx.arc(b.x0 + s.fx * (b.x1 - b.x0), b.y0 + s.fy * (b.y1 - b.y0) - hop, s.r * Math.max(1, (b.x1 - b.x0) / 80), 0, Math.PI * 2); ctx.fill();
        }
        if (st.wet > 0) {
          ctx.fillStyle = `rgba(190,225,255,${(0.9 * st.wet).toFixed(3)})`;
          for (let i = 0; i < 12; i++) { const s = spots[i % spots.length]; ctx.fillRect(Math.round(b.x0 + ((s.fx + i * 0.07) % 1) * (b.x1 - b.x0)), Math.round(b.y0 + ((s.fy + i * 0.11) % 0.9) * (b.y1 - b.y0)), 3, 4); }
        }
      }
      for (const f of st.fx) { f.life -= dt; f.x += f.vx * dt; f.y += f.vy * dt; if (f.kind === 'drip') f.vy += 300 * dt; }
      st.fx = st.fx.filter((f) => f.life > 0 && f.y < yard.H);
      for (const w of st.words) { w.life -= dt; w.y -= 14 * dt; }
      st.words = st.words.filter((w) => w.life > 0);
      for (const fx of st.fx) {
        ctx.globalAlpha = Math.min(1, fx.life);
        if (fx.kind === 'bubble') { ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(fx.x, fx.y, 6, 0, Math.PI * 2); ctx.stroke(); }
        else if (fx.kind === 'drip') { ctx.fillStyle = '#7fb8ff'; ctx.fillRect(fx.x, fx.y, 3, 6); }
        else if (fx.kind === 'air') { ctx.fillStyle = 'rgba(255,255,255,.6)'; ctx.fillRect(fx.x, fx.y, 12, 2); }
        else if (fx.kind === 'crumb') { ctx.fillStyle = '#c98a3a'; ctx.fillRect(fx.x, fx.y, 3, 3); }
        else if (fx.kind === 'dust') { ctx.fillStyle = 'rgba(150,120,80,.7)'; ctx.fillRect(fx.x, fx.y, 4, 4); }
        else { ctx.fillStyle = fx.kind === 'heart' ? '#ff5d8f' : fx.kind === 'note' ? '#ffffff' : '#fff6a0'; ctx.font = '18px sans-serif'; ctx.fillText(fx.kind === 'heart' ? '♥' : fx.kind === 'note' ? '♪' : '✦', fx.x, fx.y); }
      }
      ctx.globalAlpha = 1;
      for (const w of st.words) {
        ctx.globalAlpha = Math.min(1, w.life);
        ctx.font = 'bold 18px "Segoe UI", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
        ctx.fillStyle = 'rgba(10,8,30,.6)'; ctx.fillText(w.text, w.x + 1, w.y + 1);
        ctx.fillStyle = w.color; ctx.fillText(w.text, w.x, w.y);
        ctx.textAlign = 'start';
      }
      ctx.globalAlpha = 1;
      // what you're holding, at the pointer
      if (st.cursor && st.held) {
        if (st.held.kind === 'food') { const left = 1 - (st.held.bites ?? 0) / 3, sz = Math.max(10, 34 * left); ctx.imageSmoothingEnabled = false; ctx.drawImage(itemPicture(st.held.item), Math.round(st.cursor.x - sz / 2), Math.round(st.cursor.y - sz / 2), sz, sz); }
        else { const img = Paint.toy(toyKindOf(st.held.item), { w: 40, h: 40 }); const wob = Math.sin(st.t * 10) * 3; ctx.drawImage(img, Math.round(st.cursor.x - 20 + wob), Math.round(st.cursor.y - 20), 40, 40); }
      } else if (st.cursor && st.tool !== 'hand') toolShape(ctx, st.cursor.x, st.cursor.y, st.tool);
    }
    function berryShape(ctx, x, y, color, left = 1) {
      const r = Math.max(3, 11 * left);
      ctx.fillStyle = color || '#c0306a'; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#3f7a35'; ctx.fillRect(x - 2, y - r - 6, 4, 6);
    }
    function toolShape(ctx, x, y, tool) {
      ctx.save(); ctx.translate(x, y); ctx.scale(1.6, 1.6);
      if (tool === 'sponge') { ctx.fillStyle = '#ffd23f'; ctx.fillRect(-9, -6, 18, 12); ctx.fillStyle = '#e6b800'; ctx.fillRect(-6, -3, 2, 2); ctx.fillRect(2, 1, 2, 2); }
      else if (tool === 'towel') { ctx.fillStyle = '#7fc8ff'; ctx.fillRect(-11, -7, 22, 14); ctx.fillStyle = '#ffffff'; ctx.fillRect(-11, 3, 22, 2); }
      else if (tool === 'dryer') { ctx.fillStyle = '#e9e9f2'; ctx.fillRect(-4, -6, 16, 9); ctx.fillStyle = '#9a9ab0'; ctx.fillRect(4, 3, 4, 10); ctx.fillStyle = '#5b5b70'; ctx.fillRect(-6, -5, 2, 7); }
      else if (tool === 'brush') { ctx.fillStyle = '#a0623a'; ctx.fillRect(-10, -4, 20, 6); ctx.fillStyle = '#f4e3c3'; for (let i = -9; i < 10; i += 3) ctx.fillRect(i, 2, 1, 5); }
      else if (tool === 'comb') { ctx.fillStyle = '#b58cff'; ctx.fillRect(-10, -4, 20, 4); for (let i = -9; i < 10; i += 2) ctx.fillRect(i, 0, 1, 6); }
      ctx.restore();
    }

    // ---------- pointer (tools and held things; the bare hand is the yard's own pet and pick-up) ----------
    const lockFor = () => { yard.inputLocked = st.tool !== 'hand' || !!st.held; canvas.style.cursor = yard.inputLocked ? 'none' : ''; };
    canvas.addEventListener('pointermove', (ev) => {
      const p = yard.toBuf(ev), prev = st.cursor;
      st.cursor = p;
      if (st.down && prev && yard.inputLocked && !st.held) useTool(p, Math.hypot(p.x - prev.x, p.y - prev.y));
    });
    canvas.addEventListener('pointerdown', (ev) => { st.down = true; st.cursor = yard.toBuf(ev); });
    // double-click while holding a toy or some food: throw it where you clicked
    canvas.addEventListener('dblclick', (ev) => {
      if (!st.held) return;
      const p = yard.toBuf(ev);
      const at = yard.floorAt(p.x, Math.min(yard.H - 1, p.y + 30));
      const it = st.held.item, kind = st.held.kind;
      st.held = null; lockFor();
      if (kind === 'food') yard.throwToy('berry', it, at); else yard.throwToy(toyKindOf(it), it, at);
      sfx('blip'); renderTools();
    });
    const up = () => { st.down = false; };
    canvas.addEventListener('pointerup', up);
    canvas.addEventListener('pointercancel', up);
    canvas.addEventListener('pointerleave', () => { st.cursor = null; st.down = false; });

    // ---------- the bars ----------
    function renderStatus() {
      const cr = c();
      const n = cr.needs ?? {};
      const known = (k) => cr.firsts?.[`fav:${k}`];
      const favBerry = fav.berry && app.idx.items.get(fav.berry);
      const favToy = toys.find((t) => t.id === fav.toy);
      mount(status,
        h('strong', null, displayName(app.idx, cr)),
        h('span', null, mood(cr).label),
        ['fullness', 'joy', 'hygiene', 'energy'].map((k) => h('span', { class: 'care-need' }, `${{ fullness: 'Full', joy: 'Joy', hygiene: 'Clean', energy: 'Energy' }[k]} ${Math.round(n[k] ?? 0)}`)),
        h('button', { class: `care-btn small ${journalOpen ? 'on' : ''}`, title: 'Their likes, dislikes and favourites', onclick: () => { journalOpen = !journalOpen; renderStatus(); renderJournal(); } }, journalOpen ? 'Close journal' : 'Journal'));
    }
    // ---------- the journal: a little field notebook about them ----------
    let journalOpen = false;
    const journalEl = h('aside', { class: 'care-journal', hidden: true });
    root.append(journalEl);
    function renderJournal() {
      journalEl.hidden = !journalOpen;
      if (!journalOpen) return;
      const j = journalOf(app.idx, app.save, c());
      mount(journalEl,
        h('div', { class: 'cj-head' }, h('strong', null, j.name), h('span', null, `${j.temper} · ${j.moodLabel}`)),
        h('p', { class: 'cj-style' }, j.style),
        h('div', { class: 'cj-section' }, 'Favourites'),
        h('dl', { class: 'cj-favs' }, j.favourites.map((f) => [h('dt', null, f.label), h('dd', { class: f.value === '???' ? 'dim' : '' }, f.value)])),
        h('div', { class: 'cj-section' }, 'Likes'),
        Object.keys(j.likes).length ? Object.entries(j.likes).map(([head, list]) => h('p', { class: 'cj-line' }, h('b', null, `${head}: `), list.join(', '))) : h('p', { class: 'cj-line dim' }, 'Nothing yet. Spend time together and you’ll find out.'),
        h('div', { class: 'cj-section' }, 'Dislikes'),
        h('p', { class: `cj-line ${j.dislikes.length ? '' : 'dim'}` }, j.dislikes.length ? j.dislikes.join(', ') : 'Nothing so far.'),
        j.friends.length ? [h('div', { class: 'cj-section' }, 'Friends'), h('p', { class: 'cj-line' }, j.friends.join(', '))] : null,
        j.notes.length ? [h('div', { class: 'cj-section' }, 'Notes'), j.notes.map((n) => h('p', { class: 'cj-line' }, `• ${n}`))] : null);
    }
    function renderTools() {
      const pick = (kind, item) => { st.held = st.held?.item?.id === item.id ? null : { kind, item }; st.tool = 'hand'; lockFor(); renderTools(); };
      // click: take it in your hand (or pick it back up once thrown); double-click on the scene while holding it throws it
      const thrownOf = (it) => yard.toys.find((x) => x.item?.id === it.id && !x.carriedBy);
      const itemBtn = (kind, it, label) => h('button', {
        class: `care-btn small ${st.held?.item?.id === it.id ? 'on' : ''} ${thrownOf(it) ? 'thrown' : ''}`,
        title: thrownOf(it) ? 'Click to pick it back up' : 'Click to take it in your hand',
        onclick: () => {
          const t = thrownOf(it);
          if (t) { yard.toys = yard.toys.filter((x) => x !== t); for (const a of yard.actors.values()) if (a.toy === t) { a.state = 'idle'; a.timer = 1; a.toy = null; } sfx('back'); renderTools(); return; }
          pick(kind, it);
        },
      }, kind === 'food' ? itemIcon(it, 20) : null, label);
      mount(bar,
        h('div', { class: 'care-row' },
          tools.map(([id, label, hint]) => h('button', { class: `care-btn ${st.tool === id && !st.held ? 'on' : ''}`, title: hint, onclick: () => { st.tool = id; st.held = null; lockFor(); renderTools(); } }, label)),
          h('span', { class: 'spacer' }),
          h('button', { class: 'care-btn', title: 'Zoom in', onclick: () => yard.zoom(-1) }, '+'),
          h('button', { class: 'care-btn', title: 'Zoom out', onclick: () => yard.zoom(1) }, '−'),
          h('button', { class: 'care-btn', onclick: close }, 'Back to the yard')),
        h('div', { class: 'care-row' },
          h('span', { class: 'care-label' }, 'Toys'),
          toys.map((t) => itemBtn('toy', t, t.name))),
        h('div', { class: 'care-row' },
          h('span', { class: 'care-label' }, 'Food'),
          foods().length ? foods().slice(0, 10).map((it) => itemBtn('food', it, `${it.name}${it.unlimited ? '' : ` ×${app.save.inventory[it.id] ?? 0}`}`)) : h('span', { class: 'care-label' }, 'No food. Grow berries on the farm.')),
        h('div', { class: 'care-hint' }, st.held ? (st.held.kind === 'food' ? 'Hold the food in front of their mouth · double-click to toss it' : 'Wave the toy near them · double-click to throw it') : `${TOOLS.find((t) => t[0] === st.tool)?.[2]}${dryOnly ? ' · no baths for this one: brush and comb it clean' : ''}`));
    }
    function close() {
      yard.destroy();
      root.remove(); window.removeEventListener('keydown', onKey);
      sfx('back');
      resolve();
    }
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    window.addEventListener('keydown', onKey);
    renderStatus(); renderTools(); lockFor();
    if (st.dirt >= 3) setTimeout(() => say('A bit grubby… time for a wash?', '#f4e3c3'), 900);
    creatureCry(speciesOf(app.idx, c()), c());
  });
}
