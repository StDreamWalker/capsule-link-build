// A picture for any item, everywhere items show (Market, bag, R.A.N.C.H. food menu, care room, cooking):
// the downloaded sprite (textures/items/<id>.png, from "Download everything") when there is one, and
// otherwise hand-drawn pixel art that looks like the thing: a berry with its leaf, a root, a bowl of
// stew, a TM disc in its move's type colour, a gem, a pearl, a held item's bag…
import { shadeHex } from './habitat.js';

const cache = new Map();
let resolver = () => null;
/** Where downloaded item sprites come from: resolve('items/oran-berry.png') → url (set once by each app). */
export function setItemArt(resolve) { resolver = resolve ?? (() => null); cache.clear(); }

const imgCache = new Map();
function loaded(url) {
  let r = imgCache.get(url);
  if (!r) { const img = new Image(); r = { img, ok: false, wait: [] }; img.onload = () => { r.ok = true; for (const f of r.wait) f(); r.wait = []; }; img.src = url; imgCache.set(url, r); }
  return r;
}

/**
 * A canvas with the item's picture, `size` px square (pixel-crisp). A downloaded sprite replaces the drawn
 * one as soon as it has loaded. it: an item record ({ id, kind, color, name, move… }).
 */
export function itemIcon(it, size = 32, { idx = null } = {}) {
  const cv = document.createElement('canvas');
  cv.width = size; cv.height = size; cv.className = 'item-icon';
  const x = cv.getContext('2d'); x.imageSmoothingEnabled = false;
  const url = it?.id ? resolver(`items/${String(it.id).toLowerCase()}.png`) : null;
  const drawn = () => { const a = drawnArt(it, idx); x.drawImage(a, 0, 0, size, size); };
  if (url) {
    const r = loaded(url);
    const put = () => { x.clearRect(0, 0, size, size); const k = Math.max(1, Math.floor(size / Math.max(r.img.width, r.img.height))); const w = r.img.width * k, hh = r.img.height * k; x.drawImage(r.img, Math.round((size - w) / 2), Math.round((size - hh) / 2), w, hh); };
    if (r.ok) put(); else { drawn(); r.wait.push(put); }
  } else drawn();
  return cv;
}

/** The item's picture to draw in a scene (the downloaded sprite once loaded, else the drawn one). */
export function itemPicture(it, idx = null) {
  const url = it?.id ? resolver(`items/${String(it.id).toLowerCase()}.png`) : null;
  if (url) { const r = loaded(url); if (r.ok) return r.img; }
  return drawnArt(it, idx);
}

/** The drawn picture: a 24×24 canvas, cached. */
export function drawnArt(it, idx = null) {
  const key = `${it?.kind}:${it?.id}:${it?.color}`;
  if (cache.has(key)) return cache.get(key);
  const c = document.createElement('canvas'); c.width = 24; c.height = 24;
  const x = c.getContext('2d');
  const px = (X, Y, w, h, col) => { x.fillStyle = col; x.fillRect(X, Y, w, h); };
  const disc = (cx, cy, r, col) => { for (let yy = -r; yy <= r; yy++) { const half = Math.round(Math.sqrt(Math.max(0, r * r - yy * yy))); px(cx - half, cy + yy, half * 2 + 1, 1, col); } };
  const outline = () => {
    // a 1 px dark outline round whatever was drawn, like game item sprites
    const d = x.getImageData(0, 0, 24, 24), o = x.createImageData(24, 24);
    for (let yy = 0; yy < 24; yy++) for (let xx = 0; xx < 24; xx++) {
      const i = (yy * 24 + xx) * 4;
      if (d.data[i + 3] > 40) continue;
      const near = [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([a, b]) => { const X2 = xx + a, Y2 = yy + b; return X2 >= 0 && Y2 >= 0 && X2 < 24 && Y2 < 24 && d.data[(Y2 * 24 + X2) * 4 + 3] > 40; });
      if (near) { o.data[i] = 30; o.data[i + 1] = 24; o.data[i + 2] = 40; o.data[i + 3] = 255; }
    }
    const t = document.createElement('canvas'); t.width = 24; t.height = 24; t.getContext('2d').putImageData(o, 0, 0);
    x.drawImage(t, 0, 0);
  };
  const id = String(it?.id ?? ''), name = String(it?.name ?? '').toLowerCase(), col = it?.color ?? '#c98a3a';
  const kind = it?.kind ?? '';
  if (kind === 'tm' || id.startsWith('tm-')) {
    const tcol = (idx?.types?.get?.(idx?.moves?.get?.(it.move)?.type)?.color) ?? it.color ?? '#9aa6b8';
    disc(12, 12, 9, shadeHex(tcol, -0.15)); disc(12, 12, 7, tcol); disc(12, 12, 2, '#ffffff'); px(8, 7, 3, 2, 'rgba(255,255,255,.6)');
  } else if (kind === 'food' && id.startsWith('dish-')) {
    // a bowl with the dish in it
    disc(12, 12, 6, col); px(6, 9, 12, 3, shadeHex(col, 0.2)); px(9, 8, 3, 2, 'rgba(255,255,255,.55)');
    for (let i = 0; i < 6; i++) px(3 + i, 14 + Math.floor(i / 3), 18 - i * 2, 1, i < 2 ? '#e8e2f2' : '#c8c0d8');
    px(4, 13, 16, 2, '#ffffff'); px(8, 19, 8, 2, '#a8a0b8');
  } else if (kind === 'food' && /root|carrot|radish|tuber|yam/.test(name)) {
    for (let i = 0; i < 12; i++) px(8 + Math.round(i / 3), 8 + i, 7 - Math.round(i / 2), 1, i < 2 ? shadeHex(col, 0.15) : col);
    px(9, 3, 2, 5, '#4f9a3f'); px(12, 2, 2, 6, '#5cbf4a'); px(14, 4, 2, 4, '#4f9a3f'); px(10, 10, 2, 2, 'rgba(255,255,255,.5)');
  } else if (kind === 'food') {
    // a berry: round, shaded, with a leaf and a stalk
    disc(12, 14, 7, shadeHex(col, -0.25)); disc(11, 13, 6, col); disc(9, 11, 2, shadeHex(col, 0.35)); px(8, 10, 2, 2, '#ffffff');
    px(12, 4, 2, 4, '#6a4a2a'); px(14, 3, 5, 3, '#5cbf4a'); px(15, 2, 3, 1, '#8ae06a');
  } else if (kind === 'valuable') {
    if (/pearl|stardust|orb|ball/.test(name + id)) { disc(12, 12, 7, col ?? '#f0e8ff'); disc(10, 10, 3, '#ffffff'); }
    else { const g = col ?? '#7ad6ff'; for (let i = 0; i < 8; i++) px(12 - i, 6 + i, i * 2 + 1, 1, shadeHex(g, 0.2 - i * 0.04)); for (let i = 0; i < 6; i++) px(5 + i, 14 + i, 14 - i * 2, 1, shadeHex(g, -0.2)); px(10, 8, 2, 3, '#ffffff'); }
  } else if (kind === 'incense') {
    px(8, 10, 8, 10, col ?? '#c8a2ff'); px(7, 9, 10, 2, shadeHex(col ?? '#c8a2ff', -0.25)); px(10, 12, 2, 5, 'rgba(255,255,255,.5)');
    px(11, 3, 2, 2, 'rgba(220,220,240,.8)'); px(12, 6, 2, 2, 'rgba(220,220,240,.7)'); px(10, 1, 2, 2, 'rgba(220,220,240,.5)');
  } else if (kind === 'groom') {
    px(3, 15, 12, 4, '#8a5a34'); px(14, 13, 8, 7, '#c8a070'); for (let i = 0; i < 4; i++) px(15 + i * 2, 8, 1, 5, '#f0e8d8');
  } else if (kind === 'blueprint') {
    px(4, 5, 16, 14, '#3b6cf6'); px(4, 5, 16, 2, '#6a90ff'); for (let i = 0; i < 4; i++) px(7, 9 + i * 2, 10 - (i % 2) * 4, 1, '#cfe0ff'); px(3, 4, 2, 16, '#c8b090'); px(19, 4, 2, 16, '#c8b090');
  } else {
    // held items and the rest: a little drawstring bag, or an orb for "orb"/"ball" names
    if (/orb|ball|band|scarf|specs|lens|herb|seed|stone|plate|gem/.test(name)) {
      if (/scarf|band/.test(name)) { px(4, 9, 16, 5, col ?? '#e5484d'); px(14, 13, 4, 8, shadeHex(col ?? '#e5484d', -0.2)); }
      else if (/specs|lens/.test(name)) { disc(8, 12, 4, '#3a3048'); disc(16, 12, 4, '#3a3048'); disc(8, 12, 3, '#bfe4fb'); disc(16, 12, 3, '#bfe4fb'); px(11, 11, 2, 1, '#3a3048'); }
      else if (/herb|seed/.test(name)) { px(11, 6, 2, 14, '#3f8a3a'); px(6, 8, 6, 4, '#5cbf4a'); px(13, 11, 6, 4, '#5cbf4a'); }
      else { const g = col ?? '#9aa6b8'; disc(12, 12, 8, shadeHex(g, -0.2)); disc(11, 11, 7, g); disc(9, 9, 2, '#ffffff'); }
    } else {
      const g = col ?? '#c8a070';
      for (let yy = 0; yy < 11; yy++) { const half = 4 + Math.round(Math.sin((yy / 11) * Math.PI) * 4); px(12 - half, 9 + yy, half * 2, 1, yy < 2 ? shadeHex(g, 0.15) : g); }
      px(9, 6, 6, 3, shadeHex(g, -0.2)); px(8, 8, 8, 1, '#5a3a1c'); px(10, 12, 2, 4, 'rgba(255,255,255,.45)');
    }
  }
  outline();
  cache.set(key, c);
  return c;
}
