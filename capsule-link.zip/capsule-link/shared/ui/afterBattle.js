// After a battle: apply experience and friendship, then handle new moves and growth.
import { h, mount, dialog, chooseDialog } from './dom.js';
import { spriteCanvas } from './art.js';
import { sfx, playCry, creatureCry } from './audio.js';
import { makeEvent, applyEvent, displayName, checkEvolution, cryFor, speciesOf } from '../engine/index.js';

/**
 * ctx: { idx, bank, getSave(), commit(fn) | record(ev) }
 * `record(ev)` is used by the phone: it applies the event locally and queues it for the PC.
 * Returns a results element for the caller to show.
 */
export async function finishBattle(ctx, end) {
  const { idx, bank } = ctx;
  const ev = makeEvent('battle', { results: end.results, won: end.won, opponent: end.opponent, linked: !!end.linked });
  if (end.eventId) ev.id = end.eventId; // the same battle is never counted twice
  let outcome = null;
  if (ctx.record) outcome = ctx.record(ev)?.outcome;
  else ctx.commit((save) => { const r = applyEvent(idx, save, ev); if (r.outcome) outcome = r.outcome; });
  const save = ctx.getSave();
  const rows = (end.results || []).map((r) => {
    const c = save.creatures[r.uid];
    const ev2 = outcome?.find?.((o) => o.uid === r.uid)?.events ?? [];
    const levels = ev2.filter((e) => e.type === 'level');
    return { r, c, events: ev2, levels };
  }).filter((x) => x.c);

  // new moves
  for (const row of rows) {
    for (const e of row.events.filter((x) => x.type === 'learnPrompt')) await learnPrompt(ctx, row.c, e.move);
  }
  // growth
  for (const row of rows) {
    const evo = checkEvolution(idx, ctx.getSave().creatures[row.c.uid]);
    if (evo) await evolvePrompt(ctx, row.c.uid, evo.to);
  }
  if (rows.some((x) => x.levels.length)) sfx('level');

  return h('div', { class: 'results col' },
    h('h1', null, end.tie ? 'A draw' : end.won ? 'You won!' : 'You lost this one'),
    h('p', { class: 'dim' }, `Showdown battle against ${end.opponent}.`),
    end.unknown?.length ? h('p', { class: 'micro faint' }, `Not in your Data Lab, so counted with default experience: ${end.unknown.join(', ')}.`) : null,
    h('div', { class: 'col' }, rows.map(({ r, c, levels }) => h('div', { class: 'row result-row' },
      spriteCanvas(bank, ctx.getSave().creatures[c.uid]?.speciesId ?? c.speciesId, { scale: 2 }),
      h('div', { class: 'grow' },
        h('div', null, displayName(idx, ctx.getSave().creatures[c.uid] ?? c)),
        h('div', { class: 'dim' }, [r.exp ? `+${r.exp} exp` : 'No exp', r.friendship > 0 ? `friendship +${r.friendship}` : null, levels.length ? `reached Lv. ${levels[levels.length - 1].level}` : null].filter(Boolean).join(' · '))))),
    ));
}

async function learnPrompt(ctx, c, moveId) {
  const { idx } = ctx;
  const mv = idx.moves.get(moveId);
  const name = displayName(idx, c);
  const pick = await chooseDialog(`${name} wants to learn ${mv?.name ?? moveId}`, [
    ...c.moves.map((m, i) => ({ value: String(i), label: `Forget ${idx.moves.get(m.id)?.name ?? m.id}` })),
    { value: 'skip', label: `Don't learn ${mv?.name ?? moveId}` },
  ]);
  if (pick == null || pick === 'skip') return;
  const ev = makeEvent('learn', { uid: c.uid, slot: Number(pick), move: moveId });
  if (ctx.record) ctx.record(ev); else ctx.commit((save) => applyEvent(idx, save, ev));
}

async function evolvePrompt(ctx, uid, to) {
  const { idx, bank } = ctx;
  const c = ctx.getSave().creatures[uid];
  const target = idx.species.get(to);
  if (!c || !target) return;
  const name = displayName(idx, c);
  const ok = await dialog(`${name} is changing!`, (close) => {
    const stage = h('div', { class: 'evolve-stage' }, spriteCanvas(bank, c, { scale: 4, animate: true }));
    return h('div', { class: 'col' }, stage,
      h('p', null, `${name} is ready to evolve into ${target.name}. Let it?`),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', onclick: () => close(false) }, 'Not yet'),
        h('button', { class: 'btn primary', onclick: () => close(true) }, 'Evolve')));
  });
  if (!ok) return;
  const ev = makeEvent('evolve', { uid, to });
  if (ctx.record) ctx.record(ev); else ctx.commit((save) => applyEvent(idx, save, ev));
  sfx('level');
  creatureCry(speciesOf(idx, ctx.getSave().creatures[uid]), ctx.getSave().creatures[uid]);
  await dialog('Congratulations!', (close) => h('div', { class: 'col' },
    h('div', { class: 'evolve-stage' }, spriteCanvas(bank, to, { scale: 4, animate: true, anim: 'happy' })),
    h('p', null, `${name} evolved into ${target.name}!`),
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: () => close() }, 'Great'))));
}

export { mount };
