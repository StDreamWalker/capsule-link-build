// Moving a creature is moving data, so it looks like it: the creature turns to white light and
// a stream of data, flies to where it is going and rebuilds itself there. Sending one to the
// R.A.N.C.H. fires it up as a beacon. A short line says how they feel about the move.
import { sfx } from './audio.js';
import { brandText } from './dom.js';

const reduced = () => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; } };

function layer() {
  let el = document.getElementById('transfer-layer');
  if (!el) {
    el = document.createElement('div');
    el.id = 'transfer-layer';
    document.body.append(el);
  }
  return el;
}

function spriteFrom(el) {
  const src = el?.querySelector?.('canvas');
  const c = document.createElement('canvas');
  c.width = src?.width || 32; c.height = src?.height || 32;
  if (src) c.getContext('2d').drawImage(src, 0, 0);
  return c;
}

function rectOf(x) {
  if (!x) return null;
  if (x.getBoundingClientRect) { const r = x.getBoundingClientRect(); return r.width ? r : null; }
  return x;
}
const mid = (r) => ({ x: r.left + r.width / 2, y: r.top + r.height / 2 });

const anim = (el, frames, opts) => el.animate(frames, { fill: 'forwards', ...opts }).finished.catch(() => {});

/** A little speech bubble. */
export function sayAt(point, text, { ms = 2600, tone = '' } = {}) {
  if (!text) return;
  const b = document.createElement('div');
  b.className = `transfer-say ${tone}`;
  b.textContent = brandText(text);
  b.style.left = `${Math.max(12, Math.min(innerWidth - 12, point.x))}px`;
  b.style.top = `${Math.max(12, point.y)}px`;
  layer().append(b);
  anim(b, [{ opacity: 0, transform: 'translate(-50%, -80%) scale(.9)' }, { opacity: 1, transform: 'translate(-50%, -110%) scale(1)' }], { duration: 220, easing: 'ease-out' });
  setTimeout(() => anim(b, [{ opacity: 1 }, { opacity: 0 }], { duration: 300 }).then(() => b.remove()), ms);
}

/** Bits of data peeling off a point. */
function burst(p, { n = 14, spread = 46, up = 0, tint = '#9fe8ff', dur = 600 } = {}) {
  const L = layer();
  for (let i = 0; i < n; i++) {
    const d = document.createElement('i');
    d.className = 'transfer-bit';
    d.textContent = Math.random() < 0.5 ? (Math.random() < 0.5 ? '0' : '1') : '';
    d.style.left = `${p.x}px`; d.style.top = `${p.y}px`;
    d.style.color = tint;
    L.append(d);
    const a = Math.random() * Math.PI * 2, r = spread * (0.4 + Math.random() * 0.8);
    anim(d, [
      { transform: 'translate(-50%, -50%) scale(1)', opacity: 1 },
      { transform: `translate(calc(-50% + ${Math.cos(a) * r}px), calc(-50% + ${Math.sin(a) * r - up}px)) scale(.4)`, opacity: 0 },
    ], { duration: dur * (0.7 + Math.random() * 0.6), easing: 'cubic-bezier(.2,.7,.3,1)' }).then(() => d.remove());
  }
}

/** The creature at `from` dissolves into light (the sprite flashes white and shrinks to an orb). */
async function dissolve(from, sprite, tint) {
  const L = layer();
  const s = sprite;
  s.className = 'transfer-sprite';
  const size = Math.max(32, Math.min(96, from.width * 0.9));
  Object.assign(s.style, { left: `${mid(from).x}px`, top: `${mid(from).y}px`, width: `${size}px`, height: `${size}px` });
  L.append(s);
  const orb = document.createElement('div');
  orb.className = 'transfer-orb';
  orb.style.setProperty('--tint', tint);
  Object.assign(orb.style, { left: `${mid(from).x}px`, top: `${mid(from).y}px` });
  L.append(orb);
  await anim(s, [
    { filter: 'brightness(1)', transform: 'translate(-50%, -50%) scale(1)', opacity: 1 },
    { filter: 'brightness(6) saturate(0)', transform: 'translate(-50%, -50%) scale(1.05)', opacity: 1, offset: 0.45 },
    { filter: 'brightness(8) saturate(0) blur(2px)', transform: 'translate(-50%, -50%) scale(.15)', opacity: 0 },
  ], { duration: 520, easing: 'ease-in' });
  s.remove();
  burst(mid(from), { tint });
  return orb;
}

/** The orb rebuilds into the creature at `to`, a scanline at a time. */
async function rebuild(orb, to, sprite, tint) {
  const L = layer();
  const p = mid(to);
  burst(p, { n: 10, spread: 30, tint, dur: 450 });
  await anim(orb, [{ transform: 'translate(-50%, -50%) scale(1)', opacity: 1 }, { transform: 'translate(-50%, -50%) scale(2.6)', opacity: 0 }], { duration: 300, easing: 'ease-out' });
  orb.remove();
  if (!sprite) return;
  const s = sprite;
  s.className = 'transfer-sprite build';
  const size = Math.max(32, Math.min(96, to.width * 0.9));
  Object.assign(s.style, { left: `${p.x}px`, top: `${p.y}px`, width: `${size}px`, height: `${size}px` });
  L.append(s);
  sfx('materialize');
  await anim(s, [
    { clipPath: 'inset(100% 0 0 0)', filter: 'brightness(6) saturate(0)' },
    { clipPath: 'inset(0 0 0 0)', filter: 'brightness(3) saturate(.3)', offset: 0.6 },
    { clipPath: 'inset(0 0 0 0)', filter: 'brightness(1)' },
  ], { duration: 460, easing: 'ease-out' });
  await anim(s, [{ opacity: 1 }, { opacity: 0 }], { duration: 160 });
  s.remove();
}

/**
 * Animate one transfer.
 * opts: { from: Element|DOMRect, to: Element|DOMRect|null, mode: 'move'|'beacon'|'arrive', tint, say, hideTarget }
 * - move: light flies from `from` to `to`
 * - beacon: light shoots up out of the window (off to the R.A.N.C.H. or a capsule)
 * - arrive: light falls from above into `to`
 */
export async function playTransfer({ from = null, to = null, mode = 'move', tint = '#9fe8ff', say = '', spriteEl = null } = {}) {
  const fr = rectOf(from), tr = rectOf(to);
  const art = spriteFrom(spriteEl ?? from ?? to);
  const target = to?.getBoundingClientRect ? to : null;
  if (reduced() || (!fr && !tr)) {
    if (say) sayAt(mid(tr ?? fr ?? { left: innerWidth / 2, top: innerHeight / 2, width: 0, height: 0 }), say);
    return;
  }
  if (target) target.style.visibility = 'hidden';
  try {
    sfx(mode === 'beacon' ? 'beacon' : 'transfer');
    if (mode === 'arrive') {
      const p = mid(tr);
      const orb = document.createElement('div');
      orb.className = 'transfer-orb';
      orb.style.setProperty('--tint', tint);
      Object.assign(orb.style, { left: `${p.x}px`, top: `${p.y}px` });
      const beam = document.createElement('div');
      beam.className = 'transfer-beam down';
      beam.style.setProperty('--tint', tint);
      Object.assign(beam.style, { left: `${p.x}px`, height: `${p.y}px` });
      layer().append(beam, orb);
      anim(beam, [{ opacity: 0, transform: 'translateX(-50%) scaleX(.2)' }, { opacity: 1, transform: 'translateX(-50%) scaleX(1)', offset: 0.3 }, { opacity: 0, transform: 'translateX(-50%) scaleX(.1)' }], { duration: 900 }).then(() => beam.remove());
      await anim(orb, [{ transform: `translate(-50%, calc(-50% - ${p.y + 40}px))` }, { transform: 'translate(-50%, -50%)' }], { duration: 520, easing: 'cubic-bezier(.5,0,.7,1)' });
      await rebuild(orb, tr, art, tint);
    } else {
      const orb = await dissolve(fr, art, tint);
      const a = mid(fr);
      if (mode === 'beacon' || !tr) {
        const beam = document.createElement('div');
        beam.className = 'transfer-beam';
        beam.style.setProperty('--tint', tint);
        Object.assign(beam.style, { left: `${a.x}px`, height: `${a.y}px` });
        layer().append(beam);
        anim(beam, [{ opacity: 0, transform: 'translateX(-50%) scaleX(.2)' }, { opacity: 1, transform: 'translateX(-50%) scaleX(1)', offset: 0.25 }, { opacity: 0, transform: 'translateX(-50%) scaleX(.05)' }], { duration: 1100, easing: 'ease-out' }).then(() => beam.remove());
        await anim(orb, [{ transform: 'translate(-50%, -50%) scale(1)' }, { transform: `translate(-50%, calc(-50% - ${a.y + 60}px)) scale(.6, 2.2)` }], { duration: 650, easing: 'cubic-bezier(.6,0,.9,.4)' });
        orb.remove();
        if (say) sayAt({ x: a.x, y: Math.max(40, a.y - 20) }, say);
        return;
      }
      const b = mid(tr);
      // a curved path with a trail of data
      const dx = b.x - a.x, dy = b.y - a.y;
      const lift = Math.min(160, Math.hypot(dx, dy) * 0.35);
      const steps = 14;
      const frames = [];
      for (let i = 0; i <= steps; i++) {
        const t = i / steps;
        const x = dx * t, y = dy * t - Math.sin(Math.PI * t) * lift;
        frames.push({ transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))` });
      }
      const trail = setInterval(() => {
        const r = orb.getBoundingClientRect();
        burst({ x: r.left + r.width / 2, y: r.top + r.height / 2 }, { n: 2, spread: 10, tint, dur: 400 });
      }, 40);
      await anim(orb, frames, { duration: Math.min(820, 380 + Math.hypot(dx, dy) * 0.6), easing: 'cubic-bezier(.4,0,.2,1)' });
      clearInterval(trail);
      orb.style.left = `${b.x}px`; orb.style.top = `${b.y}px`; orb.getAnimations().forEach((x) => x.cancel());
      await rebuild(orb, tr, spriteFrom(spriteEl ?? from), tint);
    }
    if (say && tr) sayAt({ x: mid(tr).x, y: tr.top }, say);
  } finally {
    if (target) target.style.visibility = '';
  }
}

// ---------- what they say about it ----------
const LINES = {
  party: ['{n} is excited to join the team!', '{n} can’t wait to get going!', '{n} bounced into the party!', '{n} is ready for an adventure!'],
  box: ['{n} settles into {box}.', '{n} looks around {box} curiously.', '{n} found a cosy corner in {box}.', '{n} is taking a little rest.'],
  ranch: ['{n} can’t wait to stretch out at the R.A.N.C.H.!', '{n} is off to run around in the open!', '{n} beamed out, ready for fresh air!'],
  capsule: ['{n} hopped into the capsule, ready for a walk!', '{n} is snug in the capsule.', '{n} is excited to go outside with you!'],
  home: ['{n} is happy to be home!', '{n} streamed back in, stretching after the trip.', '{n} missed the PC a little.'],
  phone: ['{n} streamed off to your phone. Have a good walk!', '{n} is ready to go out with you!'],
};
export function transferLine(kind, name, { box = 'the box', seed = Math.random() } = {}) {
  const list = LINES[kind] ?? LINES.box;
  return list[Math.floor(seed * list.length) % list.length].replace(/\{n\}/g, name).replace(/\{box\}/g, box);
}
