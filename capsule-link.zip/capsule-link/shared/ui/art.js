// Sprite bank: procedural sprites with your own PNG textures layered on top,
// plus helpers to draw them crisply at any scale.
import { generateSpriteData, SPRITE_SIZE } from './sprites.js';
import { renderBiome } from './biomes.js';
import { spriteBox } from './creatureSize.js';

function makeCanvas(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

export const ANIMS = ['idle', 'walk', 'sleep', 'happy', 'blink', 'back'];
/** Sprites bigger than this (in pixels) are shrunk to it, so 96 px sprites fit the ranch. */
export const MAX_DRAW = 64;

const compact = (s) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '');
const dashed = (s) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

/**
 * File names tried for a species' sprite, best first:
 * its id, its name squashed ("mrbristle"), name-with-form ("bristle-mega"), its Showdown name, its number (7, 007, 0007).
 */
export function spriteNames(sp) {
  const out = [];
  const add = (x) => { if (x && !out.includes(x)) out.push(x); };
  add(sp.id);
  for (const n of [sp.name, sp.showdownName]) {
    if (!n) continue;
    add(compact(n));
    add(dashed(n));
    const cut = String(n).indexOf('-');
    if (cut > 0) add(`${compact(String(n).slice(0, cut))}-${compact(String(n).slice(cut + 1))}`);
  }
  if (sp.no > 0 && sp.no < 10000) { add(String(sp.no)); add(String(sp.no).padStart(3, '0')); add(String(sp.no).padStart(4, '0')); }
  return out;
}

/** The sprite id used for creatures that are still eggs. */
export const EGG_ID = '__egg';
/** What to draw for a creature (or a species id): eggs look like eggs. */
// shiny creatures use "<species>:shiny" (pictures creatures/<name>-shiny.png, -shiny-back.png, -shiny-icon.png)
export const spriteIdOf = (c) => (c && typeof c === 'object' ? (c.egg ? EGG_ID : c.shiny ? `${c.formId || c.speciesId}:shiny` : (c.formId || c.speciesId)) : c);

// small built-in pictures: an egg, and a question mark for "picture still loading / missing".
// Your own art wins: creatures/egg.png and creatures/unknown.png.
function pixelArt(rows, colors) {
  const c = makeCanvas(SPRITE_SIZE, SPRITE_SIZE), x = c.getContext('2d');
  const ox = Math.floor((SPRITE_SIZE - rows[0].length) / 2), oy = SPRITE_SIZE - rows.length - 1;
  rows.forEach((r, j) => { for (let i = 0; i < r.length; i++) if (colors[r[i]]) { x.fillStyle = colors[r[i]]; x.fillRect(ox + i, oy + j, 1, 1); } });
  return c;
}
const EGG_ROWS = ['....kkkk....', '...kwwwwk...', '..kwwgwwwk..', '.kwwwwwwwwk.', '.kwwwwwgwwk.', 'kwgwwwwwwwwk', 'kwwwwwwwwwwk', 'kwwwwgwwwwsk', 'kwwwwwwwwwsk', 'kwwgwwwwwssk', '.kwwwwwwwsk.', '.kswwwwwssk.', '..kssssssk..', '...kkkkkk...'];
const Q_ROWS = ['...kkkkkk...', '..kwwwwwwk..', '.kwwkkkkwwk.', '.kwk....kwk.', '..k.....kwk.', '.......kwwk.', '......kwwk..', '.....kwwk...', '.....kwk....', '.....kwk....', '......k.....', '.....kkk....', '.....kwk....', '.....kkk....'];
let builtIns = null;
function builtIn(kind) {
  if (!builtIns) builtIns = {
    egg: pixelArt(EGG_ROWS, { k: '#3b3550', w: '#fbf6e8', g: '#8fd18a', s: '#d9cfb4' }),
    unknown: pixelArt(Q_ROWS, { k: '#3b3550', w: '#e8ecf6' }),
  };
  return builtIns[kind];
}

export class SpriteBank {
  /**
   * resolveTexture(path) -> url string or null. Paths look like "creatures/sproutle.png",
   * "creatures/sproutle-walk.png", "ranch/meadow.png", "boxes/forest.png".
   */
  constructor({ idx, resolveTexture } = {}) {
    this.idx = idx;
    this.resolve = resolveTexture ?? (() => null);
    this.cache = new Map();
    this.loading = new Map();
    this.listeners = new Set();
    this.version = 0;
  }
  setDataset(idx) { this.idx = idx; this.cache.clear(); this.version++; }
  setResolver(fn) { this.resolve = fn; this.cache.clear(); this.loading.clear(); this.version++; this.emit(); }
  onChange(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  emit() { for (const fn of this.listeners) fn(); }

  typeColor = (t) => this.idx?.types.get(t)?.color ?? '#aaaaaa';

  /** { size, frames: { idle: [canvas, ...], ... }, custom: bool } */
  get(speciesId) {
    speciesId = spriteIdOf(speciesId);
    if (this.cache.has(speciesId)) return this.cache.get(speciesId);
    if (speciesId === EGG_ID) return this.special(EGG_ID, 'egg', 'creatures/egg.png');
    const [baseId, variant] = String(speciesId).split(':');
    const sp0 = this.idx?.species.get(baseId) ?? { id: baseId, types: [], baseStats: null };
    const sp = variant ? { ...sp0, variant } : sp0;
    // a picture of its own is on the way, or the player uses their own pictures for everything:
    // show a question mark rather than the made-up placeholder creature
    if (this.find(sp, 'idle') || this.anyCustom) {
      const q = this.unknownFrame();
      const entry = { size: SPRITE_SIZE, draw: SPRITE_SIZE, frames: Object.fromEntries(ANIMS.map((a) => [a, [q]])), custom: false, waiting: true };
      this.cache.set(speciesId, entry);
      this.loadCustom(sp, entry);
      return entry;
    }
    const data = generateSpriteData(sp0, this.typeColor);
    const frames = {};
    for (const [name, list] of Object.entries(data.frames)) {
      frames[name] = list.map((px) => {
        const c = makeCanvas(SPRITE_SIZE, SPRITE_SIZE);
        c.getContext('2d').putImageData(new ImageData(px, SPRITE_SIZE, SPRITE_SIZE), 0, 0);
        return variant === 'shiny' ? hueShift(c, 140) : c;
      });
    }
    const entry = { size: SPRITE_SIZE, draw: SPRITE_SIZE, frames, custom: false };
    this.cache.set(speciesId, entry);
    this.loadCustom(sp, entry);
    return entry;
  }

  /** The question mark: your creatures/unknown.png if there is one. */
  unknownFrame() {
    const e = this.cache.get('__unknown') ?? this.special('__unknown', 'unknown', 'creatures/unknown.png');
    return e.frames.idle[0];
  }
  special(key, kind, path) {
    const img = builtIn(kind);
    const entry = { size: SPRITE_SIZE, draw: SPRITE_SIZE, frames: Object.fromEntries(ANIMS.map((a) => [a, [img]])), custom: false };
    this.cache.set(key, entry);
    const url = this.resolve(path);
    if (url) loadImage(url).then((im) => { const f = splitFrames(im); entry.size = f[0].width; entry.draw = Math.min(entry.size, MAX_DRAW); for (const a of ANIMS) entry.frames[a] = f; this.version++; this.emit(); }).catch(() => {});
    return entry;
  }

  /** The first texture path that exists for this species and pose, or null. */
  find(sp, anim = 'idle') {
    // a shiny looks for its own picture first, then makes do with the usual one
    const tags = sp.variant ? [`-${sp.variant}`, ''] : [''];
    for (const tag of tags) {
      for (const name of spriteNames(sp)) {
        const path = anim === 'idle' ? `creatures/${name}${tag}.png` : `creatures/${name}${tag}-${anim}.png`;
        const url = this.resolve(path);
        if (url) return { path, url };
      }
    }
    return null;
  }

  loadCustom(sp, entry) {
    for (const anim of ['idle', ...ANIMS.filter((a) => a !== 'idle'), 'icon']) {
      const hit = this.find(sp, anim);
      if (!hit) continue;
      loadImage(hit.url).then((img) => {
        const frames = splitFrames(img);
        const fh = frames[0].width;
        if (anim === 'idle') {
          this.anyCustom = true;
          entry.waiting = false;
          entry.size = fh;
          entry.draw = Math.min(fh, MAX_DRAW);
          entry.custom = true;
          entry.path = hit.path;
          // poses without their own file reuse the idle frames
          for (const a of ANIMS) if (!entry.ownFile?.[a]) entry.frames[a] = a === 'blink' ? [frames[0]] : frames;
        }
        entry.ownFile = { ...(entry.ownFile || {}), [anim]: true };
        entry.frames[anim] = frames;
        this.version++;
        this.emit();
      }).catch(() => { /* missing file is fine */ });
    }
  }

  /** Background art: your PNG if present, otherwise the procedural biome. */
  background(kind, biome, w, h, seed = 0) {
    const key = `bg:${kind}:${biome}`;
    const custom = this.cache.get(key);
    if (custom?.img) return custom.img;
    if (!custom) {
      const entry = {};
      this.cache.set(key, entry);
      const url = this.resolve(`${kind}/${biome}.png`);
      if (url) loadImage(url).then((img) => { entry.img = img; this.version++; this.emit(); }).catch(() => {});
    }
    return renderBiome(biome, w, h, { seed });
  }
}

/**
 * A strip of square frames side by side (width a multiple of height) becomes that many frames.
 * Anything else is one frame, padded to a square and standing on the bottom edge.
 */
function splitFrames(img) {
  const w = img.width, fh = img.height;
  if (w >= fh && w % fh === 0) {
    const frames = [];
    for (let i = 0; i < w / fh; i++) {
      const c = makeCanvas(fh, fh);
      c.getContext('2d').drawImage(img, i * fh, 0, fh, fh, 0, 0, fh, fh);
      frames.push(c);
    }
    return frames;
  }
  const size = Math.max(w, fh);
  const c = makeCanvas(size, size);
  c.getContext('2d').drawImage(img, Math.floor((size - w) / 2), size - fh);
  return [c];
}

/** The visible part of one picture (cached). */
const boxes = new WeakMap();
function boxOf(img) {
  if (!boxes.has(img)) boxes.set(img, spriteBox({ frames: { idle: [img] } }));
  return boxes.get(img);
}

/** A copy of a picture with its colours turned around the wheel (generated shinies). */
function hueShift(src, deg) {
  const c = makeCanvas(src.width, src.height), x = c.getContext('2d');
  x.filter = `hue-rotate(${deg}deg) saturate(1.2)`;
  x.drawImage(src, 0, 0);
  return c;
}

function loadImage(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}

/** Draw a sprite frame centred on (x, bottom) at an integer scale. */
export function drawSprite(ctx, entry, anim, frame, x, bottom, scale = 1, flip = false) {
  const list = entry.frames[anim] ?? entry.frames.idle;
  const n = list.length;
  const img = list[((Math.floor(frame) % n) + n) % n] ?? list[0];
  if (!img) return;
  const s = (entry.draw ?? entry.size) * scale;
  ctx.save();
  ctx.imageSmoothingEnabled = img.width > s; // smooth only when shrinking a big sprite
  if (flip) {
    ctx.translate(Math.round(x + s / 2), Math.round(bottom - s));
    ctx.scale(-1, 1);
    ctx.drawImage(img, 0, 0, s, s);
  } else ctx.drawImage(img, Math.round(x - s / 2), Math.round(bottom - s), s, s);
  ctx.restore();
}

/** A small <canvas> element showing a creature (for lists and box slots). */
export function spriteCanvas(bank, speciesId, { scale = 2, anim = 'idle', animate = false } = {}) {
  const entry = bank.get(speciesId);
  const c = document.createElement('canvas');
  const size = SPRITE_SIZE * scale;
  c.width = size; c.height = size;
  c.className = 'sprite';
  const ctx = c.getContext('2d');
  let frame = 0, raf = 0, last = 0;
  const paint = () => {
    const e = bank.get(speciesId);
    // small pictures (boxes, menus) use the box icon when there is one, at its true size or a
    // whole multiple of it: never shrunk, never stretched by an odd amount
    const useIcon = anim === 'idle' && size <= 96 && e.ownFile?.icon && e.frames.icon;
    if (useIcon) {
      const img = e.frames.icon[frame % e.frames.icon.length];
      const b = boxOf(img);
      const bw = Math.max(1, Math.round((b.right - b.left) * img.width)), bh = Math.max(1, Math.round((b.bottom - b.top) * img.height));
      const k = Math.max(1, Math.floor(size / Math.max(bw, bh)));
      if (c.width !== bw * k || c.height !== bh * k) { c.width = bw * k; c.height = bh * k; }
      c.style.width = `${bw * k}px`; c.style.height = `${bh * k}px`;
      c.classList.add('true-size');
      ctx.imageSmoothingEnabled = false;
      ctx.clearRect(0, 0, c.width, c.height);
      ctx.drawImage(img, Math.round(b.left * img.width), Math.round(b.top * img.height), bw, bh, 0, 0, bw * k, bh * k);
      return;
    }
    if (c.classList.contains('true-size')) { c.classList.remove('true-size'); c.style.width = ''; c.style.height = ''; c.width = size; c.height = size; }
    ctx.clearRect(0, 0, size, size);
    const list = e.frames[anim] ?? e.frames.idle;
    const img = list[frame % list.length];
    // otherwise zoom in on the visible creature, so big sprites with lots of empty space aren't tiny
    const b = spriteBox(e);
    const side = Math.max(b.right - b.left, b.bottom - b.top) * img.width;
    const cx = ((b.left + b.right) / 2) * img.width, by = b.bottom * img.height;
    const sx = Math.max(0, Math.min(img.width - side, cx - side / 2)), sy = Math.max(0, Math.min(img.height - side, by - side));
    ctx.imageSmoothingEnabled = side > size;
    ctx.drawImage(img, sx, sy, side, side, 0, 0, size, size);
  };
  paint();
  if (animate) {
    const loop = (t) => {
      if (!c.isConnected && last) return;
      if (t - last > 420) { frame++; last = t; paint(); }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
  }
  const off = bank.onChange(() => { if (!c.isConnected) { off(); return; } paint(); });
  c.dispose = () => { cancelAnimationFrame(raf); off(); };
  void entry;
  return c;
}
