// Procedural placeholder sprites. Every species gets a unique 32×32 pixel creature built from
// its id, types and stats, so the apps look alive before you draw your own textures.
// Your PNGs (see docs/textures.md) always win over these.
import { createRng, hashString } from '../engine/rng.js';

export const SPRITE_SIZE = 32;

// palette indices
const E = 0, BASE = 1, SHADE = 2, LIGHT = 3, ACCENT = 4, WHITE = 5, DARK = 6, LINE = 7, BLUSH = 8, DECO = 9, DECO2 = 10;

const TYPE_DECO = {
  ember: 'flame', tide: 'fin', sprout: 'leaf', volt: 'bolt', frost: 'crystal', stone: 'rocks',
  gale: 'wings', brawl: 'band', shade: 'wisp', mind: 'gem', metal: 'antenna', plain: 'none',
};
const DECOS = ['flame', 'fin', 'leaf', 'bolt', 'crystal', 'rocks', 'wings', 'band', 'wisp', 'gem', 'antenna', 'none'];

function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  const v = m ? parseInt(m[1], 16) : 0xaaaaaa;
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
}
function rgbToHsl([r, g, b]) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h *= 60;
  }
  return [h, s, l];
}
function hslToRgb(h, s, l) {
  h = ((h % 360) + 360) % 360;
  const k = (n) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return [Math.round(f(0) * 255), Math.round(f(8) * 255), Math.round(f(4) * 255)];
}
const shiftL = (rgb, dl, ds = 0, dh = 0) => {
  const [h, s, l] = rgbToHsl(rgb);
  return hslToRgb(h + dh, Math.max(0, Math.min(1, s + ds)), Math.max(0, Math.min(1, l + dl)));
};

function paletteFor(sp, typeColor, rng) {
  const base = hexToRgb(typeColor(sp.types?.[0]));
  // nudge the hue per species so two creatures of one type differ
  const [h, s, l] = rgbToHsl(base);
  const b = hslToRgb(h + rng.int(-14, 14), Math.min(0.85, s * rng.range(0.85, 1.1)), Math.min(0.72, Math.max(0.42, l + rng.range(-0.08, 0.06))));
  const accent = sp.types?.[1] ? hexToRgb(typeColor(sp.types[1])) : hslToRgb(h + 180 + rng.int(-30, 30), 0.45, 0.62);
  const DECO_RGB = { flame: [255, 176, 56], bolt: [255, 236, 96], leaf: [92, 196, 76], crystal: [150, 225, 250], gem: [240, 110, 200], wisp: [190, 160, 255], antenna: [255, 90, 90], fin: accent };
  const decoBase = DECO_RGB[TYPE_DECO[sp.types?.[0]]] ?? shiftL(accent, 0.05);
  return [
    null, b, shiftL(b, -0.14, 0.05, -6), shiftL(b, 0.16, -0.08, 4), accent,
    [250, 250, 245], [28, 24, 40], shiftL(b, -0.36, 0.1, -10), [255, 140, 170], decoBase, shiftL(decoBase, 0.18),
  ];
}

/** Build a creature design (the random choices), then render poses from it. */
export function designFor(sp) {
  const rng = createRng(hashString(`sprite:${sp.id}`));
  const st = sp.baseStats || { hp: 50, atk: 50, def: 50, spa: 50, spd: 50, spe: 50 };
  const bst = Object.values(st).reduce((a, x) => a + (Number(x) || 0), 0);
  const size = Math.max(0, Math.min(1, (bst - 240) / 330));
  const deco = TYPE_DECO[sp.types?.[0]] ?? DECOS[hashString(sp.types?.[0] || 'x') % DECOS.length];
  const deco2 = sp.types?.[1] ? (TYPE_DECO[sp.types[1]] ?? DECOS[hashString(sp.types[1]) % DECOS.length]) : null;
  const heavy = st.def + st.hp > st.spe * 2.6;
  const fast = st.spe > 85;
  return {
    rng,
    w: Math.round(13 + size * 9 + (heavy ? 2 : 0) - (fast ? 1 : 0)) & ~1,
    h: Math.round(11 + size * 7 + rng.int(0, 2)),
    shape: rng.pick(heavy ? ['round', 'wide', 'pear'] : fast ? ['tall', 'round', 'bean'] : ['round', 'tall', 'pear', 'bean', 'wide']),
    ears: rng.pick(['pointy', 'round', 'long', 'horn', 'none', 'pointy', 'tuft']),
    eyes: rng.pick(['big', 'big', 'dot', 'sleepy', 'bright']),
    mouth: rng.pick(['smile', 'fang', 'line', 'w', 'smile']),
    belly: rng() < 0.6,
    spots: rng() < 0.3,
    cheeks: rng() < 0.45,
    arms: rng() < 0.55,
    feet: deco === 'wisp' || deco === 'wings' && rng() < 0.4 ? 'none' : rng.pick(['stubs', 'stubs', 'paws']),
    tail: rng.pick(['curl', 'straight', 'none', 'puff', 'zig']),
    deco, deco2, size, heavy,
    sat: rng(),
  };
}

function makeGrid() { return Array.from({ length: SPRITE_SIZE }, () => new Uint8Array(SPRITE_SIZE)); }

function put(g, x, y, c, overwrite = true) {
  x = Math.round(x); y = Math.round(y);
  if (x < 0 || y < 0 || x >= SPRITE_SIZE || y >= SPRITE_SIZE) return;
  if (overwrite || !g[y][x]) g[y][x] = c;
}
const putSym = (g, x, y, c, o = true) => { put(g, x, y, c, o); put(g, SPRITE_SIZE - 1 - x, y, c, o); };

function fillEllipse(g, cx, cy, rx, ry, c, sym = false, p = 2, overwrite = true) {
  for (let y = Math.floor(cy - ry - 1); y <= Math.ceil(cy + ry + 1); y++) {
    for (let x = Math.floor(cx - rx - 1); x <= Math.ceil(cx + rx + 1); x++) {
      const dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry;
      if (Math.pow(Math.abs(dx), p) + Math.pow(Math.abs(dy), p) <= 1) (sym ? putSym : put)(g, x, y, c, overwrite);
    }
  }
}

function line(g, x0, y0, x1, y1, c, sym = false) {
  const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), 1);
  for (let i = 0; i <= n; i++) (sym ? putSym : put)(g, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, c);
}

/**
 * Render one pose into a palette-index grid.
 * pose: { bob, blink, happy, sleep, step (0/1), back }
 */
function renderPose(d, pose = {}) {
  const g = makeGrid();
  const S = SPRITE_SIZE, cx = S / 2;
  const footH = d.feet === 'none' ? 0 : 3;
  const bob = pose.bob ?? 0;
  const bottom = S - 2 - footH;
  const ry = d.h / 2, rx = d.w / 2;
  const cy = bottom - ry + bob + (d.feet === 'none' ? -2 : 0);
  const top = cy - ry;

  // tail (behind the body, right side)
  if (d.tail !== 'none' && !pose.back) drawTail(g, d, cx + rx - 2, cy + ry * 0.3, pose);
  if (pose.back && d.tail !== 'none') drawTail(g, d, cx - rx + 2, cy + ry * 0.3, { ...pose, mirror: true });

  // wings behind the body
  if (d.deco === 'wings' || d.deco2 === 'wings') {
    const wy = cy - ry * 0.25;
    for (let i = 0; i < 6; i++) {
      line(g, cx - rx + 1, wy + i * 0.6, cx - rx - 5 + i * 0.3, wy - 4 + i * 1.6 - (pose.step ? 1 : 0), i % 2 ? ACCENT : LIGHT, true);
    }
  }

  // feet
  if (d.feet !== 'none') {
    const fx = rx * 0.5;
    const lift0 = pose.step === 1 ? 1 : 0, lift1 = pose.step === 2 ? 1 : 0;
    const fw = d.feet === 'paws' ? 2.6 : 2.1;
    fillEllipse(g, cx - fx, S - 3 - lift0, fw, 1.7, SHADE);
    fillEllipse(g, cx + fx, S - 3 - lift1, fw, 1.7, SHADE);
  } else {
    // a wispy tail-end for floaters
    for (let i = 0; i < 4; i++) fillEllipse(g, cx + Math.sin((i + (pose.step ? 1 : 0)) * 1.4) * 2, cy + ry + i * 1.2, rx * (0.5 - i * 0.1), 1.2, i % 2 ? BASE : SHADE);
  }

  // ears / horns
  const ex = rx * 0.55;
  switch (d.ears) {
    case 'pointy':
      for (let i = 0; i < 5; i++) line(g, cx - ex - 2 + i * 0.4, top + 2, cx - ex - 1 + i * 0.3, top - 4 + i * 0.6, BASE, true);
      line(g, cx - ex - 1, top + 1, cx - ex - 1, top - 2, LIGHT, true);
      break;
    case 'round':
      fillEllipse(g, cx - ex - 1, top + 1, 2.6, 2.6, BASE, true);
      fillEllipse(g, cx - ex - 1, top + 1, 1.2, 1.2, LIGHT, true);
      break;
    case 'long':
      fillEllipse(g, cx - ex, top - 3, 1.8, 5, BASE, true);
      line(g, cx - ex, top - 6, cx - ex, top, LIGHT, true);
      break;
    case 'horn':
      line(g, cx - ex + 1, top + 1, cx - ex - 2, top - 4, ACCENT, true);
      line(g, cx - ex + 2, top + 1, cx - ex - 1, top - 4, ACCENT, true);
      break;
    case 'tuft':
      for (let i = -1; i <= 1; i++) line(g, cx + i * 2, top + 1, cx + i * 3, top - 3, BASE, false);
      break;
    default: break;
  }

  // body
  const p = d.shape === 'wide' ? 2.6 : d.shape === 'round' ? 2.2 : 2;
  if (d.shape === 'pear') {
    fillEllipse(g, cx, cy + ry * 0.2, rx, ry * 0.8, BASE, false, 2.1);
    fillEllipse(g, cx, cy - ry * 0.35, rx * 0.78, ry * 0.65, BASE, false, 2.1);
  } else if (d.shape === 'bean') {
    fillEllipse(g, cx, cy, rx, ry, BASE, false, 2.4);
    fillEllipse(g, cx - rx * 0.8, cy + ry * 0.1, 1.2, ry * 0.4, E);
  } else if (d.shape === 'tall') {
    fillEllipse(g, cx, cy, rx * 0.9, ry, BASE, false, 2.3);
  } else {
    fillEllipse(g, cx, cy, rx, ry, BASE, false, p);
  }

  // arms
  if (d.arms) {
    const ay = cy + ry * 0.15;
    fillEllipse(g, cx - rx + 0.5, ay + (pose.happy ? -2 : 0), 1.6, 2.2, SHADE, true);
  }

  // belly + spots
  if (!pose.back && d.belly) fillEllipse(g, cx, cy + ry * 0.35, rx * 0.55, ry * 0.45, LIGHT, false, 2, true);
  if (d.spots) {
    const r2 = createRng(hashString(`spots${d.w}${d.h}${d.deco}`));
    for (let i = 0; i < 4; i++) {
      const sx = cx - rx * 0.6 + r2() * rx * 0.5, sy = cy - ry * 0.5 + r2() * ry;
      if (g[Math.round(sy)]?.[Math.round(sx)] === BASE) { putSym(g, sx, sy, ACCENT); putSym(g, sx + 1, sy, ACCENT); }
    }
  }

  // type decoration on top of the head
  drawDeco(g, d.deco, cx, top, rx, ry, cy, pose, false);
  if (d.deco2 && d.deco2 !== d.deco) drawDeco(g, d.deco2, cx, top, rx, ry, cy, pose, true);

  // face
  if (!pose.back) {
    const eyeY = Math.round(cy - ry * 0.12);
    const eyeX = Math.max(2, Math.round(rx * 0.42));
    drawEyes(g, d, cx, eyeY, eyeX, pose);
    const my = eyeY + 3;
    if (pose.happy) { putSym(g, cx - 1, my, DARK); putSym(g, cx - 1, my + 1, BLUSH); }
    else if (d.mouth === 'smile') { put(g, cx - 2, my, DARK); put(g, cx + 1, my, DARK); put(g, cx - 1, my + 1, DARK); put(g, cx, my + 1, DARK); }
    else if (d.mouth === 'fang') { put(g, cx - 1, my, DARK); put(g, cx, my, DARK); put(g, cx + 1, my + 1, WHITE); }
    else if (d.mouth === 'w') { put(g, cx - 2, my, DARK); put(g, cx - 1, my + 1, DARK); put(g, cx, my, DARK); put(g, cx + 1, my + 1, DARK); put(g, cx + 2, my, DARK); }
    else { put(g, cx - 1, my, DARK); put(g, cx, my, DARK); }
    if (d.cheeks || pose.happy) { putSym(g, cx - eyeX - 2, eyeY + 2, BLUSH); putSym(g, cx - eyeX - 1, eyeY + 2, BLUSH); }
  }

  outlineAndShade(g);
  return g;
}

function drawEyes(g, d, cx, y, ex, pose) {
  const closed = pose.blink || pose.sleep;
  if (pose.happy) {
    // ^ ^
    putSym(g, cx - ex - 1, y + 1, DARK); putSym(g, cx - ex, y, DARK); putSym(g, cx - ex + 1, y + 1, DARK);
    return;
  }
  if (closed) { putSym(g, cx - ex - 1, y + 1, DARK); putSym(g, cx - ex, y + 1, DARK); putSym(g, cx - ex + 1, y + 1, DARK); return; }
  switch (d.eyes) {
    case 'dot':
      putSym(g, cx - ex, y, DARK); putSym(g, cx - ex, y + 1, DARK);
      break;
    case 'sleepy':
      putSym(g, cx - ex - 1, y, DARK); putSym(g, cx - ex, y, DARK); putSym(g, cx - ex + 1, y, DARK);
      putSym(g, cx - ex - 1, y + 1, WHITE); putSym(g, cx - ex, y + 1, DARK); putSym(g, cx - ex + 1, y + 1, DARK);
      break;
    case 'bright':
      for (let yy = -1; yy <= 1; yy++) for (let xx = -1; xx <= 0; xx++) putSym(g, cx - ex + xx, y + yy, DARK);
      putSym(g, cx - ex - 1, y - 1, WHITE);
      putSym(g, cx - ex + 1, y, ACCENT);
      break;
    default: // big
      for (let yy = -1; yy <= 1; yy++) for (let xx = -1; xx <= 0; xx++) putSym(g, cx - ex + xx, y + yy, DARK);
      putSym(g, cx - ex - 1, y - 1, WHITE);
      break;
  }
}

function drawTail(g, d, x, y, pose) {
  const dir = pose.mirror ? -1 : 1;
  const wag = pose.step ? 1 : 0;
  switch (d.tail) {
    case 'curl':
      for (let i = 0; i < 7; i++) put(g, x + dir * (i * 0.9), y - Math.sin(i / 2) * 3 - wag * (i > 3 ? 1 : 0), i > 4 ? ACCENT : BASE);
      fillEllipse(g, x + dir * 6, y - 4 - wag, 1.5, 1.5, ACCENT);
      break;
    case 'straight':
      line(g, x, y, x + dir * 6, y - 3 - wag, BASE); line(g, x, y + 1, x + dir * 6, y - 2 - wag, BASE);
      break;
    case 'puff':
      fillEllipse(g, x + dir * 3, y - 1 - wag, 3, 2.6, LIGHT);
      break;
    case 'zig':
      line(g, x, y, x + dir * 3, y - 3, BASE); line(g, x + dir * 3, y - 3, x + dir * 1, y - 5, BASE); line(g, x + dir * 1, y - 5, x + dir * 5, y - 9 - wag, DECO);
      break;
    default: break;
  }
  if (d.deco === 'flame' && d.tail !== 'none') {
    fillEllipse(g, x + dir * 6, y - 6 - wag, 1.6, 2.4, DECO);
    put(g, x + dir * 6, y - 6 - wag, DECO2);
  }
}

function drawDeco(g, deco, cx, top, rx, ry, cy, pose, second) {
  const flick = pose.step ? 1 : 0;
  const off = second ? Math.round(rx * 0.55) : 0;
  const x = cx + off;
  switch (deco) {
    case 'flame':
      if (second) break;
      fillEllipse(g, x, top - 1, 2.4, 2.8, DECO);
      line(g, x, top - 5 - flick, x, top - 1, DECO);
      line(g, x - 2, top - 3 + flick, x - 1, top, DECO);
      put(g, x, top - 1, DECO2); put(g, x, top, DECO2);
      break;
    case 'fin':
      for (let i = 0; i < 4; i++) line(g, x - 1 + i, top + 1, x - 1 + i * 0.5, top - 4 + i, ACCENT);
      break;
    case 'leaf':
      line(g, x, top + 1, x, top - 2, SHADE);
      fillEllipse(g, x - 2, top - 3 - flick, 2.2, 1.3, DECO);
      fillEllipse(g, x + 2, top - 3, 2.2, 1.3, DECO);
      break;
    case 'bolt':
      line(g, x - 1, top - 5, x + 1, top - 2, DECO); line(g, x + 1, top - 2, x - 1, top - 1, DECO); line(g, x - 1, top - 1, x + 1, top + 1, DECO);
      break;
    case 'crystal':
      line(g, x, top - 5, x, top + 1, DECO2); line(g, x - 1, top - 3, x - 1, top + 1, DECO); line(g, x + 1, top - 3, x + 1, top + 1, DECO);
      line(g, x - 3, top - 1, x - 3, top + 2, DECO2); line(g, x + 3, top - 1, x + 3, top + 2, DECO2);
      break;
    case 'rocks':
      fillEllipse(g, x - rx * 0.4, top + 1, 1.8, 1.4, ACCENT); fillEllipse(g, x + rx * 0.35, top + 2, 1.5, 1.2, ACCENT);
      fillEllipse(g, x + rx * 0.7, cy, 1.4, 1.6, ACCENT);
      break;
    case 'band':
      for (let xx = -rx; xx <= rx; xx++) if (g[Math.round(top + 2)]?.[Math.round(cx + xx)] === BASE) put(g, cx + xx, top + 2, ACCENT);
      line(g, cx + rx - 1, top + 2, cx + rx + 2, top + 4 + flick, ACCENT);
      break;
    case 'wisp':
      fillEllipse(g, x + 2, top - 2 - flick, 1.4, 1.4, DECO);
      put(g, x + 4, top - 4, DECO2); put(g, x, top - 5 + flick, DECO2);
      break;
    case 'gem':
      put(g, x - 1, top + 3, DECO); put(g, x, top + 3, DECO); put(g, x - 1, top + 2, DECO2); put(g, x, top + 4, DECO);
      break;
    case 'antenna':
      line(g, x, top + 1, x + 1, top - 4, SHADE);
      fillEllipse(g, x + 1, top - 5, 1.3, 1.3, pose.step ? DECO2 : DECO);
      break;
    default: break;
  }
}

function outlineAndShade(g) {
  const S = SPRITE_SIZE;
  const filled = (x, y) => x >= 0 && y >= 0 && x < S && y < S && g[y][x] !== E && g[y][x] !== LINE;
  // shading: bottom/right rims get the shade colour, top-left rim gets a highlight
  const copy = g.map((r) => Uint8Array.from(r));
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    if (copy[y][x] !== BASE) continue;
    const below = y + 1 < S ? copy[y + 1][x] : E;
    const right = x + 1 < S ? copy[y][x + 1] : E;
    const above = y > 0 ? copy[y - 1][x] : E;
    const left = x > 0 ? copy[y][x - 1] : E;
    if (below === E || (right === E && y > S / 2)) g[y][x] = SHADE;
    else if ((above === E && left !== E && x < S / 2 + 2) || (left === E && above !== E && y < S / 2)) g[y][x] = LIGHT;
  }
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    if (g[y][x] !== E) continue;
    if (filled(x - 1, y) || filled(x + 1, y) || filled(x, y - 1) || filled(x, y + 1)) g[y][x] = LINE;
  }
}

const POSES = {
  idle: [{ bob: 0 }, { bob: 1 }],
  blink: [{ bob: 0, blink: true }],
  happy: [{ bob: 0, happy: true }, { bob: -1, happy: true }],
  sleep: [{ bob: 1, sleep: true }, { bob: 1, sleep: true }],
  walk: [{ bob: 0, step: 1 }, { bob: 1, step: 2 }],
  back: [{ bob: 0, back: true }, { bob: 1, back: true }],
};

/** Returns { size, frames: { idle: [rgbaArray...], ... } } as Uint8ClampedArray RGBA pixel data. */
export function generateSpriteData(sp, typeColor) {
  const d = designFor(sp);
  const pal = paletteFor(sp, typeColor, createRng(hashString(`pal:${sp.id}`)));
  const frames = {};
  for (const [name, poses] of Object.entries(POSES)) {
    frames[name] = poses.map((pose) => {
      const g = renderPose(d, pose);
      const out = new Uint8ClampedArray(SPRITE_SIZE * SPRITE_SIZE * 4);
      for (let y = 0; y < SPRITE_SIZE; y++) for (let x = 0; x < SPRITE_SIZE; x++) {
        const c = pal[g[y][x]];
        if (!c) continue;
        const o = (y * SPRITE_SIZE + x) * 4;
        out[o] = c[0]; out[o + 1] = c[1]; out[o + 2] = c[2]; out[o + 3] = 255;
      }
      return out;
    });
  }
  return { size: SPRITE_SIZE, frames, design: d };
}

export { hexToRgb, shiftL, hslToRgb, rgbToHsl };
