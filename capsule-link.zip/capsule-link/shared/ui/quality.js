// Graphics quality, per device (a phone and a PC can differ): potato · low · medium · high · ultra.
// Every 3-D scene reads it — battles, the R.A.N.C.H., activities, quality time — so a slower device can trade
// detail for speed everywhere at once.
export const QUALITY = [
  ['potato', 'Potato', 'Bare bones for old devices: a smaller picture, no shadows or lighting effects, few particles.'],
  ['low', 'Low', 'A smaller picture, no shadows, no surface detail, fewer particles.'],
  ['medium', 'Medium', 'Hard-edged shadows, most particles, no glow pass.'],
  ['high', 'High', 'Soft shadows, surface detail, glows, rain on the lens, lit-up sides in the sun.'],
  ['ultra', 'Ultra', 'Everything, plus dramatic lighting, a sharper picture and more particles.'],
];
const KEY = 'clQuality';
const listeners = new Set();
let cur = null;
const defaultQ = () => {
  // a phone starts a step lower than a PC
  const phone = typeof navigator !== 'undefined' && /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent ?? '');
  return phone ? 'medium' : 'high';
};
export function getQuality() {
  if (cur) return cur;
  try { cur = localStorage.getItem(KEY); } catch { cur = null; }
  if (!QUALITY.some((q) => q[0] === cur)) cur = defaultQ();
  return cur;
}
export function qualityLevel() { return Math.max(0, QUALITY.findIndex((q) => q[0] === getQuality())); }
export function setQuality(q) {
  if (!QUALITY.some((x) => x[0] === q)) return;
  cur = q; try { localStorage.setItem(KEY, q); } catch { /* fine */ }
  for (const f of listeners) { try { f(q); } catch { /* fine */ } }
}
export function onQuality(fn) { listeners.add(fn); return () => listeners.delete(fn); }
/** What each level turns on. */
export function qualityPreset(lvl = qualityLevel()) {
  return {
    lvl,
    res: [300, 360, 420, 480, 600][lvl],     // the picture's height in pixels (the scene is drawn small and scaled up)
    shadows: lvl >= 2, softShadows: lvl >= 3, patterns: lvl >= 3, sunSides: lvl >= 3, lamps: lvl >= 1,
    reflections: lvl >= 2, particles: [0.35, 0.6, 0.85, 1, 1.2][lvl],
  };
}

/** The slider (settings): from potato to ultra, saved on this device. */
export function qualitySlider(h, { onChange } = {}) {
  const i0 = qualityLevel();
  const name = h('b', null, QUALITY[i0][1]), help = h('span', { class: 'micro dim' }, QUALITY[i0][2]);
  const input = h('input', { type: 'range', min: 0, max: 4, step: 1, value: i0, 'aria-label': 'Graphics quality', style: { width: '100%' },
    oninput: (e) => { const q = QUALITY[Number(e.target.value)]; name.textContent = q[1]; help.textContent = q[2]; },
    onchange: (e) => { const q = QUALITY[Number(e.target.value)]; setQuality(q[0]); onChange?.(q[0]); } });
  return h('div', { class: 'col quality-slider', style: { gap: '4px' } },
    h('div', { class: 'row', style: { gap: '8px', alignItems: 'baseline' } }, h('span', null, 'Graphics (this device):'), name),
    input,
    h('div', { class: 'row micro dim', style: { justifyContent: 'space-between' } }, QUALITY.map((q) => h('span', null, q[1]))),
    help);
}
