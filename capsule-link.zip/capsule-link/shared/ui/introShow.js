// The introduction that plays the very first time either app starts: full-screen slides that fade
// in and out, like setting up a new phone. No skipping and no going back, only Next (which can be
// pressed as fast as you like).
//
// The text is written with the default names ("Capsule Link", "Capsule Link Network", "creature",
// "Nexus Ball"); like every other piece of interface text it is rewritten to the names chosen in
// setup. It can also be replaced entirely (data set → introText), in this format:
//   slides are separated by a line containing only ---
//   a line starting "## " is the slide's headline, "> " a small line above it
//   a line starting "- " is a list item ("- Label: text" makes the label bold)
//   any other line is a paragraph
import { h, mount, brandText } from './dom.js';
import { logoMark } from './icons.js';
import { capsuleCanvas } from './capsuleArt.js';
import { sfx } from './audio.js';

export const DEFAULT_INTRO = `## Introducing the Nexus Ball
A new world of connection. A new era of creature care.
---
> A joint innovation by Capsule Link and Capsule Link Network
Building upon the pioneering work of renowned creature storage system developers, including the founder of the creature Collection System, Capsule Link and our partners at Capsule Link Network are proud to introduce a revolutionary advancement in creature technology: the Nexus Ball.
---
## For the first time
Trainers can monitor, interact with, and spend meaningful time with creatures deposited in their PC storage systems, regardless of physical distance.
---
Until now, creatures stored within the PC system have enjoyed their own carefully maintained digital habitats: peaceful environments designed to provide comfort and security while their Trainers are away.
With the Nexus Ball, we're taking that experience a step further.
---
Through a groundbreaking interface with the creature storage network, the Nexus Ball provides a live viewport into these digital environments, allowing creatures to observe the world beyond their habitats and interact with their Trainers while remaining safely within their naturally digitized light state.
---
## Your creature doesn't have to leave home to be by your side.
Whether you're taking a walk, commuting by train, traveling across regions, or simply missing a familiar face, the Nexus Ball brings your PC-deposited creatures closer than ever before.
---
## More than connection. Companionship.
The Nexus ecosystem introduces a new generation of remote care and interaction features, including:
- Live Well-being Monitoring: Keep track of your creature's happiness, mood, and general condition.
- Interactive Viewports: Allow your creature to experience glimpses of the world around you and interact with their surroundings through the Nexus interface.
- Nexus BattleLink: Challenge friends to battles within specially developed digital battle environments. Battle from home, on the train, or wherever your connection allows, without the need for traditional post-battle healing.
- Seamless PC Integration: Connect with your existing creature Collection System to access and interact with eligible deposited creatures.
---
## Designed with creature safety in mind.
The Nexus Ball was developed with one principle above all others: creature well-being comes first.
---
While early demonstrations led some Trainers to believe the Nexus Ball could function as a conventional release device, this is not the case.
Its specialized containment and interface components are designed exclusively for remote observation, interaction, and digital battle participation. Attempting to release a creature through the Nexus interface could compromise the integrity of its digitized state and is therefore not supported.
---
The Nexus Ball is not a replacement for traditional travel, responsible creature care, or the bond shared between Trainer and creature.
## It is a new way to nurture that bond when circumstances keep you apart.
---
> Capsule Link × Capsule Link Network
## Together, across any distance.`;

/** Text → [{ kicker, blocks: [{ kind: 'title'|'p'|'li', text, label }] }] */
export function parseIntro(text) {
  return String(text || DEFAULT_INTRO).split(/^\s*---\s*$/m).map((chunk) => {
    const slide = { kicker: '', blocks: [] };
    for (const raw of chunk.split('\n')) {
      const line = raw.trim();
      if (!line) continue;
      if (line.startsWith('> ')) slide.kicker = line.slice(2);
      else if (line.startsWith('## ')) slide.blocks.push({ kind: 'title', text: line.slice(3) });
      else if (line.startsWith('- ')) {
        const m = /^-\s+([^:]{2,40}):\s+(.*)$/.exec(line);
        slide.blocks.push(m ? { kind: 'li', label: m[1], text: m[2] } : { kind: 'li', text: line.slice(2) });
      } else slide.blocks.push({ kind: 'p', text: line });
    }
    return slide;
  }).filter((s) => s.kicker || s.blocks.length);
}

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const reduced = () => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; } };

/**
 * Play the introduction inside `host` (it fills the host). Resolves after the last slide.
 * opts: { text, bank, accent }
 */
export function playIntro(host, { text = '', accent = '#3b6cf6' } = {}) {
  return new Promise((resolve) => {
    const slides = parseIntro(text);
    let i = 0, busy = false;
    const stage = h('div', { class: 'intro-stage' });
    const dots = h('div', { class: 'intro-dots', 'aria-hidden': 'true' });
    const next = h('button', { class: 'intro-next', id: 'intro-next' }, 'Next');
    const root = h('div', { class: 'intro-show', role: 'dialog', 'aria-label': brandText('Introducing the Nexus Ball'), style: { '--intro-accent': accent } },
      h('div', { class: 'intro-glow', 'aria-hidden': 'true' }, h('i'), h('i')),
      stage,
      h('div', { class: 'intro-foot' }, dots, next));
    mount(host, root);

    function art(k) {
      if (k === 0) {
        const ball = h('div', { class: 'intro-ball' }, capsuleCanvas({ ring: '#7dffcf', lit: true }, 9));
        return h('div', { class: 'intro-art' }, h('div', { class: 'intro-halo' }), ball);
      }
      if (k === slides.length - 1) return h('div', { class: 'intro-art small' }, logoMark(64));
      return null;
    }

    function slideEl(s, k) {
      const list = s.blocks.filter((b) => b.kind === 'li');
      const long = s.blocks.reduce((n, b) => n + b.text.length, 0) > 380 || list.length > 2;
      return h('div', { class: `intro-slide ${k === 0 ? 'first' : ''} ${k === slides.length - 1 ? 'last' : ''} ${long ? 'long' : ''}` },
        art(k),
        s.kicker ? h('div', { class: 'intro-kicker' }, s.kicker) : null,
        s.blocks.map((b) => (b.kind === 'title' ? h('h1', null, b.text)
          : b.kind === 'li' ? null
            : h('p', null, b.text))),
        list.length ? h('ul', { class: 'intro-list' }, list.map((b) => h('li', null, b.label ? [h('b', null, b.label), h('span', null, b.text)] : b.text))) : null);
    }

    async function show(k, first = false) {
      busy = true;
      const old = stage.firstChild;
      if (old && !first) {
        old.classList.add('out');
        await wait(reduced() ? 0 : 260);
      }
      const el = slideEl(slides[k], k);
      mount(stage, el);
      mount(dots, slides.map((_, j) => h('i', { class: j === k ? 'on' : j < k ? 'past' : '' })));
      next.textContent = brandText(k === slides.length - 1 ? 'Get started' : 'Next');
      void el.offsetWidth;
      el.classList.add('in');
      busy = false;
    }

    async function advance() {
      if (busy) return;
      sfx('move');
      if (i >= slides.length - 1) {
        root.classList.add('leaving');
        window.removeEventListener('keydown', onKey);
        await wait(reduced() ? 0 : 600);
        sfx('access');
        resolve();
        return;
      }
      i++;
      await show(i);
    }
    const onKey = (e) => { if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowRight') { e.preventDefault(); advance(); } };
    next.addEventListener('click', advance);
    window.addEventListener('keydown', onKey);
    show(0, true);
    setTimeout(() => next.focus({ preventScroll: true }), 50);
  });
}
