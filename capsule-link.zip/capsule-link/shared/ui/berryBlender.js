// The Berry Blender (as in Ruby, Sapphire and Emerald): 2–4 trainers, one creature and one berry each.
// The arrow in the middle spins; press when it passes your station. Perfect and Good speed the blender up,
// a Miss slows it down. The faster it got, the stronger the Pokéblock everyone takes home.
//
// Online, the trainer with the blender hosts: their app runs the spin and tells the others (through the
// friends server's play rooms) where the arrow is; everyone judges their own presses and sends the result.
// Helpers (like the games' blender regulars) can fill empty stations, so you can also practise alone.
//
// All sounds are made here with Web Audio (no game files): the motor's whirr rises with the speed, a bright
// chime for Perfect, a blip for Good, a buzz for a Miss, and a little tune whose tempo follows the RPM.
import { h, mount, toast, chooseDialog } from './dom.js';
import { audioOut, sfx } from './audio.js';
import { spriteCanvas } from './art.js';
import { blenderRpm, blendPokeblock, berryBlend, addPokeblock, BLOCK_COLORS, FLAVORS, RPM_MIN, RPM_DECAY } from '../engine/pokeblocks.js';
import { isBerry } from '../engine/foods.js';
import { itemInfo, displayName } from '../engine/index.js';

const SEAT_ANGLES = [-135, -45, 45, 135].map((d) => (d * Math.PI) / 180); // top-left, top-right, bottom-right, bottom-left
const SEAT_COLORS = ['#e8424a', '#3a7ae8', '#3cb85a', '#f2c23a'];
const PERFECT = 9, GOOD = 24, WINDOW = 60; // degrees either side of your station
const HELPERS = [
  ['Blend Master', 'cheri', 'Cheri Berry', '#e8424a'], ['Kid Mia', 'pecha', 'Pecha Berry', '#f48ac0'],
  ['Old Man Taro', 'rawst', 'Rawst Berry', '#3cb85a'], ['Miss Ayumi', 'chesto', 'Chesto Berry', '#3a6ae8'], ['Hiker Bo', 'aspear', 'Aspear Berry', '#f2d23a'],
];
const revPerSec = (rpm) => 0.12 + (rpm / 100) * 0.55;
const progPerSec = (rpm) => 0.014 + rpm * 0.00018;
const wrap = (a) => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };

// ---------- picking what you bring ----------
async function pickCreature(app, prefer = null) {
  const all = Object.values(app.save.creatures).filter((c) => !c.egg);
  const order = (c) => (c.location?.kind === 'party' ? 0 : prefer && c.location?.kind === prefer.kind && (prefer.kind === 'ranch' || c.location.box === prefer.box) ? 1 : 2);
  all.sort((a, b) => order(a) - order(b));
  return chooseDialog('Who comes to the blender?', all.slice(0, 400).map((c) => ({ value: c.uid, label: displayName(app.idx, c), detail: `Lv. ${c.level}`, el: spriteCanvas(app.bank, c, { scale: 1 }) })), { empty: 'Nobody to bring.' });
}
async function pickBerry(app) {
  const have = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && isBerry(itemInfo(app.idx, id))).map(([id, n]) => ({ it: itemInfo(app.idx, id), n }));
  return chooseDialog('Which berry goes in?', have.map(({ it, n }) => {
    const b = berryBlend(it);
    const fl = FLAVORS.filter((f) => b.flavors[f]).map((f) => `${f} ${b.flavors[f]}`).join(', ');
    return { value: it.id, label: it.name, detail: `${fl} · smooth ${b.smooth} · ${n} in the bag` };
  }), { empty: 'No berries in the bag. Grow some on the farm, find them on walks, or buy them at the Market.' });
}
const spriteUrl = (app, c) => { try { return spriteCanvas(app.bank, c, { scale: 1 }).toDataURL('image/png'); } catch { return null; } };
function seatFor(app, uid, berryId, who) {
  const c = app.save.creatures[uid], it = itemInfo(app.idx, berryId);
  const b = berryBlend(it);
  return { user: who, trainer: app.save.trainer?.name ?? who ?? 'You', mon: displayName(app.idx, c), uid, sprite: spriteUrl(app, c), berry: { id: it.id, name: it.name, color: it.color ?? '#c04a6a', flavors: b.flavors, smooth: b.smooth } };
}
function helperSeat(i, used) {
  const free = HELPERS.filter((x) => !used.includes(x[1]));
  const [trainer, id, name, color] = free[i % free.length];
  const b = berryBlend({ id, name });
  return { helper: true, trainer, mon: '', berry: { id, name, color, flavors: b.flavors, smooth: b.smooth } };
}

// ---------- the lobby ----------
/** Host a blend at your Berry Blender. */
export async function hostBerryBlender(app, { session = null, yardKey = null } = {}) {
  const S = session;
  const online = S?.signedIn?.() ? (S.friends?.friends ?? []).filter((f) => f.online) : [];
  const uid = await pickCreature(app, yardKey == null ? null : yardKey === 'ranch' ? { kind: 'ranch' } : { kind: 'box', box: yardKey }); if (!uid) return;
  const berryId = await pickBerry(app); if (!berryId) return;
  const me = seatFor(app, uid, berryId, S?.client?.token ? (S.acct?.username ?? 'me') : 'me');
  let room = null, seats = [me], helpers = 0, closed = false;
  const offs = [];
  const scrim = h('div', { class: 'bb-scrim' });
  const box = h('div', { class: 'panel bb-lobby' });
  scrim.append(box); document.body.append(scrim);
  const leave = () => { closed = true; offs.forEach((f) => f()); if (room) S.client.leaveRoom(room.id).catch(() => {}); scrim.remove(); };
  const send = (data, to) => room && S.client.roomSend(room.id, data, to);
  const lobbyMsg = () => send({ t: 'lobby', seats: seats.map((s) => ({ ...s, sprite: null })), helpers });
  if (S?.client) offs.push(S.client.onRoom((m) => {
    if (!room || m.id !== room.id) return;
    const d = m.data ?? {};
    if (d.t === 'hello') lobbyMsg();
    if (d.t === 'pick' && seats.length < 4) {
      seats = seats.filter((s) => s.user !== m.from).concat([{ ...d.seat, user: m.from }]);
      if (seats.length + helpers > 4) helpers = Math.max(0, 4 - seats.length);
      sfx('access'); lobbyMsg(); render();
    }
  }));
  if (S) offs.push(S.on((n) => { if ((n.what === 'room-leave') && room && n.id === room.id) { seats = seats.filter((s) => s.user !== n.from); lobbyMsg(); render(); } if (n.what === 'refresh') render(); }));
  function render() {
    if (closed) return;
    const total = seats.length + helpers;
    mount(box,
      h('div', { class: 'panel-title' }, h('h1', null, 'Berry Blender')),
      h('p', { class: 'dim' }, 'Everyone brings one creature and one berry. When the spinning arrow passes your station, press! Faster blending makes better Pokéblocks.'),
      h('div', { class: 'bb-seats' }, [0, 1, 2, 3].map((i) => {
        const s = seats[i] ?? (i < total ? helperSeat(i - seats.length, seats.map((x) => x.berry.id)) : null);
        return h('div', { class: `bb-seat ${s ? '' : 'empty'}`, style: { borderColor: SEAT_COLORS[i] } },
          s ? [h('b', null, s.trainer), h('span', { class: 'dim' }, s.mon || 'helper'), h('span', { class: 'bb-berry', style: { background: s.berry.color } }), h('small', null, s.berry.name)] : h('span', { class: 'dim' }, 'empty'));
      })),
      S?.signedIn?.() ? [
        h('div', { class: 'ranch-group-head' }, room ? 'Invited — they join from the invite that pops up' : 'Invite friends who are online'),
        room ? null : online.length ? h('div', { class: 'col' }, online.map((f) => h('label', { class: 'row' }, h('input', { type: 'checkbox', class: 'bb-inv', value: f.username }), h('span', null, `${f.trainerName} (${f.username})`))))
          : h('p', { class: 'dim' }, 'None of your friends are online right now. You can still practise with helpers.'),
        room ? null : h('button', { class: 'btn', disabled: !online.length, onclick: async () => {
          const to = [...box.querySelectorAll('.bb-inv:checked')].map((x) => x.value);
          if (!to.length) { toast('Tick at least one friend.', 'err'); return; }
          try { room = (await S.client.openRoom('blender', to, 4)).room; sfx('access'); toast('Invites sent!', 'ok'); render(); } catch (e) { toast(e.message, 'err'); }
        } }, 'Send invites')] : h('p', { class: 'dim' }, 'Sign in to a friends server (Friends app) to blend with friends. Helpers can fill in meanwhile.'),
      h('div', { class: 'row wrap' },
        h('span', { class: 'grow dim' }, 'Helpers:'),
        h('button', { class: 'btn small', disabled: helpers <= 0, onclick: () => { helpers--; lobbyMsg(); render(); } }, '−'),
        h('span', null, String(helpers)),
        h('button', { class: 'btn small', disabled: total >= 4, onclick: () => { helpers++; lobbyMsg(); render(); } }, '+')),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', onclick: leave }, 'Cancel'),
        h('button', { class: 'btn primary', disabled: total < 2, title: total < 2 ? 'Two or more at the blender (friends or helpers)' : '', onclick: () => {
          const all = [...seats];
          for (let i = 0; i < helpers; i++) all.push(helperSeat(i, all.map((x) => x.berry.id)));
          if (room) S.client.startRoom(room.id).catch(() => {});
          // everyone takes their own berry out of the bag when it starts
          app.commit((s) => { s.inventory[berryId] = Math.max(0, (s.inventory[berryId] ?? 0) - 1); }, 'blend', { quiet: true });
          send({ t: 'start', seats: all.map((s) => ({ ...s })) });
          box.remove();
          play(app, { scrim, seats: all, mySeat: 0, host: true, send, onRoom: S?.client ? (fn) => S.client.onRoom((m) => { if (room && m.id === room.id) fn(m); }) : null, done: () => { offs.forEach((f) => f()); if (room) S.client.leaveRoom(room.id).catch(() => {}); } });
        } }, 'Start blending!')));
  }
  render();
}

/** Join a friend's blend (from their invite). */
export async function joinBerryBlender(app, session, roomId) {
  const S = session;
  let room;
  try { room = (await S.client.joinRoom(roomId)).room; } catch (e) { toast(e.message, 'err'); return; }
  const uid = await pickCreature(app); if (!uid) { S.client.leaveRoom(roomId).catch(() => {}); return; }
  const berryId = await pickBerry(app); if (!berryId) { S.client.leaveRoom(roomId).catch(() => {}); return; }
  const meName = S.acct?.username ?? 'me';
  const mine = seatFor(app, uid, berryId, meName);
  const scrim = h('div', { class: 'bb-scrim' });
  const box = h('div', { class: 'panel bb-lobby' });
  scrim.append(box); document.body.append(scrim);
  let lobby = { seats: [], helpers: 0 }, started = false;
  const send = (data) => S.client.roomSend(room.id, data);
  const offs = [];
  const quit = () => { offs.forEach((f) => f()); S.client.leaveRoom(room.id).catch(() => {}); scrim.remove(); };
  const render = () => mount(box,
    h('div', { class: 'panel-title' }, h('h1', null, `${room.hostName}’s Berry Blender`)),
    h('p', { class: 'dim' }, 'Waiting for the host to start…'),
    h('div', { class: 'bb-seats' }, [0, 1, 2, 3].map((i) => { const s = lobby.seats[i]; return h('div', { class: `bb-seat ${s ? '' : 'empty'}`, style: { borderColor: SEAT_COLORS[i] } }, s ? [h('b', null, s.trainer), h('span', { class: 'dim' }, s.mon || 'helper'), h('span', { class: 'bb-berry', style: { background: s.berry.color } }), h('small', null, s.berry.name)] : h('span', { class: 'dim' }, i < lobby.seats.length + lobby.helpers ? 'helper' : 'empty')); })),
    h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: quit }, 'Leave')));
  offs.push(S.client.onRoom((m) => {
    if (m.id !== room.id || started) return;
    const d = m.data ?? {};
    if (d.t === 'lobby') { lobby = d; render(); }
    if (d.t === 'start') {
      started = true;
      const idx = d.seats.findIndex((s) => s.user === meName);
      if (idx < 0) { toast('The blender was full.', 'err'); quit(); return; }
      app.commit((s) => { s.inventory[berryId] = Math.max(0, (s.inventory[berryId] ?? 0) - 1); }, 'blend', { quiet: true });
      box.remove();
      play(app, { scrim, seats: d.seats, mySeat: idx, host: false, send, onRoom: (fn) => S.client.onRoom((mm) => { if (mm.id === room.id) fn(mm); }), done: () => { offs.forEach((f) => f()); S.client.leaveRoom(room.id).catch(() => {}); } });
    }
  }));
  offs.push(S.on((n) => { if (n.what === 'room-closed' && n.id === room.id && !started) { toast(`${room.hostName} closed the blender.`, 'err'); quit(); } }));
  render();
  send({ t: 'pick', seat: mine });
  send({ t: 'hello' });
  const again = setInterval(() => { if (started || !scrim.isConnected) { clearInterval(again); return; } send({ t: 'pick', seat: mine }); }, 3000);
}

// ---------- the game ----------
function play(app, { scrim, seats, mySeat, host, send, onRoom, done }) {
  const cv = h('canvas', { class: 'bb-canvas', width: 720, height: 720 });
  const hint = h('div', { class: 'bb-hint' }, 'Press Space, click or tap when the arrow reaches your station!');
  const quitBtn = h('button', { class: 'btn small bb-quit', onclick: () => end(true) }, 'Leave');
  const stage = h('div', { class: 'bb-stage' }, cv, hint, quitBtn);
  scrim.append(stage);
  const g = cv.getContext('2d');
  const imgs = seats.map((s) => { if (!s.sprite) return null; const im = new Image(); im.src = s.sprite; return im; });
  const st = { a: -Math.PI / 2, rpm: 20, maxRpm: 20, prog: 0, t: 0, phase: 'count', count: 3.2, over: false };
  const tally = seats.map(() => ({ perfect: 0, good: 0, miss: 0 }));
  const judged = seats.map(() => false); // one judged press per pass of the arrow
  const pops = []; // hit markers flying off stations
  const bounce = seats.map(() => 0);
  const helperPlan = seats.map(() => null);
  let last = performance.now(), raf = 0, lastSend = 0, result = null;
  const audio = blenderAudio();

  const hitAt = (seat, q) => {
    tally[seat][q]++;
    pops.push({ seat, q, t: 0 });
    bounce[seat] = 1;
    if (q !== 'miss') bounce[seat] = 1.4;
    audio.hit(q, seat === mySeat);
    if (host) { st.rpm = blenderRpm(st.rpm, q, seats.length); st.maxRpm = Math.max(st.maxRpm, st.rpm); }
  };
  const press = () => {
    if (st.phase !== 'go') return;
    const d = (wrap(st.a - SEAT_ANGLES[mySeat]) * 180) / Math.PI;
    if (Math.abs(d) > WINDOW || judged[mySeat]) return;
    judged[mySeat] = true;
    const q = Math.abs(d) <= PERFECT ? 'perfect' : Math.abs(d) <= GOOD ? 'good' : 'miss';
    hitAt(mySeat, q);
    if (!host) send({ t: 'hit', seat: mySeat, q });
  };
  const onKey = (e) => { if (e.code === 'Space' || e.key === 'Enter' || e.key === 'a' || e.key === 'A') { e.preventDefault(); press(); } if (e.key === 'Escape') end(true); };
  cv.addEventListener('pointerdown', (e) => { e.preventDefault(); press(); });
  document.addEventListener('keydown', onKey);
  const unRoom = onRoom?.((m) => {
    const d = m.data ?? {};
    if (host && d.t === 'hit' && seats[d.seat]?.user === m.from && st.phase === 'go') { hitAt(d.seat, d.q); send({ t: 'h', seat: d.seat, q: d.q }); }
    if (!host && d.t === 's') {
      // follow the host's blender: speed and progress directly, the arrow eased in so it doesn't jump
      st.rpm = d.rpm; st.maxRpm = Math.max(st.maxRpm, d.rpm); st.prog = d.prog; st.phase = d.phase; st.count = d.count;
      st.a += wrap(d.a - st.a) * 0.5;
    }
    if (!host && d.t === 'h' && d.seat !== mySeat) hitAt(d.seat, d.q);
    if (!host && d.t === 'end') finish(d.block, d.tally, d.maxRpm);
    if (d.t === 'bye' && m.from === seats[0]?.user && !host && !result) { toast('The host left the blender.', 'err'); end(true); }
  });

  function helperTurns(dt) {
    seats.forEach((s, i) => {
      if (!s.helper) return;
      const d = (wrap(st.a - SEAT_ANGLES[i]) * 180) / Math.PI;
      if (d < -WINDOW || d > WINDOW) { judged[i] = false; helperPlan[i] = null; return; }
      if (judged[i]) return;
      if (!helperPlan[i]) { const r = Math.random(); helperPlan[i] = r < 0.5 ? (Math.random() * 2 - 1) * PERFECT * 0.9 : r < 0.86 ? (Math.random() < 0.5 ? -1 : 1) * (PERFECT + Math.random() * (GOOD - PERFECT)) : (Math.random() < 0.5 ? -1 : 1) * (GOOD + 2 + Math.random() * 20); }
      if (d >= helperPlan[i]) { judged[i] = true; const ad = Math.abs(d); const q = ad <= PERFECT ? 'perfect' : ad <= GOOD ? 'good' : 'miss'; hitAt(i, q); send?.({ t: 'h', seat: i, q }); }
    });
  }
  function tick(now) {
    const dt = Math.min(0.05, (now - last) / 1000); last = now; st.t += dt;
    if (st.phase === 'count') {
      const before = Math.ceil(st.count);
      if (host) st.count -= dt;
      if (Math.ceil(st.count) !== before && st.count > 0) audio.beep(false);
      if (st.count <= 0 && host) { st.phase = 'go'; audio.beep(true); }
    } else if (st.phase === 'go') {
      const prevA = st.a;
      st.a = wrap(st.a + revPerSec(st.rpm) * 2 * Math.PI * dt);
      // the arrow left a station: the next pass can be judged again
      seats.forEach((_, i) => { const d = (wrap(st.a - SEAT_ANGLES[i]) * 180) / Math.PI; if (d > WINDOW && !seats[i].helper) judged[i] = false; const d0 = (wrap(prevA - SEAT_ANGLES[i]) * 180) / Math.PI; if (d0 < 0 && d >= 0) audio.tick(); });
      if (host) {
        helperTurns(dt);
        st.rpm = Math.max(RPM_MIN, st.rpm - RPM_DECAY * dt);
        st.prog = Math.min(1, st.prog + progPerSec(st.rpm) * dt);
        if (st.prog >= 1) {
          st.phase = 'done';
          const block = blendPokeblock(seats.map((s) => s.berry), st.maxRpm);
          send?.({ t: 'end', block, tally, maxRpm: st.maxRpm });
          finish(block, tally, st.maxRpm);
        }
      }
    }
    if (host && now - lastSend > 90) { lastSend = now; send?.({ t: 's', a: st.a, rpm: st.rpm, prog: st.prog, phase: st.phase, count: st.count }); }
    audio.motor(st.phase === 'go' ? st.rpm : 0);
    draw(dt);
    if (!st.over) raf = requestAnimationFrame(tick);
  }

  function draw(dt) {
    const W = cv.width, H = cv.height, cx = W / 2, cy = H / 2 + 10, R = 250;
    g.clearRect(0, 0, W, H);
    // the table
    const bg = g.createRadialGradient(cx, cy, 60, cx, cy, 420); bg.addColorStop(0, '#4a5a7a'); bg.addColorStop(1, '#1a2032');
    g.fillStyle = bg; g.fillRect(0, 0, W, H);
    // the bowl: a thick rim, the juice swirling inside
    g.save(); g.translate(cx, cy);
    g.fillStyle = '#c8d0e0'; g.beginPath(); g.arc(0, 0, R + 26, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#8890a8'; g.beginPath(); g.arc(0, 0, R + 8, 0, Math.PI * 2); g.fill();
    const mix = mixColor(seats.map((s) => s.berry.color), st.prog);
    const juice = g.createRadialGradient(0, 0, 10, 0, 0, R); juice.addColorStop(0, '#ffffff'); juice.addColorStop(0.25, mix); juice.addColorStop(1, shade(mix, -0.35));
    g.fillStyle = juice; g.beginPath(); g.arc(0, 0, R, 0, Math.PI * 2); g.fill();
    g.globalAlpha = 0.25; g.strokeStyle = '#fff'; g.lineWidth = 6;
    for (let i = 0; i < 6; i++) { g.beginPath(); g.arc(0, 0, 40 + i * 36, st.a * (1 + i * 0.3) + i, st.a * (1 + i * 0.3) + i + 1.4); g.stroke(); }
    g.globalAlpha = 1;
    // stations: each trainer's coloured marker on the rim, with their creature behind it
    seats.forEach((s, i) => {
      const ang = SEAT_ANGLES[i], sx = Math.cos(ang) * (R + 17), sy = Math.sin(ang) * (R + 17);
      g.save(); g.translate(sx, sy); g.rotate(ang + Math.PI / 2);
      g.fillStyle = SEAT_COLORS[i]; g.beginPath(); g.moveTo(0, 22); g.lineTo(-20, -14); g.lineTo(20, -14); g.closePath(); g.fill();
      g.strokeStyle = i === mySeat ? '#fff' : 'rgba(0,0,0,.4)'; g.lineWidth = i === mySeat ? 4 : 2; g.stroke();
      g.restore();
      // the window where a press counts (only your own is shown)
      if (i === mySeat && st.phase !== 'done') {
        g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 14; g.beginPath(); g.arc(0, 0, R - 10, ang - (GOOD * Math.PI) / 180, ang + (GOOD * Math.PI) / 180); g.stroke();
        g.strokeStyle = 'rgba(255,240,120,.8)'; g.beginPath(); g.arc(0, 0, R - 10, ang - (PERFECT * Math.PI) / 180, ang + (PERFECT * Math.PI) / 180); g.stroke();
      }
    });
    // the spinner: a hub with one long arrow
    g.save(); g.rotate(st.a);
    g.fillStyle = '#f4f4f8'; g.strokeStyle = '#2a2a3a'; g.lineWidth = 4;
    g.beginPath(); g.moveTo(-30, -14); g.lineTo(R - 44, -14); g.lineTo(R - 44, -30); g.lineTo(R - 4, 0); g.lineTo(R - 44, 30); g.lineTo(R - 44, 14); g.lineTo(-30, 14); g.closePath(); g.fill(); g.stroke();
    g.fillStyle = '#e8424a'; g.beginPath(); g.moveTo(R - 40, -22); g.lineTo(R - 10, 0); g.lineTo(R - 40, 22); g.closePath(); g.fill();
    g.restore();
    g.fillStyle = '#2a2a3a'; g.beginPath(); g.arc(0, 0, 58, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#ffd23f'; g.beginPath(); g.arc(0, 0, 48, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#2a2a3a'; g.font = 'bold 15px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('RPM', 0, -12);
    g.font = 'bold 19px ui-monospace, monospace'; g.fillText(st.rpm.toFixed(2), 0, 10);
    g.restore();
    // trainers and their creatures in the corners
    seats.forEach((s, i) => {
      const ang = SEAT_ANGLES[i], px = cx + Math.cos(ang) * 350, py = cy + Math.sin(ang) * 330;
      bounce[i] = Math.max(0, bounce[i] - dt * 4);
      const hop = Math.sin(Math.min(1, bounce[i]) * Math.PI) * 14;
      if (imgs[i]?.complete && imgs[i].naturalWidth) { g.imageSmoothingEnabled = false; const sz = 72; g.drawImage(imgs[i], px - sz / 2, py - sz / 2 - hop - 8, sz, sz); }
      else { g.fillStyle = SEAT_COLORS[i]; g.beginPath(); g.arc(px, py - hop, 16, 0, Math.PI * 2); g.fill(); }
      g.font = 'bold 14px system-ui, sans-serif'; g.textAlign = 'center'; g.fillStyle = '#fff';
      g.fillText(s.trainer, px, py + (py < cy ? -66 : 46));
      g.fillStyle = 'rgba(255,255,255,.7)'; g.font = '12px system-ui, sans-serif';
      g.fillText(`${tally[i].perfect}◎ ${tally[i].good}○ ${tally[i].miss}×`, px, py + (py < cy ? -50 : 62));
    });
    // hit markers
    for (let k = pops.length - 1; k >= 0; k--) {
      const p = pops[k]; p.t += dt; if (p.t > 0.9) { pops.splice(k, 1); continue; }
      const ang = SEAT_ANGLES[p.seat], px = cx + Math.cos(ang) * (R - 50 - p.t * 40), py = cy + Math.sin(ang) * (R - 50 - p.t * 40);
      g.globalAlpha = 1 - p.t / 0.9;
      g.lineWidth = 5;
      if (p.q === 'miss') { g.strokeStyle = '#3a7ae8'; g.beginPath(); g.moveTo(px - 12, py - 12); g.lineTo(px + 12, py + 12); g.moveTo(px + 12, py - 12); g.lineTo(px - 12, py + 12); g.stroke(); }
      else { g.strokeStyle = '#e8424a'; g.beginPath(); g.arc(px, py, 14, 0, Math.PI * 2); g.stroke(); if (p.q === 'perfect') { g.beginPath(); g.arc(px, py, 7, 0, Math.PI * 2); g.stroke(); } }
      g.globalAlpha = 1;
    }
    // the progress bar along the top
    g.fillStyle = 'rgba(0,0,0,.5)'; g.fillRect(140, 16, W - 280, 16);
    g.fillStyle = '#3cd06a'; g.fillRect(142, 18, (W - 284) * st.prog, 12);
    if (st.phase === 'count' && st.count > 0) {
      g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(0, 0, W, H);
      g.fillStyle = '#fff'; g.font = 'bold 120px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(String(Math.ceil(st.count)), cx, cy);
    }
  }

  function finish(block, tal, maxRpm) {
    if (result) return;
    result = block;
    st.phase = 'done';
    audio.fanfare();
    let mine = null;
    app.commit((s) => { mine = addPokeblock(s, block); }, 'pokeblock', { quiet: true });
    const order = seats.map((s, i) => ({ s, i, t: tal[i] })).sort((a, b) => b.t.perfect - a.t.perfect || b.t.good - a.t.good || a.t.miss - b.t.miss);
    const [cname, col] = BLOCK_COLORS[block.color];
    const card = h('div', { class: 'panel bb-result' },
      h('div', { class: 'panel-title' }, h('h1', null, 'Blending done!')),
      h('p', null, `Top speed: ${maxRpm.toFixed(2)} RPM`),
      h('ol', { class: 'bb-rank' }, order.map((o) => h('li', null, h('b', { style: { color: SEAT_COLORS[o.i] } }, o.s.trainer), ` — ${o.t.perfect} ◎ · ${o.t.good} ○ · ${o.t.miss} ×`))),
      h('div', { class: 'bb-block' }, h('span', { class: 'bb-cube', style: { background: col } }),
        h('div', { class: 'col' }, h('b', null, `${cname} Pokéblock`), h('span', null, `Level ${block.level} · Feel ${block.feel}`),
          h('small', { class: 'dim' }, FLAVORS.filter((f) => block.flavors[f]).map((f) => `${f[0].toUpperCase()}${f.slice(1)} ${block.flavors[f]}`).join(' · ') || 'No flavour at all'))),
      h('p', { class: 'dim' }, mine ? 'It went in your Pokéblock Case. Give it to a creature from the ranch (right-click them → Give a Pokéblock).' : ''),
      h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: () => end(false) }, 'Done')));
    stage.append(card);
  }
  function end(early) {
    if (st.over) return;
    st.over = true;
    cancelAnimationFrame(raf);
    audio.stop();
    document.removeEventListener('keydown', onKey);
    if (early) send?.({ t: 'bye' });
    unRoom?.();
    done?.();
    scrim.remove();
  }
  raf = requestAnimationFrame(tick);
}

// ---------- colours ----------
function hex(c) { const m = /^#?([0-9a-f]{6})$/i.exec(String(c)); const n = m ? parseInt(m[1], 16) : 0xc04a6a; return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function mixColor(cols, p) {
  const rgb = cols.map(hex);
  // berries start as separate swirls and become one colour as it blends
  const avg = [0, 1, 2].map((k) => Math.round(rgb.reduce((n, c) => n + c[k], 0) / rgb.length));
  const first = rgb[0];
  const m = [0, 1, 2].map((k) => Math.round(first[k] + (avg[k] - first[k]) * Math.min(1, p * 1.6)));
  return `rgb(${m.join(',')})`;
}
function shade(rgbStr, f) { const m = rgbStr.match(/\d+/g).map(Number); return `rgb(${m.map((v) => Math.max(0, Math.min(255, Math.round(v * (1 + f))))).join(',')})`; }

// ---------- sounds (all made here) ----------
function blenderAudio() {
  const A = audioOut();
  if (!A) return { hit() {}, motor() {}, beep() {}, tick() {}, fanfare() {}, stop() {} };
  const { ctx, out } = A;
  const bus = ctx.createGain(); bus.gain.value = 0.9; bus.connect(out);
  // the motor: a buzzy saw through a low-pass filter, pitch and brightness rising with the RPM
  const motor = ctx.createOscillator(), motor2 = ctx.createOscillator(), lp = ctx.createBiquadFilter(), mg = ctx.createGain();
  motor.type = 'sawtooth'; motor2.type = 'square'; lp.type = 'lowpass'; lp.frequency.value = 300; mg.gain.value = 0;
  motor.connect(lp); motor2.connect(lp); lp.connect(mg); mg.connect(bus);
  motor.start(); motor2.start();
  const note = (t, f, d, { type = 'square', gain = 0.22, slide = 0 } = {}) => {
    const o = ctx.createOscillator(), gg = ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t); if (slide) o.frequency.exponentialRampToValueAtTime(f * slide, t + d);
    gg.gain.setValueAtTime(0.0001, t); gg.gain.exponentialRampToValueAtTime(gain, t + 0.006); gg.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(gg); gg.connect(bus); o.start(t); o.stop(t + d + 0.02);
  };
  // a little looping tune of our own: bass and arpeggio, tempo following the speed
  const SCALE = [0, 2, 4, 7, 9, 12, 14, 16];
  const BASS = [0, 0, 5, 5, 3, 3, 4, 4], ARP = [0, 2, 4, 2, 5, 4, 2, 1, 0, 2, 4, 5, 7, 5, 4, 2];
  let rpmNow = 0, step = 0, nextAt = ctx.currentTime + 0.1, running = true;
  const mid = (n) => 440 * 2 ** ((n - 69) / 12);
  const timer = setInterval(() => {
    if (!running) return;
    while (nextAt < ctx.currentTime + 0.15) {
      if (rpmNow > 0) {
        const bar = Math.floor(step / 8) % BASS.length;
        if (step % 2 === 0) note(nextAt, mid(45 + SCALE[BASS[bar]]), 0.16, { type: 'triangle', gain: 0.28 });
        note(nextAt, mid(69 + SCALE[ARP[step % ARP.length] % SCALE.length] + (ARP[step % ARP.length] >= SCALE.length ? 12 : 0)), 0.07, { type: 'square', gain: 0.06 });
      }
      step++;
      nextAt += 60 / (110 + Math.min(120, rpmNow * 0.8)) / 2; // eighth notes, faster as it spins up
    }
  }, 40);
  return {
    motor(rpm) {
      rpmNow = rpm;
      const t = ctx.currentTime;
      motor.frequency.setTargetAtTime(30 + rpm * 1.1, t, 0.08);
      motor2.frequency.setTargetAtTime(60 + rpm * 2.3, t, 0.08);
      lp.frequency.setTargetAtTime(200 + rpm * 14, t, 0.1);
      mg.gain.setTargetAtTime(rpm > 0 ? 0.05 + Math.min(0.08, rpm / 1500) : 0, t, 0.1);
    },
    hit(q, mine) {
      const t = ctx.currentTime + 0.005, v = mine ? 1 : 0.55;
      if (q === 'perfect') { note(t, 1319, 0.09, { gain: 0.22 * v }); note(t + 0.07, 1976, 0.16, { gain: 0.22 * v }); note(t + 0.07, 2637, 0.12, { type: 'triangle', gain: 0.1 * v }); }
      else if (q === 'good') note(t, 1047, 0.11, { gain: 0.2 * v });
      else { note(t, 180, 0.22, { type: 'sawtooth', gain: 0.2 * v, slide: 0.6 }); }
    },
    tick() { note(ctx.currentTime, 2200, 0.02, { type: 'square', gain: 0.03 }); },
    beep(go) { const t = ctx.currentTime; note(t, go ? 1568 : 784, go ? 0.35 : 0.14, { gain: 0.25 }); },
    fanfare() {
      const t = ctx.currentTime + 0.05, seq = [[72, 0.12], [76, 0.12], [79, 0.12], [84, 0.36], [79, 0.12], [84, 0.5]];
      let at = t; for (const [n, d] of seq) { note(at, mid(n), d, { gain: 0.2 }); note(at, mid(n - 12), d, { type: 'triangle', gain: 0.15 }); at += d; }
    },
    stop() { running = false; clearInterval(timer); try { mg.gain.setTargetAtTime(0, ctx.currentTime, 0.05); setTimeout(() => { motor.stop(); motor2.stop(); bus.disconnect(); }, 400); } catch { /* already stopped */ } },
  };
}

/** Feed a Pokéblock from the case (a chooser), for the ranch menus. */
export async function chooseBlock(app, c) {
  const blocks = app.save.pokeblocks ?? [];
  return chooseDialog(`A Pokéblock for ${displayName(app.idx, c)}`, blocks.map((b) => ({ value: b.id, label: `${b.name} · Lv. ${b.level}`,
    detail: `Feel ${b.feel} · ${FLAVORS.filter((f) => b.flavors[f]).map((f) => `${f} ${b.flavors[f]}`).join(', ')}`,
    el: h('span', { class: 'bb-cube small', style: { background: BLOCK_COLORS[b.color]?.[1] } }) })), { empty: 'Your Pokéblock Case is empty. Make some at a Berry Blender (Market → Machines).' });
}
