// The Berry Blender (as in Ruby, Sapphire and Emerald): 2–4 trainers, one creature and one berry each.
// The arrow in the middle spins; press when it passes your station. Perfect and Good speed the blender up,
// a Miss slows it down. The faster it got, the stronger the Pokéblock everyone takes home.
//
// Online, the trainer with the blender hosts: their app runs the spin and tells the others (through the
// friends server's play rooms) where the arrow is; everyone judges their own presses and sends the result.
// Helpers (like the games' blender regulars) can fill empty stations, so you can also practise alone.
//
// All sounds are made here with Web Audio (no game files): the motor's whirr rises with the speed, a bright
// chime for Perfect, a blip for Good, a buzz for a Miss, and a little tune whose tempo follows the RPM.
import { h, mount, toast, chooseDialog } from './dom.js';
import { audioOut, sfx } from './audio.js';
import { spriteCanvas } from './art.js';
import { blenderRpm, blendPokeblock, berryBlend, addPokeblock, BLOCK_COLORS, FLAVORS, RPM_MIN, RPM_DECAY } from '../engine/pokeblocks.js';
import { isBerry } from '../engine/foods.js';
import { itemInfo, displayName } from '../engine/index.js';

const SEAT_ANGLES = [-135, -45, 45, 135].map((d) => (d * Math.PI) / 180); // top-left, top-right, bottom-right, bottom-left
const SEAT_COLORS = ['#e8424a', '#3a7ae8', '#3cb85a', '#f2c23a'];
const PERFECT = 9, GOOD = 24, WINDOW = 60; // degrees either side of your station
const HELPERS = [
  ['Blend Master', 'cheri', 'Cheri Berry', '#e8424a'], ['Kid Mia', 'pecha', 'Pecha Berry', '#f48ac0'],
  ['Old Man Taro', 'rawst', 'Rawst Berry', '#3cb85a'], ['Miss Ayumi', 'chesto', 'Chesto Berry', '#3a6ae8'], ['Hiker Bo', 'aspear', 'Aspear Berry', '#f2d23a'],
];
const revPerSec = (rpm) => 0.12 + (rpm / 100) * 0.55;
const progPerSec = (rpm) => 0.014 + rpm * 0.00018;
const wrap = (a) => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };

// ---------- picking what you bring ----------
async function pickCreature(app, prefer = null) {
  const all = Object.values(app.save.creatures).filter((c) => !c.egg && c.location?.kind !== 'game');
  const order = (c) => (c.location?.kind === 'party' ? 0 : prefer && c.location?.kind === prefer.kind && (prefer.kind === 'ranch' || c.location.box === prefer.box) ? 1 : 2);
  all.sort((a, b) => order(a) - order(b));
  return chooseDialog('Who comes to the blender?', all.slice(0, 400).map((c) => ({ value: c.uid, label: displayName(app.idx, c), detail: `Lv. ${c.level}`, el: spriteCanvas(app.bank, c, { scale: 1 }) })), { empty: 'Nobody to bring.' });
}
async function pickBerry(app) {
  const have = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && isBerry(itemInfo(app.idx, id))).map(([id, n]) => ({ it: itemInfo(app.idx, id), n }));
  return chooseDialog('Which berry goes in?', have.map(({ it, n }) => {
    const b = berryBlend(it);
    const fl = FLAVORS.filter((f) => b.flavors[f]).map((f) => `${f} ${b.flavors[f]}`).join(', ');
    return { value: it.id, label: it.name, detail: `${fl} · smooth ${b.smooth} · ${n} in the bag` };
  }), { empty: 'No berries in the bag. Grow some on the farm, find them on walks, or buy them at the Market.' });
}
const spriteUrl = (app, c) => { try { return spriteCanvas(app.bank, c, { scale: 1 }).toDataURL('image/png'); } catch { return null; } };
function seatFor(app, uid, berryId, who) {
  const c = app.save.creatures[uid], it = itemInfo(app.idx, berryId);
  const b = berryBlend(it);
  return { user: who, trainer: app.save.trainer?.name ?? who ?? 'You', mon: displayName(app.idx, c), uid, sprite: spriteUrl(app, c), berry: { id: it.id, name: it.name, color: it.color ?? '#c04a6a', flavors: b.flavors, smooth: b.smooth } };
}
function helperSeat(i, used) {
  const free = HELPERS.filter((x) => !used.includes(x[1]));
  const [trainer, id, name, color] = free[i % free.length];
  const b = berryBlend({ id, name });
  return { helper: true, trainer, mon: '', berry: { id, name, color, flavors: b.flavors, smooth: b.smooth } };
}

// ---------- the lobby ----------
/** Host a blend at your Berry Blender. */
export async function hostBerryBlender(app, { session = null, yardKey = null } = {}) {
  const S = session;
  const online = S?.signedIn?.() ? (S.friends?.friends ?? []).filter((f) => f.online) : [];
  const uid = await pickCreature(app, yardKey == null ? null : yardKey === 'ranch' ? { kind: 'ranch' } : { kind: 'box', box: yardKey }); if (!uid) return;
  const berryId = await pickBerry(app); if (!berryId) return;
  const me = seatFor(app, uid, berryId, S?.client?.token ? (S.acct?.username ?? 'me') : 'me');
  let room = null, seats = [me], helpers = 0, closed = false;
  const offs = [];
  const scrim = h('div', { class: 'bb-scrim' });
  const box = h('div', { class: 'panel bb-lobby' });
  scrim.append(box); document.body.append(scrim);
  const leave = () => { closed = true; offs.forEach((f) => f()); if (room) S.client.leaveRoom(room.id).catch(() => {}); scrim.remove(); };
  const send = (data, to) => room && S.client.roomSend(room.id, data, to);
  const lobbyMsg = () => send({ t: 'lobby', seats: seats.map((s) => ({ ...s, sprite: null })), helpers });
  if (S?.client) offs.push(S.client.onRoom((m) => {
    if (!room || m.id !== room.id) return;
    const d = m.data ?? {};
    if (d.t === 'hello') lobbyMsg();
    if (d.t === 'pick' && seats.length < 4) {
      seats = seats.filter((s) => s.user !== m.from).concat([{ ...d.seat, user: m.from }]);
      if (seats.length + helpers > 4) helpers = Math.max(0, 4 - seats.length);
      sfx('access'); lobbyMsg(); render();
    }
  }));
  if (S) offs.push(S.on((n) => { if ((n.what === 'room-leave') && room && n.id === room.id) { seats = seats.filter((s) => s.user !== n.from); lobbyMsg(); render(); } if (n.what === 'refresh') render(); }));
  function render() {
    if (closed) return;
    const total = seats.length + helpers;
    mount(box,
      h('div', { class: 'panel-title' }, h('h1', null, 'Berry Blender')),
      h('p', { class: 'dim' }, 'Everyone brings one creature and one berry. When the spinning arrow passes your station, press! Faster blending makes better Pokéblocks.'),
      h('div', { class: 'bb-seats' }, [0, 1, 2, 3].map((i) => {
        const s = seats[i] ?? (i < total ? helperSeat(i - seats.length, seats.map((x) => x.berry.id)) : null);
        return h('div', { class: `bb-seat ${s ? '' : 'empty'}`, style: { borderColor: SEAT_COLORS[i] } },
          s ? [h('b', null, s.trainer), h('span', { class: 'dim' }, s.mon || 'helper'), h('span', { class: 'bb-berry', style: { background: s.berry.color } }), h('small', null, s.berry.name)] : h('span', { class: 'dim' }, 'empty'));
      })),
      S?.signedIn?.() ? [
        h('div', { class: 'ranch-group-head' }, room ? 'Invited — they join from the invite that pops up' : 'Invite friends who are online'),
        room ? null : online.length ? h('div', { class: 'col' }, online.map((f) => h('label', { class: 'row' }, h('input', { type: 'checkbox', class: 'bb-inv', value: f.username }), h('span', null, `${f.trainerName} (${f.username})`))))
          : h('p', { class: 'dim' }, 'None of your friends are online right now. You can still practise with helpers.'),
        room ? null : h('button', { class: 'btn', disabled: !online.length, onclick: async () => {
          const to = [...box.querySelectorAll('.bb-inv:checked')].map((x) => x.value);
          if (!to.length) { toast('Tick at least one friend.', 'err'); return; }
          try { room = (await S.client.openRoom('blender', to, 4)).room; sfx('access'); toast('Invites sent!', 'ok'); render(); } catch (e) { toast(e.message, 'err'); }
        } }, 'Send invites')] : h('p', { class: 'dim' }, 'Sign in to a friends server (Friends app) to blend with friends. Helpers can fill in meanwhile.'),
      h('div', { class: 'row wrap' },
        h('span', { class: 'grow dim' }, 'Helpers:'),
        h('button', { class: 'btn small', disabled: helpers <= 0, onclick: () => { helpers--; lobbyMsg(); render(); } }, '−'),
        h('span', null, String(helpers)),
        h('button', { class: 'btn small', disabled: total >= 4, onclick: () => { helpers++; lobbyMsg(); render(); } }, '+')),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', onclick: leave }, 'Cancel'),
        h('button', { class: 'btn primary', disabled: total < 2, title: total < 2 ? 'Two or more at the blender (friends or helpers)' : '', onclick: () => {
          const all = [...seats];
          for (let i = 0; i < helpers; i++) all.push(helperSeat(i, all.map((x) => x.berry.id)));
          if (room) S.client.startRoom(room.id).catch(() => {});
          // everyone takes their own berry out of the bag when it starts
          app.commit((s) => { s.inventory[berryId] = Math.max(0, (s.inventory[berryId] ?? 0) - 1); }, 'blend', { quiet: true });
          send({ t: 'start', seats: all.map((s) => ({ ...s })) });
          box.remove();
          play(app, { scrim, seats: all, mySeat: 0, host: true, send, onRoom: S?.client ? (fn) => S.client.onRoom((m) => { if (room && m.id === room.id) fn(m); }) : null, done: () => { offs.forEach((f) => f()); if (room) S.client.leaveRoom(room.id).catch(() => {}); } });
        } }, 'Start blending!')));
  }
  render();
}

/** Join a friend's blend (from their invite). */
export async function joinBerryBlender(app, session, roomId) {
  const S = session;
  let room;
  try { room = (await S.client.joinRoom(roomId)).room; } catch (e) { toast(e.message, 'err'); return; }
  const uid = await pickCreature(app); if (!uid) { S.client.leaveRoom(roomId).catch(() => {}); return; }
  const berryId = await pickBerry(app); if (!berryId) { S.client.leaveRoom(roomId).catch(() => {}); return; }
  const meName = S.acct?.username ?? 'me';
  const mine = seatFor(app, uid, berryId, meName);
  const scrim = h('div', { class: 'bb-scrim' });
  const box = h('div', { class: 'panel bb-lobby' });
  scrim.append(box); document.body.append(scrim);
  let lobby = { seats: [], helpers: 0 }, started = false;
  const send = (data) => S.client.roomSend(room.id, data);
  const offs = [];
  const quit = () => { offs.forEach((f) => f()); S.client.leaveRoom(room.id).catch(() => {}); scrim.remove(); };
  const render = () => mount(box,
    h('div', { class: 'panel-title' }, h('h1', null, `${room.hostName}’s Berry Blender`)),
    h('p', { class: 'dim' }, 'Waiting for the host to start…'),
    h('div', { class: 'bb-seats' }, [0, 1, 2, 3].map((i) => { const s = lobby.seats[i]; return h('div', { class: `bb-seat ${s ? '' : 'empty'}`, style: { borderColor: SEAT_COLORS[i] } }, s ? [h('b', null, s.trainer), h('span', { class: 'dim' }, s.mon || 'helper'), h('span', { class: 'bb-berry', style: { background: s.berry.color } }), h('small', null, s.berry.name)] : h('span', { class: 'dim' }, i < lobby.seats.length + lobby.helpers ? 'helper' : 'empty')); })),
    h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: quit }, 'Leave')));
  offs.push(S.client.onRoom((m) => {
    if (m.id !== room.id || started) return;
    const d = m.data ?? {};
    if (d.t === 'lobby') { lobby = d; render(); }
    if (d.t === 'start') {
      started = true;
      const idx = d.seats.findIndex((s) => s.user === meName);
      if (idx < 0) { toast('The blender was full.', 'err'); quit(); return; }
      app.commit((s) => { s.inventory[berryId] = Math.max(0, (s.inventory[berryId] ?? 0) - 1); }, 'blend', { quiet: true });
      box.remove();
      play(app, { scrim, seats: d.seats, mySeat: idx, host: false, send, onRoom: (fn) => S.client.onRoom((mm) => { if (mm.id === room.id) fn(mm); }), done: () => { offs.forEach((f) => f()); S.client.leaveRoom(room.id).catch(() => {}); } });
    }
  }));
  offs.push(S.on((n) => { if (n.what === 'room-closed' && n.id === room.id && !started) { toast(`${room.hostName} closed the blender.`, 'err'); quit(); } }));
  render();
  send({ t: 'pick', seat: mine });
  send({ t: 'hello' });
  const again = setInterval(() => { if (started || !scrim.isConnected) { clearInterval(again); return; } send({ t: 'pick', seat: mine }); }, 3000);
}

// ---------- the game ----------
// ---------- a tiny pixel font (3×5), so the blender reads like the handheld original ----------
const GLYPHS = {
  '0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111', '4': '101101111001001', '5': '111100111001111', '6': '111100111101111', '7': '111001010010010', '8': '111101111101111', '9': '111101111001111',
  A: '010101111101101', B: '110101110101110', C: '011100100100011', D: '110101101101110', E: '111100110100111', F: '111100110100100', G: '011100101101011', H: '101101111101101', I: '111010010010111', J: '001001001101010', K: '101101110101101', L: '100100100100111', M: '101111111101101', N: '110101101101101', O: '010101101101010', P: '110101110100100', Q: '010101101110011', R: '110101110101101', S: '011100010001110', T: '111010010010010', U: '101101101101111', V: '101101101101010', W: '101101111111101', X: '101101010101101', Y: '101101010010010', Z: '111001010100111',
  '.': '000000000000010', '!': '010010010000010', ':': '000010000010000', '-': '000000111000000', ' ': '000000000000000', '/': '001001010100100', "'": '010010000000000', '?': '110001010000010', '×': '000101010101000',
};
function pixText(g, text, x, y, { color = '#f8f8f8', shadow = '#303040', scale = 1, align = 'left' } = {}) {
  const t = String(text).toUpperCase();
  const w = t.length * 4 * scale - scale;
  let cx = align === 'center' ? Math.round(x - w / 2) : align === 'right' ? x - w : x;
  for (const ch of t) {
    const gl = GLYPHS[ch] ?? GLYPHS['?'];
    for (let i = 0; i < 15; i++) if (gl[i] === '1') {
      const px = cx + (i % 3) * scale, py = y + Math.floor(i / 3) * scale;
      if (shadow) { g.fillStyle = shadow; g.fillRect(px + scale, py + scale, scale, scale); }
      g.fillStyle = color; g.fillRect(px, py, scale, scale);
    }
    cx += 4 * scale;
  }
}
const LW = 240, LH = 160; // the handheld's screen

// ---------- the game ----------
function play(app, { scrim, seats, mySeat, host, send, onRoom, done }) {
  const cv = h('canvas', { class: 'bb-canvas', width: LW * 4, height: LH * 4 });
  const hint = h('div', { class: 'bb-hint' }, 'Press Space or A, click or tap when the arrow reaches your marker!');
  const quitBtn = h('button', { class: 'btn small bb-quit', onclick: () => end(true) }, 'Leave');
  const stage = h('div', { class: 'bb-stage' }, cv, hint, quitBtn);
  scrim.append(stage);
  const g0 = cv.getContext('2d');
  g0.imageSmoothingEnabled = false;
  const lo = document.createElement('canvas'); lo.width = LW; lo.height = LH;
  const g = lo.getContext('2d');
  g.imageSmoothingEnabled = false;
  const imgs = seats.map((s) => { if (!s.sprite) return null; const im = new Image(); im.src = s.sprite; return im; });
  // the intro: everyone's berry drops into the bowl, then 3, 2, 1, START!
  const st = { a: -Math.PI / 2, rpm: 0, maxRpm: 0, prog: 0, t: 0, phase: 'drop', count: 3.99, over: false, drop: 0, startT: -1 };
  const tally = seats.map(() => ({ perfect: 0, good: 0, miss: 0 }));
  const judged = seats.map(() => false); // one judged press per pass of the arrow
  const pops = []; // hit marks flying off the markers
  const bounce = seats.map(() => 0);
  const helperPlan = seats.map(() => null);
  const sparks = [];
  let last = performance.now(), raf = 0, lastSend = 0, result = null;
  const audio = blenderAudio();
  const CX = 120, CY = 84, R = 58;

  const hitAt = (seat, q) => {
    tally[seat][q]++;
    pops.push({ seat, q, t: 0 });
    bounce[seat] = q === 'miss' ? 0.6 : 1;
    if (q === 'perfect') for (let k = 0; k < 6; k++) sparks.push({ x: CX + Math.cos(SEAT_ANGLES[seat]) * (R - 6), y: CY + Math.sin(SEAT_ANGLES[seat]) * (R - 6), vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.5) * 60, t: 0 });
    audio.hit(q, seat === mySeat);
    if (host) { st.rpm = blenderRpm(st.rpm, q, seats.length); st.maxRpm = Math.max(st.maxRpm, st.rpm); }
  };
  const press = () => {
    if (st.phase !== 'go') return;
    const d = (wrap(st.a - SEAT_ANGLES[mySeat]) * 180) / Math.PI;
    if (Math.abs(d) > WINDOW || judged[mySeat]) return;
    judged[mySeat] = true;
    const q = Math.abs(d) <= PERFECT ? 'perfect' : Math.abs(d) <= GOOD ? 'good' : 'miss';
    hitAt(mySeat, q);
    if (!host) send({ t: 'hit', seat: mySeat, q });
  };
  const onKey = (e) => { if (e.code === 'Space' || e.key === 'Enter' || e.key === 'a' || e.key === 'A') { e.preventDefault(); press(); } if (e.key === 'Escape') end(true); };
  cv.addEventListener('pointerdown', (e) => { e.preventDefault(); press(); });
  document.addEventListener('keydown', onKey);
  const unRoom = onRoom?.((m) => {
    const d = m.data ?? {};
    if (host && d.t === 'hit' && seats[d.seat]?.user === m.from && st.phase === 'go') { hitAt(d.seat, d.q); send({ t: 'h', seat: d.seat, q: d.q }); }
    if (!host && d.t === 's') {
      // follow the host's blender: speed, progress and phase directly, the arrow eased in so it doesn't jump
      st.rpm = d.rpm; st.maxRpm = Math.max(st.maxRpm, d.rpm); st.prog = d.prog; st.count = d.count; st.drop = d.drop ?? st.drop;
      if (st.phase !== d.phase && d.phase === 'go') audio.start();
      st.phase = d.phase;
      st.a += wrap(d.a - st.a) * 0.5;
    }
    if (!host && d.t === 'h' && d.seat !== mySeat) hitAt(d.seat, d.q);
    if (!host && d.t === 'end') finish(d.block, d.tally, d.maxRpm);
    if (d.t === 'bye' && m.from === seats[0]?.user && !host && !result) { toast('The host left the blender.', 'err'); end(true); }
  });

  function helperTurns() {
    seats.forEach((s, i) => {
      if (!s.helper) return;
      const d = (wrap(st.a - SEAT_ANGLES[i]) * 180) / Math.PI;
      if (d < -WINDOW || d > WINDOW) { judged[i] = false; helperPlan[i] = null; return; }
      if (judged[i]) return;
      if (!helperPlan[i]) { const r = Math.random(); helperPlan[i] = r < 0.5 ? (Math.random() * 2 - 1) * PERFECT * 0.9 : r < 0.86 ? (Math.random() < 0.5 ? -1 : 1) * (PERFECT + Math.random() * (GOOD - PERFECT)) : (Math.random() < 0.5 ? -1 : 1) * (GOOD + 2 + Math.random() * 20); }
      if (d >= helperPlan[i]) { judged[i] = true; const ad = Math.abs(d); const q = ad <= PERFECT ? 'perfect' : ad <= GOOD ? 'good' : 'miss'; hitAt(i, q); send?.({ t: 'h', seat: i, q }); }
    });
  }
  let lastDropped = -1;
  function tick(now) {
    const dt = Math.min(0.05, (now - last) / 1000); last = now; st.t += dt;
    if (st.phase === 'drop') {
      if (host) st.drop += dt;
      const k = Math.floor(st.drop / 0.55);
      if (k !== lastDropped && k < seats.length && st.drop >= 0) { lastDropped = k; audio.plop(k); }
      if (host && st.drop >= seats.length * 0.55 + 0.5) { st.phase = 'count'; st.count = 3.99; }
    } else if (st.phase === 'count') {
      const before = Math.floor(st.count);
      if (host) st.count -= dt;
      if (Math.floor(st.count) !== before && st.count >= 1) audio.beep(false);
      if (host && st.count < 1 && st.startT < 0) { st.startT = st.t; audio.beep(true); }
      if (host && st.count <= 0.2) { st.phase = 'go'; st.rpm = 20; st.maxRpm = 20; audio.start(); }
    } else if (st.phase === 'go') {
      const prevA = st.a;
      st.a = wrap(st.a + revPerSec(st.rpm) * 2 * Math.PI * dt);
      // the arrow left a marker: the next pass can be judged again
      seats.forEach((_, i) => { const d = (wrap(st.a - SEAT_ANGLES[i]) * 180) / Math.PI; if (d > WINDOW && !seats[i].helper) judged[i] = false; const d0 = (wrap(prevA - SEAT_ANGLES[i]) * 180) / Math.PI; if (d0 < 0 && d >= 0) audio.tick(); });
      if (host) {
        helperTurns();
        st.rpm = Math.max(RPM_MIN, st.rpm - RPM_DECAY * dt);
        st.prog = Math.min(1, st.prog + progPerSec(st.rpm) * dt);
        if (st.prog >= 1) {
          st.phase = 'done';
          const block = blendPokeblock(seats.map((s) => s.berry), st.maxRpm);
          send?.({ t: 'end', block, tally, maxRpm: st.maxRpm });
          finish(block, tally, st.maxRpm);
        }
      }
    } else if (st.phase === 'done') st.rpm = Math.max(0, st.rpm - 40 * dt);
    if (host && now - lastSend > 90) { lastSend = now; send?.({ t: 's', a: st.a, rpm: st.rpm, prog: st.prog, phase: st.phase, count: st.count, drop: st.drop }); }
    audio.motor(st.phase === 'go' || st.phase === 'done' ? st.rpm : 0);
    draw(dt);
    g0.drawImage(lo, 0, 0, cv.width, cv.height);
    if (!st.over) raf = requestAnimationFrame(tick);
  }

  // checkered menu backdrop, like the handheld's
  const backdrop = (() => {
    const c = document.createElement('canvas'); c.width = LW; c.height = LH;
    const b = c.getContext('2d');
    for (let y = 0; y < LH; y += 8) for (let x = 0; x < LW; x += 8) { b.fillStyle = ((x + y) / 8) % 2 ? '#5870a8' : '#6880b8'; b.fillRect(x, y, 8, 8); }
    b.fillStyle = 'rgba(255,255,255,.08)'; for (let y = 0; y < LH; y += 2) b.fillRect(0, y, LW, 1);
    return c;
  })();
  const disc = (x, y, r, col) => { g.fillStyle = col; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill(); };
  const box = (x, y, w, hh, border, fill = '#f8f8f8') => { g.fillStyle = '#303040'; g.fillRect(x, y, w, hh); g.fillStyle = border; g.fillRect(x + 1, y + 1, w - 2, hh - 2); g.fillStyle = fill; g.fillRect(x + 3, y + 3, w - 6, hh - 6); };
  const CORNER = [[2, 2], [LW - 74, 2], [LW - 74, LH - 26], [2, LH - 26]]; // top-left, top-right, bottom-right, bottom-left (as the markers)

  function draw(dt) {
    g.drawImage(backdrop, 0, 0);
    // the blender: a steel bowl with a dark rim and a lip at each marker
    disc(CX, CY + 3, R + 9, 'rgba(0,0,0,.35)');
    disc(CX, CY, R + 9, '#303040');
    disc(CX, CY, R + 7, '#c8c8d8');
    disc(CX, CY, R + 4, '#9898b0');
    // the juice: berries swirl in separately, then become one colour as it blends
    const mix = mixColor(seats.map((s) => s.berry.color), st.prog);
    disc(CX, CY, R, shade(mix, -0.3));
    for (let ring = 0; ring < 5; ring++) {
      g.strokeStyle = ring % 2 ? shade(mix, 0.15) : shade(mix, -0.12); g.lineWidth = 4;
      const a0 = st.a * (1.4 - ring * 0.18) + ring * 1.3;
      g.beginPath(); g.arc(CX, CY, 14 + ring * 9, a0, a0 + 2.2); g.stroke();
    }
    // the berries themselves, until they're blended away
    if (st.prog < 0.7) seats.forEach((s, i) => {
      const a = st.a * 0.9 + (i / seats.length) * Math.PI * 2;
      const dropT = Math.max(0, Math.min(1, (st.drop - i * 0.55) / 0.5));
      if (st.phase === 'drop' && dropT <= 0) return;
      const [cx0, cy0] = CORNER[i];
      const rr = 26 + Math.sin(st.t * 3 + i) * 4;
      const tx = CX + Math.cos(a) * rr * (st.phase === 'drop' ? 0.4 : 1), ty = CY + Math.sin(a) * rr * (st.phase === 'drop' ? 0.4 : 1);
      const x = st.phase === 'drop' ? cx0 + 36 + (tx - cx0 - 36) * dropT : tx, y = st.phase === 'drop' ? cy0 + 12 + (ty - cy0 - 12) * dropT - Math.sin(dropT * Math.PI) * 20 : ty;
      g.globalAlpha = 1 - Math.max(0, st.prog - 0.3) / 0.4;
      disc(x, y, 5, '#303040'); disc(x, y, 4, s.berry.color); disc(x - 1.5, y - 1.5, 1.2, 'rgba(255,255,255,.7)');
      g.fillStyle = '#3a8a3a'; g.fillRect(Math.round(x) - 1, Math.round(y) - 6, 2, 2);
      g.globalAlpha = 1;
    });
    // markers: each trainer's coloured arrow on the rim, pointing in (yours flashes)
    seats.forEach((s, i) => {
      const ang = SEAT_ANGLES[i], mx = CX + Math.cos(ang) * (R + 6), my = CY + Math.sin(ang) * (R + 6);
      g.save(); g.translate(Math.round(mx), Math.round(my)); g.rotate(ang + Math.PI / 2);
      g.fillStyle = '#303040'; g.beginPath(); g.moveTo(0, 8); g.lineTo(-7, -5); g.lineTo(7, -5); g.closePath(); g.fill();
      g.fillStyle = i === mySeat && Math.sin(st.t * 10) > 0 ? '#ffffff' : SEAT_COLORS[i]; g.beginPath(); g.moveTo(0, 6); g.lineTo(-5, -4); g.lineTo(5, -4); g.closePath(); g.fill();
      g.restore();
    });
    // your window: a faint band on the bowl's edge
    if (st.phase === 'go') {
      const ang = SEAT_ANGLES[mySeat];
      g.strokeStyle = 'rgba(255,255,255,.28)'; g.lineWidth = 5; g.beginPath(); g.arc(CX, CY, R - 4, ang - (GOOD * Math.PI) / 180, ang + (GOOD * Math.PI) / 180); g.stroke();
      g.strokeStyle = 'rgba(255,248,140,.7)'; g.beginPath(); g.arc(CX, CY, R - 4, ang - (PERFECT * Math.PI) / 180, ang + (PERFECT * Math.PI) / 180); g.stroke();
    }
    // the spinner: a four-bladed plate with the big arrow
    g.save(); g.translate(CX, CY); g.rotate(st.a);
    for (let k = 0; k < 4; k++) {
      g.save(); g.rotate((k * Math.PI) / 2);
      g.fillStyle = '#303040'; g.fillRect(0, -5, 22, 10);
      g.fillStyle = k === 0 ? '#f8f8f8' : '#d0d0e0'; g.fillRect(1, -4, 20, 8);
      g.restore();
    }
    g.fillStyle = '#303040'; g.beginPath(); g.moveTo(16, -9); g.lineTo(R - 2, 0); g.lineTo(16, 9); g.closePath(); g.fill();
    g.fillStyle = '#f04848'; g.beginPath(); g.moveTo(18, -7); g.lineTo(R - 5, 0); g.lineTo(18, 7); g.closePath(); g.fill();
    g.fillStyle = '#ffb0a0'; g.fillRect(20, -2, R - 30, 2);
    g.restore();
    disc(CX, CY, 9, '#303040'); disc(CX, CY, 7, '#f8d030'); disc(CX - 2, CY - 2, 2, '#fff8c0');
    // trainers in the corners: name plate, their creature, and how they're doing
    seats.forEach((s, i) => {
      const [x, y] = CORNER[i];
      bounce[i] = Math.max(0, bounce[i] - dt * 3);
      box(x, y, 72, 24, SEAT_COLORS[i]);
      pixText(g, s.trainer.slice(0, 10), x + 25, y + 5, { color: '#303040', shadow: '#c8c8d0' });
      // ◎ ○ × and how many of each
      const icon = (ix, kind) => {
        const iy = y + 15;
        if (kind === 'x') { g.fillStyle = '#4878f0'; for (let k = -2; k <= 2; k++) { g.fillRect(ix + k, iy + k, 1, 1); g.fillRect(ix + k, iy - k, 1, 1); } return; }
        g.strokeStyle = kind === 'p' ? '#f8a030' : '#f05050'; g.lineWidth = 1; g.beginPath(); g.arc(ix + 0.5, iy + 0.5, 2.5, 0, Math.PI * 2); g.stroke();
        if (kind === 'p') { g.fillStyle = '#f8a030'; g.fillRect(ix, iy, 1, 1); }
      };
      [['p', tally[i].perfect], ['g', tally[i].good], ['x', tally[i].miss]].forEach(([kind, n], k) => { icon(x + 27 + k * 15, kind); pixText(g, String(Math.min(99, n)), x + 31 + k * 15, y + 13, { color: '#606070', shadow: null }); });
      const hop = Math.round(Math.sin(Math.min(1, bounce[i]) * Math.PI) * 4);
      if (imgs[i]?.complete && imgs[i].naturalWidth) g.drawImage(imgs[i], x + 3, y + 2 - hop, 20, 20);
      else { disc(x + 13, y + 12 - hop, 6, s.berry.color); }
    });
    // hit marks: ◎ Perfect, ○ Good, × Miss, flying in from the marker
    for (let k = pops.length - 1; k >= 0; k--) {
      const p = pops[k]; p.t += dt; if (p.t > 0.8) { pops.splice(k, 1); continue; }
      const ang = SEAT_ANGLES[p.seat], rr = R - 14 - p.t * 14;
      const x = Math.round(CX + Math.cos(ang) * rr), y = Math.round(CY + Math.sin(ang) * rr);
      if (p.t > 0.55 && Math.floor(p.t * 20) % 2) continue;
      g.lineWidth = 2;
      if (p.q === 'miss') { g.strokeStyle = '#303040'; g.beginPath(); g.moveTo(x - 4, y - 4); g.lineTo(x + 4, y + 4); g.moveTo(x + 4, y - 4); g.lineTo(x - 4, y + 4); g.stroke(); g.strokeStyle = '#4878f0'; g.lineWidth = 1; g.stroke(); }
      else { disc(x, y, 6, '#303040'); disc(x, y, 5, p.q === 'perfect' ? '#f8a030' : '#f05050'); disc(x, y, 3, '#303040'); disc(x, y, 2, p.q === 'perfect' ? '#f8f080' : '#f8f8f8'); }
    }
    for (let k = sparks.length - 1; k >= 0; k--) { const p = sparks[k]; p.t += dt; if (p.t > 0.5) { sparks.splice(k, 1); continue; } p.x += p.vx * dt; p.y += p.vy * dt; g.fillStyle = Math.floor(p.t * 20) % 2 ? '#fff8a0' : '#ffffff'; g.fillRect(Math.round(p.x), Math.round(p.y), 2, 2); }
    // the speed, bottom middle, and how far along the blend is, top middle
    box(88, LH - 20, 64, 18, '#7890c8', '#203050');
    pixText(g, st.rpm.toFixed(2).padStart(6, ' '), 147, LH - 15, { color: '#f8f8f8', shadow: '#000', align: 'right' });
    pixText(g, 'RPM', 93, LH - 15, { color: '#f8d030', shadow: '#000' });
    box(92, 3, 56, 9, '#7890c8', '#203050');
    g.fillStyle = '#58d858'; g.fillRect(95, 6, Math.round(50 * st.prog), 3);
    // the start
    if (st.phase === 'count' && st.count >= 1) pixText(g, String(Math.floor(st.count)), CX, CY - 12, { scale: 5, color: '#f8f8f8', shadow: '#303040', align: 'center' });
    if (st.startT >= 0 && st.t - st.startT < 0.9 || (!host && st.phase === 'go' && st.prog < 0.02)) pixText(g, 'START!', CX, CY - 7, { scale: 3, color: '#f8d030', shadow: '#303040', align: 'center' });
    if (st.phase === 'drop') pixText(g, 'BERRIES IN!', CX, LH - 36, { color: '#f8f8f8', shadow: '#303040', align: 'center' });
  }

  function finish(block, tal, maxRpm) {
    if (result) return;
    result = block;
    st.phase = 'done';
    audio.fanfare();
    let mine = null;
    app.commit((s) => { mine = addPokeblock(s, block); }, 'pokeblock', { quiet: true });
    const order = seats.map((s, i) => ({ s, i, t: tal[i] })).sort((a, b) => b.t.perfect - a.t.perfect || b.t.good - a.t.good || a.t.miss - b.t.miss);
    const [cname, col] = BLOCK_COLORS[block.color];
    const card = h('div', { class: 'bb-result gba' },
      h('div', { class: 'gba-title' }, 'RESULTS'),
      h('table', { class: 'gba-table' },
        h('tr', null, h('th', null, ''), h('th', null, '◎'), h('th', null, '○'), h('th', null, '×')),
        order.map((o, n) => h('tr', null, h('td', null, h('b', { style: { color: SEAT_COLORS[o.i] } }, `${n + 1}. `), o.s.trainer), h('td', null, o.t.perfect), h('td', null, o.t.good), h('td', null, o.t.miss)))),
      h('div', { class: 'gba-line' }, `MAXIMUM SPEED  ${maxRpm.toFixed(2)} RPM`),
      h('div', { class: 'bb-block' }, h('span', { class: 'bb-cube', style: { background: col } }),
        h('div', { class: 'col' }, h('b', null, `${cname} Pokéblock`), h('span', null, `Level ${block.level} · Feel ${block.feel}`),
          h('small', null, FLAVORS.filter((f) => block.flavors[f]).map((f) => `${f[0].toUpperCase()}${f.slice(1)} ${block.flavors[f]}`).join(' · ') || 'No flavour at all'))),
      h('div', { class: 'gba-line small' }, mine ? 'It went in your Pokéblock Case. Give it to a creature from the ranch (right-click → Give a Pokéblock).' : ''),
      h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: () => end(false) }, 'OK')));
    setTimeout(() => stage.append(card), 900);
  }
  function end(early) {
    if (st.over) return;
    st.over = true;
    cancelAnimationFrame(raf);
    audio.stop();
    document.removeEventListener('keydown', onKey);
    if (early) send?.({ t: 'bye' });
    unRoom?.();
    done?.();
    scrim.remove();
  }
  raf = requestAnimationFrame(tick);
}

// ---------- colours ----------
function hex(c) { const m = /^#?([0-9a-f]{6})$/i.exec(String(c)); const n = m ? parseInt(m[1], 16) : 0xc04a6a; return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function mixColor(cols, p) {
  const rgb = cols.map(hex);
  // berries start as separate swirls and become one colour as it blends
  const avg = [0, 1, 2].map((k) => Math.round(rgb.reduce((n, c) => n + c[k], 0) / rgb.length));
  const first = rgb[0];
  const m = [0, 1, 2].map((k) => Math.round(first[k] + (avg[k] - first[k]) * Math.min(1, p * 1.6)));
  return `rgb(${m.join(',')})`;
}
function shade(rgbStr, f) { const m = rgbStr.match(/\d+/g).map(Number); return `rgb(${m.map((v) => Math.max(0, Math.min(255, Math.round(v * (1 + f))))).join(',')})`; }

// ---------- sounds (all made here, in the handheld's style: pulse waves, a triangle-ish bass, noise) ----------
function blenderAudio() {
  const A = audioOut();
  const none = { hit() {}, motor() {}, beep() {}, tick() {}, fanfare() {}, stop() {}, start() {}, plop() {} };
  if (!A) return none;
  const { ctx, out } = A;
  const bus = ctx.createGain(); bus.gain.value = 0.85; bus.connect(out);
  // pulse waves with the handheld's duty cycles (12.5 %, 25 %, 50 %)
  const pulse = (duty) => { const n = 64, re = new Float32Array(n), im = new Float32Array(n); for (let k = 1; k < n; k++) im[k] = (2 / (k * Math.PI)) * Math.sin(k * Math.PI * duty); return ctx.createPeriodicWave(re, im); };
  const P12 = pulse(0.125), P25 = pulse(0.25), P50 = pulse(0.5);
  const noiseBuf = (() => { const b = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate); const d = b.getChannelData(0); let r = 1; for (let i = 0; i < d.length; i++) { r ^= r << 13; r ^= r >> 17; r ^= r << 5; d[i] = ((r >>> 0) / 4294967296) * 2 - 1; } return b; })();
  const tone = (t, f, d, { wave = P25, gain = 0.16, slide = 0, decay = true } = {}) => {
    const o = ctx.createOscillator(), gg = ctx.createGain();
    o.setPeriodicWave(wave); o.frequency.setValueAtTime(f, t); if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f * slide), t + d);
    gg.gain.setValueAtTime(gain, t); if (decay) gg.gain.exponentialRampToValueAtTime(0.0008, t + d); else gg.gain.setValueAtTime(0, t + d);
    o.connect(gg); gg.connect(bus); o.start(t); o.stop(t + d + 0.02);
  };
  const noise = (t, d, { gain = 0.12, freq = 4000, q = 0.8, type = 'highpass' } = {}) => {
    const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), gg = ctx.createGain();
    s.buffer = noiseBuf; f.type = type; f.frequency.value = freq; f.Q.value = q;
    gg.gain.setValueAtTime(gain, t); gg.gain.exponentialRampToValueAtTime(0.0008, t + d);
    s.connect(f); f.connect(gg); gg.connect(bus); s.start(t, Math.random() * 0.5); s.stop(t + d + 0.02);
  };
  // the motor: filtered noise and a low pulse buzz, both rising with the RPM
  const mSrc = ctx.createBufferSource(); mSrc.buffer = noiseBuf; mSrc.loop = true;
  const mBand = ctx.createBiquadFilter(); mBand.type = 'bandpass'; mBand.Q.value = 3; mBand.frequency.value = 200;
  const mBuzz = ctx.createOscillator(); mBuzz.setPeriodicWave(P12); mBuzz.frequency.value = 40;
  const mBuzzG = ctx.createGain(); mBuzzG.gain.value = 0.25;
  const mg = ctx.createGain(); mg.gain.value = 0;
  mSrc.connect(mBand); mBand.connect(mg); mBuzz.connect(mBuzzG); mBuzzG.connect(mg); mg.connect(bus);
  mSrc.start(); mBuzz.start();
  // a bouncy little tune of our own (bass, lead and hi-hats); it speeds up with the blender like the original's does
  const N = (s) => (s == null ? null : 440 * 2 ** ((s - 69) / 12));
  const LEAD = [76, null, 79, 76, 81, null, 79, 76, 74, null, 76, 74, 72, null, 74, null, 76, null, 79, 81, 84, null, 83, 81, 79, null, 76, 79, 81, null, null, null];
  const BASS = [48, 55, 52, 55, 53, 57, 55, 57, 50, 57, 53, 57, 55, 59, 55, 52];
  let rpmNow = 0, step = 0, nextAt = 0, running = false;
  const timer = setInterval(() => {
    if (!running) return;
    while (nextAt < ctx.currentTime + 0.15) {
      const len = 60 / (128 + Math.min(110, rpmNow * 0.7)) / 2; // eighth notes, faster as it spins up
      const ln = LEAD[step % LEAD.length];
      if (ln) tone(nextAt, N(ln), len * 0.9, { wave: P25, gain: 0.07 });
      if (step % 2 === 0) tone(nextAt, N(BASS[(step >> 1) % BASS.length] - 12), len * 1.8, { wave: P50, gain: 0.09 });
      if (step % 2 === 1) noise(nextAt, 0.03, { gain: 0.035, freq: 7000 });
      if (step % 8 === 0) noise(nextAt, 0.09, { gain: 0.08, freq: 180, type: 'lowpass' });
      step++;
      nextAt += len;
    }
  }, 40);
  return {
    start() { running = true; nextAt = ctx.currentTime + 0.05; step = 0; const t = ctx.currentTime; [72, 76, 79, 84].forEach((n, i) => tone(t + i * 0.07, N(n), 0.12, { wave: P25, gain: 0.14 })); },
    motor(rpm) {
      rpmNow = rpm;
      const t = ctx.currentTime;
      mBand.frequency.setTargetAtTime(160 + rpm * 9, t, 0.08);
      mBuzz.frequency.setTargetAtTime(32 + rpm * 0.9, t, 0.08);
      mg.gain.setTargetAtTime(rpm > 0 ? 0.05 + Math.min(0.1, rpm / 1200) : 0, t, 0.1);
    },
    hit(q, mine) {
      const t = ctx.currentTime + 0.005, v = mine ? 1 : 0.5;
      if (q === 'perfect') { tone(t, 1568, 0.07, { wave: P12, gain: 0.16 * v }); tone(t + 0.06, 2093, 0.18, { wave: P12, gain: 0.16 * v }); tone(t + 0.12, 2093, 0.12, { wave: P12, gain: 0.05 * v }); }
      else if (q === 'good') { tone(t, 1175, 0.12, { wave: P25, gain: 0.15 * v }); }
      else { noise(t, 0.16, { gain: 0.16 * v, freq: 600, type: 'lowpass' }); tone(t, 110, 0.18, { wave: P50, gain: 0.12 * v, slide: 0.7 }); }
    },
    tick() { tone(ctx.currentTime, 3000, 0.015, { wave: P12, gain: 0.025 }); },
    plop(k) { const t = ctx.currentTime; tone(t, 700 - k * 60, 0.16, { wave: P50, gain: 0.13, slide: 0.25 }); noise(t + 0.12, 0.06, { gain: 0.08, freq: 900, type: 'lowpass' }); },
    beep(go) { const t = ctx.currentTime; if (go) { tone(t, 1047, 0.08, { wave: P25, gain: 0.15 }); tone(t + 0.08, 1568, 0.3, { wave: P25, gain: 0.15 }); } else tone(t, 880, 0.12, { wave: P25, gain: 0.14, decay: false }); },
    fanfare() {
      running = false;
      const t = ctx.currentTime + 0.05;
      const seq = [[72, 0.1], [72, 0.1], [72, 0.1], [77, 0.3], [76, 0.1], [77, 0.1], [81, 0.45]];
      let at = t; for (const [n, d] of seq) { tone(at, N(n), d * 0.95, { wave: P25, gain: 0.14 }); tone(at, N(n - 24), d * 0.95, { wave: P50, gain: 0.1 }); at += d; }
    },
    stop() { running = false; clearInterval(timer); try { mg.gain.setTargetAtTime(0, ctx.currentTime, 0.05); setTimeout(() => { mSrc.stop(); mBuzz.stop(); bus.disconnect(); }, 400); } catch { /* already stopped */ } },
  };
}

/** Feed a Pokéblock from the case (a chooser), for the ranch menus. */
export async function chooseBlock(app, c) {
  const blocks = app.save.pokeblocks ?? [];
  return chooseDialog(`A Pokéblock for ${displayName(app.idx, c)}`, blocks.map((b) => ({ value: b.id, label: `${b.name} · Lv. ${b.level}`,
    detail: `Feel ${b.feel} · ${FLAVORS.filter((f) => b.flavors[f]).map((f) => `${f} ${b.flavors[f]}`).join(', ')}`,
    el: h('span', { class: 'bb-cube small', style: { background: BLOCK_COLORS[b.color]?.[1] } }) })), { empty: 'Your Pokéblock Case is empty. Make some at a Berry Blender (Market → Machines).' });
}
