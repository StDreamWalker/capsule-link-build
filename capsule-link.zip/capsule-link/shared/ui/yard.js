import { artImage } from './brandArt.js';
import { brandText } from './dom.js';
import { sizeFactor, fitSprite } from './creatureSize.js';
// R.A.N.C.H. — Remote Access Nurture & Care Hub.
// A walled yard seen from inside, at creature height. The camera stays in the yard; layered
// backdrops beyond the fence slide at different speeds (parallax), so the world feels much
// bigger than the compound. Left of the yard is the berry farm, right of it the shop.
// The floor is ray-cast per pixel; everything standing on it is a depth-sorted billboard.
import {
  HABITAT_LOOKS, habitatLook, PROPS, FLOATS, pack, P, hexRgb, mixRgb, packA, shadeHex, rngFrom, hash2, vnoise,
} from './habitat.js';
import * as Paint from './paint.js';

// ---------- world layout (units) ----------
export const ZONES = {
  farm: { center: -18, min: -26.5, max: -9.5, label: 'Berry Farm' },
  yard: { center: 0, min: -8.6, max: 8.6, label: 'Yard' },
  shop: { center: 18, min: 9.5, max: 26.5, label: 'Shop' },
};
const ORDER = ['farm', 'yard', 'shop'];
const X0 = -27, X1 = 27, Z0 = -4, Z1 = 11;      // floor texture extent
const BACK = 9.8;                                 // the back fence
const FLOOR_END = 10.6;                           // floor stops just behind the fence
const TEX = 24;                                   // texture pixels per unit
const TXW = (X1 - X0) * TEX, TXH = (Z1 - Z0) * TEX;
const CAM_Y = 2.6, CAM_Z = -3.6, PITCH = 0.22;
// the camera orbits a point in the middle of the yard; turning is limited so the painted
// scenery behind the fence always fills the view
const PIVOT_Z = 4.4, ORBIT_R = PIVOT_Z - CAM_Z, MAX_YAW = 0.34;
// a 1 m creature is this many units tall (a tree is 3.6); others follow their height, see creatureSize.js
const CREATURE_H = 0.75;
export const PLOTS = [[-22.5, 3.4], [-18, 3.4], [-13.5, 3.4], [-22.5, 6.6], [-18, 6.6], [-13.5, 6.6]];

// ---------- backdrop styles per biome ----------
const STYLE = {
  meadow: { far: 'mountains', mid: 'hills', near: ['tree', 'bush'], fence: 'picket' },
  forest: { far: 'mountains', mid: 'pines', near: ['pine', 'tree'], fence: 'hedge' },
  shoreline: { far: 'none', mid: 'sea', near: ['palm', 'rock'], fence: 'rocks' },
  volcano: { far: 'volcano', mid: 'spires', near: ['spire', 'lavarock'], fence: 'rocks' },
  cavern: { far: 'cave', mid: 'stalagmites', near: ['stalagmite', 'glowshroom'], fence: 'rocks' },
  tundra: { far: 'mountains', mid: 'ice', near: ['snowpine', 'icespike'], fence: 'snowbank' },
  desert: { far: 'mesas', mid: 'dunes', near: ['cactus', 'rock'], fence: 'adobe' },
  skyline: { far: 'none', mid: 'clouds', near: ['cloud', 'pillar'], fence: 'rail' },
  seafloor: { far: 'reef', mid: 'kelp', near: ['kelp', 'coral'], fence: 'coral' },
  marsh: { far: 'mountains', mid: 'reeds', near: ['reed', 'tree'], fence: 'reeds' },
  starfield: { far: 'planets', mid: 'spires', near: ['crystal', 'pillar'], fence: 'neon' },
  crystal: { far: 'cave', mid: 'crystals', near: ['crystal', 'stalagmite'], fence: 'crystal' },
};

// ---------- painted props: { img, h (units tall) } ----------
const LEAF = { meadow: '#4f9a3f', forest: '#3a7d3a', marsh: '#5a7a3a', shoreline: '#4fae40', desert: '#7a9a3f', tundra: '#2f6b48' };
function paintedProp(kind, L, seed, biome) {
  const leaf = LEAF[biome] ?? '#4f9a3f';
  switch (kind) {
    case 'tree': return { img: Paint.tree(seed, leaf, { fruit: seed % 3 === 0 ? '#e5484d' : null }), h: 3.6 };
    case 'pine': return { img: Paint.pine(seed, '#2f6b48'), h: 4 };
    case 'snowpine': return { img: Paint.pine(seed, '#2e6a54', { snow: true }), h: 3.8 };
    case 'palm': return { img: Paint.palm(seed), h: 3.8 };
    case 'bush': return { img: Paint.bush(seed, leaf, { flowers: seed % 2 ? '#ff8fb6' : null }), h: 0.95 };
    case 'flower': return { img: Paint.flowers(seed, L.dots?.length ? L.dots : undefined), h: 0.45 };
    case 'tuft': return { img: Paint.grassTuft(seed, L.ground[2] ?? L.ground[0]), h: 0.38 };
    case 'rock': return { img: Paint.rock(seed, L.cliff[0], { moss: ['meadow', 'forest', 'marsh'].includes(biome) ? leaf : null, snow: biome === 'tundra' }), h: 0.95 };
    case 'mushroom': return { img: Paint.mushroom(seed), h: 0.6 };
    case 'glowshroom': return { img: Paint.mushroom(seed, '#4ad0ff', { glow: true }), h: 0.75 };
    case 'log': return { img: Paint.log(seed), h: 0.55 };
    case 'cactus': return { img: Paint.cactus(seed), h: 2 };
    case 'crystal': return { img: Paint.crystal(seed, ['#ff9aff', '#9ad9ff', '#c89bff', '#7dffcf'][seed % 4]), h: 1.7 };
    case 'stalagmite': return { img: Paint.stalagmite(seed, L.cliff[0]), h: 2 };
    case 'icespike': return { img: Paint.crystal(seed, '#bfe8ff', { glow: false }), h: 1.5 };
    case 'spire': return { img: Paint.stalagmite(seed, '#3b3036'), h: 2.8 };
    case 'lavarock': { const img = Paint.rock(seed, '#3a3036'); const x = img.getContext('2d'); for (let i = 0; i < 5; i++) Paint.line(x, 20 + i * 12, 30 + (i % 2) * 8, 26 + i * 12, 44, i % 2 ? '#ff8a3d' : '#ffd45e', 2); return { img, h: 0.85 }; }
    case 'kelp': return { img: Paint.kelp(seed), h: 2.6 };
    case 'coral': return { img: Paint.coral(seed, ['#ff7a9a', '#ffb23d', '#c89bff'][seed % 3]), h: 1.1 };
    case 'reed': return { img: Paint.reeds(seed), h: 1.5 };
    case 'cloud': return { img: Paint.cloud(seed, { w: 120, h: 50 }), h: 1.1 };
    case 'pillar': return { img: Paint.stalagmite(seed, L.cliff[0], { w: 44, h: 120 }), h: 2.2 };
    default: { const img = PROPS[kind]?.(rngFrom(seed), L); return img ? { img, h: img.height / 18 } : null; }
  }
}

// ---------- painted parallax strips (tileable) ----------
const LAYER_W = 2048;
function ridge(x, seed, amp, base, ks = [1, 2, 3, 5, 8]) {
  let y = base;
  ks.forEach((k, i) => { y += Math.sin((x / LAYER_W) * Math.PI * 2 * k + seed * (i + 1)) * amp / (i + 1); });
  return y;
}
function hazeOf(L, t) { const a = hexRgb(L.sky[1]); return (col) => { const b = hexRgb(col); return `rgb(${mixRgb(b, a, t).map((v) => v | 0).join(',')})`; }; }
function paintedLayer(kind, L, seed, h, which, biome) {
  const { c, x } = Paint.mk(LAYER_W, h);
  const r = rngFrom(seed * 1000 + which);
  const haze = hazeOf(L, which === 1 ? 0.5 : which === 2 ? 0.28 : 0.15);
  const wrapDraw = (img, px, py, w, hh) => { for (const dx of [0, -LAYER_W, LAYER_W]) x.drawImage(img, Math.round(px + dx), Math.round(py), Math.round(w), Math.round(hh)); };
  const terrain = (base, amp, ks, colTop, colBody, { snow = 0, lit = true } = {}) => {
    const pal = Paint.ramp(colBody, 6, 0.45).map(haze);
    for (let px = 0; px < LAYER_W; px++) {
      const y = ridge(px, seed, amp, base, ks), y2 = ridge(px + 2, seed, amp, base, ks);
      const slope = (y2 - y) * 0.5;
      for (let yy = Math.floor(y); yy < h; yy++) {
        const depth = (yy - y) / (h - y + 1);
        let k = (lit ? 0.55 + slope * 0.6 : 0.5) - depth * 0.35 + (Math.sin(px * 0.7 + yy * 1.3) > 0.97 ? 0.15 : 0);
        k = Math.max(0, Math.min(0.999, k));
        x.fillStyle = yy < y + 2 ? haze(colTop) : (snow && yy - y < snow * (1 - (y - (base - amp)) / (amp * 2)) && slope > -0.6 ? haze('#f4f8ff') : pal[Math.floor(k * pal.length)]);
        x.fillRect(px, yy, 1, 1);
      }
    }
  };
  switch (kind) {
    case 'mountains': terrain(h * 0.38, h * 0.26, [1, 2, 3, 5, 9], '#ffffff', L.mount, { snow: h * 0.16 }); break;
    case 'volcano': { terrain(h * 0.5, h * 0.18, [1, 3, 4], '#ff6a2a', '#3a1418'); const cx = LAYER_W * 0.3; for (let y = 0; y < h * 0.7; y++) { const w = 20 + y * 1.4; x.fillStyle = haze(y < 4 ? '#ff6a2a' : '#2a1418'); x.fillRect(cx - w / 2, h * 0.18 + y, w, 1); } x.save(); x.globalAlpha = 0.3; Paint.dab(x, cx, h * 0.12, 26, '#ff8a3d'); x.restore(); break; }
    case 'mesas': for (let i = 0; i < 6; i++) { const w = 120 + r() * 220, top = h * (0.25 + r() * 0.3), px = r() * LAYER_W; const pal = Paint.ramp('#b5673a', 5, 0.4).map(haze); for (const dx of [0, -LAYER_W]) for (let yy = top; yy < h; yy++) { x.fillStyle = yy < top + 3 ? haze('#e0a070') : pal[Math.min(4, Math.floor(((yy - top) % 18) / 6) + 1)]; x.fillRect(px + dx, yy, w, 1); x.fillStyle = pal[0]; x.fillRect(px + dx + w * 0.75, yy, w * 0.25, 1); } } break;
    case 'cave': { x.fillStyle = Paint.ramp(L.cliff[2] ?? L.cliff[0], 4, 0.3)[0]; x.fillRect(0, 0, LAYER_W, h); for (let px = 0; px < LAYER_W; px += 9) { const d = 14 + hash2(px, seed) * h * 0.45; for (let y = 0; y < d; y++) { const w = Math.max(1, 8 * (1 - y / d)); x.fillStyle = y % 7 === 0 ? shadeHex(L.cliff[1], -0.2) : shadeHex(L.cliff[1], -0.05); x.fillRect(px - w / 2, y, w, 1); } } terrain(h * 0.65, h * 0.08, [3, 7], L.cliff[0], L.cliff[1], { lit: false }); break; }
    case 'reef': terrain(h * 0.5, h * 0.18, [2, 3, 7], '#3dd6ff', '#0b3a62'); break;
    case 'planets': { const g = x.createRadialGradient(LAYER_W * 0.25, h * 0.3, 4, LAYER_W * 0.25, h * 0.35, 60); g.addColorStop(0, '#f0d8ff'); g.addColorStop(1, '#7a4fb0'); x.fillStyle = g; x.beginPath(); x.arc(LAYER_W * 0.25, h * 0.35, 52, 0, Math.PI * 2); x.fill(); x.strokeStyle = 'rgba(255,226,122,.8)'; x.lineWidth = 3; x.beginPath(); x.ellipse(LAYER_W * 0.25, h * 0.35, 84, 14, -0.3, 0, Math.PI * 2); x.stroke(); x.fillStyle = '#7db8ff'; x.beginPath(); x.arc(LAYER_W * 0.7, h * 0.5, 22, 0, Math.PI * 2); x.fill(); break; }
    case 'hills': case 'pines': case 'reeds': {
      const base = kind === 'pines' ? h * 0.45 : h * 0.4;
      terrain(base, h * 0.12, [2, 3, 5], L.ground[2] ?? L.ground[0], L.ground[3] ?? L.ground[0]);
      const leaf = kind === 'pines' ? '#2a5e40' : kind === 'reeds' ? '#5a7a3a' : (LEAF[biome] ?? '#4f9a3f');
      const pal = Paint.ramp(leaf, 6, 0.45).map(haze);
      for (let px = 0; px < LAYER_W; px += kind === 'pines' ? 7 : 11) {
        const y = ridge(px, seed, h * 0.12, base, [2, 3, 5]);
        if (kind === 'pines') { const th = 18 + r() * 26; for (let yy = 0; yy < th; yy++) { const w = (yy / th) * 10 + 1; x.fillStyle = pal[Math.min(5, Math.floor((1 - yy / th) * 3 + (yy % 4 === 0 ? 0 : 2)))]; x.fillRect(px - w / 2, y + 6 - th + yy, w, 1); } }
        else if (kind === 'reeds') { for (let i = 0; i < 4; i++) { x.fillStyle = pal[2 + (i % 3)]; x.fillRect(px + i * 2, y - 6 - r() * 12, 1, 18); } }
        else if (r() < 0.75) Paint.clump(x, r, px, y + 2, 7 + r() * 6, 6 + r() * 4, pal, { size: [1, 2.2] });
      }
      break;
    }
    case 'sea': { const top = h * 0.55; const g = x.createLinearGradient(0, top, 0, h); g.addColorStop(0, shadeHex(L.water, -0.15)); g.addColorStop(1, shadeHex(L.water, 0.18)); x.fillStyle = g; x.fillRect(0, top, LAYER_W, h - top); for (let i = 0; i < 380; i++) { const yy = top + 2 + r() * (h - top - 2); x.fillStyle = `rgba(255,255,255,${(0.3 + r() * 0.5).toFixed(2)})`; x.fillRect(r() * LAYER_W, yy, 3 + r() * 10 * (yy - top) / (h - top) + 2, 1); } for (let i = 0; i < 3; i++) { const px = r() * LAYER_W; for (let yy = 0; yy < 18; yy++) { const w = 120 - yy * 3; x.fillStyle = haze(yy < 2 ? '#8fd08a' : '#5a8a5a'); x.fillRect(px - w / 2 + yy * 4, top - 18 + yy, w * 0.6, 1); } } break; }
    case 'spires': case 'stalagmites': case 'crystals': {
      terrain(h * 0.72, h * 0.05, [4, 9], L.cliff[0], L.cliff[1], { lit: false });
      for (let i = 0; i < 26; i++) {
        const px = r() * LAYER_W, img = kind === 'crystals' ? Paint.crystal(seed + i, ['#7a4fb0', '#4a7ab0', '#a04f9a'][i % 3], { w: 40, h: 70, glow: false }) : Paint.stalagmite(seed + i, kind === 'spires' ? '#3a2a30' : L.cliff[1], { w: 30, h: 80 });
        const s = 0.6 + r() * 0.7; wrapDraw(img, px, h * 0.76 - img.height * s, img.width * s, img.height * s);
      }
      x.globalCompositeOperation = 'source-atop'; x.fillStyle = `rgba(${hexRgb(L.sky[1]).join(',')},.3)`; x.fillRect(0, 0, LAYER_W, h); x.globalCompositeOperation = 'source-over';
      break;
    }
    case 'ice': terrain(h * 0.5, h * 0.14, [2, 5, 11], '#ffffff', '#bfd8f2'); break;
    case 'dunes': terrain(h * 0.55, h * 0.1, [2, 3], '#fff0c8', L.ground[0]); for (let i = 0; i < 260; i++) { const px = r() * LAYER_W, y = ridge(px, seed, h * 0.1, h * 0.55, [2, 3]) + 4 + r() * 30; x.fillStyle = haze(shadeHex(L.ground[0], -0.12)); x.fillRect(px, y, 8 + r() * 14, 1); } break;
    case 'clouds': for (let i = 0; i < 18; i++) { const img = Paint.cloud(seed + i, { w: 160 + r() * 120, h: 60 + r() * 30, tint: i % 3 ? '#ffffff' : '#ffe6f2' }); wrapDraw(img, r() * LAYER_W, h * (0.25 + r() * 0.5), img.width, img.height); } break;
    case 'kelp': for (let i = 0; i < 40; i++) { const img = Paint.kelp(seed + i, { w: 40, h: 120 }); const s = 0.6 + r(); wrapDraw(img, r() * LAYER_W, h - img.height * s, img.width * s, img.height * s); } x.globalCompositeOperation = 'source-atop'; x.fillStyle = 'rgba(31,127,176,.4)'; x.fillRect(0, 0, LAYER_W, h); x.globalCompositeOperation = 'source-over'; break;
    case 'none': break;
    default: break;
  }
  return c;
}
function paintedNear(L, style, seed, h, biome) {
  const { c, x } = Paint.mk(LAYER_W, h);
  const r = rngFrom(seed * 77 + 3);
  for (let i = 0; i < 22; i++) {
    const kind = style.near[i % style.near.length];
    const p = paintedProp(kind, L, seed * 31 + i, biome);
    if (!p) continue;
    const s = (h * (0.75 + r() * 0.35)) / p.img.height * Math.min(1, p.h / 3.4 + 0.3);
    const w = p.img.width * s, hh = p.img.height * s;
    const px = (i / 22) * LAYER_W + r() * 40;
    for (const dx of [0, -LAYER_W, LAYER_W]) x.drawImage(p.img, Math.round(px + dx), Math.round(h - hh), Math.round(w), Math.round(hh));
  }
  x.globalCompositeOperation = 'source-atop';
  x.fillStyle = `rgba(${hexRgb(L.sky[1]).join(',')},0.22)`;
  x.fillRect(0, 0, LAYER_W, h);
  return c;
}

// ---------- floor texture for all three zones ----------
const FLOOR_STYLE = { meadow: 'grass', forest: 'grass', marsh: 'grass', shoreline: 'sand', desert: 'sand', seafloor: 'sand', tundra: 'snow', volcano: 'rock', cavern: 'rock', crystal: 'rock', starfield: 'rock', skyline: 'cloud' };
function buildFloor(L, seed, biome) {
  const col = new Uint32Array(TXW * TXH), mat = new Uint8Array(TXW * TXH);
  const pal = L.ground.map(hexRgb);
  const r = rngFrom(seed * 131 + 7);
  const style = FLOOR_STYLE[biome] ?? 'grass';
  const soil = ['#5e3c22', '#6b4423', '#7a5232', '#4f321c'].map(hexRgb), stone = ['#b9b2c8', '#a8a0ba', '#c8c2d6', '#9a92ae'].map(hexRgb), meadowPal = Paint.ramp('#5cae48', 6, 0.35).map(hexRgb);
  const farmGrass = Paint.ramp('#62b04c', 6, 0.35).map(hexRgb);
  for (let ty = 0; ty < TXH; ty++) for (let tx = 0; tx < TXW; tx++) {
    const wx = X0 + tx / TEX, wz = Z0 + ty / TEX;
    const n = vnoise(tx / 28 + seed, ty / 28) * 0.6 + vnoise(tx / 9, ty / 9 + seed) * 0.3 + hash2(tx, ty) * 0.1;
    let c;
    if (wx < -9.4) c = farmGrass[Math.min(5, Math.floor(n * 6))];
    else if (wx > 9.4) {
      const row = Math.floor(wz * 2.2), off = (row % 2) * 0.5, bx = Math.floor(wx * 2.2 + off);
      const fx = (wx * 2.2 + off) % 1, fz = (wz * 2.2) % 1;
      c = stone[(bx * 7 + row * 3) & 3];
      c = mixRgb(c, [255, 255, 255], (0.5 - fz) * 0.12 + (0.5 - fx) * 0.08);
      if (fx < 0.06 || fz < 0.07) c = mixRgb(c, [70, 60, 90], 0.45);
    } else {
      c = pal[Math.min(pal.length - 1, Math.floor(n * pal.length))];
      if (style === 'sand') c = mixRgb(c, [255, 250, 230], Math.sin(wz * 7 + vnoise(tx / 30, ty / 30) * 6) > 0.86 ? 0.25 : 0);
      if (style === 'snow') c = mixRgb(c, [255, 255, 255], hash2(tx, ty) < 0.02 ? 0.8 : 0);
      if (style === 'rock') { const cr = vnoise(tx / 6, ty / 6); if (cr > 0.48 && cr < 0.5) c = mixRgb(c, [20, 16, 30], 0.4); }
      if (style === 'grass') c = mixRgb(meadowPal[Math.min(5, Math.floor(n * 6))], c, 0.55);
    }
    col[ty * TXW + tx] = packA(c);
  }
  // grass blades: short strokes, lit tips
  const blades = (x0, x1, palette, density) => {
    const n = Math.round((x1 - x0) * TEX * TXH * density);
    for (let i = 0; i < n; i++) {
      const tx = Math.floor((x0 - X0) * TEX + r() * (x1 - x0) * TEX), ty = Math.floor(r() * TXH);
      const len = 2 + Math.floor(r() * 3);
      for (let k = 0; k < len; k++) { const yy = ty - k; if (yy < 0 || tx >= TXW) continue; col[yy * TXW + tx] = packA(palette[Math.min(palette.length - 1, 1 + k + (r() < 0.3 ? 1 : 0))]); }
    }
  };
  if (style === 'grass') blades(-9.4, 9.4, Paint.ramp(L.ground[1] ?? L.ground[0], 6, 0.45).map(hexRgb), 0.09);
  blades(X0, -9.4, farmGrass, 0.09);
  // the farm: tilled beds and a stepping-stone path to the yard gate
  for (const [px, pz] of PLOTS) {
    for (let ty = 0; ty < TXH; ty++) for (let tx = 0; tx < TXW; tx++) {
      const wx = X0 + tx / TEX, wz = Z0 + ty / TEX;
      if (Math.abs(wx - px) < 1.6 && wz > pz - 0.95 && wz < pz + 0.9) {
        const furrow = Math.sin((wz - pz) * 9) > 0.2;
        let c = soil[(furrow ? 2 : 0) + (hash2(tx, ty) < 0.2 ? 1 : 0)];
        if (hash2(tx + 3, ty) < 0.02) c = [150, 130, 110];
        col[ty * TXW + tx] = packA(c);
      }
    }
  }
  const stones = [];
  for (let z = 0.6; z < 9; z += 0.9) stones.push([-15.75 + Math.sin(z) * 0.3, z]);
  for (let x = -15.5; x < -9.4; x += 0.9) stones.push([x, 1.4 + Math.sin(x) * 0.2]);
  for (const [sx, sz] of stones) for (let ty = 0; ty < TXH; ty++) for (let tx = 0; tx < TXW; tx++) {
    const dx = X0 + tx / TEX - sx, dz = Z0 + ty / TEX - sz;
    const d = (dx * dx) / 0.12 + (dz * dz) / 0.08;
    if (d < 1) col[ty * TXW + tx] = packA(mixRgb(stone[(tx + ty) & 3], [255, 255, 255], (1 - d) * 0.15 - (dz > 0.15 ? 0.1 : 0)));
  }
  const circle = (cx, cz, rad, m) => {
    for (let ty = 0; ty < TXH; ty++) for (let tx = 0; tx < TXW; tx++) {
      const dx = X0 + tx / TEX - cx, dz = Z0 + ty / TEX - cz;
      const wob = 1 + (vnoise(tx / 10 + seed, ty / 10) - 0.5) * 0.4;
      if (dx * dx + (dz * 1.4) ** 2 < (rad * wob) ** 2) mat[ty * TXW + tx] = m;
    }
  };
  const decal = (L.decals ?? [])[0];
  if (decal === 'lava') circle(6.2, 7.6, 1.6, 2);
  else if (decal === 'ice') circle(-5.5, 7.4, 1.7, 4);
  else if (decal === 'sea') { for (let ty = 0; ty < TXH; ty++) for (let tx = 0; tx < TXW; tx++) { const wx = X0 + tx / TEX, wz = Z0 + ty / TEX; if (wx > -9.2 && wx < 9.2 && wz > 8.3 + Math.sin(wx * 1.1) * 0.35) mat[ty * TXW + tx] = 1; } }
  else if (L.water && decal) circle(6, 7.6, 1.5, 1);
  if (L.glowlines) for (let i = 0; i < 10; i++) { let tx = Math.floor(r() * TXW), ty = Math.floor(r() * TXH); for (let k = 0; k < 180; k++) { if (tx >= 0 && ty >= 0 && tx < TXW && ty < TXH && !mat[ty * TXW + tx]) mat[ty * TXW + tx] = 3; if (r() < 0.5) tx += r() < 0.5 ? 1 : -1; else ty += r() < 0.5 ? 1 : -1; } }
  const dots = (L.dots ?? []).map(hexRgb);
  for (let i = 0; i < TXW * 2; i++) { const tx = Math.floor(r() * TXW), ty = Math.floor(r() * TXH); const wx = X0 + tx / TEX; if (!mat[ty * TXW + tx] && wx > -9.4 && wx < 9.4 && dots.length) { const d = dots[Math.floor(r() * dots.length)]; const cross = style === 'grass' ? [[0, 0], [1, 0], [0, 1], [-1, 0], [0, -1]] : [[0, 0], [1, 0]]; for (const [ox, oy] of cross) { const i2 = (ty + oy) * TXW + tx + ox; if (i2 >= 0 && i2 < col.length) col[i2] = packA(ox || oy || style !== 'grass' ? d : [255, 220, 90]); } } }
  for (let ty = 1; ty < TXH - 1; ty++) for (let tx = 1; tx < TXW - 1; tx++) {
    const i = ty * TXW + tx;
    if (mat[i] || !(mat[i - 1] === 1 || mat[i + 1] === 1 || mat[i - TXW] === 1 || mat[i + TXW] === 1)) continue;
    col[i] = packA(mixRgb(pal[0], [255, 255, 255], 0.5));
  }
  return { col, mat };
}

// ---------- farm and shop pieces, cached per stage and colour ----------
const plantCache = new Map();
function plantImg(stage, color, seed) {
  const key = `${stage}:${color}:${seed}`;
  if (!plantCache.has(key)) plantCache.set(key, Paint.seedling(stage, color, seed));
  return plantCache.get(key);
}

export class Yard {
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.bank = opts.bank;
    this.resolve = opts.resolveTexture ?? (() => null);
    this.onSelect = opts.onSelect ?? (() => {});
    this.onPet = opts.onPet ?? (() => {});
    this.onDrop = opts.onDrop ?? (() => {});
    this.onPlot = opts.onPlot ?? (() => {});
    this.onZone = opts.onZone ?? (() => {});
    this.plots = [];
    this.zone = 'yard';
    this.camX = 0; this.camTarget = 0;
    this.yaw = 0; this.yawTarget = 0;
    this.updateCamera();
    this.actors = new Map();
    this.reacts = [];
    this.ball = null;
    this.selected = null; this.hover = null;
    this.time = 0; this.warp = 0;
    this.hits = [];
    this.accent = opts.accent ?? '#5b45c4';
    this.sizeScale = opts.sizeScale ?? 1; // the player's "creature size" setting
    this.floorCanvas = document.createElement("canvas");
    if (typeof window !== "undefined") window.__yard = this; // handy in the dev tools
    this.resize();
    this.setBiome(opts.biome ?? 'meadow', opts.seed ?? 1);
    this.bindInput();
    this.ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(() => this.resize()) : null;
    this.ro?.observe(canvas);
  }

  resize() {
    const r = this.canvas.getBoundingClientRect();
    const aspect = r.width > 10 && r.height > 10 ? r.width / r.height : 16 / 9;
    this.H = 480;
    this.W = Math.max(480, Math.min(1280, Math.round(this.H * aspect)));
    this.canvas.width = this.W; this.canvas.height = this.H;
    this.floorCanvas.width = this.W; this.floorCanvas.height = this.H;
    this.fctx = this.floorCanvas.getContext('2d');
    this.img = this.fctx.createImageData(this.W, this.H);
    this.buf = new Uint32Array(this.img.data.buffer);
    this.F = this.H * 1.05;
    // where the floor ends on screen: everything above is backdrop
    const keep = [this.yaw, this.camX];
    this.yaw = 0; this.camX = 0; this.updateCamera();
    this.yBack = Math.floor(this.project(0, 0, FLOOR_END)?.y ?? this.H * 0.4);
    [this.yaw, this.camX] = keep; this.updateCamera();
  }

  setBiome(biome, seed = 1) {
    this.biome = biome; this.seed = seed;
    const L = (this.L = habitatLook(biome));
    this.style = STYLE[biome] ?? STYLE.meadow;
    this.floor = buildFloor(L, seed, biome);
    this.floorAnimated = !!L.caustics || this.floor.mat.some((m) => m > 0);
    this.floorKey = null;
    this.c = { water: hexRgb(L.water ?? '#3d9be0'), sky1: hexRgb(L.sky[1]), grid: hexRgb(L.grid) };
    const st = this.style;
    const yb = this.yBack ?? 200;
    this.layers = [
      { img: paintedLayer(st.far, L, seed, Math.round(yb * 0.95), 1, biome), f: 0.06 },
      { img: paintedLayer(st.mid, L, seed + 3, Math.round(yb * 0.62), 2, biome), f: 0.22 },
      { img: paintedNear(L, st, seed, Math.round(yb * 0.55), biome), f: 0.5 },
    ];
    // the colour along the bottom of the nearest strip, to fill under it when the view leans
    try {
      const near = this.layers[2].img;
      const d = near.getContext('2d').getImageData(0, near.height - 2, near.width, 1).data;
      let r = 0, g = 0, b = 0, n = 0;
      for (let i = 0; i < d.length; i += 16) if (d[i + 3] > 200) { r += d[i]; g += d[i + 1]; b += d[i + 2]; n++; }
      if (n) this.layers[2].base = `rgb(${(r / n) | 0},${(g / n) | 0},${(b / n) | 0})`;
    } catch { /* not readable */ }
    this.clouds = (L.cave || L.underwater || L.night) ? [] : Array.from({ length: 5 }, (_, i) => ({ img: Paint.cloud(seed * 7 + i, { w: 180 + i * 30, h: 64 + (i % 2) * 16, tint: biome === 'volcano' ? '#6a5a5c' : L.clouds ? '#fff0f7' : '#ffffff', shade: biome === 'volcano' ? '#2a2024' : L.clouds ? '#e6c8f0' : '#cdd6ee' }), x: (i * 0.23 + hash2(i, seed) * 0.1), y: 0.08 + hash2(seed, i) * 0.35, v: 3 + i * 1.5 }));
    this.fence = { yard: Paint.fence(st.fence, L, seed), farm: Paint.fence('picket', L, seed + 1), shop: Paint.fence('adobe', L, seed + 2) };
    // props: scattered inside the yard near its edges, plus the farm and the shop
    const r = rngFrom(seed * 31 + biome.length);
    this.props = [];
    let n0 = 0;
    const put = (kind, x, z, extra = {}) => { const pp = paintedProp(kind, L, seed * 101 + n0++, biome); if (pp) this.props.push({ kind, img: pp.img, h: pp.h, x, z, solid: !['flower', 'tuft', 'shell', 'lily'].includes(kind), ...extra }); };
    for (const [kind, n] of L.props) {
      if (FLOATS.has(kind)) { for (let i = 0; i < n; i++) put(kind, (r() * 2 - 1) * 8, 6 + r() * 3.5, { y: 2.5 + r() * 2.5, float: true, bob: r() * 6 }); continue; }
      for (let i = 0; i < Math.ceil(n * 0.75); i++) {
        for (let t = 0; t < 20; t++) {
          const pp = { tree: 1, pine: 1, snowpine: 1, palm: 1, spire: 1, cactus: 1, kelp: 1, pillar: 1 }[kind];
          const x = (r() * 2 - 1) * 8.4, z = pp ? 7.4 + r() * 2 : 1 + r() * 8.4;
          if (!pp && Math.abs(x) < 5 && z < 6 && !['flower', 'tuft', 'shell'].includes(kind)) continue; // keep the middle open to play
          if (this.matAt(x, z)) continue;
          if (this.props.some((p) => (p.x - x) ** 2 + (p.z - z) ** 2 < 1.2)) continue;
          put(kind, x, z);
          break;
        }
      }
    }
    for (let i = 0; i < 18; i++) { const x = (r() * 2 - 1) * 8.6, z = 0.6 + r() * 9; if (!this.matAt(x, z)) put(FLOOR_STYLE[biome] === 'grass' ? (i % 3 ? 'tuft' : 'flower') : 'tuft', x, z); }
    this.props.push({ kind: 'beacon', img: PROPS.beacon(), x: 8.2, z: 9.1, h: 2.2, solid: true, beacon: true });
    // the berry farm
    const add = (kind, img, x, z, h, extra = {}) => this.props.push({ kind, img, x, z, h, solid: true, ...extra });
    add('barn', Paint.barn(seed), -23.6, 9.3, 3.6);
    add('scarecrow', Paint.scarecrow(seed, '#e5484d'), -20.2, 8.6, 1.9);
    add('crate', Paint.crate(seed, '#c0306a'), -11.6, 8.5, 0.75);
    add('crate', Paint.crate(seed + 1, '#4ad0ff'), -10.8, 8.9, 0.75);
    for (let x = -26.2; x < -10; x += 1.25) if (x < -25.5 || x > -21.2) add('sunflower', Paint.sunflower(seed + Math.round(x * 10)), x, 9.55, 2.1);
    add('sign', Paint.signboard('BERRY FARM', '#3fb26a'), -12.4, 1.3, 1.2);
    for (let i = 0; i < 6; i++) add('bush', Paint.bush(seed + 40 + i, '#4f9a3f', { flowers: i % 2 ? '#ffffff' : '#ff8fb6' }), -26.3 + (i % 2) * 0.4, 2 + i * 1.25, 0.95);
    PLOTS.forEach(([px, pz], i) => add('bed', Paint.raisedBed(seed + i), px, pz - 0.98, 0.69, { bed: true, solid: false }));
    // the shop
    add('stall', Paint.stall(seed, this.accent), 18, 8.7, 3.6);
    add('bot', Paint.bot(seed), 18.9, 7.4, 1.35, { bot: true });
    add('lantern', Paint.lantern(seed), 13.6, 6.8, 1.8);
    add('lantern', Paint.lantern(seed + 1), 22.4, 6.8, 1.8);
    add('crate', Paint.crate(seed + 2, '#ffc93c'), 14.8, 8.4, 0.75);
    add('crate', Paint.crate(seed + 3, '#3fb26a'), 21.4, 8.6, 0.75);
    add('sign', Paint.signboard('SHOP', this.accent), 12.4, 1.3, 1.2);
    add('bush', Paint.bush(seed + 60, '#4f9a3f', { flowers: '#ffd45e' }), 26.2, 3, 0.95);
    add('bush', Paint.bush(seed + 61, '#4f9a3f'), 26.2, 6, 0.95);
    this.particles = [];
    for (let i = 0; i < 50; i++) this.particles.push(this.newParticle(Math.random, true));
    this.sky = null;
    this.loadCustom(biome, seed);
    this.warp = 1;
  }

  /** Your own art (all optional): ranch/<biome>-ground.png, -sky.png, -far.png, -mid.png, -near.png, -prop1…8.png */
  loadCustom(biome, seed) {
    const token = (this.loadToken = {});
    const img = (path) => new Promise((resolve) => {
      const url = this.resolve(path);
      if (!url) { resolve(null); return; }
      const im = new Image();
      im.onload = () => resolve(im); im.onerror = () => resolve(null); im.src = url;
    });
    const pixels = (im, w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(im, 0, 0, w, h); return new Uint32Array(x.getImageData(0, 0, w, h).data.buffer); };
    img(`ranch/${biome}-ground.png`).then((im) => {
      if (!im || token !== this.loadToken) return;
      // the image covers the yard (18 × 11 units); farm and shop keep their own floors
      const w = 18 * TEX, h = 11 * TEX, px = pixels(im, w, h);
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        const tx = (-9 - X0) * TEX + x, ty = (0 - Z0) * TEX + y;
        this.floor.col[ty * TXW + tx] = px[(h - 1 - y) * w + x] | 0xff000000;
        this.floor.mat[ty * TXW + tx] = 0;
      }
      this.floorKey = null;
    });
    img(`ranch/${biome}-sky.png`).then((im) => { if (im && token === this.loadToken) this.sky = im; });
    ['far', 'mid', 'near'].forEach((k, i) => img(`ranch/${biome}-${k}.png`).then((im) => { if (im && token === this.loadToken) this.layers[i] = { ...this.layers[i], img: im }; }));
    const r = rngFrom(seed * 97 + 5);
    for (let i = 1; i <= 8; i++) img(`ranch/${biome}-prop${i}.png`).then((im) => {
      if (!im || token !== this.loadToken) return;
      for (let k = 0; k < 2; k++) { const at = this.randomSpot(r, true); this.props.push({ kind: 'custom', img: im, x: at.x, z: at.z, h: im.height / 18, solid: true }); }
    });
  }

  matAt(x, z) {
    const tx = Math.floor((x - X0) * TEX), tz = Math.floor((z - Z0) * TEX);
    if (tx < 0 || tz < 0 || tx >= TXW || tz >= TXH) return 255;
    return this.floor.mat[tz * TXW + tx];
  }
  /** Can this creature (or any creature, without one) stand here? Swimmers go in water, fliers anywhere. */
  walkable(x, z, a = null) {
    if (x < -8.6 || x > 8.6 || z < 0.7 || z > 9.1) return false;
    const m = this.matAt(x, z);
    if (m === 1 && !(a?.swim || a?.fly)) return false;
    if (m === 2 && !(a?.fly || a?.fire)) return false;
    if (a?.fly) return true;
    return !this.props.some((p) => p.solid && !p.float && (p.x - x) ** 2 + (p.z - z) ** 2 < Math.min(1.2, 0.18 + p.h * 0.12));
  }
  /** A spot in the water, if this yard has any. */
  waterSpot() {
    for (let i = 0; i < 80; i++) {
      const x = (Math.random() * 2 - 1) * 8.2, z = 0.8 + Math.random() * 8.2;
      if (this.matAt(x, z) === 1) return { x, z };
    }
    return null;
  }
  randomSpot(r = Math.random, edge = false) {
    for (let i = 0; i < 60; i++) {
      const x = (r() * 2 - 1) * 8.2, z = edge ? 6 + r() * 3 : 0.8 + Math.pow(r(), 1.4) * 7.6; // favour the front, where there is more to see
      if (this.walkable(x, z)) return { x, z };
    }
    return { x: 0, z: 3 };
  }

  newParticle(r = Math.random, anywhere = false) {
    const kind = this.L.fx;
    const x0 = this.camX - 12 + r() * 24;
    const p = { x: x0, y: anywhere ? r() * 5 : 0, z: 0.5 + r() * 9.5, vx: 0, vy: 0, vz: 0, life: 4 + r() * 6, ph: r() * 6, kind };
    if (kind === 'snow') { p.y = anywhere ? r() * 7 : 6.5; p.vy = -0.7 - r() * 0.4; p.vx = 0.2; }
    else if (kind === 'ember') { p.vy = 0.6 + r() * 0.8; }
    else if (kind === 'bubble') { p.vy = 0.5 + r() * 0.5; }
    else if (kind === 'sand') { p.y = r() * 1.5; p.vx = 1.2 + r(); }
    else if (kind === 'feather') { p.y = 1 + r() * 4; p.vy = -0.25; p.vx = 0.3; }
    else { p.y = 0.3 + r() * 3; p.vx = (r() - 0.5) * 0.3; p.vz = (r() - 0.5) * 0.3; }
    return p;
  }

  setCreatures(list) {
    const keep = new Set(list.map((c) => c.uid));
    for (const uid of [...this.actors.keys()]) if (!keep.has(uid)) this.actors.delete(uid);
    let i = 0;
    for (const c of list) {
      let a = this.actors.get(c.uid);
      if (!a) {
        const at = this.randomSpot();
        a = { uid: c.uid, x: at.x, z: at.z, y: 0, vy: 0, vx: 0, vz: 0, tx: at.x, tz: at.z, state: 'idle', timer: 1 + Math.random() * 2, flip: false, ft: Math.random() * 4, blink: 3, hop: 0, appear: -0.25 * i - 0.2, squash: 0 };
        this.actors.set(c.uid, a);
      }
      i++;
      Object.assign(a, { speciesId: c.speciesId, name: c.name, mood: c.mood, speed: c.speed ?? 1.2, swim: !!c.swim, fly: !!c.fly, fire: !!c.fire });
    }
  }
  setSizeScale(v) { this.sizeScale = Math.max(0.3, Math.min(2.5, Number(v) || 1)); }
  /** How tall this actor stands, in units. */
  heightOf(a) { return CREATURE_H * this.sizeScale * sizeFactor(this.bank?.idx?.species.get(a.speciesId)); }
  setPlots(list) { this.plots = list; this.plotImgs = list.map((p, i) => (p?.empty ? null : [0, 1, 2].map((k) => plantImg(p.stage, p.item?.color ?? '#c0306a', i * 3 + k + 1)))); }

  materialize() { let i = 0; for (const a of this.actors.values()) { const at = this.randomSpot(); Object.assign(a, { x: at.x, z: at.z, tx: at.x, tz: at.z, y: 0, vy: 0, state: 'idle', timer: 1.5 + Math.random() * 2, appear: -0.22 * i++ - 0.3 }); } this.warp = 1; }

  goZone(zone) {
    if (!ZONES[zone]) return;
    this.zone = zone;
    this.camTarget = ZONES[zone].center;
    this.onZone(zone);
  }
  /** Turn the view (d = -1 left, +1 right), or 0 to face the yard straight on. */
  turn(d) { this.yawTarget = d === 0 ? 0 : Math.max(-MAX_YAW, Math.min(MAX_YAW, this.yawTarget + d * 0.17)); }
  step(d) { const i = ORDER.indexOf(this.zone); const n = ORDER[i + d]; if (n) this.goZone(n); }

  react(uid, kind, n = 3) {
    const a = this.actors.get(uid);
    if (!a) return;
    if (['hearts', 'note', 'sparkle'].includes(kind)) { if (a.state !== 'held' && a.state !== 'falling') { a.state = 'happy'; a.timer = 1.6; } a.hop = 1; }
    if (kind === 'sleep') { a.state = 'sleep'; a.timer = 8; }
    if (kind === 'munch') { a.state = 'eat'; a.timer = 2; }
    for (let i = 0; i < n; i++) this.reacts.push({ uid, kind, t: -i * 0.2, life: 1.5, dx: (Math.random() - 0.5) * 0.8 });
  }

  throwBall() {
    const at = this.randomSpot();
    this.ball = { x: this.camX + (Math.random() - 0.5) * 2, y: 1.5, z: 0.6, vx: (at.x - this.camX) * 0.6, vy: 5, vz: (at.z - 0.6) * 0.55, t: 0 };
    for (const a of this.actors.values()) if (a.state !== 'sleep' && a.state !== 'held' && a.appear >= 1) { a.state = 'chase'; a.timer = 6; }
  }

  // ---------- camera ----------
  /** Where an actor is on screen, in page pixels (for effects drawn over the yard). */
  screenRect(uid) {
    const a = this.actors.get(uid);
    if (!a) return null;
    const tall = this.heightOf(a);
    const p = this.project(a.x, (a.y || 0) + tall / 2, a.z);
    if (!p || p.z <= 0) return null;
    const r = this.canvas.getBoundingClientRect();
    const sx = r.width / this.W, sy = r.height / this.H;
    const size = Math.max(40, Math.min(140, p.k * tall * 1.1 * sx));
    return { left: r.left + p.x * sx - size / 2, top: r.top + p.y * sy - size / 2, width: size, height: size };
  }

  /** Camera position and turn for this frame. */
  updateCamera() {
    this.ys = Math.sin(this.yaw); this.yc = Math.cos(this.yaw);
    this.cx = this.camX - ORBIT_R * this.ys;
    this.cz = PIVOT_Z - ORBIT_R * this.yc;
  }

  project(x, y, z) {
    const wx = x - this.cx, dy = y - CAM_Y, wz = z - this.cz;
    const dx = wx * this.yc - wz * this.ys, dz = wx * this.ys + wz * this.yc;
    const s = Math.sin(PITCH), c = Math.cos(PITCH);
    const zc = -dy * s + dz * c, yc = dy * c + dz * s;
    if (zc < 0.3) return null;
    const F = this.F ?? this.H * 1.05;
    return { x: this.W / 2 + (F * dx) / zc, y: this.H / 2 - (F * yc) / zc, z: zc, k: F / zc };
  }
  /** The floor point under a screen pixel, or null above the floor. */
  floorAt(sx, sy) {
    const F = this.F, s = Math.sin(PITCH), c = Math.cos(PITCH);
    const vx = (sx - this.W / 2) / F, vy = -(sy - this.H / 2) / F;
    const dy = -s + c * vy, dz = c + s * vy;
    if (dy >= -0.01) return null;
    const t = -CAM_Y / dy;
    const wx = vx * this.yc + dz * this.ys, wz = -vx * this.ys + dz * this.yc;
    return { x: this.cx + wx * t, z: this.cz + wz * t };
  }

  // ---------- input ----------
  toBuf(e) { const r = this.canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) * (this.W / r.width), y: (e.clientY - r.top) * (this.H / r.height) }; }
  hitAt(x, y) { for (const b of this.hits.slice().reverse()) if (x >= b.x0 && x <= b.x1 && y >= b.y0 && y <= b.y1) return b; return null; }
  bindInput() {
    const c = this.canvas;
    let drag = null;
    c.addEventListener('pointerdown', (e) => {
      const p = this.toBuf(e);
      const hit = this.hitAt(p.x, p.y);
      drag = { sx: e.clientX, sy: e.clientY, last: p, hit, rub: 0, moved: 0, t: performance.now(), hist: [] };
      this.dragging = true;
      c.setPointerCapture?.(e.pointerId);
      if (hit?.uid) { this.selected = hit.uid; this.onSelect(hit.uid); }
    });
    c.addEventListener('pointermove', (e) => {
      const p = this.toBuf(e);
      if (!drag) {
        const hv = this.hitAt(p.x, p.y);
        const id = hv?.uid ?? (hv ? `plot${hv.plot}` : null);
        if (id !== this.hover) { this.hover = id; c.style.cursor = hv ? 'grab' : 'default'; }
        return;
      }
      const ddx = p.x - drag.last.x, ddy = p.y - drag.last.y;
      drag.moved += Math.abs(ddx) + Math.abs(ddy);
      drag.last = p;
      const a = drag.hit?.uid && this.actors.get(drag.hit.uid);
      if (a && a.state !== 'held') {
        // rubbing on the creature pets it; pulling it away picks it up
        const b = this.hits.find((h) => h.uid === a.uid);
        const inside = b && p.x >= b.x0 - 2 && p.x <= b.x1 + 2 && p.y >= b.y0 - 2 && p.y <= b.y1 + 2;
        if (inside) { drag.rub += Math.abs(ddx) + Math.abs(ddy); if (drag.rub > 26) { drag.rub = 0; this.onPet(a.uid); } }
        else if (drag.moved > 4) { a.state = 'held'; a.vy = 0; this.lift = 0; c.style.cursor = 'grabbing'; }
      }
      if (a && a.state === 'held') {
        const fp = this.floorAt(p.x, Math.min(this.H - 1, p.y + 26));
        if (fp) {
          const nx = Math.max(-8.6, Math.min(8.6, fp.x)), nz = Math.max(0.7, Math.min(9.1, fp.z));
          drag.hist.push({ x: nx, z: nz, t: performance.now() }); if (drag.hist.length > 6) drag.hist.shift();
          if (nx !== a.x) a.flip = nx < a.x;
          a.x = nx; a.z = nz;
        }
      } else if (!drag.hit) {
        // dragging empty ground looks around the zone a little
        // dragging empty ground turns the camera around the yard (and slides a little)
        const zn = ZONES[this.zone];
        this.yawTarget = Math.max(-MAX_YAW, Math.min(MAX_YAW, this.yawTarget + ddx * 0.0022));
        this.camTarget = Math.max(zn.center - 2.4, Math.min(zn.center + 2.4, this.camTarget - ddx * 0.012));
      }
    });
    const end = () => {
      if (!drag) return;
      const a = drag.hit?.uid && this.actors.get(drag.hit.uid);
      if (a && a.state === 'held') {
        const h = drag.hist;
        if (h.length >= 2) { const dt = Math.max(0.016, (h[h.length - 1].t - h[0].t) / 1000); a.vx = Math.max(-9, Math.min(9, (h[h.length - 1].x - h[0].x) / dt)); a.vz = Math.max(-9, Math.min(9, (h[h.length - 1].z - h[0].z) / dt)); }
        a.state = 'falling';
        this.onDrop(a.uid, Math.hypot(a.vx, a.vz));
      } else if (drag.hit && drag.hit.plot != null && drag.moved < 6) this.onPlot(drag.hit.plot);
      else if (!drag.hit && drag.moved < 4) { this.selected = null; this.onSelect(null); }
      drag = null;
      this.dragging = false;
      c.style.cursor = 'default';
    };
    c.addEventListener('pointerup', end);
    c.addEventListener('pointercancel', end);
    c.addEventListener('lostpointercapture', end);
    window.addEventListener('pointerup', end);
    window.addEventListener('blur', end);
  }

  // ---------- simulation ----------
  updateActors(dt) {
    for (const a of this.actors.values()) {
      a.ft += dt;
      a.appear = Math.min(1, a.appear + dt * 1.4);
      a.squash = Math.max(0, a.squash - dt * 4);
      if (a.appear < 1) continue;
      a.hop = Math.max(0, a.hop - dt * 2.5);
      a.blink -= dt; if (a.blink < -0.15) a.blink = 2 + Math.random() * 4;
      if (a.state === 'held') {
        // let go somewhere we never heard about (outside the window): drop it
        if (!this.dragging) { a.state = 'falling'; a.vx = a.vz = 0; }
        else { a.y += (1.1 + Math.sin(this.time * 9) * 0.06 - a.y) * Math.min(1, dt * 14); continue; }
      }
      // anything still off the ground that isn't being carried falls back down
      if (a.state !== 'falling' && a.y > 0.001) { a.state = 'falling'; a.vy = a.vy || 0; }
      if (a.state === 'falling') {
        a.vy -= 22 * dt; a.y += a.vy * dt;
        a.x += a.vx * dt; a.z += a.vz * dt;
        if (a.x < -8.6 || a.x > 8.6) { a.x = Math.max(-8.6, Math.min(8.6, a.x)); a.vx *= -0.5; }
        if (a.z < 0.7 || a.z > 9.1) { a.z = Math.max(0.7, Math.min(9.1, a.z)); a.vz *= -0.5; }
        if (a.y <= 0) {
          a.y = 0;
          if (Math.abs(a.vy) > 3) { a.vy = -a.vy * 0.35; a.vx *= 0.6; a.vz *= 0.6; a.squash = 1; }
          else { a.vy = 0; a.vx = 0; a.vz = 0; a.state = 'happy'; a.timer = 1.2; a.squash = 1; }
        }
        continue;
      }
      a.timer -= dt;
      const moving = a.state === 'walk' || a.state === 'chase';
      if (a.state === 'chase' && this.ball) { a.tx = this.ball.x; a.tz = this.ball.z; }
      if (moving) {
        const dx = a.tx - a.x, dz = a.tz - a.z, d = Math.hypot(dx, dz);
        // swimmers are quick in water and slow on land; everyone else wades nowhere
        const wet = this.matAt(a.x, a.z) === 1;
        const sp = (a.state === 'chase' ? 2.4 : 1) * a.speed * (a.fly ? 1.15 : a.swim ? (wet ? 1.5 : 0.75) : 1);
        a.wet = wet && !a.fly;
        if (d < 0.25 || a.timer < 0) { a.state = a.state === 'chase' ? 'happy' : 'idle'; a.timer = 1.5 + Math.random() * 3; if (a.state === 'happy') a.hop = 1; }
        else {
          const nx = a.x + (dx / d) * sp * dt, nz = a.z + (dz / d) * sp * dt;
          const m2 = this.matAt(nx, nz), chaseOk = a.state === 'chase' && (m2 !== 1 || a.swim || a.fly) && (m2 !== 2 || a.fly || a.fire);
          if (this.walkable(nx, nz, a) || chaseOk) { a.x = Math.max(-8.6, Math.min(8.6, nx)); a.z = Math.max(0.7, Math.min(9.1, nz)); }
          else { a.state = 'idle'; a.timer = 0.4; }
          if (Math.abs(dx) > 0.05) a.flip = dx < 0;
        }
      } else if (a.timer < 0) {
        if (a.state === 'sleep' && a.mood === 'sleepy' && Math.random() < 0.6) { a.timer = 6; continue; }
        if (a.mood === 'sleepy' && Math.random() < 0.35) { a.state = 'sleep'; a.timer = 8 + Math.random() * 6; continue; }
        if (Math.random() < 0.65) { const at = (a.swim && Math.random() < 0.6 && this.waterSpot()) || this.randomSpot(); a.tx = at.x; a.tz = at.z; a.state = 'walk'; a.timer = 9; }
        else { a.state = 'idle'; a.timer = 1.5 + Math.random() * 3; }
      }
    }
  }
  updateBall(dt) {
    const b = this.ball;
    if (!b) return;
    b.t += dt;
    b.vy -= 14 * dt; b.x += b.vx * dt; b.y += b.vy * dt; b.z += b.vz * dt;
    if (b.y < 0.15) { b.y = 0.15; b.vy = Math.abs(b.vy) > 1 ? -b.vy * 0.55 : 0; b.vx *= 0.8; b.vz *= 0.8; }
    if (b.x < -8.6 || b.x > 8.6) { b.x = Math.max(-8.6, Math.min(8.6, b.x)); b.vx *= -0.6; }
    if (b.z < 0.7 || b.z > 9.2) { b.z = Math.max(0.7, Math.min(9.2, b.z)); b.vz *= -0.6; }
    if (b.t > 7) this.ball = null;
  }
  updateParticles(dt) {
    for (const p of this.particles) {
      p.life -= dt; p.ph += dt;
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
      if (p.kind === 'firefly' || p.kind === 'pollen' || p.kind === 'dust' || p.kind === 'sparkle') { p.x += Math.sin(p.ph * 1.3) * dt * 0.4; p.y += Math.cos(p.ph) * dt * 0.2; }
      if (p.life < 0 || p.y > 8 || p.y < -0.2 || Math.abs(p.x - this.camX) > 14) Object.assign(p, this.newParticle());
    }
  }

  // ---------- drawing ----------
  drawBackdrop(ctx) {
    const { W, yBack } = this;
    const L = this.L;
    if (this.sky) {
      const img = this.sky;
      const off = ((-(this.camX * 2 + this.yaw * 260)) % img.width + img.width) % img.width;
      const sc = (yBack + 4) / img.height;
      const w = img.width * sc;
      for (let x = -off * sc; x < W; x += w) ctx.drawImage(img, x, 0, w, yBack + 4 + Math.abs(this.backTilt ?? 0) * W * 0.6);
    } else {
      const g = ctx.createLinearGradient(0, 0, 0, yBack);
      g.addColorStop(0, L.sky[0]); g.addColorStop(1, L.sky[1]);
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, yBack + 4 + Math.abs(this.backTilt ?? 0) * W * 0.6);
      if (L.sun) {
        const sx = W * (0.25 + ((L.sun[0] * 0.13) % 0.5)) - this.camX * 1.2 - this.yaw * this.F, sy = yBack * 0.36, rr = 34;
        const glow = ctx.createRadialGradient(sx, sy, rr * 0.6, sx, sy, rr * 4);
        glow.addColorStop(0, `rgba(${hexRgb(L.sun[2]).join(',')},0.55)`); glow.addColorStop(1, `rgba(${hexRgb(L.sun[2]).join(',')},0)`);
        ctx.fillStyle = glow; ctx.fillRect(sx - rr * 4, sy - rr * 4, rr * 8, rr * 8);
        for (let y = -rr; y <= rr; y++) {
          const half = Math.sqrt(rr * rr - y * y);
          const t = (y + rr) / (2 * rr);
          ctx.fillStyle = `rgb(${mixRgb(hexRgb(L.sun[2]), hexRgb(L.sun[3]), t * 0.8).map((v) => v | 0).join(',')})`;
          ctx.fillRect(Math.round(sx - half), Math.round(sy + y), Math.round(half * 2), 1);
        }
      }
      if (L.night || L.cave || L.nebula || L.underwater) {
        for (let i = 0; i < 160; i++) {
          const x = ((hash2(i, 3) * W * 2 - this.camX * 0.8 - this.yaw * this.F) % W + W) % W, y = hash2(i, 9) * yBack * 0.9;
          if (L.underwater) { if (i % 4) continue; ctx.fillStyle = 'rgba(160,220,255,.10)'; ctx.fillRect(Math.round(x), 0, 12, yBack); continue; }
          if (Math.sin(this.time * 2 + i) > -0.3) { ctx.fillStyle = i % 7 ? '#ffffff' : '#c89bff'; const sz = i % 11 === 0 ? 2 : 1; ctx.fillRect(Math.round(x), Math.round(y), sz, sz); }
        }
      }
      for (const cl of this.clouds ?? []) {
        const span = W + cl.img.width * 2;
        const x = (((cl.x * span + this.time * cl.v - this.camX * 4 - this.yaw * this.F) % span) + span) % span - cl.img.width;
        ctx.drawImage(cl.img, Math.round(x), Math.round(cl.y * yBack));
      }
    }
    // three parallax strips, far to near, sitting on the floor's far edge
    const pxPerUnit = this.F / (FLOOR_END - CAM_Z);
    const turn = this.yaw * this.F * 0.92; // turning slides the scenery like looking around
    ctx.save();
    ctx.translate(W / 2, this.backY ?? yBack);
    ctx.rotate(this.backTilt ?? 0);
    ctx.translate(-W / 2, -yBack);
    for (const ly of this.layers) {
      const img = ly.img;
      const off = ((((this.camX * pxPerUnit + turn) * ly.f) % img.width) + img.width) % img.width;
      const top = yBack + 3 - img.height;
      for (let x = -off - img.width; x < W + img.width; x += img.width) ctx.drawImage(img, Math.round(x), top);
      // fill under the strip so a leaning edge never shows a gap
      ctx.fillStyle = ly.base ?? 'rgba(0,0,0,0)';
      if (ly.base) ctx.fillRect(-W * 0.2, yBack + 2, W * 1.4, 40);
    }
    ctx.restore();
  }

  renderFloor() {
    const { W, H, buf, F } = this;
    // the floor only needs redrawing when the camera moves, or now and then for water and lava
    this.floorTick = (this.floorTick ?? 0) + 1;
    const key = `${this.camX.toFixed(3)}:${this.yaw.toFixed(4)}:${W}`;
    if (key === this.floorKey && !(this.floorAnimated && this.floorTick % 3 === 0)) { this.ctx.drawImage(this.floorCanvas, 0, 0); return; }
    this.floorKey = key;
    buf.fill(0);
    const s = Math.sin(PITCH), c = Math.cos(PITCH), t = this.time;
    const col = this.floor.col, mat = this.floor.mat;
    const [wr, wg, wb] = this.c.water;
    const LAVA = [P('#ffe27a'), P('#ff8a3d'), P('#e5482d')], ICE = [P('#ffffff'), P('#bfe4fb')];
    const L = this.L;
    const ys = this.ys, yc = this.yc, cx = this.cx, cz = this.cz, tilt = Math.abs(this.backTilt ?? 0) * W * 0.6 + 4;
    for (let sy = Math.max(0, Math.floor(this.yBack - tilt)); sy < H; sy++) {
      const vy = -(sy - H / 2) / F;
      const dy = -s + c * vy, dzc = c + s * vy;
      if (dy >= -0.001) continue;
      const tt = -CAM_Y / dy;
      // along a screen row the floor point moves in a straight line (turned by the camera's yaw)
      const vx0 = (-W / 2) / F, dvx = 1 / F;
      let x = cx + tt * (vx0 * yc + dzc * ys), z = cz + tt * (-vx0 * ys + dzc * yc);
      const sxStep = tt * dvx * yc, szStep = -tt * dvx * ys;
      const zMid = cz + tt * dzc * yc;
      const fog = Math.max(0, Math.min(0.35, (zMid - 5) / 22));
      for (let sx = 0; sx < W; sx++, x += sxStep, z += szStep) {
        if (z > FLOOR_END) continue;
        const tz = Math.floor((z - Z0) * TEX);
        if (tz < 0 || tz >= TXH) continue;
        const tx = Math.floor((x - X0) * TEX);
        if (tx < 0 || tx >= TXW) continue;
        const i = tz * TXW + tx;
        const m = mat[i];
        let out = col[i];
        if (m === 1) { const wave = Math.sin(x * 2.1 + t * 1.6) + Math.sin(z * 2.7 - t * 1.2); const k = wave > 1.4 ? 0.45 : wave > 0.9 ? 0.18 : 0; out = pack(wr + (255 - wr) * k, wg + (255 - wg) * k, wb + (255 - wb) * k); }
        else if (m === 2) { const fl = Math.sin(x * 3 + t * 2) * Math.sin(z * 2.3 - t * 1.4); out = fl > 0.45 ? LAVA[0] : fl > -0.2 ? LAVA[1] : LAVA[2]; }
        else if (m === 3) { const g = 0.55 + 0.45 * Math.sin(t * 2 + x + z); const gc = this.c.grid; out = pack(gc[0] * g + 40, gc[1] * g + 20, gc[2] * g + 40); }
        else if (m === 4) out = (tx + tz + ((t * 6) | 0)) % 23 === 0 ? ICE[0] : ICE[1];
        if (L.caustics && !m) { const cst = Math.sin(x * 3.1 + t) + Math.sin(z * 2.6 - t * 0.8) + Math.sin((x + z) * 1.7 + t * 1.3); if (cst > 2.1) out = pack((out & 255) + 40, ((out >> 8) & 255) + 40, ((out >> 16) & 255) + 40); }
        if (fog > 0) { const sk = this.c.sky1; out = pack((out & 255) + (sk[0] - (out & 255)) * fog, ((out >> 8) & 255) + (sk[1] - ((out >> 8) & 255)) * fog, ((out >> 16) & 255) + (sk[2] - ((out >> 16) & 255)) * fog); }
        buf[sy * W + sx] = out;
      }
    }
    this.fctx.putImageData(this.img, 0, 0);
    this.ctx.drawImage(this.floorCanvas, 0, 0);
  }

  frame(dt) {
    this.time += dt;
    this.camX += (this.camTarget - this.camX) * Math.min(1, dt * 4);
    this.yaw += (this.yawTarget - this.yaw) * Math.min(1, dt * 5);
    if (Math.abs(this.yawTarget - this.yaw) < 1e-4) this.yaw = this.yawTarget;
    this.updateCamera();
    // the far fence line leans a little when the camera turns; the scenery leans with it
    {
      const l = this.project(this.camX - 16, 0, FLOOR_END), r = this.project(this.camX + 16, 0, FLOOR_END);
      const m = this.project(this.camX, 0, FLOOR_END);
      this.backTilt = l && r ? Math.atan2(r.y - l.y, r.x - l.x) : 0;
      this.backY = m ? m.y + (this.W / 2 - m.x) * Math.tan(this.backTilt) : this.yBack;
    }
    this.warp = Math.max(0, this.warp - dt * 1.2);
    this.updateActors(dt);
    this.updateBall(dt);
    this.updateParticles(dt);
    const ctx = this.ctx;
    ctx.imageSmoothingEnabled = false;
    this.drawBackdrop(ctx);
    this.renderFloor();
    const items = [];
    const add = (x, y, z, draw) => { const q = this.project(x, y, z); if (q && q.x > -200 && q.x < this.W + 200) items.push({ z: q.z, q, draw }); };
    // fences: back line for each zone, the yard's sides with gaps for the gates
    const seg = 1.6;
    for (let x = X0 + seg / 2; x < X1; x += seg) {
      const zone = x < -9.4 ? 'farm' : x > 9.4 ? 'shop' : 'yard';
      add(x, 0, BACK, (q) => this.drawBill(ctx, this.fence[zone], q, (seg * q.k) / this.fence[zone].width, zone === 'yard'));
    }
    for (const sx of [-9.4, 9.4]) for (let z = 2.6; z < BACK; z += 1.1) add(sx, 0, z, (q) => this.drawBill(ctx, this.fence.yard, q, (1.3 * q.k) / this.fence.yard.width, true));
    for (const ex of [X0 + 0.4, X1 - 0.4]) for (let z = 0.5; z < BACK; z += 1.1) { const f = this.fence[ex < 0 ? 'farm' : 'shop']; add(ex, 0, z, (q) => this.drawBill(ctx, f, q, (1.3 * q.k) / f.width, false)); }
    for (const p of this.props) {
      const y = p.float ? p.y + Math.sin(this.time + p.bob) * 0.15 : 0;
      add(p.x, y, p.z, (q) => this.drawProp(ctx, p, q));
    }
    this.plots.forEach((pl, i) => {
      const [px, pz] = PLOTS[i];
      const imgs = this.plotImgs?.[i];
      [-1.05, 0, 1.05].forEach((dx, k) => {
        add(px + dx, 0, pz + 0.05 + (k % 2) * 0.25, (q) => {
          if (k === 1) this.hits.push({ plot: i, x0: q.x - 1.7 * q.k, x1: q.x + 1.7 * q.k, y0: q.y - 1.5 * q.k, y1: q.y + 1.2 * q.k });
          const img = imgs?.[k];
          if (img) { const hh = (img.height / 64) * 0.9 * q.k, ww = (img.width / img.height) * hh; ctx.drawImage(img, Math.round(q.x - ww / 2), Math.round(q.y - hh), Math.round(ww), Math.round(hh)); }
          if (k === 1 && pl?.ready && Math.sin(this.time * 4) > 0) { ctx.fillStyle = '#ffffff'; const s = Math.max(2, Math.round(q.k * 0.06)); ctx.fillRect(Math.round(q.x + q.k * 0.4), Math.round(q.y - q.k * 0.9), s, s * 3); ctx.fillRect(Math.round(q.x + q.k * 0.4 - s), Math.round(q.y - q.k * 0.9 + s), s * 3, s); }
          if (k === 1 && pl?.ready) this.label(ctx, 'Ready to pick', q.x, q.y - 1.6 * q.k, '#ffffff');
          else if (k === 1 && this.hover === `plot${i}`) this.label(ctx, pl?.empty ? 'Plant here' : `${Math.round((pl?.frac ?? 0) * 100)}% grown`, q.x, q.y - 1.4 * q.k);
        });
      });
    });
    for (const a of this.actors.values()) add(a.x, 0, a.z, (q) => this.drawActor(ctx, a, q));
    if (this.ball) { const b = this.ball; add(b.x, 0, b.z, () => { const q = this.project(b.x, b.y, b.z); if (!q) return; const sh = this.project(b.x, 0, b.z); const s = Math.max(2, Math.round(q.k * 0.32)); ctx.fillStyle = 'rgba(10,8,30,.25)'; ctx.fillRect(Math.round(sh.x - s / 2), Math.round(sh.y - 1), s, 2); const toy = artImage('ui/toy-ball.png'); if (toy) { ctx.drawImage(toy, Math.round(q.x - s / 2), Math.round(q.y - s), s, s); return; } ctx.fillStyle = '#e5484d'; ctx.fillRect(Math.round(q.x - s / 2), Math.round(q.y - s), s, Math.ceil(s / 2)); ctx.fillStyle = '#ffffff'; ctx.fillRect(Math.round(q.x - s / 2), Math.round(q.y - s / 2), s, Math.ceil(s / 2)); }); }
    for (const p of this.particles) add(p.x, p.y, p.z, (q) => this.drawParticle(ctx, p, q));
    items.sort((a, b) => b.z - a.z);
    this.hits = [];
    for (const it of items) it.draw(it.q);
    this.drawReactions(ctx, dt);
    const tag = this.actors.get(this.hover) ?? this.actors.get(this.selected);
    if (tag?.name) { const b = this.hits.find((h) => h.uid === tag.uid); if (b) this.label(ctx, tag.name, (b.x0 + b.x1) / 2, b.y0 - 12); }
    if (this.warp > 0) {
      ctx.fillStyle = `rgba(200,255,240,${(this.warp * 0.5).toFixed(3)})`;
      ctx.fillRect(0, 0, this.W, this.H);
      ctx.fillStyle = `rgba(125,255,207,${(this.warp * 0.5).toFixed(3)})`;
      for (let y = (this.time * 300) % 6; y < this.H; y += 6) ctx.fillRect(0, Math.round(y), this.W, 1);
    }
  }

  drawBill(ctx, img, q, s, shimmer = false) {
    const w = Math.max(1, Math.round(img.width * s)), h = Math.max(1, Math.round(img.height * s));
    ctx.drawImage(img, Math.round(q.x - w / 2), Math.round(q.y - h + 1), w + 1, h);
    if (shimmer) {
      // the habitat's holographic boundary shimmers above the fence
      const a = 0.07 + 0.05 * Math.sin(this.time * 2 + q.x * 0.05);
      ctx.fillStyle = `rgba(125,255,207,${a.toFixed(3)})`;
      ctx.fillRect(Math.round(q.x - w / 2), Math.round(q.y - h - 2.5 * q.k), w + 1, Math.round(2.5 * q.k));
    }
  }
  drawProp(ctx, p, q) {
    const k = (q.k * p.h) / p.img.height;
    const w = Math.max(1, Math.round(p.img.width * k)), h = Math.max(1, Math.round(p.img.height * k));
    let y0 = q.y - h;
    if (p.bot) y0 += Math.sin(this.time * 3) * 2;
    if (p.kind === 'tree' || p.kind === 'pine' || p.kind === 'palm' || p.kind === 'snowpine') {
      // a gentle sway in the wind
      const sway = Math.sin(this.time * 0.9 + p.x) * 0.012;
      ctx.save(); ctx.translate(q.x, q.y); ctx.transform(1, 0, sway, 1, 0, 0); ctx.drawImage(p.img, Math.round(-w / 2), Math.round(-h), w, h); ctx.restore();
    } else ctx.drawImage(p.img, Math.round(q.x - w / 2), Math.round(y0), w, h);
    if (p.beacon) {
      const pulse = 0.5 + 0.5 * Math.sin(this.time * 3);
      ctx.fillStyle = `rgba(125,255,207,${(0.1 + pulse * 0.16).toFixed(3)})`;
      const bw = Math.max(2, Math.round(q.k * 0.22));
      ctx.fillRect(Math.round(q.x - bw / 2), 0, bw, Math.round(y0 + 2));
    }
  }

  drawActor(ctx, a, q) {
    const entry = this.bank.get(a.speciesId);
    const tall = this.heightOf(a) * q.k; // visible pixels
    const fit = fitSprite(entry, tall, 0);
    const pxH = fit.size;
    const hop = Math.sin(a.hop * Math.PI) * 0.35 * q.k * Math.min(1, this.heightOf(a));
    const lift = a.y * q.k;
    // shadow stays on the ground, shrinking as it is lifted
    const sw = Math.max(3, Math.round(pxH * (fit.box.right - fit.box.left) * 0.85 / (1 + a.y * 0.6)));
    ctx.fillStyle = 'rgba(10,8,30,.28)';
    ctx.fillRect(Math.round(q.x - sw / 2), Math.round(q.y - 1), sw, Math.max(2, Math.round(q.k * 0.12)));
    if (this.selected === a.uid && a.state !== 'held') {
      ctx.strokeStyle = Math.sin(this.time * 5) > 0 ? '#7dffcf' : '#ffffff';
      ctx.strokeRect(Math.round(q.x - sw / 2 - 3) + 0.5, Math.round(q.y - 3) + 0.5, sw + 6, Math.max(3, Math.round(q.k * 0.2)));
    }
    let anim = 'idle', frame = Math.floor(a.ft * 2);
    if (a.state === 'walk' || a.state === 'chase') { anim = 'walk'; frame = Math.floor(a.ft * 6); }
    else if (a.state === 'sleep') { anim = 'sleep'; frame = Math.floor(a.ft); }
    else if (a.state === 'happy' || a.state === 'eat') { anim = 'happy'; frame = Math.floor(a.ft * 4); }
    else if (a.state === 'held' || a.state === 'falling') { anim = 'walk'; frame = Math.floor(a.ft * 10); }
    else if (a.blink < 0) anim = 'blink';
    const list = entry.frames[anim] ?? entry.frames.idle;
    const img = list[((frame % list.length) + list.length) % list.length] ?? list[0];
    const sq = a.squash * 0.25;
    const w = Math.round(pxH * (1 + sq)), hh = Math.round(pxH * (1 - sq));
    const x0 = Math.round(q.x - w / 2 + (0.5 - (fit.box.left + fit.box.right) / 2) * w), y0 = Math.round(q.y - hh * fit.box.bottom - hop - lift + 1);
    const paint = () => {
      ctx.save();
      ctx.imageSmoothingEnabled = false;
      if (a.state === 'held') { ctx.translate(q.x, y0); ctx.rotate(Math.sin(this.time * 7) * 0.12); ctx.translate(-q.x, -y0); }
      if (a.flip) { ctx.translate(x0 + w, y0); ctx.scale(-1, 1); ctx.drawImage(img, 0, 0, w, hh); } else ctx.drawImage(img, x0, y0, w, hh);
      ctx.restore();
    };
    if (a.appear < 1) {
      if (a.appear <= 0) return;
      const bw = Math.max(3, Math.round(w * 0.6));
      ctx.fillStyle = `rgba(125,255,207,${(0.6 * (1 - a.appear)).toFixed(3)})`;
      ctx.fillRect(Math.round(q.x - bw / 2), 0, bw, Math.round(q.y));
      const shown = Math.max(0, (a.appear - 0.2) / 0.8);
      ctx.save(); ctx.beginPath(); ctx.rect(0, Math.round(q.y - hh * shown), this.W, Math.ceil(hh * shown) + 1); ctx.clip(); paint(); ctx.restore();
      return;
    }
    paint();
    // small creatures get a slightly bigger target so they are still easy to grab
    const b = fit.box, pad = Math.max(0, 14 - tall) / 2;
    this.hits.push({ uid: a.uid, x0: x0 + w * b.left - pad, x1: x0 + w * b.right + pad, y0: y0 + hh * b.top - pad, y1: y0 + hh * b.bottom + 2 });
    if (a.state === 'sleep' && Math.sin(this.time * 2) > 0) this.label(ctx, 'z', q.x + w * b.right * 0.6, y0 + hh * b.top, '#ffffff', true);
  }

  drawParticle(ctx, p, q) {
    const s = Math.max(1, Math.round(q.k / 26));
    let c = '#ffffff';
    switch (p.kind) {
      case 'pollen': c = '#fff3a0'; break;
      case 'firefly': if (Math.sin(p.ph * 3) < 0) return; c = '#e8ff7a'; ctx.fillStyle = 'rgba(232,255,122,.25)'; ctx.fillRect(q.x - 2, q.y - 2, 5, 5); break;
      case 'ember': c = p.y > 2.5 ? '#ff6a2a' : '#ffd45e'; break;
      case 'sand': c = '#fff0c8'; break;
      case 'bubble': ctx.strokeStyle = 'rgba(200,240,255,.8)'; ctx.strokeRect(Math.round(q.x) + 0.5, Math.round(q.y) + 0.5, s + 1, s + 1); return;
      case 'dust': c = 'rgba(200,190,230,.6)'; break;
      case 'sparkle': if (Math.sin(p.ph * 4) < 0.2) return; ctx.fillStyle = Math.sin(p.ph) > 0 ? '#ffffff' : this.L.rim; ctx.fillRect(Math.round(q.x) - 1, Math.round(q.y), 3, 1); ctx.fillRect(Math.round(q.x), Math.round(q.y) - 1, 1, 3); return;
      case 'feather': ctx.fillStyle = '#fff0fa'; ctx.fillRect(Math.round(q.x), Math.round(q.y), 3, 1); return;
      case 'spray': c = 'rgba(255,255,255,.7)'; break;
      default: break;
    }
    ctx.fillStyle = c;
    ctx.fillRect(Math.round(q.x), Math.round(q.y), s, s);
  }

  drawReactions(ctx, dt) {
    const SH = { hearts: ['.#.#.', '#####', '#####', '.###.', '..#..'], note: ['..##', '..#.', '..#.', '###.', '##..'], sparkle: ['..#..', '..#..', '##.##', '..#..', '..#..'], munch: ['#.#', '.#.', '#.#'], sleep: ['###', '..#', '.#.', '###'], sad: ['.#.', '###', '###'], dizzy: ['#...#', '.#.#.', '..#..', '.#.#.', '#...#'] };
    const COL = { hearts: '#ff5d8f', note: '#7db8ff', sparkle: '#ffd45e', munch: '#c98a4a', sleep: '#ffffff', sad: '#7db8ff', dizzy: '#ffd45e' };
    this.reacts = this.reacts.filter((r) => { r.t += dt; return r.t < r.life; });
    for (const r of this.reacts) {
      if (r.t < 0) continue;
      const b = this.hits.find((h) => h.uid === r.uid);
      if (!b) continue;
      const rows = SH[r.kind] ?? SH.hearts;
      const sc = 3;
      const x = Math.round((b.x0 + b.x1) / 2 + r.dx * 20 - 5), y = Math.round(b.y0 - 6 - r.t * 18);
      ctx.globalAlpha = Math.min(1, (r.life - r.t) * 2);
      ctx.fillStyle = COL[r.kind] ?? '#ff5d8f';
      rows.forEach((row, j) => [...row].forEach((ch, i) => { if (ch === '#') ctx.fillRect(x + i * sc, y + j * sc, sc, sc); }));
      ctx.globalAlpha = 1;
    }
  }

  label(ctx, text, x, y, color = '#ffffff', bare = false) {
    text = brandText(String(text));
    ctx.font = `600 ${bare ? 22 : 15}px "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif`;
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'left';
    const w = Math.ceil(ctx.measureText(text).width);
    const lx = Math.round(x - w / 2), ly = Math.round(y);
    if (!bare) {
      ctx.fillStyle = 'rgba(12,14,24,.72)';
      ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(lx - 9, ly - 13, w + 18, 26, 13); else ctx.rect(lx - 9, ly - 13, w + 18, 26); ctx.fill();
    }
    ctx.fillStyle = color;
    ctx.fillText(text, lx, ly + 1);
  }

  start() {
    if (this.running) return;
    this.running = true;
    let last = performance.now(), acc = 0;
    const loop = (now) => {
      if (!this.running) return;
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now; acc += dt;
      if (acc >= 1 / 45) { this.frame(acc); acc = 0; }
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }
  stop() { this.running = false; cancelAnimationFrame(this.raf); this.ro?.disconnect(); }
}

export { HABITAT_LOOKS };
