import { artImage } from './brandArt.js';
import { brandText } from './dom.js';
import { sizeFactor, fitSprite, animRate } from './creatureSize.js';
// R.A.N.C.H. — Remote Access Nurture & Care Hub.
// Seen from inside, at creature height. Each area is its own scene you load into: the yard (one
// per box, in the box's environment), the berry farm, the shop, and the care room (a shallow,
// close-up corner of the yard's environment for one creature). The land carries on past the
// fences on every side, and layered painted backdrops beyond it slide at different speeds
// (parallax), so the world feels endless. The floor is ray-cast per pixel; everything standing on
// it is a depth-sorted billboard. The camera turns, slides and zooms a little.
import {
  HABITAT_LOOKS, habitatLook, PROPS, FLOATS, pack, P, hexRgb, mixRgb, packA, shadeHex, rngFrom, hash2, vnoise,
} from './habitat.js';
import * as Paint from './paint.js';
import { arenaProps } from './arenaModels.js';
import { FACES, FACE_COL, MOOD_FACE } from './emote.js';
import { itemPicture } from './itemIcon.js';
import { propMesh, fenceMesh, drawMesh, planterMesh, MODEL_KINDS } from './models.js';
import { gatherLights, drawFloorLights, lightSprite, drawLightGlows, sunOf, drawGroundShadows, castShadows, sunSprite } from './lighting.js';
import { buildScatter, drawScatter } from './groundScatter.js';
import { buildArt } from './buildArt.js';
import { YARD_SIZES, blueprintOf } from '../engine/ranchBuild.js';
import { timeOfDay } from '../engine/walkLife.js';
import { yardWeather, activeSkyFix } from '../engine/sky.js';

// ---------- scenes (units; 1 unit ≈ the height of a small creature) ----------
//   x0..x1, z0..z1   where creatures can be
//   back, side       the fence lines (none in the room)
//   floorEnd         how far the land runs before the painted backdrops take over
//   X0..Z1, TEX      the floor texture's extent and detail
//   camY, camZ, pivotZ, maxYaw, slide   the camera
export const SCENES = {
  yard: { x0: -11, x1: 11, z0: 0.7, z1: 12.2, back: 12.9, side: 11.7, floorEnd: 34, X0: -46, X1: 46, Z0: -7, Z1: 36, TEX: 18, camY: 2.7, camZ: -3.7, pivotZ: 5.2, maxYaw: 0.42, slide: 2.6, fence: true },
  farm: { x0: -9, x1: 9, z0: 0.7, z1: 9.6, back: 10.3, side: 9.7, floorEnd: 30, X0: -40, X1: 40, Z0: -6, Z1: 32, TEX: 18, camY: 2.7, camZ: -3.8, pivotZ: 4.6, maxYaw: 0.36, slide: 2, fence: true },
  shop: { x0: -8, x1: 8, z0: 0.7, z1: 8.6, back: 9.3, side: 8.7, floorEnd: 30, X0: -40, X1: 40, Z0: -6, Z1: 32, TEX: 18, camY: 2.6, camZ: -3.6, pivotZ: 4.4, maxYaw: 0.34, slide: 1.6, fence: true },
  room: { x0: -4.4, x1: 4.4, z0: 0.9, z1: 4.4, back: 5.2, side: 5, floorEnd: 22, X0: -26, X1: 26, Z0: -4, Z1: 24, TEX: 22, camY: 1.35, camZ: -1.7, pivotZ: 2.3, maxYaw: 0.16, slide: 0.8, fence: false },
  // a wild battle's field: two spots (yours near, theirs far), the place all around
  battle: { x0: -7, x1: 7, z0: 0.2, z1: 10.4, back: 11.2, side: 8, floorEnd: 56, X0: -56, X1: 56, Z0: -44, Z1: 54, TEX: 18, camY: 2.1, camZ: -3.4, pivotZ: 5, maxYaw: 3.2, slide: 1, fence: false },
};
/** Where the two creatures stand in a battle (world x, z): yours near the camera on the left, theirs far right. */
// Which ground reflects (battles and the R.A.N.C.H. alike): polished or glassy floors always; hard ground when
// it's soaked by rain; and anywhere frozen (opaque ice: a faint, blurry reflection). Nothing on grass, sand or soil.
const SHINY_FLOOR = { crystal: 0.3, starfield: 0.3, prism: 0.3, synth: 0.38 };
const WET_SHINES = new Set(['volcano', 'cavern', 'crystal', 'outskirts', 'starfield', 'colosseum', 'ruins', 'prism', 'synth']);
export function reflectFor(look, { wet = false, icy = false } = {}) {
  let r = SHINY_FLOOR[look] ?? 0, water = false;
  if (wet && WET_SHINES.has(look)) { if (0.24 > r) r = 0.24; water = true; }
  if (icy && r < 0.14) r = 0.14;
  return { reflect: r, water };
}
export const BATTLE_SPOTS = { near: [-2.9, 0.5], far: [2.9, 9.5] }; // (far enough apart for the run-up and the flight to be seen)
export const FIELD_Z = 5; // the middle of the battle field
// arenas that aren't natural places: how their ground is laid out
const ARENA = { colosseum: 'colosseum', ruins: 'ruins', stadium: 'stadium', shrine: 'shrine', prism: 'prism', synth: 'neon' };
const PITCH = 0.22;
const TREE_KINDS = new Set(['tree', 'pine', 'snowpine', 'palm', 'deadtree']);
// things that give off light at night: how far up their light sits (fraction of their height)
const LIGHT_KINDS = { lamppost: 0.08, lantern: 0.12, campfire: 0.7, glowshroom: 0.3, pumpkin: 0.4, fountain: 0.6, gate: 0.1 };
const NO_WEATHER = new Set(['cavern', 'seafloor', 'crystal', 'prism', 'synth', 'starfield']);
// how often each kind of place has each weather (simulated: the same for everyone at the same time)
const WEATHER_ODDS = {
  desert: { clear: 8, windy: 3, cloudy: 1 }, tundra: { snow: 5, clear: 2, cloudy: 2, fog: 1, windy: 1 }, marsh: { rain: 3, fog: 3, cloudy: 2, clear: 2, storm: 1 },
  shoreline: { clear: 4, windy: 3, cloudy: 2, rain: 1, storm: 1 }, forest: { clear: 3, rain: 2, fog: 2, cloudy: 2 }, skyline: { clear: 3, windy: 3, cloudy: 2, snow: 1, fog: 1 },
  volcano: { clear: 4, cloudy: 3, windy: 1 }, spooky: { fog: 4, cloudy: 2, rain: 1, storm: 1 }, outskirts: { clear: 4, cloudy: 3, rain: 2, storm: 1 },
  meadow: { clear: 5, cloudy: 2, rain: 2, windy: 1, storm: 1 },
};
export function simWeather(biome, t = Date.now()) {
  const odds = WEATHER_ODDS[biome] ?? WEATHER_ODDS.meadow;
  const block = Math.floor(t / (3 * 3600000));
  let h = 2166136261; for (const ch of `${biome}:${block}`) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
  const total = Object.values(odds).reduce((a, b) => a + b, 0);
  let r = (h % 10000) / 10000 * total;
  for (const [k, v] of Object.entries(odds)) { r -= v; if (r < 0) return k; }
  return 'clear';
}
export const WEATHER_LABEL = { clear: '☀ Clear', cloudy: '☁ Cloudy', rain: '🌧 Rain', storm: '⛈ Storm', snow: '❄ Snow', fog: '🌫 Fog', windy: '🍃 Windy' };
// local time: the real sun where you are when it's known (Settings → Where you are, or the phone), else the clock
function localTod(t = Date.now()) { return activeSkyFix(t)?.tod ?? timeOfDay(t); }
const hashSeed = (s) => { let h = 2166136261; for (const ch of String(s)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0; return h % 100000; };
// a 1 m creature is this many units tall (a tree is 3.6); others follow their height, see creatureSize.js
const CREATURE_H = 1.5;
export const PLOTS = [[-4.5, 3.6], [0, 3.6], [4.5, 3.6], [-4.5, 6.8], [0, 6.8], [4.5, 6.8]];
/** Where the farm's planters go: rows of three, a row further back for each expansion. */
export const plotSpots = (level = 0) => Array.from({ length: (2 + level) * 3 }, (_, i) => [[-4.5, 0, 4.5][i % 3], 3.6 + Math.floor(i / 3) * 3.2]);
const FARM_ROW = 3.2;

// toys in the yard and the care room: how bouncy, how they roll, how big
export const TOYS = {
  ball: { bounce: 0.74, roll: 0.978, r: 0.2, label: 'Bouncy ball' },
  duck: { bounce: 0.45, roll: 0.93, r: 0.22, label: 'Squeaky duck' },
  plush: { bounce: 0.15, roll: 0.82, r: 0.26, label: 'Plush' },
  bell: { bounce: 0.32, roll: 0.975, r: 0.18, label: 'Jingle bell' },
  disc: { bounce: 0.22, roll: 0.9, r: 0.24, glide: true, label: 'Flying disc' },
  feather: { bounce: 0.05, roll: 0.7, r: 0.2, floaty: true, label: 'Feather wand' },
  ribbon: { bounce: 0.08, roll: 0.75, r: 0.2, floaty: true, label: 'Ribbon' },
  berry: { bounce: 0.25, roll: 0.9, r: 0.13 },
};
const toyImgs = new Map();
const toyImg = (kind) => { if (!toyImgs.has(kind)) toyImgs.set(kind, Paint.toy(kind)); return toyImgs.get(kind); };

// ---------- backdrop styles per biome ----------
const STYLE = {
  meadow: { far: 'mountains', mid: 'hills', near: ['tree', 'bush'], fence: 'picket', out: ['tree', 'bush', 'tree', 'rock', 'flower'] },
  forest: { far: 'mountains', mid: 'pines', near: ['pine', 'tree'], fence: 'hedge', out: ['pine', 'pine', 'tree', 'log', 'mushroom', 'bush'] },
  shoreline: { far: 'none', mid: 'sea', near: ['palm', 'rock'], fence: 'rocks', out: ['palm', 'rock', 'shell'] },
  volcano: { far: 'volcano', mid: 'spires', near: ['spire', 'lavarock'], fence: 'rocks', out: ['spire', 'lavarock', 'rock'] },
  cavern: { far: 'cave', mid: 'stalagmites', near: ['stalagmite', 'glowshroom'], fence: 'rocks', out: ['stalagmite', 'stalagmite', 'rock', 'glowshroom'] },
  tundra: { far: 'mountains', mid: 'ice', near: ['snowpine', 'icespike'], fence: 'snowbank', out: ['snowpine', 'snowpine', 'icespike', 'rock'] },
  desert: { far: 'mesas', mid: 'dunes', near: ['cactus', 'rock'], fence: 'adobe', out: ['cactus', 'rock', 'bones'] },
  skyline: { far: 'peaks', mid: 'canopy', near: ['pine', 'rock'], fence: 'rail', out: ['rock', 'rock', 'pine', 'flower'] },
  seafloor: { far: 'reef', mid: 'kelp', near: ['kelp', 'coral'], fence: 'coral', out: ['kelp', 'coral', 'rock', 'shell'] },
  marsh: { far: 'mountains', mid: 'reeds', near: ['reed', 'tree'], fence: 'reeds', out: ['reed', 'reed', 'tree', 'log'] },
  starfield: { far: 'planets', mid: 'spires', near: ['crystal', 'pillar'], fence: 'neon', out: ['crystal', 'pillar'] },
  crystal: { far: 'cave', mid: 'crystals', near: ['crystal', 'stalagmite'], fence: 'crystal', out: ['crystal', 'stalagmite'] },
  outskirts: { far: 'city', mid: 'industry', near: ['tree', 'lamppost'], fence: 'iron', out: ['tree', 'lamppost', 'bush', 'tree', 'bench'], city: true },
  spooky: { far: 'mountains', mid: 'deadwood', near: ['deadtree', 'pine'], fence: 'iron', out: ['deadtree', 'deadtree', 'grave', 'pine', 'pumpkin'] },
  prism: { far: 'shapes', mid: 'none', near: ['orb', 'pyramid'], fence: 'glass', out: ['cube', 'orb', 'pyramid', 'ring'] },
  synth: { far: 'synthsun', mid: 'gridhills', near: ['monolith', 'pyramid'], fence: 'neon', out: ['monolith', 'pyramid', 'orb'] },
  colosseum: { far: 'mesas', mid: 'dunes', near: ['rock'], fence: 'adobe', out: ['rock', 'cactus'] },
  ruins: { far: 'mountains', mid: 'pines', near: ['tree', 'rock'], fence: 'rocks', out: ['tree', 'rock', 'bush'] },
  stadium: { far: 'city', mid: 'industry', near: ['lamppost'], fence: 'iron', out: ['lamppost', 'bush'], city: true },
  shrine: { far: 'mountains', mid: 'pines', near: ['pine', 'tree'], fence: 'hedge', out: ['pine', 'tree', 'bush'] },
};

// ---------- painted props: { img, h (units tall) } ----------
const LEAF = { meadow: '#4f9a3f', forest: '#3a7d3a', marsh: '#5a7a3a', shoreline: '#4fae40', desert: '#7a9a3f', tundra: '#2f6b48' };
// painting a prop takes a while: keep a few looks of each kind per environment and reuse them
const propCache = new Map();
function paintedProp(kind, L, seed, biome) {
  const v = Math.abs(seed) % 6;
  const key = `${biome}:${kind}:${v}`;
  if (!propCache.has(key)) { propCache.set(key, paintProp(kind, L, 1000 + v * 37, biome)); if (propCache.size > 600) propCache.delete(propCache.keys().next().value); }
  return propCache.get(key);
}
function paintProp(kind, L, seed, biome) {
  const leaf = LEAF[biome] ?? '#4f9a3f';
  switch (kind) {
    case 'tree': return { img: Paint.tree(seed, leaf, { fruit: seed % 3 === 0 ? '#e5484d' : null }), h: 3.6 };
    case 'pine': return { img: Paint.pine(seed, '#2f6b48'), h: 4 };
    case 'snowpine': return { img: Paint.pine(seed, '#2e6a54', { snow: true }), h: 3.8 };
    case 'palm': return { img: Paint.palm(seed), h: 3.8 };
    case 'bush': return { img: Paint.bush(seed, leaf, { flowers: seed % 2 ? '#ff8fb6' : null }), h: 0.95 };
    case 'flower': return { img: Paint.flowers(seed, L.dots?.length ? L.dots : undefined), h: 0.45 };
    case 'tuft': return { img: Paint.grassTuft(seed, L.ground[2] ?? L.ground[0]), h: 0.38 };
    case 'rock': return { img: Paint.rock(seed, L.cliff[0], { moss: ['meadow', 'forest', 'marsh'].includes(biome) ? leaf : null, snow: biome === 'tundra' }), h: 0.95 };
    case 'mushroom': return { img: Paint.mushroom(seed), h: 0.6 };
    case 'glowshroom': return { img: Paint.mushroom(seed, '#4ad0ff', { glow: true }), h: 0.75 };
    case 'log': return { img: Paint.log(seed), h: 0.55 };
    case 'cactus': return { img: Paint.cactus(seed), h: 2 };
    case 'crystal': return { img: Paint.crystal(seed, ['#ff9aff', '#9ad9ff', '#c89bff', '#7dffcf'][seed % 4]), h: 1.7 };
    case 'stalagmite': return { img: Paint.stalagmite(seed, L.cliff[0]), h: 2 };
    case 'icespike': return { img: Paint.crystal(seed, '#bfe8ff', { glow: false }), h: 1.5 };
    case 'spire': return { img: Paint.stalagmite(seed, '#3b3036'), h: 2.8 };
    case 'lavarock': { const img = Paint.rock(seed, '#3a3036'); const x = img.getContext('2d'); for (let i = 0; i < 5; i++) Paint.line(x, 20 + i * 12, 30 + (i % 2) * 8, 26 + i * 12, 44, i % 2 ? '#ff8a3d' : '#ffd45e', 2); return { img, h: 0.85 }; }
    case 'kelp': return { img: Paint.kelp(seed), h: 2.6 };
    case 'coral': return { img: Paint.coral(seed, ['#ff7a9a', '#ffb23d', '#c89bff'][seed % 3]), h: 1.1 };
    case 'reed': return { img: Paint.reeds(seed), h: 1.5 };
    case 'cloud': return { img: Paint.cloud(seed, { w: 120, h: 50 }), h: 1.1 };
    case 'pillar': return { img: Paint.stalagmite(seed, L.cliff[0], { w: 44, h: 120 }), h: 2.2 };
    case 'lamppost': return { img: Paint.lamppost(seed), h: 3.4 };
    case 'bench': return { img: Paint.bench(seed), h: 0.95 };
    case 'hydrant': return { img: Paint.hydrant(seed), h: 0.75 };
    case 'house': return { img: Paint.house(seed), h: 4.8 };
    case 'deadtree': return { img: Paint.deadTree(seed), h: 4 };
    case 'grave': return { img: Paint.grave(seed), h: 1 };
    case 'pumpkin': return { img: Paint.pumpkin(seed), h: 0.6 };
    case 'cube': case 'orb': case 'pyramid': case 'ring': case 'monolith': {
      const hues = biome === 'synth' ? ['#ff3dd0', '#7de8ff', '#b08aff'] : ['#ff7ac8', '#7ad6ff', '#ffe27a', '#b08aff'];
      return { img: Paint.shape(kind, seed, hues[seed % hues.length]), h: kind === 'monolith' ? 3.2 : kind === 'ring' ? 2 : 1.4 };
    }
    default: { const img = PROPS[kind]?.(rngFrom(seed), L); return img ? { img, h: img.height / 18 } : null; }
  }
}

// ---------- painted parallax strips (tileable) ----------
const LAYER_W = 2048;
function ridge(x, seed, amp, base, ks = [1, 2, 3, 5, 8]) {
  let y = base;
  ks.forEach((k, i) => { y += Math.sin((x / LAYER_W) * Math.PI * 2 * k + seed * (i + 1)) * amp / (i + 1); });
  return y;
}
function hazeOf(L, t) { const a = hexRgb(L.sky[1]); return (col) => { const b = hexRgb(col); return `rgb(${mixRgb(b, a, t).map((v) => v | 0).join(',')})`; }; }
function paintedLayer(kind, L, seed, h, which, biome) {
  const { c, x } = Paint.mk(LAYER_W, h);
  const r = rngFrom(seed * 1000 + which);
  const haze = hazeOf(L, which === 1 ? 0.5 : which === 2 ? 0.28 : 0.15);
  const wrapDraw = (img, px, py, w, hh) => { for (const dx of [0, -LAYER_W, LAYER_W]) x.drawImage(img, Math.round(px + dx), Math.round(py), Math.round(w), Math.round(hh)); };
  const terrain = (base, amp, ks, colTop, colBody, { snow = 0, lit = true } = {}) => {
    const pal = Paint.ramp(colBody, 6, 0.45).map(haze);
    for (let px = 0; px < LAYER_W; px++) {
      const y = ridge(px, seed, amp, base, ks), y2 = ridge(px + 2, seed, amp, base, ks);
      const slope = (y2 - y) * 0.5;
      for (let yy = Math.floor(y); yy < h; yy++) {
        const depth = (yy - y) / (h - y + 1);
        let k = (lit ? 0.55 + slope * 0.6 : 0.5) - depth * 0.35 + (Math.sin(px * 0.7 + yy * 1.3) > 0.97 ? 0.15 : 0);
        k = Math.max(0, Math.min(0.999, k));
        x.fillStyle = yy < y + 2 ? haze(colTop) : (snow && yy - y < snow * (1 - (y - (base - amp)) / (amp * 2)) && slope > -0.6 ? haze('#f4f8ff') : pal[Math.floor(k * pal.length)]);
        x.fillRect(px, yy, 1, 1);
      }
    }
  };
  switch (kind) {
    case 'mountains': terrain(h * 0.38, h * 0.26, [1, 2, 3, 5, 9], '#ffffff', L.mount, { snow: h * 0.16 }); break;
    case 'volcano': { terrain(h * 0.5, h * 0.18, [1, 3, 4], '#ff6a2a', '#3a1418'); const cx = LAYER_W * 0.3; for (let y = 0; y < h * 0.7; y++) { const w = 20 + y * 1.4; x.fillStyle = haze(y < 4 ? '#ff6a2a' : '#2a1418'); x.fillRect(cx - w / 2, h * 0.18 + y, w, 1); } x.save(); x.globalAlpha = 0.3; Paint.dab(x, cx, h * 0.12, 26, '#ff8a3d'); x.restore(); break; }
    case 'mesas': for (let i = 0; i < 6; i++) { const w = 120 + r() * 220, top = h * (0.25 + r() * 0.3), px = r() * LAYER_W; const pal = Paint.ramp('#b5673a', 5, 0.4).map(haze); for (const dx of [0, -LAYER_W]) for (let yy = top; yy < h; yy++) { x.fillStyle = yy < top + 3 ? haze('#e0a070') : pal[Math.min(4, Math.floor(((yy - top) % 18) / 6) + 1)]; x.fillRect(px + dx, yy, w, 1); x.fillStyle = pal[0]; x.fillRect(px + dx + w * 0.75, yy, w * 0.25, 1); } } break;
    case 'cave': { x.fillStyle = Paint.ramp(L.cliff[2] ?? L.cliff[0], 4, 0.3)[0]; x.fillRect(0, 0, LAYER_W, h); for (let px = 0; px < LAYER_W; px += 9) { const d = 14 + hash2(px, seed) * h * 0.45; for (let y = 0; y < d; y++) { const w = Math.max(1, 8 * (1 - y / d)); x.fillStyle = y % 7 === 0 ? shadeHex(L.cliff[1], -0.2) : shadeHex(L.cliff[1], -0.05); x.fillRect(px - w / 2, y, w, 1); } } terrain(h * 0.65, h * 0.08, [3, 7], L.cliff[0], L.cliff[1], { lit: false }); break; }
    case 'reef': terrain(h * 0.5, h * 0.18, [2, 3, 7], '#3dd6ff', '#0b3a62'); break;
    case 'planets': { const g = x.createRadialGradient(LAYER_W * 0.25, h * 0.3, 4, LAYER_W * 0.25, h * 0.35, 60); g.addColorStop(0, '#f0d8ff'); g.addColorStop(1, '#7a4fb0'); x.fillStyle = g; x.beginPath(); x.arc(LAYER_W * 0.25, h * 0.35, 52, 0, Math.PI * 2); x.fill(); x.strokeStyle = 'rgba(255,226,122,.8)'; x.lineWidth = 3; x.beginPath(); x.ellipse(LAYER_W * 0.25, h * 0.35, 84, 14, -0.3, 0, Math.PI * 2); x.stroke(); x.fillStyle = '#7db8ff'; x.beginPath(); x.arc(LAYER_W * 0.7, h * 0.5, 22, 0, Math.PI * 2); x.fill(); break; }
    case 'hills': case 'pines': case 'reeds': {
      const base = kind === 'pines' ? h * 0.45 : h * 0.4;
      terrain(base, h * 0.12, [2, 3, 5], L.ground[2] ?? L.ground[0], L.ground[3] ?? L.ground[0]);
      const leaf = kind === 'pines' ? '#2a5e40' : kind === 'reeds' ? '#5a7a3a' : (LEAF[biome] ?? '#4f9a3f');
      const pal = Paint.ramp(leaf, 6, 0.45).map(haze);
      for (let px = 0; px < LAYER_W; px += kind === 'pines' ? 7 : 11) {
        const y = ridge(px, seed, h * 0.12, base, [2, 3, 5]);
        if (kind === 'pines') { const th = 18 + r() * 26; for (let yy = 0; yy < th; yy++) { const w = (yy / th) * 10 + 1; x.fillStyle = pal[Math.min(5, Math.floor((1 - yy / th) * 3 + (yy % 4 === 0 ? 0 : 2)))]; x.fillRect(px - w / 2, y + 6 - th + yy, w, 1); } }
        else if (kind === 'reeds') { for (let i = 0; i < 4; i++) { x.fillStyle = pal[2 + (i % 3)]; x.fillRect(px + i * 2, y - 6 - r() * 12, 1, 18); } }
        else if (r() < 0.75) Paint.clump(x, r, px, y + 2, 7 + r() * 6, 6 + r() * 4, pal, { size: [1, 2.2] });
      }
      break;
    }
    case 'sea': { const top = h * 0.55; const g = x.createLinearGradient(0, top, 0, h); g.addColorStop(0, shadeHex(L.water, -0.15)); g.addColorStop(1, shadeHex(L.water, 0.18)); x.fillStyle = g; x.fillRect(0, top, LAYER_W, h - top); for (let i = 0; i < 380; i++) { const yy = top + 2 + r() * (h - top - 2); x.fillStyle = `rgba(255,255,255,${(0.3 + r() * 0.5).toFixed(2)})`; x.fillRect(r() * LAYER_W, yy, 3 + r() * 10 * (yy - top) / (h - top) + 2, 1); } for (let i = 0; i < 3; i++) { const px = r() * LAYER_W; for (let yy = 0; yy < 18; yy++) { const w = 120 - yy * 3; x.fillStyle = haze(yy < 2 ? '#8fd08a' : '#5a8a5a'); x.fillRect(px - w / 2 + yy * 4, top - 18 + yy, w * 0.6, 1); } } break; }
    case 'spires': case 'stalagmites': case 'crystals': {
      terrain(h * 0.72, h * 0.05, [4, 9], L.cliff[0], L.cliff[1], { lit: false });
      for (let i = 0; i < 26; i++) {
        const px = r() * LAYER_W, img = kind === 'crystals' ? Paint.crystal(seed + i, ['#7a4fb0', '#4a7ab0', '#a04f9a'][i % 3], { w: 40, h: 70, glow: false }) : Paint.stalagmite(seed + i, kind === 'spires' ? '#3a2a30' : L.cliff[1], { w: 30, h: 80 });
        const s = 0.6 + r() * 0.7; wrapDraw(img, px, h * 0.76 - img.height * s, img.width * s, img.height * s);
      }
      x.globalCompositeOperation = 'source-atop'; x.fillStyle = `rgba(${hexRgb(L.sky[1]).join(',')},.3)`; x.fillRect(0, 0, LAYER_W, h); x.globalCompositeOperation = 'source-over';
      break;
    }
    case 'ice': terrain(h * 0.5, h * 0.14, [2, 5, 11], '#ffffff', '#bfd8f2'); break;
    case 'dunes': terrain(h * 0.55, h * 0.1, [2, 3], '#fff0c8', L.ground[0]); for (let i = 0; i < 260; i++) { const px = r() * LAYER_W, y = ridge(px, seed, h * 0.1, h * 0.55, [2, 3]) + 4 + r() * 30; x.fillStyle = haze(shadeHex(L.ground[0], -0.12)); x.fillRect(px, y, 8 + r() * 14, 1); } break;
    case 'clouds': for (let i = 0; i < 18; i++) { const img = Paint.cloud(seed + i, { w: 160 + r() * 120, h: 60 + r() * 30, tint: i % 3 ? '#ffffff' : '#ffe6f2' }); wrapDraw(img, r() * LAYER_W, h * (0.25 + r() * 0.5), img.width, img.height); } break;
    case 'kelp': for (let i = 0; i < 40; i++) { const img = Paint.kelp(seed + i, { w: 40, h: 120 }); const s = 0.6 + r(); wrapDraw(img, r() * LAYER_W, h - img.height * s, img.width * s, img.height * s); } x.globalCompositeOperation = 'source-atop'; x.fillStyle = 'rgba(31,127,176,.4)'; x.fillRect(0, 0, LAYER_W, h); x.globalCompositeOperation = 'source-over'; break;
    case 'peaks': terrain(h * 0.32, h * 0.3, [1, 2, 3, 6, 11], '#ffffff', '#7a8cb0', { snow: h * 0.3 }); break;
    case 'canopy': {
      // an ocean of treetops far below the mountaintop
      terrain(h * 0.62, h * 0.04, [3, 7], '#3a7d52', '#24603a');
      const pal = Paint.ramp('#2f6b48', 6, 0.45).map(haze);
      for (let px = 0; px < LAYER_W; px += 5) { const y = ridge(px, seed, h * 0.04, h * 0.6, [3, 7]); Paint.clump(x, r, px, y + 2, 5 + r() * 5, 4 + r() * 3, pal, { size: [1, 2] }); }
      break;
    }
    case 'industry': {
      // far-off factories: low sheds, gas holders and smoking chimneys
      for (let px = 0; px < LAYER_W;) {
        const bw = 60 + r() * 120, bh = h * (0.2 + r() * 0.25), top = h - bh;
        x.fillStyle = haze(r() < 0.5 ? '#8a7a70' : '#7a7a86'); x.fillRect(px, top, bw, bh);
        for (let k = 0; k < bw; k += 16) { x.fillStyle = haze('#6a5a54'); x.beginPath(); x.moveTo(px + k, top); x.lineTo(px + k + 16, top - 8); x.lineTo(px + k + 16, top); x.fill(); }
        if (r() < 0.6) { const sx = px + r() * bw, sh = h * (0.4 + r() * 0.4); x.fillStyle = haze('#9a5a50'); x.fillRect(sx, h - sh, 5, sh); x.fillStyle = haze('#ffffff'); for (let k = 0; k < 4; k++) x.fillRect(sx - 3 + k * 4, h - sh - 8 - k * 7, 8, 5); }
        if (r() < 0.25) { const cx = px + bw * 0.5, rr = 14 + r() * 10; x.fillStyle = haze('#8a96a8'); x.fillRect(cx - rr, h - rr * 2.2, rr * 2, rr * 2.2); }
        px += bw + r() * 30;
      }
      break;
    }
    case 'city': {
      // a skyline in the haze, windows lit
      for (let px = 0; px < LAYER_W;) {
        const bw = 26 + r() * 60, bh = h * (0.3 + r() * 0.65), top = h - bh;
        const body = haze(r() < 0.5 ? '#6c7a9c' : '#7a86a8');
        x.fillStyle = body; x.fillRect(px, top, bw, bh);
        x.fillStyle = haze('#ffe9a8');
        for (let yy = top + 6; yy < h - 4; yy += 9) for (let xx = px + 4; xx < px + bw - 6; xx += 8) if (r() < 0.35) x.fillRect(xx, yy, 3, 4);
        if (r() < 0.25) { x.fillStyle = body; x.fillRect(px + bw / 2 - 1, top - 18, 2, 18); }
        px += bw + r() * 6;
      }
      break;
    }
    case 'houses': {
      terrain(h * 0.78, h * 0.03, [3, 5], L.ground[2] ?? L.ground[0], L.ground[3] ?? L.ground[0]);
      for (let i = 0; i < 26; i++) {
        const img = Paint.house(seed + i, { w: 120, h: 100 });
        const s = 0.5 + r() * 0.4, px = (i / 26) * LAYER_W + r() * 30;
        wrapDraw(img, px, h * 0.8 - img.height * s, img.width * s, img.height * s);
      }
      x.globalCompositeOperation = 'source-atop'; x.fillStyle = `rgba(${hexRgb(L.sky[1]).join(',')},.25)`; x.fillRect(0, 0, LAYER_W, h); x.globalCompositeOperation = 'source-over';
      break;
    }
    case 'deadwood': {
      terrain(h * 0.7, h * 0.05, [3, 6], '#2a2040', '#1d1530', { lit: false });
      for (let i = 0; i < 30; i++) { const img = Paint.deadTree(seed + i, { w: 80, h: 120 }); const s = 0.5 + r() * 0.6; wrapDraw(img, r() * LAYER_W, h * 0.74 - img.height * s, img.width * s, img.height * s); }
      x.globalCompositeOperation = 'source-atop'; x.fillStyle = 'rgba(40,24,70,.45)'; x.fillRect(0, 0, LAYER_W, h); x.globalCompositeOperation = 'source-over';
      break;
    }
    case 'shapes': {
      const hues = ['#ff7ac8', '#7ad6ff', '#ffe27a', '#b08aff'];
      for (let i = 0; i < 22; i++) {
        const kinds = ['cube', 'orb', 'pyramid', 'ring'];
        const img = Paint.shape(kinds[i % 4], seed + i, hues[i % 4], { w: 120, h: 130 });
        const s = 0.5 + r() * 0.9;
        wrapDraw(img, r() * LAYER_W, h * (0.3 + r() * 0.5) - img.height * s * 0.5, img.width * s, img.height * s);
      }
      x.globalCompositeOperation = 'source-atop'; x.fillStyle = `rgba(${hexRgb(L.sky[1]).join(',')},.35)`; x.fillRect(0, 0, LAYER_W, h); x.globalCompositeOperation = 'source-over';
      break;
    }
    case 'synthsun': {
      const cx = LAYER_W * 0.5, cy = h * 0.55, rr = h * 0.42;
      for (let yy = -rr; yy <= rr; yy++) { if (yy > 0 && Math.floor(yy / 7) % 2) continue; const half = Math.sqrt(rr * rr - yy * yy); const t = (yy + rr) / (2 * rr); x.fillStyle = `rgb(${mixRgb(hexRgb('#ffe27a'), hexRgb('#ff3d9a'), t).map((v) => v | 0).join(',')})`; x.fillRect(cx - half, cy + yy, half * 2, 1); }
      break;
    }
    case 'gridhills': {
      for (let px = 0; px < LAYER_W; px++) { const y = ridge(px, seed, h * 0.2, h * 0.62, [2, 3, 7]); x.fillStyle = '#12062a'; x.fillRect(px, y, 1, h - y); x.fillStyle = '#ff3dd0'; x.fillRect(px, y, 1, 2); }
      x.globalAlpha = 0.5; x.fillStyle = '#7de8ff'; for (let px = 0; px < LAYER_W; px += 24) for (let yy = Math.round(ridge(px, seed, h * 0.2, h * 0.62, [2, 3, 7])); yy < h; yy += 6) x.fillRect(px, yy, 1, 2); x.globalAlpha = 1;
      break;
    }
    case 'none': break;
    default: break;
  }
  return c;
}
function paintedNear(L, style, seed, h, biome) {
  const { c, x } = Paint.mk(LAYER_W, h);
  const r = rngFrom(seed * 77 + 3);
  for (let i = 0; i < 22; i++) {
    const kind = style.near[i % style.near.length];
    const p = paintedProp(kind, L, seed * 31 + i, biome);
    if (!p) continue;
    const s = (h * (0.75 + r() * 0.35)) / p.img.height * Math.min(1, p.h / 3.4 + 0.3);
    const w = p.img.width * s, hh = p.img.height * s;
    const px = (i / 22) * LAYER_W + r() * 40;
    for (const dx of [0, -LAYER_W, LAYER_W]) x.drawImage(p.img, Math.round(px + dx), Math.round(h - hh), Math.round(w), Math.round(hh));
  }
  x.globalCompositeOperation = 'source-atop';
  x.fillStyle = `rgba(${hexRgb(L.sky[1]).join(',')},0.22)`;
  x.fillRect(0, 0, LAYER_W, h);
  return c;
}


// ---------- floor texture for a scene ----------
const FLOOR_STYLE = { colosseum: 'sand', ruins: 'rock', stadium: 'grass', shrine: 'rock', meadow: 'grass', forest: 'grass', marsh: 'grass', shoreline: 'sand', desert: 'sand', seafloor: 'sand', tundra: 'snow', volcano: 'rock', cavern: 'rock', crystal: 'rock', starfield: 'rock', skyline: 'alpine', outskirts: 'grass', spooky: 'grass', prism: 'checker', synth: 'grid' };
function buildFloor(S, L, seed, biome, scene, sky = false, features = []) {
  const { X0, X1, Z0, Z1, TEX } = S;
  const TXW = (X1 - X0) * TEX, TXH = (Z1 - Z0) * TEX;
  const col = new Uint32Array(TXW * TXH), mat = new Uint8Array(TXW * TXH);
  const pal = L.ground.map(hexRgb);
  const r = rngFrom(seed * 131 + 7);
  const style = sky ? 'cloud' : scene === 'farm' ? 'farm' : scene === 'shop' ? 'plaza' : FLOOR_STYLE[biome] ?? 'grass';
  const soil = ['#5e3c22', '#6b4423', '#7a5232', '#4f321c'].map(hexRgb), stone = ['#b9b2c8', '#a8a0ba', '#c8c2d6', '#9a92ae'].map(hexRgb);
  const meadowPal = Paint.ramp('#5cae48', 6, 0.35).map(hexRgb), farmGrass = Paint.ramp('#62b04c', 6, 0.35).map(hexRgb);
  const cliff = L.cliff.map(hexRgb);
  const inside = (wx, wz) => wx > S.x0 - 0.7 && wx < S.x1 + 0.7 && wz > S.z0 - 1 && wz < S.back;
  // visit only the texels inside a world-space box
  const box = (x0, x1, z0, z1, fn) => {
    const tx0 = Math.max(0, Math.floor((x0 - X0) * TEX)), tx1 = Math.min(TXW - 1, Math.ceil((x1 - X0) * TEX));
    const ty0 = Math.max(0, Math.floor((z0 - Z0) * TEX)), ty1 = Math.min(TXH - 1, Math.ceil((z1 - Z0) * TEX));
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) fn(ty * TXW + tx, X0 + tx / TEX, Z0 + ty / TEX, tx, ty);
  };
  for (let ty = 0; ty < TXH; ty++) for (let tx = 0; tx < TXW; tx++) {
    const wx = X0 + tx / TEX, wz = Z0 + ty / TEX;
    const n = vnoise(tx / 28 + seed, ty / 28) * 0.6 + vnoise(tx / 9, ty / 9 + seed) * 0.3 + hash2(tx, ty) * 0.1;
    let c = pal[Math.min(pal.length - 1, Math.floor(n * pal.length))];
    switch (style) {
      case 'farm': c = farmGrass[Math.min(5, Math.floor(n * 6))]; break;
      case 'cloud': { const k = vnoise(tx / 40 + seed, ty / 22) * 0.7 + vnoise(tx / 12, ty / 8 + seed) * 0.3; c = k > 0.55 ? mixRgb([236, 242, 255], [255, 255, 255], (k - 0.55) * 2) : mixRgb([176, 196, 236], [226, 234, 252], k / 0.55); break; }
      case 'plaza': {
        if (inside(wx, wz)) {
          const row = Math.floor(wz * 2.2), off = (row % 2) * 0.5, bx = Math.floor(wx * 2.2 + off);
          const fx = (wx * 2.2 + off) % 1, fz = (wz * 2.2) % 1;
          c = stone[(bx * 7 + row * 3) & 3];
          c = mixRgb(c, [255, 255, 255], (0.5 - fz) * 0.12 + (0.5 - fx) * 0.08);
          if (fx < 0.06 || fz < 0.07) c = mixRgb(c, [70, 60, 90], 0.45);
        } else c = farmGrass[Math.min(5, Math.floor(n * 6))];
        break;
      }
      case 'sand': c = mixRgb(c, [255, 250, 230], Math.sin(wz * 7 + vnoise(tx / 30, ty / 30) * 6) > 0.86 ? 0.25 : 0); break;
      case 'snow': c = mixRgb(c, [255, 255, 255], hash2(tx, ty) < 0.02 ? 0.8 : 0); break;
      case 'rock': { const cr = vnoise(tx / 6, ty / 6); if (cr > 0.48 && cr < 0.5) c = mixRgb(c, [20, 16, 30], 0.4); break; }
      case 'alpine': { const rk = vnoise(tx / 40 + 3, ty / 40 + seed); c = rk > 0.64 ? mixRgb(cliff[Math.floor(n * 3) % 3], [255, 255, 255], hash2(tx, ty) * 0.12) : mixRgb(meadowPal[Math.min(5, Math.floor(n * 6))], c, 0.6); break; }
      case 'checker': { const t = (Math.floor(wx) + Math.floor(wz)) & 1; c = inside(wx, wz) ? (t ? pal[0] : pal[2]) : mixRgb(pal[(Math.floor(wx / 2) + Math.floor(wz / 2)) & 3], [255, 255, 255], 0.2); break; }
      case 'grid': {
        const fx = ((wx % 1.5) + 1.5) % 1.5, fz = ((wz % 1.5) + 1.5) % 1.5;
        if (fx < 0.06 || fz < 0.06) mat[ty * TXW + tx] = 3;
        break;
      }
      default: c = mixRgb(meadowPal[Math.min(5, Math.floor(n * 6))], c, 0.55);
    }
    // the land outside the fence gets a little wilder (patchier)
    if (!inside(wx, wz) && style !== 'checker' && style !== 'grid') c = mixRgb(c, [0, 0, 0], vnoise(tx / 60, ty / 60 + 7) * 0.12);
    col[ty * TXW + tx] = packA(c);
  }
  // grass blades: short strokes, lit tips
  if (['grass', 'alpine', 'farm', 'plaza'].includes(style)) {
    const bladePal = style === 'farm' || style === 'plaza' ? farmGrass : Paint.ramp(L.ground[1] ?? L.ground[0], 6, 0.45).map(hexRgb);
    const n = Math.round(TXW * TXH * 0.07);
    for (let i = 0; i < n; i++) {
      const tx = Math.floor(r() * TXW), ty = Math.floor(r() * TXH);
      if (style === 'plaza' && inside(X0 + tx / TEX, Z0 + ty / TEX)) continue;
      const len = 2 + Math.floor(r() * 3);
      for (let k = 0; k < len; k++) { const yy = ty - k; if (yy < 0) continue; col[yy * TXW + tx] = packA(bladePal[Math.min(bladePal.length - 1, 1 + k + (r() < 0.3 ? 1 : 0))]); }
    }
  }
  // the farm: tilled beds and stepping stones from the gate
  if (scene === 'farm') {
    for (const [px, pz] of S.plots ?? PLOTS) box(px - 1.7, px + 1.7, pz - 1, pz + 1, (i, wx, wz, tx, ty) => {
      if (Math.abs(wx - px) < 1.6 && wz > pz - 0.95 && wz < pz + 0.9) {
        const furrow = Math.sin((wz - pz) * 9) > 0.2;
        let c = soil[(furrow ? 2 : 0) + (hash2(tx, ty) < 0.2 ? 1 : 0)];
        if (hash2(tx + 3, ty) < 0.02) c = [150, 130, 110];
        col[i] = packA(c);
      }
    });
    for (let z = 0.4; z < 9.5; z += 0.9) { const sx = -7.4 + Math.sin(z) * 0.3, sz = z; box(sx - 0.4, sx + 0.4, sz - 0.3, sz + 0.3, (i, wx, wz, tx, ty) => { const dx = wx - sx, dz = wz - sz, d = (dx * dx) / 0.12 + (dz * dz) / 0.08; if (d < 1) col[i] = packA(mixRgb(stone[(tx + ty) & 3], [255, 255, 255], (1 - d) * 0.15 - (dz > 0.15 ? 0.1 : 0))); }); }
  }
  // a battle field: the arena's own ground, and a worn spot under each creature
  if (scene === 'battle') {
    const kind = ARENA[biome] ?? 'natural';
    const base = (i) => [col[i] & 255, (col[i] >> 8) & 255, (col[i] >> 16) & 255];
    if (kind === 'colosseum') {
      box(X0, X1, Z0, Z1, (i, wx, wz, tx, ty) => {
        const d = Math.hypot(wx / 1.2, wz - FIELD_Z) * (6.2 / 14.2);
        const sand = mixRgb([226, 196, 142], [204, 172, 120], vnoise(tx / 14, ty / 14) * 0.8 + hash2(tx, ty) * 0.2);
        if (d < 6.2) col[i] = packA(Math.abs(d - 5.9) < 0.07 || Math.abs(d - 1.2) < 0.05 ? mixRgb(sand, [150, 110, 70], 0.55) : sand);
        else { const row = Math.floor(wz * 1.6), bx = Math.floor(wx * 1.6 + (row % 2) * 0.5); col[i] = packA(mixRgb([184, 168, 140], [150, 136, 112], ((bx * 7 + row * 3) & 3) / 6 + hash2(tx, ty) * 0.15)); }
      });
    } else if (kind === 'stadium') {
      box(X0, X1, Z0, Z1, (i, wx, wz, tx, ty) => {
        const F = FIELD_Z, inCourt = Math.abs(wx) < 5.6 && wz > F - 5.6 && wz < F + 5.6, inField = Math.abs(wx) < 13.8 && wz > F - 12.8 && wz < F + 11.8;
        if (inCourt) {
          const stripe = Math.floor((wz - F + 5.6) / 0.8) % 2;
          let c = stripe ? [86, 168, 90] : [74, 152, 80];
          const line = Math.abs(Math.abs(wx) - 5.6) < 0.07 || Math.abs(Math.abs(wz - F) - 5.6) < 0.07 || Math.abs(wz - F) < 0.05;
          const rr = Math.hypot(wx, (wz - F) * 1.1);
          if (line || Math.abs(rr - 1.1) < 0.06) c = [240, 244, 240];
          if (rr < 0.5) c = wz > F ? [220, 60, 60] : [244, 244, 244];
          if (Math.abs(rr - 0.5) < 0.05 || (rr < 0.5 && Math.abs(wz - F) < 0.04)) c = [40, 40, 50];
          if (Math.abs(rr - 1.5) < 0.07) c = [240, 244, 240];
          col[i] = packA(c);
        } else if (inField) { const stripe = Math.floor((wz - F + 12.8) / 0.8) % 2; col[i] = packA(mixRgb(stripe ? [70, 150, 76] : [62, 136, 70], [0, 0, 0], hash2(tx, ty) * 0.06)); }
        else col[i] = packA(mixRgb([86, 98, 140], [70, 80, 120], hash2(tx, ty) * 0.4 + ((Math.floor(wx * 2) + Math.floor(wz * 2)) & 1) * 0.15));
      });
    } else if (kind === 'ruins') {
      box(X0, X1, Z0, Z1, (i, wx, wz, tx, ty) => {
        const row = Math.floor(wz * 1.1), bx = Math.floor(wx * 1.1 + (row % 2) * 0.5);
        const fx = (wx * 1.1 + (row % 2) * 0.5) % 1, fz = (wz * 1.1) % 1;
        let c = mixRgb([160, 158, 144], [128, 126, 116], ((bx * 13 + row * 7) & 7) / 10 + hash2(tx, ty) * 0.12);
        if (fx < 0.05 || fz < 0.05 || (vnoise(tx / 5, ty / 5) > 0.62 && vnoise(tx / 5, ty / 5) < 0.64)) c = mixRgb(c, [50, 50, 46], 0.5);
        const moss = vnoise(tx / 22 + seed, ty / 22);
        if (moss > 0.58) c = mixRgb(c, [92, 140, 62], Math.min(0.85, (moss - 0.58) * 4));
        col[i] = packA(c);
      });
    } else if (kind === 'shrine') {
      box(X0, X1, Z0, Z1, (i, wx, wz, tx, ty) => {
        let c = mixRgb([214, 208, 198], [186, 180, 170], hash2(tx, ty) * 0.7 + vnoise(tx / 8, ty / 8) * 0.3);
        // raked lines in the gravel, and a stone path up the middle to the back
        if (Math.sin(wz * 9 + Math.sin(wx * 0.6) * 1.5) > 0.8) c = mixRgb(c, [150, 144, 134], 0.4);
        if (Math.abs(wx) < 0.9 && wz > FIELD_Z + 5) { const fz = (wz * 1.4) % 1; c = fz < 0.08 ? [120, 116, 108] : mixRgb([176, 172, 164], [150, 146, 138], hash2(tx, ty) * 0.4); }
        col[i] = packA(c);
      });
    }
    if (biome === 'outskirts') {
      // the city park: a round court of paving in the middle, a gravel path round it, lawns, and the city's
      // pavements beyond the hedges
      box(X0, X1, Z0, Z1, (i, wx, wz, tx, ty) => {
        const d = Math.hypot(wx / 1.08, (wz - FIELD_Z) / 0.9) / 1.4;
        if (d > 15.5) col[i] = packA(mixRgb([176, 176, 186], [140, 140, 150], (((tx >> 4) + (ty >> 4)) & 1) * 0.3 + hash2(tx, ty) * 0.1));
        else if (Math.abs(d - 8.6) < 0.9) col[i] = packA(mixRgb([200, 184, 150], [170, 154, 120], hash2(tx, ty) * 0.6));
        else if (d < 7.4) { const ring = Math.floor(d * 1.6), seg = Math.floor((Math.atan2(wz - FIELD_Z, wx) + Math.PI) * (4 + ring * 2)); col[i] = packA(mixRgb([196, 190, 178], [168, 162, 150], ((ring + seg) & 1) * 0.5 + hash2(tx, ty) * 0.15)); if ((d * 1.6) % 1 < 0.06) col[i] = packA([140, 136, 126]); }
      });
    }
    if (kind === 'prism' || kind === 'neon') {
      // the prism plaza: pastel glass tiles with a bright ring round the field; the neon grid: dark floor with
      // glowing lines and a lit border round the field
      box(X0, X1, Z0, Z1, (i, wx, wz, tx, ty) => {
        const d = Math.hypot(wx / 1.1, (wz - FIELD_Z) / 0.9), gx = Math.abs(((wx % 2) + 2) % 2 - 1), gz = Math.abs((((wz - FIELD_Z) % 2) + 2) % 2 - 1);
        if (kind === 'prism') {
          const tile = ((Math.floor(wx / 2) + Math.floor((wz - FIELD_Z) / 2)) & 1);
          let c = tile ? [250, 238, 255] : [230, 244, 255];
          if (gx > 0.96 || gz > 0.96) c = [255, 255, 255];
          if (Math.abs(d - 10.5) < 0.18) c = [255, 140, 220]; else if (Math.abs(d - 10.9) < 0.1) c = [140, 220, 255];
          col[i] = packA(mixRgb(c, [200, 180, 255], hash2(tx, ty) * 0.05));
        } else {
          let c = mixRgb([20, 8, 44], [14, 6, 32], hash2(tx, ty) * 0.5);
          if (gx > 0.94 || gz > 0.94) c = d < 10.5 ? [255, 61, 208] : [150, 40, 150];
          if (Math.abs(d - 10.5) < 0.16) c = [61, 232, 255];
          col[i] = packA(c);
        }
      });
    }
    // the two spots: a round worn patch with a rim (natural places), a painted circle on built floors
    for (const [sx, sz] of [BATTLE_SPOTS.near, BATTLE_SPOTS.far]) {
      box(sx - 1.7, sx + 1.7, sz - 1.2, sz + 1.2, (i, wx, wz, tx, ty) => {
        const k = Math.hypot((wx - sx) / 1.45, (wz - sz) / 0.95);
        if (k > 1.06) return;
        const c0 = base(i);
        if (kind === 'stadium') { if (Math.abs(k - 0.95) < 0.05) col[i] = packA([240, 244, 240]); return; }
        if (kind === 'prism' || kind === 'neon') { if (Math.abs(k - 0.95) < 0.06) col[i] = packA(kind === 'prism' ? [255, 160, 230] : [61, 232, 255]); return; }
        if (kind === 'colosseum' || kind === 'shrine' || kind === 'ruins') { if (Math.abs(k - 0.96) < 0.05) col[i] = packA(mixRgb(c0, [60, 46, 36], 0.45)); else if (k < 0.92) col[i] = packA(mixRgb(c0, [255, 250, 235], 0.12)); return; }
        const dirt = mixRgb(mixRgb(c0, [120, 92, 60], 0.45), [255, 240, 210], 0.1 + hash2(tx, ty) * 0.08);
        col[i] = packA(k > 0.9 ? mixRgb(c0, [255, 255, 255], 0.35) : k > 0.84 ? mixRgb(dirt, [40, 30, 20], 0.25) : dirt);
      });
    }
  }
  // the city park: gravel paths winding through the grass, a road past the railings, and the city's
  // concrete beyond it (where the buildings stand)
  if (biome === 'outskirts' && scene !== 'farm' && scene !== 'shop' && scene !== 'battle') {
    const zr = S.back + 2.4;
    box(X0, X1, zr - 0.8, Z1, (i, wx, wz, tx, ty) => {
      if (wz < zr) col[i] = packA(mixRgb([196, 196, 204], [255, 255, 255], ((tx >> 3) + (ty >> 3)) % 2 ? 0.05 : 0));
      else if (wz < zr + 2.2) col[i] = packA(Math.abs(wz - (zr + 1.1)) < 0.05 && Math.floor(wx) % 2 === 0 ? [240, 230, 160] : mixRgb([70, 72, 82], [0, 0, 0], hash2(tx, ty) * 0.15));
      else if (wz < zr + 3) col[i] = packA(mixRgb([186, 186, 196], [255, 255, 255], ((tx >> 2) % 6 === 0 ? 0.1 : 0)));
      else col[i] = packA(mixRgb([150, 150, 160], [90, 90, 100], (((tx >> 4) + (ty >> 4)) & 1) * 0.25 + hash2(tx, ty) * 0.15));
    });
    if (scene === 'yard' || scene === 'room') {
      const path = (wz) => Math.sin(wz * 0.55 + seed) * S.x1 * 0.4;
      // the winding path runs all the way to the front edge of the ground (seen when zoomed out)
      box(X0, X1, Z0, S.back, (i, wx, wz, tx, ty) => {
        const d = Math.abs(wx - path(wz)), d2 = Math.abs(wz - S.z1 * 0.55 - Math.sin(wx * 0.4) * 0.6);
        if (d < 0.75 || (d2 < 0.55 && Math.abs(wx) < S.x1 * 0.9)) col[i] = packA(mixRgb([214, 196, 160], [180, 160, 128], hash2(tx, ty) * 0.6 + (Math.min(d, d2 * 1.4) > 0.6 ? 0.3 : 0)));
      });
    }
  }
  // water, lava and ice inside the area (and an ocean beyond the shoreline)
  const circle = (cx, cz, rad, m) => box(cx - rad * 1.3, cx + rad * 1.3, cz - rad, cz + rad, (i, wx, wz, tx, ty) => {
    const dx = wx - cx, dz = wz - cz;
    const wob = 1 + (vnoise(tx / 10 + seed, ty / 10) - 0.5) * 0.4;
    if (dx * dx + (dz * 1.4) ** 2 < (rad * wob) ** 2) mat[i] = m;
  });
  const decal = sky || scene === 'farm' || scene === 'shop' || (scene === 'battle' && ARENA[biome]) ? null : (L.decals ?? [])[0];
  const small = scene === 'room' ? 0.6 : 1;
  const px = scene === 'battle' ? S.x1 * 0.95 : S.x1 * 0.62, pz = scene === 'battle' ? S.z1 * 1.0 : S.z1 * 0.78;
  if (decal === 'lava') circle(px, pz, 1.8 * small, 2);
  else if (decal === 'ice') circle(-px, pz, 1.9 * small, 4);
  else if (decal === 'sea') box(X0, X1, S.back - 1.6 * small, Z1, (i, wx, wz) => { if (wz > S.back - 1.5 * small + Math.sin(wx * 1.1) * 0.35) mat[i] = 1; });
  else if (L.water && decal) circle(px, pz, 1.7 * small, 1);
  if (L.glowlines) for (let i = 0; i < 26; i++) { let tx = Math.floor(r() * TXW), ty = Math.floor(r() * TXH); for (let k = 0; k < 220; k++) { if (tx >= 0 && ty >= 0 && tx < TXW && ty < TXH && !mat[ty * TXW + tx]) mat[ty * TXW + tx] = 3; if (r() < 0.5) tx += r() < 0.5 ? 1 : -1; else ty += r() < 0.5 ? 1 : -1; } }
  // things built in the yard mark the ground: a pond, a sand pit, a patch of snow…
  for (const f of features) {
    const d = f.def;
    if (!d?.floor) continue;
    const rad = d.r * (d.floor === 'water' ? 1 + 0.3 * (f.life ?? 0) : 1);
    box(f.x - rad - 0.3, f.x + rad + 0.3, f.z - rad, f.z + rad, (i, wx, wz, tx, ty) => {
      const dx = wx - f.x, dz = (wz - f.z) * 1.35;
      const wob = 1 + (vnoise(tx / 9 + seed, ty / 9) - 0.5) * 0.3;
      const k = Math.sqrt(dx * dx + dz * dz) / (rad * wob);
      if (k > 1) return;
      const c0 = [col[i] & 255, (col[i] >> 8) & 255, (col[i] >> 16) & 255];
      const edge = Math.min(1, (1 - k) * 4);
      switch (d.floor) {
        case 'water': mat[i] = 1; break;
        case 'spring': mat[i] = 5; break;
        case 'moss': col[i] = packA(mixRgb(c0, [52, 96, 84], 0.55 * edge)); break;
        case 'warm': col[i] = packA(mixRgb(c0, [255, 222, 140], 0.42 * edge)); break;
        case 'soil': col[i] = packA(mixRgb(c0, hash2(tx, ty) < 0.15 ? [92, 60, 34] : [118, 78, 44], 0.9 * edge)); break;
        case 'gravel': col[i] = packA(mixRgb(c0, hash2(tx, ty) < 0.5 ? [170, 166, 178] : [140, 136, 150], 0.85 * edge)); break;
        case 'sand': col[i] = packA(mixRgb(c0, hash2(tx, ty) < 0.1 ? [250, 236, 196] : [232, 206, 150], 0.9 * edge)); break;
        case 'snow': col[i] = packA(mixRgb(c0, hash2(tx, ty) < 0.04 ? [210, 230, 255] : [246, 250, 255], 0.92 * edge)); break;
        case 'balls': { const h = hash2(tx >> 1, ty >> 1); col[i] = packA(k > 0.85 ? [70, 120, 220] : h < 0.25 ? [229, 72, 77] : h < 0.5 ? [255, 210, 63] : h < 0.75 ? [74, 168, 255] : [255, 143, 182]); break; }
        default: break;
      }
    });
  }
  const dots = (L.dots ?? []).map(hexRgb);
  if (dots.length && style !== 'grid' && style !== 'plaza' && style !== 'cloud') {
    for (let i = 0; i < TXW * 3; i++) {
      const tx = Math.floor(r() * TXW), ty = Math.floor(r() * TXH);
      if (mat[ty * TXW + tx]) continue;
      const d = dots[Math.floor(r() * dots.length)];
      const cross = style === 'grass' || style === 'alpine' ? [[0, 0], [1, 0], [0, 1], [-1, 0], [0, -1]] : [[0, 0], [1, 0]];
      for (const [ox, oy] of cross) { const i2 = (ty + oy) * TXW + tx + ox; if (i2 >= 0 && i2 < col.length) col[i2] = packA(ox || oy || (style !== 'grass' && style !== 'alpine') ? d : [255, 220, 90]); }
    }
  }
  // foam where water meets land
  for (let ty = 1; ty < TXH - 1; ty++) for (let tx = 1; tx < TXW - 1; tx++) {
    const i = ty * TXW + tx;
    const wet = (m) => m === 1 || m === 5;
    if (mat[i] || !(wet(mat[i - 1]) || wet(mat[i + 1]) || wet(mat[i - TXW]) || wet(mat[i + TXW]))) continue;
    col[i] = packA(mixRgb(pal[0], [255, 255, 255], 0.5));
  }
  return { col, mat, TXW, TXH };
}

// ---------- farm pieces, cached per stage and colour ----------
const plantCache = new Map();
function plantImg(stage, color, seed) {
  const key = `${stage}:${color}:${seed}`;
  if (!plantCache.has(key)) plantCache.set(key, Paint.seedling(stage, color, seed));
  return plantCache.get(key);
}

// ---------- moods and types: bubbles over heads, and the little bursts that go with them ----------
const TYPE_FX = [
  [/fire|ember|flame|blaze/i, 'ember'], [/water|tide|aqua/i, 'drop'], [/grass|sprout|leaf|plant/i, 'leaf'],
  [/electric|volt|spark|thunder/i, 'spark'], [/ice|frost/i, 'flake'], [/fairy|charm/i, 'glitter'],
  [/ghost|spirit/i, 'wisp'], [/dark|shade/i, 'wisp'], [/psychic|mind/i, 'ring'], [/fighting|brawl/i, 'star'],
  [/steel|metal/i, 'glint'], [/poison|toxic/i, 'bubble'], [/rock|stone/i, 'pebble'], [/ground|earth/i, 'pebble'],
  [/flying|gale|wind|air/i, 'gust'], [/bug|insect/i, 'mote'], [/dragon|wyrm/i, 'scale'],
];
const FX_COL = {
  ember: ['#ff6a2a', '#ffd45e'], drop: ['#4aa8ff', '#bfe6ff'], leaf: ['#4fb63f', '#a8e070'], spark: ['#ffe23d', '#ffffff'],
  flake: ['#ffffff', '#bfe8ff'], pebble: ['#9a8468', '#cbb89a'], gust: ['#ffffff', '#d8f0ff'], ring: ['#ff7ad6', '#ffc0ec'],
  wisp: ['#9a6ae0', '#5a3a8a'], star: ['#ffb23d', '#ffffff'], glint: ['#ffffff', '#a8b4c8'], glitter: ['#ffa8dc', '#ffffff'],
  bubble: ['#b45ad0', '#e6a8ff'], mote: ['#a6d03d', '#efff8a'], scale: ['#8a6aff', '#ff9a4d'], plain: ['#ffffff', '#fff3a0'],
};
/** The kind of little particles a creature of these types gives off (type ids or names). */
export function typeFxOf(types = []) {
  const s = types.join(' ');
  for (const [re, kind] of TYPE_FX) if (re.test(s)) return kind;
  return 'plain';
}

export class Yard {
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.bank = opts.bank;
    this.res = opts.res ?? null;
    this.resolve = opts.resolveTexture ?? (() => null);
    const noop = () => {};
    this.onSelect = opts.onSelect ?? noop;
    this.onContext = opts.onContext ?? null;
    this.onPet = opts.onPet ?? noop;
    this.onDrop = opts.onDrop ?? noop;
    this.onPlot = opts.onPlot ?? noop;
    this.onShop = opts.onShop ?? noop;
    this.onEat = opts.onEat ?? null;
    this.onPlay = opts.onPlay ?? null;
    this.onPlayTogether = opts.onPlayTogether ?? null;
    this.onPlace = opts.onPlace ?? null;          // build mode: clicked the ground at { x, z }
    this.onFeature = opts.onFeature ?? null;      // build mode: clicked something built
    this.onFeatureOpen = opts.onFeatureOpen ?? null; // double-clicked a machine (not in build mode)
    this.onPlaceBlocked = opts.onPlaceBlocked ?? null; // build mode: clicked where the thing won't fit
    this.onFeatureVisit = opts.onFeatureVisit ?? null;
    this.yardSize = opts.yardSize ?? 2;
    this.features = [];
    this.buildMode = false;
    this.tod = opts.tod ?? 'day';
    this.onBounce = opts.onBounce ?? null;
    this.overlay = opts.overlay ?? null;
    this.plots = [];
    this.scene = SCENES[opts.scene] ? opts.scene : 'yard';
    this.S = this.sceneDef(this.scene);
    this.camX = 0; this.camTarget = 0;
    this.yaw = 0; this.yawTarget = 0;
    this.dist = 1; this.distTarget = 1;
    // activities can look down more (pitch, radians) and follow along the ground (camZ: the pivot moves forward)
    this.pitch = PITCH; this.pitchTarget = PITCH;
    this.camZ = 0; this.camZTarget = 0;
    this.actors = new Map();
    this.toys = [];
    this.sparks = [];
    this.reacts = [];
    this.selected = null; this.hover = null;
    this.time = 0; this.warp = 0;
    this.hits = [];
    this.inputLocked = false; // the care room takes the pointer while a tool is in hand
    this.accent = opts.accent ?? '#5b45c4';
    this.sizeScale = opts.sizeScale ?? 1; // the player's "creature size" setting
    this.floorCanvas = document.createElement('canvas');
    if (typeof window !== 'undefined') window.__yard = this; // handy in the dev tools
    this.updateCamera();
    this.resize();
    this.setScene(this.scene, opts.biome ?? 'meadow', opts.seed ?? 1);
    this.bindInput();
    this.ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(() => this.resize()) : null;
    this.ro?.observe(canvas);
  }

  resize() {
    const r = this.canvas.getBoundingClientRect();
    const aspect = r.width > 10 && r.height > 10 ? r.width / r.height : 16 / 9;
    this.H = this.res ?? 480; // (the battle stage draws finer)
    // phones held upright get a tall picture (activities fill the screen), not a little letterbox
    this.W = Math.max(aspect < 1 ? 280 : 480, Math.min(1280, Math.round(this.H * aspect)));
    // activities on an upright phone: a wider picture (taller buffer) so their buttons and bars fit, in the
    // screen's own shape (never stretched sideways)
    if (this.minW && this.W > Math.round(this.H * aspect) - 1 && aspect < 1) { this.W = this.minW; this.H = Math.min(940, Math.round(this.minW / aspect)); }
    this.canvas.width = this.W; this.canvas.height = this.H;
    this.floorCanvas.width = this.W; this.floorCanvas.height = this.H;
    this.fctx = this.floorCanvas.getContext('2d');
    this.img = this.fctx.createImageData(this.W, this.H);
    this.buf = new Uint32Array(this.img.data.buffer);
    // a narrow, tall picture keeps the same width of view (and shows more above and below)
    this.F = Math.min(this.H * 1.05, this.W * 1.12);
    this.floorKey = null;
    this.updateCamera();
  }

  /** Load an area: 'yard' (in this biome), 'farm', 'shop' or 'room' (a close corner of the biome). */
  /** The area's shape: yards grow with their size level (expansions bought at the market). */
  sceneDef(scene) {
    const base = SCENES[scene] ?? SCENES.yard;
    if (scene === 'farm') {
      // a bigger farm is deeper: one more row of planters per expansion
      const lv = Math.max(0, Math.min(3, this.farmSize ?? 0)), dz = lv * FARM_ROW;
      return { ...base, z1: base.z1 + dz, back: base.back + dz, pivotZ: base.pivotZ + dz * 0.5, plots: plotSpots(lv), farmDz: dz };
    }
    if (scene !== 'yard') return base;
    const Y = YARD_SIZES[Math.max(0, Math.min(YARD_SIZES.length - 1, this.yardSize ?? 2))];
    const k = Y.z / 12.2;
    return { ...base, x0: -Y.x, x1: Y.x, z1: Y.z, back: Y.z + 0.7, side: Y.x + 0.7, pivotZ: 1.6 + 3.6 * k, slide: 2.6 * (Y.x / 11), maxYaw: 0.42 * Math.min(1.1, Y.x / 11 + 0.15) };
  }
  /** The props around a battle field: the place's own things at the back and sides, the middle kept clear. */
  buildArena(biome, L, seed, put, add, r) {
    const kind = ARENA[biome];
    const clear = (x, z) => Math.hypot((x - BATTLE_SPOTS.near[0]) / 2.2, (z - BATTLE_SPOTS.near[1]) / 1.6) > 1 && Math.hypot((x - BATTLE_SPOTS.far[0]) / 2.2, (z - BATTLE_SPOTS.far[1]) / 1.6) > 1 && !(Math.abs(x) < 6.2 && z > -1.8 && z < 11.8);
    const props = this.props;
    const pushArt = (art, x, z, extra = {}) => props.push({ kind: 'arena', img: art.img, h: art.h, x, z, solid: true, ...extra });
    if (kind || biome === 'outskirts') {
      for (const p of arenaProps(kind ?? 'park', { seed, CZ: FIELD_Z })) props.push(p);
      // a few of the place's small things about the edges (tufts, flowers), never on the court
      if (!kind) for (let i = 0; i < 30; i++) { const x = (r() * 2 - 1) * 20, z = FIELD_Z + (r() * 2 - 1) * 16; const d = Math.hypot(x / 1.08, (z - FIELD_Z) / 0.9) / 1.4; if (d > 9.8 && d < 12.5) put(i % 3 ? 'flower' : 'bush', x, z); }
      if (kind === 'ruins') for (let i = 0; i < 24; i++) { const x = (r() * 2 - 1) * 14, z = FIELD_Z + (r() * 2 - 1) * 12; if (clear(x, z)) put(i % 2 ? 'rock' : 'tuft', x, z); }
      if (kind === 'shrine') for (let i = 0; i < 14; i++) { const x = (r() * 2 - 1) * 14, z = FIELD_Z + (r() * 2 - 1) * 12; if (clear(x, z)) put('bush', x, z); }
    } else {
      // a natural place: its usual things all the way round (so a shot from behind the foe still has
      // scenery), the big ones well back from the field and from where the camera stands; grass about
      for (const [k, n] of L.props) {
        if (FLOATS.has(k)) { for (let i = 0; i < Math.ceil(n * 0.8); i++) { const a = r() * Math.PI * 2, d = 11 + r() * 10; put(k, Math.cos(a) * d * 1.1, FIELD_Z + Math.sin(a) * d, { y: 2.4 + r() * 2.5, float: true, bob: r() * 6 }); } continue; }
        const small = ['flower', 'tuft', 'shell', 'lily'].includes(k);
        for (let i = 0; i < Math.ceil(n * (small ? 2 : 3.4)); i++) {
          for (let t = 0; t < 24; t++) {
            const a = r() * Math.PI * 2, back = Math.sin(a) < 0;
            const d = small ? 4 + r() * 12 : (back ? 12 : 9.5) + r() * 13;
            const x = Math.cos(a) * d * 1.15, z = FIELD_Z + Math.sin(a) * d * 0.95;
            if (!small && !clear(x, z)) continue;
            if (small && Math.hypot((x - BATTLE_SPOTS.near[0]) / 1.8, (z - BATTLE_SPOTS.near[1]) / 1.3) < 1) continue;
            if (small && Math.hypot((x - BATTLE_SPOTS.far[0]) / 1.8, (z - BATTLE_SPOTS.far[1]) / 1.3) < 1) continue;
            put(k, x, z);
            break;
          }
        }
      }
    }
  }
  /** Change the farm's size level (0 = six planters … 3 = fifteen). */
  setFarmSize(level) {
    if (level === this.farmSize) return;
    this.farmSize = level;
    if (this.scene !== 'farm') return;
    this.S = this.sceneDef('farm');
    this.updateCamera();
    this.build('meadow', this.seed);
  }
  /** Change the yard's size level (0 = the original yard … 3). */
  setYardSize(level) {
    if (level === this.yardSize) return;
    this.yardSize = level;
    if (this.scene !== 'yard') return;
    this.S = this.sceneDef('yard');
    this.updateCamera();
    this.build(this.biome, this.seed);
    for (const a of this.actors.values()) { a.x = this.clampX(a.x); a.z = this.clampZ(a.z); a.tx = a.x; a.tz = a.z; }
  }
  /** What's built in this yard: [{ id, bp, x, z, life (0…1: how much it has come alive) }]. */
  setFeatures(list = []) {
    const norm = list.map((f) => ({ ...f, def: blueprintOf(f.bp) })).filter((f) => f.def && f.def.kind !== 'expand');
    const key = JSON.stringify(norm.map((f) => [f.id, f.bp, f.x, f.z, Math.round((f.life ?? 0) * 4)]));
    if (key === this.featKey) { this.features = norm; return; }
    this.featKey = key;
    this.features = norm;
    if (this.scene === 'yard' || this.roomFeatures) this.build(this.biome, this.seed);
  }
  /**
   * Extra things standing in the scene (activities set up their own: a campfire, garden beds…):
   * [{ img, h, x, z, solid, kind }] (img from buildArt or Paint). Rebuilds the scene.
   */
  setDecor(list = []) { this.decor = list; this.build(this.biome, this.seed); }
  /** Take over a creature (activities): it stops wandering and goes where it's told. */
  puppet(uid, on = true) { const a = this.actors.get(uid); if (a) { a.puppet = on; a.state = 'idle'; a.goTo = null; } return a; }
  /** Walk a puppet to (x, z) at `speed` units a second (it faces the way it goes). */
  walkTo(uid, x, z, speed = 1.6) { const a = this.actors.get(uid); if (a) a.goTo = { x, z, speed }; }
  setScene(scene, biome = this.homeBiome ?? 'meadow', seed = this.seed ?? 1) {
    this.scene = SCENES[scene] ? scene : 'yard';
    this.S = this.sceneDef(this.scene);
    this.fetch = this.scene === 'room';
    this.homeBiome = biome;
    this.camX = this.camTarget = 0;
    this.yaw = this.yawTarget = 0;
    this.dist = this.distTarget = 1;
    this.pitch = this.pitchTarget = PITCH; this.camZ = this.camZTarget = 0;
    this.toys = []; this.sparks = [];
    this.updateCamera();
    const look = this.scene === 'farm' ? 'meadow' : this.scene === 'shop' ? 'outskirts' : biome;
    this.build(look, seed);
  }
  /** Change the yard's environment (stays in the same area). */
  setBiome(biome, seed = 1) { this.homeBiome = biome; this.seed = seed; this.build(this.scene === 'farm' ? 'meadow' : this.scene === 'shop' ? 'outskirts' : biome, seed); }

  build(biome, seed) {
    const S = this.S, scene = this.scene;
    this.biome = biome; this.seed = seed;
    const L = (this.L = habitatLook(biome));
    const st = (this.style = STYLE[biome] ?? STYLE.meadow);
    // where the land ends: on the mountaintop it drops away just past the fence, to the treetops far below
    // a mountaintop where everyone floats: no ground at all, just a sea of clouds below them
    const sky = (this.skyMode = biome === 'skyline' && !!this.skyAll && (scene === 'yard' || scene === 'room'));
    this.floorEnd = biome === 'skyline' && !sky && (scene === 'yard' || scene === 'room') ? S.back + (scene === 'room' ? 3 : 4.5) : S.floorEnd;
    this.updateCamera();
    const feats = scene === 'yard' || this.roomFeatures ? this.features ?? [] : [];
    this.floor = buildFloor(S, L, seed, biome, scene, sky, feats);
    this.floorAnimated = !!L.caustics || this.floor.mat.some((m) => m > 0);
    this.hasWater = this.floor.mat.some((m) => m === 1);
    this.floorKey = null;
    this.c = { water: hexRgb(L.water ?? '#3d9be0'), sky1: hexRgb(L.sky[1]), grid: hexRgb(L.grid) };
    const yb = Math.max(160, this.yBack ?? 200);
    this.layers = [
      { img: paintedLayer(st.far, L, seed, Math.round(yb * 0.92), 1, biome), f: 0.05 },
      { img: paintedLayer(st.mid, L, seed + 3, Math.round(yb * 0.5), 2, biome), f: 0.14 },
      { img: paintedNear(L, st, seed, Math.round(yb * 0.26), biome), f: 0.3 },
    ];
    // the colour along the bottom of the nearest strip, to fill under it when the view leans
    try {
      const near = this.layers[2].img;
      const d = near.getContext('2d').getImageData(0, near.height - 2, near.width, 1).data;
      let r = 0, g = 0, b = 0, n = 0;
      for (let i = 0; i < d.length; i += 16) if (d[i + 3] > 200) { r += d[i]; g += d[i + 1]; b += d[i + 2]; n++; }
      if (n) this.layers[2].base = `rgb(${(r / n) | 0},${(g / n) | 0},${(b / n) | 0})`;
    } catch { /* not readable */ }
    this.clouds = (L.cave || L.underwater || L.night) ? [] : Array.from({ length: 5 }, (_, i) => ({ img: Paint.cloud(seed * 7 + i, { w: 180 + i * 30, h: 64 + (i % 2) * 16, tint: biome === 'volcano' ? '#6a5a5c' : L.clouds ? '#fff0f7' : '#ffffff', shade: biome === 'volcano' ? '#2a2024' : L.clouds ? '#e6c8f0' : '#cdd6ee' }), x: (i * 0.23 + hash2(i, seed) * 0.1), y: 0.08 + hash2(seed, i) * 0.3, v: 3 + i * 1.5 }));
    const fenceKind = scene === 'farm' ? 'picket' : scene === 'shop' ? 'hedge' : st.fence;
    this.fenceImg = S.fence && !sky ? Paint.fence(fenceKind, L, seed) : null;
    // structural fences and walls are models (they have sides and turn with the camera); natural ones stay pictures
    this.fenceMesh = this.fenceImg ? { x: fenceMesh(fenceKind, this.fenceImg, 1.6, 'x', seed), z: fenceMesh(fenceKind, this.fenceImg, 1.1, 'z', seed) } : null;
    this.props = [];
    const r = rngFrom(seed * 31 + biome.length + scene.length * 7);
    let n0 = 0;
    const put = (kind, x, z, extra = {}) => { const pp = paintedProp(kind, L, seed * 101 + n0++, biome); if (pp) this.props.push({ kind, img: pp.img, h: pp.h, x, z, solid: !['flower', 'tuft', 'shell', 'lily'].includes(kind), ...extra }); return pp; };
    const add = (kind, img, x, z, h, extra = {}) => this.props.push({ kind, img, x, z, h, solid: true, ...extra });
    const TALL = { tree: 1, pine: 1, snowpine: 1, palm: 1, spire: 1, cactus: 1, kelp: 1, pillar: 1, deadtree: 1, lamppost: 1, monolith: 1, house: 1 };
    const free = (x, z, gap = 1.2) => !this.props.some((p) => (p.x - x) ** 2 + (p.z - z) ** 2 < gap) && !feats.some((f) => (f.x - x) ** 2 + (f.z - z) ** 2 < (f.def.r + 0.7) ** 2);
    // what's been built here: its pieces stand around (or in) its spot
    for (const f of feats) {
      const d = f.def, life = f.life ?? 0, art = [...(d.art ?? [])];
      if (f.bp === 'pond') for (let i = 0; i < 1 + Math.round(life * 4); i++) art.push('lily');
      if (f.bp === 'sun-patch' || f.bp === 'flower-bed') for (let i = 0; i < Math.round(life * 4); i++) art.push('flower');
      const rr = rngFrom(hashSeed(f.id));
      art.forEach((kind, i) => {
        const single = art.length === 1 && !['flower', 'rock', 'reed'].includes(kind);
        const inside = kind === 'lily';
        const ang = (i / art.length) * Math.PI * 2 + rr() * 0.8;
        const dist = single ? 0 : inside ? rr() * d.r * 0.7 : d.r * (0.85 + rr() * 0.25);
        const x = f.x + Math.cos(ang) * dist, z = f.z + Math.sin(ang) * dist * 0.75;
        const own = buildArt(kind, this.accent);
        const pp = own ?? (kind === 'lantern' ? { img: Paint.lantern(seed + i), h: 1.8 } : paintedProp(kind, L, hashSeed(f.id) + i * 7, biome));
        if (!pp) return;
        this.props.push({ kind, img: pp.img, h: pp.h, x, z, solid: !['flower', 'lily', 'reed'].includes(kind) && (single || kind !== 'glowshroom'), feature: f.id, glow: f.bp === 'moon-grove' && (kind === 'glowshroom' || kind === 'lantern') ? 0.3 + life * 0.7 : f.bp === 'lanterns' ? 0.6 : 0 });
      });
    }
    // inside the fence
    if ((scene === 'yard' || scene === 'room') && !sky) {
      const roomy = scene === 'room';
      for (const [kind, n] of L.props) {
        if (FLOATS.has(kind)) { for (let i = 0; i < Math.ceil(n * (roomy ? 0.5 : 1)); i++) put(kind, (r() * 2 - 1) * S.x1 * 0.9, S.back - 3 + r() * 3, { y: 2.2 + r() * 2.5, float: true, bob: r() * 6 }); continue; }
        for (let i = 0; i < Math.ceil(n * (roomy ? 0.4 : 1)); i++) {
          for (let t = 0; t < 24; t++) {
            const tall = TALL[kind];
            const x = (r() * 2 - 1) * (S.x1 - 0.4), z = tall || roomy ? S.back - 2.4 + r() * 2 : S.z0 + 0.3 + r() * (S.back - S.z0 - 0.8);
            // keep the middle open to play in
            if (!tall && Math.abs(x) < S.x1 * 0.55 && z < S.z1 * 0.6 && !['flower', 'tuft', 'shell'].includes(kind)) continue;
            if (this.matAt(x, z) || this.matAt(x - 0.7, z) || this.matAt(x + 0.7, z) || this.matAt(x, z + 0.5) || this.matAt(x, z - 0.5) || !free(x, z)) continue;
            put(kind, x, z);
            break;
          }
        }
      }
      const tufts = roomy ? 10 : 26;
      for (let i = 0; i < tufts; i++) { const x = (r() * 2 - 1) * S.x1, z = S.z0 + r() * (S.back - S.z0); if (!this.matAt(x, z)) put(FLOOR_STYLE[biome] === 'grass' ? (i % 3 ? 'tuft' : 'flower') : 'tuft', x, z); }
      if (scene === 'yard') this.props.push({ kind: 'beacon', img: PROPS.beacon(), x: S.x1 - 1.2, z: S.back - 0.8, h: 2.2, solid: true, beacon: true });
    }
    if (scene === 'battle' && !sky) this.buildArena(biome, L, seed, put, add, r);
    // the little things on the ground (grass, flowers, leaves, pebbles, shells, embers, crystals…)
    this.scatter = []; this.scatterLights = [];
    if (scene === 'battle' && !sky) {
      const kind = ARENA[biome] ?? null, F = FIELD_Z;
      const inside = { stadium: (x, z) => Math.abs(x) < 13.6 && z > F - 12.6 && z < F + 11.6 && !(Math.abs(x) < 5.7 && Math.abs(z - F) < 5.7), colosseum: (x, z) => Math.hypot(x / 1.2, z - F) < 13.6, outskirts: (x, z) => { const d = Math.hypot(x / 1.08, (z - F) / 0.9) / 1.4; return (d > 9.6 && d < 15.2) || (d < 7.2 && Math.random() < 0.06); } };
      const sc = buildScatter({ biome, arena: kind, L, seed, spots: [BATTLE_SPOTS.near, BATTLE_SPOTS.far], center: [0, F], radius: kind ? 15 : 30,
        ok: (x, z) => !this.matAt(x, z) && (inside[kind ?? biome]?.(x, z) ?? true) && free(x, z, 0.5) });
      this.scatter = sc.items; this.scatterLights = sc.lights;
    }
    if (scene === 'farm') {
      const dz = S.farmDz ?? 0;
      add('barn', Paint.barn(seed), -6.8, 9.2 + dz, 3.6);
      add('scarecrow', Paint.scarecrow(seed, '#e5484d'), 7.4, 5.4, 1.9);
      add('crate', Paint.crate(seed, '#c0306a'), 7, 8.8 + dz, 0.75);
      add('crate', Paint.crate(seed + 1, '#4ad0ff'), 7.9, 9.1 + dz, 0.75);
      for (let x = -9; x <= 9; x += 1.25) if (x > -3.9) add('sunflower', Paint.sunflower(seed + Math.round(x * 10)), x, 9.9 + dz, 2.1);
      add('sign', Paint.signboard('BERRY FARM', '#3fb26a'), -8.2, 1.2, 1.2);
      for (let i = 0; i < 5; i++) add('bush', Paint.bush(seed + 40 + i, '#4f9a3f', { flowers: i % 2 ? '#ffffff' : '#ff8fb6' }), 8.9 - (i % 2) * 0.3, 1 + i * 0.9, 0.95);
      // planter boxes with dirt in them (models), one per plot
      (S.plots ?? PLOTS).forEach(([px, pz]) => this.props.push({ kind: 'planter', mesh: planterMesh(3.6, 2.0, 0.34), x: px, z: pz, h: 0.34, solid: false, bed: true }));
    }
    if (scene === 'shop') {
      add('stall', Paint.stall(seed, this.accent), 0, 7.5, 3.6, { shopkeeper: true });
      add('bot', Paint.bot(seed), 0.9, 6.3, 1.35, { bot: true, shopkeeper: true });
      add('lantern', Paint.lantern(seed), -4.4, 6, 1.8);
      add('lantern', Paint.lantern(seed + 1), 4.4, 6, 1.8);
      add('crate', Paint.crate(seed + 2, '#ffc93c'), -3, 7.7, 0.75);
      add('crate', Paint.crate(seed + 3, '#3fb26a'), 3.2, 7.9, 0.75);
      add('crate', Paint.crate(seed + 4, '#4ad0ff'), 3.9, 7.5, 0.75);
      add('sign', Paint.signboard('SHOP', this.accent), -6.6, 1.2, 1.2);
      add('bench', Paint.bench(seed), -5.8, 3.6, 0.95);
      add('bench', Paint.bench(seed + 1), 5.8, 3.6, 0.95);
      for (const x of [-7.6, 7.6]) for (let z = 2; z < 9; z += 2.2) add('lamppost', Paint.lamppost(seed + Math.round(z * 3 + x)), x, z, 3.4);
    }
    // beyond the fence the land carries on: the biome's own scenery, thinning out into the haze
    const out = sky ? ['cloud'] : st.out ?? st.near;
    const road = biome === 'outskirts' ? [S.back + 1.4, S.back + 5] : null;
    const count = scene === 'room' ? 70 : 120;
    for (let i = 0, tries = 0; i < count && tries < count * 8; tries++) {
      const x = S.X0 + 3 + r() * (S.X1 - S.X0 - 6), z = S.z0 - 1 + Math.pow(r(), 0.8) * (S.floorEnd - S.z0 - 2);
      if (!sky && x > -S.side - 1.4 && x < S.side + 1.4 && z < S.back + 1.4) continue;
      if (road && z > road[0] && z < road[1]) continue;
      // nothing big right beside the camera
      if (z < S.z0 + 2 && Math.abs(x) < S.side + 5 && scene !== 'battle') continue;
      // a battle place: the arenas and the park are laid out on their own; elsewhere only far off, in the haze
      if (scene === 'battle' && (ARENA[biome] || biome === 'outskirts' || Math.hypot(x / 1.15, z - FIELD_Z) < 26)) continue;
      const kind = out[Math.floor(r() * out.length)];
      if (z > this.floorEnd - 1 || !free(x, z, TALL[kind] ? 2.6 : 1.4)) continue;
      const wet = this.matAt(x, z);
      if (wet === 1 || wet === 2) continue;
      put(kind, x, z, { outside: true });
      i++;
    }
    if (road) for (let x = S.X0 + 4; x < S.X1 - 4; x += 7 + r() * 5) put('lamppost', x, S.back + 1.2, { outside: true });
    // the city beyond the park: real 3D buildings (you see their sides as the view turns), taller
    // towers further back, factories with smokestacks and warehouses in between
    if (st.city && (scene === 'yard' || scene === 'room')) {
      const zStart = S.back + 6.2;
      for (let row = 0; row < 4; row++) {
        const z0 = zStart + row * 5.5;
        if (z0 > this.floorEnd - 3) break;
        for (let x = S.X0 + 4 + r() * 3; x < S.X1 - 4;) {
          const pick = r(), far = row / 3;
          let b;
          if (pick < 0.3 + far * 0.3) b = { type: 'tower', w: 2.6 + r() * 2, d: 2.4 + r() * 1.5, h: 7 + r() * 9 + far * 8 };
          else if (pick < 0.65) b = { type: 'factory', w: 4.5 + r() * 3, d: 3 + r() * 1.5, h: 2.6 + r() * 1.6, stacks: 1 + Math.floor(r() * 3) };
          else if (pick < 0.85) b = { type: 'warehouse', w: 5 + r() * 3, d: 3.4, h: 2.2 + r() * 1 };
          else b = { type: 'office', w: 3 + r() * 2, d: 2.6, h: 4.5 + r() * 4 };
          const colr = b.type === 'tower' ? ['#7d8fb3', '#8a9ab8', '#9aa8c4', '#6d7fa3'][Math.floor(r() * 4)] : b.type === 'office' ? ['#c8b8a0', '#b8a890', '#a0a8b8'][Math.floor(r() * 3)] : ['#9a8a7a', '#8a8a92', '#a89480', '#7a7a84'][Math.floor(r() * 4)];
          this.props.push({ kind: 'block', block: true, outside: true, solid: false, x: x + b.w / 2, z: z0 + r() * 1.2 + b.d / 2, h: b.h, ...b, color: colr, seed: Math.floor(r() * 1e6), img: null });
          if (b.stacks) for (let k = 0; k < b.stacks; k++) this.props.push({ kind: 'stack', block: true, outside: true, solid: false, type: 'stack', x: x + 0.8 + k * 1.1, z: z0 + b.d + 0.4, w: 0.42, d: 0.42, h: b.h + 3 + r() * 3, color: k % 2 ? '#8a8a92' : '#9a6a5a', seed: k, img: null, smoke: true });
          x += b.w + 0.8 + r() * 2.5;
        }
      }
    }
    this.particles = [];
    for (let i = 0; i < 60; i++) this.particles.push(this.newParticle(Math.random, true));
    this.sky = null;
    for (const d of this.decor ?? []) this.props.push({ solid: false, ...d, decor: true });
    // the foreground's trees, bushes and rocks become models (the far ones stay pictures)
    if (this.models !== false) {
      let k = 0;
      for (const p of this.props) {
        if (p.mesh || p.decor || !MODEL_KINDS.has(p.kind) || p.float) continue;
        if (this.scene === 'battle' ? Math.hypot(p.x, p.z - FIELD_Z) > 34 : (Math.abs(p.x) > S.side + 2 || p.z > S.back + 2.5)) continue;
        p.mesh = propMesh(p.kind, p.img, seed * 13 + (k++), p.h);
      }
    }
    this.loadCustom(biome, seed);
    this.warp = 1;
  }

  /** Your own art (all optional): ranch/<biome>-ground.png, -sky.png, -far.png, -mid.png, -near.png, -prop1…8.png */
  loadCustom(biome, seed) {
    const token = (this.loadToken = {});
    if (this.scene === 'farm' || this.scene === 'shop') return;
    const S = this.S;
    const img = (path) => new Promise((resolve) => {
      const url = this.resolve(path);
      if (!url) { resolve(null); return; }
      const im = new Image();
      im.onload = () => resolve(im); im.onerror = () => resolve(null); im.src = url;
    });
    const pixels = (im, w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(im, 0, 0, w, h); return new Uint32Array(x.getImageData(0, 0, w, h).data.buffer); };
    img(`ranch/${biome}-ground.png`).then((im) => {
      if (!im || token !== this.loadToken) return;
      // the image covers the fenced area
      const { TXW } = this.floor;
      const w = Math.round((S.side * 2) * S.TEX), h = Math.round((S.back - 0) * S.TEX), px = pixels(im, w, h);
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        const tx = Math.round((-S.side - S.X0) * S.TEX) + x, ty = Math.round((0 - S.Z0) * S.TEX) + y;
        this.floor.col[ty * TXW + tx] = px[(h - 1 - y) * w + x] | 0xff000000;
        this.floor.mat[ty * TXW + tx] = 0;
      }
      this.floorKey = null;
    });
    img(`ranch/${biome}-sky.png`).then((im) => { if (im && token === this.loadToken) this.sky = im; });
    ['far', 'mid', 'near'].forEach((k, i) => img(`ranch/${biome}-${k}.png`).then((im) => { if (im && token === this.loadToken) this.layers[i] = { ...this.layers[i], img: im }; }));
    const r = rngFrom(seed * 97 + 5);
    for (let i = 1; i <= 8; i++) img(`ranch/${biome}-prop${i}.png`).then((im) => {
      if (!im || token !== this.loadToken) return;
      for (let k = 0; k < 2; k++) { const at = this.randomSpot(r, true); this.props.push({ kind: 'custom', img: im, x: at.x, z: at.z, h: im.height / 18, solid: true }); }
    });
  }

  matAt(x, z) {
    const { X0, Z0, TEX } = this.S, { TXW, TXH } = this.floor;
    const tx = Math.floor((x - X0) * TEX), tz = Math.floor((z - Z0) * TEX);
    if (tx < 0 || tz < 0 || tx >= TXW || tz >= TXH) return 255;
    return this.floor.mat[tz * TXW + tx];
  }
  inBounds(x, z) { const S = this.S; return x >= S.x0 && x <= S.x1 && z >= S.z0 && z <= S.z1; }
  clampX(x) { return Math.max(this.S.x0, Math.min(this.S.x1, x)); }
  clampZ(z) { return Math.max(this.S.z0, Math.min(this.S.z1, z)); }
  /** Can this creature (or any creature, without one) stand here? Swimmers go in water, fliers anywhere. */
  walkable(x, z, a = null) {
    if (!this.inBounds(x, z)) return false;
    if (this.domed(a)) return this.inDome(x, z);
    const air = a && (a.fly || (this.swimAll && !this.domed(a)));
    let m = this.matAt(x, z);
    if (m === 5) m = a?.noWater ? 1 : 0; // a hot spring: anyone can wade in, except those who can't stand water
    if (a?.noWater && m === 1) return false;
    // somewhere it really doesn't like (fire creatures and the pond…): it keeps its distance
    if (a?.hate?.length && a.hate.some((f) => (f.x - x) ** 2 + ((f.z - z) * 1.3) ** 2 < (f.r + 0.5) ** 2)) return false;
    // can't walk at all: stays in the water (when there is any)
    if (a?.waterOnly && !air && m !== 1 && this.hasWater) return false;
    if (m === 1 && !(a?.swim || air)) return false;
    if (m === 2 && !(air || a?.fire)) return false;
    if (air) return true;
    return !this.props.some((p) => p.solid && !p.float && !p.outside && (p.x - x) ** 2 + (p.z - z) ** 2 < Math.min(1.2, 0.18 + p.h * 0.12));
  }
  /** A spot in the water, if this area has any. */
  waterSpot() {
    const S = this.S;
    for (let i = 0; i < 80; i++) {
      const x = S.x0 + Math.random() * (S.x1 - S.x0), z = S.z0 + Math.random() * (S.z1 - S.z0);
      if (this.matAt(x, z) === 1) return { x, z };
    }
    return null;
  }
  randomSpot(r = Math.random, edge = false, a = null) {
    const S = this.S;
    for (let i = 0; i < 60; i++) {
      const x = S.x0 + 0.4 + r() * (S.x1 - S.x0 - 0.8);
      // favour the front, where there is more to see
      const z = edge ? S.z1 - 3 + r() * 3 : S.z0 + 0.2 + Math.pow(r(), 1.3) * (S.z1 - S.z0 - 0.4);
      if (this.walkable(x, z, a)) return { x, z };
    }
    if (this.domed(a)) return { x: this.dome.x + (Math.random() - 0.5) * this.dome.r, z: this.dome.z + (Math.random() - 0.5) * this.dome.r * 0.6 };
    return { x: 0, z: (S.z0 + S.z1) / 2 };
  }

  newParticle(r = Math.random, anywhere = false) {
    const kind = this.L.fx, S = this.S;
    const p = { x: this.camX - 14 + r() * 28, y: anywhere ? r() * 5 : 0, z: S.z0 + r() * (S.back - S.z0 + 6), vx: 0, vy: 0, vz: 0, life: 4 + r() * 6, ph: r() * 6, kind };
    if (kind === 'snow') { p.y = anywhere ? r() * 7 : 6.5; p.vy = -0.7 - r() * 0.4; p.vx = 0.2; }
    else if (kind === 'ember') { p.vy = 0.6 + r() * 0.8; }
    else if (kind === 'bubble') { p.vy = 0.5 + r() * 0.5; }
    else if (kind === 'sand') { p.y = r() * 1.5; p.vx = 1.2 + r(); }
    else if (kind === 'feather') { p.y = 1 + r() * 4; p.vy = -0.25; p.vx = 0.3; }
    else if (kind === 'wisp') { p.y = 0.2 + r() * 1.5; p.vx = (r() - 0.5) * 0.4; p.vy = 0.05; }
    else if (kind === 'rain') { p.y = anywhere ? r() * 7 : 7; p.vy = -9; p.vx = -0.6; }
    else { p.y = 0.3 + r() * 3; p.vx = (r() - 0.5) * 0.3; p.vz = (r() - 0.5) * 0.3; }
    return p;
  }

  /**
   * list: [{ uid, speciesId, name, mood, speed, swim, fly, fire, sizeMul, types, friends: [uid], egg, clothes: [{ img, fx, fy, s }] }]
   * fly: flying types and levitators float above the ground (and sit now and then).
   */
  setCreatures(list) {
    const keep = new Set(list.map((c) => c.uid));
    for (const uid of [...this.actors.keys()]) if (!keep.has(uid)) this.actors.delete(uid);
    let i = 0;
    for (const c of list) {
      let a = this.actors.get(c.uid);
      if (!a) {
        const at = this.randomSpot();
        a = { uid: c.uid, x: at.x, z: at.z, y: 0, vy: 0, vx: 0, vz: 0, tx: at.x, tz: at.z, state: 'idle', timer: 1 + Math.random() * 2, flip: false, ft: Math.random() * 4, blink: 3, hop: 0, appear: -0.25 * i - 0.2, squash: 0, hoverY: 0.55 + Math.random() * 0.5, bobPh: Math.random() * 6, lastPlay: 0 };
        this.actors.set(c.uid, a);
      }
      i++;
      const spx = this.bank?.idx?.species.get(String(c.speciesId).split(':')[0]);
      a.rate = spx ? animRate(spx, c.sizeMul ?? 1) : 1;
      Object.assign(a, { featLikes: c.featLikes ?? {}, canFly: !!c.canFly, hover: !!c.hover, waterOnly: !!c.waterOnly, prefersWater: !!c.prefersWater, tired: !!c.tired, full: !!c.full, upset: !!c.upset, likes: c.likes ?? [], sunLover: !!c.sunLover, night: !!c.night, temper: c.temper ?? 'calm', noWater: !!c.noWater, speciesId: c.speciesId, name: c.name, mood: c.mood, speed: c.speed ?? 1.2, swim: !!c.swim, fly: !!c.fly, fire: !!c.fire, electric: !!c.electric, asleep: !!c.asleep, dreamer: !!c.dreamer, wxPrefs: c.wxPrefs ?? {}, misfit: !!c.misfit, sizeMul: c.sizeMul ?? 1, fx: typeFxOf(c.types ?? []), friends: c.friends ?? [], clothes: c.clothes ?? [], egg: !!c.egg || c.speciesId === '__egg' });
      if (a.hover && (a.hoverY ?? 1) > 0.3) a.hoverY = 0.16 + Math.random() * 0.12; // hoverers stay low
    }
    // a seafloor yard where everyone is a swimmer: the water fills it, and they swim about in it
    for (const a of this.actors.values()) a.hate = this.features.filter((f) => (a.featLikes?.[f.id] ?? 0) < -0.35).map((f) => ({ x: f.x, z: f.z, r: f.def.r }));
    // creatures that can't go in water (fire types…) get a dry dome to stay in instead
    // on the seafloor, everyone who can't breathe underwater (non-swimmers, fire types, water-haters) keeps to the dome
    const isDry = (c) => !!c.noWater || !!c.fire || !c.swim || !!c.egg || c.speciesId === '__egg';
    const dry = this.biome === 'seafloor' ? list.filter(isDry) : list.filter((c) => c.noWater);
    const wet = list.filter((c) => !dry.includes(c));
    for (const c of list) { const a = this.actors.get(c.uid); if (a) a.dry = dry.includes(c); }
    this.swimAll = this.biome === 'seafloor' && wet.length > 0;
    this.dome = this.biome === 'seafloor' && this.scene !== 'room' && dry.length ? { x: -this.S.x1 * 0.45, z: this.S.z0 + (this.S.z1 - this.S.z0) * 0.42, r: Math.min(3.4, 1.6 + dry.length * 0.35) } : null;
    if (this.biome === 'seafloor' && this.scene === 'room' && dry.length) this.dome = { x: 0, z: (this.S.z0 + this.S.z1) / 2, r: 2.6 };
    // a little gazebo in every yard that gets weather: shelter for those who don't like the rain (or this place)
    this.shelter = this.scene === 'yard' && !this.roomFeatures && !NO_WEATHER.has(this.biome) ? { x: this.S.x1 * 0.5, z: this.S.z0 + (this.S.z1 - this.S.z0) * 0.72, r: 1.0 } : null;
    for (const a of this.actors.values()) if (this.domed(a) && !this.inDome(a.x, a.z)) { a.x = this.dome.x; a.z = this.dome.z; a.tx = a.x; a.tz = a.z; a.y = 0; }
    const skyAll = list.length > 0 && list.every((c) => c.fly && !c.hover && !c.egg);
    if (skyAll !== !!this.skyAll) { this.skyAll = skyAll; if (this.biome === 'skyline') this.build(this.biome, this.seed); }
  }
  /** In the care room everyone is shown about the same, close-up size. */
  boostOf(a) {
    if (this.scene !== 'room') return 1;
    const base = CREATURE_H * this.sizeScale * (a.sizeMul ?? 1) * (a.speciesId === '__egg' ? 0.16 : sizeFactor(this.bank?.idx?.species.get(String(a.speciesId).split(':')[0])));
    return Math.max(1, Math.min(4, 1.15 / Math.max(0.05, base)));
  }
  setSizeScale(v) { this.sizeScale = Math.max(0.3, Math.min(2.5, Number(v) || 1)); }
  /** How tall this actor stands, in units. */
  heightOf(a) { return this.boostOf(a) * CREATURE_H * this.sizeScale * (a.sizeMul ?? 1) * (a.speciesId === '__egg' ? 0.16 : sizeFactor(this.bank?.idx?.species.get(String(a.speciesId).split(':')[0]))); }
  setPlots(list) { this.plots = list; this.plotImgs = list.map((p, i) => (p?.empty ? null : [0, 1, 2].map((k) => plantImg(p.stage, p.item?.color ?? '#c0306a', i * 3 + k + 1)))); }

  materialize() {
    let i = 0;
    for (const a of this.actors.values()) {
      const at = this.domed(a) ? this.randomSpot(Math.random, false, a) : this.scene === 'room' ? { x: (Math.random() - 0.5) * 1.2, z: this.S.z0 + 1.4 } : this.randomSpot();
      Object.assign(a, { x: at.x, z: at.z, tx: at.x, tz: at.z, y: (a.fly || (this.swimAll && !this.domed(a))) ? a.hoverY : 0, vy: 0, vx: 0, vz: 0, state: 'idle', sitting: false, timer: 1.5 + Math.random() * 2, appear: -0.22 * i++ - 0.3 });
    }
    this.warp = 1;
  }

  /** Turn the view (d = -1 left, +1 right), or 0 to face the area straight on. */
  turn(d) { const M = this.S.maxYaw; this.yawTarget = d === 0 ? 0 : Math.max(-M, Math.min(M, this.yawTarget + d * 0.17)); if (d === 0) this.camTarget = 0; }
  /** Zoom: d < 0 closer, d > 0 further out, 0 back to normal. */
  /** Point the camera for an activity: { pitch (radians, 0.22 = usual), x, z (pivot), dist, yaw, snap }. */
  view({ pitch, x, z, dist, yaw, snap = false } = {}) {
    if (pitch != null) this.pitchTarget = pitch;
    if (x != null) this.camTarget = x;
    if (z != null) this.camZTarget = z - this.S.pivotZ;
    if (dist != null) this.distTarget = dist;
    if (yaw != null) this.yawTarget = yaw;
    if (snap) { this.pitch = this.pitchTarget; this.camX = this.camTarget; this.camZ = this.camZTarget; this.dist = this.distTarget; this.yaw = this.yawTarget; this.updateCamera(); this.floorKey = null; }
  }
  zoom(d) { this.distTarget = d === 0 ? 1 : Math.max(0.62, Math.min(1.38, this.distTarget + d * 0.12)); }

  react(uid, kind, n = 3) {
    const a = this.actors.get(uid);
    if (!a) return;
    if (['hearts', 'note', 'sparkle'].includes(kind)) { if (!['held', 'falling', 'chase', 'return'].includes(a.state)) { a.state = 'happy'; a.timer = 1.6; } a.hop = 1; }
    if (kind === 'sleep') { a.state = 'sleep'; a.timer = 8; }
    if (kind === 'munch') { a.state = 'eat'; a.timer = 2; }
    if (kind === 'hearts') this.emote(uid, 'love');
    else if (kind === 'note') this.emote(uid, 'note');
    else if (kind === 'dizzy') this.emote(uid, 'wow', false);
    else if (kind === 'sad') this.emote(uid, 'frown', false);
    for (let i = 0; i < n; i++) this.reacts.push({ uid, kind, t: -i * 0.2, life: 1.5, dx: (Math.random() - 0.5) * 0.8 });
  }
  /** A bubble over their head (how they feel, or the face given), with a burst of their type's particles. */
  emote(uid, face, burst = true) {
    const a = this.actors.get(uid);
    if (!a || a.egg) return;
    a.bubble = { face: face ?? MOOD_FACE[a.mood] ?? 'calm', t: 0, life: 2.4 };
    if (burst) this.burst(a, a.bubble.face === 'tired' || a.bubble.face === 'frown' ? 3 : 7);
  }
  /** Do what they were asked (from talking): come, sit, jump, spin, dance, move left/right/away/near, play. */
  command(uid, act) {
    const a = this.actors.get(uid);
    if (!a || a.egg || !act || ['held', 'falling', 'sleep'].includes(a.state)) return;
    const go = (sx, sy) => {
      const p = this.floorAt(sx, sy);
      if (!p) return;
      a.tx = this.clampX(p.x); a.tz = this.clampZ(p.z); a.state = 'walk'; a.timer = 9; a.goal = null; a.sitting = false;
    };
    const me = this.project(a.x, a.y || 0, a.z) ?? { x: this.W / 2, y: this.H * 0.6 };
    switch (act.kind) {
      case 'come': go(this.W / 2 + (Math.random() - 0.5) * this.W * 0.15, this.H * 0.8); break;
      case 'move': {
        const d = act.dir;
        if (d === 'left') go(Math.max(this.W * 0.08, me.x - this.W * 0.3), me.y);
        else if (d === 'right') go(Math.min(this.W * 0.92, me.x + this.W * 0.3), me.y);
        else if (d === 'away') go(me.x, Math.max(this.H * 0.35, me.y - this.H * 0.22));
        else go(me.x, Math.min(this.H * 0.9, me.y + this.H * 0.22));
        break;
      }
      case 'sit': a.state = 'idle'; a.timer = 14; a.goTo = null; a.tx = a.x; a.tz = a.z; if (a.fly) a.sitting = true; break;
      case 'jump': a.hop = 1; a.jumpT = 0.9; break;
      case 'spin': a.spinT = 1.4; break;
      case 'dance': a.danceT = 3.2; this.emote(uid, 'note'); break;
      case 'play': this.throwToy('ball', null, null, uid); break;
      // to the toy box at the back for it, then back to you with it (it lands in front of them)
      case 'fetch': {
        go(this.W * (0.15 + Math.random() * 0.7), this.H * 0.4);
        setTimeout(() => { const b = this.actors.get(uid); if (!b || this.running === false) return; this.emote(uid, 'exclaim'); this.command(uid, { kind: 'come' }); }, 2200);
        setTimeout(() => { if (this.actors.get(uid) && this.running !== false) this.throwToy(TOYS[act.toy] ? act.toy : 'ball', null, null, uid); }, 4600);
        break;
      }
      // over to a friend, to keep them company
      case 'pair': {
        const b = this.actors.get(act.with);
        if (!b) break;
        const side = a.x < b.x ? -0.55 : 0.55;
        a.tx = this.clampX(b.x + side); a.tz = this.clampZ(b.z + 0.1); a.state = 'walk'; a.timer = 12; a.goal = null; a.sitting = false;
        setTimeout(() => { if (this.actors.get(uid) && this.actors.get(act.with)) { this.emote(uid, 'hearts'); this.emote(act.with, 'hearts'); } }, 2600);
        break;
      }
      default: break;
    }
  }
  /** A thought bubble with a picture in it (a canvas: an item, a friend, an emoji), for talking. */
  think(uid, pic, life = 4.2) {
    const a = this.actors.get(uid);
    if (!a || a.egg || !pic) return;
    a.bubble = { face: 'calm', pic, t: 0, life };
  }
  /** One small puff of a creature's type particles (battles). */
  typeWhiff(a, kind) {
    const tall = this.heightOf(a), sz = a.sizeMul ?? 1;
    const n = kind === 'ember' ? 2 : 1;
    for (let i = 0; i < n; i++) {
      const s = { kind, x: a.x + (Math.random() - 0.5) * 0.5 * Math.min(2, sz), y: (a.y || 0) + tall * (0.3 + Math.random() * 0.6), z: a.z - 0.05, vx: (Math.random() - 0.5) * 0.4, vy: 0, vz: 0, life: 0.8 + Math.random() * 0.6, ph: Math.random() * 6, c: Math.random() < 0.5 ? 0 : 1 };
      if (kind === 'ember') { s.vy = 0.9 + Math.random() * 0.7; s.life = 0.6 + Math.random() * 0.5; }
      else if (kind === 'spark') { const ang = Math.random() * Math.PI * 2; s.x = a.x + Math.cos(ang) * 0.35 * Math.min(2, sz); s.vx = Math.cos(ang) * 2.2; s.vy = Math.sin(ang) * 2.2; s.life = 0.25 + Math.random() * 0.2; }
      else if (kind === 'flake' || kind === 'leaf') s.vy = -0.15;
      else if (kind === 'drop') { s.vy = 1.2 + Math.random(); s.g = 6; }
      else s.vy = 0.35 + Math.random() * 0.4;
      this.sparks.push(s);
    }
    if (this.sparks.length > 220) this.sparks.splice(0, this.sparks.length - 220);
  }
  burst(a, n = 6) {
    const tall = this.heightOf(a), kind = a.fx ?? 'plain';
    for (let i = 0; i < n; i++) {
      const s = { kind, x: a.x + (Math.random() - 0.5) * 0.7, y: (a.y || 0) + tall * (0.55 + Math.random() * 0.5), z: a.z - 0.05, vx: (Math.random() - 0.5) * 0.9, vy: 0, vz: 0, life: 1 + Math.random() * 0.8, ph: Math.random() * 6, c: Math.random() < 0.5 ? 0 : 1 };
      switch (kind) {
        case 'ember': case 'glitter': case 'wisp': case 'bubble': s.vy = 0.6 + Math.random() * 0.6; break;
        case 'drop': case 'pebble': s.vy = 1.6 + Math.random(); s.g = 6; break;
        case 'leaf': case 'flake': s.vy = -0.2; break;
        case 'spark': case 'star': { const ang = Math.random() * Math.PI * 2; s.vx = Math.cos(ang) * 1.6; s.vy = Math.sin(ang) * 1.6; s.life = 0.5 + Math.random() * 0.3; break; }
        case 'gust': s.vx = (Math.random() < 0.5 ? -1 : 1) * (1.2 + Math.random()); s.vy = 0.1; break;
        case 'ring': s.vx = 0; s.vy = 0.15; s.life = 1.2; break;
        default: s.vy = 0.4 + Math.random() * 0.4;
      }
      this.sparks.push(s);
    }
    if (this.sparks.length > 220) this.sparks.splice(0, this.sparks.length - 220);
  }

  // ---------- toys and food ----------
  /** Throw a toy (or a berry: kind 'berry', item = the food) in from where you stand. */
  throwToy(kind = 'ball', item = null, target = null, forUid = null) {
    const S = this.S;
    const me = forUid ? this.actors.get(forUid) : null;
    let t;
    if (me && !me.egg) {
      // for someone in particular (you had them selected): it drops in right in front of them, and the
      // others leave it to them for a while
      const fx = this.clampX(me.x + (me.flip ? -0.35 : 0.35)), fz = this.clampZ(me.z - 0.15);
      t = { kind: TOYS[kind] ? kind : 'ball', item, x: fx, y: (me.y || 0) + this.heightOf(me) + 0.9, z: fz, vx: 0, vy: 0, vz: 0, spin: 0, squash: 0, age: 0, r: (TOYS[kind] ?? TOYS.ball).r, for: forUid };
    } else {
      const at = target ? { x: this.clampX(target.x), z: this.clampZ(target.z) } : this.randomSpot();
      const z0 = S.z0 - 0.3, x0 = this.camX + (Math.random() - 0.5) * 1.5;
      const T = 0.9 + Math.random() * 0.3; // seconds in the air before the first bounce, about
      t = { kind: TOYS[kind] ? kind : 'ball', item, x: x0, y: 1.6, z: z0, vx: (at.x - x0) / T * 0.55, vy: 5, vz: (at.z - z0) / T * 0.55, spin: 0, squash: 0, age: 0, r: (TOYS[kind] ?? TOYS.ball).r };
    }
    this.toys.push(t);
    // tidy: at most 6 things lying about (berries first to go)
    while (this.toys.length > 6) { const i = this.toys.findIndex((x) => x.kind === 'berry' && x !== t); this.toys.splice(i >= 0 ? i : 0, 1); }
    this.notice(t);
    return t;
  }
  tossBerry(item, forUid = null) { return this.throwToy('berry', item ?? { color: '#c0306a' }, null, forUid); }
  throwBall() { return this.throwToy('ball'); }
  clearToys() { this.toys = []; for (const a of this.actors.values()) if (a.state === 'chase' || a.state === 'return') { a.state = 'idle'; a.timer = 1; a.toy = null; } }
  /** Creatures nearby take an interest in a toy that just landed or flew past. */
  notice(t, chance = this.fetch ? 1 : 0.8) {
    for (const a of this.actors.values()) {
      if (a.egg || a.appear < 1 || ['sleep', 'held', 'falling', 'return'].includes(a.state)) continue;
      // meant for someone else: left alone for now
      if (this.reservedFor(t, a)) continue;
      if (t.for === a.uid) { a.state = 'chase'; a.toy = t; a.timer = 10; a.kicks = 0; a.sitting = false; continue; }
      // too tired to play, too full to eat, or sulking: they let it go by
      if (t.kind === 'berry' ? a.full : a.tired) continue;
      if (a.upset && Math.random() < 0.8) continue;
      if (this.domed(a) && !this.inDome(t.x, t.z)) continue;
      if (a.state === 'chase' && a.toy && a.toy !== t && Math.random() < 0.6) continue;
      if (Math.random() > chance) continue;
      a.state = 'chase'; a.toy = t; a.timer = 8; a.kicks = 0; a.sitting = false;
    }
  }
  updateToys(dt) {
    const S = this.S;
    for (const t of this.toys) {
      t.age += dt;
      t.squash = Math.max(0, t.squash - dt * 5);
      if (t.carriedBy) {
        const a = this.actors.get(t.carriedBy);
        if (a && a.state === 'return') { t.x = a.x + (a.flip ? -1 : 1) * 0.22; t.z = a.z - 0.06; t.y = (a.y || 0) + this.heightOf(a) * 0.4; t.vx = t.vy = t.vz = 0; continue; }
        t.carriedBy = null;
      }
      if (t.held) continue;
      if (t.stuck) { t.x = t.stuck.x + (t.sx ?? 0); t.z = t.stuck.z - 0.15; t.y = t.stuck.h * 0.62; t.vx = t.vy = t.vz = 0; continue; }
      const P = TOYS[t.kind] ?? TOYS.ball;
      const g = P.floaty ? 3 : 14;
      t.vy -= g * dt;
      if (P.floaty) { const k = Math.pow(0.35, dt); t.vx *= k; t.vz *= k; if (t.vy < -1.2) t.vy = -1.2; t.vx += Math.sin(t.age * 3) * dt * 0.6; }
      if (P.glide && t.y > t.r + 0.05) t.vy += Math.min(9, Math.hypot(t.vx, t.vz) * 1.5) * dt;
      t.x += t.vx * dt; t.y += t.vy * dt; t.z += t.vz * dt;
      const sp = Math.hypot(t.vx, t.vz);
      if (t.y <= t.r) {
        t.y = t.r;
        if (t.vy < -1.1) { const hit = -t.vy; t.vy = hit * P.bounce; t.squash = Math.min(1, hit / 8); if (hit > 3) this.onBounce?.(t, hit); }
        else t.vy = 0;
        const f = Math.pow(P.roll, dt * 60); t.vx *= f; t.vz *= f;
        if (this.matAt(t.x, t.z) === 1) { t.vx *= 0.97; t.vz *= 0.97; t.y = t.r * 0.6 + Math.sin(t.age * 3) * 0.04; } // floats on water
      }
      t.spin += (t.vx >= 0 ? 1 : -1) * sp * dt / Math.max(0.1, t.r);
      // flying high into a tree: sometimes it gets caught up there
      if (t.kind !== 'berry' && t.y > 1.3 && t.vy < 0 && this.scene === 'yard' && !this.fetch) {
        const tree = this.props.find((p) => !p.outside && p.h >= 2.5 && TREE_KINDS.has(p.kind) && (p.x - t.x) ** 2 + (p.z - t.z) ** 2 < 0.8);
        if (tree && Math.random() < 0.3) { t.stuck = tree; t.sx = (Math.random() - 0.5) * 0.6; t.tries = 0; }
      }
      // walls: bounce off the fence (the room has soft edges)
      const wb = 0.55;
      if (t.x < S.x0 - 0.3) { t.x = S.x0 - 0.3; t.vx = Math.abs(t.vx) * wb; }
      if (t.x > S.x1 + 0.3) { t.x = S.x1 + 0.3; t.vx = -Math.abs(t.vx) * wb; }
      if (t.z < S.z0 - 0.6) { t.z = S.z0 - 0.6; t.vz = Math.abs(t.vz) * wb; }
      if (t.z > S.z1 + 0.4) { t.z = S.z1 + 0.4; t.vz = -Math.abs(t.vz) * wb; }
      // creatures walking into a toy nudge it along
      if (t.y < t.r + 0.3) for (const a of this.actors.values()) {
        if (a.appear < 1 || a.state === 'held' || (a.y || 0) > 0.6) continue;
        const dx = t.x - a.x, dz = t.z - a.z, d2 = dx * dx + dz * dz, rr = 0.3 + t.r;
        if (d2 < rr * rr && d2 > 1e-4) { const d = Math.sqrt(d2), push = (rr - d) * 6; t.vx += (dx / d) * push; t.vz += (dz / d) * push; }
      }
    }
    // berries nobody wants go off after a while
    this.toys = this.toys.filter((t) => !(t.kind === 'berry' && t.age > 45 && !t.carriedBy));
  }
  /** Is this toy (or berry) being kept for someone other than a? (Only for the first while.) */
  reservedFor(t, a) { return !!(t?.for && t.for !== a.uid && t.age < 12 && this.actors.has(t.for)); }
  /** What happens when a creature reaches the toy it is after. */
  reachToy(a, t) {
    if (this.reservedFor(t, a)) { a.state = 'idle'; a.timer = 1; a.toy = null; return; }
    if (t.for === a.uid) t.for = null; // theirs now; after this anyone can join in
    if (t.kind === 'berry') {
      if (this.fetch) { t.carriedBy = a.uid; a.state = 'return'; a.timer = 12; return; }
      this.toys = this.toys.filter((x) => x !== t);
      for (const o of this.actors.values()) if (o.toy === t) { o.state = 'idle'; o.timer = 1; o.toy = null; }
      a.state = 'happy'; a.timer = 1.6; a.hop = 1; a.toy = null;
      this.onEat?.(a.uid, t.item ?? {});
      return;
    }
    if (this.fetch) { t.carriedBy = a.uid; a.state = 'return'; a.timer = 12; for (const o of this.actors.values()) if (o !== a && o.toy === t) { o.state = 'idle'; o.timer = 1; o.toy = null; } return; }
    // kick it! where it goes depends on how bouncy it is — and often to someone nearby, who joins in
    const P = TOYS[t.kind] ?? TOYS.ball;
    const mate = Math.random() < 0.7 ? this.playmate(a, t) : null;
    let dx, dz, power;
    if (mate) {
      dx = mate.x - t.x; dz = mate.z - t.z;
      const d = Math.hypot(dx, dz) || 1;
      dx = dx / d + (Math.random() - 0.5) * 0.25; dz = dz / d + (Math.random() - 0.5) * 0.25;
      power = Math.max(2, Math.min(7.5, 1.4 + d * 0.95)) * (P.floaty ? 0.55 : 1);
      mate.state = 'chase'; mate.toy = t; mate.timer = 7; mate.kicks = 0; mate.sitting = false;
      this.onPlayTogether?.(a.uid, mate.uid);
    } else {
      dx = t.x - a.x; dz = t.z - a.z; const d = Math.hypot(dx, dz) || 1;
      dx = dx / d + (Math.random() - 0.5) * 0.8; dz = dz / d + (Math.random() - 0.5) * 0.8;
      power = (2.6 + Math.random() * 2.4) * (P.floaty ? 0.5 : 1);
    }
    t.vx = dx * power; t.vz = dz * power; t.vy = P.floaty ? 1.8 : 2 + P.bounce * 4 + Math.random() * 1.5;
    if (P.glide) t.vy = 2.2;
    // fliers juggle it up into the air
    if (a.fly && (a.y || 0) > 0.3) { t.vy = 4.5 + Math.random() * 1.5; t.vx *= 0.6; t.vz *= 0.6; }
    a.hop = 1; a.kicks = (a.kicks ?? 0) + 1;
    if (this.time - (a.lastPlay ?? -9) > 2.5) { a.lastPlay = this.time; this.onPlay?.(a.uid, t.kind, t.item); }
    if (a.kicks > 1 + Math.random() * 4) { a.state = 'happy'; a.timer = 1.4; a.toy = null; if (Math.random() < 0.5) this.emote(a.uid, 'smile'); }
    else a.timer = 4;
  }

  /** Arrived at something built: what it does there depends on what it is. */
  atFeature(a, f) {
    const tags = f.def.tags ?? [];
    const like = a.featLikes?.[f.id] ?? 0;
    this.onFeatureVisit?.(a.uid, f.bp);
    if (like > 0.6) this.emote(a.uid, 'love', false);
    if (tags.includes('sun') && this.tod === 'day') { a.state = 'sleep'; a.sunbathe = true; a.timer = 10 + Math.random() * 8; this.emote(a.uid, 'sun', false); return; }
    if (tags.includes('rest')) { a.state = 'sleep'; a.timer = 8 + Math.random() * 8; return; }
    if (f.bp === 'toy-chest') {
      const kinds = ['ball', 'duck', 'plush', 'bell', 'disc'];
      const t = { kind: kinds[Math.floor(Math.random() * kinds.length)], item: null, x: f.x, y: 0.9, z: f.z - 0.3, vx: (Math.random() - 0.5) * 3, vy: 3, vz: -1 - Math.random() * 2, spin: 0, squash: 0, age: 0 };
      t.r = TOYS[t.kind].r;
      this.toys.push(t);
      while (this.toys.length > 6) this.toys.splice(this.toys.findIndex((x) => x !== t), 1);
      a.state = 'chase'; a.toy = t; a.timer = 6; a.kicks = 0;
      return;
    }
    if (tags.includes('play') || tags.includes('toy')) { a.state = 'play'; a.timer = 3 + Math.random() * 4; return; }
    if (tags.includes('sky') && a.fly) { a.sitting = true; a.state = 'idle'; a.timer = 6 + Math.random() * 6; return; }
    a.state = 'happy'; a.timer = 1.5;
  }
  /** Someone close by who'd happily join in a game (friends first). */
  playmate(a, t) {
    let best = null, bestD = 7.5;
    for (const o of this.actors.values()) {
      if (o === a || o.egg || o.appear < 1 || o.tired || o.upset || ['sleep', 'held', 'falling', 'return'].includes(o.state)) continue;
      if (this.domed(o) && !this.domed(a)) continue;
      const d = Math.hypot(o.x - t.x, o.z - t.z) * (a.friends?.includes(o.uid) ? 0.55 : 1);
      if (d > 0.9 && d < bestD) { best = o; bestD = d; }
    }
    return best;
  }

  wantsShelter(a) {
    const bad = ['rain', 'storm', 'snow'].includes(this.weather) || (this.weather === 'windy' && a.sizeMul < 0.8);
    if (bad && (a.fire || a.noWater || (a.wxPrefs?.[this.weather] ?? 0) <= -1)) return Math.random() < 0.85;
    if (bad && (a.wxPrefs?.[this.weather] ?? 0) >= 1) return false;
    if (bad) return Math.random() < 0.25;
    return !!a.misfit && Math.random() < 0.4;
  }
  inShelter(x, z) { const G = this.shelter; return !!G && Math.abs(x - G.x) < G.r && Math.abs(z - G.z) < G.r * 0.8; }
  // ---------- the dome: creatures who can't be in water get a dry bubble on the seafloor ----------
  domed(a) { return !!(a?.dry && this.dome); }
  domeEdge(x, z) {
    const D = this.dome, dx = x - D.x, dz = (z - D.z) * 1.3, d = Math.hypot(dx, dz) || 1, R = D.r - 0.3;
    return { x: D.x + (dx / d) * R, z: D.z + ((dz / d) * R) / 1.3 };
  }
  inDome(x, z) { const D = this.dome; return !!D && (x - D.x) ** 2 + ((z - D.z) * 1.3) ** 2 < (D.r - 0.25) ** 2; }

  // ---------- camera ----------
  /** Where an actor is on screen, in page pixels (for effects drawn over the yard). */
  screenRect(uid) {
    const a = this.actors.get(uid);
    if (!a) return null;
    const tall = this.heightOf(a);
    const p = this.project(a.x, (a.y || 0) + tall / 2, a.z);
    if (!p || p.z <= 0) return null;
    const r = this.canvas.getBoundingClientRect();
    const sx = r.width / this.W, sy = r.height / this.H;
    const size = Math.max(40, Math.min(220, p.k * tall * 1.1 * sx));
    return { left: r.left + p.x * sx - size / 2, top: r.top + p.y * sy - size / 2, width: size, height: size };
  }
  /** An actor's box on the canvas (canvas pixels), from the last frame. */
  actorBox(uid) { return this.hits.find((h) => h.uid === uid) ?? null; }

  /** Camera position, turn and distance for this frame. */
  /** A free camera (the battle stage's shots): standing at eye, looking at `at`; lookFrom(null) goes back to the usual one. */
  lookFrom(eye, at) {
    if (!eye) { this.free = null; this.updateCamera(); return; }
    const dx = at.x - eye.x, dz = at.z - eye.z, hd = Math.max(1e-3, Math.hypot(dx, dz));
    this.free = { x: eye.x, y: Math.max(0.12, eye.y), z: eye.z, yaw: Math.atan2(dx, dz), pitch: Math.atan2(eye.y - at.y, hd) };
    this.updateCamera();
  }
  updateCamera() {
    if (this.free) {
      const f = this.free;
      this.yaw = this.yawTarget = f.yaw; this.pitch = this.pitchTarget = f.pitch;
      this.camX = this.camTarget = f.x; this.camZ = this.camZTarget = f.z; this.dist = this.distTarget = 1;
      this.camY = f.y; this.cx = f.x; this.cz = f.z;
      this.ys = Math.sin(f.yaw); this.yc = Math.cos(f.yaw); this.ps = Math.sin(f.pitch); this.pc = Math.cos(f.pitch);
      if (this.H) this.yBack = Math.floor(this.H / 2 - this.F * Math.tan(f.pitch));
      return;
    }
    const S = this.S, d = this.dist ?? 1;
    const P = this.pitch ?? PITCH;
    // looking further down lifts the camera, so the pivot stays in the middle of the screen
    const R0 = (S.pivotZ - S.camZ) * d;
    const lift = Math.max(0, Math.tan(P) - Math.tan(PITCH)) * R0;
    this.camY = S.camY * (0.55 + 0.45 * d) + lift;
    const R = R0;
    this.ys = Math.sin(this.yaw); this.yc = Math.cos(this.yaw);
    this.cx = this.camX - R * this.ys;
    this.cz = S.pivotZ + (this.camZ ?? 0) - R * this.yc;
    this.ps = Math.sin(P); this.pc = Math.cos(P);
    // where the land ends on screen when facing straight on: the backdrops sit on this line
    if (this.H) {
      const dy = -this.camY, dz = (this.floorEnd ?? S.floorEnd) - this.cz, s = this.ps, c = this.pc;
      const zc = -dy * s + dz * c, yc = dy * c + dz * s;
      this.yBack = Math.floor(this.H / 2 - (this.F * yc) / zc);
      // an open floor (activities that turn all the way round): the land runs to the true horizon
      if (this.openFloor) this.yBack = Math.floor(this.H / 2 - this.F * Math.tan(P));
    }
  }

  project(x, y, z) {
    const wx = x - this.cx, dy = y - this.camY, wz = z - this.cz;
    const dx = wx * this.yc - wz * this.ys, dz = wx * this.ys + wz * this.yc;
    const s = this.ps, c = this.pc;
    const zc = -dy * s + dz * c, yc = dy * c + dz * s;
    if (zc < 0.3) return null;
    const F = this.F ?? this.H * 1.05;
    return { x: this.W / 2 + (F * dx) / zc, y: this.H / 2 - (F * yc) / zc, z: zc, k: F / zc };
  }
  /** The floor point under a screen pixel, or null above the floor. */
  floorAt(sx, sy) {
    const F = this.F, s = this.ps, c = this.pc;
    const vx = (sx - this.W / 2) / F, vy = -(sy - this.H / 2) / F;
    const dy = -s + c * vy, dz = c + s * vy;
    if (dy >= -0.01) return null;
    const t = -this.camY / dy;
    const wx = vx * this.yc + dz * this.ys, wz = -vx * this.ys + dz * this.yc;
    return { x: this.cx + wx * t, z: this.cz + wz * t };
  }

  // ---------- input ----------
  toBuf(e) { const r = this.canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) * (this.W / r.width), y: (e.clientY - r.top) * (this.H / r.height) }; }
  hitAt(x, y) { for (const b of this.hits.slice().reverse()) if (x >= b.x0 && x <= b.x1 && y >= b.y0 && y <= b.y1) return b; return null; }
  bindInput() {
    const c = this.canvas;
    let drag = null;
    const S = () => this.S;
    c.addEventListener('wheel', (e) => { e.preventDefault(); this.zoom(e.deltaY > 0 ? 0.6 : -0.6); }, { passive: false });
    // right-click (or a long press on touch screens) someone: their menu
    c.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      if (this.inputLocked || !this.onContext) return;
      const p = this.toBuf(e); const hit = this.hitAt(p.x, p.y);
      if (hit?.uid && !String(hit.uid).startsWith('guest:')) { drag = null; this.dragging = false; this.onContext(hit.uid, e); }
    });
    // double-click a machine (a Berry Blender, a revival machine…) to use it
    c.addEventListener('dblclick', (e) => {
      if (this.inputLocked || this.buildMode || !this.onFeatureOpen) return;
      const p = this.toBuf(e);
      const f = this.machineAt(p.x, p.y);
      if (f) this.onFeatureOpen(f.id, f.bp);
    });
    c.addEventListener('pointermove', (e) => {
      if (this.buildMode && this.ghostBp) { const p = this.toBuf(e); this.ghostAt = this.floorAt(p.x, p.y); return; }
      if (this.buildMode || !this.onFeatureOpen || this.dragging) return;
      const p = this.toBuf(e);
      const f = this.machineAt(p.x, p.y);
      if (f && c.style.cursor !== 'pointer') { c.style.cursor = 'pointer'; c.title = `${f.def.name}: double-click to use`; }
      else if (!f && c.title) { c.style.cursor = 'default'; c.title = ''; }
    });
    c.addEventListener('pointerdown', (e) => {
      if (this.inputLocked || e.button === 2) return;
      const p = this.toBuf(e);
      const hit = this.hitAt(p.x, p.y);
      drag = { sx: e.clientX, sy: e.clientY, last: p, hit, rub: 0, moved: 0, t: performance.now(), hist: [] };
      this.dragging = true;
      c.setPointerCapture?.(e.pointerId);
      if (hit?.uid) { this.selected = hit.uid; this.onSelect(hit.uid); }
      if (hit?.toy) { hit.toy.held = true; hit.toy.carriedBy = null; hit.toy.stuck = null; }
    });
    c.addEventListener('pointermove', (e) => {
      const p = this.toBuf(e);
      if (!drag) {
        if (this.inputLocked) return;
        const hv = this.hitAt(p.x, p.y);
        const id = hv?.uid ?? (hv?.plot != null ? `plot${hv.plot}` : hv?.shop ? 'shop' : hv?.toy ? 'toy' : null);
        if (id !== this.hover) { this.hover = id; c.style.cursor = hv ? 'grab' : 'default'; }
        return;
      }
      const ddx = p.x - drag.last.x, ddy = p.y - drag.last.y;
      drag.moved += Math.abs(ddx) + Math.abs(ddy);
      drag.last = p;
      const toy = drag.hit?.toy;
      if (toy) {
        const fp = this.floorAt(p.x, Math.min(this.H - 1, p.y + 16));
        if (fp) {
          const nx = Math.max(S().x0 - 0.3, Math.min(S().x1 + 0.3, fp.x)), nz = Math.max(S().z0 - 0.5, Math.min(S().z1 + 0.3, fp.z));
          drag.hist.push({ x: nx, z: nz, t: performance.now() }); if (drag.hist.length > 6) drag.hist.shift();
          toy.x = nx; toy.z = nz; toy.y = 0.9; toy.vx = toy.vy = toy.vz = 0;
        }
        c.style.cursor = 'grabbing';
        return;
      }
      const a = drag.hit?.uid && this.actors.get(drag.hit.uid);
      if (a && a.state !== 'held') {
        // rubbing on the creature pets it; pulling it away picks it up
        const b = this.hits.find((h) => h.uid === a.uid);
        const inside = b && p.x >= b.x0 - 2 && p.x <= b.x1 + 2 && p.y >= b.y0 - 2 && p.y <= b.y1 + 2;
        if (inside) { drag.rub += Math.abs(ddx) + Math.abs(ddy); if (drag.rub > 26) { drag.rub = 0; this.onPet(a.uid); } }
        else if (drag.moved > 4) { a.state = 'held'; a.vy = 0; a.sitting = false; a.toy = null; c.style.cursor = 'grabbing'; }
      }
      if (a && a.state === 'held') {
        const fp = this.floorAt(p.x, Math.min(this.H - 1, p.y + 26));
        if (fp) {
          const nx = this.clampX(fp.x), nz = this.clampZ(fp.z);
          drag.hist.push({ x: nx, z: nz, t: performance.now() }); if (drag.hist.length > 6) drag.hist.shift();
          if (nx !== a.x) a.flip = nx < a.x;
          a.x = nx; a.z = nz;
          // the dome is a real bubble: they can't be pulled out of it (or the water would get them)
          if (this.domed(a) && !this.inDome(a.x, a.z)) { const pp = this.domeEdge(a.x, a.z); a.x = pp.x; a.z = pp.z; }
        }
      } else if (!drag.hit || drag.hit.plot != null || drag.hit.shop || drag.hit.feature) {
        // dragging the ground turns the camera around the area (and slides a little)
        const M = S().maxYaw, sl = S().slide;
        this.yawTarget = Math.max(-M, Math.min(M, this.yawTarget + ddx * 0.0022));
        this.camTarget = Math.max(-sl, Math.min(sl, this.camTarget - ddx * 0.012));
      }
    });
    const end = () => {
      if (!drag) return;
      const toy = drag.hit?.toy;
      const fling = (obj, h) => { if (h.length >= 2) { const dt = Math.max(0.016, (h[h.length - 1].t - h[0].t) / 1000); obj.vx = Math.max(-11, Math.min(11, (h[h.length - 1].x - h[0].x) / dt)); obj.vz = Math.max(-11, Math.min(11, (h[h.length - 1].z - h[0].z) / dt)); } };
      if (toy) {
        toy.held = false; toy.vx = toy.vz = 0; fling(toy, drag.hist); toy.vy = 2 + Math.hypot(toy.vx, toy.vz) * 0.25;
        this.notice(toy, 0.7);
      } else {
        const a = drag.hit?.uid && this.actors.get(drag.hit.uid);
        if (a && a.state === 'held') {
          fling(a, drag.hist);
          a.state = 'falling';
          this.onDrop(a.uid, Math.hypot(a.vx, a.vz));
        } else if (this.buildMode && drag.hit?.feature && drag.moved < 6) this.onFeature?.(drag.hit.feature);
        else if (this.buildMode && !drag.hit?.uid && drag.moved < 5) {
          const fp = this.floorAt(drag.last.x, drag.last.y);
          if (fp && this.inBounds(fp.x, fp.z)) {
            const chk = this.ghostBp ? this.placeOk(this.ghostBp, fp.x, fp.z, this.ghostSkip) : { ok: true };
            if (chk.ok) this.onPlace?.(fp); else this.onPlaceBlocked?.(chk.why);
          }
        }
        else if (drag.hit && drag.hit.plot != null && drag.moved < 6) this.onPlot(drag.hit.plot);
        else if (drag.hit?.shop && drag.moved < 6) this.onShop();
        else if (!drag.hit && drag.moved < 4) { this.selected = null; this.onSelect(null); }
      }
      drag = null;
      this.dragging = false;
      c.style.cursor = 'default';
    };
    c.addEventListener('pointerup', end);
    c.addEventListener('pointercancel', end);
    c.addEventListener('lostpointercapture', end);
    window.addEventListener('pointerup', end);
    window.addEventListener('blur', end);
  }

  // ---------- simulation ----------
  pickTarget(a) {
    const S = this.S, air = a.fly || (this.swimAll && !this.domed(a));
    // shelter: out of the rain and snow for those who hate it, and a corner of their own for those who don't belong here
    if (this.shelter && !this.domed(a) && !air && this.wantsShelter(a)) {
      const G = this.shelter, ang = Math.random() * Math.PI * 2, d = Math.random() * G.r * 0.55;
      return { x: G.x + Math.cos(ang) * d, z: G.z + Math.sin(ang) * d * 0.7, shelter: true };
    }
    // friends like to hang around together
    const pal = a.friends?.length && Math.random() < 0.3 ? this.actors.get(a.friends[Math.floor(Math.random() * a.friends.length)]) : null;
    if (pal && pal.appear >= 1) {
      const ang = Math.random() * Math.PI * 2, d = 0.8 + Math.random() * 0.6;
      const x = this.clampX(pal.x + Math.cos(ang) * d), z = this.clampZ(pal.z + Math.sin(ang) * d * 0.6);
      if (this.walkable(x, z, a)) return { x, z, friend: true };
    }
    // somewhere built that it loves: the pond, the sun patch, the slide…
    const liked = this.scene === 'yard' && !this.domed(a) ? this.features.filter((f) => (a.featLikes?.[f.id] ?? 0) > 0.3) : [];
    if (liked.length && Math.random() < 0.3) {
      const f = liked[Math.floor(Math.random() * liked.length)];
      for (let k = 0; k < 6; k++) {
        const wet = f.def.floor === 'water' || f.def.floor === 'spring';
        const ang = Math.random() * Math.PI * 2, d = wet && (a.swim || a.fly) ? Math.random() * f.def.r * 0.6 : f.def.r * (0.6 + Math.random() * 0.5) + 0.2;
        const x = this.clampX(f.x + Math.cos(ang) * d), z = this.clampZ(f.z + Math.sin(ang) * d * 0.75);
        if (this.walkable(x, z, a)) return { x, z, feature: f };
      }
    }
    // a toy stuck up a tree: they'll try (and try) to reach it
    const stuck = this.toys.find((t) => t.stuck);
    if (stuck && !a.tired && !this.domed(a) && Math.random() < (a.temper === 'playful' ? 0.6 : 0.3)) return { reach: stuck };
    // a toy lying about is tempting (playful ones especially)
    const toy = a.tired ? null : this.toys.find((t) => !t.carriedBy && !t.held && !t.stuck && t.kind !== 'berry' && !this.reservedFor(t, a) && (!this.domed(a) || this.inDome(t.x, t.z)));
    if (toy && Math.random() < (a.temper === 'playful' ? 0.35 : a.temper === 'lazy' ? 0.06 : 0.15)) return { toy };
    if (this.domed(a)) return this.randomSpot(Math.random, false, a);
    if (a.swim && !air && Math.random() < (a.prefersWater || a.waterOnly ? 0.95 : 0.6)) { const w = this.waterSpot(); if (w) return w; }
    if (this.scene === 'room') return { x: (Math.random() - 0.5) * (S.x1 - S.x0) * 0.7, z: S.z0 + 0.4 + Math.random() * (S.z1 - S.z0 - 0.8) };
    return this.randomSpot(Math.random, false, a);
  }
  updateActors(dt) {
    const S = this.S;
    for (const a of this.actors.values()) {
      a.ft += dt;
      a.appear = Math.min(1, a.appear + dt * 1.4);
      a.squash = Math.max(0, a.squash - dt * 4);
      if (a.appear < 1) continue;
      a.hop = Math.max(0, a.hop - dt * 2.5);
      // asked to jump / spin / dance (talking)
      if (a.jumpT > 0) { a.jumpT -= dt; if (a.jumpT < 0.45 && a.jumpT + dt >= 0.45) a.hop = 1; }
      if (a.spinT > 0) { a.spinT -= dt; a.flip = Math.floor(a.spinT * 7) % 2 === 0; }
      if (a.danceT > 0) { a.danceT -= dt; if (a.hop < 0.1) a.hop = 0.7; a.flip = Math.floor(a.danceT * 2.5) % 2 === 0; if (Math.random() < dt * 1.5) this.reacts.push({ uid: a.uid, kind: 'note', t: 0, life: 1.2, dx: (Math.random() - 0.5) * 0.8 }); }
      a.blink -= dt; if (a.blink < -0.15) a.blink = 2 + Math.random() * 4;
      if (a.bubble) { a.bubble.t += dt; if (a.bubble.t > a.bubble.life) a.bubble = null; }
      if (a.puppet) {
        // under an activity's control: walk where it's told, otherwise stay put
        a.timer -= dt;
        if (a.goTo) {
          const dx = a.goTo.x - a.x, dz = a.goTo.z - a.z, d = Math.hypot(dx, dz);
          if (d < 0.05) { a.goTo = null; if (a.state === 'walk') a.state = 'idle'; }
          else { const st = Math.min(d, a.goTo.speed * dt); a.x += (dx / d) * st; a.z += (dz / d) * st; a.state = 'walk'; if (Math.abs(dx) > 0.02) a.flip = dx < 0; const mx = dx / d, mz = dz / d; a.away = mx * this.ys + mz * this.yc > Math.abs(mx * this.yc - mz * this.ys) * 1.1; }
        } else if (a.state === 'walk' && !a.running) a.state = 'idle';
        else if ((a.state === 'happy' || a.state === 'eat') && a.timer < 0) a.state = 'idle';
        if (a.fly) a.y += ((a.hoverY ?? 0.6) + Math.sin(a.ft * 1.7) * 0.08 - (a.y || 0)) * Math.min(1, dt * 3);
        continue;
      }
      else if (!a.egg && a.state !== 'held' && a.state !== 'sleep' && Math.random() < dt * 0.03) this.emote(a.uid);
      // napping: they stay put (unless you pick them up), with just the odd Zzz; creatures of dreams dream
      if (a.asleep && a.state !== 'held' && a.state !== 'falling') {
        a.state = 'sleep'; a.goTo = null; a.toy = null; a.vx = 0; a.vz = 0; a.away = false;
        if (a.fly) a.y += (0.15 - (a.y || 0)) * Math.min(1, dt * 2);
        if (Math.random() < dt * 0.25) this.emote(a.uid, a.dreamer && Math.random() < 0.6 ? ['love', 'smile', 'note', 'wow'][Math.floor(Math.random() * 4)] : 'zzz', false);
        continue;
      }
      const air = (a.fly || (this.swimAll && !this.domed(a))) && !a.egg;
      if (a.state === 'held') {
        // let go somewhere we never heard about (outside the window): drop it
        if (!this.dragging) { a.state = 'falling'; a.vx = a.vz = 0; }
        else { a.y += (1.1 + Math.sin(this.time * 9) * 0.06 - a.y) * Math.min(1, dt * 14); continue; }
      }
      if (a.state === 'falling') {
        a.x += a.vx * dt; a.z += a.vz * dt;
        if (a.x < S.x0 || a.x > S.x1) { a.x = this.clampX(a.x); a.vx *= -0.5; }
        if (a.z < S.z0 || a.z > S.z1) { a.z = this.clampZ(a.z); a.vz *= -0.5; }
        if (this.domed(a) && !this.inDome(a.x, a.z)) { const pp = this.domeEdge(a.x, a.z); a.x = pp.x; a.z = pp.z; a.vx *= -0.4; a.vz *= -0.4; }
        if (air) {
          // fliers and swimmers glide back to their cruising height
          const k = Math.pow(0.12, dt); a.vx *= k; a.vz *= k;
          a.vy += (a.hoverY - a.y) * 7 * dt; a.vy *= Math.pow(0.15, dt); a.y += a.vy * dt;
          if (Math.abs(a.y - a.hoverY) < 0.1 && Math.hypot(a.vx, a.vz) < 0.4) { a.state = 'happy'; a.timer = 1; }
          continue;
        }
        a.vy -= 22 * dt; a.y += a.vy * dt;
        if (a.y <= 0) {
          a.y = 0;
          if (Math.abs(a.vy) > 3) { a.vy = -a.vy * 0.35; a.vx *= 0.6; a.vz *= 0.6; a.squash = 1; }
          else { a.vy = 0; a.vx = 0; a.vz = 0; a.state = 'happy'; a.timer = 1.2; a.squash = 1; }
        }
        continue;
      }
      if (air) {
        const target = a.sitting || a.state === 'sleep' ? 0 : a.hoverY + Math.sin(a.ft * 1.7 + a.bobPh) * 0.1;
        a.y += (target - a.y) * Math.min(1, dt * 2.5);
      } else if (a.y > 0.001) { a.state = 'falling'; a.vy = a.vy || 0; continue; }
      a.timer -= dt;
      // after a toy: run to it, then kick it (yard) or carry it back to you (care room)
      if (a.state === 'chase') {
        const t = a.toy && this.toys.includes(a.toy) && !a.toy.carriedBy ? a.toy : null;
        if (!t || t.held) { a.state = 'idle'; a.timer = 0.8; a.toy = null; }
        else {
          a.tx = t.x; a.tz = t.z;
          const reach = 0.42 + t.r + this.heightOf(a) * 0.1;
          if ((t.x - a.x) ** 2 + (t.z - a.z) ** 2 < reach * reach && t.y < Math.max(1.1, (a.y || 0) + this.heightOf(a))) this.reachToy(a, t);
        }
      }
      if (a.state === 'return') {
        a.tx = 0; a.tz = S.z0 + 0.5;
        if ((a.tx - a.x) ** 2 + (a.tz - a.z) ** 2 < 0.12 || a.timer < 0) {
          const t = this.toys.find((x) => x.carriedBy === a.uid);
          a.state = 'happy'; a.timer = 1.5; a.hop = 1; a.flip = false; a.toy = null;
          if (t) {
            t.carriedBy = null;
            if (t.kind === 'berry') { this.toys = this.toys.filter((x) => x !== t); this.onEat?.(a.uid, t.item ?? {}); }
            else { t.x = a.x; t.z = a.z - 0.4; t.y = 0.5; t.vx = (Math.random() - 0.5); t.vz = -0.5; t.vy = 1; this.onPlay?.(a.uid, t.kind, t.item); this.emote(a.uid, 'smile'); }
          }
          continue;
        }
      }
      if (a.state === 'reach') {
        const t = a.toy;
        if (!t || !t.stuck || !this.toys.includes(t)) { a.state = 'idle'; a.timer = 1; a.toy = null; }
        else if ((a.x - a.tx) ** 2 + (a.z - a.tz) ** 2 > 0.1 && a.timer > 6) {
          const dx = a.tx - a.x, dz = a.tz - a.z, d = Math.hypot(dx, dz), step = Math.min(d, a.speed * 1.8 * dt);
          const nx = a.x + (dx / d) * step, nz = a.z + (dz / d) * step;
          a.x = this.clampX(nx); a.z = this.clampZ(nz); if (Math.abs(dx) > 0.05) a.flip = dx < 0;
        } else {
          // under it: jump for it, again and again
          a.away = false;
          a.reachT = (a.reachT ?? 0) - dt;
          if (a.reachT <= 0) {
            a.reachT = 0.55 + Math.random() * 0.4; a.hop = 1; a.tries = (a.tries ?? 0) + 1;
            const tall = this.heightOf(a) + (a.y || 0) + 0.7;
            if (a.fly || tall >= t.y || Math.random() < 0.05) { t.stuck = null; t.vy = -1; t.vx = (Math.random() - 0.5) * 2; this.emote(a.uid, 'wow'); this.onPlay?.(a.uid, t.kind, t.item); a.state = 'chase'; a.timer = 5; continue; }
            if (a.tries === 2) this.emote(a.uid, 'wow', false);
            if (a.tries > 4 + Math.random() * 4) { this.emote(a.uid, 'frown', false); a.state = 'idle'; a.timer = 3 + Math.random() * 4; a.toy = null; }
          }
          if (a.timer < 0) { a.state = 'idle'; a.timer = 2; a.toy = null; }
        }
        continue;
      }
      if (a.state === 'play') {
        a.playT = (a.playT ?? 0) - dt;
        if (a.playT <= 0) { a.playT = 0.4 + Math.random() * 0.3; a.hop = 1; a.flip = Math.random() < 0.5 ? !a.flip : a.flip; }
        if (a.timer < 0) { a.state = 'happy'; a.timer = 1; if (Math.random() < 0.5) this.emote(a.uid, 'smile'); }
        continue;
      }
      if (a.state === 'sulk') { a.away = true; if (a.timer < 0) { a.state = 'idle'; a.away = false; a.timer = 1; } continue; }
      const moving = a.state === 'walk' || a.state === 'chase' || a.state === 'return';
      if (moving && !a.egg) {
        const dx = a.tx - a.x, dz = a.tz - a.z, d = Math.hypot(dx, dz);
        // swimmers are quick in water and slow on land
        const wet = this.matAt(a.x, a.z) === 1;
        const rush = a.state === 'walk' ? 1 : 2.3;
        const sp = rush * a.speed * (air ? 1.15 : a.swim ? (wet ? 1.5 : 0.75) : 1);
        a.wet = wet && !air;
        if (a.state === 'walk' && (d < 0.25 || a.timer < 0)) { a.state = 'idle'; a.timer = 1.5 + Math.random() * 3; if (a.goal && d < 0.6) this.atFeature(a, a.goal); a.goal = null; }
        else if (a.state === 'chase' && a.timer < 0) { a.state = 'idle'; a.timer = 1; a.toy = null; }
        else if (d > 0.02) {
          const step = Math.min(d, sp * dt);
          const nx = a.x + (dx / d) * step, nz = a.z + (dz / d) * step;
          const m2 = this.matAt(nx, nz), keen = a.state !== 'walk' && (m2 !== 1 || a.swim || air) && (m2 !== 2 || air || a.fire);
          if (this.walkable(nx, nz, a) || (keen && !this.domed(a) && !(a.noWater && m2 === 1))) { a.x = this.clampX(nx); a.z = this.clampZ(nz); }
          else if (a.state === 'walk') { a.state = 'idle'; a.timer = 0.4; }
          if (Math.abs(dx) > 0.05) a.flip = dx < 0;
          // which way are they heading, seen from the camera? away from it shows their back
          const mx = dx / d, mz = dz / d;
          const along = mx * this.ys + mz * this.yc, across = mx * this.yc - mz * this.ys;
          a.away = along > Math.abs(across) * 1.1;
        }
      } else if (a.timer < 0) {
        a.away = false;
        if (a.egg) { a.state = 'idle'; a.timer = 3 + Math.random() * 4; if (Math.random() < 0.3) a.hop = 0.5; continue; }
        a.sunbathe = false;
        // napping (from a Nap): they sleep on until they wake by themselves or you wake them
        if (a.asleep) { a.state = 'sleep'; a.timer = 4; if (Math.random() < 0.3) this.emote(a.uid, 'zzz', false); continue; }
        if (a.state === 'sleep' && a.mood === 'sleepy' && Math.random() < 0.6) { a.timer = 6; continue; }
        if (a.mood === 'sleepy' && Math.random() < 0.35) { a.state = 'sleep'; a.timer = 8 + Math.random() * 6; continue; }
        if (this.autonomous(a)) continue;
        // fliers sit down for a rest now and then
        if (air && !a.hover && !a.sitting && Math.random() < 0.18) { a.sitting = true; a.state = 'idle'; a.timer = 6 + Math.random() * 8; continue; }
        if (Math.random() < 0.65) {
          a.sitting = false;
          const at = this.pickTarget(a);
          if (at.toy) { a.state = 'chase'; a.toy = at.toy; a.timer = 6; a.kicks = 0; continue; }
          if (at.reach) { a.state = 'reach'; a.toy = at.reach; a.tx = at.reach.x; a.tz = at.reach.z + 0.2; a.timer = 10; a.tries = 0; continue; }
          a.tx = at.x; a.tz = at.z; a.state = 'walk'; a.timer = 9; a.goal = at.feature ?? null;
          if (this.swimAll) a.hoverY = 0.3 + Math.random() * 2.2;
          else if (a.hover) a.hoverY = 0.16 + Math.random() * 0.12;
          else if (a.fly) a.hoverY = 0.5 + Math.random() * 0.7;
        } else { a.state = 'idle'; a.timer = 1.5 + Math.random() * 3; }
      }
    }
  }
  /**
   * Things they get up to on their own: sulking when upset, sunbathing (sun-lovers, in the day),
   * napping when it's not their time of day, visiting a friend for a chat, a big stretch.
   * Returns true when it picked something.
   */
  autonomous(a) {
    const r = Math.random();
    // can fly but usually walks: now and then it takes off for a little while (and lands again)
    if (a.flight && this.time > a.flight) { a.fly = false; a.flight = 0; a.state = 'falling'; a.vy = 0; return true; }
    if (a.canFly && !a.fly && !this.domed(a) && r < 0.05) { a.fly = true; a.flight = this.time + 6 + Math.random() * 10; a.hoverY = 0.7 + Math.random() * 1.2; a.y = 0.05; return false; }
    const sunny = this.tod === 'day' && !this.L.cave && !this.L.night && !this.L.underwater && !this.swimAll && !this.domed(a);
    if (a.upset && r < 0.55) { a.state = 'sulk'; a.timer = 4 + Math.random() * 5; if (Math.random() < 0.5) this.emote(a.uid, 'angry', false); return true; }
    if (a.sunLover && sunny && r < 0.22) { a.state = 'sleep'; a.sunbathe = true; a.timer = 9 + Math.random() * 8; this.emote(a.uid, 'sun', false); return true; }
    // night owls doze in the day; everyone else at night
    const offHours = a.night ? this.tod === 'day' : this.tod === 'night';
    if (offHours && r < (a.temper === 'lazy' ? 0.45 : 0.28)) { a.state = 'sleep'; a.timer = 8 + Math.random() * 8; if (Math.random() < 0.4) this.emote(a.uid, 'zzz', false); return true; }
    if (a.temper === 'lazy' && r < 0.12) { a.state = 'sleep'; a.timer = 5 + Math.random() * 5; return true; }
    // a friend nearby: go over and have a little chat
    if (a.friends?.length && r < 0.12) {
      const pal = this.actors.get(a.friends[Math.floor(Math.random() * a.friends.length)]);
      if (pal && pal.appear >= 1 && !['sleep', 'held', 'falling'].includes(pal.state) && Math.hypot(pal.x - a.x, pal.z - a.z) < 1.6) {
        a.state = 'happy'; a.timer = 2; a.hop = 0.6; a.flip = pal.x < a.x; pal.flip = a.x < pal.x;
        this.emote(a.uid, 'note', false); setTimeout(() => this.emote(pal.uid, Math.random() < 0.5 ? 'smile' : 'note', false), 600);
        return true;
      }
    }
    if (a.temper === 'shy' && r < 0.1 && this.scene === 'yard') { const at = this.randomSpot(Math.random, true, a); a.tx = at.x; a.tz = at.z; a.state = 'walk'; a.timer = 9; return true; }
    return false;
  }
  updateParticles(dt) {
    for (const p of this.particles) {
      p.life -= dt; p.ph += dt;
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
      if (p.kind === 'firefly' || p.kind === 'pollen' || p.kind === 'dust' || p.kind === 'sparkle' || p.kind === 'wisp') { p.x += Math.sin(p.ph * 1.3) * dt * 0.4; p.y += Math.cos(p.ph) * dt * 0.2; }
      if (p.life < 0 || p.y > 8 || p.y < -0.2 || Math.abs(p.x - this.camX) > 16) Object.assign(p, this.newParticle());
    }
    // in a battle, each creature gives off a few particles of its type now and then (embers rising off a fire
    // type, sparks crackling off an electric one, wisps off a ghost…) instead of the ranch's constant glow
    if (this.scene === 'battle') for (const a of this.actors.values()) {
      if (a.egg || (a.alpha ?? 1) < 0.5) continue;
      const kind = a.fx ?? 'plain', rate = kind === 'ember' ? 1.6 : kind === 'spark' ? 0.9 : kind === 'plain' || kind === 'pebble' || kind === 'star' || kind === 'glint' ? 0 : 0.45;
      if (rate && Math.random() < rate * dt) this.typeWhiff(a, kind);
      if (a.electric && (a._arc ?? 0) <= 0 && Math.random() < 0.35 * dt) a._arc = 0.14 + Math.random() * 0.1; // a crackle of electricity over it
      if (a._arc > 0) a._arc -= dt;
    }
    for (const s of this.sparks) {
      s.life -= dt; s.ph += dt;
      if (s.g) s.vy -= s.g * dt;
      if (s.kind === 'leaf' || s.kind === 'flake') s.vx = Math.sin(s.ph * 3) * 0.6;
      if (s.kind === 'spark' || s.kind === 'star') { s.vx *= Math.pow(0.05, dt); s.vy *= Math.pow(0.05, dt); }
      s.x += s.vx * dt; s.y += s.vy * dt; s.z += s.vz * dt;
      if (s.y < 0) { s.y = 0; s.vy = 0; s.vx *= 0.5; }
    }
    this.sparks = this.sparks.filter((s) => s.life > 0);
  }

  // ---------- drawing ----------
  drawBackdrop(ctx) {
    const { W, yBack } = this;
    const L = this.L, S = this.S;
    const lean = Math.abs(this.backTilt ?? 0) * W * 0.6;
    if (this.sky) {
      const img = this.sky;
      const off = ((-(this.camX * 2 + this.yaw * 260)) % img.width + img.width) % img.width;
      const sc = (yBack + 4) / img.height;
      const w = img.width * sc;
      for (let x = -off * sc; x < W; x += w) ctx.drawImage(img, x, 0, w, yBack + 4 + lean);
    } else {
      const g = ctx.createLinearGradient(0, 0, 0, yBack);
      g.addColorStop(0, L.sky[0]); g.addColorStop(1, L.sky[1]);
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, yBack + 4 + lean);
      if (L.sun && this.light !== 'night') {
        const sx = W * (0.25 + ((L.sun[0] * 0.13) % 0.5)) - this.camX * 1.2 - this.yaw * this.F * 0.3, sy = yBack * 0.36, rr = 34;
        const glow = ctx.createRadialGradient(sx, sy, rr * 0.6, sx, sy, rr * 4);
        glow.addColorStop(0, `rgba(${hexRgb(L.sun[2]).join(',')},0.55)`); glow.addColorStop(1, `rgba(${hexRgb(L.sun[2]).join(',')},0)`);
        ctx.fillStyle = glow; ctx.fillRect(sx - rr * 4, sy - rr * 4, rr * 8, rr * 8);
        for (let y = -rr; y <= rr; y++) {
          const half = Math.sqrt(rr * rr - y * y);
          const t = (y + rr) / (2 * rr);
          ctx.fillStyle = `rgb(${mixRgb(hexRgb(L.sun[2]), hexRgb(L.sun[3]), t * 0.8).map((v) => v | 0).join(',')})`;
          ctx.fillRect(Math.round(sx - half), Math.round(sy + y), Math.round(half * 2), 1);
        }
      }
      if (L.moon || (this.light === 'night' && !L.cave && !L.underwater)) {
        const mx = W * 0.72 - this.camX * 1.2 - this.yaw * this.F * 0.3, my = yBack * 0.3, mr = 22;
        ctx.fillStyle = 'rgba(230,240,255,.12)'; ctx.beginPath(); ctx.arc(mx, my, mr * 2.4, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#eef3ff'; ctx.beginPath(); ctx.arc(mx, my, mr, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#c9d2ea'; for (const [ox, oy, rad] of [[-7, -5, 4], [6, 4, 5], [-2, 9, 3]]) { ctx.beginPath(); ctx.arc(mx + ox, my + oy, rad, 0, Math.PI * 2); ctx.fill(); }
      }
      if (L.night || L.cave || L.nebula || L.underwater || this.light === 'night') {
        for (let i = 0; i < 160; i++) {
          const x = ((hash2(i, 3) * W * 2 - this.camX * 0.8 - this.yaw * this.F * 0.3) % W + W) % W, y = hash2(i, 9) * yBack * 0.9;
          if (L.underwater) { if (i % 4) continue; ctx.fillStyle = 'rgba(160,220,255,.10)'; ctx.fillRect(Math.round(x), 0, 12, yBack); continue; }
          if (Math.sin(this.time * 2 + i) > -0.3) { ctx.fillStyle = i % 7 ? '#ffffff' : '#c89bff'; const sz = i % 11 === 0 ? 2 : 1; ctx.fillRect(Math.round(x), Math.round(y), sz, sz); }
        }
      }
      for (const cl of this.clouds ?? []) {
        const span = W + cl.img.width * 2;
        const x = (((cl.x * span + this.time * cl.v - this.camX * 4 - this.yaw * this.F * 0.3) % span) + span) % span - cl.img.width;
        ctx.drawImage(cl.img, Math.round(x), Math.round(cl.y * yBack));
      }
    }
    // three parallax strips, far to near, sitting where the land fades out
    const pxPerUnit = this.F / (S.floorEnd - S.camZ);
    const cliff = this.floorEnd < S.floorEnd - 8;
    const turn = this.yaw * this.F * 0.92; // turning slides the scenery like looking around
    ctx.save();
    ctx.translate(W / 2, this.backY ?? yBack);
    ctx.rotate(this.backTilt ?? 0);
    ctx.translate(-W / 2, -yBack);
    for (const ly of this.layers) {
      if ((cliff || this.skyMode) && ly === this.layers[2]) continue; // nothing close by past a cliff edge
      if (this.skyMode && ly === this.layers[1]) continue; // above the clouds: only far peaks
      const img = ly.img;
      const off = ((((this.camX * pxPerUnit * 3 + turn) * ly.f) % img.width) + img.width) % img.width;
      const top = yBack + 3 - img.height;
      for (let x = -off - img.width; x < W + img.width; x += img.width) ctx.drawImage(img, Math.round(x), top);
      // fill under the strip so a leaning edge never shows a gap
      if (ly.base) { ctx.fillStyle = ly.base; ctx.fillRect(-W * 0.2, yBack + 2, W * 1.4, 40); }
    }
    ctx.restore();
  }

  renderFloor() {
    const { W, H, buf, F } = this;
    const S = this.S;
    // the floor only needs redrawing when the camera moves, or now and then for water and lava
    this.floorTick = (this.floorTick ?? 0) + 1;
    const key = `${this.camY.toFixed(3)}:${this.camX.toFixed(3)}:${this.yaw.toFixed(4)}:${this.dist.toFixed(4)}:${this.pitch.toFixed(4)}:${this.camZ.toFixed(3)}:${W}`;
    if (key === this.floorKey && !(this.floorAnimated && this.floorTick % 3 === 0)) { this.ctx.drawImage(this.floorCanvas, 0, 0); return; }
    this.floorKey = key;
    buf.fill(0);
    const s = this.ps, c = this.pc, t = this.time;
    const { col, mat, TXW, TXH } = this.floor;
    const { X0, Z0, TEX } = S, floorEnd = this.floorEnd;
    const [wr, wg, wb] = this.c.water;
    const LAVA = [P('#ffe27a'), P('#ff8a3d'), P('#e5482d')], ICE = [P('#ffffff'), P('#bfe4fb')];
    const L = this.L, sk = this.c.sky1, gc = this.c.grid;
    const ys = this.ys, yc = this.yc, cx = this.cx, cz = this.cz, camY = this.camY;
    const tilt = Math.abs(this.backTilt ?? 0) * W * 0.6 + 6;
    const fogFrom = S.back + 1, fogSpan = Math.max(6, S.floorEnd - fogFrom);
    const open = !!this.openFloor;
    const cliffEdge = !open && floorEnd < S.floorEnd - 8, edgeLit = P(this.L.cliff[0]), edgeDark = P(this.L.cliff[2] ?? this.L.cliff[0]);
    for (let sy = Math.max(0, Math.floor(this.yBack - tilt)); sy < H; sy++) {
      const vy = -(sy - H / 2) / F;
      const dy = -s + c * vy, dzc = c + s * vy;
      if (dy >= -0.001) continue;
      const tt = -camY / dy;
      // along a screen row the floor point moves in a straight line (turned by the camera's yaw)
      const vx0 = (-W / 2) / F, dvx = 1 / F;
      let x = cx + tt * (vx0 * yc + dzc * ys), z = cz + tt * (-vx0 * ys + dzc * yc);
      const sxStep = tt * dvx * yc, szStep = -tt * dvx * ys;
      const zMid = cz + tt * dzc * yc;
      // the land fades into the haze before it meets the painted distance
      const fog = open ? Math.max(0, Math.min(0.62, ((tt * dzc - 12) / 20) * 0.7)) : Math.max(0, Math.min(0.62, ((zMid - fogFrom) / fogSpan) * 0.7));
      for (let sx = 0; sx < W; sx++, x += sxStep, z += szStep) {
        if (!open && z > floorEnd) continue;
        if (cliffEdge && z > floorEnd - 0.35) { buf[sy * W + sx] = z > floorEnd - 0.12 ? edgeDark : edgeLit; continue; }
        let tz = Math.floor((z - Z0) * TEX);
        if (tz < 0 || tz >= TXH) { if (!open) continue; tz = ((tz % TXH) + TXH) % TXH; }
        let tx = Math.floor((x - X0) * TEX);
        if (tx < 0 || tx >= TXW) tx = ((tx % TXW) + TXW) % TXW; // the land goes on: wrap it round
        const i = tz * TXW + tx;
        const m = mat[i];
        let out = col[i];
        if (m === 1) { const wave = Math.sin(x * 2.1 + t * 1.6) + Math.sin(z * 2.7 - t * 1.2); const k = wave > 1.4 ? 0.45 : wave > 0.9 ? 0.18 : 0; out = pack(wr + (255 - wr) * k, wg + (255 - wg) * k, wb + (255 - wb) * k); }
        else if (m === 2) { const fl = Math.sin(x * 3 + t * 2) * Math.sin(z * 2.3 - t * 1.4); out = fl > 0.45 ? LAVA[0] : fl > -0.2 ? LAVA[1] : LAVA[2]; }
        else if (m === 3) { const g = 0.55 + 0.45 * Math.sin(t * 2 + x + z); out = pack(gc[0] * g + 40, gc[1] * g + 20, gc[2] * g + 40); }
        else if (m === 4) out = (tx + tz + ((t * 6) | 0)) % 23 === 0 ? ICE[0] : ICE[1];
        else if (m === 5) { const wave = Math.sin(x * 2.4 + t * 1.2) + Math.sin(z * 2.9 - t); const k = wave > 1.3 ? 0.4 : 0.12; out = pack(110 + 145 * k, 200 + 55 * k, 205 + 50 * k); }
        if (L.caustics && !m) { const cst = Math.sin(x * 3.1 + t) + Math.sin(z * 2.6 - t * 0.8) + Math.sin((x + z) * 1.7 + t * 1.3); if (cst > 2.1) out = pack((out & 255) + 40, ((out >> 8) & 255) + 40, ((out >> 16) & 255) + 40); }
        if (fog > 0) out = pack((out & 255) + (sk[0] - (out & 255)) * fog, ((out >> 8) & 255) + (sk[1] - ((out >> 8) & 255)) * fog, ((out >> 16) & 255) + (sk[2] - ((out >> 16) & 255)) * fog);
        buf[sy * W + sx] = out;
      }
    }
    this.fctx.putImageData(this.img, 0, 0);
    this.ctx.drawImage(this.floorCanvas, 0, 0);
  }

  frame(dt) {
    const S = this.S;
    this.time += dt;
    if (this.autoReflect) { const f = reflectFor(this.biome, { wet: this.weather === 'rain' || this.weather === 'storm', icy: this.biome === 'tundra' || this.weather === 'snow' }); this.reflect = f.reflect; this.reflectWater = f.water; }
    // following someone: the camera keeps them in view (in cinematic mode too, drifting gently round them)
    const fol = this.followUid && this.actors.get(this.followUid);
    if (this.followUid && !fol) this.followUid = null;
    if (fol && fol.state !== 'held') {
      const t = this.time * 0.05;
      this.camTarget = fol.x;
      this.camZTarget = fol.z + 1.2 - this.S.pivotZ;
      this.distTarget = this.cinematic ? 0.78 + Math.sin(t * 0.5) * 0.12 : 0.72;
      this.yawTarget = this.cinematic ? Math.sin(t) * S.maxYaw * 0.5 : this.yawTarget;
      this.pitchTarget = 0.38;
    } else if (this.cinematic) {
      const t = this.time * 0.05;
      this.yawTarget = Math.sin(t) * S.maxYaw * 0.8;
      this.camTarget = Math.sin(t * 0.7 + 1) * S.slide * 0.8;
      this.distTarget = 1.05 + Math.sin(t * 0.5) * 0.25;
    }
    this.camX += (this.camTarget - this.camX) * Math.min(1, dt * 4);
    // turn the short way round (a target that wraps from +180° to -180° must not spin the camera all the way back)
    let dYaw = this.yawTarget - this.yaw;
    while (dYaw > Math.PI) dYaw -= 2 * Math.PI;
    while (dYaw < -Math.PI) dYaw += 2 * Math.PI;
    this.yaw += dYaw * Math.min(1, dt * 5);
    if (this.yaw > Math.PI) this.yaw -= 2 * Math.PI; else if (this.yaw < -Math.PI) this.yaw += 2 * Math.PI;
    this.dist += (this.distTarget - this.dist) * Math.min(1, dt * 6);
    this.pitch += (this.pitchTarget - this.pitch) * Math.min(1, dt * 4);
    this.camZ += (this.camZTarget - this.camZ) * Math.min(1, dt * 4);
    if (Math.abs(this.pitchTarget - this.pitch) < 1e-4) this.pitch = this.pitchTarget;
    if (Math.abs(this.camZTarget - this.camZ) < 1e-4) this.camZ = this.camZTarget;
    if (Math.abs(dYaw) < 1e-4) this.yaw = this.yawTarget;
    if (Math.abs(this.distTarget - this.dist) < 1e-4) this.dist = this.distTarget;
    if (Math.abs(this.camTarget - this.camX) < 1e-4) this.camX = this.camTarget;
    this.updateCamera();
    // the far edge leans a little when the camera turns; the scenery leans with it
    {
      const l = this.project(this.camX - 16, 0, this.floorEnd), r = this.project(this.camX + 16, 0, this.floorEnd);
      const m = this.project(this.camX, 0, this.floorEnd);
      this.backTilt = l && r && !this.openFloor ? Math.atan2(r.y - l.y, r.x - l.x) : 0;
      this.backY = m && !this.openFloor ? m.y + (this.W / 2 - m.x) * Math.tan(this.backTilt) : this.yBack;
    }
    this.warp = Math.max(0, this.warp - dt * 1.2);
    this.updateActors(dt);
    this.updateToys(dt);
    this.updateParticles(dt);
    const ctx = this.ctx;
    ctx.imageSmoothingEnabled = false;
    this.drawBackdrop(ctx);
    this.renderFloor();
    // this frame's lights (lamps, fires, glowing things, moves…): pools on the ground first
    try { this.sun = sunOf(this); this.lit = this.lighting === false ? [] : gatherLights(this); drawFloorLights(ctx, this); if (this.shadows !== false) drawGroundShadows(ctx, this); } catch (e) { this.lit = []; if (!this._litErr) { this._litErr = true; console.warn('lighting', e); } }
    const items = [];
    const add = (x, y, z, draw) => { const q = this.project(x, y, z); if (q && q.x > -260 && q.x < this.W + 260) items.push({ z: q.z, q, draw }); };
    // fences: along the back, and down both sides
    if (this.fenceImg) {
      const f = this.fenceImg, seg = 1.6, shimmer = this.scene === 'yard';
      const FM = this.fenceMesh, sky = this.c.sky1;
      for (let x = -S.side + seg / 2; x < S.side; x += seg) add(x, 0, S.back, (q) => (FM?.x ? drawMesh(ctx, this, FM.x, x, S.back, { sky }) : this.drawBill(ctx, f, q, (seg * q.k) / f.width, shimmer)));
      for (const sx of [-S.side, S.side]) for (let z = S.z0 - 1.2; z < S.back; z += 1.1) add(sx, 0, z, (q) => (FM?.z ? drawMesh(ctx, this, FM.z, sx, z + 0.55, { sky }) : this.drawBill(ctx, f, q, (1.3 * q.k) / f.width, shimmer)));
    }
    for (const p of this.props) {
      const y = p.float ? p.y + Math.sin(this.time + p.bob) * 0.15 : (p.lift ?? 0);
      // a big model can be sorted by another point (a stand by its back, so its crowd is drawn over it)
      if (p.mesh && p.sz != null) { const q = this.project(p.sx ?? p.x, 0, p.sz); if (q) items.push({ z: q.z, q, draw: () => this.drawProp(ctx, p, q) }); continue; }
      add(p.x, y, p.z, (q) => (p.block ? this.drawBlock(ctx, p) : this.drawProp(ctx, p, q)));
    }
    if (this.scene === 'farm') this.plots.forEach((pl, i) => {
      const spot = (S.plots ?? PLOTS)[i];
      if (!spot) return;
      const [px, pz] = spot;
      const imgs = this.plotImgs?.[i];
      [-1.05, 0, 1.05].forEach((dx, k) => {
        // sorted as if at the planter's front edge, so the planter is drawn first and the plants on top
        add(px + dx, 0, pz - 1.1 - k * 0.001, (q0) => {
          const q = this.project(px + dx, 0, pz + 0.05 + (k % 2) * 0.25) ?? q0;
          if (k === 1) this.hits.push({ plot: i, x0: q.x - 1.7 * q.k, x1: q.x + 1.7 * q.k, y0: q.y - 1.5 * q.k, y1: q.y + 1.2 * q.k });
          const img = imgs?.[k];
          // plants grow out of the planter's dirt (0.3 up), and stand taller than they used to
          const qs = this.project(px + dx, 0.3, pz + 0.05 + (k % 2) * 0.25) ?? q;
          if (img) { const hh = (img.height / 64) * 1.35 * qs.k, ww = (img.width / img.height) * hh; ctx.drawImage(img, Math.round(qs.x - ww / 2), Math.round(qs.y - hh), Math.round(ww), Math.round(hh)); }
          if (k === 1 && pl?.ready && Math.sin(this.time * 4) > 0) { ctx.fillStyle = '#ffffff'; const s = Math.max(2, Math.round(q.k * 0.06)); ctx.fillRect(Math.round(q.x + q.k * 0.4), Math.round(q.y - q.k * 0.9), s, s * 3); ctx.fillRect(Math.round(q.x + q.k * 0.4 - s), Math.round(q.y - q.k * 0.9 + s), s * 3, s); }
          if (k === 1 && pl?.ready) this.label(ctx, 'Ready to pick', q.x, q.y - 1.6 * q.k, '#ffffff');
          else if (k === 1 && this.hover === `plot${i}`) this.label(ctx, pl?.empty ? 'Plant here' : `${Math.round((pl?.frac ?? 0) * 100)}% grown`, q.x, q.y - 1.4 * q.k);
        });
      });
    });
    for (const a of this.actors.values()) add(a.x, 0, a.z, (q) => this.drawActor(ctx, a, q));
    // the little things on the ground: only the near ones (far off they're too small to see)
    if (this.scatter?.length) { const cx = this.cx, cz = this.cz; for (const g of this.scatter) { const dx = g.x - cx, dz = g.z - cz; if (dx * dx + dz * dz < 900) add(g.x, 0, g.z, (q) => drawScatter(ctx, this, g, q)); } }
    // things an activity draws itself, sorted in with everything else (so whoever stands in front is in front)
    for (const e of this.extras ?? []) add(e.x, e.y ?? 0, e.z, (q) => e.draw(ctx, q));
    // 3D shells: the far half is drawn behind whoever is inside, the near half over them (whichever way the camera turns)
    const far = (x, z, r, rz) => [[x + this.ys * r, z + this.yc * rz], [x - this.ys * r, z - this.yc * rz]];
    if (this.dome) { const D = this.dome; const [bk, fr] = far(D.x, D.z, D.r, D.r / 1.3); add(bk[0], 0, bk[1], () => this.drawDome(ctx, 'back')); add(fr[0], 0, fr[1], () => this.drawDome(ctx, 'front')); }
    if (this.shelter) { const G = this.shelter; const [bk, fr] = far(G.x, G.z, G.r, G.r * 0.8); add(bk[0], 0, bk[1], () => this.drawShelter(ctx, 'back')); add(fr[0], 0, fr[1], () => this.drawShelter(ctx, 'front')); }
    if (this.scene === 'yard' || this.roomFeatures) for (const f of this.features) {
      if (f.bp === 'hot-spring' && Math.random() < dt * 5) this.sparks.push({ kind: 'gust', x: f.x + (Math.random() - 0.5) * f.def.r, y: 0.2, z: f.z + (Math.random() - 0.5) * f.def.r * 0.6, vx: 0, vy: 0.5, vz: 0, life: 1.4, ph: 0, c: 0 });
      if (f.bp === 'fountain' && Math.random() < dt * 6) this.sparks.push({ kind: 'drop', x: f.x + (Math.random() - 0.5) * 0.4, y: 1.4, z: f.z - 0.1, vx: (Math.random() - 0.5) * 1.4, vy: 1.4, vz: 0, g: 6, life: 0.8, ph: 0, c: Math.random() < 0.5 ? 0 : 1 });
      if (this.buildMode) add(f.x, 0, f.z + 0.01, () => this.drawFeatureMark(ctx, f));
    }
    // build mode: what you're placing follows the pointer, red where it can't go and green where it can
    if (this.buildMode && this.ghostBp && this.ghostAt) { const gh = this.ghostAt; add(gh.x, 0, gh.z - 0.02, () => this.drawGhost(ctx)); }
    for (const t of this.toys) add(t.x, 0, t.z - 0.01, (q) => this.drawToy(ctx, t, q));
    for (const p of this.particles) add(p.x, p.y, p.z, (q) => this.drawParticle(ctx, p, q));
    for (const s of this.sparks) add(s.x, s.y, s.z - 0.02, (q) => this.drawSpark(ctx, s, q));
    items.sort((a, b) => b.z - a.z);
    this.hits = [];
    this.lamps = [];
    for (const it of items) it.draw(it.q);
    this.drawLight(ctx);
    // weather on top of the light, so rain and snow still show at night
    this.drawWeather(ctx, dt);
    // bubbles go on top of everything
    for (const a of this.actors.values()) if (a.bubble && a.appear >= 1) this.drawBubble(ctx, a);
    this.drawReactions(ctx, dt);
    const tag = this.actors.get(this.hover) ?? this.actors.get(this.selected);
    if (tag?.name) { const b = this.hits.find((h) => h.uid === tag.uid); if (b) this.label(ctx, tag.name, (b.x0 + b.x1) / 2, b.y0 - (tag.bubble ? 40 : 12)); }
    if (this.hover === 'shop') { const b = this.hits.find((h) => h.shop); if (b) this.label(ctx, 'Open the shop', (b.x0 + b.x1) / 2, b.y0 - 10); }
    if (this.swimAll) {
      // underwater: a soft blue wash with drifting light
      ctx.fillStyle = 'rgba(60,165,235,.16)'; ctx.fillRect(0, 0, this.W, this.H);
      ctx.fillStyle = 'rgba(200,240,255,.05)';
      for (let i = 0; i < 6; i++) { const x = ((i * 233 + this.time * 14) % (this.W + 200)) - 100; ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x + 40, 0); ctx.lineTo(x + 140, this.H); ctx.lineTo(x + 70, this.H); ctx.fill(); }
    }
    this.overlay?.(ctx, this);
    if (this.warp > 0) {
      ctx.fillStyle = `rgba(200,255,240,${(this.warp * 0.5).toFixed(3)})`;
      ctx.fillRect(0, 0, this.W, this.H);
      ctx.fillStyle = `rgba(125,255,207,${(this.warp * 0.5).toFixed(3)})`;
      for (let y = (this.time * 300) % 6; y < this.H; y += 6) ctx.fillRect(0, Math.round(y), this.W, 1);
    }
  }

  /**
   * Weather in the yard: 'clear' | 'cloudy' | 'rain' | 'storm' | 'snow' | 'fog' | 'windy', or 'sim' (it changes
   * through the day, the way that kind of place tends to: deserts are mostly clear, tundras snow, marshes
   * are rainy and misty). Caves, the seafloor and the abstract places have no weather.
   */
  setWeather(kind = 'sim') {
    this.weatherMode = kind;
    // 'real': the weather where you are (fog when you can't see far), else simulated
    this.weather = kind === 'real' ? yardWeather() ?? simWeather(this.biome) : kind === 'sim' ? simWeather(this.biome) : kind;
    if (NO_WEATHER.has(this.biome)) this.weather = 'clear';
    if (this.weather === 'snow' && ['volcano', 'desert'].includes(this.biome)) this.weather = 'cloudy';
    this.wx = this.wx ?? { drops: [], flakes: [], flash: 0, nextFlash: 4, leaves: [] };
    return this.weather;
  }
  drawWeather(ctx, dt) {
    if ((this.weatherMode === 'sim' || this.weatherMode === 'real') && (this._wxCheck = (this._wxCheck ?? 0) + 1) % 900 === 0) this.setWeather(this.weatherMode);
    const w = this.weather;
    if (!w || w === 'clear') return;
    const W = this.W, H = this.H, X = this.wx;
    ctx.save();
    // the light: grey skies dim everything a little
    const dim = { cloudy: 0.12, rain: 0.2, storm: 0.32, snow: 0.08, fog: 0.05, windy: 0.04 }[w] ?? 0;
    if (dim) { ctx.fillStyle = `rgba(40,48,70,${dim})`; ctx.fillRect(0, 0, W, H); }
    if (w === 'cloudy' || w === 'rain' || w === 'storm') {
      // cloud shadows drifting over the ground
      ctx.fillStyle = 'rgba(20,24,40,.10)';
      for (let i = 0; i < 4; i++) { const x = ((i * 377 + this.time * 18) % (W + 400)) - 200, y = this.yBack + 40 + ((i * 97) % Math.max(40, H - this.yBack - 60)); ctx.beginPath(); ctx.ellipse(x, y, 180, 40, 0, 0, Math.PI * 2); ctx.fill(); }
    }
    if (w === 'rain' || w === 'storm') {
      const n = w === 'storm' ? 260 : 150, wind = w === 'storm' ? 3.5 : 1.2;
      while (X.drops.length < n) X.drops.push({ x: Math.random() * W, y: Math.random() * H, v: 600 + Math.random() * 300, l: 8 + Math.random() * 10 });
      ctx.strokeStyle = this.light === 'night' ? 'rgba(190,210,255,.55)' : 'rgba(210,225,255,.7)'; ctx.lineWidth = 1.4; ctx.beginPath();
      for (const d of X.drops) {
        d.y += d.v * dt; d.x += d.v * dt * wind * 0.1;
        if (d.y > H || d.x > W) { d.y = -10 - Math.random() * 40; d.x = Math.random() * (W + 100) - 100; }
        ctx.moveTo(d.x, d.y); ctx.lineTo(d.x - d.l * wind * 0.1, d.y - d.l);
      }
      ctx.stroke();
      // splashes on the ground
      if (Math.random() < dt * 30) { const fp = this.floorAt(Math.random() * W, this.yBack + 20 + Math.random() * (H - this.yBack - 20)); if (fp) this.sparks.push({ kind: 'drop', x: fp.x, y: 0.05, z: fp.z, vx: (Math.random() - 0.5) * 0.6, vy: 0.8, vz: 0, g: 6, life: 0.3, ph: 0, c: 1 }); }
      if (w === 'storm') {
        X.nextFlash -= dt;
        if (X.nextFlash <= 0) { X.flash = 1; X.nextFlash = 5 + Math.random() * 9; this.onThunder?.(); }
        if (X.flash > 0) { ctx.fillStyle = `rgba(235,240,255,${(X.flash * 0.55).toFixed(3)})`; ctx.fillRect(0, 0, W, H); X.flash = Math.max(0, X.flash - dt * 3); }
      }
    } else if (w === 'snow') {
      while (X.flakes.length < 220) X.flakes.push({ x: Math.random() * W, y: Math.random() * H, v: 30 + Math.random() * 50, s: 1 + Math.random() * 2.5, ph: Math.random() * 6 });
      ctx.fillStyle = 'rgba(255,255,255,.9)';
      for (const f of X.flakes) {
        f.y += f.v * dt; f.x += Math.sin(this.time * 1.3 + f.ph) * 12 * dt;
        if (f.y > H) { f.y = -4; f.x = Math.random() * W; }
        ctx.fillRect(Math.round(f.x), Math.round(f.y), Math.ceil(f.s) + 1, Math.ceil(f.s) + 1);
      }
    } else if (w === 'fog') {
      const g = ctx.createLinearGradient(0, Math.max(0, this.yBack - 60), 0, H);
      g.addColorStop(0, 'rgba(230,236,244,.75)'); g.addColorStop(0.45, 'rgba(230,236,244,.35)'); g.addColorStop(1, 'rgba(230,236,244,.08)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = 'rgba(255,255,255,.06)';
      for (let i = 0; i < 5; i++) { const x = ((i * 311 + this.time * 10) % (W + 500)) - 250; ctx.beginPath(); ctx.ellipse(x, this.yBack + 30 + i * 40, 260, 30, 0, 0, Math.PI * 2); ctx.fill(); }
    }
    if (w === 'windy' || w === 'storm') {
      while (X.leaves.length < 18) X.leaves.push({ x: Math.random() * W, y: Math.random() * H, v: 160 + Math.random() * 160, ph: Math.random() * 6 });
      const col = FLOOR_STYLE[this.biome] === 'sand' ? 'rgba(230,200,140,.7)' : FLOOR_STYLE[this.biome] === 'snow' ? 'rgba(255,255,255,.8)' : 'rgba(110,170,70,.85)';
      ctx.fillStyle = col;
      for (const l of X.leaves) {
        l.x += l.v * dt; l.y += Math.sin(this.time * 3 + l.ph) * 30 * dt + 10 * dt;
        if (l.x > W + 10) { l.x = -10; l.y = Math.random() * H; }
        ctx.fillRect(Math.round(l.x), Math.round(l.y), 4, 2); ctx.fillRect(Math.round(l.x) + 1, Math.round(l.y) - 1, 2, 1);
      }
      ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 1;
      for (let i = 0; i < 6; i++) { const x = ((i * 211 + this.time * 220) % (W + 300)) - 150, y = 60 + ((i * 131) % (H - 120)); ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 60, y - 8, x + 120, y); ctx.stroke(); }
    }
    ctx.restore();
  }

  /**
   * Time of day in the yard: 'day' | 'dawn' | 'dusk' | 'night' (or 'local': follow this computer's clock).
   * Night darkens everything, lamps and glowing things light up, the moon and stars come out.
   */
  setTime(kind = 'local') {
    this.timeMode = kind;
    const tod = kind === 'local' ? localTod() : kind;
    if (tod === this.light) return;
    this.light = tod; this.tod = tod === 'dawn' ? 'dawn' : tod;
    this.floorKey = null;
  }
  drawLight(ctx) {
    if (this.timeMode === 'local' && (this._todCheck = (this._todCheck ?? 0) + 1) % 600 === 0) this.setTime('local');
    const t = this.light ?? 'day';
    const W = this.W, H = this.H;
    const dark = t === 'night' ? 1 : t === 'dusk' ? 0.6 : t === 'dawn' ? 0.45 : this.L.cave || this.L.night ? 0.8 : 0.28;
    ctx.save();
    if (t !== 'day' && !this.L.cave) {
      ctx.globalCompositeOperation = 'multiply';
      if (t === 'night') { const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, 'rgb(58,70,140)'); g.addColorStop(1, 'rgb(70,78,130)'); ctx.fillStyle = g; }
      else if (t === 'dusk') { const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, 'rgb(255,150,120)'); g.addColorStop(1, 'rgb(210,170,190)'); ctx.fillStyle = g; }
      else { const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, 'rgb(255,200,210)'); g.addColorStop(1, 'rgb(235,220,235)'); ctx.fillStyle = g; }
      ctx.fillRect(0, 0, W, H);
    }
    ctx.globalCompositeOperation = 'lighter';
    try { drawLightGlows(ctx, this); } catch { /* no glows */ }
    ctx.globalCompositeOperation = 'lighter';
    const tm = this.time;
    // places that give off their own light: lava, and the neon grid
    const yb = Math.max(0, this.yBack ?? 0);
    if (this.biome === 'volcano') {
      const fl = 0.75 + 0.15 * Math.sin(tm * 1.7) + 0.1 * Math.sin(tm * 4.3);
      const g = ctx.createLinearGradient(0, yb, 0, H); g.addColorStop(0, `rgba(255,90,30,${0.05 * fl})`); g.addColorStop(1, `rgba(255,110,40,${(0.12 + 0.14 * dark) * fl})`);
      ctx.fillStyle = g; ctx.fillRect(0, yb, W, H - yb);
    } else if (this.biome === 'synth') {
      const fl = 0.8 + 0.2 * Math.sin(tm * 2.2);
      const g = ctx.createLinearGradient(0, yb, 0, H); g.addColorStop(0, `rgba(255,60,200,${0.1 * fl})`); g.addColorStop(1, `rgba(80,200,255,${(0.08 + 0.12 * dark) * fl})`);
      ctx.fillStyle = g; ctx.fillRect(0, yb, W, H - yb);
    }
    if (t === 'night' || t === 'dusk') {
      const k = t === 'night' ? 1 : 0.45;
      for (const l of this.lamps ?? []) {
        const g = ctx.createRadialGradient(l.x, l.y, 0, l.x, l.y, l.r * 2.2);
        g.addColorStop(0, l.warm ? `rgba(255,200,120,${0.45 * k})` : `rgba(120,255,220,${0.4 * k})`); g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g; ctx.fillRect(l.x - l.r * 2.2, l.y - l.r * 2.2, l.r * 4.4, l.r * 4.4);
      }
    }
    // fire creatures give off a soft, flickering warm light; electric ones a dim, harsh, crackling one
    for (const a of this.actors.values()) {
      if (!a.fire && !a.electric) continue;
      const b = this.hits.find((x) => x.uid === a.uid); if (!b) continue;
      const cx = (b.x0 + b.x1) / 2, cy = (b.y0 + b.y1) / 2, r = Math.max(14, (b.y1 - b.y0) * 1.1);
      let alpha, col;
      const inBattle = this.scene === 'battle';
      if (a.fire) {
        const ph = (a.uid?.length ?? 1) * 1.3;
        const fl = inBattle ? 0.9 + 0.1 * Math.sin(tm * 2.2 + ph) : 0.78 + 0.12 * Math.sin(tm * 6 + ph) + 0.1 * Math.sin(tm * 13.7 + ph * 2);
        alpha = (0.14 + 0.24 * dark) * fl * (inBattle ? 0.3 : 1); col = '255,140,60';
      } else if (inBattle) {
        // electricity in battle: a crackle of bright, jagged arcs over it now and then, never a glow
        if ((a._arc ?? 0) > 0) {
          const w = b.x1 - b.x0, hh = b.y1 - b.y0;
          ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
          for (let k = 0; k < 2; k++) {
            const sx = b.x0 + Math.random() * w, sy = b.y0 + Math.random() * hh * 0.8, ang = Math.random() * Math.PI * 2, len = Math.max(10, hh * (0.25 + Math.random() * 0.3));
            const pts = [[sx, sy]]; for (let j = 1; j <= 4; j++) pts.push([sx + Math.cos(ang) * len * j / 4 + (Math.random() - 0.5) * len * 0.35, sy + Math.sin(ang) * len * j / 4 + (Math.random() - 0.5) * len * 0.35]);
            for (const [lw, st] of [[4, 'rgba(255,240,120,.35)'], [1.6, 'rgba(255,255,230,.95)']]) { ctx.lineWidth = lw; ctx.strokeStyle = st; ctx.beginPath(); pts.forEach(([x, y], j) => (j ? ctx.lineTo(x, y) : ctx.moveTo(x, y))); ctx.stroke(); }
          }
          ctx.restore();
          alpha = 0.06 + 0.08 * dark; col = '255,250,190';
        } else continue;
      } else {
        // static: mostly a faint hum, with sharp flashes now and then
        a._zap = (a._zap ?? 0) - 1;
        if (a._zap <= 0 && Math.random() < 0.06) a._zap = 2 + Math.floor(Math.random() * 4);
        alpha = (0.05 + 0.08 * dark) + (a._zap > 0 ? (0.18 + 0.2 * dark) * (Math.random() < 0.5 ? 1 : 0.4) : 0); col = '200,230,255';
      }
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r); g.addColorStop(0, `rgba(${col},${alpha.toFixed(3)})`); g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g; ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
    }
    if (t === 'night') for (let i = 0; i < 26; i++) {
      // fireflies
      const x = ((hash2(i, 5) * W + Math.sin(tm * 0.3 + i) * 60) % W + W) % W, y = this.yBack + hash2(i, 9) * (H - this.yBack) * 0.8 + Math.sin(tm * 0.7 + i * 2) * 14;
      if (Math.sin(tm * 2 + i * 1.7) > 0.2) { ctx.fillStyle = 'rgba(220,255,140,.8)'; ctx.fillRect(x, y, 2, 2); ctx.fillStyle = 'rgba(220,255,140,.15)'; ctx.fillRect(x - 3, y - 3, 8, 8); }
    }
    ctx.restore();
  }
  /** Cinematic mode: the camera drifts slowly on its own (a living wallpaper). */
  cinema(on) { this.cinematic = !!on; if (!on && !this.followUid) { this.yawTarget = 0; this.camTarget = 0; this.distTarget = 1; } }
  /** Keep the camera on someone (uid), or stop (null): back to the usual view. */
  follow(uid) {
    this.followUid = uid || null;
    if (!uid) { this.camTarget = 0; this.camZTarget = 0; this.distTarget = 1; this.pitchTarget = PITCH; }
  }
  /**
   * What's being placed in build mode: setGhost(bpId, movingFeatureId) shows it under the pointer; null hides it.
   * placeOk(bp, x, z, skip) → { ok, why }: inside the yard and clear of everything else built.
   */
  setGhost(bp, skip = null) {
    if (bp === this.ghostBp && skip === this.ghostSkip) return;
    this.ghostBp = bp; this.ghostSkip = skip;
    const def = bp ? blueprintOf(bp) : null;
    this.ghostArt = def ? (def.art ?? []).slice(0, 3).map((k) => buildArt(k, this.accent) ?? (this.L ? paintedProp(k, this.L, 7, this.biome) : null)).filter(Boolean) : [];
    if (!bp) this.ghostAt = null;
  }
  placeOk(bp, x, z, skip = null) {
    const def = blueprintOf(bp);
    if (!def) return { ok: false, why: '' };
    const S = this.S, r = def.r ?? 0.8;
    if (x - r * 0.6 < S.x0 || x + r * 0.6 > S.x1 || z - r * 0.4 < S.z0 || z + r * 0.4 > S.z1) return { ok: false, why: 'Too close to the edge' };
    for (const f of this.features ?? []) {
      if (f.id === skip) continue;
      const need = (r + (f.def?.r ?? 0.8)) * 0.85;
      if ((f.x - x) ** 2 + ((f.z - z) * 1.2) ** 2 < need * need) return { ok: false, why: `In the way of the ${f.def?.name ?? 'something built'}` };
    }
    return { ok: true, why: '' };
  }
  drawGhost(ctx) {
    const gh = this.ghostAt, def = blueprintOf(this.ghostBp);
    if (!gh || !def) return;
    const ok = this.placeOk(this.ghostBp, gh.x, gh.z, this.ghostSkip).ok;
    const col = ok ? '80,230,120' : '240,70,70';
    const c = this.project(gh.x, 0, gh.z), l = this.project(gh.x - def.r, 0, gh.z), r = this.project(gh.x + def.r, 0, gh.z);
    if (!c || !l || !r) return;
    const w = (r.x - l.x) / 2, hh = Math.max(4, w * 0.32);
    ctx.save();
    ctx.fillStyle = `rgba(${col},.38)`; ctx.strokeStyle = `rgba(${col},1)`; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.ellipse(c.x, c.y, w, hh, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    // the model itself, see-through and tinted
    for (const [i, pp] of (this.ghostArt ?? []).entries()) {
      const n = this.ghostArt.length, ang = (i / n) * Math.PI * 2, dist = n === 1 ? 0 : def.r * 0.9;
      const q = this.project(gh.x + Math.cos(ang) * dist, 0, gh.z + Math.sin(ang) * dist * 0.75);
      if (!q) continue;
      const k = (q.k * pp.h) / pp.img.height, ww = pp.img.width * k, h2 = pp.img.height * k;
      if (!this._ghostCv) { this._ghostCv = document.createElement('canvas'); }
      const g = this._ghostCv; g.width = pp.img.width; g.height = pp.img.height;
      const gx = g.getContext('2d'); gx.clearRect(0, 0, g.width, g.height); gx.drawImage(pp.img, 0, 0);
      gx.globalCompositeOperation = 'source-atop'; gx.fillStyle = `rgba(${col},.42)`; gx.fillRect(0, 0, g.width, g.height); gx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 0.9; ctx.imageSmoothingEnabled = false;
      ctx.drawImage(g, Math.round(q.x - ww / 2), Math.round(q.y - h2), Math.round(ww), Math.round(h2));
      ctx.globalAlpha = 1;
    }
    this.label(ctx, ok ? `${def.name}: click to place` : `Can’t go here: ${this.placeOk(this.ghostBp, gh.x, gh.z, this.ghostSkip).why.toLowerCase()}`, c.x, c.y - Math.max(26, w * 1.25), ok ? '#a8ffbf' : '#ff9a9a');
    ctx.restore();
  }
  /** The machine under a screen pixel (canvas pixels), or null. */
  machineAt(x, y) {
    for (const f of this.features ?? []) {
      if (f.def?.kind !== 'machine') continue;
      const c = this.project(f.x, 0, f.z), l = this.project(f.x - f.def.r, 0, f.z), r = this.project(f.x + f.def.r, 0, f.z);
      if (!c || !l || !r) continue;
      const w = Math.max(10, (r.x - l.x) / 2);
      if (x >= c.x - w && x <= c.x + w && y >= c.y - w * 2.2 && y <= c.y + w * 0.4) return f;
    }
    return null;
  }
  /** In build mode: a ring around each built thing, its name, and a target to click. */
  drawFeatureMark(ctx, f) {
    const c = this.project(f.x, 0, f.z), l = this.project(f.x - f.def.r, 0, f.z), r = this.project(f.x + f.def.r, 0, f.z);
    if (!c || !l || !r) return;
    const w = (r.x - l.x) / 2, hh = Math.max(4, w * 0.32);
    const on = this.pickedFeature === f.id;
    ctx.save();
    ctx.strokeStyle = on ? '#ffd23f' : 'rgba(125,255,207,.9)'; ctx.lineWidth = on ? 3 : 2; ctx.setLineDash(on ? [] : [6, 4]);
    ctx.beginPath(); ctx.ellipse(c.x, c.y, w, hh, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.restore();
    this.label(ctx, f.def.name, c.x, c.y - hh - 14, on ? '#ffd23f' : '#ffffff');
    this.hits.push({ feature: f.id, x0: c.x - w, x1: c.x + w, y0: c.y - hh - 26, y1: c.y + hh });
  }
  /** A building as a real box: front, the side you can see, and windows that light up at night. */
  drawBlock(ctx, p) {
    const hw = p.w / 2, hd = p.d / 2;
    const P = (x, y, z) => this.project(p.x + x, y, p.z + z);
    const c = { lbf: P(-hw, 0, -hd), rbf: P(hw, 0, -hd), ltf: P(-hw, p.h, -hd), rtf: P(hw, p.h, -hd), lbb: P(-hw, 0, hd), rbb: P(hw, 0, hd), ltb: P(-hw, p.h, hd), rtb: P(hw, p.h, hd) };
    if (Object.values(c).some((v) => !v)) return;
    const fog = Math.max(0, Math.min(0.75, (p.z - this.S.back - 3) / Math.max(8, this.S.floorEnd - this.S.back) * 0.9));
    const night = this.light === 'night' || this.light === 'dusk';
    const tint = (hex, k) => { const rgb = mixRgb(hexRgb(shadeHex(hex, k)), this.c.sky1, fog); return `rgb(${rgb.map((v) => v | 0).join(',')})`; };
    const quad = (a, b, cc, d, fill) => { ctx.fillStyle = fill; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(cc.x, cc.y); ctx.lineTo(d.x, d.y); ctx.closePath(); ctx.fill(); };
    const lerp = (a, b, t) => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t });
    // windows on a face: bottom-left, bottom-right, top-right, top-left corners
    const windows = (bl, br, tr, tl, cols, rows, seed) => {
      if (p.type === 'stack' || cols < 1) return;
      for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
        const u0 = (i + 0.25) / cols, u1 = (i + 0.75) / cols, v0 = (j + 0.3) / rows, v1 = (j + 0.75) / rows;
        const at = (u, v) => lerp(lerp(bl, br, u), lerp(tl, tr, u), v);
        const lit = hash2(i + seed, j + p.seed) < (night ? 0.55 : 0.12);
        quad(at(u0, v0), at(u1, v0), at(u1, v1), at(u0, v1), lit ? (night ? 'rgba(255,214,120,.95)' : tint('#fff2c0', 0)) : tint(p.type === 'tower' ? '#3a4a6a' : '#4a4a58', 0.05));
      }
    };
    const cam = this.cx;
    const rows = Math.max(1, Math.floor(p.h / (p.type === 'warehouse' || p.type === 'factory' ? 1.6 : 1.1))), cols = Math.max(1, Math.floor(p.w / 0.9));
    // the side facing the camera (left or right), then the front
    if (cam < p.x - hw) { quad(c.lbb, c.lbf, c.ltf, c.ltb, tint(p.color, -0.25)); windows(c.lbb, c.lbf, c.ltf, c.ltb, Math.max(1, Math.floor(p.d / 1)), rows, 7); }
    else if (cam > p.x + hw) { quad(c.rbf, c.rbb, c.rtb, c.rtf, tint(p.color, -0.25)); windows(c.rbf, c.rbb, c.rtb, c.rtf, Math.max(1, Math.floor(p.d / 1)), rows, 9); }
    if (this.camY > p.h) quad(c.ltf, c.rtf, c.rtb, c.ltb, tint(p.color, 0.15));
    quad(c.lbf, c.rbf, c.rtf, c.ltf, tint(p.color, 0));
    windows(c.lbf, c.rbf, c.rtf, c.ltf, cols, rows, 3);
    // roof details: a sawtooth on warehouses, a parapet and antenna on towers, a big door on factories
    if (p.type === 'warehouse') { for (let i = 0; i < 4; i++) { const a = lerp(c.ltf, c.rtf, i / 4), b2 = lerp(c.ltf, c.rtf, (i + 1) / 4); ctx.fillStyle = tint(p.color, -0.15); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b2.x, b2.y - (b2.x - a.x) * 0.35); ctx.lineTo(b2.x, b2.y); ctx.fill(); } }
    if (p.type === 'tower') { const top = lerp(c.ltf, c.rtf, 0.7); ctx.strokeStyle = tint('#5a5a68', 0); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(top.x, top.y); ctx.lineTo(top.x, top.y - (c.lbf.y - c.ltf.y) * 0.12); ctx.stroke(); if (night && Math.sin(this.time * 3) > 0) { ctx.fillStyle = '#ff4040'; ctx.fillRect(top.x - 1, top.y - (c.lbf.y - c.ltf.y) * 0.12 - 2, 3, 3); } }
    if (p.type === 'factory') { const a = lerp(c.lbf, c.rbf, 0.35), b2 = lerp(c.lbf, c.rbf, 0.6), h2 = (c.lbf.y - c.ltf.y) * 0.45; quad(a, b2, { x: b2.x, y: b2.y - h2 }, { x: a.x, y: a.y - h2 }, tint('#5a5048', 0)); }
    if (p.smoke && Math.random() < 0.08) this.sparks.push({ kind: 'gust', x: p.x, y: p.h + 0.2, z: p.z, vx: 0.3, vy: 0.8, vz: 0, life: 2.4, ph: 0, c: 1 });
  }
  /** A glassy bubble of air on the seafloor. */
  /** The dome: a glass hemisphere drawn in 3D (its back half behind whoever is inside, the front over them). */
  drawDome(ctx, part = 'back') {
    const D = this.dome, H = D.r * 1.1, rz = D.r / 1.3;
    const P = (u, v) => { const cu = Math.cos(u), su = Math.sin(u), cv = Math.cos(v); return this.project(D.x + cu * cv * D.r, Math.sin(v) * H, D.z + su * cv * rz); };
    ctx.save();
    const front = part === 'front';
    if (!front) {
      // the sandy floor
      ctx.fillStyle = 'rgba(240,226,180,.4)'; ctx.beginPath();
      for (let i = 0; i <= 32; i++) { const q = P((i / 32) * Math.PI * 2, 0); if (!q) continue; i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }
      ctx.fill();
    }
    // the glass: a soft fill, then lines of longitude and latitude for the far or near half
    // the half of the ring facing away from the camera (depth runs along (ys, yc) in the world)
    const phi = Math.atan2(rz * this.yc, D.r * this.ys);
    const u0 = front ? phi + Math.PI / 2 : phi - Math.PI / 2, u1 = u0 + Math.PI;
    ctx.fillStyle = front ? 'rgba(220,245,255,.10)' : 'rgba(200,235,255,.14)';
    ctx.beginPath();
    for (let i = 0; i <= 20; i++) { const q = P(u0 + ((u1 - u0) * i) / 20, 0); if (q) i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }
    for (let i = 0; i <= 10; i++) { const q = P(u1, (i / 10) * (Math.PI / 2)); if (q) ctx.lineTo(q.x, q.y); }
    for (let i = 10; i >= 0; i--) { const q = P(u0, (i / 10) * (Math.PI / 2)); if (q) ctx.lineTo(q.x, q.y); }
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = front ? 'rgba(235,252,255,.55)' : 'rgba(220,245,255,.35)'; ctx.lineWidth = front ? 1.6 : 1.2;
    for (let m = 0; m < 8; m++) {
      const u = u0 + ((u1 - u0) * (m + 0.5)) / 8;
      ctx.beginPath();
      for (let i = 0; i <= 12; i++) { const q = P(u, (i / 12) * (Math.PI / 2)); if (q) i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }
      ctx.stroke();
    }
    for (const v of [0, 0.35, 0.75]) {
      ctx.beginPath();
      for (let i = 0; i <= 24; i++) { const q = P(u0 + ((u1 - u0) * i) / 24, v); if (q) i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }
      ctx.stroke();
    }
    if (front) {
      // a glint on the glass, and bubbles climbing it
      ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.lineWidth = 3; ctx.beginPath();
      for (let i = 0; i <= 8; i++) { const q = P(u0 + Math.PI * (0.62 + i * 0.02), 0.5 + i * 0.05); if (q) i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }
      ctx.stroke();
      ctx.fillStyle = 'rgba(230,250,255,.5)';
      for (let i = 0; i < 5; i++) { const v = ((this.time * 0.15 + i * 0.2) % 1) * (Math.PI / 2); const q = P(u0 + Math.PI * (0.2 + i * 0.15), v); if (q) { ctx.beginPath(); ctx.arc(q.x, q.y, 1.5 + (q.k ?? 30) * 0.02, 0, Math.PI * 2); ctx.fill(); } }
    }
    ctx.restore();
  }
  /** The gazebo: a wooden floor, four posts and a peaked roof (back posts behind, the roof and front posts in front). */
  drawShelter(ctx, part = 'back') {
    const G = this.shelter, rz = G.r * 0.8, hP = 1.6, hR = 2.3;
    const isFar = (x, z) => x * this.ys + z * this.yc > 0;
    const P = (x, y, z) => this.project(G.x + x, y, G.z + z);
    const poly = (pts, fill, stroke) => { const qs = pts.map((p) => P(...p)); if (qs.some((q) => !q)) return; ctx.beginPath(); qs.forEach((q, i) => (i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y))); ctx.closePath(); if (fill) { ctx.fillStyle = fill; ctx.fill(); } if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); } };
    // a post runs from the floor to where the roof sits, following the perspective (so the roof lines up)
    const post = (x, z) => {
      const a = P(x, 0, z), b = P(x, hP, z); if (!a || !b) return;
      const wa = Math.max(2, (a.k ?? 30) * 0.12) / 2, wb = Math.max(2, (b.k ?? 30) * 0.12) / 2;
      ctx.fillStyle = '#7a5434'; ctx.beginPath(); ctx.moveTo(a.x - wa, a.y); ctx.lineTo(a.x + wa, a.y); ctx.lineTo(b.x + wb, b.y); ctx.lineTo(b.x - wb, b.y); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = Math.max(1, wa * 0.5); ctx.beginPath(); ctx.moveTo(a.x - wa * 0.5, a.y); ctx.lineTo(b.x - wb * 0.5, b.y); ctx.stroke();
    };
    const r = G.r;
    const wood = this.light === 'night' ? '#5c4632' : '#a07850', dark = this.light === 'night' ? '#3c2c20' : '#6e4e32';
    ctx.save();
    if (part === 'back') {
      poly([[-r, 0.06, -rz], [r, 0.06, -rz], [r, 0.06, rz], [-r, 0.06, rz]], wood, dark);
      for (let i = 1; i < 5; i++) { const z = -rz + (2 * rz * i) / 5; const a = P(-r, 0.07, z), b = P(r, 0.07, z); if (a && b) { ctx.strokeStyle = dark; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); } }
      for (const [x, z] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) if (isFar(x * r, z * rz)) post(x * r * 0.92, z * rz * 0.92);
      // a little bench at the back
      poly([[-r * 0.7, 0.45, rz * 0.8], [r * 0.7, 0.45, rz * 0.8], [r * 0.7, 0.45, rz * 0.55], [-r * 0.7, 0.45, rz * 0.55]], '#8a6440', dark);
    } else {
      for (const [x, z] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) if (!isFar(x * r, z * rz)) post(x * r * 0.92, z * rz * 0.92);
      const roof = this.weather === 'snow' ? '#eef4ff' : '#b0473a', roofD = this.weather === 'snow' ? '#c8d4e8' : '#7c2c24';
      const e = 1.08, apex = [0, hR, 0];
      const faces = [[[-r * e, hP, -rz * e], [r * e, hP, -rz * e]], [[r * e, hP, -rz * e], [r * e, hP, rz * e]], [[-r * e, hP, -rz * e], [-r * e, hP, rz * e]], [[-r * e, hP, rz * e], [r * e, hP, rz * e]]]
        .map((f) => ({ f, d: ((f[0][0] + f[1][0]) / 2) * this.ys + ((f[0][2] + f[1][2]) / 2) * this.yc, lit: (f[0][0] + f[1][0]) <= 0 }))
        .sort((a, b) => b.d - a.d);
      for (const { f, lit } of faces) poly([...f, apex], lit ? roof : roofD, '#2a1c14');
      const tip = P(0, hR + 0.15, 0); if (tip) { ctx.fillStyle = '#ffd23f'; ctx.beginPath(); ctx.arc(tip.x, tip.y, 2.5, 0, Math.PI * 2); ctx.fill(); }
    }
    ctx.restore();
  }
  drawBill(ctx, img, q, s, shimmer = false) {
    const w = Math.max(1, Math.round(img.width * s)), h = Math.max(1, Math.round(img.height * s));
    ctx.drawImage(img, Math.round(q.x - w / 2), Math.round(q.y - h + 1), w + 1, h);
    if (shimmer) {
      // the habitat's holographic boundary shimmers above the fence
      const a = 0.07 + 0.05 * Math.sin(this.time * 2 + q.x * 0.05);
      ctx.fillStyle = `rgba(125,255,207,${a.toFixed(3)})`;
      ctx.fillRect(Math.round(q.x - w / 2), Math.round(q.y - h - 2.5 * q.k), w + 1, Math.round(2.5 * q.k));
    }
  }
  /** Something an animation is moving about (a move hitting, a dash): { dx, dy, scale, opacity } in pixels. */
  withOffset(ctx, o, q, draw) {
    if (!o) { draw(); return; }
    ctx.save();
    ctx.globalAlpha *= Math.max(0, Math.min(1, o.opacity ?? 1));
    ctx.translate(q.x + (o.dx ?? 0), q.y + (o.dy ?? 0)); ctx.scale(o.scale ?? 1, o.scale ?? 1); ctx.translate(-q.x, -q.y);
    draw();
    ctx.restore();
  }
  drawProp(ctx, p, q) { if (p.fxOff) { this.withOffset(ctx, p.fxOff, q, () => this.drawPropInner(ctx, p, q)); return; } this.drawPropInner(ctx, p, q); }
  drawPropInner(ctx, p, q) {
    if (p.mesh) {
      const fog = this.scene === 'battle' ? Math.max(0, Math.min(0.45, (Math.hypot(p.x, p.z - FIELD_Z) - 22) / 50)) : Math.max(0, Math.min(0.75, (p.z - this.S.back - 3) / Math.max(8, this.S.floorEnd - this.S.back) * 0.9));
      drawMesh(ctx, this, p.mesh, p.x, p.z, { fog, sky: this.c.sky1 });
      if (p.glow && (p.glow >= 1 || this.tod === 'dusk' || this.tod === 'night' || this.L.night || this.L.cave || this.L.moon)) {
        // floodlights, lamps, torches: a halo where the light is, and a pool of light at night
        const L = this.project(p.x, p.lightY ?? p.h, p.z);
        if (L) {
          const rr = Math.max(6, L.k * 0.9 * p.glow);
          const g = ctx.createRadialGradient(L.x, L.y, 0, L.x, L.y, rr);
          g.addColorStop(0, 'rgba(255,250,220,.55)'); g.addColorStop(1, 'rgba(255,240,200,0)');
          ctx.fillStyle = g; ctx.fillRect(L.x - rr, L.y - rr, rr * 2, rr * 2);
          this.lamps.push({ x: L.x, y: L.y, r: Math.max(10, L.k * p.glow), warm: true });
        }
      }
      return;
    }
    const k = (q.k * p.h) / p.img.height;
    const w = Math.max(1, Math.round(p.img.width * k)), h = Math.max(1, Math.round(p.img.height * k));
    if (w < 2 && h < 2) return;
    let y0 = q.y - h;
    if (p.bot) y0 += Math.sin(this.time * 3) * 2;
    if (p.outside && q.z > 12) {
      // far-off scenery fades into the haze like the ground does
      ctx.globalAlpha = Math.max(0.35, 1 - (q.z - 12) / 40);
    }
    if (['tree', 'pine', 'palm', 'snowpine', 'kelp', 'reed', 'deadtree'].includes(p.kind)) {
      // a gentle sway in the wind (or the current)
      const sway = Math.sin(this.time * (p.kind === 'kelp' ? 1.4 : 0.9) + p.x) * (p.kind === 'kelp' ? 0.05 : 0.012);
      ctx.save(); ctx.translate(q.x, q.y); ctx.transform(1, 0, sway, 1, 0, 0); ctx.drawImage(p.img, Math.round(-w / 2), Math.round(-h), w, h); ctx.restore();
    } else ctx.drawImage(p.img, Math.round(q.x - w / 2), Math.round(y0), w, h);
    ctx.globalAlpha = 1;
    if (p.shopkeeper) this.hits.push({ shop: true, x0: q.x - w / 2, x1: q.x + w / 2, y0, y1: q.y });
    if (p.glow && (this.L.night || this.L.moon || this.L.cave || this.tod === 'night' || this.tod === 'dusk' || p.kind === 'glowshroom')) {
      const g = p.glow * (0.8 + 0.2 * Math.sin(this.time * 2 + p.x));
      ctx.fillStyle = `rgba(160,255,230,${(0.14 * g).toFixed(3)})`; ctx.beginPath(); ctx.arc(q.x, y0 + h * 0.3, Math.max(6, w * (1.2 + g)), 0, Math.PI * 2); ctx.fill();
    }
    if (LIGHT_KINDS[p.kind] || p.glow) this.lamps.push({ x: q.x, y: y0 + h * (LIGHT_KINDS[p.kind] ?? 0.3), r: Math.max(10, q.k * (p.kind === 'campfire' ? 1.6 : 1)), warm: p.kind !== 'glowshroom' });
    if (p.kind === 'lamppost' && (this.L.night || this.L.moon)) {
      ctx.fillStyle = 'rgba(255,233,168,.12)'; ctx.beginPath(); ctx.arc(q.x, y0 + h * 0.08, Math.max(4, w * 1.4), 0, Math.PI * 2); ctx.fill();
    }
    if (p.beacon) {
      const pulse = 0.5 + 0.5 * Math.sin(this.time * 3);
      ctx.fillStyle = `rgba(125,255,207,${(0.1 + pulse * 0.16).toFixed(3)})`;
      const bw = Math.max(2, Math.round(q.k * 0.22));
      ctx.fillRect(Math.round(q.x - bw / 2), 0, bw, Math.round(y0 + 2));
    }
  }

  drawToy(ctx, t, q) {
    const P = TOYS[t.kind] ?? TOYS.ball;
    const top = this.project(t.x, t.y + t.r, t.z), bottom = this.project(t.x, t.y - t.r, t.z);
    if (!top || !bottom) return;
    const size = Math.max(4, Math.round((bottom.y - top.y)));
    // shadow on the ground, smaller the higher it goes
    const sh = Math.max(2, Math.round(size * 0.9 / (1 + t.y * 0.8)));
    ctx.fillStyle = 'rgba(10,8,30,.25)';
    ctx.beginPath(); ctx.ellipse(Math.round(q.x), Math.round(q.y), sh / 2, Math.max(1.5, size * 0.12), 0, 0, Math.PI * 2); ctx.fill();
    const cx = (top.x + bottom.x) / 2, cy = (top.y + bottom.y) / 2;
    const sq = t.squash * 0.3 * (P.bounce > 0.3 ? 1 : 0.4);
    const w = Math.round(size * (1 + sq)), h = Math.round(size * (1 - sq));
    ctx.save();
    ctx.translate(Math.round(cx), Math.round(cy + (size - h) / 2));
    if (t.kind === 'berry') {
      // the berry's own picture (downloaded sprite, or drawn), a little bigger than a toy
      const img = itemPicture(t.item ?? { kind: 'food', color: '#c0306a' }, this.bank?.idx);
      ctx.drawImage(img, -w * 0.7, -h * 0.7, w * 1.4, h * 1.4);
    } else {
      if (t.kind === 'ball' || t.kind === 'bell' || t.kind === 'disc') ctx.rotate(t.kind === 'disc' ? Math.sin(t.spin) * 0.3 : t.spin);
      const img = (t.kind === 'ball' && artImage('ui/toy-ball.png')) || toyImg(t.kind);
      ctx.drawImage(img, -w / 2, -h / 2, w, h);
    }
    ctx.restore();
    const pad = Math.max(0, 16 - size) / 2;
    this.hits.push({ toy: t, x0: cx - w / 2 - pad, x1: cx + w / 2 + pad, y0: cy - h / 2 - pad, y1: cy + h / 2 + pad });
    if (this.hover === 'toy' && !t.held) { /* the cursor says it all */ }
  }

  hasBack(entry) { return !!(entry.ownFile?.back || (!entry.custom && !entry.waiting && entry.frames.back?.length)); }
  drawActor(ctx, a, q) { if (a.ghost) return; // (an invisible stand-in: move practice's target)
    if (a.fxOff) { this.withOffset(ctx, a.fxOff, q, () => this.drawActorInner(ctx, a, q)); return; } this.drawActorInner(ctx, a, q); }
  drawActorInner(ctx, a, q) {
    const entry = this.bank.get(a.speciesId);
    const tall = this.heightOf(a) * q.k; // visible pixels
    const fit = fitSprite(entry, tall, 0);
    const pxH = fit.size;
    const hop = Math.sin(a.hop * Math.PI) * 0.35 * q.k * Math.min(1, this.heightOf(a));
    const lift = (a.y || 0) * q.k;
    // shadow stays on the ground, shrinking as it is lifted
    const sw = Math.max(3, Math.round(pxH * (fit.box.right - fit.box.left) * 0.85 / (1 + (a.y || 0) * 0.6)));
    ctx.fillStyle = `rgba(10,8,30,${((this.sun || this.lit?.length ? 0.2 : 0.28) / (1 + (a.y || 0) * 0.5)).toFixed(3)})`; // (a contact shadow; the cast ones come with the picture)
    ctx.beginPath(); ctx.ellipse(Math.round(q.x), Math.round(q.y), sw / 2, Math.max(1.5, Math.min(sw * 0.16, q.k * 0.07)), 0, 0, Math.PI * 2); ctx.fill();
    if (this.selected === a.uid && a.state !== 'held') {
      ctx.strokeStyle = Math.sin(this.time * 5) > 0 ? '#7dffcf' : '#ffffff';
      ctx.strokeRect(Math.round(q.x - sw / 2 - 3) + 0.5, Math.round(q.y - 3) + 0.5, sw + 6, Math.max(3, Math.round(q.k * 0.2)));
    }
    const moving = a.state === 'walk' || a.state === 'chase' || a.state === 'return';
    const floating = (a.fly || (this.swimAll && !this.domed(a))) && !a.sitting && (a.y || 0) > 0.2;
    // downloaded animations have many frames: play them at their own pace
    // big creatures animate slowly (a.rate), small ones at the usual pace
    const R = a.rate ?? 1, at = a.ft * R;
    const fps = (entry.frames.idle?.length ?? 1) > 4 ? 10 : 0;
    let anim = 'idle', frame = Math.floor(at * (fps || 2));
    if (a.battleBack && this.hasBack(entry)) { anim = 'back'; frame = Math.floor(at * (fps || 2)); }
    else if (moving && a.away && this.hasBack(entry)) { anim = 'back'; frame = Math.floor(at * (fps || 6)); }
    else if (moving) { anim = 'walk'; frame = Math.floor(at * (fps ? fps * 1.3 : floating ? 4 : 6)); }
    else if (a.state === 'sleep') { anim = 'sleep'; frame = Math.floor(at); }
    else if (a.state === 'happy' || a.state === 'eat') { anim = 'happy'; frame = Math.floor(at * 4); }
    else if (a.state === 'held' || a.state === 'falling') { anim = 'walk'; frame = Math.floor(at * 10); }
    else if (a.blink < 0) anim = 'blink';
    if (a.state === 'sulk' && this.hasBack(entry)) anim = 'back';
    const list = entry.frames[anim] ?? entry.frames.idle;
    const img = list[((frame % list.length) + list.length) % list.length] ?? list[0];
    const sq = a.squash * 0.25;
    const w = Math.round(pxH * (1 + sq)), hh = Math.round(pxH * (1 - sq));
    const x0 = Math.round(q.x - w / 2 + (0.5 - (fit.box.left + fit.box.right) / 2) * w + (a.jitter ?? 0)), y0 = Math.round(q.y - hh * fit.box.bottom - hop - lift + 1);
    // front sprites face left as drawn (back sprites face right): mirror them to face the way they're heading on screen
    // (flip = heading to world -x; the camera may be turned round)
    const headingRight = (a.flip ? -1 : 1) * (this.yc < 0 ? -1 : 1) > 0;
    const mirror = a.battleFace != null ? (anim === 'back' ? a.battleFace !== 'right' : a.battleFace === 'right') : anim === 'back' ? !headingRight : headingRight;
    // the pose on top of the sprite (and the lighting drawn over it follows the same pose, so it never slips off)
    const poseT = () => {
      const P0 = a.pose;
      if (P0) {
        const px = q.x, py = y0 + hh * fit.box.bottom;
        ctx.translate(px + (P0.dx ?? 0) * pxH, py + (P0.dy ?? 0) * pxH);
        if (P0.lean) ctx.rotate(P0.lean);
        ctx.scale(P0.sx ?? 1, P0.sy ?? 1);
        ctx.translate(-px, -py);
      }
      if (a.state === 'held') { ctx.translate(q.x, y0); ctx.rotate(Math.sin(this.time * 7) * 0.12); ctx.translate(-q.x, -y0); }
      else if (floating && moving) { const tilt = (a.flip ? -1 : 1) * 0.06; ctx.translate(q.x, y0 + hh / 2); ctx.rotate(tilt); ctx.translate(-q.x, -(y0 + hh / 2)); }
    };
    const paint = () => {
      ctx.save();
      ctx.imageSmoothingEnabled = false;
      // battles: fading out (fainting, switching), and the white flash of taking a hit
      if (a.alpha != null && a.alpha < 1) ctx.globalAlpha = Math.max(0, a.alpha);
      if (a.redLight > 0) ctx.filter = 'brightness(1.6) sepia(1) saturate(7) hue-rotate(-45deg)'; // red light (going back into its ball)
      else if (a.hitFlash > 0) ctx.filter = 'brightness(2.6) saturate(0.3)';
      else if (a.tint === 'frz') ctx.filter = 'sepia(0.5) hue-rotate(165deg) saturate(2.2) brightness(1.25)';
      else if (a.tint === 'par') ctx.filter = 'sepia(1) saturate(5) brightness(1.5)';
      else if (a.tint === 'psn') ctx.filter = 'sepia(1) hue-rotate(230deg) saturate(4) brightness(0.95)'; // hurt by poison: purple
      else if (a.tint === 'brn') ctx.filter = 'sepia(1) hue-rotate(-35deg) saturate(6) brightness(1.1)'; // hurt by a burn: red
      // battles: a pose on top of the sprite (leaning back to wind up, stretching into a lunge, reeling from a
      // hit, settling back), pivoting on its feet
      const P0 = a.pose;
      poseT();
      if (P0?.dim && !(a.hitFlash > 0)) ctx.filter = `brightness(${(1 - P0.dim).toFixed(2)})`;
      if (mirror) { ctx.translate(x0 + w, y0); ctx.scale(-1, 1); ctx.drawImage(img, 0, 0, w, hh); this.drawWorn(ctx, a, 0, 0, w, hh, fit.box, anim === 'back'); }
      else { ctx.drawImage(img, x0, y0, w, hh); this.drawWorn(ctx, a, x0, y0, w, hh, fit.box, anim === 'back'); }
      ctx.restore();
    };
    if (a.appear < 1) {
      if (a.appear <= 0) return;
      const bw = Math.max(3, Math.round(w * 0.6));
      ctx.fillStyle = `rgba(125,255,207,${(0.6 * (1 - a.appear)).toFixed(3)})`;
      ctx.fillRect(Math.round(q.x - bw / 2), 0, bw, Math.round(q.y - lift));
      const shown = Math.max(0, (a.appear - 0.2) / 0.8);
      ctx.save(); ctx.beginPath(); ctx.rect(0, Math.round(q.y - lift - hh * shown), this.W, Math.ceil(hh * shown) + 1); ctx.clip(); paint(); ctx.restore();
      return;
    }
    if (a.sink > 0) {
      // diving into clouds, sand or a bush: the ground line hides the part that has gone under
      ctx.save(); ctx.beginPath(); ctx.rect(0, 0, this.W, Math.round(q.y - lift + 2)); ctx.clip(); ctx.translate(0, Math.round(hh * Math.min(1, a.sink))); paint(); ctx.restore();
    } else {
      // a reflection under it on water, ice, polished floors or a soaked field (this.reflect: 0..1): the sprite
      // flipped upside down below its feet, faint, and rippling where the surface is water
      // its shadows on the ground, cast away from the sun and from any strong light near it
      if (this.lighting !== false && this.shadows !== false && a.state !== 'held' && (a.alpha ?? 1) > 0.15) { try { castShadows(ctx, this, a, img, x0, w, hh, fit.box.bottom, mirror, lift); } catch { /* none */ } }
      if (this.reflect > 0 && (a.alpha ?? 1) > 0.1 && !a.sink) {
        const feet = q.y - lift + 1, lift2 = hop + lift, ripple = !!this.reflectWater;
        const srcB = img.height * fit.box.bottom, hr = hh * fit.box.bottom, strips = 10, sh = hr / strips, ss = srcB / strips;
        const base = Math.max(0, Math.min(1, this.reflect * (a.alpha ?? 1))) * Math.max(0.2, 1 - lift2 / (hh * 1.5));
        ctx.save(); ctx.imageSmoothingEnabled = false;
        for (let k2 = 0; k2 < strips; k2++) { // k2 = 0 by the feet, fading further down
          const off = ripple ? Math.sin(this.time * 3 + k2 * 0.9 + a.x) * Math.max(1, w * 0.025) * (k2 / strips + 0.25) : 0;
          ctx.globalAlpha = base * (1 - k2 / strips) * 0.9;
          const dy = feet + lift2 + k2 * sh;
          ctx.save(); ctx.translate(x0 + off + (mirror ? w : 0), dy + sh); ctx.scale(mirror ? -1 : 1, -1);
          ctx.drawImage(img, 0, srcB - (k2 + 1) * ss, img.width, ss, 0, 0, w, sh + 0.5);
          ctx.restore();
        }
        ctx.restore();
      }
      paint();
      // the light falling on it: the place's key light, and any lamps, fires or moves nearby
      if (this.lighting !== false && a.state !== 'held' && !(floating && moving)) { ctx.save(); try { poseT(); sunSprite(ctx, this, a, img, x0, y0, w, hh, mirror); lightSprite(ctx, this, a, img, x0, y0, w, hh, mirror); } catch { /* unlit */ } ctx.restore(); }
      // a stat raised or lowered in battle: a thick chevron pattern scrolling over it (up for better, down for worse)
      if (a.chev && a.chev.until > this.time) { ctx.save(); try { poseT(); this.drawChevrons(ctx, a, img, x0, y0, w, hh, mirror); } catch { /* skip */ } ctx.restore(); }
    }
    // small creatures get a slightly bigger target so they are still easy to grab
    const b = fit.box, pad = Math.max(0, 14 - tall) / 2;
    this.hits.push({ uid: a.uid, x0: x0 + w * b.left - pad, x1: x0 + w * b.right + pad, y0: y0 + hh * b.top - pad, y1: y0 + hh * b.bottom + 2, k: q.k });
    if (a.state === 'sleep' && Math.sin(this.time * 2) > 0) this.label(ctx, 'z', q.x + w * b.right * 0.6, y0 + hh * b.top, '#ffffff', true);
  }

  /** Clothes they're wearing, drawn on the sprite (fractions of its box; hidden from behind except hats). */
  drawChevrons(ctx, a, img, x0, y0, w, hh, mirror) {
    const W = Math.max(1, Math.round(w)), H = Math.max(1, Math.round(hh));
    const cv = this._chevCv ?? (this._chevCv = document.createElement('canvas'));
    if (cv.width < W || cv.height < H) { cv.width = Math.max(cv.width, W); cv.height = Math.max(cv.height, H); }
    const c = cv.getContext('2d'); c.clearRect(0, 0, cv.width, cv.height); c.imageSmoothingEnabled = false;
    c.globalCompositeOperation = 'source-over';
    if (mirror) { c.save(); c.translate(W, 0); c.scale(-1, 1); c.drawImage(img, 0, 0, W, H); c.restore(); } else c.drawImage(img, 0, 0, W, H);
    c.globalCompositeOperation = 'source-atop';
    const up = !!a.chev.up, step = Math.max(6, W * 0.26), off = ((this.time * step * 1.6) % step) * (up ? -1 : 1);
    c.strokeStyle = a.chev.col ?? (up ? 'rgba(255,90,70,1)' : 'rgba(80,140,255,1)'); c.lineWidth = step * 0.38; c.lineJoin = 'miter';
    c.beginPath();
    for (let y = -step * 2; y < H + step * 2; y += step) { const yy = y + off; if (up) { c.moveTo(-2, yy + step * 0.55); c.lineTo(W / 2, yy); c.lineTo(W + 2, yy + step * 0.55); } else { c.moveTo(-2, yy); c.lineTo(W / 2, yy + step * 0.55); c.lineTo(W + 2, yy); } }
    c.stroke();
    const left = a.chev.until - this.time, k = Math.min(1, left / 0.4, (this.time - (a.chev.from ?? 0)) / 0.25);
    // emissive: the stripes shine (added as light) with a soft glow round the creature's outline, pulsing
    const pulse = 0.85 + 0.15 * Math.sin(this.time * 6), kk = Math.max(0, k) * (a.alpha ?? 1);
    ctx.save(); ctx.globalAlpha = 0.5 * kk; ctx.drawImage(cv, 0, 0, W, H, Math.round(x0), Math.round(y0), W, H);
    ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.55 * kk * pulse; ctx.drawImage(cv, 0, 0, W, H, Math.round(x0), Math.round(y0), W, H);
    ctx.filter = `blur(${Math.max(2, Math.round(W * 0.04))}px)`; ctx.globalAlpha = 0.5 * kk * pulse; ctx.drawImage(cv, 0, 0, W, H, Math.round(x0), Math.round(y0), W, H);
    ctx.restore();
  }
  drawWorn(ctx, a, ox, oy, w, hh, box, back = false) {
    if (!a.clothes?.length) return;
    const bw = (box.right - box.left) * w, bh = (box.bottom - box.top) * hh;
    for (const wr of a.clothes) {
      if (!wr.img || (back && wr.fy > 0.35)) continue;
      // whole-pixel scale so the clothes stay as crisp as the sprite
      const k = Math.max(1, Math.round((bw * 0.3 * (wr.s ?? 1)) / wr.img.width));
      const cw = wr.img.width * k, ch = wr.img.height * k;
      const cx = Math.round(ox + box.left * w + wr.fx * bw), cy = Math.round(oy + box.top * hh + wr.fy * bh);
      if (wr.r) { ctx.save(); ctx.translate(cx, cy); ctx.rotate((wr.r * Math.PI) / 180); ctx.drawImage(wr.img, -Math.round(cw / 2), -Math.round(ch / 2), cw, ch); ctx.restore(); }
      else ctx.drawImage(wr.img, cx - Math.round(cw / 2), cy - Math.round(ch / 2), cw, ch);
    }
  }

  drawBubble(ctx, a) {
    const b = this.hits.find((h) => h.uid === a.uid);
    if (!b) return;
    const bb = a.bubble, rows = FACES[bb.face] ?? FACES.calm;
    const s = Math.max(2, Math.min(4, Math.round((b.k ?? 60) / 26)));
    const pop = Math.min(1, bb.t / 0.12), fade = Math.min(1, (bb.life - bb.t) / 0.35);
    const bw = (bb.pic ? 13 : 11) * s, bh = (bb.pic ? 12 : 10) * s;
    const cx = Math.round((b.x0 + b.x1) / 2 + (b.x1 - b.x0) * 0.25), y = Math.round(b.y0 - bh - 4 * s - bb.t * 3);
    ctx.save();
    ctx.globalAlpha = fade;
    ctx.translate(cx, y + bh);
    ctx.scale(pop, pop);
    ctx.translate(-cx, -(y + bh));
    const x = cx - Math.round(bw / 2);
    const blob = (ox, oy, grow, col) => {
      ctx.fillStyle = col;
      ctx.fillRect(x + ox - grow, y + oy - s - grow, bw + grow * 2, bh + 2 * s + grow * 2);
      ctx.fillRect(x + ox - s - grow, y + oy - grow, bw + 2 * s + grow * 2, bh + grow * 2);
      // the tail, pointing down at their head
      ctx.fillRect(x + ox + s * 2 - grow, y + oy + bh, s * 2 + grow * 2, s * 2 + grow);
      ctx.fillRect(x + ox + s - grow, y + oy + bh + s * 2, s + grow * 2, s + grow);
    };
    blob(s, s, 0, 'rgba(20,16,40,.35)');
    blob(0, 0, Math.max(1, s / 2), '#2a2448');
    blob(0, 0, 0, '#ffffff');
    ctx.fillStyle = '#e4e8f6'; ctx.fillRect(x, y + bh - s, bw, s);
    if (bb.pic) {
      const m = 2 * s, side = Math.min(bw, bh) - m;
      ctx.imageSmoothingEnabled = false;
      try { ctx.drawImage(bb.pic, x + Math.round((bw - side) / 2), y + Math.round((bh - side) / 2) - Math.round(s / 2), side, side); } catch { /* not ready */ }
      ctx.restore();
      return;
    }
    ctx.fillStyle = FACE_COL[bb.face] ?? '#3b3550';
    rows.forEach((row, j) => { for (let i = 0; i < row.length; i++) if (row[i] === '#') ctx.fillRect(x + (i + 2) * s, y + (j + 1.5) * s, s, s); });
    ctx.restore();
  }

  drawSpark(ctx, sp, q) {
    const col = (FX_COL[sp.kind] ?? FX_COL.plain)[sp.c];
    const s = Math.max(2, Math.round(q.k / 30));
    ctx.globalAlpha = Math.max(0, Math.min(1, sp.life * 1.6));
    ctx.fillStyle = col;
    const x = Math.round(q.x), y = Math.round(q.y);
    switch (sp.kind) {
      case 'spark': ctx.fillRect(x, y, s, s); ctx.fillRect(x + s, y + s, s, s); ctx.fillRect(x - s, y + s * 2, s, s); break;
      case 'star': case 'glitter': case 'glint': if (Math.sin(sp.ph * 9) > -0.4) { ctx.fillRect(x - s, y, s * 3, s); ctx.fillRect(x, y - s, s, s * 3); } break;
      case 'ring': { const rr = s * (2 + (1.2 - sp.life) * 6); ctx.strokeStyle = col; ctx.lineWidth = Math.max(1, s / 2); ctx.strokeRect(x - rr, y - rr, rr * 2, rr * 2); break; }
      case 'gust': ctx.fillRect(x, y, s * 4, Math.max(1, s / 2)); ctx.fillRect(x + s * 2, y - s, s * 3, Math.max(1, s / 2)); break;
      case 'drop': ctx.fillRect(x, y, s, s * 2); break;
      case 'leaf': ctx.fillRect(x, y, s * 2, s); ctx.fillRect(x + s, y - s, s, s); break;
      case 'bubble': ctx.strokeStyle = col; ctx.lineWidth = 1; ctx.strokeRect(x + 0.5, y + 0.5, s + 1, s + 1); break;
      case 'wisp': ctx.fillRect(x, y, s * 2, s * 2); ctx.globalAlpha *= 0.4; ctx.fillRect(x - s, y + s * 2, s * 2, s * 2); break;
      default: ctx.fillRect(x, y, s, s);
    }
    ctx.globalAlpha = 1;
  }

  drawParticle(ctx, p, q) {
    const s = Math.max(1, Math.round(q.k / 26));
    let c = '#ffffff';
    switch (p.kind) {
      case 'pollen': c = '#fff3a0'; break;
      case 'firefly': if (Math.sin(p.ph * 3) < 0) return; c = '#e8ff7a'; ctx.fillStyle = 'rgba(232,255,122,.25)'; ctx.fillRect(q.x - 2, q.y - 2, 5, 5); break;
      case 'ember': c = p.y > 2.5 ? '#ff6a2a' : '#ffd45e'; break;
      case 'sand': c = '#fff0c8'; break;
      case 'bubble': ctx.strokeStyle = 'rgba(200,240,255,.8)'; ctx.strokeRect(Math.round(q.x) + 0.5, Math.round(q.y) + 0.5, s + 1, s + 1); return;
      case 'dust': c = 'rgba(200,190,230,.6)'; break;
      case 'sparkle': if (Math.sin(p.ph * 4) < 0.2) return; ctx.fillStyle = Math.sin(p.ph) > 0 ? '#ffffff' : this.L.rim; ctx.fillRect(Math.round(q.x) - 1, Math.round(q.y), 3, 1); ctx.fillRect(Math.round(q.x), Math.round(q.y) - 1, 1, 3); return;
      case 'feather': ctx.fillStyle = '#fff0fa'; ctx.fillRect(Math.round(q.x), Math.round(q.y), 3, 1); return;
      case 'wisp': ctx.fillStyle = `rgba(190,170,255,${(0.25 + 0.2 * Math.sin(p.ph * 2)).toFixed(3)})`; ctx.fillRect(Math.round(q.x), Math.round(q.y), s * 3, s * 2); return;
      case 'rain': ctx.fillStyle = 'rgba(190,215,255,.6)'; ctx.fillRect(Math.round(q.x), Math.round(q.y), 1, s * 4); return;
      case 'spray': c = 'rgba(255,255,255,.7)'; break;
      default: break;
    }
    ctx.fillStyle = c;
    ctx.fillRect(Math.round(q.x), Math.round(q.y), s, s);
  }

  drawReactions(ctx, dt) {
    const SH = { hearts: ['.#.#.', '#####', '#####', '.###.', '..#..'], note: ['..##', '..#.', '..#.', '###.', '##..'], sparkle: ['..#..', '..#..', '##.##', '..#..', '..#..'], munch: ['#.#', '.#.', '#.#'], sleep: ['###', '..#', '.#.', '###'], sad: ['.#.', '###', '###'], dizzy: ['#...#', '.#.#.', '..#..', '.#.#.', '#...#'] };
    const COL = { hearts: '#ff5d8f', note: '#7db8ff', sparkle: '#ffd45e', munch: '#c98a4a', sleep: '#ffffff', sad: '#7db8ff', dizzy: '#ffd45e' };
    this.reacts = this.reacts.filter((r) => { r.t += dt; return r.t < r.life; });
    for (const r of this.reacts) {
      if (r.t < 0) continue;
      const b = this.hits.find((h) => h.uid === r.uid);
      if (!b) continue;
      const rows = SH[r.kind] ?? SH.hearts;
      const sc = 3;
      const x = Math.round((b.x0 + b.x1) / 2 + r.dx * 20 - 5), y = Math.round(b.y0 - 6 - r.t * 18);
      ctx.globalAlpha = Math.min(1, (r.life - r.t) * 2);
      ctx.fillStyle = COL[r.kind] ?? '#ff5d8f';
      rows.forEach((row, j) => [...row].forEach((ch, i) => { if (ch === '#') ctx.fillRect(x + i * sc, y + j * sc, sc, sc); }));
      ctx.globalAlpha = 1;
    }
  }

  label(ctx, text, x, y, color = '#ffffff', bare = false) {
    text = brandText(String(text));
    ctx.font = `600 ${bare ? 22 : 15}px "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif`;
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'left';
    const w = Math.ceil(ctx.measureText(text).width);
    const lx = Math.round(x - w / 2), ly = Math.round(y);
    if (!bare) {
      ctx.fillStyle = 'rgba(12,14,24,.72)';
      ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(lx - 9, ly - 13, w + 18, 26, 13); else ctx.rect(lx - 9, ly - 13, w + 18, 26); ctx.fill();
    }
    ctx.fillStyle = color;
    ctx.fillText(text, lx, ly + 1);
  }

  start() {
    if (this.running) return;
    this.running = true;
    let last = performance.now(), acc = 0;
    const loop = (now) => {
      if (!this.running) return;
      now = Number.isFinite(now) ? now : performance.now();
      const dt = Math.max(0, Math.min(0.1, (now - last) / 1000));
      last = now; acc += dt;
      this.raf = requestAnimationFrame(loop);
      if (acc >= 1 / 45) {
        const step = acc; acc = 0;
        try { this.frame(step); } catch (e) { if (!this.warned) { this.warned = true; console.error('R.A.N.C.H. frame failed', e); } }
      }
    };
    this.raf = requestAnimationFrame(loop);
  }
  stop() { this.running = false; cancelAnimationFrame(this.raf); }
  destroy() { this.stop(); this.ro?.disconnect(); if (typeof window !== 'undefined' && window.__yard === this) window.__yard = null; }
}

export { HABITAT_LOOKS };

/** Which physics toy an item behaves like (by its id or name). */
export function toyKindOf(item) {
  const s = `${item?.id ?? ''} ${item?.name ?? ''}`.toLowerCase();
  for (const k of ['duck', 'plush', 'bell', 'disc', 'feather', 'ribbon']) if (s.includes(k)) return k;
  if (/doll|teddy|soft/.test(s)) return 'plush';
  if (/frisbee|saucer|ring/.test(s)) return 'disc';
  if (/wand|string/.test(s)) return 'feather';
  return 'ball';
}
/** Toys everyone owns besides CARE_TOYS (never anyone's favourite, just fun). */
export const EXTRA_TOYS = [{ id: 'duck', name: 'Squeaky duck' }, { id: 'disc', name: 'Flying disc' }];
