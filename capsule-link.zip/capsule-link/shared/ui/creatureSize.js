// How big a creature is drawn. Sizes follow each species' real height (the "height"/"heightm"
// column of your data, in metres), squeezed so a tiny bug is still visible and a skyscraper-sized
// one still leaves room for the rest of the yard. Sprites are measured by their visible pixels,
// so a 96 px sprite with lots of empty space and a tightly cropped 32 px one come out the same.

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const REF_HEIGHT = 1;
// Tuned on two creatures: a 0.7 m one (Bulbasaur-sized) is drawn at 0.31 and a 14.5 m one
// (Wailord-sized) at 2.86, which is as big as anything gets. In between it follows
// height^0.73, so a 10x taller creature is drawn about 5.4x taller.
const CURVE = 0.73, K = 0.407;
export const MIN_FACTOR = 0.154, MAX_FACTOR = 2.86;

/** Height in metres: the data set's if it has one, otherwise a guess from its base stats. */
export function heightOf(sp) {
  const h = Number(sp?.height);
  if (Number.isFinite(h) && h > 0) return h;
  const s = sp?.baseStats;
  const bst = s ? ['hp', 'atk', 'def', 'spa', 'spd', 'spe'].reduce((n, k) => n + (Number(s[k]) || 0), 0) : 0;
  if (!bst) return REF_HEIGHT;
  return bst < 300 ? 0.45 : bst < 400 ? 0.75 : bst < 480 ? 1.1 : bst < 540 ? 1.6 : 2.2;
}

/** How big a creature is drawn (MIN_FACTOR … MAX_FACTOR); a 1 m creature is about 0.41. */
export function sizeFactor(sp) {
  return clamp(K * Math.pow(heightOf(sp) / REF_HEIGHT, CURVE), MIN_FACTOR, MAX_FACTOR);
}

/** The desktop buddy is alone on screen: a softer curve where a 1 m creature is 1. */
export function petFactor(sp) {
  return Math.sqrt(sizeFactor(sp) / K);
}

// ---------- each creature's own size ----------
// Like the games' size scale: every creature is a little bigger or smaller than its species'
// average, up to 20% either way, most of them near the middle. It's fixed for life (worked out
// from its id, or from c.sizeScalar 0-255 if it came with one).
export const SIZE_LABELS = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL'];
export function sizeVariant(c) {
  if (!c?.uid) return { mult: 1, label: 'M', v: 0 };
  let v;
  if (Number.isFinite(c.sizeScalar)) v = (Math.max(0, Math.min(255, c.sizeScalar)) / 255) * 2 - 1;
  else {
    let h = 2166136261;
    for (const ch of String(c.uid)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
    v = (h & 0xffff) / 0xffff + (h >>> 16) / 0xffff - 1; // two dice: most land near the middle
  }
  return { mult: 1 + 0.2 * v, label: SIZE_LABELS[Math.round(((v + 1) / 2) * 6)], v };
}

/**
 * The visible part of a sprite's first idle frame, as fractions of the frame:
 * { top, bottom, left, right, h }. Cached on the sprite entry until its frames change.
 */
export function spriteBox(entry) {
  const img = entry?.frames?.idle?.[0];
  if (!img) return FULL;
  if (entry.boxOf === img) return entry.box;
  let box = FULL;
  try {
    const w = img.width, h = img.height;
    const d = img.getContext('2d').getImageData(0, 0, w, h).data;
    let x0 = w, x1 = -1, y0 = h, y1 = -1;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if (d[(y * w + x) * 4 + 3] > 24) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
      }
    }
    // a sprite that is almost all empty is probably a mistake: don't blow it up
    if (x1 >= 0 && (y1 - y0 + 1) >= h * 0.15) box = { left: x0 / w, right: (x1 + 1) / w, top: y0 / h, bottom: (y1 + 1) / h, h: (y1 - y0 + 1) / h };
  } catch { /* pixels not readable: use the whole frame */ }
  entry.box = box; entry.boxOf = img;
  return box;
}
const FULL = Object.freeze({ left: 0, right: 1, top: 0, bottom: 1, h: 1 });

/**
 * Where to draw a frame so its visible part is `visible` pixels tall and stands on `groundY`.
 * Returns { size, top, box } — size is the square frame's side, top its top edge.
 */
export function fitSprite(entry, visible, groundY) {
  const box = spriteBox(entry);
  const size = visible / box.h;
  return { size, top: groundY - box.bottom * size, box };
}
