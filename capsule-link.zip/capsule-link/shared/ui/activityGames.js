// Activities, played in the same 2.5D world as the R.A.N.C.H. (PC and phone). Your creature is right there
// with you, and how it helps depends on its nature (engine: activities.js → aptitude):
//   cooking       wash and rinse in a spinning basin (you and your creature take turns to splash), season it
//                 the way they like, keep the fire just right, stir
//   gardening     from above: weeds sprout between the crops and grow into flowers and thistles; pull them,
//                 water thirsty plants; your creature pulls weeds too
//   fishing       you hold the rod and the line drifts in the pond; wait for your creature's call to reel in,
//                 then keep the line tight until the fish is landed
//   scavenging    your creature sniffs about; time each sniff right to steer it, until it digs, rummages
//                 through the bushes, or dives into the clouds, and finds something
//   obstacle      a circular track: the camera runs along behind them while you drag up to run, left and
//                 right to change lanes, down to slide under bars; hurdles need speed
//   puzzle        match the pairs; if you get stuck, your creature thinks hard and shows you what it thinks
//   training      use its moves on dummies, cans and targets (move effects from Showdown, or its type's)
//   photography   frame them with the viewfinder and catch them mid-pose
// Every activity stops completely when it's closed.
import { Yard } from './yard.js';
import { buildArt } from './buildArt.js';
import * as Paint from './paint.js';
import { actorFor } from './actor.js';
import { sfx, creatureCry } from './audio.js';
import { moveFx, fxImage, TYPE_FX } from './moveFx.js';
import { speciesOf } from '../engine/index.js';

const SCENE = { cooking: ['room', 'meadow'], gardening: ['room', 'meadow'], fishing: ['room', 'marsh'], scavenging: ['room', null], obstacle: ['yard', 'meadow'], puzzle: ['room', 'crystal'], training: ['room', 'outskirts'], photography: ['room', 'forest'] };
const GRASSY = new Set(['meadow', 'forest', 'marsh', 'outskirts', 'spooky']);
const CLOUDY = new Set(['skyline', 'starfield']);

/**
 * Run an activity in `container`. Returns { stop() } (always call stop when leaving: nothing keeps running).
 * opts: { bank, idx, c (creature), actId, apt (0…1), extra, clothesImg, resolveTexture, onDone(perf, { photo, moves }) }
 */
export function runActivity(container, opts) {
  const { bank, idx, c, actId, apt, extra = {}, onDone } = opts;
  const [scene, biome0] = SCENE[actId] ?? ['room', 'meadow'];
  const sp = speciesOf(idx, c);
  const biome = biome0 ?? (sp?.habitat && sp.habitat !== 'seafloor' ? sp.habitat : 'meadow');
  const canvas = document.createElement('canvas');
  canvas.className = 'act-canvas';
  canvas.tabIndex = 0;
  container.append(canvas);
  let game = null, last = performance.now(), stopped = false;
  const yard = new Yard(canvas, { bank, scene, biome, seed: 7, yardSize: 0, resolveTexture: opts.resolveTexture, overlay: (ctx) => {
    const now = performance.now(), dt = Math.min(0.05, (now - last) / 1000); last = now;
    if (!game || stopped) return;
    try { game.frame(dt, ctx); } catch (e) { console.error(e); }
    if (game.done && !stopped) { stopped = true; setTimeout(() => { finish(); onDone?.(game.perf ?? 0, { photo: game.photo ?? null, moves: game.used ?? null }); }, 50); }
  } });
  yard.inputLocked = true;
  yard.roomFeatures = true;
  yard.setCreatures([actorFor(idx, c, { clothesImg: opts.clothesImg })]);
  yard.materialize();
  const uid = c.uid;
  const ctx0 = {
    yard, canvas, idx, c, apt, extra, biome, grassy: GRASSY.has(biome), cloudy: CLOUDY.has(biome), resolve: opts.resolveTexture ?? (() => null),
    actor: () => yard.actors.get(uid),
    place: (x, z) => { const q = yard.actors.get(uid); if (q) { q.x = x; q.z = z; q.tx = x; q.tz = z; } },
    /**
     * Put them somewhere they fit: big creatures (and fliers, who hover) step further back until the top of
     * their head (plus `top` pixels for a thought bubble) is on screen. Very big ones are shown a little smaller.
     */
    stage: (x, z, { top = 90, maxZ = yard.S.z1, hover = 0.3 } = {}) => {
      const q = yard.actors.get(uid); if (!q) return;
      yard.updateCamera();
      if (q.fly) { q.hoverY = hover; q.y = hover; }
      const headY = (zz) => { const p = yard.project(x, yard.heightOf(q) + (q.fly ? hover : 0), zz); return p ? p.y : -999; };
      let zz = z;
      while (headY(zz) < top && zz < maxZ) zz += 0.12;
      for (let i = 0; i < 12 && headY(zz) < top; i++) q.sizeMul = Math.max(0.3, (q.sizeMul ?? 1) * 0.9);
      // and all of them inside the picture, side to side
      const half = yard.heightOf(q) * 0.5;
      for (let i = 0; i < 30; i++) {
        const l = yard.project(x - half, 0, zz), r = yard.project(x + half, 0, zz);
        if (l && l.x < yard.W * 0.04) x += 0.12; else if (r && r.x > yard.W * 0.96) x -= 0.12; else break;
      }
      q.x = x; q.z = zz; q.tx = x; q.tz = zz;
      return zz;
    },
    walk: (x, z, speed) => yard.walkTo(uid, x, z, speed ?? 1.2 + apt),
    emote: (face) => yard.emote(uid, face, false),
    hop: () => { const q = yard.actors.get(uid); if (q) q.hop = 1; },
    pose: (s = 'happy', t = 1.2) => { const q = yard.actors.get(uid); if (q) { q.state = s; q.timer = t; } },
    cry: (mood) => { try { creatureCry(sp, c, { mood }); } catch { /* sound off */ } },
    box: () => yard.actorBox(uid),
    toBuf: (e) => yard.toBuf(e),
  };
  yard.puppet(uid);
  game = GAMES[actId](ctx0);
  yard.start();
  canvas.focus();
  function finish() { game?.dispose?.(); yard.destroy(); canvas.remove(); }
  return { canvas, yard, stop() { if (!stopped) { stopped = true; finish(); } else { try { yard.destroy(); canvas.remove(); } catch { /* gone */ } } } };
}

// ---------- drawing helpers ----------
export function text(ctx, s, x, y, { size = 18, color = '#fff', align = 'center', weight = 700 } = {}) {
  ctx.font = `${weight} ${size}px "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif`; ctx.textAlign = align; ctx.textBaseline = 'middle';
  ctx.fillStyle = 'rgba(10,8,30,.6)'; ctx.fillText(s, x + 1.5, y + 1.5); ctx.fillStyle = color; ctx.fillText(s, x, y); ctx.textAlign = 'start';
}
function panel(ctx, x, y, w, h, { fill = 'rgba(14,12,34,.78)', stroke = 'rgba(125,255,207,.5)', r = 12 } = {}) {
  ctx.fillStyle = fill; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, w, h, r) : ctx.rect(x, y, w, h); ctx.fill();
  ctx.strokeStyle = stroke; ctx.lineWidth = 2; ctx.stroke();
}
function hint(ctx, W, s) { text(ctx, s, W / 2, 22, { size: 15, weight: 600, color: '#e9fff8' }); }
function banner(ctx, W, H, s, t) { if (t <= 0) return; ctx.globalAlpha = Math.min(1, t * 2); text(ctx, s, W / 2, H * 0.32, { size: 34, color: '#fff6a0' }); ctx.globalAlpha = 1; }
/** A thought bubble above someone's head (b: their screen box), drawing `inside(cx, cy)` in it. */
function thought(ctx, b, w, h, inside) {
  if (!b) return;
  const cx = Math.max(w / 2 + 6, (b.x0 + b.x1) / 2 + 30), cy = Math.max(h / 2 + 34, b.y0 - h / 2 - 22);
  ctx.fillStyle = 'rgba(255,255,255,.96)'; ctx.strokeStyle = '#2a2448'; ctx.lineWidth = 2;
  for (const [dx, dy, r] of [[-22, h / 2 + 12, 4], [-14, h / 2 + 4, 6]]) { ctx.beginPath(); ctx.arc(cx + dx, cy + dy, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); }
  ctx.beginPath(); ctx.roundRect ? ctx.roundRect(cx - w / 2, cy - h / 2, w, h, h / 2) : ctx.rect(cx - w / 2, cy - h / 2, w, h); ctx.fill(); ctx.stroke();
  inside(cx, cy);
}
/** A moving marker on a bar with a target zone. Returns the bar's box. */
function slider(ctx, x, y, w, pos, center, zone, { h = 20 } = {}) {
  panel(ctx, x - 6, y - 6, w + 12, h + 12, { r: 8 });
  ctx.fillStyle = '#3fb26a'; ctx.fillRect(x + (center - zone / 2) * w, y, zone * w, h);
  ctx.fillStyle = '#9ff0b8'; ctx.fillRect(x + (center - zone / 6) * w, y, (zone / 3) * w, h);
  ctx.fillStyle = '#ffffff'; ctx.fillRect(x + pos * w - 3, y - 7, 6, h + 14);
}
function on(el, type, fn, opt) { el.addEventListener(type, fn, opt); return () => el.removeEventListener(type, fn, opt); }
function keysOrClick(canvas, fn) {
  const offs = [on(canvas, 'pointerdown', (e) => { e.preventDefault(); fn(e); }), on(canvas, 'keydown', (e) => { if (e.code === 'Space' || e.key === 'Enter') { e.preventDefault(); fn(e); } })];
  return () => offs.forEach((f) => f());
}

// ---------- the games ----------
export const GAMES = {
  // ===== cooking: wash and rinse, season, heat, stir =====
  cooking(g0) {
    const { yard, canvas, apt, extra, c, idx } = g0;
    const tw = (speciesOf(idx, c)?.types ?? []).map((t) => `${t} ${idx.types.get(t)?.name ?? ''}`).join(' ').toLowerCase();
    const wants = /fire|ember|dragon/.test(tw) ? 'spicy' : /grass|sprout|bug/.test(tw) ? 'fresh' : /poison|dark|shade|ghost/.test(tw) ? 'sour' : /water|tide|ice|frost/.test(tw) ? 'salty' : 'sweet';
    const FLAV = { sweet: ['#ff8fb6', 'Honey'], spicy: ['#e5484d', 'Chili'], fresh: ['#5cbf4a', 'Herbs'], sour: ['#ffd23f', 'Citrus'], salty: ['#7ad6ff', 'Sea salt'] };
    yard.setDecor([
      { ...buildArt('table'), x: -2.2, z: 3.4, kind: 'table' },
      { ...buildArt('campfire'), x: 0.7, z: 3.0, kind: 'campfire' },
      { ...buildArt('pot'), x: 0.7, z: 3.02, kind: 'pot' },
      { ...buildArt('jar', '#ff8fb6'), x: -2.8, z: 3.3, kind: 'jar' }, { ...buildArt('jar', '#e5484d'), x: -2.3, z: 3.25, kind: 'jar' }, { ...buildArt('jar', '#5cbf4a'), x: -1.8, z: 3.3, kind: 'jar' },
    ]);
    // stand them where their thought bubble fits on screen, whatever their size
    g0.stage(2.3, 2.0, { top: 130, maxZ: 4.4, hover: 0.15 }); g0.actor().flip = true;
    const color = extra.dish?.color ?? '#c0306a';
    const g = { t: 0, phase: 0, scores: [], bannerT: 1.6, bannerText: 'Step 1: wash and rinse!', done: false };
    const PHASES = ['Step 1: wash and rinse!', 'Step 2: season it', 'Step 3: mind the fire', 'Step 4: stir!'];
    // wash: a spinning basin (like a berry blender). Splash when the paddle passes your mark; your creature
    // splashes at its own mark. Every good splash spins it faster and gets things cleaner.
    const wash = { ang: -Math.PI / 2, spin: 1.7, len: 14, t: 0, mine: Math.PI / 2, theirs: -Math.PI / 6, chances: 0, hits: 0, clean: 0, passedMine: false, passedTheirs: false, flash: 0, msg: '', theirMsg: 0, bubbles: [] };
    const angDiff = (a1, a2) => { let d = (a1 - a2) % (Math.PI * 2); if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2; return d; };
    // season
    const season = { round: 0, of: 2, think: 0, picked: null, sum: 0, opts: [] };
    const newSeason = () => { const keys = Object.keys(FLAV).filter((k) => k !== wants).sort(() => Math.random() - 0.5).slice(0, 2); season.opts = [...keys, wants].sort(() => Math.random() - 0.5); season.think = 0; season.picked = null; };
    newSeason();
    // heat
    const heat = { v: 0.3, vel: 0, hold: false, inZone: 0, time: 0, len: 9, zone: [0.55, 0.78] };
    // stir
    const stir = { round: 0, of: 3, hits: 0, pos: 0, dir: 1, speed: 0.9, zone: 0.12 + apt * 0.14, center: 0.5, flash: 0, msg: '' };
    const next = (score) => { g.scores.push(Math.max(0, Math.min(1, score))); g.phase++; if (g.phase >= 4) { g.perf = g.scores.reduce((x, y) => x + y, 0) / 4; setTimeout(() => { g.done = true; }, 900); g.bannerText = 'Delicious!'; g.bannerT = 1.4; g0.pose('happy', 2); g0.cry('happy'); return; } g.bannerText = PHASES[g.phase]; g.bannerT = 1.4; if (g.phase === 3) stir.center = 0.3 + Math.random() * 0.4; };
    let jarBoxes = [];
    const press = (e) => {
      if (g.bannerT > 0.4 || g.phase >= 4) return;
      if (g.phase === 0) {
        const d = Math.abs(angDiff(wash.ang, wash.mine));
        const win = 0.32 + apt * 0.12;
        if (d < win) {
          const good = d < win / 2.5;
          wash.hits += good ? 1 : 0.6; wash.spin = Math.min(7, wash.spin + (good ? 0.55 : 0.3)); wash.clean += good ? 0.09 : 0.06;
          wash.msg = good ? 'Splash!' : 'Good'; sfx('blip'); wash.passedMine = true;
          for (let i = 0; i < 8; i++) wash.bubbles.push({ a: Math.random() * 6.28, r: 10 + Math.random() * 40, life: 0.8 });
        } else { wash.msg = 'Miss'; wash.spin = Math.max(1.2, wash.spin - 0.5); sfx('miss'); }
        wash.flash = 0.5;
      } else if (g.phase === 1) {
        if (season.think < 0.6) return;
        const p = e?.clientX != null ? g0.toBuf(e) : null;
        const hit = p && jarBoxes.find((b) => p.x > b.x && p.x < b.x + b.w && p.y > b.y && p.y < b.y + b.h);
        if (!hit) return;
        season.picked = hit.k; const ok = hit.k === wants;
        season.sum += ok ? 1 : 0.2; sfx(ok ? 'heal' : 'miss'); g0.emote(ok ? 'love' : 'frown'); if (ok) g0.hop();
        setTimeout(() => { season.round++; if (season.round >= season.of) next(season.sum / season.of); else newSeason(); }, 700);
      } else if (g.phase === 3) {
        const off = Math.abs(stir.pos - stir.center);
        if (off <= stir.zone / 2) { stir.hits += 1 - off / stir.zone; stir.msg = off < stir.zone / 6 ? 'Perfect!' : 'Nice!'; sfx('heal'); } else { stir.msg = 'Oops!'; sfx('miss'); }
        stir.flash = 0.6; stir.round++; stir.speed += 0.35; stir.center = 0.2 + Math.random() * 0.6;
        if (stir.round >= stir.of) next(stir.hits / stir.of);
      }
    };
    const offs = [keysOrClick(canvas, press),
      on(canvas, 'pointerdown', () => { heat.hold = true; }), on(window, 'pointerup', () => { heat.hold = false; }),
      on(canvas, 'keydown', (e) => { if (e.code === 'Space') heat.hold = true; }), on(canvas, 'keyup', (e) => { if (e.code === 'Space') heat.hold = false; })];
    g.dispose = () => offs.forEach((f) => f());
    g.frame = (dt, ctx) => {
      const W = yard.W, H = yard.H;
      g.t += dt; g.bannerT = Math.max(0, g.bannerT - dt);
      // steam from the pot
      if (Math.random() < dt * 8) yard.sparks.push({ kind: 'gust', x: 0.7 + (Math.random() - 0.5) * 0.4, y: 1.1, z: 3.0, vx: 0, vy: 0.6, vz: 0, life: 1.2, ph: 0, c: 0 });
      if (g.phase === 0) {
        hint(ctx, W, 'Splash when the paddle passes your mark (click or space). Your creature splashes at its own.');
        if (g.bannerT <= 0.4) { wash.t += dt; wash.ang += wash.spin * dt; wash.spin = Math.max(1.2, wash.spin - dt * 0.18); }
        wash.flash = Math.max(0, wash.flash - dt); wash.theirMsg = Math.max(0, wash.theirMsg - dt);
        // each time the paddle comes round to a mark: a chance (missed if you didn't splash)
        const dm = angDiff(wash.ang, wash.mine), dtm = angDiff(wash.ang, wash.theirs);
        if (dm > 0.45 && dm < 0.7) { if (!wash.counted) { wash.chances++; wash.counted = true; } } else if (Math.abs(dm) < 0.4) wash.counted = false;
        if (Math.abs(dtm) < 0.12 && !wash.passedTheirs) {
          wash.passedTheirs = true;
          if (Math.random() < 0.45 + apt * 0.5) { wash.spin = Math.min(7, wash.spin + 0.45); wash.clean += 0.05; wash.theirMsg = 0.6; g0.hop(); sfx('move'); for (let i = 0; i < 6; i++) wash.bubbles.push({ a: wash.theirs + (Math.random() - 0.5), r: 30 + Math.random() * 30, life: 0.8 }); }
        } else if (Math.abs(dtm) > 0.5) wash.passedTheirs = false;
        const cx = W / 2, cy = H - 110, R = 78;
        // the basin
        ctx.fillStyle = 'rgba(14,12,34,.55)'; ctx.beginPath(); ctx.ellipse(cx, cy + 8, R + 16, R * 0.62 + 14, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#e8eef8'; ctx.beginPath(); ctx.ellipse(cx, cy, R + 10, R * 0.62 + 8, 0, 0, Math.PI * 2); ctx.fill();
        const water = ctx.createRadialGradient(cx, cy, 6, cx, cy, R); water.addColorStop(0, '#bfe9ff'); water.addColorStop(1, `rgba(${Math.round(140 - wash.clean * 60)},${Math.round(150 + wash.clean * 40)},${Math.round(120 + wash.clean * 120)},1)`);
        ctx.fillStyle = water; ctx.beginPath(); ctx.ellipse(cx, cy, R, R * 0.6, 0, 0, Math.PI * 2); ctx.fill();
        // swirl lines
        ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 2;
        for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.ellipse(cx, cy, R * (0.3 + i * 0.22), R * 0.6 * (0.3 + i * 0.22), 0, wash.ang * (1.2 - i * 0.2), wash.ang * (1.2 - i * 0.2) + 1.6); ctx.stroke(); }
        // the ingredients bobbing round (dirt specks fade as it gets cleaner)
        for (let i = 0; i < 4; i++) {
          const a = wash.ang * 0.8 + i * (Math.PI / 2), bx = cx + Math.cos(a) * R * 0.45, by = cy + Math.sin(a) * R * 0.27;
          ctx.fillStyle = color; ctx.beginPath(); ctx.arc(bx, by, 11, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = `rgba(90,60,30,${Math.max(0, 0.8 - wash.clean).toFixed(2)})`; ctx.fillRect(bx - 5, by - 3, 3, 3); ctx.fillRect(bx + 3, by + 2, 3, 3);
        }
        // marks: yours (bottom) and theirs
        const mark = (a, col, label) => { const mx = cx + Math.cos(a) * (R + 14), my = cy + Math.sin(a) * (R * 0.6 + 12); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(mx, my, 9, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke(); text(ctx, label, mx, my + 20, { size: 11 }); };
        mark(wash.mine, '#3fb26a', 'you'); mark(wash.theirs, '#ffd23f', 'them');
        // the paddle
        const px = cx + Math.cos(wash.ang) * R, py = cy + Math.sin(wash.ang) * R * 0.6;
        ctx.strokeStyle = '#8a5a34'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(px, py); ctx.stroke();
        ctx.fillStyle = '#c89a60'; ctx.beginPath(); ctx.ellipse(px, py, 10, 7, wash.ang, 0, Math.PI * 2); ctx.fill();
        for (const b of wash.bubbles) { b.life -= dt; b.r += dt * 30; const bx = cx + Math.cos(b.a) * b.r, by = cy + Math.sin(b.a) * b.r * 0.6 - (0.8 - b.life) * 30; ctx.strokeStyle = `rgba(255,255,255,${Math.max(0, b.life).toFixed(2)})`; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(bx, by, 4, 0, Math.PI * 2); ctx.stroke(); }
        wash.bubbles = wash.bubbles.filter((b) => b.life > 0);
        // clean-o-meter and speed
        panel(ctx, W / 2 - 160, H - 26, 320, 18, { r: 6 }); ctx.fillStyle = '#7ad6ff'; ctx.fillRect(W / 2 - 154, H - 22, 308 * Math.min(1, wash.clean), 10);
        text(ctx, `clean ${Math.round(Math.min(1, wash.clean) * 100)}% · speed ${wash.spin.toFixed(1)}`, W / 2, H - 38, { size: 12 });
        if (wash.flash > 0) text(ctx, wash.msg, cx, cy - R * 0.6 - 26, { size: 24, color: wash.msg === 'Miss' ? '#ff9a9a' : '#fff6a0' });
        if (wash.theirMsg > 0) text(ctx, 'Splash!', cx + Math.cos(wash.theirs) * (R + 30), cy + Math.sin(wash.theirs) * R * 0.6 - 30, { size: 16, color: '#ffe48a' });
        if (wash.clean >= 1 || wash.t >= wash.len) next(Math.min(1, wash.clean * 0.75 + (wash.chances ? wash.hits / wash.chances : 0) * 0.25));
      } else if (g.phase === 1) {
        hint(ctx, W, 'Watch your creature: which flavour does it want?');
        season.think += dt;
        if (season.think > 0.4 && season.think < 0.5) g0.emote('question');
        // a thought bubble with the flavour it wants (clearer for good cooks); always kept on screen
        if (season.think > 0.6 && season.picked == null) {
          thought(ctx, g0.box(), 112, 52, (bx, by) => {
            ctx.globalAlpha = Math.min(1, 0.45 + apt); ctx.fillStyle = FLAV[wants][0]; ctx.beginPath(); ctx.arc(bx - 26, by, 12, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1;
            text(ctx, apt > 0.4 ? FLAV[wants][1] : '…?', bx + 12, by, { size: 13, color: '#2a2448' });
          });
        }
        jarBoxes = season.opts.map((k, i) => ({ k, x: W / 2 - 210 + i * 145, y: H - 130, w: 130, h: 96 }));
        for (const jb of jarBoxes) {
          panel(ctx, jb.x, jb.y, jb.w, jb.h, { fill: season.picked === jb.k ? (jb.k === wants ? 'rgba(63,178,106,.9)' : 'rgba(229,72,77,.85)') : 'rgba(14,12,34,.8)' });
          ctx.fillStyle = FLAV[jb.k][0]; ctx.fillRect(jb.x + jb.w / 2 - 16, jb.y + 14, 32, 40); ctx.fillStyle = '#8a5a34'; ctx.fillRect(jb.x + jb.w / 2 - 19, jb.y + 8, 38, 8);
          text(ctx, FLAV[jb.k][1], jb.x + jb.w / 2, jb.y + 74, { size: 15 });
        }
      } else if (g.phase === 2) {
        hint(ctx, W, 'Hold to stoke the fire, let go to cool it: keep it in the green');
        heat.time += dt;
        const drift = (Math.sin(g.t * 1.7) + Math.sin(g.t * 3.1) * 0.5) * (0.25 - apt * 0.15);
        heat.vel += ((heat.hold ? 0.9 : -0.6) + drift) * dt; heat.vel *= Math.pow(0.4, dt);
        heat.v = Math.max(0, Math.min(1, heat.v + heat.vel * dt));
        // a fire creature lends a hand when it drops too low
        if (apt > 0.5 && heat.v < heat.zone[0] - 0.1 && Math.random() < dt * 2) { heat.vel += 0.4; g0.hop(); }
        const inZ = heat.v >= heat.zone[0] && heat.v <= heat.zone[1];
        if (inZ) heat.inZone += dt;
        if (Math.random() < dt * (4 + heat.v * 24)) yard.sparks.push({ kind: 'ember', x: 0.7 + (Math.random() - 0.5) * 0.5, y: 0.2, z: 2.95, vx: (Math.random() - 0.5) * 0.3, vy: 0.6 + heat.v, vz: 0, life: 0.8, ph: 0, c: Math.random() < 0.5 ? 0 : 1 });
        const gx = W - 90, gy = 70, gh = H - 170;
        panel(ctx, gx - 12, gy - 12, 48, gh + 24, { r: 10 });
        const grd = ctx.createLinearGradient(0, gy + gh, 0, gy); grd.addColorStop(0, '#3b6cf6'); grd.addColorStop(0.5, '#ffd23f'); grd.addColorStop(1, '#e5484d');
        ctx.fillStyle = grd; ctx.fillRect(gx, gy, 24, gh);
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 3; ctx.strokeRect(gx - 2, gy + (1 - heat.zone[1]) * gh, 28, (heat.zone[1] - heat.zone[0]) * gh);
        ctx.fillStyle = '#ffffff'; ctx.fillRect(gx - 8, gy + (1 - heat.v) * gh - 3, 40, 6);
        const pr = heat.inZone / 4;
        panel(ctx, W / 2 - 160, H - 70, 320, 26, { r: 8 }); ctx.fillStyle = '#3fb26a'; ctx.fillRect(W / 2 - 154, H - 64, 308 * Math.min(1, pr), 14);
        text(ctx, inZ ? 'Just right…' : heat.v < heat.zone[0] ? 'Too cool' : 'Too hot!', W / 2, H - 92, { size: 18, color: inZ ? '#c8ffb0' : '#ffd0a0' });
        if (heat.inZone >= 4) next(1 - Math.max(0, heat.time - 4) / heat.len * 0.6);
        else if (heat.time >= heat.len) next(heat.inZone / 4 * 0.8);
      } else if (g.phase === 3) {
        hint(ctx, W, 'Stir when the marker is in the green');
        stir.pos += stir.dir * stir.speed * dt; if (stir.pos > 1) { stir.pos = 1; stir.dir = -1; } if (stir.pos < 0) { stir.pos = 0; stir.dir = 1; }
        stir.flash = Math.max(0, stir.flash - dt);
        slider(ctx, W / 2 - 220, H - 90, 440, stir.pos, stir.center, stir.zone);
        text(ctx, `Stir ${Math.min(stir.round + 1, stir.of)} of ${stir.of}`, W / 2, H - 115, { size: 15 });
        if (stir.flash > 0) text(ctx, stir.msg, W / 2, H - 150, { size: 26, color: stir.msg === 'Oops!' ? '#ff9a9a' : '#fff6a0' });
      }
      banner(ctx, W, H, g.bannerText, g.bannerT);
      // the dish shows in the pot
      const q = yard.project(0.7, 1.05, 3.0);
      if (q && g.phase > 0) { ctx.fillStyle = color; ctx.beginPath(); ctx.ellipse(q.x, q.y, q.k * 0.42, q.k * 0.1, 0, 0, Math.PI * 2); ctx.fill(); }
    };
    return g;
  },

  // ===== gardening: from above; weeds come up between the crops =====
  gardening(g0) {
    const { yard, canvas, apt } = g0;
    // look down on the beds (more from above than from the side)
    yard.view({ pitch: 0.62, z: 2.9, dist: 1.05, snap: true });
    const rows = [1.9, 2.7, 3.5];
    const COLS = [-2.2, -1.1, 0, 1.1, 2.2];
    // a clear patch for the beds (no trees, logs or mounds in the way)
    yard.setDecor(rows.map((z, i) => ({ img: Paint.raisedBed(i * 10 + 3, { w: 520, h: 34 }), h: 0.36, x: 0, z: z + 0.04, kind: 'bed' })));
    yard.props = (yard.props ?? []).filter((p) => p.decor || ['tuft', 'flower'].includes(p.kind) || !(p.x > -3.6 && p.x < 3.6 && p.z < 4.8));
    const crops = rows.flatMap((z) => COLS.map((x) => ({ x, z, thirst: 0, water: 0, pop: 0, wilt: 0 })));
    // weeds grow in the gaps between crops: a sprout, then leaves, then a dandelion, clover or thistle in flower
    const gaps = rows.flatMap((z) => COLS.slice(0, -1).map((x) => ({ x: x + 0.55, z: z + 0.02, weed: 0, kind: 0, pop: 0 })));
    const WEEDS = [{ name: 'dandelion', flower: '#ffd23f', leaf: '#5aa83a' }, { name: 'clover', flower: '#ff9ad0', leaf: '#3f9a4a' }, { name: 'thistle', flower: '#b066e0', leaf: '#7a9a3a' }];
    g0.stage(-3.4, 1.5, { top: 60 });
    const g = { t: 0, len: 26, handled: 0, missed: 0, next: 0.8, helperT: 1.5, cursor: null, down: false, done: false };
    const offs = [
      on(canvas, 'pointermove', (e) => { g.cursor = g0.toBuf(e); }),
      on(canvas, 'pointerdown', (e) => { g.cursor = g0.toBuf(e); g.down = true; pick(g.cursor); }),
      on(window, 'pointerup', () => { g.down = false; }),
    ];
    const near = (q, p, k = 0.5) => q && Math.abs(p.x - q.x) < q.k * k && Math.abs(p.y - q.y + q.k * 0.15) < q.k * (k + 0.1);
    function pick(p) {
      // the closest weed under the pointer
      const hit = gaps.filter((s) => s.weed > 0).map((s) => ({ s, q: yard.project(s.x, 0, s.z) })).filter(({ q }) => near(q, p, 0.42)).sort((a, b) => Math.hypot(a.q.x - p.x, a.q.y - p.y) - Math.hypot(b.q.x - p.x, b.q.y - p.y))[0];
      if (hit) { hit.s.weed = 0; hit.s.pop = 0.5; g.handled++; sfx('blip'); for (let i = 0; i < 5; i++) yard.sparks.push({ kind: 'leaf', x: hit.s.x, y: 0.15, z: hit.s.z, vx: (Math.random() - 0.5) * 2, vy: 1.4, vz: 0, g: 6, life: 0.7, ph: 0, c: Math.random() < 0.5 ? 0 : 1 }); }
    }
    g.dispose = () => offs.forEach((f) => f());
    g.frame = (dt, ctx) => {
      const W = yard.W, H = yard.H;
      g.t += dt; g.next -= dt; g.helperT -= dt;
      if (g.t < g.len && g.next <= 0) {
        if (Math.random() < 0.62) { const free = gaps.filter((s) => !s.weed); if (free.length) { const s = free[Math.floor(Math.random() * free.length)]; s.weed = 0.01; s.kind = Math.floor(Math.random() * WEEDS.length); } }
        else { const free = crops.filter((s) => !s.thirst && !s.wilt); if (free.length) free[Math.floor(Math.random() * free.length)].thirst = 0.01; }
        g.next = 0.6 + Math.random() * 0.8 - Math.min(0.3, g.t / 80);
      }
      for (const s of gaps) {
        s.pop = Math.max(0, s.pop - dt);
        if (s.weed > 0) {
          s.weed += dt * 0.09;
          // fully grown: it seeds and smothers the crop next to it
          if (s.weed >= 1) { s.weed = 0; g.missed++; const cr = crops.find((q) => Math.abs(q.z - s.z) < 0.1 && Math.abs(q.x - (s.x - 0.55)) < 0.1); if (cr) cr.wilt = 3; sfx('back'); }
        }
      }
      for (const s of crops) {
        s.pop = Math.max(0, s.pop - dt); s.wilt = Math.max(0, s.wilt - dt);
        if (s.thirst > 0) { s.thirst += dt * 0.08; if (s.thirst >= 1) { s.thirst = 0; s.wilt = 3; g.missed++; } }
        const q = yard.project(s.x, 0, s.z);
        if (s.thirst > 0 && g.down && g.cursor && near(q, g.cursor, 0.55)) {
          s.water += dt; if (Math.random() < dt * 20) yard.sparks.push({ kind: 'drop', x: s.x + (Math.random() - 0.5) * 0.3, y: 0.9, z: s.z, vx: 0, vy: -1, vz: 0, g: 6, life: 0.5, ph: 0, c: 0 });
          if (s.water > 0.7) { s.thirst = 0; s.water = 0; s.pop = 0.5; g.handled++; sfx('heal'); }
        }
      }
      // your helper goes after the biggest weeds by itself (better gardeners, more often)
      const a = g0.actor();
      if (g.helperT <= 0 && !a.goTo) {
        const w = gaps.filter((s) => s.weed > 0.35).sort((p, q2) => q2.weed - p.weed)[0];
        if (w) { g0.walk(w.x, w.z - 0.35); g.target = w; }
        g.helperT = 3.2 - apt * 2;
      }
      if (g.target && !a.goTo) { if (g.target.weed > 0) { g.target.weed = 0; g.target.pop = 0.5; g.handled++; g0.hop(); } g.target = null; }
      // crops
      for (const s of crops) {
        const q = yard.project(s.x, 0, s.z); if (!q) continue;
        const k = q.k, droop = s.thirst * 0.3;
        const leaf = s.wilt > 0 ? '#8a7a4a' : s.thirst > 0.5 ? '#9a9a4a' : '#3fb26a';
        ctx.fillStyle = 'rgba(40,24,10,.35)'; ctx.beginPath(); ctx.ellipse(q.x, q.y, k * 0.16, k * 0.06, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = leaf;
        ctx.fillRect(q.x - k * 0.025, q.y - k * 0.3 + droop * k, k * 0.05, k * 0.3 - droop * k);
        for (const [dx, dy, rot] of [[-0.1, -0.24, -0.5], [0.1, -0.22, 0.5], [0, -0.33, 0]]) { ctx.beginPath(); ctx.ellipse(q.x + dx * k, q.y + (dy + droop * 1.1) * k, k * 0.1, k * 0.05, rot + Math.sign(rot) * droop * 3, 0, Math.PI * 2); ctx.fill(); }
        // a ripening berry on healthy plants
        if (!s.wilt && s.thirst < 0.5) { ctx.fillStyle = '#e5484d'; ctx.beginPath(); ctx.arc(q.x + k * 0.05, q.y - k * 0.18, k * 0.035, 0, Math.PI * 2); ctx.fill(); }
        if (s.thirst > 0) text(ctx, '💧', q.x, q.y - k * 0.5, { size: Math.max(14, k * 0.2) });
        if (s.pop > 0) text(ctx, '✓', q.x, q.y - k * 0.6 - (0.5 - s.pop) * 40, { size: 22, color: '#c8ffb0' });
      }
      // weeds: easy to spot from up here, and they get bigger (and burst into flower) as they grow
      for (const s of gaps) {
        const q = yard.project(s.x, 0, s.z); if (!q) continue;
        if (s.pop > 0) text(ctx, '✓', q.x, q.y - q.k * 0.4 - (0.5 - s.pop) * 40, { size: 20, color: '#c8ffb0' });
        if (!(s.weed > 0)) continue;
        const k = q.k, W2 = WEEDS[s.kind], gr = s.weed, hh = k * (0.12 + gr * 0.42);
        ctx.fillStyle = W2.leaf;
        const n = 3 + Math.floor(gr * 4);
        for (let i = 0; i < n; i++) { const ang = (i / n) * Math.PI - Math.PI; const lx = q.x + Math.cos(ang) * k * (0.05 + gr * 0.1), ly = q.y + Math.sin(ang) * k * 0.03; ctx.beginPath(); ctx.ellipse(lx, ly - hh * 0.25, k * (0.03 + gr * 0.04), hh * 0.3, ang + Math.PI / 2, 0, Math.PI * 2); ctx.fill(); }
        if (gr > 0.35) {
          ctx.fillRect(q.x - 1, q.y - hh, 2, hh);
          const fr = k * (0.03 + gr * 0.075);
          ctx.fillStyle = W2.flower; ctx.strokeStyle = 'rgba(40,20,10,.6)'; ctx.lineWidth = 1;
          for (let i = 0; i < 6; i++) { const pa = (i / 6) * Math.PI * 2 + g.t * 0.2; ctx.beginPath(); ctx.arc(q.x + Math.cos(pa) * fr * 0.8, q.y - hh + Math.sin(pa) * fr * 0.8, fr * 0.6, 0, Math.PI * 2); ctx.fill(); }
          ctx.fillStyle = '#fff6a0'; ctx.beginPath(); ctx.arc(q.x, q.y - hh, fr * 0.45, 0, Math.PI * 2); ctx.fill();
        }
        // nearly seeding: a warning ring
        if (gr > 0.75) { ctx.strokeStyle = `rgba(255,120,120,${(0.4 + 0.4 * Math.sin(g.t * 8)).toFixed(2)})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(q.x, q.y - hh * 0.4, k * 0.2, hh * 0.7, 0, 0, Math.PI * 2); ctx.stroke(); }
      }
      if (g.cursor) { ctx.font = '28px sans-serif'; ctx.fillText(g.down ? '🚿' : '🧤', g.cursor.x - 10, g.cursor.y); }
      hint(ctx, W, 'Pull the weeds between the crops before they flower and seed · hold on a drooping plant to water it');
      text(ctx, `${Math.ceil(Math.max(0, g.len - g.t))} s · tended ${g.handled}`, W / 2, H - 24, { size: 16 });
      if (g.t >= g.len + 0.8 && !g.done) { const left = gaps.filter((s) => s.weed > 0).length + crops.filter((s) => s.thirst > 0).length; const total = g.handled + g.missed + left; g.perf = total ? g.handled / total : 1; g.done = true; }
    };
    return g;
  },

  // ===== fishing: wait for the call, then keep the line tight =====
  fishing(g0) {
    const { yard, canvas, apt } = g0;
    const P = { x: 0.8, z: 3.1, r: 1.9 };
    yard.setFeatures([{ id: 'pond', bp: 'pond', x: P.x, z: P.z, life: 1 }]);
    // stand back from the pond: further back the bigger they are (fliers hover low, out of the way)
    g0.stage(-2.4, 1.9, { top: 70, maxZ: 4.6, hover: 0.25 });
    const g = { t: 0, cast: 0, casts: 3, caught: 0, state: 'drift', timer: 2, lure: { x: P.x, z: P.z, vx: 0.2, vz: 0.1 }, fish: [], msg: '', msgT: 0, reel: 0, tension: 0.4, pull: 0, hold: false, slack: 0, done: false, cursor: null };
    for (let i = 0; i < 4; i++) g.fish.push({ x: P.x + (Math.random() - 0.5) * P.r, z: P.z + (Math.random() - 0.5) * P.r * 0.6, a: Math.random() * 6, s: 0.3 + Math.random() * 0.3 });
    const say = (m) => { g.msg = m; g.msgT = 1.2; };
    const nextCast = () => { g.cast++; if (g.cast >= g.casts) { g.state = 'end'; g.perf = g.caught / g.casts; setTimeout(() => { g.done = true; }, 1000); return; } g.state = 'drift'; g.timer = 2 + Math.random() * 3 * (1.3 - apt); g.fake = 0; };
    const press = () => {
      if (g.state === 'bite') { g.state = 'reel'; g.reel = 0; g.tension = 0.45; g.slack = 0; sfx('dock'); say('Reel it in!'); }
      else if (g.state === 'drift' || g.state === 'nibble') { say('Too soon: it swam off'); sfx('back'); g0.emote('frown'); nextCast(); }
    };
    const offs = [on(canvas, 'pointerdown', (e) => { e.preventDefault(); g.hold = true; press(); }), on(window, 'pointerup', () => { g.hold = false; }),
      on(canvas, 'keydown', (e) => { if (e.code === 'Space') { e.preventDefault(); if (!g.hold) press(); g.hold = true; } }), on(canvas, 'keyup', (e) => { if (e.code === 'Space') g.hold = false; }),
      on(canvas, 'pointermove', (e) => { g.cursor = g0.toBuf(e); })];
    g.dispose = () => offs.forEach((f) => f());
    g.frame = (dt, ctx) => {
      const W = yard.W, H = yard.H;
      g.t += dt; g.msgT = Math.max(0, g.msgT - dt);
      const L = g.lure;
      // the line drifts about the pond on its own (and leans a little toward the pointer)
      if (g.state !== 'reel') {
        L.vx += (Math.random() - 0.5) * dt * 0.8; L.vz += (Math.random() - 0.5) * dt * 0.6;
        if (g.cursor) { const fp = yard.floorAt(g.cursor.x, g.cursor.y); if (fp) { L.vx += (fp.x - L.x) * dt * 0.25; L.vz += (fp.z - L.z) * dt * 0.25; } }
        L.vx *= Math.pow(0.5, dt); L.vz *= Math.pow(0.5, dt);
        L.x += L.vx * dt; L.z += L.vz * dt;
        const dx = L.x - P.x, dz = (L.z - P.z) * 1.4, d = Math.hypot(dx, dz);
        if (d > P.r * 0.8) { L.x = P.x + (dx / d) * P.r * 0.8; L.z = P.z + (dz / d) * P.r * 0.8 / 1.4; L.vx *= -0.5; L.vz *= -0.5; }
      }
      // fish shadows
      for (const f of g.fish) {
        const chase = (g.state === 'nibble' || g.state === 'bite') && f === g.fish[0];
        if (chase) { f.x += (L.x - f.x) * dt * 2; f.z += (L.z - f.z) * dt * 2; }
        else { f.a += (Math.random() - 0.5) * dt * 2; f.x += Math.cos(f.a) * f.s * dt; f.z += Math.sin(f.a) * f.s * dt * 0.6; const d = Math.hypot(f.x - P.x, (f.z - P.z) * 1.4); if (d > P.r * 0.85) f.a += Math.PI; }
        const q = yard.project(f.x, 0.02, f.z);
        if (q) { ctx.fillStyle = 'rgba(20,40,80,.35)'; ctx.beginPath(); ctx.ellipse(q.x, q.y, q.k * 0.22, q.k * 0.06, Math.cos(f.a) * 0.3, 0, Math.PI * 2); ctx.fill(); }
      }
      // the creature watches the water and calls it
      if (g.state === 'drift') {
        g.timer -= dt;
        if (g.timer <= 0) {
          // sometimes a false alarm first: a nibble that isn't a bite (good fishers hardly ever fall for these)
          if (Math.random() < 0.5 - apt * 0.35 && !g.fake) { g.state = 'nibble'; g.timer = 0.8 + Math.random(); g.fake = 1; g0.emote('question'); }
          else { g.state = 'bite'; g.timer = 0.45 + apt * 0.6; g0.emote('alert'); g0.hop(); g0.cry('happy'); say('Now!'); sfx('alert'); }
        }
      } else if (g.state === 'nibble') { g.timer -= dt; if (g.timer <= 0) { g.state = 'drift'; g.timer = 0.8 + Math.random() * 1.5; } }
      else if (g.state === 'bite') { g.timer -= dt; if (g.timer <= 0) { say('It got away…'); sfx('back'); g0.emote('frown'); nextCast(); } }
      else if (g.state === 'reel') {
        // hold to reel in (the line tightens); the fish tugs now and then; too tight snaps, too slack lets it go
        g.pull = Math.max(0, g.pull - dt * 2) + (Math.random() < dt * 1.4 ? 0.6 + Math.random() * 0.5 : 0);
        g.tension += ((g.hold ? 0.55 : -0.5) + g.pull * 0.7 - apt * 0.1) * dt;
        g.tension = Math.max(0, Math.min(1.05, g.tension));
        if (g.hold && g.tension < 0.85) g.reel += dt * (0.22 + apt * 0.1);
        if (g.tension < 0.12) g.slack += dt; else g.slack = 0;
        L.x += (-1.4 - L.x) * dt * 0.1 * (g.hold ? 1 : 0); L.z += (1.9 - L.z) * dt * 0.1 * (g.hold ? 1 : 0);
        if (Math.random() < dt * 12) yard.sparks.push({ kind: 'drop', x: L.x, y: 0.1, z: L.z, vx: (Math.random() - 0.5), vy: 1.2, vz: 0, g: 6, life: 0.5, ph: 0, c: 1 });
        if (g.tension >= 1) { say('Snap! Too tight'); sfx('miss'); g0.emote('frown'); nextCast(); }
        else if (g.slack > 1.2) { say('It slipped off…'); sfx('back'); nextCast(); }
        else if (g.reel >= 1) { g.caught++; say('Caught one!'); sfx('level'); g0.emote('love'); g0.pose('happy', 1.5); nextCast(); }
        panel(ctx, W / 2 - 170, H - 86, 340, 62, { r: 10 });
        ctx.fillStyle = 'rgba(255,255,255,.15)'; ctx.fillRect(W / 2 - 160, H - 76, 320, 14);
        ctx.fillStyle = g.tension > 0.8 ? '#e5484d' : g.tension < 0.2 ? '#7a8aa8' : '#3fb26a'; ctx.fillRect(W / 2 - 160, H - 76, 320 * Math.min(1, g.tension), 14);
        ctx.fillStyle = '#ffd23f'; ctx.fillRect(W / 2 - 160, H - 52, 320 * g.reel, 10);
        text(ctx, 'line', W / 2 - 190, H - 69, { size: 11 }); text(ctx, 'catch', W / 2 - 192, H - 47, { size: 11 });
      }
      // the rod and line: from the bottom corner to the lure
      const lq = yard.project(L.x, 0.05, L.z);
      const bob = (g.state === 'nibble' ? Math.sin(g.t * 30) * 3 : g.state === 'bite' ? 8 + Math.sin(g.t * 40) * 4 : Math.sin(g.t * 2) * 2);
      if (lq) {
        const tip = { x: W * 0.22, y: H * 0.42 };
        ctx.strokeStyle = '#5a3a1c'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(W * 0.04, H + 10); ctx.lineTo(tip.x, tip.y); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(tip.x, tip.y); ctx.quadraticCurveTo((tip.x + lq.x) / 2, Math.max(tip.y, lq.y) + (g.state === 'reel' ? -10 + g.tension * 10 : 40), lq.x, lq.y + bob - 6); ctx.stroke();
        ctx.fillStyle = '#e5484d'; ctx.fillRect(lq.x - 5, lq.y + bob - 12, 10, 7); ctx.fillStyle = '#fff'; ctx.fillRect(lq.x - 5, lq.y + bob - 5, 10, 5);
        ctx.strokeStyle = 'rgba(255,255,255,.4)'; ctx.beginPath(); ctx.ellipse(lq.x, lq.y, 10 + (g.t * 20) % 14, 4 + (g.t * 7) % 5, 0, 0, Math.PI * 2); ctx.stroke();
      }
      hint(ctx, W, g.state === 'reel' ? 'Hold to reel · let go when the line gets too tight' : 'Watch your creature: when it calls, click (or press space) to strike!');
      text(ctx, `Cast ${Math.min(g.cast + 1, g.casts)} of ${g.casts} · caught ${g.caught}`, W - 120, H - 20, { size: 14 });
      if (g.msgT > 0) text(ctx, g.msg, W / 2, H * 0.3, { size: 28, color: '#fff6a0' });
    };
    return g;
  },

  // ===== scavenging: steer the sniffing, then dig =====
  scavenging(g0) {
    const { yard, canvas, apt, grassy, cloudy } = g0;
    const S = yard.S;
    if (grassy && !cloudy) yard.setDecor(Array.from({ length: 7 }, (_, i) => ({ img: Paint.bush(40 + i, '#4f9a3f', { flowers: i % 2 ? '#ff8fb6' : null }), h: 0.9, x: -3.6 + i * 1.2, z: 3.9 + (i % 2) * 0.3, kind: 'bush' })));
    g0.stage(0, 2.2, { top: 60 });
    const g = { t: 0, round: 0, rounds: 3, found: 0, steps: 0, misses: 0, pos: 0, dir: 1, speed: 0.8, zone: 0.14 + apt * 0.12, center: 0.5, msg: '', msgT: 0, done: false, dig: 0, look: 0 };
    const newTarget = () => {
      const a = g0.actor();
      for (let i = 0; i < 20; i++) {
        const x = S.x0 + 0.6 + Math.random() * (S.x1 - S.x0 - 1.2), z = grassy && !cloudy ? 3.7 + Math.random() * 0.4 : S.z0 + 0.5 + Math.random() * (S.z1 - S.z0 - 1);
        if (Math.hypot(x - a.x, z - a.z) > 2.2) { g.target = { x, z }; break; }
      }
      g.center = 0.25 + Math.random() * 0.5; g.speed = 0.8 + g.round * 0.15;
    };
    newTarget();
    const press = () => {
      if (g.dig > 0 || g.round >= g.rounds) return;
      const a = g0.actor(), T = g.target;
      const off = Math.abs(g.pos - g.center);
      if (off <= g.zone / 2) {
        // on the scent: a confident step toward it
        const dx = T.x - a.x, dz = T.z - a.z, d = Math.hypot(dx, dz), stp = Math.min(d, 0.75 + apt * 0.35);
        g0.walk(a.x + (dx / d) * stp, a.z + (dz / d) * stp);
        g.msg = off < g.zone / 6 ? 'Got the scent!' : 'This way…'; sfx('heal');
        g.steps++;
        if (d - stp < 0.45) { g.dig = 1.6; g0.emote('alert'); }
      } else {
        // lost it: it wanders off a little the wrong way
        const ang = Math.random() * Math.PI * 2;
        g0.walk(Math.max(S.x0 + 0.3, Math.min(S.x1 - 0.3, a.x + Math.cos(ang) * 0.5)), Math.max(S.z0 + 0.2, Math.min(S.z1 - 0.2, a.z + Math.sin(ang) * 0.35)));
        g.msg = 'Lost the scent'; g.misses++; sfx('miss'); g0.emote('question');
      }
      g.msgT = 0.9; g.center = 0.2 + Math.random() * 0.6;
    };
    const off = keysOrClick(canvas, press);
    g.dispose = off;
    g.frame = (dt, ctx) => {
      const W = yard.W, H = yard.H;
      g.t += dt; g.msgT = Math.max(0, g.msgT - dt);
      const a = g0.actor();
      // sniffing about: it turns this way and that while it searches
      g.look -= dt;
      if (g.look <= 0 && !a.goTo && g.dig <= 0) { a.flip = !a.flip; g.look = 0.6 + Math.random() * 0.8; }
      if (g.dig > 0) {
        g.dig -= dt;
        if (cloudy) {
          // up in the clouds: a hop, a dive down into them, a rummage, and back up
          const k = 1 - g.dig / 1.6;
          a.sink = k < 0.15 ? 0 : k < 0.35 ? (k - 0.15) / 0.2 : k < 0.8 ? 1 : Math.max(0, 1 - (k - 0.8) / 0.15);
          if (k < 0.12 && !g.dove) { g.dove = true; g0.hop(); }
          if (a.sink > 0.2 && Math.random() < dt * 18) yard.sparks.push({ kind: 'gust', x: a.x + (Math.random() - 0.5) * 0.8, y: 0.1, z: a.z + (Math.random() - 0.5) * 0.3, vx: (Math.random() - 0.5) * 1.5, vy: 0.4 + Math.random() * 0.5, vz: 0, life: 0.9, ph: 0, c: 0 });
        } else {
          if (Math.random() < dt * 14) yard.sparks.push({ kind: grassy ? 'leaf' : 'pebble', x: a.x + (Math.random() - 0.5) * 0.4, y: 0.2, z: a.z - 0.1, vx: (Math.random() - 0.5) * 2, vy: 1.6, vz: 0, g: 6, life: 0.8, ph: 0, c: Math.random() < 0.5 ? 0 : 1 });
          if (Math.random() < dt * 4) g0.hop();
        }
        if (g.dig <= 0) {
          a.sink = 0; g.dove = false;
          g.found++; g.round++; g0.pose('happy', 1.5); g0.cry('happy'); sfx('level');
          g.msg = cloudy ? 'Dove into the clouds and found something!' : grassy ? 'Found something in the bushes!' : 'Dug something up!'; g.msgT = 1.4;
          if (g.round >= g.rounds) { g.perf = Math.max(0, Math.min(1, 1 - g.misses / (g.steps + g.misses + 3))); setTimeout(() => { g.done = true; }, 1200); }
          else setTimeout(newTarget, 800);
        }
      } else {
        g.pos += g.dir * g.speed * dt; if (g.pos > 1) { g.pos = 1; g.dir = -1; } if (g.pos < 0) { g.pos = 0; g.dir = 1; }
      }
      // a faint glint where it is, for sharp noses up close
      const T = g.target; const d = Math.hypot(T.x - a.x, T.z - a.z);
      if (apt > 0.4 && d < 1.6 && Math.sin(g.t * 6) > 0.5) { const q = yard.project(T.x, 0.1, T.z); if (q) { ctx.fillStyle = 'rgba(255,246,160,.9)'; ctx.fillRect(q.x - 1, q.y - 8, 3, 10); ctx.fillRect(q.x - 5, q.y - 4, 11, 3); } }
      slider(ctx, W / 2 - 220, H - 70, 440, g.pos, g.center, g.zone);
      hint(ctx, W, 'Time each sniff in the green to steer them toward the treasure');
      text(ctx, `Treasure ${g.found} / ${g.rounds} · ${d < 1 ? 'Very close!' : d < 2 ? 'Getting warm' : 'Searching…'}`, W / 2, H - 92, { size: 15 });
      if (g.msgT > 0) text(ctx, g.msg, W / 2, H * 0.3, { size: 26, color: '#fff6a0' });
    };
    return g;
  },

  // ===== obstacle course: a circular track; the camera runs along behind them =====
  obstacle(g0) {
    const { yard, canvas, apt, c } = g0;
    yard.openFloor = true;
    const a0 = g0.actor();
    const flies = !!a0.fly;
    const C = { x: 0, z: 6.4 }, R0 = 4.4, HALF = 1.15, LAPS = 2;
    // what's on the track: [angle (fraction of a lap), kind, lane offset for stumps]
    const course = [[0.1, 'hurdle'], [0.19, 'stump', -0.6], [0.24, 'stump', 0.6], [0.33, 'lowbar'], [0.45, 'hurdle'], [0.53, 'stump', 0], [0.62, 'lowbar'],
      [0.7, 'stump', 0.7], [0.74, 'stump', -0.7], [0.83, 'hurdle'], [0.92, 'lowbar']]
      .map(([f, kind, u = 0]) => ({ th: f * Math.PI * 2, kind, u }));
    const at = (th, u = 0) => ({ x: C.x + (R0 + u) * Math.cos(th), z: C.z + (R0 + u) * Math.sin(th) });
    const decor = [];
    // cones along both edges of the track, and the start line flags
    for (let i = 0; i < 36; i++) { const th = (i / 36) * Math.PI * 2; for (const u of [-HALF - 0.15, HALF + 0.15]) { const p = at(th, u); decor.push({ ...buildArt('cone', i % 2 ? '#ff8a3d' : '#ffffff'), x: p.x, z: p.z, kind: 'cone' }); } }
    for (const o of course) {
      if (o.kind === 'stump') { const p = at(o.th, o.u); decor.push({ ...buildArt('stump'), x: p.x, z: p.z, kind: 'stump' }); continue; }
      for (const u of [-0.7, 0, 0.7]) { const p = at(o.th, u); decor.push({ ...buildArt(o.kind), x: p.x, z: p.z, kind: o.kind }); }
    }
    for (const u of [-HALF, HALF]) { const p = at(0, u); decor.push({ ...buildArt('flag', '#ffd23f'), x: p.x, z: p.z, kind: 'flag' }); }
    yard.setDecor(decor);
    // an open field: no fences, and nothing tall on or near the track (trees stay in the distance)
    yard.fenceImg = null;
    yard.props = (yard.props ?? []).filter((p) => p.decor || (['tuft', 'flower'].includes(p.kind) ? Math.abs(Math.hypot(p.x - C.x, p.z - C.z) - R0) > HALF + 0.3 : Math.hypot(p.x - C.x, p.z - C.z) > R0 + 6));
    const st = { th: -0.25, u: 0, ut: 0, v: 0, duck: 0, air: 0, stun: 0, lapStart: 0 };
    const g = { t: 0, bumps: 0, clears: 0, started: false, done: false, msg: '', msgT: 0, cursor: null, down: false, keys: {}, par: 26 };
    const top = 2.6 + (speciesOf(g0.idx, c)?.baseStats?.spe ?? 60) / 55 + apt * 1.2;
    const offs = [
      on(canvas, 'pointermove', (e) => { g.cursor = g0.toBuf(e); }),
      on(canvas, 'pointerdown', (e) => { g.cursor = g0.toBuf(e); g.down = true; g.started = true; }),
      on(window, 'pointerup', () => { g.down = false; }),
      on(canvas, 'keydown', (e) => { if (/^Arrow/.test(e.key) || e.code === 'Space') { e.preventDefault(); g.keys[e.key] = true; g.started = true; } }),
      on(canvas, 'keyup', (e) => { g.keys[e.key] = false; }),
    ];
    g.dispose = () => { offs.forEach((f) => f()); yard.openFloor = false; };
    const say = (m, t = 0.8) => { g.msg = m; g.msgT = t; };
    const place = () => {
      const a = g0.actor(), p = at(st.th, st.u);
      a.x = p.x; a.z = p.z; a.tx = p.x; a.tz = p.z;
      // camera: behind them, looking along the track
      const tx = -Math.sin(st.th), tz = Math.cos(st.th);
      yard.view({ pitch: 0.42, x: p.x + tx * 1.8, z: p.z + tz * 1.8, dist: 0.6, yaw: -st.th });
    };
    place(); yard.view({ snap: true });
    g.frame = (dt, ctx) => {
      const W = yard.W, H = yard.H;
      const a = g0.actor();
      if (g.started && !g.finished) g.t += dt;
      g.msgT = Math.max(0, g.msgT - dt);
      st.stun = Math.max(0, st.stun - dt); st.air = Math.max(0, st.air - dt);
      // input: where the pointer is compared with them (or the arrow keys)
      let run = 0, steer = 0, duck = false;
      const b = g0.box();
      if (g.down && g.cursor && b) {
        const cx = (b.x0 + b.x1) / 2, cy = (b.y0 + b.y1) / 2;
        const dx = g.cursor.x - cx, dy = g.cursor.y - cy;
        run = Math.max(0, Math.min(1, -dy / 160));
        steer = Math.max(-1, Math.min(1, dx / 120));
        duck = dy > 40;
      }
      if (g.keys.ArrowUp) run = 1; if (g.keys.ArrowLeft) steer = -1; if (g.keys.ArrowRight) steer = 1; if (g.keys.ArrowDown) duck = true;
      const want = st.stun > 0 ? 0 : duck ? top * 0.35 : run * top;
      st.v += (want - st.v) * Math.min(1, dt * (want > st.v ? 2.2 : 4));
      st.duck += ((duck ? 1 : 0) - st.duck) * Math.min(1, dt * 10);
      // screen right is the outside of the ring
      st.u = Math.max(-HALF, Math.min(HALF, st.u + steer * dt * 2.4));
      const before = st.th;
      st.th += (st.v * dt) / (R0 + st.u);
      // obstacles in the way
      for (const o of course) {
        for (let lap = 0; lap < LAPS; lap++) {
          const oth = o.th + lap * Math.PI * 2;
          if (!(before < oth && st.th >= oth)) continue;
          if (o.kind === 'stump' && Math.abs(st.u - o.u) < 0.45 && !(flies && st.air > 0)) { st.th = oth - 0.05; st.v = 0; st.stun = 0.7; g.bumps++; a.squash = 1; sfx('miss'); g0.emote('wow'); say('Bonk! Steer round it'); }
          else if (o.kind === 'hurdle') {
            if (flies || st.v > top * 0.6) { st.air = 0.55; a.hop = 1; g.clears++; sfx('blip'); }
            else { st.th = oth - 0.05; st.v = 0; st.stun = 0.6; g.bumps++; a.squash = 1; sfx('miss'); say('Run at it to jump!', 1); }
          } else if (o.kind === 'lowbar') {
            if (st.duck > 0.5) { g.clears++; sfx('heal'); say('Under it!', 0.5); }
            else { st.th = oth - 0.05; st.v = 0; st.stun = 0.6; g.bumps++; a.squash = 1; sfx('miss'); say('Drag down to slide under!', 1); }
          }
        }
      }
      // finish line
      if (!g.finished && st.th >= LAPS * Math.PI * 2 - 0.25) {
        g.finished = true; st.v = 0; g0.pose('happy', 2); g0.cry('happy'); sfx('level'); say('Finished!', 2);
        g.perf = Math.max(0, Math.min(1, (g.par * 1.7 - g.t - g.bumps * 2.5) / (g.par * 0.9)));
        setTimeout(() => { g.done = true; }, 1300);
      }
      a.running = st.v > 0.2;
      a.state = a.running ? 'walk' : a.state === 'happy' ? 'happy' : 'idle';
      a.away = st.v > 0.2;
      a.y = (flies ? 0.3 : 0) + (st.air > 0 ? Math.sin((st.air / 0.55) * Math.PI) * 0.6 : 0);
      a.sizeMulBase = a.sizeMulBase ?? a.sizeMul ?? 1;
      a.sizeMul = a.sizeMulBase * (1 - st.duck * 0.35);
      place();
      // HUD
      const lap = Math.min(LAPS, Math.floor(Math.max(0, st.th) / (Math.PI * 2)) + 1);
      if (g.down && g.cursor) { ctx.strokeStyle = 'rgba(125,255,207,.8)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(g.cursor.x, g.cursor.y, 10, 0, Math.PI * 2); ctx.stroke(); }
      hint(ctx, W, g.started ? 'Drag up to run · left and right to change lane · down to slide under bars' : 'Press and hold above them (or the arrow keys) to start running');
      // a little map of the ring
      const mx = W - 70, my = 70, mr = 40;
      ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(mx, my, mr, 0, Math.PI * 2); ctx.stroke();
      for (const o of course) { ctx.fillStyle = o.kind === 'stump' ? '#8a5a34' : o.kind === 'hurdle' ? '#e5484d' : '#ffd23f'; ctx.fillRect(mx + Math.cos(o.th) * mr - 2, my - Math.sin(o.th) * mr - 2, 4, 4); }
      ctx.fillStyle = '#7dffcf'; ctx.beginPath(); ctx.arc(mx + Math.cos(st.th) * mr, my - Math.sin(st.th) * mr, 5, 0, Math.PI * 2); ctx.fill();
      text(ctx, `Lap ${lap}/${LAPS} · ${g.t.toFixed(1)} s · bumps ${g.bumps}`, W / 2, H - 22, { size: 16 });
      if (g.msgT > 0) text(ctx, g.msg, W / 2, H * 0.3, { size: 24, color: '#fff6a0' });
    };
    return g;
  },

  // ===== puzzle: pairs; stuck? they think hard and show you what they think =====
  puzzle(g0) {
    const { yard, canvas, apt } = g0;
    g0.stage(2.9, 2.1, { top: 120 }); g0.actor().flip = true;
    const small = yard.heightOf(g0.actor()) < 1.3;
    const home = { x: g0.actor().x, z: g0.actor().z };
    const syms = ['◆', '●', '▲', '★', '♥', '♣'];
    const cols = ['#e5484d', '#3b8ae0', '#3fb26a', '#ffd23f', '#ff7ab0', '#8b5cf6'];
    const deck = [...syms.keys(), ...syms.keys()].sort(() => Math.random() - 0.5).map((k, i) => ({ k, i, open: false, done: false, flip: 0 }));
    const g = { t: 0, flips: 18, pairs: 0, sel: [], lock: 0, idle: 0, point: null, peek: apt > 0.55 ? 1.2 + apt : 0, done: false, wander: 3 };
    const cardBox = (d) => { const W = yard.W, H = yard.H; const cw = Math.min(84, W * 0.075), ch = cw * 1.25, gx = W * 0.05, gy = H * 0.13; return { x: gx + (d.i % 6) * (cw + 14), y: gy + Math.floor(d.i / 6) * (ch + 16), w: cw, h: ch }; };
    if (g.peek) { const k = deck[0].k; for (const d of deck) if (d.k === k) d.peekable = true; }
    const choose = (p) => {
      if (g.lock > 0 || g.peek > 0 || g.flips <= 0) return;
      const d = deck.find((q) => { const b = cardBox(q); return !q.open && !q.done && p.x > b.x && p.x < b.x + b.w && p.y > b.y && p.y < b.y + b.h; });
      if (!d) return;
      d.open = true; g.sel.push(d); sfx('move'); g.idle = 0;
      if (g.sel.length === 2) {
        g.flips--;
        const [x, y] = g.sel;
        if (x.k === y.k) { x.done = y.done = true; g.pairs++; sfx('heal'); g.sel = []; g0.hop(); g0.emote('love'); if (g.point) { g.point = null; g0.walk(home.x, home.z); } }
        else { g.lock = 0.9; if (Math.random() < 0.4) g0.emote('frown'); }
        if (g.pairs === syms.length || g.flips <= 0) { g.perf = g.pairs / syms.length * (0.7 + 0.3 * g.flips / 18); g0.pose('happy', 2); setTimeout(() => { g.done = true; }, 900); }
      }
    };
    const offs = [on(canvas, 'pointerdown', (e) => choose(g0.toBuf(e)))];
    g.dispose = () => offs.forEach((f) => f());
    g.frame = (dt, ctx) => {
      const W = yard.W, H = yard.H;
      g.t += dt; g.peek = Math.max(0, g.peek - dt); g.idle += dt; g.wander -= dt;
      if (g.lock > 0) { g.lock -= dt; if (g.lock <= 0) { for (const d of g.sel) d.open = false; g.sel = []; } }
      const a = g0.actor();
      // not just standing there: it shifts about and watches the cards
      if (!g.point && g.wander <= 0 && !a.goTo) { g0.walk(Math.max(1.2, Math.min(3.8, home.x + (Math.random() - 0.5) * 1.6)), home.z + (Math.random() - 0.5) * 0.5, 0.8); g.wander = 2.5 + Math.random() * 3; }
      // stuck? it thinks it over and shows you what it thinks (clever ones get it right more often)
      if (!g.point && g.idle > 7 - apt * 2 && g.pairs < syms.length) {
        const left = deck.filter((d) => !d.done && !d.open);
        const a1 = left[Math.floor(Math.random() * left.length)];
        const right = Math.random() < 0.55 + apt * 0.45;
        const a2 = right ? left.find((d) => d !== a1 && d.k === a1.k) : left.find((d) => d !== a1 && d.k !== a1.k);
        if (a1 && a2) {
          g.point = { cards: [a1, a2], t: 0 }; g0.emote('question'); g.idle = 0;
          // small ones float (or scamper) over toward the cards; big ones just think it at you
          if (small) { const b = cardBox(a1), fp = yard.floorAt(b.x + b.w / 2, H * 0.9); if (fp) g0.walk(Math.max(-3.8, Math.min(3.8, fp.x)), Math.max(yard.S.z0 + 0.1, fp.z), 1.6); }
        }
      }
      for (const d of deck) {
        const b = cardBox(d);
        const show = d.open || d.done || (g.peek > 0 && d.peekable);
        ctx.save(); ctx.globalAlpha = d.done ? 0.45 : 1;
        panel(ctx, b.x, b.y, b.w, b.h, { fill: show ? '#fdf8ea' : 'rgba(91,69,196,.92)', stroke: show ? '#2a2448' : 'rgba(200,180,255,.8)', r: 10 });
        if (!show) { ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.beginPath(); ctx.arc(b.x + b.w / 2, b.y + b.h / 2, b.w * 0.2, 0, Math.PI * 2); ctx.fill(); }
        else text(ctx, syms[d.k], b.x + b.w / 2, b.y + b.h / 2, { size: b.w * 0.42, color: cols[d.k] });
        ctx.restore();
      }
      // what it thinks: a thought bubble with the symbol, and a soft glow on the two cards it means
      if (g.point) {
        g.point.t += dt;
        if (g.point.t > 0.8) {
          const sym = g.point.cards[0].k;
          thought(ctx, g0.box(), 110, 54, (bx, by) => { text(ctx, syms[sym], bx - 22, by, { size: 26, color: cols[sym] }); text(ctx, '+', bx, by, { size: 16, color: '#2a2448' }); text(ctx, syms[sym], bx + 22, by, { size: 26, color: cols[sym] }); });
          const pulse = 0.5 + 0.5 * Math.sin(g.t * 6);
          for (const cd of g.point.cards) { if (cd.done || cd.open) continue; const b = cardBox(cd); ctx.strokeStyle = `rgba(255,246,160,${(0.5 + pulse * 0.5).toFixed(2)})`; ctx.lineWidth = 4; ctx.strokeRect(b.x - 4, b.y - 4, b.w + 8, b.h + 8); }
        }
        if (g.point.t > 7) { g.point = null; g0.walk(home.x, home.z, 1); }
      }
      hint(ctx, W, g.peek > 0 ? 'Your creature is concentrating… remember those!' : 'Match all the pairs. Stuck? Wait a moment: your creature will think it over.');
      text(ctx, `Pairs ${g.pairs}/${syms.length} · flips left ${g.flips}`, W / 2, H - 22, { size: 16 });
    };
    return g;
  },

  // ===== training: its moves against dummies, cans and targets =====
  training(g0) {
    const { yard, canvas, apt, c, idx } = g0;
    const resolve = g0.resolve;
    yard.view({ pitch: 0.3, z: 2.9, snap: true });
    g0.stage(-3.0, 1.5, { top: 70 }); g0.actor().flip = false;
    const home = { x: g0.actor().x, z: g0.actor().z };
    // its moves (up to four); a creature with none uses a plain tackle of its type
    let moves = (c.moves ?? []).map((m) => idx.moves.get(m.id ?? m)).filter(Boolean).slice(0, 4);
    if (!moves.length) { const t = speciesOf(idx, c)?.types?.[0]; moves = [{ id: 'tackle', name: 'Tackle', type: t, category: 'physical', power: 40 }]; }
    const fx = moves.map((mv) => ({ mv, ...moveFx(idx, mv) }));
    const KIND = { can: { hp: 1, pts: 1 }, dummy: { hp: 3, pts: 2 }, target: { hp: 2, pts: 3 } };
    const g = { t: 0, len: 32, sel: 0, targets: [], spawned: 0, score: 0, max: 0, cool: 0, shots: [], boost: 0, done: false, used: new Set(), msg: '', msgT: 0, next: 0.4 };
    const spawn = () => {
      const r = Math.random(), kind = r < 0.4 ? 'can' : r < 0.75 ? 'dummy' : 'target';
      for (let i = 0; i < 12; i++) {
        const x = -1.2 + Math.random() * 5, z = kind === 'target' ? 3.6 + Math.random() * 1 : 2.3 + Math.random() * 1.9;
        if (g.targets.every((q) => Math.hypot(q.x - x, q.z - z) > 0.9)) { g.targets.push({ kind, x, z, hp: KIND[kind].hp, fall: 0, shake: 0 }); g.spawned++; g.max += KIND[kind].pts; break; }
      }
    };
    // the scene is only rebuilt when targets come and go; shaking and falling move the props themselves
    const decorNow = () => {
      yard.setDecor(g.targets.map((q, i) => ({ ...buildArt(q.kind, q.kind === 'can' ? ['#e5484d', '#3b8ae0', '#3fb26a'][Math.abs(Math.floor(q.x * 7)) % 3] : '#e5484d'), x: q.x, z: q.z, kind: q.kind, tgt: i })));
      for (const pr of yard.props) if (pr.decor && pr.tgt != null && g.targets[pr.tgt]) { g.targets[pr.tgt].prop = pr; pr.h0 = pr.h; }
    };
    for (let i = 0; i < 4; i++) spawn();
    decorNow();
    const btns = () => { const W = yard.W, H = yard.H, bw = Math.min(190, (W - 40) / fx.length - 10); return fx.map((f, i) => ({ i, x: W / 2 - (fx.length * (bw + 10)) / 2 + i * (bw + 10), y: H - 64, w: bw, h: 50 })); };
    const typeCol = (f) => idx.types.get(f.mv.type)?.color ?? TYPE_FX[f.type].col[0];
    const hitTarget = (q, f) => {
      const dmg = f.how === 'buff' ? 0 : (1 + (f.power >= 80 ? 1 : 0) + (g.boost > 0 ? 1 : 0));
      g.boost = 0;
      q.hp -= dmg; q.shake = 0.5; sfx(dmg ? 'blip' : 'move');
      for (let i = 0; i < 10; i++) yard.sparks.push({ kind: f.trail, x: q.x, y: 0.6, z: q.z, vx: (Math.random() - 0.5) * 3, vy: 1 + Math.random() * 2, vz: (Math.random() - 0.5), g: 5, life: 0.7, ph: 0, c: Math.random() < 0.5 ? 0 : 1 });
      if (q.hp <= 0 && q.fall === 0) { q.fall = 0.01; g.score += KIND[q.kind].pts * (f.how === 'throw' && q.kind === 'target' ? 1.3 : 1); g.msg = q.kind === 'target' ? 'Bullseye!' : q.kind === 'dummy' ? 'Down it goes!' : 'Clang!'; g.msgT = 0.8; g0.hop(); }
    };
    const fire = (q) => {
      const f = fx[g.sel];
      if (g.cool > 0 || !f) return;
      g.used.add(f.mv.id);
      const a = g0.actor();
      g.cool = 0.55 + Math.min(0.8, f.power / 180);
      g0.cry('happy');
      if (f.how === 'buff') { g.boost = 1; g.msg = `${f.mv.name}: powered up!`; g.msgT = 1; yard.burst(a, 10); g0.pose('happy', 0.8); sfx('heal'); return; }
      if (!q) return;
      a.flip = q.x < a.x;
      if (f.how === 'hit') {
        // up close: a dash over, a hit, and back
        g0.walk(q.x - 0.55 * Math.sign(q.x - a.x || 1), q.z - 0.05, 5 + apt * 2);
        g.shots.push({ f, q, kind: 'hit', t: 0, wait: true });
      } else g.shots.push({ f, q, kind: f.how, t: 0, from: { x: a.x, y: yard.heightOf(a) * 0.6, z: a.z } });
    };
    const offs = [
      on(canvas, 'pointerdown', (e) => {
        const p = g0.toBuf(e);
        const b = btns().find((bb) => p.x > bb.x && p.x < bb.x + bb.w && p.y > bb.y && p.y < bb.y + bb.h);
        if (b) { g.sel = b.i; sfx('move'); if (fx[b.i].how === 'buff') fire(null); return; }
        // the target under the pointer (nearest one)
        let best = null, bd = 1e9;
        for (const q of g.targets) { if (q.fall) continue; const s2 = yard.project(q.x, 0.5, q.z); if (!s2) continue; const d = Math.hypot(s2.x - p.x, s2.y - p.y); if (d < Math.max(40, s2.k * 0.7) && d < bd) { bd = d; best = q; } }
        if (best) fire(best);
      }),
      on(canvas, 'keydown', (e) => { const n = Number(e.key); if (n >= 1 && n <= fx.length) { g.sel = n - 1; sfx('move'); } }),
    ];
    g.dispose = () => offs.forEach((f) => f());
    g.frame = (dt, ctx) => {
      const W = yard.W, H = yard.H;
      g.t += dt; g.cool = Math.max(0, g.cool - dt); g.msgT = Math.max(0, g.msgT - dt); g.next -= dt;
      const a = g0.actor();
      let changed = false;
      if (g.t < g.len && g.next <= 0 && g.targets.filter((q) => !q.fall).length < 5) { spawn(); g.next = 1.2 + Math.random(); changed = true; }
      for (const q of g.targets) {
        if (q.shake > 0) q.shake = Math.max(0, q.shake - dt);
        if (q.fall > 0) q.fall = Math.min(1, q.fall + dt * 2.5);
        if (q.prop) { q.prop.x = q.x + Math.sin(q.shake * 40) * q.shake * 0.08; q.prop.h = (q.prop.h0 ?? q.prop.h) * Math.max(0.02, 1 - q.fall); }
        if (q.fall >= 1) changed = true;
      }
      if (changed) { g.targets = g.targets.filter((q) => q.fall < 1); decorNow(); }
      // shots in flight
      for (const s2 of g.shots) {
        s2.t += dt;
        if (s2.kind === 'hit') {
          if (s2.wait && !a.goTo) { s2.wait = false; s2.t = 0; a.squash = 1; hitTarget(s2.q, s2.f); const img = fxImage(resolve, s2.f.img); s2.flash = { img, x: s2.q.x, z: s2.q.z }; setTimeout(() => g0.walk(home.x, home.z, 4), 180); }
          if (!s2.wait && s2.flash) { const q2 = yard.project(s2.flash.x, 0.6, s2.flash.z); if (q2) { const sz = q2.k * 0.7 * (1 + s2.t); ctx.globalAlpha = Math.max(0, 1 - s2.t * 2.5); if (s2.flash.img) ctx.drawImage(s2.flash.img, q2.x - sz / 2, q2.y - sz / 2, sz, sz); else { ctx.fillStyle = typeCol(s2.f); ctx.beginPath(); ctx.arc(q2.x, q2.y, sz * 0.35, 0, Math.PI * 2); ctx.fill(); } ctx.globalAlpha = 1; } }
          if (!s2.wait && s2.t > 0.45) s2.gone = true;
          continue;
        }
        const T = s2.kind === 'beam' ? 0.35 : s2.kind === 'bolt' ? 0.3 : 0.45;
        const k = Math.min(1, s2.t / T);
        const from = yard.project(s2.from.x, s2.from.y, s2.from.z), to = yard.project(s2.q.x, 0.6, s2.q.z);
        if (from && to) {
          const col = typeCol(s2.f);
          if (s2.kind === 'beam') { ctx.strokeStyle = col; ctx.globalAlpha = 0.85; ctx.lineWidth = 10 * (1 - k * 0.5); ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(from.x + (to.x - from.x) * k, from.y + (to.y - from.y) * k); ctx.stroke(); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 3; ctx.stroke(); ctx.globalAlpha = 1; }
          else if (s2.kind === 'bolt') { ctx.strokeStyle = col; ctx.lineWidth = 4; ctx.beginPath(); let x = to.x, y = 0; ctx.moveTo(x, y); while (y < to.y) { y += 18; x = to.x + (Math.random() - 0.5) * 22; ctx.lineTo(x, Math.min(y, to.y)); } ctx.stroke(); }
          else {
            const x = from.x + (to.x - from.x) * k, y = from.y + (to.y - from.y) * k - Math.sin(k * Math.PI) * 40;
            const img = fxImage(resolve, s2.f.img), sz = 18 + to.k * 0.25;
            if (img) { ctx.save(); ctx.translate(x, y); ctx.rotate(s2.t * 8); ctx.drawImage(img, -sz / 2, -sz / 2, sz, sz); ctx.restore(); }
            else { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, sz * 0.32, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = TYPE_FX[s2.f.type].col[1]; ctx.beginPath(); ctx.arc(x - 2, y - 2, sz * 0.14, 0, Math.PI * 2); ctx.fill(); }
            const wp = yard.floorAt(x, y + 30); if (wp && Math.random() < 0.6) yard.sparks.push({ kind: s2.f.trail, x: wp.x, y: 0.6, z: wp.z, vx: 0, vy: 0.3, vz: 0, life: 0.4, ph: 0, c: Math.random() < 0.5 ? 0 : 1 });
          }
        }
        if (k >= 1 && !s2.hit) { s2.hit = true; hitTarget(s2.q, s2.f); }
        if (s2.t > T + 0.1) s2.gone = true;
      }
      g.shots = g.shots.filter((s2) => !s2.gone);
      // move buttons
      for (const b of btns()) {
        const f = fx[b.i], on2 = b.i === g.sel;
        panel(ctx, b.x, b.y, b.w, b.h, { fill: on2 ? typeCol(f) : 'rgba(14,12,34,.82)', stroke: on2 ? '#ffffff' : typeCol(f), r: 10 });
        text(ctx, `${b.i + 1}. ${f.mv.name}`, b.x + b.w / 2, b.y + 17, { size: 14 });
        text(ctx, f.category === 'status' ? 'status · powers up' : `${f.category} · ${f.power || '—'} power`, b.x + b.w / 2, b.y + 36, { size: 11, weight: 600, color: '#e9fff8' });
      }
      if (g.cool > 0) { const bb = g0.box(); if (bb) { ctx.fillStyle = 'rgba(255,255,255,.7)'; ctx.fillRect(bb.x0, bb.y0 - 10, (bb.x1 - bb.x0) * (1 - g.cool / 1.3), 4); } }
      if (g.boost) text(ctx, '⚡ powered up', 90, H - 90, { size: 14, color: '#fff6a0' });
      hint(ctx, W, 'Pick a move (1–4), then click a dummy, can or target. Physical moves dash in; special moves fly.');
      text(ctx, `${Math.ceil(Math.max(0, g.len - g.t))} s · points ${Math.round(g.score)}`, W - 100, 50, { size: 15 });
      if (g.msgT > 0) text(ctx, g.msg, W / 2, H * 0.28, { size: 24, color: '#fff6a0' });
      if (g.t >= g.len && !g.done && !g.ending) { g.ending = true; g.perf = Math.max(0, Math.min(1, g.score / Math.max(8, g.max * 0.7))); g0.pose('happy', 1.5); setTimeout(() => { g.done = true; g.used = [...g.used]; }, 800); }
    };
    return g;
  },

  // ===== photography: frame them, catch the pose =====
  photography(g0) {
    const { yard, canvas, apt } = g0;
    g0.stage(0, 2.4, { top: 40 });
    const g = { t: 0, shots: 4, best: 0, flash: 0, pose: 0, next: 1.4, done: false, photo: null, msg: '', msgT: 0, cursor: null, wander: 0 };
    const frame = () => { const W = yard.W, H = yard.H, fw = W * 0.34, fh = fw * 0.75; const c = g.cursor ?? { x: W / 2, y: H / 2 }; return { x: Math.max(0, Math.min(W - fw, c.x - fw / 2)), y: Math.max(0, Math.min(H - fh, c.y - fh / 2)), w: fw, h: fh }; };
    const shoot = () => {
      if (g.shots <= 0 || g.flash > 0) return;
      g.shots--; g.flash = 0.35; sfx('dock');
      const b = g0.box(), f = frame();
      let q = 0.1;
      if (b) {
        const cx = (b.x0 + b.x1) / 2, cy = (b.y0 + b.y1) / 2;
        const inside = cx > f.x && cx < f.x + f.w && cy > f.y && cy < f.y + f.h;
        const centered = inside ? 1 - Math.min(1, Math.hypot((cx - (f.x + f.w / 2)) / f.w, (cy - (f.y + f.h / 2)) / f.h) * 2.2) : 0;
        const fills = Math.min(1, (b.y1 - b.y0) / (f.h * 0.6));
        q = inside ? 0.25 + centered * 0.3 + fills * 0.1 + (g.pose > 0 ? 0.35 : 0) : 0.05;
      }
      if (q >= g.best) { g.best = q; g.want = { ...f }; }
      g.msg = q > 0.75 ? 'Perfect shot!' : q > 0.5 ? 'Nice one' : q > 0.2 ? 'Hmm, a bit off' : 'Missed them!'; g.msgT = 1;
      if (g.shots <= 0) { g.perf = Math.min(1, g.best); setTimeout(() => { g.done = true; }, 1000); }
    };
    const offs = [on(canvas, 'pointermove', (e) => { g.cursor = g0.toBuf(e); }), keysOrClick(canvas, (e) => { if (e?.clientX != null) g.cursor = g0.toBuf(e); shoot(); })];
    g.dispose = () => offs.forEach((f) => f());
    g.frame = (dt, ctx) => {
      const W = yard.W, H = yard.H, S = yard.S;
      g.t += dt; g.flash = Math.max(0, g.flash - dt); g.msgT = Math.max(0, g.msgT - dt); g.next -= dt; g.wander -= dt;
      const a = g0.actor();
      if (g.pose > 0) { g.pose -= dt * (1.5 - apt * 0.7); if (g.pose <= 0) a.state = 'idle'; }
      else if (g.next <= 0) { g.pose = 1; g.next = 2 + Math.random() * 2.5; a.goTo = null; a.state = 'happy'; a.timer = 1.4; a.hop = 1; a.flip = Math.random() < 0.5; if (Math.random() < 0.4) yard.burst(a, 8); }
      else if (g.wander <= 0) { g0.walk(S.x0 + 0.6 + Math.random() * (S.x1 - S.x0 - 1.2), S.z0 + 0.3 + Math.random() * (S.z1 - S.z0 - 0.8), 0.9 + apt * 0.5); g.wander = 1.5 + Math.random() * 2; }
      // capture the best shot (the framed part only), before the viewfinder is drawn
      if (g.want) { const f = g.want; g.want = null; const pc = document.createElement('canvas'); pc.width = Math.round(f.w * 2); pc.height = Math.round(f.h * 2); const px = pc.getContext('2d'); px.imageSmoothingEnabled = false; px.drawImage(canvas, f.x, f.y, f.w, f.h, 0, 0, pc.width, pc.height); g.photo = pc.toDataURL('image/png'); }
      const f = frame();
      ctx.fillStyle = 'rgba(8,6,20,.35)';
      ctx.fillRect(0, 0, W, f.y); ctx.fillRect(0, f.y + f.h, W, H - f.y - f.h); ctx.fillRect(0, f.y, f.x, f.h); ctx.fillRect(f.x + f.w, f.y, W - f.x - f.w, f.h);
      ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 3;
      for (const [x, y, dx, dy] of [[f.x, f.y, 1, 1], [f.x + f.w, f.y, -1, 1], [f.x, f.y + f.h, 1, -1], [f.x + f.w, f.y + f.h, -1, -1]]) { ctx.beginPath(); ctx.moveTo(x, y + dy * 22); ctx.lineTo(x, y); ctx.lineTo(x + dx * 22, y); ctx.stroke(); }
      ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(f.x + f.w / 2 - 8, f.y + f.h / 2); ctx.lineTo(f.x + f.w / 2 + 8, f.y + f.h / 2); ctx.moveTo(f.x + f.w / 2, f.y + f.h / 2 - 8); ctx.lineTo(f.x + f.w / 2, f.y + f.h / 2 + 8); ctx.stroke();
      if (g.pose > 0) text(ctx, '✦ posing! ✦', W / 2, 52, { size: 16, color: '#fff6a0' });
      hint(ctx, W, 'Frame them with the viewfinder and click when they pose');
      text(ctx, `Shots left: ${g.shots}`, W - 90, H - 22, { size: 15 });
      if (g.msgT > 0) text(ctx, g.msg, W / 2, H * 0.84, { size: 24, color: '#fff6a0' });
      if (g.flash > 0) { ctx.fillStyle = `rgba(255,255,255,${(g.flash * 2.4).toFixed(2)})`; ctx.fillRect(0, 0, W, H); }
    };
    return g;
  },
};
