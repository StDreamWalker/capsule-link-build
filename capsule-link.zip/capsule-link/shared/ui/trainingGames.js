// Training: a set of drills, like Duck Life's, each building a different side of your creature. No stars
// and no pass or fail: whatever they put in comes out as effort in a stat (and some experience).
//   moves    Move practice: its own moves against dummies, cans and targets, with Showdown's real move
//            animations. Each move has a few uses (fewer for moves with little PP); moves that would knock
//            the user out or end things in one hit are too risky to practise.        → Attack / Sp. Atk
//   dodge    Dodging run: it runs on its own; switch lanes round crates and jump rocks and logs.  → Speed
//   smash    Smash: charge up and release in the sweet spot to break boards, bricks and boulders.  → Attack, Defence
//   glide    Leap and glide: tap to flap (or bound) through the rings.                         → HP, Sp. Def
import { buildArt } from './buildArt.js';
import * as Paint from './paint.js';
import { sfx } from './audio.js';
import { prepareMoveAnim, standInMove } from './sdanim/player.js';
import { TYPE_FX, fxType } from './moveFx.js';
import { speciesOf } from '../engine/index.js';

export const DRILLS = [
  { id: 'moves', name: 'Move practice', stat: 'Attack or Sp. Atk', desc: 'Its own moves against dummies, cans and targets. A few uses each.' },
  { id: 'dodge', name: 'Dodging run', stat: 'Speed', desc: 'It runs; you switch lanes round crates and jump rocks and logs.' },
  { id: 'smash', name: 'Smash', stat: 'Attack and Defence', desc: 'Charge up, release in the sweet spot, break whatever’s in front of it.' },
  { id: 'glide', name: 'Leap and glide', stat: 'HP and Sp. Def', desc: 'Tap to flap (or bound) through the rings.' },
];
/** Moves too risky to practise: they knock the user out, or end things in one hit. */
export const RISKY = /^(explosion|self-?destruct|memento|final gambit|healing wish|lunar dance|misty explosion|fissure|guillotine|horn drill|sheer cold|destiny bond|perish song|curse|belly drum)$/i;

// ---------- drawing and input helpers ----------
function text(ctx, s, x, y, { size = 18, color = '#fff', align = 'center', weight = 700 } = {}) {
  ctx.font = `${weight} ${size}px "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif`; ctx.textAlign = align; ctx.textBaseline = 'middle';
  ctx.fillStyle = 'rgba(10,8,30,.6)'; ctx.fillText(s, x + 1.5, y + 1.5); ctx.fillStyle = color; ctx.fillText(s, x, y); ctx.textAlign = 'start';
}
function panel(ctx, x, y, w, h, { fill = 'rgba(14,12,34,.8)', stroke = 'rgba(125,255,207,.5)', r = 12 } = {}) {
  ctx.fillStyle = fill; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, w, h, r) : ctx.rect(x, y, w, h); ctx.fill();
  ctx.strokeStyle = stroke; ctx.lineWidth = 2; ctx.stroke();
}
const hint = (ctx, W, s) => text(ctx, s, W / 2, 22, { size: 15, weight: 600, color: '#e9fff8' });
const on = (el, type, fn, opt) => { el.addEventListener(type, fn, opt); return () => el.removeEventListener(type, fn, opt); };
const say = (g, m, t = 0.9) => { g.msg = m; g.msgT = t; };
const showMsg = (ctx, g, W, H, dt) => { g.msgT = Math.max(0, (g.msgT ?? 0) - dt); if (g.msgT > 0) text(ctx, g.msg, W / 2, H * 0.3, { size: 26, color: '#fff6a0' }); };
const sdName = (mv) => mv.showdownName ?? mv.name;
/** Showdown's animation for the move, or (for a move it doesn't know) one of the same type. */
const animFor = (idx, mv) => prepareMoveAnim(sdName(mv)) ?? prepareMoveAnim(standInMove(fxType(idx, mv.type), mv.category));

/** The training activity: g0.extra.drill picks the drill. */
export function training(g0) {
  const fn = { moves: movePractice, dodge: dodgingRun, smash, glide }[g0.extra?.drill] ?? movePractice;
  return fn(g0);
}

// ===== move practice =====
function movePractice(g0) {
  const { yard, canvas, idx, c, apt } = g0;
  yard.view({ pitch: 0.3, z: 2.9, snap: true });
  g0.stage(-2.6, 1.6, { top: 80 }); g0.actor().flip = false;
  const home = { x: g0.actor().x, z: g0.actor().z };
  const moves = (c.moves ?? []).map((m) => ({ m, mv: idx.moves.get(m.id) })).filter((x) => x.mv).slice(0, 4).map(({ m, mv }) => {
    const risky = RISKY.test(mv.name) || (Number(mv.power) || 0) >= 180;
    const uses = risky ? 0 : Math.max(1, Math.min(5, Math.round((mv.pp ?? m.pp ?? 10) / 3)));
    return { mv, uses, left: uses, risky, type: fxType(idx, mv.type) };
  });
  if (!moves.length) moves.push({ mv: { id: 'tackle', name: 'Tackle', category: 'physical', power: 40, type: speciesOf(idx, c)?.types?.[0] }, uses: 5, left: 5, type: 'normal' });
  const g = { t: 0, sel: moves.findIndex((m) => m.left > 0), targets: [], hits: 0, used: 0, boost: 0, anim: null, done: false, usedIds: new Set() };
  const total = moves.reduce((a, m) => a + m.uses, 0);
  const KINDS = ['dummy', 'can', 'target'];
  const SPOTS = [[0.4, 3.4], [1.9, 2.6], [3.0, 3.9], [-0.6, 4.3], [2.4, 4.6]];
  const place = () => {
    const free = SPOTS.filter(([x, z]) => !g.targets.some((t) => Math.hypot(t.x - x, t.z - z) < 0.5));
    const [x, z] = free[Math.floor(Math.random() * free.length)] ?? SPOTS[0];
    const kind = KINDS[Math.floor(Math.random() * KINDS.length)];
    const art = buildArt(kind, kind === 'can' ? ['#e5484d', '#3b8ae0', '#3fb26a'][Math.floor(Math.random() * 3)] : '#e5484d');
    const prop = { ...art, kind, x, z, h0: art.h, decor: true, solid: false };
    yard.props.push(prop);
    g.targets.push({ kind, x, z, hp: kind === 'dummy' ? 2 : 1, prop, fall: 0 });
  };
  for (let i = 0; i < 3; i++) place();
  const btns = () => { const W = yard.W, H = yard.H, bw = Math.min(200, (W - 40) / moves.length - 10); return moves.map((m, i) => ({ i, x: W / 2 - (moves.length * (bw + 10)) / 2 + i * (bw + 10), y: H - 66, w: bw, h: 52 })); };
  const colOf = (m) => idx.types.get(m.mv.type)?.color ?? TYPE_FX[m.type]?.col[0] ?? '#ffffff';
  const screenOf = (t) => yard.project(t.x, (t.prop.h0 ?? 1) * 0.5, t.z);
  const use = (target) => {
    const m = moves[g.sel];
    if (!m || g.anim || m.left <= 0) return;
    if (m.mv.category === 'status') { m.left--; g.used++; g.boost = 1; g.usedIds.add(m.mv.id); say(g, `${m.mv.name}: powered up!`); yard.burst(g0.actor(), 10); g0.pose('happy', 0.8); sfx('heal'); g.anim = { status: true, t: 0, a: animFor(idx, m.mv) }; return; }
    if (!target) return;
    m.left--; g.used++; g.usedIds.add(m.mv.id);
    g0.cry('happy');
    g.anim = { m, target, t: 0, a: animFor(idx, m.mv), hit: false };
  };
  const offs = [
    on(canvas, 'pointerdown', (e) => {
      const p = g0.toBuf(e);
      const b = btns().find((bb) => p.x > bb.x && p.x < bb.x + bb.w && p.y > bb.y && p.y < bb.y + bb.h);
      if (b) { if (moves[b.i].left > 0) { g.sel = b.i; sfx('move'); if (moves[b.i].mv.category === 'status') use(null); } else sfx('miss'); return; }
      let best = null, bd = 1e9;
      for (const t of g.targets) { if (t.fall) continue; const q = screenOf(t); if (!q) continue; const d = Math.hypot(q.x - p.x, q.y - p.y); if (d < Math.max(48, q.k * 0.8) && d < bd) { bd = d; best = t; } }
      if (best) use(best);
    }),
    on(canvas, 'keydown', (e) => { const n = Number(e.key); if (n >= 1 && n <= moves.length && moves[n - 1].left > 0) { g.sel = n - 1; sfx('move'); } }),
  ];
  g.dispose = () => offs.forEach((f) => f());
  const land = (target) => {
    target.hp -= 1 + (g.boost ? 1 : 0); g.boost = 0; sfx('blip');
    for (let i = 0; i < 10; i++) yard.sparks.push({ kind: target.kind === 'can' ? 'glint' : target.kind === 'dummy' ? 'leaf' : 'spark', x: target.x, y: 0.6, z: target.z, vx: (Math.random() - 0.5) * 3, vy: 1 + Math.random() * 2, vz: 0, g: 5, life: 0.7, ph: 0, c: Math.random() < 0.5 ? 0 : 1 });
    if (target.hp <= 0 && !target.fall) { target.fall = 0.01; g.hits++; say(g, target.kind === 'target' ? 'Bullseye!' : target.kind === 'dummy' ? 'Down it goes!' : 'Clang!'); g0.hop(); }
  };
  g.frame = (dt, ctx) => {
    const W = yard.W, H = yard.H;
    g.t += dt;
    const a = g0.actor();
    // targets topple, and new ones are set up
    for (const t of g.targets) { if (t.fall > 0) { t.fall = Math.min(1, t.fall + dt * 2.4); t.prop.h = t.prop.h0 * Math.max(0.03, 1 - t.fall); } }
    const gone = g.targets.filter((t) => t.fall >= 1);
    if (gone.length) { yard.props = yard.props.filter((p) => !gone.some((t) => t.prop === p)); g.targets = g.targets.filter((t) => t.fall < 1); for (let i = 0; i < gone.length; i++) place(); }
    // the move itself, as Showdown animates it
    if (g.anim) {
      const an = g.anim; an.t += dt * 1000;
      const ab = g0.box();
      const aPt = ab ? { x: (ab.x0 + ab.x1) / 2, y: (ab.y0 + ab.y1) / 2 } : { x: W * 0.25, y: H * 0.6 };
      const tq = an.target ? screenOf(an.target) : null;
      const dPt = tq ? { x: tq.x, y: tq.y } : { x: aPt.x + W * 0.35, y: aPt.y - H * 0.2 };
      const tint = an.m ? colOf(an.m) : '#ffffff';
      if (an.a) {
        const r = an.a.frame(ctx, an.t, { a: aPt, d: dPt, resolve: g0.resolve, tint });
        a.fxOff = r.attacker; if (an.target) an.target.prop.fxOff = r.defender;
        if (an.target && !an.hit && an.t >= an.a.duration * 0.62) { an.hit = true; land(an.target); }
        if (r.done) { a.fxOff = null; if (an.target) an.target.prop.fxOff = null; g.anim = null; }
      } else {
        // no Showdown animation for it: a ball of its colour
        const k = Math.min(1, an.t / 450);
        ctx.fillStyle = tint; ctx.beginPath(); ctx.arc(aPt.x + (dPt.x - aPt.x) * k, aPt.y + (dPt.y - aPt.y) * k - Math.sin(k * Math.PI) * 40, 12, 0, Math.PI * 2); ctx.fill();
        if (k >= 1) { if (an.target && !an.hit) { an.hit = true; land(an.target); } g.anim = null; }
      }
    }
    if (!g.anim && a.fxOff) a.fxOff = null;
    // move buttons, with uses left
    for (const b of btns()) {
      const m = moves[b.i], sel = b.i === g.sel && m.left > 0;
      ctx.globalAlpha = m.left > 0 ? 1 : 0.45;
      panel(ctx, b.x, b.y, b.w, b.h, { fill: sel ? colOf(m) : 'rgba(14,12,34,.82)', stroke: sel ? '#ffffff' : colOf(m), r: 10 });
      text(ctx, `${b.i + 1}. ${m.mv.name}`, b.x + b.w / 2, b.y + 17, { size: 14 });
      text(ctx, m.risky ? 'too risky to practise' : `${m.left}/${m.uses} uses · ${m.mv.category === 'status' ? 'powers up' : `${m.mv.power || '—'} power`}`, b.x + b.w / 2, b.y + 37, { size: 11, weight: 600, color: '#e9fff8' });
      ctx.globalAlpha = 1;
    }
    if (g.boost) text(ctx, '⚡ powered up', 100, H - 92, { size: 14, color: '#fff6a0' });
    hint(ctx, W, 'Pick a move (1–4), then click a dummy, can or target');
    text(ctx, `Knocked down ${g.hits}`, W - 90, 50, { size: 15 });
    showMsg(ctx, g, W, H, dt);
    if (g.sel < 0 || moves[g.sel]?.left <= 0) g.sel = moves.findIndex((m) => m.left > 0);
    // done when every use is spent (or nothing can be practised)
    if (!g.ending && !g.anim && (moves.every((m) => m.left <= 0) || g.t > 90)) {
      g.ending = true;
      g.perf = total ? Math.min(1, g.hits / Math.max(1, total * 0.7)) : 0;
      g.used = [...g.usedIds];
      g0.pose('happy', 1.2);
      setTimeout(() => { g.done = true; }, 900);
    }
    void home;
  };
  return g;
}

// ===== dodging run =====
function dodgingRun(g0) {
  const { yard, canvas, c, apt } = g0;
  yard.openFloor = true; yard.fenceImg = null;
  yard.props = (yard.props ?? []).filter((p) => ['tuft', 'flower'].includes(p.kind) || Math.abs(p.x) > 9);
  const a = g0.actor();
  const LANES = [-1.5, 0, 1.5];
  const st = { lane: 1, x: 0, z: 2, y: 0, vy: 0, v: 3.2 + (speciesOf(g0.idx, c)?.baseStats?.spe ?? 60) / 60, hits: 0, passed: 0, stun: 0, next: 1.2 };
  const obs = [];
  const g = { t: 0, len: 34, done: false };
  const spawn = () => {
    const r = Math.random();
    const kind = r < 0.4 ? 'crate' : r < 0.7 ? 'rock' : 'log';
    const lane = Math.floor(Math.random() * 3);
    const z = st.z + 20;
    const add = (x, art) => { const p = { ...art, kind: 'obstacle', x, z, decor: true, solid: false }; yard.props.push(p); return p; };
    if (kind === 'crate') obs.push({ kind, lanes: [lane], z, props: [add(LANES[lane], buildArt('chest', '#8a5a34'))], need: 'switch' });
    else if (kind === 'rock') obs.push({ kind, lanes: [lane], z, props: [add(LANES[lane], { img: Paint.rock(Math.floor(Math.random() * 99), '#8a8296', { w: 70, h: 44 }), h: 0.5 })], need: 'jump' });
    else { const l2 = lane === 2 ? 1 : lane + 1; obs.push({ kind, lanes: [lane, l2], z, props: [add(LANES[lane], buildArt('stump')), add(LANES[l2], buildArt('stump'))], need: 'jump' }); }
  };
  const jump = () => { if (st.y <= 0.01 && st.stun <= 0) { st.vy = 4.6 + apt; sfx('blip'); } };
  const shift = (d) => { st.lane = Math.max(0, Math.min(2, st.lane + d)); sfx('move'); };
  let downAt = null;
  const offs = [
    on(canvas, 'keydown', (e) => { if (e.key === 'ArrowLeft') shift(-1); else if (e.key === 'ArrowRight') shift(1); else if (e.key === 'ArrowUp' || e.code === 'Space') jump(); else return; e.preventDefault(); }),
    on(canvas, 'pointerdown', (e) => { downAt = g0.toBuf(e); }),
    on(window, 'pointerup', (e) => {
      if (!downAt) return;
      const p = g0.toBuf(e), dx = p.x - downAt.x, dy = p.y - downAt.y; downAt = null;
      if (Math.abs(dx) > 30 && Math.abs(dx) > Math.abs(dy)) shift(dx > 0 ? 1 : -1);
      else if (dy < -20 || Math.abs(dx) < 12) jump();
    }),
  ];
  g.dispose = () => { offs.forEach((f) => f()); yard.openFloor = false; };
  g.frame = (dt, ctx) => {
    const W = yard.W, H = yard.H;
    g.t += dt; st.stun = Math.max(0, st.stun - dt); st.next -= dt;
    const run = g.t < g.len;
    if (run) { st.v += dt * 0.06; st.z += (st.stun > 0 ? st.v * 0.3 : st.v) * dt; }
    if (run && st.next <= 0) { spawn(); st.next = Math.max(0.55, 1.4 - g.t / 40) * (0.8 + Math.random() * 0.5); }
    st.x += (LANES[st.lane] - st.x) * Math.min(1, dt * 10);
    st.vy -= 12 * dt; st.y = Math.max(0, st.y + st.vy * dt); if (st.y === 0) st.vy = Math.max(0, st.vy);
    a.x = st.x; a.z = st.z; a.tx = a.x; a.tz = a.z; a.y = st.y + (a.fly ? 0.25 : 0);
    a.running = run && st.stun <= 0; a.state = a.running ? 'walk' : 'idle'; a.away = true;
    // obstacles: did we make it?
    for (const o of obs) {
      if (o.done || o.z > st.z + 0.15) continue;
      if (o.z < st.z - 0.4) { o.done = true; continue; }
      if (!o.lanes.includes(st.lane)) continue;
      const cleared = o.need === 'jump' && st.y > 0.35;
      o.done = true;
      if (cleared) { st.passed++; sfx('heal'); }
      else { st.hits++; st.stun = 0.6; a.squash = 1; sfx('miss'); g0.emote('wow'); say(g, o.need === 'jump' ? 'Jump it!' : 'Switch lanes!', 0.6); }
    }
    // drop what's behind us
    const old = obs.filter((o) => o.z < st.z - 4);
    if (old.length) { yard.props = yard.props.filter((p) => !old.some((o) => o.props.includes(p))); for (const o of old) obs.splice(obs.indexOf(o), 1); }
    yard.view({ pitch: 0.32, x: st.x * 0.4, z: st.z + 2.6, dist: 0.6, yaw: 0 });
    hint(ctx, W, 'Swipe or ← → to change lanes · tap, swipe up or space to jump');
    text(ctx, `${Math.ceil(Math.max(0, g.len - g.t))} s · ${Math.round(st.z)} m · bumps ${st.hits}`, W / 2, H - 24, { size: 16 });
    showMsg(ctx, g, W, H, dt);
    if (!run && !g.ending) { g.ending = true; g.perf = Math.max(0, Math.min(1, (st.z / 120) * 0.6 + (1 - st.hits / 6) * 0.4)); g0.pose('happy', 1.5); setTimeout(() => { g.done = true; }, 900); }
  };
  return g;
}

// ===== smash =====
function smash(g0) {
  const { yard, canvas, apt, c } = g0;
  yard.view({ pitch: 0.26, z: 2.8, snap: true });
  g0.stage(-1.6, 2.0, { top: 70 }); g0.actor().flip = false;
  const home = { x: g0.actor().x, z: g0.actor().z };
  const atk = speciesOf(g0.idx, c)?.baseStats?.atk ?? 60;
  const ITEMS = [
    { name: 'Plank', col: '#c89a60', tough: 0.35 }, { name: 'Two planks', col: '#a87a40', tough: 0.5 },
    { name: 'Brick', col: '#b0503a', tough: 0.62 }, { name: 'Stone block', col: '#8a8296', tough: 0.74 }, { name: 'Boulder', col: '#6a6276', tough: 0.85 },
  ];
  const art = (it) => { const cv = document.createElement('canvas'); cv.width = 60; cv.height = 70; const x = cv.getContext('2d'); x.fillStyle = '#5a3a1c'; x.fillRect(26, 34, 8, 36); x.fillStyle = it.col; x.fillRect(6, 6, 48, 30); x.fillStyle = 'rgba(255,255,255,.25)'; x.fillRect(6, 6, 48, 4); x.fillStyle = 'rgba(0,0,0,.2)'; x.fillRect(6, 32, 48, 4); return { img: cv, h: 1.1 }; };
  const g = { t: 0, i: 0, broken: 0, power: 0, dir: 1, charging: false, phase: 'ready', anim: 0, done: false, prop: null };
  const setItem = () => { if (g.prop) yard.props = yard.props.filter((p) => p !== g.prop); const it = ITEMS[g.i]; if (!it) return; g.prop = { ...art(it), kind: 'smash', x: 1.4, z: 2.6, decor: true, solid: false }; yard.props.push(g.prop); };
  setItem();
  // the sweet spot is wider for strong creatures
  const zoneW = 0.1 + apt * 0.08 + Math.max(0, (atk - 60) / 900);
  const release = () => {
    if (g.phase !== 'charge') return;
    g.phase = 'swing'; g.anim = 0;
    const it = ITEMS[g.i];
    g.hit = g.power >= it.tough && g.power <= it.tough + zoneW + 0.12;
    g0.walk(g.prop.x - 0.7, g.prop.z - 0.05, 7);
  };
  const offs = [
    on(canvas, 'pointerdown', () => { if (g.phase === 'ready') { g.phase = 'charge'; g.power = 0; g.dir = 1; } }),
    on(window, 'pointerup', release),
    on(canvas, 'keydown', (e) => { if (e.code === 'Space' && g.phase === 'ready') { e.preventDefault(); g.phase = 'charge'; g.power = 0; g.dir = 1; } }),
    on(canvas, 'keyup', (e) => { if (e.code === 'Space') release(); }),
  ];
  g.dispose = () => offs.forEach((f) => f());
  g.frame = (dt, ctx) => {
    const W = yard.W, H = yard.H;
    g.t += dt;
    const a = g0.actor(), it = ITEMS[g.i];
    if (g.phase === 'charge') { g.power += g.dir * dt * (0.9 + g.i * 0.15); if (g.power > 1) { g.power = 1; g.dir = -1; } if (g.power < 0) { g.power = 0; g.dir = 1; } }
    if (g.phase === 'swing' && !a.goTo) {
      g.phase = 'result'; a.squash = 1;
      if (g.hit) { g.broken++; sfx('level'); say(g, `Smashed the ${it.name.toLowerCase()}!`); for (let i = 0; i < 18; i++) yard.sparks.push({ kind: 'pebble', x: g.prop.x, y: 0.8, z: g.prop.z, vx: (Math.random() - 0.3) * 4, vy: 1.5 + Math.random() * 2.5, vz: (Math.random() - 0.5), g: 7, life: 0.9, ph: 0, c: Math.random() < 0.5 ? 0 : 1 }); g.prop.h = 0.05; g0.hop(); }
      else { sfx('miss'); say(g, g.power < it.tough ? 'Not hard enough!' : 'Too wild: it bounced off!'); g0.emote('wow'); g.prop.fxOff = { dx: 0, dy: 0, scale: 1, opacity: 1 }; }
      setTimeout(() => { g0.walk(home.x, home.z, 3); g.i++; if (g.prop) g.prop.fxOff = null; setItem(); g.phase = g.i < ITEMS.length ? 'ready' : 'end'; }, 1000);
    }
    if (g.prop?.fxOff) g.prop.fxOff.dx = Math.sin(g.t * 60) * 3;
    // the meter
    if (it && g.phase !== 'end') {
      const mx = W - 80, my = 70, mh = H - 170;
      panel(ctx, mx - 12, my - 12, 48, mh + 24, { r: 10 });
      ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(mx, my, 24, mh);
      ctx.fillStyle = '#3fb26a'; ctx.fillRect(mx, my + (1 - it.tough - zoneW) * mh, 24, zoneW * mh);
      ctx.fillStyle = '#ffd23f'; ctx.fillRect(mx, my + (1 - g.power) * mh, 24, g.power * mh);
      ctx.fillStyle = '#fff'; ctx.fillRect(mx - 6, my + (1 - g.power) * mh - 2, 36, 4);
      text(ctx, it.name, W / 2, 52, { size: 18 });
    }
    hint(ctx, W, 'Hold to charge, let go when the bar is in the green');
    text(ctx, `Broken ${g.broken} of ${ITEMS.length}`, W / 2, H - 24, { size: 16 });
    showMsg(ctx, g, W, H, dt);
    if (g.phase === 'end' && !g.ending) { g.ending = true; g.perf = g.broken / ITEMS.length; g0.pose('happy', 1.4); setTimeout(() => { g.done = true; }, 900); }
  };
  return g;
}

// ===== leap and glide =====
function glide(g0) {
  const { yard, canvas, apt } = g0;
  yard.openFloor = true; yard.fenceImg = null;
  yard.props = (yard.props ?? []).filter((p) => ['tuft', 'flower'].includes(p.kind) || Math.abs(p.x) > 8);
  const a = g0.actor();
  const flier = !!a.fly;
  const st = { z: 2, y: 1.2, vy: 0, v: 3.4, passed: 0, missed: 0, next: 0.8 };
  const rings = [];
  const g = { t: 0, len: 32, done: false };
  const flap = () => { st.vy = (flier ? 3.4 : 3.9) + apt * 0.6; sfx('blip'); a.hop = 0.6; };
  const offs = [on(canvas, 'pointerdown', (e) => { e.preventDefault(); flap(); }), on(canvas, 'keydown', (e) => { if (e.code === 'Space' || e.key === 'ArrowUp') { e.preventDefault(); flap(); } })];
  g.dispose = () => { offs.forEach((f) => f()); yard.openFloor = false; };
  g.frame = (dt, ctx) => {
    const W = yard.W, H = yard.H;
    g.t += dt; st.next -= dt;
    const run = g.t < g.len;
    if (run) st.z += st.v * dt;
    st.vy -= (flier ? 5.5 : 8) * dt; st.y += st.vy * dt;
    if (st.y < 0) { st.y = 0; st.vy = 0; } if (st.y > 3.4) { st.y = 3.4; st.vy = Math.min(0, st.vy); }
    a.x = 0; a.z = st.z; a.tx = 0; a.tz = st.z; a.y = st.y; a.running = run; a.state = run ? 'walk' : 'idle'; a.away = true;
    if (run && st.next <= 0) { rings.push({ z: st.z + 16, y: 0.5 + Math.random() * 2.4 }); st.next = 1.5 + Math.random() * 0.8; }
    for (const r of rings) {
      if (r.done || r.z > st.z) continue;
      r.done = true;
      if (Math.abs(st.y + 0.3 - r.y) < 0.55) { st.passed++; r.hit = true; sfx('heal'); } else { st.missed++; sfx('miss'); }
    }
    yard.view({ pitch: 0.24, x: 0, z: st.z + 2.4, dist: 0.62, yaw: 0 });
    // the rings, drawn as hoops in the air (far ones first)
    for (const r of rings.filter((x) => x.z > st.z - 1.5).sort((p, q) => q.z - p.z)) {
      const q = yard.project(0, r.y, r.z); if (!q) continue;
      const rr = q.k * 0.55;
      ctx.lineWidth = Math.max(2, q.k * 0.07);
      ctx.strokeStyle = r.done ? (r.hit ? 'rgba(125,255,170,.5)' : 'rgba(255,120,120,.5)') : '#ffd23f';
      ctx.beginPath(); ctx.ellipse(q.x, q.y, rr, rr, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(q.x, q.y, rr * 0.86, rr * 0.86, 0, 0, Math.PI * 2); ctx.stroke();
    }
    hint(ctx, W, flier ? 'Tap (or space) to flap through the rings' : 'Tap (or space) to bound up through the rings');
    text(ctx, `${Math.ceil(Math.max(0, g.len - g.t))} s · rings ${st.passed}`, W / 2, H - 24, { size: 16 });
    if (!run && !g.ending) { g.ending = true; const tot = st.passed + st.missed; g.perf = tot ? st.passed / tot : 0; g0.pose('happy', 1.4); setTimeout(() => { g.done = true; }, 900); }
  };
  return g;
}
