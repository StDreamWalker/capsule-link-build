// Training: a set of drills, like Duck Life's. No stars and no pass or fail. On their own they're for fun
// and coins; holding a power item that suits the drill, the effort goes into that item's stat:
//   moves    Move practice: its own moves against dummies, cans and targets all around it, with Showdown's
//            real move animations. A few uses per move; moves that would knock the user out are too risky.
//                                                          Power Bracer → Attack, Power Lens → Sp. Atk
//   dodge    Dodge the rocks: seen from above, yellow circles appear, flash and turn red, and boulders
//            crash down (lightning in the sky, for fliers; on the seafloor, for swimmers). Click where to go;
//            how fast they get there is their Speed. One hit ends it.          Power Anklet → Speed
//   smash    Strength: click as fast as you can to keep the power in the green for a whole second.
//                                                          Power Bracer → Attack, Power Belt → Defence
//   swipe    Catch and swipe: things are thrown at them; before each one lands, swipe the way the arrow
//            shows. It speeds up until one gets through.   Power Weight → HP, Power Band → Sp. Def
import { buildArt } from './buildArt.js';
import * as Paint from './paint.js';
import { sfx } from './audio.js';
import { prepareMoveAnim, standInMove } from './sdanim/player.js';
import { TYPE_FX, fxType } from './moveFx.js';
import { speciesOf, POWER_ITEMS, powerItemOf } from '../engine/index.js';

export const DRILLS = [
  { id: 'moves', name: 'Move practice', stat: 'Attack or Sp. Atk', items: ['power-bracer', 'power-lens'], desc: 'Its own moves against dummies, cans and targets all around it. A few uses each.' },
  { id: 'dodge', name: 'Dodge the rocks', stat: 'Speed', items: ['power-anklet'], desc: 'From above: get out of the circles before the boulders land. One hit and it’s over.' },
  { id: 'smash', name: 'Strength', stat: 'Attack or Defence', items: ['power-bracer', 'power-belt'], desc: 'Click fast to keep the power in the green for a second, and smash it.' },
  { id: 'swipe', name: 'Catch and swipe', stat: 'HP or Sp. Def', items: ['power-weight', 'power-band'], desc: 'Swipe the way the arrow shows before each throw lands. It speeds up until one gets through.' },
];
/** What a drill does for this creature: { fits, item, line } (the words for the drill picker). */
export function drillPlan(idx, c, drill) {
  const d = DRILLS.find((x) => x.id === drill) ?? DRILLS[0];
  const pw = powerItemOf(idx, c);
  const names = d.items.map((id) => POWER_ITEMS.find((p) => p.id === id)?.name).filter(Boolean);
  if (pw && pw.drills.includes(d.id)) return { fits: true, item: pw, line: `Holding the ${pw.name}: effort goes into ${{ hp: 'HP', atk: 'Attack', def: 'Defence', spa: 'Sp. Atk', spd: 'Sp. Def', spe: 'Speed' }[pw.stat]}.` };
  return { fits: false, item: pw, line: `For fun and coins.${pw ? ` (The ${pw.name} doesn’t work here.)` : ''} To train ${d.stat}, hold ${names.join(' or ')}.` };
}
/** Moves too risky to practise: they knock the user out, or end things in one hit. */
export const RISKY = /^(explosion|self-?destruct|memento|final gambit|healing wish|lunar dance|misty explosion|fissure|guillotine|horn drill|sheer cold|destiny bond|perish song|curse|belly drum)$/i;

// ---------- drawing and input helpers ----------
function text(ctx, s, x, y, { size = 18, color = '#fff', align = 'center', weight = 700 } = {}) {
  ctx.font = `${weight} ${size}px "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif`; ctx.textAlign = align; ctx.textBaseline = 'middle';
  ctx.fillStyle = 'rgba(10,8,30,.6)'; ctx.fillText(s, x + 1.5, y + 1.5); ctx.fillStyle = color; ctx.fillText(s, x, y); ctx.textAlign = 'start';
}
function panel(ctx, x, y, w, h, { fill = 'rgba(14,12,34,.8)', stroke = 'rgba(125,255,207,.5)', r = 12 } = {}) {
  ctx.fillStyle = fill; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, w, h, r) : ctx.rect(x, y, w, h); ctx.fill();
  ctx.strokeStyle = stroke; ctx.lineWidth = 2; ctx.stroke();
}
const hint = (ctx, W, s) => text(ctx, s, W / 2, 22, { size: 15, weight: 600, color: '#e9fff8' });
const on = (el, type, fn, opt) => { el.addEventListener(type, fn, opt); return () => el.removeEventListener(type, fn, opt); };
const say = (g, m, t = 0.9) => { g.msg = m; g.msgT = t; };
const showMsg = (ctx, g, W, H, dt) => { g.msgT = Math.max(0, (g.msgT ?? 0) - dt); if (g.msgT > 0) text(ctx, g.msg, W / 2, H * 0.3, { size: 26, color: '#fff6a0' }); };
const sdName = (mv) => mv.showdownName ?? mv.name;
/** Showdown's animation for the move, or (for a move it doesn't know) one of the same type. */
const animFor = (idx, mv) => prepareMoveAnim(sdName(mv)) ?? prepareMoveAnim(standInMove(fxType(idx, mv.type), mv.category));

/** The training activity: g0.extra.drill picks the drill. */
export function training(g0) {
  const fn = { moves: movePractice, dodge: dodgeField, smash: strength, swipe: swipeDrill, glide: swipeDrill }[g0.extra?.drill] ?? movePractice;
  return fn(g0);
}

// ===== move practice =====
function movePractice(g0) {
  const { yard, canvas, idx, c, apt } = g0;
  // zoomed out a little, with them in the middle and targets all around
  yard.view({ pitch: 0.46, z: 3.1, dist: 1.32, snap: true });
  g0.stage(0, 3.0, { top: 80 }); g0.actor().flip = false;
  const home = { x: g0.actor().x, z: g0.actor().z };
  const moves = (c.moves ?? []).map((m) => ({ m, mv: idx.moves.get(m.id) })).filter((x) => x.mv).slice(0, 4).map(({ m, mv }) => {
    const risky = RISKY.test(mv.name) || (Number(mv.power) || 0) >= 180;
    const uses = risky ? 0 : Math.max(1, Math.min(5, Math.round((mv.pp ?? m.pp ?? 10) / 3)));
    return { mv, uses, left: uses, risky, type: fxType(idx, mv.type) };
  });
  if (!moves.length) moves.push({ mv: { id: 'tackle', name: 'Tackle', category: 'physical', power: 40, type: speciesOf(idx, c)?.types?.[0] }, uses: 5, left: 5, type: 'normal' });
  const g = { t: 0, sel: moves.findIndex((m) => m.left > 0), targets: [], hits: 0, used: 0, boost: 0, anim: null, done: false, usedIds: new Set() };
  const total = moves.reduce((a, m) => a + m.uses, 0);
  const KINDS = ['dummy', 'can', 'target'];
  const SPOTS = Array.from({ length: 8 }, (_, i) => { const ang = (i / 8) * Math.PI * 2 + 0.3, r = 1.9 + (i % 2) * 0.6; return [yard.clampX(home.x + Math.cos(ang) * r * 1.2), yard.clampZ(home.z + Math.sin(ang) * r * 0.75)]; });
  const place = () => {
    const free = SPOTS.filter(([x, z]) => !g.targets.some((t) => Math.hypot(t.x - x, t.z - z) < 0.5));
    const [x, z] = free[Math.floor(Math.random() * free.length)] ?? SPOTS[0];
    const kind = KINDS[Math.floor(Math.random() * KINDS.length)];
    const art = buildArt(kind, kind === 'can' ? ['#e5484d', '#3b8ae0', '#3fb26a'][Math.floor(Math.random() * 3)] : '#e5484d');
    const prop = { ...art, kind, x, z, h0: art.h, decor: true, solid: false };
    yard.props.push(prop);
    g.targets.push({ kind, x, z, hp: kind === 'dummy' ? 2 : 1, prop, fall: 0 });
  };
  for (let i = 0; i < 3; i++) place();
  const btns = () => { const W = yard.W, H = yard.H, bw = Math.min(200, (W - 40) / moves.length - 10); return moves.map((m, i) => ({ i, x: W / 2 - (moves.length * (bw + 10)) / 2 + i * (bw + 10), y: H - 66, w: bw, h: 52 })); };
  const colOf = (m) => idx.types.get(m.mv.type)?.color ?? TYPE_FX[m.type]?.col[0] ?? '#ffffff';
  const screenOf = (t) => yard.project(t.x, (t.prop.h0 ?? 1) * 0.5, t.z);
  const use = (target) => {
    const m = moves[g.sel];
    if (!m || g.anim || m.left <= 0) return;
    if (m.mv.category === 'status') { m.left--; g.used++; g.boost = 1; g.usedIds.add(m.mv.id); say(g, `${m.mv.name}: powered up!`); yard.burst(g0.actor(), 10); g0.pose('happy', 0.8); sfx('heal'); g.anim = { status: true, t: 0, a: animFor(idx, m.mv) }; return; }
    if (!target) return;
    m.left--; g.used++; g.usedIds.add(m.mv.id);
    g0.actor().flip = target.x < g0.actor().x;
    g0.cry('happy');
    g.anim = { m, target, t: 0, a: animFor(idx, m.mv), hit: false };
  };
  const offs = [
    on(canvas, 'pointerdown', (e) => {
      const p = g0.toBuf(e);
      const b = btns().find((bb) => p.x > bb.x && p.x < bb.x + bb.w && p.y > bb.y && p.y < bb.y + bb.h);
      if (b) { if (moves[b.i].left > 0) { g.sel = b.i; sfx('move'); if (moves[b.i].mv.category === 'status') use(null); } else sfx('miss'); return; }
      let best = null, bd = 1e9;
      for (const t of g.targets) { if (t.fall) continue; const q = screenOf(t); if (!q) continue; const d = Math.hypot(q.x - p.x, q.y - p.y); if (d < Math.max(48, q.k * 0.8) && d < bd) { bd = d; best = t; } }
      if (best) use(best);
    }),
    on(canvas, 'keydown', (e) => { const n = Number(e.key); if (n >= 1 && n <= moves.length && moves[n - 1].left > 0) { g.sel = n - 1; sfx('move'); } }),
  ];
  g.dispose = () => offs.forEach((f) => f());
  const land = (target) => {
    target.hp -= 1 + (g.boost ? 1 : 0); g.boost = 0; sfx('blip');
    for (let i = 0; i < 10; i++) yard.sparks.push({ kind: target.kind === 'can' ? 'glint' : target.kind === 'dummy' ? 'leaf' : 'spark', x: target.x, y: 0.6, z: target.z, vx: (Math.random() - 0.5) * 3, vy: 1 + Math.random() * 2, vz: 0, g: 5, life: 0.7, ph: 0, c: Math.random() < 0.5 ? 0 : 1 });
    if (target.hp <= 0 && !target.fall) { target.fall = 0.01; g.hits++; say(g, target.kind === 'target' ? 'Bullseye!' : target.kind === 'dummy' ? 'Down it goes!' : 'Clang!'); g0.hop(); }
  };
  g.frame = (dt, ctx) => {
    const W = yard.W, H = yard.H;
    g.t += dt;
    const a = g0.actor();
    // targets topple, and new ones are set up
    for (const t of g.targets) { if (t.fall > 0) { t.fall = Math.min(1, t.fall + dt * 2.4); t.prop.h = t.prop.h0 * Math.max(0.03, 1 - t.fall); } }
    const gone = g.targets.filter((t) => t.fall >= 1);
    if (gone.length) { yard.props = yard.props.filter((p) => !gone.some((t) => t.prop === p)); g.targets = g.targets.filter((t) => t.fall < 1); for (let i = 0; i < gone.length; i++) place(); }
    // the move itself, as Showdown animates it
    if (g.anim) {
      const an = g.anim; an.t += dt * 1000;
      const ab = g0.box();
      const aPt = ab ? { x: (ab.x0 + ab.x1) / 2, y: (ab.y0 + ab.y1) / 2 } : { x: W * 0.25, y: H * 0.6 };
      const tq = an.target ? screenOf(an.target) : null;
      const dPt = tq ? { x: tq.x, y: tq.y } : { x: aPt.x + W * 0.35, y: aPt.y - H * 0.2 };
      const tint = an.m ? colOf(an.m) : '#ffffff';
      if (an.a) {
        const r = an.a.frame(ctx, an.t, { a: aPt, d: dPt, resolve: g0.resolve, tint });
        a.fxOff = r.attacker; if (an.target) an.target.prop.fxOff = r.defender;
        if (an.target && !an.hit && an.t >= an.a.duration * 0.62) { an.hit = true; land(an.target); }
        if (r.done) { a.fxOff = null; if (an.target) an.target.prop.fxOff = null; g.anim = null; }
      } else {
        // no Showdown animation for it: a ball of its colour
        const k = Math.min(1, an.t / 450);
        ctx.fillStyle = tint; ctx.beginPath(); ctx.arc(aPt.x + (dPt.x - aPt.x) * k, aPt.y + (dPt.y - aPt.y) * k - Math.sin(k * Math.PI) * 40, 12, 0, Math.PI * 2); ctx.fill();
        if (k >= 1) { if (an.target && !an.hit) { an.hit = true; land(an.target); } g.anim = null; }
      }
    }
    if (!g.anim && a.fxOff) a.fxOff = null;
    // move buttons, with uses left
    for (const b of btns()) {
      const m = moves[b.i], sel = b.i === g.sel && m.left > 0;
      ctx.globalAlpha = m.left > 0 ? 1 : 0.45;
      panel(ctx, b.x, b.y, b.w, b.h, { fill: sel ? colOf(m) : 'rgba(14,12,34,.82)', stroke: sel ? '#ffffff' : colOf(m), r: 10 });
      text(ctx, `${b.i + 1}. ${m.mv.name}`, b.x + b.w / 2, b.y + 17, { size: 14 });
      text(ctx, m.risky ? 'too risky to practise' : `${m.left}/${m.uses} uses · ${m.mv.category === 'status' ? 'powers up' : `${m.mv.power || '—'} power`}`, b.x + b.w / 2, b.y + 37, { size: 11, weight: 600, color: '#e9fff8' });
      ctx.globalAlpha = 1;
    }
    if (g.boost) text(ctx, '⚡ powered up', 100, H - 92, { size: 14, color: '#fff6a0' });
    hint(ctx, W, 'Pick a move (1–4), then click a dummy, can or target');
    text(ctx, `Knocked down ${g.hits}`, W - 90, 50, { size: 15 });
    showMsg(ctx, g, W, H, dt);
    if (g.sel < 0 || moves[g.sel]?.left <= 0) g.sel = moves.findIndex((m) => m.left > 0);
    // done when every use is spent (or nothing can be practised)
    if (!g.ending && !g.anim && (moves.every((m) => m.left <= 0) || g.t > 90)) {
      g.ending = true;
      g.perf = total ? Math.min(1, g.hits / Math.max(1, total * 0.7)) : 0;
      g.used = [...g.usedIds];
      g0.pose('happy', 1.2);
      setTimeout(() => { g.done = true; }, 900);
    }
    void home;
  };
  return g;
}


// ===== dodge the rocks (from above) =====
function dodgeField(g0) {
  const { yard, canvas, idx, c, apt, extra } = g0;
  const arena = extra.arena ?? 'ground'; // 'ground' | 'sky' | 'sea'
  const S = yard.S;
  const C = { x: 0, z: (S.z0 + S.z1) / 2 };
  const R = Math.max(2.4, Math.min(3.6, (S.x1 - S.x0) / 2 - 0.8, (S.z1 - S.z0) / 2 - 0.5));
  // a clear field: nothing in the way
  yard.props = (yard.props ?? []).filter((p) => Math.hypot(p.x - C.x, (p.z - C.z) * 1.1) > R + 1.4);
  yard.fenceImg = null; yard.openFloor = true;
  const a = g0.actor();
  a.x = C.x; a.z = C.z; a.tx = a.x; a.tz = a.z; a.away = true;
  if (arena === 'sky' || arena === 'sea') { a.hoverY = 0.35; a.y = 0.35; }
  // how fast they cross the field: their Speed
  const sp = speciesOf(idx, c);
  const spe = (sp?.baseStats?.spe ?? 60) + (c.effort?.spe ?? 0) / 8;
  const speed = 1.4 + spe / 45 + apt * 0.4;
  const g = { t: 0, done: false, hz: [], next: 1.2, goal: null, dodged: 0, hitAt: null, flash: 0 };
  const HR = 0.62; // how big a crash is
  const inField = (x, z) => { const dx = x - C.x, dz = (z - C.z) * 1.15, d = Math.hypot(dx, dz); return d <= R ? { x, z } : { x: C.x + (dx / d) * R, z: C.z + (dz / d) * R / 1.15 }; };
  const offs = [
    on(canvas, 'pointerdown', (e) => {
      if (g.hitAt) return;
      const p = g0.toBuf(e); const fp = yard.floorAt(p.x, p.y);
      if (fp) { g.goal = inField(fp.x, fp.z); sfx('move'); }
    }),
  ];
  g.dispose = () => { offs.forEach((f) => f()); yard.openFloor = false; };
  const spawn = () => {
    // most land near them (so they have to move), some anywhere
    const near = Math.random() < 0.55;
    const ang = Math.random() * Math.PI * 2, d = near ? Math.random() * 0.9 : Math.random() * R;
    const base = near ? { x: a.x, z: a.z } : C;
    const at = inField(base.x + Math.cos(ang) * d, base.z + Math.sin(ang) * d * 0.8);
    const warn = Math.max(0.75, 1.7 - g.t / 40);
    g.hz.push({ ...at, t: 0, warn, landed: false });
  };
  const ring = (ctx, x, z, r, fill, stroke) => {
    ctx.beginPath();
    for (let i = 0; i <= 24; i++) { const q = yard.project(x + Math.cos((i / 24) * Math.PI * 2) * r, 0.02, z + Math.sin((i / 24) * Math.PI * 2) * r); if (!q) return; i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y); }
    ctx.closePath(); if (fill) { ctx.fillStyle = fill; ctx.fill(); } if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 2; ctx.stroke(); }
  };
  const boulder = Paint.rock(5, arena === 'sea' ? '#6a7c8a' : '#8a8296', { w: 56, h: 44 });
  g.frame = (dt, ctx) => {
    const W = yard.W, H = yard.H;
    yard.view({ pitch: 1.0, x: C.x, z: C.z - 0.4, dist: 0.92, yaw: 0 });
    if (!g.hitAt) g.t += dt;
    // walking where you clicked, at their own speed
    if (g.goal && !g.hitAt) {
      const dx = g.goal.x - a.x, dz = g.goal.z - a.z, d = Math.hypot(dx, dz);
      if (d < 0.05) { g.goal = null; a.state = 'idle'; a.running = false; }
      else { const st = Math.min(d, speed * dt); a.x += (dx / d) * st; a.z += (dz / d) * st; a.flip = dx < 0; a.state = 'walk'; a.running = true; }
      a.tx = a.x; a.tz = a.z;
    } else if (!g.hitAt) { a.state = 'idle'; a.running = false; }
    // the field's edge
    ring(ctx, C.x, C.z, R, null, arena === 'sky' ? 'rgba(255,255,255,.5)' : 'rgba(255,255,255,.35)');
    // warnings, then the crash
    g.next -= dt;
    if (!g.hitAt && g.next <= 0) { spawn(); if (g.t > 12 && Math.random() < Math.min(0.6, g.t / 60)) spawn(); g.next = Math.max(0.35, 1.25 - g.t / 35) * (0.7 + Math.random() * 0.6); }
    for (const h of g.hz) {
      h.t += dt;
      const k = h.t / h.warn;
      if (!h.landed) {
        const red = k > 0.6, blink = k > 0.35 && Math.floor(h.t * (red ? 14 : 8)) % 2 === 0;
        ring(ctx, h.x, h.z, HR, red ? `rgba(229,72,77,${blink ? 0.55 : 0.35})` : `rgba(255,210,63,${blink ? 0.5 : 0.3})`, red ? '#ff4040' : '#ffd23f');
        // the boulder (or bolt) on its way down
        if (arena !== 'sky' && k > 0.7) {
          const y = Math.max(0, (1 - (k - 0.7) / 0.3) * 7);
          const q = yard.project(h.x, y, h.z);
          if (q) { const w = q.k * 0.9, hh = w * 0.8; ctx.drawImage(boulder, q.x - w / 2, q.y - hh, w, hh); }
        }
        if (k >= 1) {
          h.landed = true; h.life = 0.6;
          const hit = Math.hypot(a.x - h.x, (a.z - h.z) * 1.1) < HR + 0.15;
          if (arena === 'sky') { h.bolt = 0.25; g.flash = 0.15; sfx('miss'); for (let i = 0; i < 10; i++) yard.sparks.push({ kind: 'spark', x: h.x, y: 0.3, z: h.z, vx: (Math.random() - 0.5) * 4, vy: 1 + Math.random() * 2, vz: (Math.random() - 0.5) * 2, g: 6, life: 0.5, ph: 0, c: 0 }); }
          else { sfx('blip'); for (let i = 0; i < 14; i++) yard.sparks.push({ kind: 'pebble', x: h.x, y: 0.3, z: h.z, vx: (Math.random() - 0.5) * 4, vy: 1.5 + Math.random() * 2.5, vz: (Math.random() - 0.5) * 2, g: 8, life: 0.8, ph: 0, c: Math.random() < 0.5 ? 0 : 1 }); }
          if (hit && !g.hitAt) { g.hitAt = g.t; a.squash = 1; a.state = 'idle'; a.running = false; g0.emote('wow'); say(g, arena === 'sky' ? 'Zapped!' : 'Bonk!', 1.2); }
          else if (!hit) g.dodged++;
        }
      } else {
        h.life -= dt;
        if (h.bolt > 0) {
          // lightning: a jagged line from the top of the picture to the ground
          h.bolt -= dt;
          const q = yard.project(h.x, 0, h.z);
          if (q) {
            ctx.strokeStyle = '#fffbe0'; ctx.lineWidth = 3; ctx.shadowColor = '#9ad8ff'; ctx.shadowBlur = 14; ctx.beginPath(); ctx.moveTo(q.x + (Math.random() - 0.5) * 40, 0);
            for (let i = 1; i <= 8; i++) ctx.lineTo(q.x + (Math.random() - 0.5) * 30 * (1 - i / 8), (q.y * i) / 8);
            ctx.stroke(); ctx.shadowBlur = 0;
          }
        } else if (arena !== 'sky' && h.life > 0.3) {
          // the boulder breaking apart
          const q = yard.project(h.x, 0, h.z); if (q) { const w = q.k * 0.9 * (1 + (0.6 - h.life)); ctx.globalAlpha = Math.max(0, (h.life - 0.3) / 0.3); ctx.drawImage(boulder, q.x - w / 2, q.y - w * 0.7, w, w * 0.8); ctx.globalAlpha = 1; }
        }
      }
    }
    g.hz = g.hz.filter((h) => !h.landed || h.life > 0);
    if (g.flash > 0) { g.flash -= dt; ctx.fillStyle = `rgba(255,255,240,${g.flash * 2})`; ctx.fillRect(0, 0, W, H); }
    hint(ctx, W, g.hitAt ? '' : 'Click where to go. Get out of the circles before they turn red!');
    text(ctx, `${Math.floor(g.t)} s · dodged ${g.dodged}`, W / 2, H - 24, { size: 16 });
    showMsg(ctx, g, W, H, dt);
    if (g.hitAt != null && !g.ending) { g.ending = true; g.perf = Math.max(0, Math.min(1, g.t / 45)); setTimeout(() => { g.done = true; }, 1400); }
    if (!g.ending && g.t > 120) { g.ending = true; g.perf = 1; g0.pose('happy', 1.4); setTimeout(() => { g.done = true; }, 900); }
  };
  return g;
}

// ===== strength: click fast to keep it in the green =====
function strength(g0) {
  const { yard, canvas, apt, c } = g0;
  yard.view({ pitch: 0.26, z: 2.8, snap: true });
  g0.stage(-1.6, 2.0, { top: 70 }); g0.actor().flip = false;
  const home = { x: g0.actor().x, z: g0.actor().z };
  const atk = (speciesOf(g0.idx, c)?.baseStats?.atk ?? 60) + (c.effort?.atk ?? 0) / 8;
  const ITEMS = [
    { name: 'Plank', col: '#c89a60', tough: 0.3 }, { name: 'Two planks', col: '#a87a40', tough: 0.42 },
    { name: 'Brick', col: '#b0503a', tough: 0.55 }, { name: 'Stone block', col: '#8a8296', tough: 0.66 }, { name: 'Boulder', col: '#6a6276', tough: 0.76 },
  ];
  const art = (it) => { const cv = document.createElement('canvas'); cv.width = 60; cv.height = 70; const x = cv.getContext('2d'); x.fillStyle = '#5a3a1c'; x.fillRect(26, 34, 8, 36); x.fillStyle = it.col; x.fillRect(6, 6, 48, 30); x.fillStyle = 'rgba(255,255,255,.25)'; x.fillRect(6, 6, 48, 4); x.fillStyle = 'rgba(0,0,0,.2)'; x.fillRect(6, 32, 48, 4); return { img: cv, h: 1.1 }; };
  const g = { t: 0, i: 0, broken: 0, power: 0, hold: 0, phase: 'ready', left: 10, done: false, prop: null, clicks: 0 };
  const setItem = () => { if (g.prop) yard.props = yard.props.filter((p) => p !== g.prop); const it = ITEMS[g.i]; if (!it) return; g.prop = { ...art(it), kind: 'smash', x: 1.4, z: 2.6, decor: true, solid: false }; yard.props.push(g.prop); g.power = 0; g.hold = 0; g.left = 10; };
  setItem();
  const zoneW = 0.12 + apt * 0.05;
  const push = 0.075 + atk / 2400 + apt * 0.02;
  const tap = () => {
    if (g.phase === 'ready') g.phase = 'pump';
    if (g.phase !== 'pump') return;
    g.power = Math.min(1, g.power + push); g.clicks++;
    g0.actor().squash = 0.4; sfx('blip');
  };
  const offs = [
    on(canvas, 'pointerdown', (e) => { e.preventDefault(); tap(); }),
    on(canvas, 'keydown', (e) => { if (e.code === 'Space' || e.key === 'Enter') { e.preventDefault(); if (!e.repeat) tap(); } }),
  ];
  g.dispose = () => offs.forEach((f) => f());
  g.frame = (dt, ctx) => {
    const W = yard.W, H = yard.H;
    g.t += dt;
    const a = g0.actor(), it = ITEMS[g.i];
    if (g.phase === 'pump' && it) {
      // the power drains away: keep clicking to hold it up in the green
      g.power = Math.max(0, g.power - dt * (0.32 + g.i * 0.05));
      const inZone = g.power >= it.tough && g.power <= it.tough + zoneW;
      g.hold = inZone ? g.hold + dt : Math.max(0, g.hold - dt * 3);
      g.left -= dt;
      if (g.hold >= 1) { g.phase = 'swing'; g0.walk(g.prop.x - 0.7, g.prop.z - 0.05, 7); g.hit = true; }
      else if (g.left <= 0) { g.phase = 'swing'; g.hit = false; g0.walk(g.prop.x - 0.7, g.prop.z - 0.05, 3); }
    }
    if (g.phase === 'swing' && !a.goTo) {
      g.phase = 'result'; a.squash = 1;
      if (g.hit) { g.broken++; sfx('level'); say(g, `Smashed the ${it.name.toLowerCase()}!`); for (let i = 0; i < 18; i++) yard.sparks.push({ kind: 'pebble', x: g.prop.x, y: 0.8, z: g.prop.z, vx: (Math.random() - 0.3) * 4, vy: 1.5 + Math.random() * 2.5, vz: (Math.random() - 0.5), g: 7, life: 0.9, ph: 0, c: Math.random() < 0.5 ? 0 : 1 }); g.prop.h = 0.05; g0.hop(); }
      else { sfx('miss'); say(g, 'Out of puff! It bounced off.'); g0.emote('wow'); g.prop.fxOff = { dx: 0, dy: 0, scale: 1, opacity: 1 }; }
      setTimeout(() => { g0.walk(home.x, home.z, 3); g.i++; if (g.prop) g.prop.fxOff = null; setItem(); g.phase = g.i < ITEMS.length ? 'ready' : 'end'; }, 1000);
    }
    if (g.prop?.fxOff) g.prop.fxOff.dx = Math.sin(g.t * 60) * 3;
    // the meter, the green zone, and how long it's been held there
    if (it && g.phase !== 'end') {
      const mx = W - 80, my = 70, mh = H - 170;
      panel(ctx, mx - 12, my - 12, 48, mh + 24, { r: 10 });
      ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(mx, my, 24, mh);
      ctx.fillStyle = '#3fb26a'; ctx.fillRect(mx, my + (1 - it.tough - zoneW) * mh, 24, zoneW * mh);
      ctx.fillStyle = g.power >= it.tough && g.power <= it.tough + zoneW ? '#9ff0b8' : '#ffd23f'; ctx.fillRect(mx, my + (1 - g.power) * mh, 24, g.power * mh);
      ctx.fillStyle = '#fff'; ctx.fillRect(mx - 6, my + (1 - g.power) * mh - 2, 36, 4);
      // hold ring
      const cx = mx + 12, cy = my + mh + 46;
      ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.beginPath(); ctx.arc(cx, cy, 18, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = '#7dffcf'; ctx.beginPath(); ctx.arc(cx, cy, 18, -Math.PI / 2, -Math.PI / 2 + Math.min(1, g.hold) * Math.PI * 2); ctx.stroke();
      text(ctx, it.name, W / 2, 52, { size: 18 });
      if (g.phase === 'pump') text(ctx, `${Math.ceil(g.left)} s`, W / 2, 78, { size: 14, color: g.left < 3 ? '#ff9a9a' : '#e9fff8' });
    }
    hint(ctx, W, 'Click (or tap space) fast! Keep the power in the green for a whole second');
    text(ctx, `Broken ${g.broken} of ${ITEMS.length}`, W / 2, H - 24, { size: 16 });
    showMsg(ctx, g, W, H, dt);
    if (g.phase === 'end' && !g.ending) { g.ending = true; g.perf = g.broken / ITEMS.length; g0.pose('happy', 1.4); setTimeout(() => { g.done = true; }, 900); }
  };
  return g;
}

// ===== catch and swipe: match the arrow before the throw lands =====
const DIRS = [[1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1], [0, 1], [1, 1]].map(([x, y]) => { const l = Math.hypot(x, y); return { x: x / l, y: y / l }; });
function swipeDrill(g0) {
  const { yard, canvas, apt } = g0;
  yard.view({ pitch: 0.28, z: 2.9, snap: true });
  g0.stage(-2.2, 2.2, { top: 80 }); g0.actor().flip = false;
  const KINDS = ['ball', 'plush', 'duck'];
  const pics = Object.fromEntries(KINDS.map((k) => [k, Paint.toy(k, { w: 40, h: 40 })]));
  const g = { t: 0, n: 0, throwT: 0, cur: null, next: 1.2, drag: null, trail: [], over: false, done: false };
  const travel = () => Math.max(0.75, 2.4 - g.n * 0.09) * (1 + apt * 0.15);
  const throwOne = () => {
    const d = DIRS[Math.floor(Math.random() * DIRS.length)];
    g.cur = { d, t: 0, T: travel(), kind: KINDS[Math.floor(Math.random() * KINDS.length)], from: { x: yard.W + 30, y: yard.H * (0.25 + Math.random() * 0.35) }, ok: false, out: 0 };
    sfx('move');
  };
  const target = () => { const b = g0.box(); return b ? { x: (b.x0 + b.x1) / 2, y: (b.y0 + b.y1) / 2 } : { x: yard.W * 0.3, y: yard.H * 0.6 }; };
  const offs = [
    on(canvas, 'pointerdown', (e) => { g.drag = g0.toBuf(e); g.trail = [g.drag]; }),
    on(window, 'pointermove', (e) => { if (g.drag) { g.trail.push(g0.toBuf(e)); if (g.trail.length > 20) g.trail.shift(); } }),
    on(window, 'pointerup', (e) => {
      if (!g.drag) return;
      const p = g0.toBuf(e), dx = p.x - g.drag.x, dy = p.y - g.drag.y; g.drag = null;
      const l = Math.hypot(dx, dy);
      if (!g.cur || g.cur.ok || g.over || l < 40) return;
      const dot = (dx / l) * g.cur.d.x + (dy / l) * g.cur.d.y;
      if (dot > 0.85) { g.cur.ok = true; g.cur.out = 0.01; g.n++; sfx('heal'); say(g, ['Nice!', 'Swiped!', 'Got it!', 'Easy!'][g.n % 4], 0.5); g0.hop(); }
      else { sfx('miss'); say(g, 'Wrong way!', 0.5); }
    }),
    on(canvas, 'keydown', (e) => {
      // arrow keys work too (two at once for the diagonals is hard, so diagonals need the mouse)
      const k = { ArrowRight: [1, 0], ArrowLeft: [-1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key]; if (!k || !g.cur || g.cur.ok || g.over) return; e.preventDefault();
      if (k[0] === Math.round(g.cur.d.x) && k[1] === Math.round(g.cur.d.y) && (g.cur.d.x === 0 || g.cur.d.y === 0)) { g.cur.ok = true; g.cur.out = 0.01; g.n++; sfx('heal'); g0.hop(); } else { sfx('miss'); }
    }),
  ];
  g.dispose = () => offs.forEach((f) => f());
  const arrow = (ctx, cx, cy, d, len, t) => {
    // the swipe to make: a trail moving along the arrow
    const x0 = cx - d.x * len / 2, y0 = cy - d.y * len / 2, x1 = cx + d.x * len / 2, y1 = cy + d.y * len / 2;
    ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 14; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
    const k = (t * 1.6) % 1;
    ctx.strokeStyle = '#7dffcf'; ctx.lineWidth = 8; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x0 + (x1 - x0) * k, y0 + (y1 - y0) * k); ctx.stroke();
    const ang = Math.atan2(d.y, d.x);
    ctx.fillStyle = '#7dffcf'; ctx.beginPath(); ctx.moveTo(x1 + Math.cos(ang) * 14, y1 + Math.sin(ang) * 14); ctx.lineTo(x1 + Math.cos(ang + 2.4) * 16, y1 + Math.sin(ang + 2.4) * 16); ctx.lineTo(x1 + Math.cos(ang - 2.4) * 16, y1 + Math.sin(ang - 2.4) * 16); ctx.closePath(); ctx.fill();
    ctx.lineCap = 'butt';
  };
  g.frame = (dt, ctx) => {
    const W = yard.W, H = yard.H;
    g.t += dt;
    if (!g.cur && !g.over) { g.next -= dt; if (g.next <= 0) throwOne(); }
    const cur = g.cur;
    if (cur) {
      const tg = target();
      if (cur.ok) {
        // swatted away
        cur.out += dt;
        const k = Math.min(1, cur.t / cur.T);
        const x = cur.from.x + (tg.x - cur.from.x) * k + cur.out * 500, y = cur.from.y + (tg.y - cur.from.y) * k - cur.out * 380 + cur.out * cur.out * 600;
        ctx.save(); ctx.translate(x, y); ctx.rotate(cur.out * 12); ctx.drawImage(pics[cur.kind], -20, -20); ctx.restore();
        if (cur.out > 0.8) { g.cur = null; g.next = Math.max(0.25, 0.8 - g.n * 0.03); }
      } else {
        cur.t += dt;
        const k = Math.min(1, cur.t / cur.T);
        const x = cur.from.x + (tg.x - cur.from.x) * k, y = cur.from.y + (tg.y - cur.from.y) * k - Math.sin(k * Math.PI) * H * 0.18;
        ctx.save(); ctx.translate(x, y); ctx.rotate(cur.t * 8); ctx.drawImage(pics[cur.kind], -20, -20); ctx.restore();
        // the prompt
        panel(ctx, W / 2 - 90, H * 0.14, 180, 120, { r: 16 });
        arrow(ctx, W / 2, H * 0.14 + 60, cur.d, 110, g.t);
        // a little timer ring
        ctx.strokeStyle = k > 0.7 ? '#ff7a7a' : '#ffd23f'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(W / 2 + 74, H * 0.14 + 14, 9, -Math.PI / 2, -Math.PI / 2 + (1 - k) * Math.PI * 2); ctx.stroke();
        if (k >= 1 && !g.over) { g.over = true; g0.actor().squash = 1; g0.emote('wow'); sfx('miss'); say(g, 'Got through!', 1.2); }
      }
    }
    // your swipe, as you make it
    if (g.trail.length > 1) { ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 4; ctx.beginPath(); g.trail.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y))); ctx.stroke(); if (!g.drag) g.trail.shift(); }
    hint(ctx, W, 'Press, swipe the way the arrow shows, and let go before it lands');
    text(ctx, `Swiped ${g.n}`, W / 2, H - 24, { size: 16 });
    showMsg(ctx, g, W, H, dt);
    if (g.over && !g.ending) { g.ending = true; g.perf = Math.min(1, g.n / 20); setTimeout(() => { g.done = true; }, 1300); }
  };
  return g;
}
