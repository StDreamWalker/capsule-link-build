// The wild battle screen: your creature (from behind, bottom left) against the wild one (top right), HP
// bars, Showdown's own move animations, and the buttons grouped: Fight (the four moves), Party (switch),
// Run. Resolves to the battle state when it's over (the caller keeps the outcome with wildResult).
import { h, mount } from './dom.js';
import { spriteIdOf } from './art.js';
import { sfx } from './audio.js';
import { prepareMoveAnim, standInMove } from './sdanim/player.js';
import { fxType, TYPE_FX } from './moveFx.js';
import { takeTurn, STATUS_NAME } from '../engine/wildBattle.js';

const SKY = {
  meadow: ['#9ad8ff', '#d8f2ff', '#7cc46a'], forest: ['#7fb88a', '#cfe8c8', '#4f8a4a'], desert: ['#ffd29a', '#fff0d0', '#e0b070'], tundra: ['#c8e4ff', '#f4faff', '#e8f0fa'],
  volcano: ['#5a2a2a', '#c86a3a', '#4a2a22'], shoreline: ['#8ad0ff', '#e4f6ff', '#f0dca0'], marsh: ['#8ab89a', '#d8e8d0', '#5a7a4a'], cavern: ['#2a2836', '#4a4458', '#3a3644'],
  skyline: ['#7ab8ff', '#e0f0ff', '#ffffff'], spooky: ['#3a2a5a', '#6a5a8a', '#3a3448'], seafloor: ['#1a5a8a', '#3a8ac0', '#d8c890'], outskirts: ['#a0c8f0', '#e8f2fa', '#9aa890'],
};

export function openWildBattle({ idx, bank, resolve, battle: b, biome = 'meadow', host = document.body }) {
  return new Promise((done) => {
    const W = 760, H = 400;
    const cv = h('canvas', { class: 'wb-canvas', width: W, height: H });
    const logEl = h('div', { class: 'wb-log', 'aria-live': 'polite' });
    const ctl = h('div', { class: 'wb-controls' });
    const root = h('div', { class: 'wb-scrim' }, h('div', { class: 'wb panel' }, cv, h('div', { class: 'wb-bottom' }, logEl, ctl)));
    host.append(root);
    const x = cv.getContext('2d'); x.imageSmoothingEnabled = false;
    let mode = 'menu'; // 'menu' | 'busy' | 'switch' | 'over'
    let shown = b.log.length, anim = null, raf = 0, t0 = performance.now();
    const disp = new Map(); // displayed HP (eases toward the real value)
    const fade = new Map(); // fainted ones sinking away
    const [sky1, sky2, ground] = SKY[biome] ?? SKY.meadow;
    const FOE = { x: W * 0.72, y: H * 0.42 }, ME = { x: W * 0.27, y: H * 0.86 };
    const lines = () => b.log.slice(Math.max(0, shown - 3), shown);
    const typeCol = (t) => idx.types.get(t)?.color ?? TYPE_FX[fxType(idx, t)]?.col?.[0] ?? '#9aa6b8';

    function drawMon(f, at, scale, back, off) {
      if (!f) return;
      const e = bank.get(spriteIdOf({ speciesId: f.speciesId, shiny: f.shiny }));
      const fr = e?.frames?.idle ?? [];
      const img = fr[Math.floor(performance.now() / 260) % Math.max(1, fr.length)];
      if (!img) return;
      const k = Math.max(1, Math.round(scale * 96 / Math.max(img.width, img.height))), w = img.width * k, hh = img.height * k;
      const sink = fade.get(f.uid) ?? 0;
      x.save();
      x.globalAlpha = Math.max(0, 1 - sink) * (off?.opacity ?? 1);
      x.translate(at.x + (off?.dx ?? 0), at.y + (off?.dy ?? 0) + sink * 40);
      x.scale((back ? -1 : 1) * (off?.scale ?? 1), off?.scale ?? 1);
      if (f.flash > 0 && Math.floor(f.flash * 20) % 2) x.globalAlpha *= 0.3;
      x.drawImage(img, -w / 2, -hh, w, hh);
      x.restore();
    }
    function box(f, bx, by, mine) {
      if (!f) return;
      const v = disp.get(f.uid) ?? f.hp; const k = Math.max(0, v / f.max);
      x.fillStyle = 'rgba(14,12,34,.82)'; x.strokeStyle = 'rgba(125,255,207,.6)'; x.lineWidth = 2;
      x.beginPath(); x.roundRect ? x.roundRect(bx, by, 250, mine ? 62 : 50, 10) : x.rect(bx, by, 250, mine ? 62 : 50); x.fill(); x.stroke();
      x.fillStyle = '#fff'; x.font = '700 15px system-ui, sans-serif'; x.textBaseline = 'middle'; x.textAlign = 'left';
      x.fillText(`${f.name}${f.shiny ? ' ✦' : ''}`, bx + 12, by + 15);
      x.textAlign = 'right'; x.fillText(`Lv. ${f.level}`, bx + 238, by + 15);
      if (f.status) { x.fillStyle = { brn: '#f0743c', psn: '#9b59b6', par: '#f2cc2e', slp: '#8d99ae', frz: '#7fd6e6' }[f.status] ?? '#999'; x.fillRect(bx + 12, by + 26, 34, 14); x.fillStyle = '#111'; x.font = '700 10px system-ui'; x.textAlign = 'center'; x.fillText(f.status.toUpperCase(), bx + 29, by + 33); }
      x.fillStyle = 'rgba(255,255,255,.18)'; x.fillRect(bx + 52, by + 28, 186, 10);
      x.fillStyle = k > 0.5 ? '#3fd27a' : k > 0.2 ? '#ffd23f' : '#ff5a5a'; x.fillRect(bx + 52, by + 28, 186 * k, 10);
      if (mine) { x.fillStyle = '#e9fff8'; x.font = '600 13px system-ui'; x.textAlign = 'right'; x.fillText(`${Math.ceil(v)} / ${f.max}`, bx + 238, by + 50); }
    }
    function draw() {
      raf = requestAnimationFrame(draw);
      const now = performance.now(), dt = Math.min(0.05, (now - t0) / 1000); t0 = now;
      const g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, sky1); g.addColorStop(0.55, sky2); g.addColorStop(0.551, ground); g.addColorStop(1, ground);
      x.fillStyle = g; x.fillRect(0, 0, W, H);
      // the two platforms
      x.fillStyle = 'rgba(0,0,0,.14)'; x.beginPath(); x.ellipse(FOE.x, FOE.y, 120, 26, 0, 0, Math.PI * 2); x.fill();
      x.beginPath(); x.ellipse(ME.x, ME.y - 4, 150, 30, 0, 0, Math.PI * 2); x.fill();
      for (const [uid, v] of disp) { const f = uid === b.foe.uid ? b.foe : b.side.find((s) => s.uid === uid); if (!f) continue; const tgt = f.hp; disp.set(uid, v + (tgt - v) * Math.min(1, dt * 4)); }
      for (const f of [b.foe, ...b.side]) { if (!disp.has(f.uid)) disp.set(f.uid, f.hp); if (f.flash > 0) f.flash -= dt; }
      for (const [uid, v] of fade) fade.set(uid, Math.min(1, v + dt * 1.5));
      const me = b.side[b.active];
      let offA = null, offD = null;
      if (anim) {
        anim.t += dt * 1000;
        const fromMe = anim.user === me.uid;
        const a = fromMe ? { x: ME.x, y: ME.y - 70 } : { x: FOE.x, y: FOE.y - 50 }, d = fromMe ? { x: FOE.x, y: FOE.y - 50 } : { x: ME.x, y: ME.y - 70 };
        if (anim.a) {
          const r = anim.a.frame(x, anim.t, { a, d, resolve, tint: anim.tint });
          offA = r.attacker; offD = r.defender;
          if (r.done) { const fn = anim.then; anim = null; fn?.(); }
        } else {
          const k = Math.min(1, anim.t / 450);
          x.fillStyle = anim.tint; x.beginPath(); x.arc(a.x + (d.x - a.x) * k, a.y + (d.y - a.y) * k - Math.sin(k * Math.PI) * 40, 12, 0, Math.PI * 2); x.fill();
          if (k >= 1) { const fn = anim.then; anim = null; fn?.(); }
        }
      }
      const meOff = anim && anim.user === me.uid ? offA : anim ? offD : null, foeOff = anim && anim.user === b.foe.uid ? offA : anim ? offD : null;
      drawMon(b.foe, FOE, 1.1, false, foeOff);
      drawMon(me, ME, 1.5, true, meOff);
      box(b.foe, 24, 22, false);
      box(me, W - 274, H - 92, true);
    }
    function renderLog() { mount(logEl, lines().map((l, i, arr) => h('p', { class: i === arr.length - 1 ? 'now' : '' }, l))); }
    const btn = (label, fn, cls = '', extra = {}) => h('button', { class: `btn ${cls}`, onclick: fn, ...extra }, label);
    function renderControls() {
      const me = b.side[b.active];
      if (mode === 'busy') { mount(ctl, h('p', { class: 'dim' }, '…')); return; }
      if (mode === 'over') {
        mount(ctl, h('div', { class: 'btn-group' }, h('div', { class: 'btn-group-head' }, b.won ? 'You won!' : b.ran ? 'Got away' : 'Lost this time'), btn('Continue', () => close(), 'primary')));
        return;
      }
      if (mode === 'switch') {
        mount(ctl, h('div', { class: 'btn-group' }, h('div', { class: 'btn-group-head' }, me.hp > 0 ? 'Switch to…' : 'Who’s next?'),
          b.side.map((f, i) => btn(`${f.name} · ${f.hp}/${f.max}`, () => choose({ switchTo: i }), 'small', { disabled: f.hp <= 0 || i === b.active })),
          me.hp > 0 ? btn('Back', () => { mode = 'menu'; renderControls(); }, 'small ghost') : null));
        return;
      }
      mount(ctl,
        h('div', { class: 'btn-group wb-moves' }, h('div', { class: 'btn-group-head' }, 'Fight'),
          me.moves.map((m, i) => { const mv = idx.moves.get(m.id); return h('button', { class: 'btn wb-move', style: { borderColor: typeCol(mv.type) }, disabled: m.pp <= 0, onclick: () => choose({ move: i }) },
            h('b', null, mv.name), h('small', null, `${idx.types.get(mv.type)?.name ?? mv.type} · ${mv.category === 'status' ? 'status' : `${mv.power || '—'} power`} · PP ${m.pp}/${mv.pp ?? m.pp}`)); })),
        h('div', { class: 'btn-group' }, h('div', { class: 'btn-group-head' }, 'Other'),
          btn('Party', () => { mode = 'switch'; renderControls(); }, 'small', { disabled: b.side.filter((f) => f.hp > 0).length < 2 }),
          btn('Run', () => choose({ run: true }), 'small')));
    }
    function playSteps(steps, i, then) {
      if (i >= steps.length) { then(); return; }
      const s = steps[i];
      if (s.kind === 'move') {
        const mv = idx.moves.get(s.move);
        const a = prepareMoveAnim(mv?.showdownName ?? mv?.name ?? '') ?? prepareMoveAnim(standInMove(fxType(idx, mv?.type), mv?.category));
        anim = { a, t: 0, user: s.user, tint: typeCol(mv?.type), then: () => playSteps(steps, i + 1, then) };
        shown = Math.min(b.log.length, shown + 1); renderLog();
        return;
      }
      if (s.kind === 'hit') { const f = s.uid === b.foe.uid ? b.foe : b.side.find((q) => q.uid === s.uid); if (f) f.flash = 0.4; sfx(s.crit ? 'level' : 'blip'); }
      if (s.kind === 'faint') { fade.set(s.uid, 0.01); sfx('miss'); }
      if (s.kind === 'switch') sfx('warp');
      setTimeout(() => playSteps(steps, i + 1, then), s.kind === 'hit' ? 380 : s.kind === 'faint' ? 700 : 300);
    }
    function revealRest(then) {
      if (shown >= b.log.length) { then(); return; }
      shown++; renderLog();
      setTimeout(() => revealRest(then), 650);
    }
    function choose(c) {
      if (mode === 'busy') return;
      mode = 'busy'; renderControls();
      const r = takeTurn(idx, b, c);
      playSteps(r.steps, 0, () => revealRest(() => {
        if (r.over) { mode = 'over'; sfx(b.won ? 'level' : 'back'); }
        else if (r.needSwitch) mode = 'switch';
        else mode = 'menu';
        renderControls();
      }));
    }
    function close() { cancelAnimationFrame(raf); root.remove(); done(b); }
    renderLog(); renderControls(); draw();
    void STATUS_NAME;
  });
}
