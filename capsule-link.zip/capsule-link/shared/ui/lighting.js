// Simulated light for every scene the Yard draws (the R.A.N.C.H., the farm, the shop, rooms, battles).
// Not ray tracing: a handful of point lights each frame, each lighting what's near it the way light falls off
// with distance —
//   the ground       a pool of light under and around it
//   models           every face turned towards it brightens (stands, walls, rocks, trees, arena pieces)
//   creatures        lit on the side facing it, a rim of colour when it's behind them
//   the light        a soft glow where it is
// Lights come from lamps, lanterns, campfires, glowing mushrooms and crystals, neon, lava, fire and electric
// creatures (the scene's own), and whatever the scene adds each frame (yard.dynLights: moves in a battle).
// Creatures also get the place's key light: a little light from above and shade below, warm at dusk.
//
//   gatherLights(yard)                          → this frame's lights [{ x, y, z, r, c: [r, g, b], i }]
//   drawFloorLights(ctx, yard)                  pools of light on the ground (before anything standing on it)
//   faceLight(yard, wx, wy, wz, n, mesh)        → extra [r, g, b] (0…255) for a model's face, or null
//   lightSprite(ctx, yard, a, img, x, y, w, h, mirror)   a creature's lighting, over its picture
//   drawLightGlows(ctx, yard)                   the glow at each light (after the scene's darkness)

const MAX_LIGHTS = 24;
const hex = (s) => { const v = String(s ?? '').replace('#', ''); const n = parseInt(v.length === 3 ? v.split('').map((c) => c + c).join('') : v.slice(0, 6), 16); return Number.isFinite(n) ? [(n >> 16) & 255, (n >> 8) & 255, n & 255] : [255, 220, 160]; };
export const lightRgb = (c) => (Array.isArray(c) ? c : hex(c));

// how strongly lights show: a little in daylight (a fire still glows), fully in the dark
export function darkness(yard) {
  const t = yard.light ?? 'day';
  if (yard.L?.cave || yard.L?.night || yard.biome === 'synth' || yard.biome === 'starfield' || yard.biome === 'seafloor') return 1;
  return t === 'night' ? 1 : t === 'dusk' ? 0.85 : t === 'dawn' ? 0.7 : 0.5;
}
// night and dusk darken the whole picture afterwards (a multiply): lights drawn before that are given
// back what it will take away
function afterDark(yard) {
  const t = yard.light ?? 'day';
  if (yard.L?.cave) return 1;
  return t === 'night' ? 2.3 : t === 'dusk' ? 1.35 : t === 'dawn' ? 1.2 : 1;
}

const PROP_LIGHT = {
  lamppost: { c: [255, 214, 150], r: 5, y: 0.92 }, lantern: { c: [255, 190, 110], r: 4, y: 0.6 }, campfire: { c: [255, 140, 60], r: 6.5, y: 0.4, flicker: 1 },
  glowshroom: { c: [90, 210, 255], r: 3, y: 0.4 }, pumpkin: { c: [255, 150, 50], r: 3, y: 0.4, flicker: 0.6 }, fountain: { c: [170, 230, 255], r: 3.5, y: 0.6 },
  crystal: { c: [190, 140, 255], r: 3.5, y: 0.6 }, torch: { c: [255, 150, 70], r: 5, y: 0.9, flicker: 1 },
};

/** This frame's lights, nearest the middle of the view first (at most MAX_LIGHTS). */
export function gatherLights(yard) {
  const out = [], tm = yard.time ?? 0;
  for (const p of yard.props ?? []) {
    const def = PROP_LIGHT[p.kind];
    const g = p.glow ?? 0;
    if (!def && !g && !p.light) continue;
    const L = p.light ?? {};
    const fl = (L.flicker ?? def?.flicker) ? 0.82 + 0.12 * Math.sin(tm * 7.3 + p.x * 3) + 0.06 * Math.sin(tm * 17.1 + p.z) : 1;
    const h = p.h ?? 1;
    out.push({ x: p.x, y: L.y ?? p.lightY ?? h * (def?.y ?? 0.6), z: p.z, r: L.r ?? (def?.r ?? 3 + Math.min(2, g) * 2.2), c: lightRgb(L.c ?? p.lightCol ?? def?.c ?? defaultGlow(yard, p)), i: (L.i ?? (def ? 1 : 0.5 + Math.min(1.5, g) * 0.6)) * fl });
  }
  for (const s of yard.scatterLights ?? []) {
    const fl = s.flicker ? 0.75 + 0.25 * Math.sin(tm * (2 + s.flicker) + s.x * 5) : 1;
    out.push({ ...s, i: s.i * fl });
  }
  // fire creatures glow warm and flicker; electric ones crackle now and then
  for (const a of yard.actors?.values?.() ?? []) {
    if (a.appear != null && a.appear < 1) continue;
    const ht = (yard.heightOf?.(a) ?? 1);
    if (a.fire) out.push({ x: a.x, y: (a.y || 0) + ht * 0.6, z: a.z, r: 2.6 + ht, c: [255, 140, 60], i: 0.75 + 0.12 * Math.sin(tm * 6 + a.x) + 0.1 * Math.sin(tm * 13.7 + a.z) });
    else if (a.electric && a._zap > 0) out.push({ x: a.x, y: (a.y || 0) + ht * 0.6, z: a.z, r: 2.2 + ht, c: [210, 235, 255], i: 0.9 });
  }
  for (const l of yard.dynLights ?? []) out.push({ ...l, c: lightRgb(l.c ?? l.col) });
  if (out.length <= MAX_LIGHTS) return out;
  // too many: the strongest near the middle of the view
  const cx = yard.cx + (yard.ys ?? 0) * 6, cz = yard.cz + (yard.yc ?? 1) * 6;
  return out.map((l) => ({ l, s: (l.i * l.r) / (1 + Math.hypot(l.x - cx, l.z - cz) * 0.15) })).sort((a, b) => b.s - a.s).slice(0, MAX_LIGHTS).map((e) => e.l);
}
function defaultGlow(yard, p) {
  if (yard.biome === 'synth') return (Math.round(p.x * 3 + p.z) & 1) ? [255, 61, 208] : [61, 232, 255];
  if (yard.biome === 'prism') return [[255, 170, 230], [160, 220, 255], [200, 255, 210], [255, 230, 160]][Math.abs(Math.round(p.x + p.z * 2)) % 4];
  if (yard.biome === 'crystal') return [190, 140, 255];
  if (yard.L?.cave || p.kind === 'glowshroom') return [100, 210, 255];
  return [255, 210, 140];
}

// ---------- the ground ----------
/** Pools of light on the ground (call after the floor, before anything standing on it). */
export function drawFloorLights(ctx, yard) {
  const lights = yard.lit ?? [];
  if (!lights.length) return;
  const D = darkness(yard) * afterDark(yard);
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const l of lights) {
    // a light high up spreads wider and dimmer; one on the ground makes a small bright pool
    const r = l.r * (1 + Math.min(1.2, l.y / Math.max(1, l.r)) * 0.4);
    const k = l.i * D * 0.55 / (1 + (l.y / Math.max(0.5, l.r)) ** 2 * 0.6);
    if (k < 0.02) continue;
    const C = yard.project(l.x, 0, l.z), A = yard.project(l.x + r, 0, l.z), B = yard.project(l.x, 0, l.z + r);
    if (!C || !A || !B) continue;
    const ax = A.x - C.x, ay = A.y - C.y, bx = B.x - C.x, by = B.y - C.y, det = ax * by - ay * bx;
    if (Math.abs(det) < 4 || Math.abs(ax) + Math.abs(bx) > yard.W * 3) continue;
    ctx.setTransform(ax, ay, bx, by, C.x, C.y);
    const [cr, cg, cb] = l.c, a = Math.min(0.9, k);
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, 1);
    g.addColorStop(0, `rgba(${cr},${cg},${cb},${a.toFixed(3)})`);
    g.addColorStop(0.35, `rgba(${cr},${cg},${cb},${(a * 0.45).toFixed(3)})`);
    g.addColorStop(1, `rgba(${cr},${cg},${cb},0)`);
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(0, 0, 1, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();
}

// ---------- models ----------
function meshBounds(m) {
  if (m._bs) return m._bs;
  let x0 = Infinity, y0 = Infinity, z0 = Infinity, x1 = -Infinity, y1 = -Infinity, z1 = -Infinity;
  for (const [x, y, z] of m.v) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; if (z < z0) z0 = z; if (z > z1) z1 = z; }
  m._bs = { x: (x0 + x1) / 2, y: (y0 + y1) / 2, z: (z0 + z1) / 2, r: Math.hypot(x1 - x0, y1 - y0, z1 - z0) / 2 };
  return m._bs;
}
/** The lights that can reach a model placed at (x, z), or null. */
export function lightsFor(yard, m, x, z) {
  const lights = yard.lit;
  if (!lights?.length) return null;
  const b = meshBounds(m), cx = x + b.x, cz = z + b.z;
  let out = null;
  for (const l of lights) { if (Math.hypot(l.x - cx, l.y - b.y, l.z - cz) < b.r + l.r * 1.6) (out ??= []).push(l); }
  return out;
}
/** Extra light on one face of a model ([r, g, b] to add, 0…255), or null when there's next to none. */
export function faceLight(yard, near, wx, wy, wz, n) {
  if (!near) return null;
  const D = darkness(yard) * afterDark(yard);
  let r = 0, g = 0, b = 0;
  for (const l of near) {
    const dx = l.x - wx, dy = l.y - wy, dz = l.z - wz, d = Math.hypot(dx, dy, dz) || 1;
    const reach = l.r * 1.6;
    if (d > reach) continue;
    const facing = (n[0] * dx + n[1] * dy + n[2] * dz) / d;
    if (facing <= 0) continue;
    const fall = (1 - d / reach) ** 2;
    const k = l.i * fall * (0.25 + 0.75 * facing) * D * 150;
    r += l.c[0] / 255 * k; g += l.c[1] / 255 * k; b += l.c[2] / 255 * k;
  }
  if (r + g + b < 6) return null;
  return [Math.min(255, r), Math.min(255, g), Math.min(255, b)];
}

// ---------- creatures ----------
let scratch = null, sx = null;
function pad(w, h) {
  if (!scratch) { scratch = (typeof OffscreenCanvas !== 'undefined') ? new OffscreenCanvas(64, 64) : document.createElement('canvas'); sx = scratch.getContext('2d'); }
  if (scratch.width < w || scratch.height < h) { scratch.width = Math.max(scratch.width, w); scratch.height = Math.max(scratch.height, h); }
  sx.setTransform(1, 0, 0, 1, 0, 0); sx.globalCompositeOperation = 'source-over'; sx.globalAlpha = 1; sx.clearRect(0, 0, w, h); sx.imageSmoothingEnabled = false;
  return sx;
}
function silhouette(img, w, h, mirror) {
  const c = pad(w, h);
  if (mirror) { c.save(); c.translate(w, 0); c.scale(-1, 1); c.drawImage(img, 0, 0, w, h); c.restore(); } else c.drawImage(img, 0, 0, w, h);
  c.globalCompositeOperation = 'source-in';
  return c;
}
// the place's key light on creatures: from above, warm at dusk and dawn, cool and dim at night, none in caves
function keyLight(yard) {
  const t = yard.light ?? 'day';
  if (yard.L?.cave || yard.biome === 'synth' || yard.biome === 'seafloor') return { top: [140, 170, 255], ta: 0.06, bottom: [10, 6, 30], ba: 0.32 };
  if (t === 'night') return { top: [150, 170, 255], ta: 0.08, bottom: [8, 10, 30], ba: 0.3 };
  if (t === 'dusk') return { top: [255, 170, 110], ta: 0.16, bottom: [40, 20, 60], ba: 0.26 };
  if (t === 'dawn') return { top: [255, 200, 190], ta: 0.14, bottom: [40, 30, 70], ba: 0.22 };
  return { top: [255, 248, 225], ta: 0.13, bottom: [30, 30, 60], ba: 0.22 };
}
/** A creature's lighting, drawn over its picture (img drawn at x, y, w × h, mirrored or not). */
export function lightSprite(ctx, yard, a, img, x, y, w, h, mirror) {
  if (!img || w < 10 || h < 10 || w > 1400 || h > 1400) return;
  if (a.hitFlash > 0 || (a.alpha != null && a.alpha < 0.98) || a.tint) return;
  const W = Math.ceil(w), H = Math.ceil(h);
  // the key light: a touch of light from above, shade towards the feet
  const K = keyLight(yard);
  let c = silhouette(img, W, H, mirror);
  let g = c.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, `rgba(${K.top},${K.ta})`); g.addColorStop(0.45, `rgba(${K.top},0)`); g.addColorStop(0.62, `rgba(${K.bottom},0)`); g.addColorStop(1, `rgba(${K.bottom},${K.ba})`);
  c.fillStyle = g; c.fillRect(0, 0, W, H);
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(scratch, 0, 0, W, H, x, y, W, H);
  // nearby lights: summed into one colour, brighter on the side they're on (a rim when they're behind)
  const lights = yard.lit ?? [];
  if (lights.length) {
    const ht = yard.heightOf?.(a) ?? 1, cy = (a.y || 0) + ht * 0.55;
    const me = yard.project(a.x, cy, a.z);
    let r = 0, gg = 0, b = 0, side = 0, behind = 0, tot = 0;
    const D = darkness(yard) * afterDark(yard);
    for (const l of lights) {
      const d = Math.hypot(l.x - a.x, l.y - cy, l.z - a.z), reach = l.r * 1.7;
      if (d > reach) continue;
      const k = l.i * (1 - d / reach) ** 2 * D;
      if (k < 0.01) continue;
      r += l.c[0] * k; gg += l.c[1] * k; b += l.c[2] * k; tot += k;
      const q = yard.project(l.x, l.y, l.z);
      if (q && me) { side += Math.max(-1, Math.min(1, (q.x - me.x) / Math.max(20, w))) * k; behind += (q.z > me.z + 0.2 ? 1 : 0) * k; }
    }
    if (tot > 0.03) {
      const s = side / tot, back = behind / tot, amt = Math.min(0.55, tot * 0.42);
      const col = `${Math.min(255, Math.round(r / tot))},${Math.min(255, Math.round(gg / tot))},${Math.min(255, Math.round(b / tot))}`;
      c = silhouette(img, W, H, mirror);
      // facing the light: an even wash; side-on or behind: strong on the near edge, little on the far one
      const edge = Math.min(1, Math.abs(s) * 1.4 + back * 0.8), near = amt, far = amt * (1 - edge * 0.85);
      g = s >= 0 ? c.createLinearGradient(0, 0, W, 0) : c.createLinearGradient(W, 0, 0, 0);
      g.addColorStop(0, `rgba(${col},${far.toFixed(3)})`); g.addColorStop(0.6, `rgba(${col},${((far + near) / 2).toFixed(3)})`); g.addColorStop(1, `rgba(${col},${near.toFixed(3)})`);
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      ctx.globalCompositeOperation = 'lighter';
      ctx.drawImage(scratch, 0, 0, W, H, x, y, W, H);
    }
  }
  ctx.restore();
}

// ---------- the lights themselves ----------
/** A soft glow where each light is (after the scene's darkness, so they shine at night). */
export function drawLightGlows(ctx, yard) {
  const lights = yard.lit ?? [];
  if (!lights.length) return;
  const D = darkness(yard);
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const l of lights) {
    if (!l.glow && !l.dyn) continue; // props draw their own glow
    const q = yard.project(l.x, l.y, l.z);
    if (!q) continue;
    const rr = Math.min(yard.H * 0.6, Math.max(6, q.k * l.r * 0.35));
    const a = Math.min(0.75, l.i * D * 0.35);
    if (a < 0.02) continue;
    const g = ctx.createRadialGradient(q.x, q.y, 0, q.x, q.y, rr);
    g.addColorStop(0, `rgba(${l.c},${a.toFixed(3)})`); g.addColorStop(0.3, `rgba(${l.c},${(a * 0.4).toFixed(3)})`); g.addColorStop(1, `rgba(${l.c},0)`);
    ctx.fillStyle = g; ctx.fillRect(q.x - rr, q.y - rr, rr * 2, rr * 2);
  }
  ctx.restore();
}
