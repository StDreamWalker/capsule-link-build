// The field journal: a little notebook about a creature (what you've found out: favourites, likes, dislikes,
// friends, quirks). Shown in Quality time, on the R.A.N.C.H. page, in the storage summary and on the phone.
import { h, dialog } from './dom.js';
import { spriteCanvas } from './art.js';
import { journalOf, CONDITION_NAMES, sheenStars } from '../engine/index.js';

/** The journal's pages for creature c (an element; class care-journal for the notebook look). */
export function journalPages(idx, save, c, { inline = false } = {}) {
  const j = journalOf(idx, save, c);
  return h('div', { class: `care-journal ${inline ? 'inline' : ''}` },
    h('div', { class: 'cj-head' }, h('strong', null, j.name), h('span', null, `${j.temper} · ${j.moodLabel}`)),
    h('p', { class: 'cj-style' }, j.style),
    h('div', { class: 'cj-section' }, 'Favourites'),
    h('dl', { class: 'cj-favs' }, j.favourites.map((f) => [h('dt', null, f.label), h('dd', { class: f.value === '???' ? 'dim' : '' }, f.value)])),
    h('div', { class: 'cj-section' }, 'Likes'),
    Object.keys(j.likes).length ? Object.entries(j.likes).map(([head, list]) => h('p', { class: 'cj-line' }, h('b', null, `${head}: `), list.join(', '))) : h('p', { class: 'cj-line dim' }, 'Nothing yet. Spend time together and you’ll find out.'),
    h('div', { class: 'cj-section' }, 'Dislikes'),
    h('p', { class: `cj-line ${j.dislikes.length ? '' : 'dim'}` }, j.dislikes.length ? j.dislikes.join(', ') : 'Nothing so far.'),
    j.friends.length ? [h('div', { class: 'cj-section' }, 'Friends'), h('p', { class: 'cj-line' }, j.friends.join(', '))] : null,
    j.notes.length ? [h('div', { class: 'cj-section' }, 'Notes'), j.notes.map((n) => h('p', { class: 'cj-line' }, `• ${n}`))] : null,
    c.condition ? [h('div', { class: 'cj-section' }, 'Condition (from Pokéblocks)'),
      h('p', { class: 'cj-line' }, Object.entries(CONDITION_NAMES).map(([k, n]) => `${n} ${c.condition[k] ?? 0}`).join(' · ')),
      h('p', { class: 'cj-line' }, `Sheen ${'★'.repeat(sheenStars(c.condition.sheen))}${c.condition.sheen >= 255 ? ' (full: no more Pokéblocks)' : ''}`)] : null);
}

/** The journal on its own, as a dialog. env: { idx, bank, save }. */
export function openJournal(env, c) {
  return dialog(`${c.nickname || 'Their'} journal`.replace(/^Their journal$/, 'Journal'), (close) => h('div', { class: 'col journal-dialog' },
    h('div', { class: 'row', style: { alignItems: 'flex-start', gap: '14px' } },
      spriteCanvas(env.bank, c, { scale: 2, animate: true }),
      journalPages(env.idx, env.save, c, { inline: true })),
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: () => close(true) }, 'Close'))));
}
