// "Battles follow the real weather and time" (on unless turned off), and a hand correction for when the
// real sky and the app disagree: a sudden fog or rain the weather service hasn't caught yet, or the light
// going earlier than the clock thinks (sunset around the solstice). The correction can last an hour, a
// few hours, the rest of the day, or until it's changed back. Used by the PC's and the phone's settings.
import { h } from './dom.js';
import { battleSky, setSkyFix, SKY_FIX_WEATHER, SKY_FIX_TOD } from '../engine/sky.js';

const WX = { clear: '☀ Clear', cloudy: '☁ Cloudy', rain: '🌧 Rain', storm: '⛈ Storm', snow: '❄ Snow', fog: '🌫 Fog', windy: '🍃 Windy' };
const TOD = { dawn: '🌅 Dawn', day: '🌞 Day', dusk: '🌇 Dusk', night: '🌙 Night' };
const FOR = [['1', 'for an hour'], ['3', 'for 3 hours'], ['day', 'for the rest of today'], ['0', 'until I change it']];
const untilOf = (v) => { if (v === '0') return 0; if (v === 'day') { const d = new Date(); d.setHours(23, 59, 59, 0); return d.getTime(); } return Date.now() + Number(v) * 3600000; };

/** settings: the save's settings; set(fn): change them (fn gets the settings) and re-render. */
export function skySettingsBlock({ settings: s = {}, set }) {
  const fix = s.skyFix && (!s.skyFix.until || s.skyFix.until > Date.now()) ? s.skyFix : null;
  const now = battleSky({ ...s, realSkyBattles: true });
  let pickFor = fix ? (fix.until ? '3' : '0') : '3';
  const apply = (patch) => set((st) => {
    const cur = st.skyFix && (!st.skyFix.until || st.skyFix.until > Date.now()) ? st.skyFix : {};
    const next = { ...cur, ...patch, until: untilOf(pickFor) };
    st.skyFix = next.weather || next.tod ? next : null;
    setSkyFix(st.skyFix);
  });
  const sel = (label, options, value, onchange) => h('label', { class: 'sky-sel' }, h('span', { class: 'micro dim' }, label),
    h('select', { onchange: (e) => onchange(e.target.value || null) }, [['', 'As it really is'], ...options].map(([v, l]) => h('option', { value: v, selected: (value ?? '') === v }, l))));
  return h('div', { class: 'col sky-settings' },
    h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.realSkyBattles !== false, onchange: (e) => set((st) => { st.realSkyBattles = e.target.checked; }) }),
      'Battles follow the real weather and time where you are'),
    qualitySlider(s, set),
    h('p', { class: 'micro dim', style: { margin: 0 } }, now
      ? `Right now: ${WX[now.weather] ?? now.weather}, ${TOD[now.tod] ?? now.tod}${now.temp != null ? `, ${now.temp}°C` : ''}${now.source === 'fixed' ? ' (corrected by you)' : ''}. Outdoor battles look like it${now.field ? `, and ${{ RainDance: 'the rain', Snowscape: 'the snow', SunnyDay: 'the harsh sun' }[now.field]} carries into the battle itself` : ''}.`
      : ''),
    h('div', { class: 'row wrap sky-fix' },
      sel('Weather', SKY_FIX_WEATHER.map((w) => [w, WX[w]]), fix?.weather, (v) => apply({ weather: v })),
      sel('Time of day', SKY_FIX_TOD.map((t) => [t, TOD[t]]), fix?.tod, (v) => apply({ tod: v })),
      h('label', { class: 'sky-sel' }, h('span', { class: 'micro dim' }, 'Keep it'), h('select', { onchange: (e) => { pickFor = e.target.value; if (fix) apply({}); } }, FOR.map(([v, l]) => h('option', { value: v, selected: v === pickFor }, l)))),
      fix ? h('button', { class: 'btn small ghost', onclick: () => set((st) => { st.skyFix = null; setSkyFix(null); }) }, 'Back to the real sky') : null),
    h('p', { class: 'micro faint', style: { margin: 0 } }, 'If the real sky changes before the app notices (a sudden fog or shower, an early sunset), set it here. It applies to battles and the R.A.N.C.H.'));
}

// graphics quality for battles: a slider from potato to ultra
const QUALITY = [
  ['potato', 'Potato', 'Bare bones for old devices: no shadows, no lens effects, few particles, chunkier effects.'],
  ['low', 'Low', 'Light shadows off, fewer particles, no surface detail.'],
  ['medium', 'Medium', 'Shadows (hard-edged), most particles, no glow pass.'],
  ['high', 'High', 'Soft shadows, surface detail, glows, rain on the lens, spotlights at night.'],
  ['ultra', 'Ultra', 'Everything, plus dramatic lighting: deeper shadows, moves that glow light up the place, light on wet and polished ground, more particles.'],
];
function qualitySlider(s, set) {
  const cur = Math.max(0, QUALITY.findIndex((q) => q[0] === (s.quality ?? (s.dramaticLight ? 'ultra' : 'high'))));
  const name = h('b', null, QUALITY[cur][1]), help = h('span', { class: 'micro dim' }, QUALITY[cur][2]);
  const input = h('input', { type: 'range', min: 0, max: 4, step: 1, value: cur, 'aria-label': 'Battle graphics quality', style: { width: '100%' },
    oninput: (e) => { const q = QUALITY[Number(e.target.value)]; name.textContent = q[1]; help.textContent = q[2]; },
    onchange: (e) => { const q = QUALITY[Number(e.target.value)]; set((st) => { st.quality = q[0]; st.dramaticLight = q[0] === 'ultra'; }); } });
  return h('div', { class: 'col', style: { gap: '4px' } },
    h('div', { class: 'row', style: { gap: '8px', alignItems: 'baseline' } }, h('span', null, 'Battle graphics:'), name),
    input,
    h('div', { class: 'row micro dim', style: { justifyContent: 'space-between' } }, QUALITY.map((q) => h('span', null, q[1]))),
    help);
}
