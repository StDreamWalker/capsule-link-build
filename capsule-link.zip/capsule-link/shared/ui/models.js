// Low-poly models for the R.A.N.C.H. foreground: trees, pines, palms, cacti, bushes, rocks, fences, walls,
// hedges and planter boxes, so they have sides and turn properly with the camera (like the buildings),
// instead of flat pictures. Their colours come from each biome's own painted pictures, so a desert wall,
// a spooky tree or a snowy pine still looks like it belongs.
//
// A mesh: { v: [[x, y, z], …], f: [{ i: [vertex indices], col: '#rrggbb', n: [nx, ny, nz], c: [cx, cy, cz] }] }
// in yard units around its foot. drawMesh() projects it with the yard's camera, culls faces turned away,
// sorts the rest far to near, and fills them with flat shading.

import { lightsFor, faceLight, sunShade } from './lighting.js';
const LIGHT = (() => { const l = [-0.45, 0.8, -0.4]; const m = Math.hypot(...l); return l.map((x) => x / m); })();
function rng(seed) { let s = (seed >>> 0) || 1; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; }
const hexRgb = (h) => { const x = String(h).replace('#', ''); const n = parseInt(x.length === 3 ? x.split('').map((c) => c + c).join('') : x, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const rgbHex = (r, g, b) => `#${[r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('')}`;
const shade = (hex, k) => { const [r, g, b] = hexRgb(hex); return k >= 0 ? rgbHex(r + (255 - r) * k, g + (255 - g) * k, b + (255 - b) * k) : rgbHex(r * (1 + k), g * (1 + k), b * (1 + k)); };

/** Average colours of a painted picture: top part, middle and bottom centre (for trunks and posts). */
const colorCache = new WeakMap();
export function colorsOf(img) {
  if (!img) return { top: '#4f9a3f', mid: '#4f9a3f', bottom: '#7a5232' };
  if (colorCache.has(img)) return colorCache.get(img);
  let out = { top: '#4f9a3f', mid: '#4f9a3f', bottom: '#7a5232' };
  try {
    const w = img.width, h = img.height;
    const d = img.getContext ? img.getContext('2d').getImageData(0, 0, w, h).data : null;
    if (d) {
      const avg = (x0, y0, x1, y1) => { let r = 0, g = 0, b = 0, n = 0; for (let y = Math.floor(y0); y < y1; y += 2) for (let x = Math.floor(x0); x < x1; x += 2) { const i = (y * w + x) * 4; if (d[i + 3] > 200) { r += d[i]; g += d[i + 1]; b += d[i + 2]; n++; } } return n ? rgbHex(r / n, g / n, b / n) : null; };
      out = { top: avg(0, 0, w, h * 0.5) ?? out.top, mid: avg(0, h * 0.35, w, h * 0.7) ?? out.mid, bottom: avg(w * 0.4, h * 0.8, w * 0.6, h) ?? avg(0, h * 0.75, w, h) ?? out.bottom };
    }
  } catch { /* not readable */ }
  colorCache.set(img, out);
  return out;
}

// ---------- surface detail ----------
// Faces can carry a pattern laid over their flat colour (stone courses, brick, bark, leaves, planks, roof tiles,
// concrete seams): drawn in see-through darks and lights so it works on any colour, fixed to the face in world
// units (it stays put and gets smaller with distance), and left off faces too small on screen to show it.
let PAT = null;
/** Patterns for the faces made from here on: 'stone' | 'brick' | 'bark' | 'leaf' | 'plank' | 'tile' | 'concrete' | 'metal' | null. */
export function setPat(p) { PAT = p || null; }
const PXU = 24; // pattern pixels per world unit
const PATS = {};
function patCanvas(kind) {
  if (PATS[kind] !== undefined) return PATS[kind];
  let cv = null;
  try {
    const sz = { stone: [72, 48], brick: [48, 24], bark: [24, 48], leaf: [32, 32], plank: [48, 24], tile: [24, 18], concrete: [72, 72], metal: [48, 48] }[kind];
    if (!sz) return (PATS[kind] = null);
    cv = document.createElement('canvas'); cv.width = sz[0]; cv.height = sz[1];
    const g = cv.getContext('2d'), r = rng(kind.length * 977 + 13), W = sz[0], H = sz[1];
    const dk = (a) => `rgba(20,14,10,${Math.min(0.7, a * 1.1)})`, lt = (a) => `rgba(255,250,235,${a})`;
    const speck = (n, a) => { for (let i = 0; i < n; i++) { g.fillStyle = r() < 0.5 ? dk(a * r()) : lt(a * 0.7 * r()); g.fillRect(Math.floor(r() * W), Math.floor(r() * H), 1 + (r() < 0.2), 1); } };
    if (kind === 'stone' || kind === 'brick') { // courses of blocks, every other row offset; mortar in shadow below, a lit edge above
      const bw = kind === 'stone' ? 24 : 12, bh = kind === 'stone' ? 12 : 6;
      for (let row = 0; row * bh < H; row++) {
        const y = row * bh, off = (row % 2) * bw / 2;
        g.fillStyle = dk(0.5); g.fillRect(0, y + bh - 2, W, 2); g.fillStyle = lt(0.2); g.fillRect(0, y, W, 1);
        for (let x = -off; x < W; x += bw) { const xx = Math.round(x); g.fillStyle = dk(0.45); g.fillRect(((xx % W) + W) % W, y, 2, bh); g.fillStyle = dk(0.04 + r() * 0.1); g.fillRect(((xx + 1) % W + W) % W, y + 1, bw - 2, bh - 2); }
      }
      speck(kind === 'stone' ? 70 : 40, 0.28);
      if (kind === 'stone') for (let i = 0; i < 3; i++) { g.strokeStyle = dk(0.22); g.beginPath(); let x = r() * W, y = r() * H; g.moveTo(x, y); for (let k = 0; k < 4; k++) { x += (r() - 0.5) * 8; y += 2 + r() * 3; g.lineTo(x, y); } g.stroke(); }
    } else if (kind === 'bark') { // ridged vertical grooves that wander
      for (let x = 0; x < W; x += 4 + Math.floor(r() * 3)) { g.fillStyle = dk(0.3); let xx = x; for (let y = 0; y < H; y++) { if (r() < 0.15) xx += r() < 0.5 ? -1 : 1; g.fillRect(((xx % W) + W) % W, y, 1, 1); } g.fillStyle = lt(0.08); g.fillRect((x + 2) % W, 0, 1, H); }
      speck(30, 0.3);
    } else if (kind === 'leaf') { // clumps of leaves: lit tops, shaded undersides
      for (let i = 0; i < 26; i++) { const x = Math.floor(r() * W), y = Math.floor(r() * H), s = 2 + Math.floor(r() * 3); g.fillStyle = lt(0.16); g.fillRect(x, y, s, 1); g.fillStyle = dk(0.26); g.fillRect(x, y + 2, s + 1, 1); g.fillStyle = dk(0.1); g.fillRect(x + 1, y + 1, s, 1); }
    } else if (kind === 'plank') {
      for (let y = 0; y < H; y += 6) { g.fillStyle = dk(0.32); g.fillRect(0, y + 5, W, 1); g.fillStyle = lt(0.08); g.fillRect(0, y, W, 1); for (let k = 0; k < 3; k++) { g.fillStyle = dk(0.12); g.fillRect(Math.floor(r() * W), y + 2 + Math.floor(r() * 2), 6 + Math.floor(r() * 10), 1); } g.fillStyle = dk(0.3); g.fillRect(Math.floor(r() * W), y, 1, 6); }
      g.fillStyle = dk(0.3); g.fillRect(Math.floor(r() * W), 8, 2, 2);
    } else if (kind === 'tile') { // overlapping roof tiles: a curved lower edge each, every row offset
      for (let row = 0; row * 6 < H; row++) for (let x = (row % 2) * 4; x < W + 8; x += 8) { g.fillStyle = dk(0.3); g.fillRect((x % W), row * 6 + 5, 7, 1); g.fillRect((x + 7) % W, row * 6 + 1, 1, 4); g.fillStyle = lt(0.14); g.fillRect((x + 1) % W, row * 6 + 1, 4, 1); }
    } else if (kind === 'concrete') {
      speck(160, 0.2); g.fillStyle = dk(0.25); g.fillRect(0, H - 1, W, 1); g.fillRect(W - 1, 0, 1, H); g.fillStyle = lt(0.08); g.fillRect(0, 0, W, 1);
      g.fillStyle = dk(0.08); g.fillRect(Math.floor(r() * W), 0, 3, H); // a rain streak
    } else if (kind === 'metal') {
      g.fillStyle = dk(0.28); g.fillRect(0, H - 1, W, 1); g.fillRect(W - 1, 0, 1, H); g.fillStyle = lt(0.14); g.fillRect(0, 0, W, 1);
      for (const [x, y] of [[3, 3], [W - 5, 3], [3, H - 5], [W - 5, H - 5]]) { g.fillStyle = dk(0.35); g.fillRect(x, y + 1, 2, 1); g.fillStyle = lt(0.3); g.fillRect(x, y, 1, 1); }
      for (let y = 0; y < H; y += 3) { g.fillStyle = lt(0.03 + r() * 0.04); g.fillRect(0, y, W, 1); }
    }
  } catch { cv = null; }
  return (PATS[kind] = cv);
}
const patCache = new WeakMap();
function patternFor(ctx, kind) {
  let m = patCache.get(ctx); if (!m) { m = {}; patCache.set(ctx, m); }
  if (m[kind] !== undefined) return m[kind];
  const cv = patCanvas(kind);
  return (m[kind] = cv ? ctx.createPattern(cv, 'repeat') : null);
}
// a face's pattern, fixed onto it: u along its level edge, v up its slope
function drawPat(ctx, m, f, pv, x, z, fogK) {
  const n = f.i.length; if (n < 3) return;
  const i0 = f.i[0], i1 = f.i[1], iL = f.i[n - 1], A = pv[i0], B = pv[i1], T = pv[iL];
  const area = Math.abs((B.x - A.x) * (T.y - A.y) - (B.y - A.y) * (T.x - A.x));
  if (area < 220) return;
  const P0 = m.v[i0], P1 = m.v[i1], PL = m.v[iL];
  const e1 = [P1[0] - P0[0], P1[1] - P0[1], P1[2] - P0[2]], e2 = [PL[0] - P0[0], PL[1] - P0[1], PL[2] - P0[2]];
  let U = B, V = T, lu = Math.hypot(...e1), lv = Math.hypot(...e2);
  if (Math.abs(e1[1]) / (lu || 1) < Math.abs(e2[1]) / (lv || 1)) { /* e1 is the level one: keep */ } else { U = T; V = B; [lu, lv] = [lv, lu]; }
  if (lu < 0.05 || lv < 0.05) return;
  const pat = patternFor(ctx, f.pat); if (!pat) return;
  ctx.save();
  ctx.beginPath(); ctx.moveTo(pv[f.i[0]].x, pv[f.i[0]].y); for (let k = 1; k < n; k++) ctx.lineTo(pv[f.i[k]].x, pv[f.i[k]].y); ctx.closePath(); ctx.clip();
  ctx.globalAlpha *= Math.max(0, 1 - fogK * 1.3);
  const s = 1 / PXU;
  ctx.transform((U.x - A.x) / lu * s, (U.y - A.y) / lu * s, (V.x - A.x) / lv * s, (V.y - A.y) / lv * s, A.x, A.y);
  ctx.fillStyle = pat; ctx.fillRect(0, 0, lu * PXU, lv * PXU);
  ctx.restore();
}

// ---------- building blocks ----------
function mesh() { return { v: [], f: [] }; }
function face(m, idx, col) {
  const P = idx.map((i) => m.v[i]);
  const a = P[0], b = P[1], c = P[2];
  const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], w = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
  let n = [u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0]];
  const len = Math.hypot(...n) || 1; n = n.map((x) => x / len);
  const cen = [0, 1, 2].map((k) => P.reduce((s, p) => s + p[k], 0) / P.length);
  const lit = 0.62 + 0.38 * Math.max(0, n[0] * LIGHT[0] + n[1] * LIGHT[1] + n[2] * LIGHT[2]);
  m.f.push({ i: idx, col: shade(col, lit - 1), base: hexRgb(col), n, c: cen, pat: PAT });
}
/** An axis-aligned box (outward faces, counter-clockwise seen from outside). */
export function box(m, x0, y0, z0, x1, y1, z1, col, { top = null, skipBottom = true } = {}) {
  const b = m.v.length;
  m.v.push([x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0], [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]);
  face(m, [b, b + 3, b + 2, b + 1], col);          // front (z0)
  face(m, [b + 4, b + 5, b + 6, b + 7], col);      // back (z1)
  face(m, [b, b + 4, b + 7, b + 3], col);          // left
  face(m, [b + 1, b + 2, b + 6, b + 5], col);      // right
  face(m, [b + 3, b + 7, b + 6, b + 2], top ?? col); // top
  if (!skipBottom) face(m, [b, b + 1, b + 5, b + 4], col);
  return m;
}
/** A tapered n-sided prism standing on y0 (a trunk, a post, a cactus). */
function prism(m, cx, cz, y0, y1, r0, r1, n, col, { cap = true } = {}) {
  const b = m.v.length;
  for (let k = 0; k < n; k++) { const a = (k / n) * Math.PI * 2; m.v.push([cx + Math.cos(a) * r0, y0, cz + Math.sin(a) * r0]); }
  for (let k = 0; k < n; k++) { const a = (k / n) * Math.PI * 2; m.v.push([cx + Math.cos(a) * r1, y1, cz + Math.sin(a) * r1]); }
  for (let k = 0; k < n; k++) { const k2 = (k + 1) % n; face(m, [b + k, b + n + k, b + n + k2, b + k2], col); }
  if (cap && r1 > 0.01) face(m, Array.from({ length: n }, (_, k) => b + n + (n - 1 - k)), shade(col, 0.1));
  return m;
}
/** A cone (n sides) for pine layers. */
function cone(m, cx, cz, y0, y1, r, n, col) {
  const b = m.v.length;
  for (let k = 0; k < n; k++) { const a = (k / n) * Math.PI * 2 + 0.3; m.v.push([cx + Math.cos(a) * r, y0, cz + Math.sin(a) * r]); }
  m.v.push([cx, y1, cz]);
  for (let k = 0; k < n; k++) face(m, [b + k, b + n, b + ((k + 1) % n)], col);
  face(m, Array.from({ length: n }, (_, k) => b + k), shade(col, -0.3));
  return m;
}
/** A lumpy low-poly ball (an octahedron split once, pushed about a little): canopies, bushes, rocks. */
function blob(m, cx, cy, cz, rx, ry, rz, col, seed, { jitter = 0.18, flatBottom = false } = {}) {
  const r = rng(seed);
  let tris = [[[1, 0, 0], [0, 1, 0], [0, 0, 1]], [[0, 0, 1], [0, 1, 0], [-1, 0, 0]], [[-1, 0, 0], [0, 1, 0], [0, 0, -1]], [[0, 0, -1], [0, 1, 0], [1, 0, 0]],
    [[1, 0, 0], [0, 0, 1], [0, -1, 0]], [[0, 0, 1], [-1, 0, 0], [0, -1, 0]], [[-1, 0, 0], [0, 0, -1], [0, -1, 0]], [[0, 0, -1], [1, 0, 0], [0, -1, 0]]];
  const norm = (p) => { const l = Math.hypot(...p); return p.map((x) => x / l); };
  const mid = (a, b) => norm([(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2]);
  tris = tris.flatMap(([a, b, c]) => { const ab = mid(a, b), bc = mid(b, c), ca = mid(c, a); return [[a, ab, ca], [ab, b, bc], [ca, bc, c], [ab, bc, ca]]; });
  const vmap = new Map();
  const vid = (p) => {
    const key = p.map((x) => x.toFixed(3)).join(',');
    if (!vmap.has(key)) {
      const j = 1 + (r() - 0.5) * 2 * jitter;
      let y = p[1] * ry * j; if (flatBottom && y < -ry * 0.35) y = -ry * 0.35;
      m.v.push([cx + p[0] * rx * j, cy + y, cz + p[2] * rz * j]);
      vmap.set(key, m.v.length - 1);
    }
    return vmap.get(key);
  };
  for (const [a, b, c] of tris) {
    const tone = (r() - 0.5) * 0.16;
    face(m, [vid(a), vid(b), vid(c)], shade(col, tone));
  }
  return m;
}

// ---------- props ----------
/** The model for a scenery prop, or null to keep its picture. img: its painted picture (for colours). */
export function propMesh(kind, img, seed = 1, h = 3) {
  try { return propMesh0(kind, img, seed, h); } finally { setPat(null); }
}
function propMesh0(kind, img, seed, h) {
  const C = colorsOf(img), m = mesh();
  // (bark on trunks, leaves on canopies, grain on rock)
  const prism0 = prism, blob0 = blob, cone0 = cone;
  const prismB = (...a) => { setPat('bark'); prism0(...a); setPat(null); }, blobL = (...a) => { setPat('leaf'); blob0(...a); setPat(null); }, coneL = (...a) => { setPat('leaf'); cone0(...a); setPat(null); };
  const leaf = C.top, trunk = /^#([0-9a-f]{6})$/i.test(C.bottom) ? C.bottom : '#7a5232';
  const r = rng(seed * 7 + 3);
  switch (kind) {
    case 'tree': {
      prismB(m, 0, 0, 0, h * 0.5, 0.2, 0.13, 6, trunk);
      // roots flaring out at the foot, and a couple of boughs reaching into the canopy
      for (let i = 0; i < 4; i++) { const a = (i / 4) * Math.PI * 2 + r(); prismB(m, Math.cos(a) * 0.2, Math.sin(a) * 0.2, 0, 0.22, 0.1, 0.03, 4, shade(trunk, -0.1), { cap: false }); }
      for (let i = 0; i < 2; i++) { const a = r() * Math.PI * 2; prismB(m, Math.cos(a) * 0.32, Math.sin(a) * 0.32, h * 0.38, h * 0.6, 0.07, 0.04, 4, trunk); }
      blobL(m, 0, h * 0.62, 0, 1.05, 0.85, 1.0, leaf, seed);
      blobL(m, (r() - 0.5) * 0.6, h * 0.82, (r() - 0.5) * 0.4, 0.75, 0.6, 0.7, shade(leaf, 0.08), seed + 1);
      for (let i = 0; i < 3; i++) { const a = r() * Math.PI * 2; blobL(m, Math.cos(a) * 0.85, h * (0.55 + r() * 0.2), Math.sin(a) * 0.8, 0.42, 0.36, 0.42, shade(leaf, (r() - 0.5) * 0.18), seed + 5 + i); }
      return m;
    }
    case 'deadtree': {
      prismB(m, 0, 0, 0, h * 0.85, 0.2, 0.08, 5, trunk);
      for (let i = 0; i < 3; i++) { const a = r() * Math.PI * 2, y = h * (0.45 + i * 0.15), l = 0.7 - i * 0.12; box(m, Math.min(0, Math.cos(a) * l), y, Math.min(0, Math.sin(a) * l) - 0.04, Math.max(0, Math.cos(a) * l), y + 0.09, Math.max(0, Math.sin(a) * l) + 0.04, trunk); }
      return m;
    }
    case 'pine': case 'snowpine': {
      prismB(m, 0, 0, 0, h * 0.3, 0.16, 0.12, 6, trunk);
      const green = kind === 'snowpine' ? '#2e6a54' : leaf;
      for (let i = 0; i < 3; i++) coneL(m, 0, 0, h * (0.2 + i * 0.22), h * (0.55 + i * 0.22), 1.0 - i * 0.25, 7, i === 2 && kind === 'snowpine' ? '#eef4ff' : shade(green, i * 0.06));
      return m;
    }
    case 'palm': {
      prismB(m, 0, 0, 0, h * 0.8, 0.15, 0.1, 6, '#9a7a4a');
      for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; const b = m.v.length; m.v.push([0, h * 0.82, 0], [Math.cos(a + 0.25) * 0.4, h * 0.86, Math.sin(a + 0.25) * 0.4], [Math.cos(a) * 1.3, h * 0.62, Math.sin(a) * 1.3], [Math.cos(a - 0.25) * 0.4, h * 0.86, Math.sin(a - 0.25) * 0.4]); face(m, [b, b + 1, b + 2, b + 3], '#3f9a4a'); face(m, [b, b + 3, b + 2, b + 1], '#2f7a3a'); }
      return m;
    }
    case 'cactus': {
      prism(m, 0, 0, 0, h * 0.95, 0.24, 0.2, 7, leaf);
      for (const s of [-1, 1]) { const y = h * (0.35 + r() * 0.2); box(m, s < 0 ? -0.55 : 0.2, y, -0.1, s < 0 ? -0.2 : 0.55, y + 0.18, 0.1, leaf); prism(m, s * 0.45, 0, y, y + h * 0.3, 0.12, 0.1, 6, leaf); }
      return m;
    }
    case 'bush': case 'hedgebush': {
      blobL(m, 0, 0.42, 0, 0.75, 0.48, 0.6, C.mid, seed, { flatBottom: true });
      blobL(m, 0.35, 0.55, 0.1, 0.45, 0.35, 0.4, shade(C.mid, 0.08), seed + 2, { flatBottom: true });
      blobL(m, -0.4, 0.38, -0.05, 0.38, 0.3, 0.36, shade(C.mid, -0.06), seed + 3, { flatBottom: true });
      return m;
    }
    case 'rock': case 'lavarock': {
      setPat('concrete'); blob(m, 0, 0.32, 0, 0.62, 0.42, 0.52, C.mid, seed, { jitter: 0.28, flatBottom: true });
      blob(m, 0.45, 0.14, 0.2, 0.26, 0.18, 0.24, shade(C.mid, -0.08), seed + 9, { jitter: 0.3, flatBottom: true }); setPat(null); // a smaller stone beside it
      return m;
    }
    default: return null;
  }
}
export const MODEL_KINDS = new Set(['tree', 'deadtree', 'pine', 'snowpine', 'palm', 'cactus', 'bush', 'rock', 'lavarock']);

// ---------- fences and walls ----------
const STRUCT_FENCES = new Set(['picket', 'rail', 'iron', 'neon', 'glass', 'adobe', 'hedge', 'chain']);
/** A fence segment `len` long along x (dir 'x') or z (dir 'z'), centred on its anchor; null to keep the picture. */
export function fenceMesh(kind, img, len, dir = 'x', seed = 1) {
  if (!STRUCT_FENCES.has(kind)) return null;
  const C = colorsOf(img), m = mesh();
  const B = (a0, y0, b0, a1, y1, b1, col, opts) => (dir === 'x' ? box(m, a0, y0, b0, a1, y1, b1, col, opts) : box(m, b0, y0, a0, b1, y1, a1, col, opts));
  const half = len / 2;
  const wood = C.mid;
  switch (kind) {
    case 'picket': {
      B(-half, 0.35, -0.04, half, 0.45, 0.02, shade(wood, -0.1)); B(-half, 0.75, -0.04, half, 0.85, 0.02, shade(wood, -0.1));
      setPat('plank'); for (let x = -half + 0.1; x < half; x += 0.22) B(x, 0, 0.02, x + 0.14, 1.05, 0.08, wood, { top: shade(wood, 0.25) }); setPat(null);
      return m;
    }
    case 'rail': {
      B(-half, 0, -0.06, -half + 0.12, 1.1, 0.06, '#f2eeff'); B(-half, 0.4, -0.03, half, 0.48, 0.03, '#ffffff'); B(-half, 0.85, -0.03, half, 0.93, 0.03, '#ffffff');
      return m;
    }
    case 'iron': case 'chain': {
      const iron = kind === 'iron' ? '#2a2232' : '#6a708a';
      B(-half, 0.25, -0.02, half, 0.31, 0.02, iron); B(-half, 0.95, -0.02, half, 1.01, 0.02, iron);
      for (let x = -half + 0.05; x < half; x += 0.18) B(x, 0, -0.02, x + 0.05, 1.2, 0.02, iron, { top: '#5a4e6a' });
      return m;
    }
    case 'neon': case 'glass': {
      B(-half, 0, -0.06, -half + 0.12, 1.1, 0.06, '#2a2850');
      B(-half + 0.12, 0.1, -0.01, half, 1.0, 0.01, kind === 'neon' ? '#5a3aa8' : '#bfefff');
      return m;
    }
    case 'adobe': {
      // the desert wall: a thick mud-brick wall with a lighter cap, solid from every side
      const mud = C.mid, cap = shade(C.mid, 0.2);
      B(-half, 0, -0.2, half, 1.05, 0.2, mud, { top: cap });
      B(-half - 0.02, 1.05, -0.24, half + 0.02, 1.15, 0.24, cap, { top: shade(cap, 0.1) });
      return m;
    }
    case 'hedge': {
      const g = C.top;
      B(-half, 0, -0.3, half, 1.0, 0.3, g, { top: shade(g, 0.15) });
      const r = rng(seed);
      for (let x = -half; x < half - 0.1; x += 0.4) { const hh = 1.0 + r() * 0.18; B(x, 0.9, -0.25, x + 0.4, hh, 0.25, shade(g, (r() - 0.5) * 0.12), { top: shade(g, 0.18) }); }
      return m;
    }
    default: return null;
  }
}

// ---------- planters ----------
/** A wooden planter box w × d, h high, filled with dirt (gardening and the berry farm). */
export function planterMesh(w, d, h = 0.34, wood = '#9a6a3c', dirt = '#5a3a20') {
  const m = mesh(), t = 0.09, hw = w / 2, hd = d / 2;
  box(m, -hw, 0, -hd, hw, h, -hd + t, wood, { top: shade(wood, 0.25) });
  box(m, -hw, 0, hd - t, hw, h, hd, wood, { top: shade(wood, 0.25) });
  box(m, -hw, 0, -hd + t, -hw + t, h, hd - t, wood, { top: shade(wood, 0.25) });
  box(m, hw - t, 0, -hd + t, hw, h, hd - t, wood, { top: shade(wood, 0.25) });
  // the dirt inside, just below the rim
  const b = m.v.length;
  m.v.push([-hw + t, h - 0.05, -hd + t], [-hw + t, h - 0.05, hd - t], [hw - t, h - 0.05, hd - t], [hw - t, h - 0.05, -hd + t]);
  face(m, [b, b + 1, b + 2, b + 3], dirt);
  return m;
}

// ---------- drawing ----------
/**
 * Draw a mesh at (x, z) with the yard's camera. fog: 0…0.75 (mixes towards the sky colour), sky: [r, g, b].
 */
export function drawMesh(ctx, yard, m, x, z, { fog = 0, sky = [200, 220, 240], alpha = 1 } = {}) {
  const pv = m.v.map((p) => yard.project(x + p[0], p[1], z + p[2]));
  // lamps, fires and moves nearby light the faces turned towards them
  const near = yard.lighting === false ? null : lightsFor(yard, m, x, z);
  const lit = (f) => {
    if (!near) return;
    const add = faceLight(yard, near, x + f.c[0], f.c[1], z + f.c[2], f.n);
    if (!add) return;
    ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = `rgb(${add[0] | 0},${add[1] | 0},${add[2] | 0})`;
    ctx.beginPath(); ctx.moveTo(pv[f.i[0]].x, pv[f.i[0]].y); for (let k = 1; k < f.i.length; k++) ctx.lineTo(pv[f.i[k]].x, pv[f.i[k]].y); ctx.closePath(); ctx.fill(); ctx.restore();
  };
  const camX = yard.cx, camY = yard.camY, camZ = yard.cz;
  const vis = [];
  for (const f of m.f) {
    const c = f.c;
    const dx = camX - (x + c[0]), dy = camY - c[1], dz = camZ - (z + c[2]);
    if (f.n[0] * dx + f.n[1] * dy + f.n[2] * dz <= 0) continue;
    if (f.i.some((k) => !pv[k])) continue;
    vis.push({ f, d: dx * dx + dy * dy + dz * dz });
  }
  vis.sort((a, b) => b.d - a.d);
  const lvl = Math.round(Math.max(0, Math.min(0.75, fog)) * 10), fogK = lvl / 10;
  if (alpha < 1) { ctx.save(); ctx.globalAlpha = alpha; }
  for (const { f } of vis) {
    // lit by the sun where it is now (worked out again only when the sun has moved), or the fixed light
    const sun = yard.sun;
    if (sun && f.base && f.sunKey !== sun.key) { f.sunKey = sun.key; f.sunRgb = sunShade(sun, f.base, f.n); f.fogCol = null; }
    else if (!sun && f.sunKey) { f.sunKey = null; f.sunRgb = null; f.fogCol = null; }
    let col = f.fogCol?.[lvl];
    if (!col) {
      const [r, g, b] = f.sunRgb ?? hexRgb(f.col), k = lvl / 10;
      col = `rgb(${Math.round(r + (sky[0] - r) * k)},${Math.round(g + (sky[1] - g) * k)},${Math.round(b + (sky[2] - b) * k)})`;
      (f.fogCol = f.fogCol || [])[lvl] = col;
    }
    if (f.tex) {
      // a picture fixed onto the model (a crowd in the stands): mapped onto the face's corners, so it stays put
      // in the world however the camera turns
      const [i0, i1, i3] = f.tq, A = pv[i0], B = pv[i1], T = pv[i3], w = f.tex.width, hh = f.tex.height;
      ctx.save();
      ctx.setTransform((B.x - A.x) / w, (B.y - A.y) / w, (A.x - T.x) / hh, (A.y - T.y) / hh, T.x, T.y);
      ctx.drawImage(f.tex, 0, 0);
      ctx.restore();
      if (lvl > 0) { ctx.fillStyle = `rgba(${sky[0]},${sky[1]},${sky[2]},${(lvl / 10).toFixed(2)})`; ctx.beginPath(); ctx.moveTo(pv[f.i[0]].x, pv[f.i[0]].y); for (let k = 1; k < f.i.length; k++) ctx.lineTo(pv[f.i[k]].x, pv[f.i[k]].y); ctx.closePath(); ctx.fill(); }
      lit(f);
      continue;
    }
    ctx.fillStyle = col; ctx.strokeStyle = col; ctx.lineWidth = 0.6;
    ctx.beginPath();
    const p0 = pv[f.i[0]]; ctx.moveTo(p0.x, p0.y);
    for (let k = 1; k < f.i.length; k++) { const p = pv[f.i[k]]; ctx.lineTo(p.x, p.y); }
    ctx.closePath(); ctx.fill(); ctx.stroke();
    if (f.pat && !yard.lowFx && fogK < 0.7) drawPat(ctx, m, f, pv, x, z, fogK);
    lit(f);
  }
  if (alpha < 1) ctx.restore();
}

// ---------- for the battle arenas (stadium stands, colosseum walls, temples…) ----------
export { mesh, face, prism, cone, blob, shade };
/** A box turned by `ang` (radians, about its own centre cx, cz). w along its length, d its depth. */
export function obox(m, cx, cz, w, d, y0, y1, ang, col, { top = null } = {}) {
  const c = Math.cos(ang), s = Math.sin(ang), b = m.v.length;
  const pt = (lx, lz, y) => [cx + lx * c - lz * s, y, cz + lx * s + lz * c];
  const hw = w / 2, hd = d / 2;
  m.v.push(pt(-hw, -hd, y0), pt(hw, -hd, y0), pt(hw, -hd, y1), pt(-hw, -hd, y1), pt(-hw, hd, y0), pt(hw, hd, y0), pt(hw, hd, y1), pt(-hw, hd, y1));
  face(m, [b, b + 3, b + 2, b + 1], col);
  face(m, [b + 4, b + 5, b + 6, b + 7], col);
  face(m, [b, b + 4, b + 7, b + 3], col);
  face(m, [b + 1, b + 2, b + 6, b + 5], col);
  face(m, [b + 3, b + 7, b + 6, b + 2], top ?? col);
  return m;
}
/** A flat panel (a window, an arch's shadow, a sign) facing direction (nx, nz), centred at (cx, y, cz). */
export function panel(m, cx, cy, cz, w, h, nx, nz, col) {
  const b = m.v.length, tx = -nz, tz = nx; // along the wall
  const hw = w / 2, hh = h / 2;
  m.v.push([cx - tx * hw, cy - hh, cz - tz * hw], [cx + tx * hw, cy - hh, cz + tz * hw], [cx + tx * hw, cy + hh, cz + tz * hw], [cx - tx * hw, cy + hh, cz - tz * hw]);
  face(m, [b, b + 1, b + 2, b + 3], col);
  // make sure it faces the way asked (flip the winding if not)
  const f = m.f[m.f.length - 1];
  if (f.n[0] * nx + f.n[2] * nz < 0) { m.f.pop(); face(m, [b, b + 3, b + 2, b + 1], col); }
  return m;
}

/** A picture fixed onto a model as an upright quad: corners bottom-left a, bottom-right b (each [x, z]), from y0 to y1.
 *  It faces the way box()'s front face does when a is at x0 and b at x1. */
export function texQuad(m, a, b, y0, y1, img) {
  const k = m.v.length;
  m.v.push([a[0], y0, a[1]], [b[0], y0, b[1]], [b[0], y1, b[1]], [a[0], y1, a[1]]);
  face(m, [k, k + 3, k + 2, k + 1], '#808080');
  const f = m.f[m.f.length - 1];
  f.tex = img; f.tq = [k, k + 1, k + 3];
  return m;
}
