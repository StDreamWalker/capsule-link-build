// Creature summary card (used by the PC boxes, the ranch and the phone).
import { h, hearts, bar, typeChip, hpBar, fmtNum } from './dom.js';
import { spriteCanvas } from './art.js';
import { sizeVariant } from './creatureSize.js';
import { eggProgress, calcStats, displayName, friendshipTier, levelProgress, speciesOf, STAT_KEYS, NEED_KEYS, NEED_LABELS, mood, tickNeeds, cryFor } from '../engine/index.js';
import { playCry, creatureCry } from './audio.js';

export function creatureSummary(idx, bank, c, { compact = false, actions = null, sections = ['stats', 'moves', 'care', 'walk', 'info', 'memories'] } = {}) {
  const sp = speciesOf(idx, c);
  if (!sp) return h('div', { class: 'summary' }, h('p', null, `Unknown species "${c.speciesId}". Add it in the Data Lab.`));
  tickNeeds(idx, c);
  const stats = calcStats(idx, c);
  const tier = friendshipTier(c.friendship);
  const m = mood(c);
  const sprite = spriteCanvas(bank, c, { scale: compact ? 3 : 4, animate: true });
  sprite.title = 'Play cry';
  sprite.style.cursor = 'pointer';
  sprite.addEventListener('click', () => creatureCry(sp, c));
  const maxStat = Math.max(150, ...STAT_KEYS.map((k) => stats[k]));

  const parts = [
    h('div', { class: 'pedestal' }, sprite),
    h('div', { class: 'ident' },
      h('h1', null, displayName(idx, c)),
      c.nickname ? h('span', { class: 'dim' }, sp.name) : null,
      h('span', { class: 'spacer' }),
      h('span', { class: 'dim', title: 'Its size compared with others of its kind' }, `Size ${sizeVariant(c).label}`),
      h('span', null, `Lv. ${c.level}`)),
    c.egg ? h('div', { class: 'col', style: { gap: '4px' } },
      h('div', { class: 'row' }, h('span', { class: 'dim', style: { width: '48px' } }, 'Egg'), h('div', { class: 'grow' }, bar(eggProgress(c), 'exp')), h('span', { class: 'mono-num' }, `${fmtNum(Math.ceil(c.egg.steps))} steps`)),
      h('p', { class: 'micro dim' }, 'Walking together counts double. It also warms up on its own, so it always hatches in the end.')) : null,
    h('div', { class: 'row wrap' }, sp.types.map((t) => typeChip(idx, t)),
      c.status ? h('span', { class: 'chip', style: { background: idx.statuses.get(c.status)?.color ?? '#999' } }, idx.statuses.get(c.status)?.name ?? c.status) : null),
    h('div', { class: 'row' }, hearts(tier.hearts), h('span', { class: 'dim' }, `${tier.label} · ${m.label}`)),
    h('div', { class: 'col', style: { gap: '4px' } },
      h('div', { class: 'row' }, h('span', { class: 'dim', style: { width: '48px' } }, 'HP'), h('div', { class: 'grow' }, hpBar(c.hp ?? stats.hp, stats.hp)), h('span', { class: 'mono-num' }, `${c.hp ?? stats.hp}/${stats.hp}`)),
      h('div', { class: 'row' }, h('span', { class: 'dim', style: { width: '48px' } }, 'Exp'), h('div', { class: 'grow' }, bar(levelProgress(idx, c), 'exp')), h('span', { class: 'mono-num' }, fmtNum(c.exp)))),
  ];

  if (sections.includes('stats')) {
    parts.push(h('div', { class: 'stats' }, STAT_KEYS.filter((k) => k !== 'hp').map((k) => {
      const t = idx.temperaments.get(c.temper);
      const mark = t?.up === k ? ' ▲' : t?.down === k ? ' ▼' : '';
      return [h('span', { class: 'dim' }, idx.ds.statLabels[k] + mark), h('span', { class: 'mono-num' }, stats[k]), bar(stats[k] / maxStat, 'stat')];
    })));
  }
  if (sections.includes('moves')) {
    parts.push(h('div', { class: 'moves' }, [0, 1, 2, 3].map((i) => {
      const mm = c.moves[i];
      const mv = mm && idx.moves.get(mm.id);
      if (!mv) return h('div', { class: 'move faint' }, '—');
      return h('div', { class: 'move', style: { '--type': idx.types.get(mv.type)?.color }, title: mv.desc ?? '' },
        h('div', null, mv.name), h('div', { class: 'dim' }, mv.category === 'status' ? `Status · PP ${mv.pp}` : `${mv.power} pow · PP ${mv.pp}`));
    })));
  }
  if (sections.includes('care')) {
    parts.push(h('div', { class: 'stats' }, NEED_KEYS.map((k) => [h('span', { class: 'dim' }, NEED_LABELS[k]), h('span', { class: 'mono-num' }, Math.round(c.needs[k])), bar(c.needs[k] / 100, 'need')])));
  }
  if (sections.includes('walk')) {
    parts.push(h('div', { class: 'kv' },
      h('span', null, 'Walked together'), h('span', null, `${fmtNum(c.walk?.totalSteps)} steps`),
      h('span', null, 'Friendship'), h('span', null, `${c.friendship} / ${idx.ds.rules.maxFriendship}`)));
  }
  if (sections.includes('info') && !compact) {
    const t = idx.temperaments.get(c.temper);
    parts.push(h('div', { class: 'kv' },
      h('span', null, 'Temperament'), h('span', null, t?.name ?? '—'),
      h('span', null, 'Trainer'), h('span', null, c.trainer || '—'),
      h('span', null, 'Met'), h('span', null, `${new Date(c.metAt).toLocaleDateString()} at Lv. ${c.metLevel}`)));
    if (sp.flavor) parts.push(h('p', { class: 'dim' }, sp.flavor));
  }
  if (sections.includes('memories') && c.memories?.length) {
    const list = [...c.memories].reverse().slice(0, compact ? 10 : 30);
    parts.push(h('div', null, h('h2', null, 'Memories'),
      c.origin?.game ? h('p', { class: 'micro dim' }, `Came from ${c.origin.game}${c.origin.ot ? ` · first trainer ${c.origin.ot}` : ''}. Older memories come from there.`) : null,
      h('ul', { class: 'memories' }, list.map((mm) => h('li', { class: mm.from === 'game' ? 'from-game' : '' },
        h('span', { class: 'dim' }, new Date(mm.t).toLocaleDateString(), '  '), mm.text,
        mm.from === 'game' ? h('span', { class: 'chip micro mem-tag' }, c.origin?.game ?? 'earlier') : null)))));
  }
  if (actions) parts.push(actions);
  return h('div', { class: 'summary' }, parts);
}
