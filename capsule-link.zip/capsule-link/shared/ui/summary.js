// Creature summary card (used by the PC boxes, the ranch and the phone).
import { h, hearts, bar, typeChip, hpBar, fmtNum } from './dom.js';
import { spriteCanvas } from './art.js';
import { ballIcon, creatureBall } from './capsuleArt.js';
import { BALL_NAMES } from './brandArt.js';
import { sizeVariant } from './creatureSize.js';
import { topPrefs, dislikes, favorites, CARE_TOYS, friendsOf, formsOf, currentFormId, homeTransferNote } from '../engine/index.js';
const hex8 = (n) => (Number(n) >>> 0).toString(16).toUpperCase().padStart(8, '0');
import { eggProgress, calcStats, displayName, friendshipTier, levelProgress, speciesOf, STAT_KEYS, NEED_KEYS, NEED_LABELS, mood, tickNeeds, cryFor } from '../engine/index.js';
import { playCry, creatureCry } from './audio.js';

// a small warning beside the name (never on the picture) when training here won't go back with it to its game
function homeMark(c) {
  const note = homeTransferNote(c);
  if (!note) return null;
  // hover shows it; a tap (phones have no hover) opens it underneath
  const toggle = (e) => { const el = e.currentTarget, row = el.closest('.ident'); const open = row?.nextElementSibling?.classList.contains('home-note'); if (open) row.nextElementSibling.remove(); else row?.insertAdjacentElement('afterend', h('p', { class: 'home-note micro' }, '⚠ ', note)); };
  return h('span', { class: 'home-mark', tabindex: 0, role: 'button', 'aria-label': note, title: note, onclick: toggle, onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(e); } } }, '⚠');
}

export function creatureSummary(idx, bank, c, { compact = false, actions = null, save = null, sections = ['stats', 'moves', 'care', 'walk', 'info', 'memories'], onChangeBall = null, reballCost = 300 } = {}) {
  const sp = speciesOf(idx, c);
  if (!sp) return h('div', { class: 'summary' }, h('p', null, `Unknown species "${c.speciesId}". Add it in the Data Lab.`));
  tickNeeds(idx, c);
  const stats = calcStats(idx, c);
  const tier = friendshipTier(c.friendship);
  const m = mood(c);
  const sprite = spriteCanvas(bank, c, { scale: compact ? 3 : 4, animate: true });
  sprite.title = 'Play cry';
  sprite.style.cursor = 'pointer';
  sprite.addEventListener('click', () => creatureCry(sp, c));
  const maxStat = Math.max(150, ...STAT_KEYS.map((k) => stats[k]));

  const parts = [
    h('div', { class: 'pedestal' }, sprite),
    h('div', { class: 'ident' },
      (() => { const b = creatureBall(c), el = ballIcon(b, 22, 'closed'); el.title = b === 'nexus' ? 'In a Nexus Ball' : `Caught in a ${BALL_NAMES[b] ?? 'ball'}`; el.classList.add('sum-ball'); return el; })(),
      h('h1', null, displayName(idx, c)),
      c.nickname ? h('span', { class: 'dim' }, sp.name) : null,
      h('span', { class: 'spacer' }),
      h('span', { class: 'dim', title: 'Its size compared with others of its kind' }, `Size ${sizeVariant(c).label}`),
      h('span', null, `Lv. ${c.level}`),
      homeMark(c)),
    c.egg ? h('div', { class: 'col', style: { gap: '4px' } },
      h('div', { class: 'row' }, h('span', { class: 'dim', style: { width: '48px' } }, 'Egg'), h('div', { class: 'grow' }, bar(eggProgress(c), 'exp')), h('span', { class: 'mono-num' }, `${fmtNum(Math.ceil(c.egg.steps))} steps`)),
      h('p', { class: 'micro dim' }, 'Walking together counts double. It also warms up on its own, so it always hatches in the end.')) : null,
    h('div', { class: 'row wrap' }, sp.types.map((t) => typeChip(idx, t)),
      c.status ? h('span', { class: 'chip', style: { background: idx.statuses.get(c.status)?.color ?? '#999' } }, idx.statuses.get(c.status)?.name ?? c.status) : null),
    h('div', { class: 'row' }, hearts(tier.hearts), h('span', { class: 'dim' }, `${tier.label} · ${m.label}`)),
    h('div', { class: 'col', style: { gap: '4px' } },
      h('div', { class: 'row' }, h('span', { class: 'dim', style: { width: '48px' } }, 'HP'), h('div', { class: 'grow' }, hpBar(c.hp ?? stats.hp, stats.hp)), h('span', { class: 'mono-num' }, `${c.hp ?? stats.hp}/${stats.hp}`)),
      h('div', { class: 'row' }, h('span', { class: 'dim', style: { width: '48px' } }, 'Exp'), h('div', { class: 'grow' }, bar(levelProgress(idx, c), 'exp')), h('span', { class: 'mono-num' }, fmtNum(c.exp)))),
  ];

  if (sections.includes('stats')) {
    parts.push(h('div', { class: 'stats' }, STAT_KEYS.filter((k) => k !== 'hp').map((k) => {
      const t = idx.temperaments.get(c.temper);
      const mark = t?.up === k ? ' ▲' : t?.down === k ? ' ▼' : '';
      return [h('span', { class: 'dim' }, idx.ds.statLabels[k] + mark), h('span', { class: 'mono-num' }, stats[k]), bar(stats[k] / maxStat, 'stat')];
    })));
  }
  if (sections.includes('moves')) {
    parts.push(h('div', { class: 'moves' }, [0, 1, 2, 3].map((i) => {
      const mm = c.moves[i];
      const mv = mm && idx.moves.get(mm.id);
      if (!mv) return h('div', { class: 'move faint' }, '—');
      return h('div', { class: 'move', style: { '--type': idx.types.get(mv.type)?.color }, title: mv.desc ?? '' },
        h('div', null, mv.name), h('div', { class: 'dim' }, mv.category === 'status' ? `Status · PP ${mv.pp}` : `${mv.power} pow · PP ${mv.pp}`));
    })));
  }
  if (sections.includes('care')) {
    parts.push(h('div', { class: 'stats' }, NEED_KEYS.map((k) => [h('span', { class: 'dim' }, NEED_LABELS[k]), h('span', { class: 'mono-num' }, Math.round(c.needs[k])), bar(c.needs[k] / 100, 'need')])));
  }
  if (sections.includes('walk')) {
    parts.push(h('div', { class: 'kv' },
      h('span', null, 'Walked together'), h('span', null, `${fmtNum(c.walk?.totalSteps)} steps`),
      h('span', null, 'Friendship'), h('span', null, `${c.friendship} / ${idx.ds.rules.maxFriendship}`)));
  }
  if (sections.includes('info') && !compact) {
    const t = idx.temperaments.get(c.temper);
    parts.push(h('div', { class: 'kv' },
      h('span', null, 'Temperament'), h('span', null, t?.name ?? '—'),
      h('span', null, 'Trainer'), h('span', null, c.trainer || '—'),
      h('span', null, 'Met'), h('span', null, `${new Date(c.metAt).toLocaleDateString()} at Lv. ${c.metLevel}`),
      // its ball, and (for a substantial sum) a different one
      h('span', null, 'Ball'), h('span', { class: 'row', style: { gap: '6px', alignItems: 'center' } }, ballIcon(creatureBall(c), 18, 'closed'), BALL_NAMES[creatureBall(c)] ?? (creatureBall(c) === 'nexus' ? 'Nexus Ball' : 'Poké Ball'),
        onChangeBall && c.location?.kind !== 'capsule' ? h('button', { class: 'btn small ghost', title: `Move ${displayName(idx, c)} into a different ball (${reballCost} coins). Only how it looks here: its game data keeps the ball it was caught in.`, onclick: () => onChangeBall(c) }, `Change (🪙 ${reballCost})`) : null)));
    if (sp.flavor) parts.push(h('p', { class: 'dim' }, sp.flavor));
  }
  if (sections.includes('likes')) {
    // what they've come to love (from experience), their favourites once found, and their friends
    const likes = topPrefs(c, idx, 5).map((p) => p.label);
    const fav = favorites(idx, c);
    const found = (id) => c.firsts?.[`fav:${id}`];
    if (fav.berry && found(fav.berry)) likes.unshift(idx.items.get(fav.berry)?.name ?? fav.berry);
    if (fav.toy && found(fav.toy)) likes.unshift(CARE_TOYS.find((t) => t.id === fav.toy)?.name ?? idx.items.get(fav.toy)?.name ?? fav.toy);
    const not = dislikes(c, idx).map((p) => p.label);
    const friends = save ? friendsOf(c).map((f) => save.creatures[f.uid]).filter(Boolean) : [];
    if (likes.length || not.length || friends.length) {
      parts.push(h('div', { class: 'kv likes-kv' },
        likes.length ? [h('span', null, 'Loves'), h('span', null, [...new Set(likes)].join(', '))] : null,
        not.length ? [h('span', null, 'Not keen on'), h('span', null, not.join(', '))] : null,
        friends.length ? [h('span', null, 'Friends'), h('span', null, friends.map((f) => displayName(idx, f)).join(', '))] : null));
    }
  }
  if (sections.includes('info') && !compact && c.pk) {
    // the hidden values the games keep, carried over exactly
    const k = c.pk;
    const ivs = k.ivs ? STAT_KEYS.map((s) => k.ivs[s]).join('/') : '—';
    const evs = k.evs ? STAT_KEYS.map((s) => k.evs[s]).join('/') : '—';
    parts.push(h('details', { class: 'game-data' }, h('summary', null, 'Game data'),
      h('div', { class: 'kv mono-kv' },
        h('span', null, 'PID / EC'), h('span', null, `${hex8(k.pid)} / ${hex8(k.ec)}`),
        h('span', null, 'TID / SID'), h('span', null, `${k.tid} / ${k.sid}`),
        h('span', null, 'Shiny'), h('span', null, k.shinyType ? `${k.shinyType} (xor ${k.shinyXor})` : `no (xor ${k.shinyXor})`),
        h('span', null, 'IVs'), h('span', null, ivs), h('span', null, 'EVs'), h('span', null, evs),
        h('span', null, 'Nature'), h('span', null, `${k.nature}${k.statNature && k.statNature !== k.nature ? ` (stats as ${k.statNature})` : ''}`),
        h('span', null, 'Size'), h('span', null, `height ${k.heightScalar} · weight ${k.weightScalar}${k.scale != null ? ` · scale ${k.scale}` : ''}`),
        k.teraType ? [h('span', null, 'Tera type'), h('span', null, `#${k.teraType.original}${k.teraType.override !== k.teraType.original && k.teraType.override !== 19 ? ` → #${k.teraType.override}` : ''}`)] : null,
        h('span', null, 'Origin'), h('span', null, `${k.format} · version ${k.version} · language ${k.language} · ball ${k.ball}`))));
  }
  if (sections.includes('memories') && (c.memories?.length || c.journal?.length)) {
    const list = [...(c.memories ?? [])].reverse().slice(0, compact ? 10 : 40);
    const lately = [...(c.journal ?? [])].reverse().slice(0, compact ? 5 : 12);
    parts.push(h('div', null, h('h2', null, 'Core memories'),
      c.origin?.game ? h('p', { class: 'micro dim' }, `Came from ${c.origin.game}${c.origin.ot ? ` · first trainer ${c.origin.ot}` : ''}. Older memories come from there.`) : null,
      h('ul', { class: 'memories' }, list.map((mm) => h('li', { class: mm.from === 'game' ? 'from-game' : '' },
        h('span', { class: 'dim' }, new Date(mm.t).toLocaleDateString(), '  '), mm.text,
        mm.from === 'game' ? h('span', { class: 'chip micro mem-tag' }, c.origin?.game ?? 'earlier') : null))),
      lately.length ? h('details', { class: 'journal' }, h('summary', null, `Lately (${lately.length})`),
        h('ul', { class: 'memories lately' }, lately.map((mm) => h('li', null, h('span', { class: 'dim' }, new Date(mm.t).toLocaleDateString(), '  '), mm.text)))) : null));
  }
  if (actions) parts.push(actions);
  return h('div', { class: 'summary' }, parts);
}

/** A "Form" picker for creatures with more than one form (null otherwise). onPick(formId or null). */
export function formPicker(idx, c, onPick) {
  const forms = formsOf(idx, c.speciesId);
  if (forms.length < 2 || c.egg) return null;
  const cur = currentFormId(idx, c);
  return h('label', { class: 'row form-pick' }, h('span', { class: 'dim' }, 'Form'),
    h('select', { onchange: (e) => onPick(e.target.value === c.speciesId ? null : e.target.value) },
      forms.map((f) => h('option', { value: f.id, selected: f.id === cur }, `${f.forme}${f.battleOnly ? ' (battles as usual form)' : ''}`))));
}
