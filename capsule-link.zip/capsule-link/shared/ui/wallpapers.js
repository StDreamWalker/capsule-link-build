// Storage box wallpapers. The default is a clean, system-style surface; each box can pick
// another (soft OS-style gradients, any habitat scene, or a picture of your own in textures/boxes).
import { renderBiome, BIOME_IDS, BIOME_INFO } from './biomes.js';

export const WALL_W = 216, WALL_H = 180;

export const OS_WALLS = [
  { id: 'clean', label: 'Clean' },
  { id: 'bloom', label: 'Bloom' },
  { id: 'glow', label: 'Glow' },
  { id: 'aurora', label: 'Aurora' },
  { id: 'sunset', label: 'Sunset' },
  { id: 'mint', label: 'Mint' },
  { id: 'lavender', label: 'Lavender' },
  { id: 'mesh', label: 'Mesh' },
  { id: 'waves', label: 'Waves' },
  { id: 'dots', label: 'Dot grid' },
  { id: 'graphite', label: 'Graphite' },
  { id: 'midnight', label: 'Midnight' },
];

/** Every choice: [{ id, label, group }] with custom textures from boxes/ that are not biome names. */
export function wallpaperChoices(textureKeys = []) {
  const biomeSet = new Set(BIOME_IDS);
  const custom = textureKeys
    .filter((k) => k.startsWith('boxes/') && k.endsWith('.png'))
    .map((k) => k.slice(6, -4))
    .filter((id) => !biomeSet.has(id) && !OS_WALLS.some((w) => w.id === id));
  return [
    ...OS_WALLS.map((w) => ({ ...w, group: 'System' })),
    ...BIOME_IDS.map((id) => ({ id: `biome:${id}`, label: BIOME_INFO[id].label, group: 'Habitats' })),
    ...custom.map((id) => ({ id: `custom:${id}`, label: id.replace(/[-_]+/g, ' '), group: 'Yours' })),
  ];
}

/** The box's wallpaper id (older saves used the habitat as wallpaper; new boxes start clean). */
export function boxWallpaper(box) { return box?.wallpaper || 'clean'; }

function grad(ctx, stops, x0, y0, x1, y1) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  stops.forEach(([o, c]) => g.addColorStop(o, c));
  return g;
}
function blob(ctx, x, y, r, c) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, c); g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2);
}

/** Paint a system wallpaper at 2× for crisp edges. Returns a canvas, or null for 'clean' (pure CSS). */
export function renderOsWall(id) {
  if (id === 'clean') return null;
  const W = WALL_W * 2, H = WALL_H * 2;
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const ctx = c.getContext('2d');
  switch (id) {
    case 'bloom': {
      ctx.fillStyle = grad(ctx, [[0, '#dce8ff'], [1, '#eef3ff']], 0, 0, 0, H); ctx.fillRect(0, 0, W, H);
      ctx.save(); ctx.translate(W * 0.55, H * 0.62);
      for (let i = 0; i < 9; i++) {
        ctx.rotate(Math.PI / 4.5);
        ctx.fillStyle = `hsla(${215 + i * 4}, 90%, ${55 + i * 3}%, 0.35)`;
        ctx.beginPath(); ctx.ellipse(70, 0, 120, 42, 0, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();
      blob(ctx, W * 0.55, H * 0.62, 120, 'rgba(255,255,255,0.6)');
      break;
    }
    case 'glow': ctx.fillStyle = '#0f1630'; ctx.fillRect(0, 0, W, H); blob(ctx, W * 0.2, H * 0.2, 260, 'rgba(59,108,246,0.65)'); blob(ctx, W * 0.85, H * 0.9, 260, 'rgba(18,181,165,0.55)'); blob(ctx, W * 0.7, H * 0.25, 180, 'rgba(139,92,246,0.4)'); break;
    case 'aurora': ctx.fillStyle = grad(ctx, [[0, '#0b1a2e'], [1, '#132a3a']], 0, 0, 0, H); ctx.fillRect(0, 0, W, H);
      for (let k = 0; k < 3; k++) { ctx.fillStyle = `hsla(${150 + k * 40}, 80%, 60%, 0.22)`; ctx.beginPath(); ctx.moveTo(0, H * (0.3 + k * 0.12)); for (let x = 0; x <= W; x += 8) ctx.lineTo(x, H * (0.3 + k * 0.12) + Math.sin(x / 60 + k * 2) * 40); ctx.lineTo(W, 0); ctx.lineTo(0, 0); ctx.fill(); }
      break;
    case 'sunset': ctx.fillStyle = grad(ctx, [[0, '#ffd3a5'], [0.55, '#ff9a9e'], [1, '#a18cd1']], 0, 0, 0, H); ctx.fillRect(0, 0, W, H); blob(ctx, W * 0.5, H * 0.62, 150, 'rgba(255,240,200,0.7)'); break;
    case 'mint': ctx.fillStyle = grad(ctx, [[0, '#e0fff4'], [1, '#c2f0e6']], 0, 0, W, H); ctx.fillRect(0, 0, W, H); blob(ctx, W * 0.8, H * 0.2, 200, 'rgba(18,181,165,0.25)'); blob(ctx, W * 0.1, H * 0.9, 220, 'rgba(59,108,246,0.15)'); break;
    case 'lavender': ctx.fillStyle = grad(ctx, [[0, '#f2eaff'], [1, '#e3d7ff']], 0, 0, W, H); ctx.fillRect(0, 0, W, H); blob(ctx, W * 0.2, H * 0.25, 200, 'rgba(192,79,216,0.18)'); blob(ctx, W * 0.9, H * 0.8, 220, 'rgba(91,69,196,0.2)'); break;
    case 'mesh': ctx.fillStyle = '#f7f3ff'; ctx.fillRect(0, 0, W, H); blob(ctx, 0, 0, 300, 'rgba(255,138,61,0.45)'); blob(ctx, W, 0, 300, 'rgba(61,123,255,0.45)'); blob(ctx, 0, H, 300, 'rgba(52,209,191,0.45)'); blob(ctx, W, H, 300, 'rgba(192,79,216,0.45)'); break;
    case 'waves': ctx.fillStyle = '#eaf1ff'; ctx.fillRect(0, 0, W, H);
      for (let k = 0; k < 5; k++) { ctx.fillStyle = `rgba(59,108,246,${0.06 + k * 0.05})`; ctx.beginPath(); const y0 = H * (0.35 + k * 0.13); ctx.moveTo(0, H); for (let x = 0; x <= W; x += 6) ctx.lineTo(x, y0 + Math.sin(x / 70 + k) * 14); ctx.lineTo(W, H); ctx.fill(); }
      break;
    case 'dots': ctx.fillStyle = '#f4f6fb'; ctx.fillRect(0, 0, W, H); ctx.fillStyle = 'rgba(30,40,70,0.12)'; for (let y = 10; y < H; y += 18) for (let x = 10; x < W; x += 18) { ctx.beginPath(); ctx.arc(x, y, 1.6, 0, Math.PI * 2); ctx.fill(); } break;
    case 'graphite': ctx.fillStyle = grad(ctx, [[0, '#2b2f38'], [1, '#1d2027']], 0, 0, 0, H); ctx.fillRect(0, 0, W, H); for (let i = 0; i < 2500; i++) { ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.04})`; ctx.fillRect(Math.random() * W, Math.random() * H, 1, 1); } break;
    case 'midnight': ctx.fillStyle = grad(ctx, [[0, '#0b0f24'], [1, '#1b1446']], 0, 0, 0, H); ctx.fillRect(0, 0, W, H); for (let i = 0; i < 120; i++) { ctx.fillStyle = `rgba(255,255,255,${0.2 + Math.random() * 0.6})`; ctx.fillRect(Math.random() * W, Math.random() * H * 0.8, 1.4, 1.4); } blob(ctx, W * 0.8, H * 0.2, 60, 'rgba(255,250,220,0.5)'); break;
    default: ctx.fillStyle = '#eef1f7'; ctx.fillRect(0, 0, W, H);
  }
  return c;
}

const cache = new Map();
/**
 * Background for a wallpaper id: { url, dark, pixel } or { url: null } for the clean style.
 * textures: path -> url map (custom pictures and per-habitat replacements).
 */
export function wallpaperStyle(id, textures = {}, version = 0) {
  const key = `${id}:${version}:${id.startsWith('custom:') ? textures[`boxes/${id.slice(7)}.png`] : ''}`;
  if (cache.has(key)) return cache.get(key);
  let out;
  if (id.startsWith('custom:')) out = { url: textures[`boxes/${id.slice(7)}.png`] ?? null, dark: false, pixel: false };
  else if (id.startsWith('biome:')) {
    const biome = id.slice(6);
    let url = textures[`boxes/${biome}.png`];
    if (!url) {
      const src = renderBiome(biome, WALL_W, WALL_H, { seed: 5 });
      const c = document.createElement('canvas');
      c.width = WALL_W; c.height = WALL_H;
      c.getContext('2d').drawImage(src, 0, 0);
      url = c.toDataURL();
    }
    out = { url, dark: ['cavern', 'starfield', 'seafloor', 'volcano'].includes(biome), pixel: true };
  } else {
    const custom = textures[`boxes/${id}.png`];
    const c = custom ? null : renderOsWall(id);
    out = { url: custom ?? (c ? c.toDataURL() : null), dark: ['glow', 'aurora', 'graphite', 'midnight'].includes(id), pixel: false };
  }
  cache.set(key, out);
  return out;
}
