// Trainer ID cards drawn as pixel art. Each design is original; together they nod to how
// differently ID cards look around the world (landscape cards, booklet pages, portrait badges,
// holographic plastics, licenses with stamps).
import { normalizeCard, trainerNumber, CARD_DESIGNS } from '../engine/trainerCard.js';
import { brandText } from './dom.js';
import { artImage, onUiArt } from './brandArt.js';

const FONT = '"Segoe UI Variable Text", "Segoe UI", system-ui, -apple-system, Roboto, "Inter", "Helvetica Neue", Arial, sans-serif';
const RES = 3; // cards are drawn at three times their layout size so text is sharp
export const CARD_SIZE = { landscape: [240, 150], portrait: [150, 240] };

// ---------- colour helpers ----------
function rgb(hex) { const n = parseInt(hex.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function hex([r, g, b]) { return `#${[r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('')}`; }
export function shade(c, f) { const [r, g, b] = rgb(c); return f < 0 ? hex([r * (1 + f), g * (1 + f), b * (1 + f)]) : hex([r + (255 - r) * f, g + (255 - g) * f, b + (255 - b) * f]); }
const lum = (c) => { const [r, g, b] = rgb(c); return (0.299 * r + 0.587 * g + 0.114 * b) / 255; };
const onColor = (c) => (lum(c) > 0.6 ? '#1b1838' : '#ffffff');

// ---------- pixel helpers ----------
function px(ctx, x, y, w, h, c) { ctx.fillStyle = c; ctx.fillRect(Math.round(x), Math.round(y), w, h); }
function text(ctx, s, x, y, c, { size = 10, align = 'left', max = 0, weight = 600 } = {}) {
  const fs = size >= 20 ? 17 : size >= 12 ? size : 9;
  ctx.font = `${size >= 20 ? 700 : weight} ${fs}px ${FONT}`;
  ctx.textBaseline = 'top';
  ctx.textAlign = align;
  ctx.fillStyle = c;
  let str = brandText(String(s ?? ''));
  if (max) while (str.length > 1 && ctx.measureText(str).width > max) str = str.slice(0, -1);
  ctx.fillText(str, x, y + (size >= 20 ? 0 : 0.5));
}
function field(ctx, label, value, x, y, { lc = '#7a77a0', vc = '#1b1838', max = 0, size = 10 } = {}) {
  ctx.save();
  ctx.font = `700 6px ${FONT}`;
  ctx.textBaseline = 'top'; ctx.textAlign = 'left'; ctx.fillStyle = lc;
  if ('letterSpacing' in ctx) ctx.letterSpacing = '0.6px';
  ctx.fillText(brandText(label).toUpperCase(), x, y + 1);
  ctx.restore();
  text(ctx, value, x, y + 9, vc, { size, max });
}
function frame(ctx, x, y, w, h, c) { px(ctx, x, y, w, 1, c); px(ctx, x, y + h - 1, w, 1, c); px(ctx, x, y, 1, h, c); px(ctx, x + w - 1, y, 1, h, c); }
function roundMask(ctx, w, h, r) {
  ctx.globalCompositeOperation = 'destination-in';
  ctx.beginPath();
  // stepped corners so the edge stays pixel-sharp
  for (let y = 0; y < h; y++) {
    let inset = 0;
    if (y < r) inset = r - Math.round(Math.sqrt(r * r - (r - y - 0.5) ** 2));
    else if (y >= h - r) inset = r - Math.round(Math.sqrt(r * r - (y - (h - r) + 0.5) ** 2));
    ctx.rect(inset, y, w - inset * 2, 1);
  }
  ctx.fill();
  ctx.globalCompositeOperation = 'source-over';
}
function barcode(ctx, x, y, w, h, seed, c) {
  let s = 0;
  for (const ch of String(seed)) s = (Math.imul(s, 31) + ch.charCodeAt(0)) >>> 0;
  let cx = x;
  while (cx < x + w - 2) {
    s = (Math.imul(s, 1103515245) + 12345) >>> 0;
    const bw = 1 + ((s >>> 8) % 3);
    if ((s >>> 16) & 1) px(ctx, cx, y, Math.min(bw, x + w - cx), h, c);
    cx += bw + ((s >>> 20) % 2);
  }
}
function chip(ctx, x, y) {
  px(ctx, x, y, 22, 17, '#c99412'); px(ctx, x + 1, y + 1, 20, 15, '#ffd45e');
  for (const yy of [5, 11]) px(ctx, x + 1, y + yy, 20, 1, '#c99412');
  px(ctx, x + 8, y + 1, 1, 15, '#c99412'); px(ctx, x + 13, y + 1, 1, 15, '#c99412');
}
/** The Capsule Link emblem: an upright capsule with a status light. */
function emblem(ctx, x, y, r, c, band = '#1b1838') {
  const logo = artImage('ui/logo.png');
  if (logo) { const s = r * 2.2; ctx.save(); ctx.imageSmoothingEnabled = true; ctx.drawImage(logo, x - s / 2, y - s / 2, s, s); ctx.restore(); return; }
  const w = r * 1.25, hh = r * 2, x0 = x - w / 2, y0 = y - r;
  ctx.save();
  const rr = w / 2;
  const pill = () => { ctx.beginPath(); ctx.moveTo(x0, y0 + rr); ctx.arc(x, y0 + rr, rr, Math.PI, 0); ctx.lineTo(x0 + w, y0 + hh - rr); ctx.arc(x, y0 + hh - rr, rr, 0, Math.PI); ctx.closePath(); };
  pill(); ctx.fillStyle = '#ffffff'; ctx.fill();
  ctx.save(); pill(); ctx.clip(); ctx.fillStyle = c; ctx.fillRect(x0, y0, w, hh * 0.47); ctx.fillStyle = band; ctx.fillRect(x0, y0 + hh * 0.45, w, Math.max(0.8, r * 0.12)); ctx.restore();
  pill(); ctx.strokeStyle = band; ctx.lineWidth = 0.8; ctx.stroke();
  ctx.fillStyle = '#12b5a5'; ctx.beginPath(); ctx.arc(x, y0 + hh * 0.66, Math.max(0.8, r * 0.16), 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}
function guilloche(ctx, w, h, c, a = 0.18) {
  ctx.save(); ctx.globalAlpha = a; ctx.strokeStyle = c; ctx.lineWidth = 0.4;
  for (let k = 0; k < 12; k++) {
    ctx.beginPath();
    for (let x = 0; x <= w; x += 1) {
      const y = h * 0.5 + Math.sin(x / (9 + k) + k * 1.7) * (h * 0.32) * Math.cos(x / 41 + k);
      if (x) ctx.lineTo(x, y); else ctx.moveTo(x, y);
    }
    ctx.stroke();
  }
  ctx.restore();
}
function stamp(ctx, x, y, r, c, label) {
  ctx.save(); ctx.globalAlpha = 0.6; ctx.strokeStyle = c; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.stroke();
  ctx.lineWidth = 0.5; ctx.beginPath(); ctx.arc(x, y, r - 2.5, 0, Math.PI * 2); ctx.stroke();
  text(ctx, label, x, y - 5, c, { align: 'center', weight: 800 });
  ctx.restore();
}
const fmtDate = (t) => { const d = new Date(t); return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`; };

// ---------- the portrait ----------
/**
 * A 40×48 pixel portrait from the avatar options. Colours come from the avatar itself (hat,
 * outfit, trim), never from the card, so clothes and card colour are chosen separately.
 */
export function drawAvatar(ctx, ox, oy, av, { bg = null } = {}) {
  const P = (x, y, w, h, c) => px(ctx, ox + x, oy + y, w, h, c);
  if (bg) P(0, 0, 40, 48, bg);
  const ink = '#1b1838';
  const skin = av.skin, skinD = shade(skin, -0.18), skinL = shade(skin, 0.18);
  const hair = av.hairColor, hairD = shade(hair, -0.3), hairL = shade(hair, 0.25);
  const out = av.outfit, outD = shade(out, -0.25), outL = shade(out, 0.2), out2 = av.outfit2 ?? '#ffffff';
  const hc = av.hatColor ?? '#e5484d', hcD = shade(hc, -0.3), hcL = shade(hc, 0.3);
  const ec = av.eyeColor ?? ink;
  const acc = new Set(av.accessories ?? []);
  const style = av.outfitStyle ?? 'tee';

  // ---- behind the head ----
  switch (av.hair) {
    case 'long': P(8, 12, 24, 30, hairD); break;
    case 'wavy': P(8, 12, 24, 29, hairD); for (let y = 16; y < 40; y += 4) { P(7, y, 1, 2, hairD); P(32, y + 2, 1, 2, hairD); } break;
    case 'braids': P(8, 12, 24, 14, hairD); break;
    case 'bob': P(9, 12, 22, 18, hairD); break;
    case 'ponytail': P(29, 13, 5, 20, hairD); P(30, 14, 3, 18, hair); P(30, 31, 3, 3, hairD); break;
    case 'afro': P(6, 4, 28, 26, hair); P(5, 8, 1, 18, hair); P(34, 8, 1, 18, hair); P(8, 3, 24, 1, hair); break;
    default: break;
  }
  if (acc.has('backpack')) { P(4, 37, 32, 11, '#3a3550'); }

  // ---- body ----
  P(5, 38, 30, 10, out); P(5, 38, 30, 1, outL); P(5, 44, 30, 4, outD);
  switch (style) {
    case 'tee': P(9, 41, 1, 7, outD); P(30, 41, 1, 7, outD); break;
    case 'hoodie': P(11, 35, 18, 4, outD); P(17, 40, 1, 5, out2); P(22, 40, 1, 5, out2); P(13, 44, 14, 3, outD); P(13, 44, 14, 1, out); break;
    case 'jacket': P(16, 38, 8, 10, out2); P(14, 38, 3, 8, outD); P(23, 38, 3, 8, outD); P(9, 40, 1, 8, outD); P(30, 40, 1, 8, outD); break;
    case 'vest': P(5, 38, 30, 10, out2); P(5, 38, 30, 1, shade(out2, 0.2)); P(8, 39, 8, 9, out); P(24, 39, 8, 9, out); P(15, 44, 1, 1, outD); P(24, 44, 1, 1, outD); break;
    case 'uniform': P(19, 40, 2, 1, out2); P(19, 43, 2, 1, out2); P(19, 46, 2, 1, out2); P(20, 38, 1, 10, outD); break;
    case 'sweater': P(5, 42, 30, 2, out2); P(5, 46, 30, 1, out2); break;
    case 'coat': P(5, 38, 30, 10, out); P(20, 38, 1, 10, outD); for (const y of [40, 43, 46]) { P(17, y, 1, 1, out2); P(23, y, 1, 1, out2); } P(5, 47, 30, 1, outD); break;
    case 'track': P(8, 38, 2, 10, out2); P(30, 38, 2, 10, out2); P(20, 38, 1, 10, outL); break;
    case 'dress': P(5, 38, 30, 4, skin); P(5, 38, 30, 1, skinL); P(9, 41, 22, 7, out); P(9, 41, 22, 1, out2); P(13, 38, 2, 3, out); P(25, 38, 2, 3, out); P(9, 47, 22, 1, outD); break;
    case 'overalls': P(5, 38, 30, 10, out2); P(5, 38, 30, 1, shade(out2, 0.15)); P(13, 41, 14, 7, out); P(13, 38, 3, 3, out); P(24, 38, 3, 3, out); P(14, 41, 1, 1, '#ffd45e'); P(25, 41, 1, 1, '#ffd45e'); P(17, 44, 6, 2, outD); break;
    default: break;
  }
  // neck
  P(17, 31, 6, 7, skin); P(17, 31, 6, 2, skinD);
  if (style === 'tee' || style === 'sweater' || style === 'track') { P(16, 37, 8, 2, style === 'tee' ? skinD : outD); P(17, 37, 6, 1, skin); }
  if (style === 'uniform') { P(15, 36, 4, 3, out2); P(21, 36, 4, 3, out2); P(19, 38, 2, 5, shade(out2 === '#ffffff' ? hc : out2, -0.25)); }
  if (style === 'coat') { P(14, 34, 4, 5, outD); P(22, 34, 4, 5, outD); }
  if (style === 'hoodie') { P(16, 37, 8, 1, outD); }
  if (acc.has('backpack')) { P(9, 38, 3, 10, '#2a2640'); P(28, 38, 3, 10, '#2a2640'); P(9, 43, 3, 1, '#7a77a0'); P(28, 43, 3, 1, '#7a77a0'); }
  if (acc.has('necklace')) { P(15, 36, 1, 1, '#ffd45e'); P(24, 36, 1, 1, '#ffd45e'); P(16, 37, 8, 1, '#ffd45e'); P(19, 38, 2, 2, hc); }
  if (acc.has('scarf')) { P(13, 34, 14, 5, hc); P(13, 34, 14, 1, hcL); P(13, 38, 4, 7, hcD); }

  // ---- head ----
  P(11, 11, 18, 21, skin); P(12, 31, 16, 1, skin); P(13, 32, 14, 1, skinD);
  P(10, 19, 1, 5, skin); P(29, 19, 1, 5, skin); P(10, 20, 1, 3, skinD); P(29, 20, 1, 3, skinD);
  if (av.hair === 'bald' || av.hair === 'mohawk') P(14, 12, 4, 1, skinL);

  // ---- eyes and brows ----
  const ey = 20;
  const eye = (x, kind, right) => {
    switch (kind) {
      case 'round': P(x, ey, 2, 2, ec); P(x, ey, 1, 1, '#ffffff'); break;
      case 'wide': P(x - 1, ey - 1, 3, 3, '#ffffff'); P(x, ey - 1, 2, 3, ec); P(x, ey - 1, 1, 1, '#ffffff'); P(x - 1, ey - 2, 3, 1, ink); break;
      case 'lashes': P(x, ey, 2, 2, ec); P(x, ey, 1, 1, '#ffffff'); P(right ? x + 2 : x - 1, ey - 1, 1, 1, ink); P(x - 1 + (right ? 1 : 0), ey - 1, 2, 1, ink); break;
      case 'sharp': P(x - 1, ey, 3, 1, ink); P(x, ey + 1, 2, 1, ec); break;
      case 'narrow': P(x - 1, ey + 1, 3, 1, ink); P(x, ey, 2, 1, ec); break;
      case 'happy': P(x - 1, ey + 1, 1, 1, ink); P(x, ey, 2, 1, ink); P(x + 2, ey + 1, 1, 1, ink); break;
      case 'sleepy': P(x - 1, ey + 1, 4, 1, ink); break;
      default: P(x, ey, 2, 2, ec);
    }
  };
  if (av.eyes === 'wink') { eye(15, 'round', false); P(22, ey + 1, 4, 1, ink); } else { eye(15, av.eyes, false); eye(23, av.eyes, true); }
  const brow = (x, right) => {
    switch (av.brows) {
      case 'bold': P(x - 1, ey - 3, 4, 2, hairD); break;
      case 'angled': if (right) { P(x - 1, ey - 2, 2, 1, hairD); P(x + 1, ey - 3, 2, 1, hairD); } else { P(x - 1, ey - 3, 2, 1, hairD); P(x + 1, ey - 2, 2, 1, hairD); } break;
      case 'raised': P(x - 1, ey - 4, 3, 1, hairD); break;
      case 'thin': P(x, ey - 2, 2, 1, hairD); break;
      case 'none': break;
      default: P(x - 1, ey - 2, 3, 1, hairD);
    }
  };
  brow(15, false); brow(23, true);
  P(19, 23, 2, 2, skinD); // nose
  if (!acc.has('mask')) { P(13, 25, 2, 1, '#ff9aa8'); P(25, 25, 2, 1, '#ff9aa8'); }
  if (acc.has('blush')) { P(12, 24, 4, 2, '#ff9aa8'); P(24, 24, 4, 2, '#ff9aa8'); }
  if (acc.has('freckles')) for (const [x, y] of [[13, 23], [15, 24], [24, 23], [26, 24], [14, 25]]) P(x, y, 1, 1, shade(skin, -0.35));
  if (acc.has('beautymark')) P(25, 27, 1, 1, shade(skin, -0.55));
  if (acc.has('bandaid')) { P(23, 22, 5, 2, '#f2c48d'); P(25, 22, 1, 2, '#e0a96e'); }

  // ---- facial hair, then mouth ----
  const fh = av.facialHair;
  if (fh === 'stubble') for (let y = 26; y < 32; y++) for (let x = 12 + (y % 2); x < 28; x += 2) if (!(y >= 26 && y <= 28 && x >= 17 && x <= 22)) P(x, y, 1, 1, shade(skin, -0.24));
  if (fh === 'beard') { P(11, 22, 2, 9, hair); P(27, 22, 2, 9, hair); P(12, 27, 16, 6, hair); P(14, 33, 12, 1, hair); P(16, 25, 8, 2, hair); P(13, 31, 14, 1, hairD); }
  if (fh === 'goatee') { P(18, 29, 4, 3, hair); P(17, 26, 6, 1, hair); }
  if (fh === 'mustache') { P(16, 25, 8, 2, hair); P(15, 26, 1, 1, hair); P(24, 26, 1, 1, hair); }
  const lip = '#8c3a3a';
  if (!acc.has('mask')) {
    switch (av.mouth) {
      case 'smile': P(17, 27, 6, 1, lip); P(18, 28, 4, 1, lip); break;
      case 'grin': P(16, 27, 8, 2, lip); P(17, 27, 6, 1, '#ffffff'); P(17, 29, 6, 1, lip); break;
      case 'open': P(18, 27, 4, 3, '#5a1f2a'); P(19, 29, 2, 1, '#ff7a8a'); break;
      case 'smirk': P(18, 28, 4, 1, lip); P(22, 27, 1, 1, lip); break;
      case 'pout': P(18, 27, 4, 2, '#c2566a'); P(18, 27, 4, 1, '#a8455a'); break;
      default: P(18, 27, 4, 1, lip);
    }
  } else {
    P(12, 24, 16, 8, '#e8eef8'); P(12, 24, 16, 1, '#ffffff'); P(13, 27, 14, 1, '#cfd6e4'); P(10, 23, 2, 1, '#cfd6e4'); P(28, 23, 2, 1, '#cfd6e4');
  }

  // ---- hair on top ----
  const top = () => { P(10, 8, 20, 6, hair); P(11, 7, 18, 1, hair); P(10, 14, 3, 6, hair); P(27, 14, 3, 6, hair); P(12, 8, 6, 1, hairL); P(13, 14, 7, 2, hair); };
  switch (av.hair) {
    case 'short': top(); break;
    case 'sidepart': top(); P(12, 13, 13, 3, hair); P(24, 13, 3, 2, hair); P(17, 7, 1, 5, hairD); P(18, 8, 8, 1, hairL); break;
    case 'long': top(); P(8, 14, 4, 26, hair); P(28, 14, 4, 26, hair); break;
    case 'wavy': top(); for (let y = 14; y < 40; y += 2) { const o = (y >> 1) % 2; P(8 + o, y, 4, 2, hair); P(28 - o, y, 4, 2, hair); } break;
    case 'ponytail': top(); P(28, 12, 3, 3, hc); break;
    case 'pigtails': top(); P(4, 15, 7, 9, hair); P(29, 15, 7, 9, hair); P(5, 16, 2, 2, hairL); P(30, 16, 2, 2, hairL); P(9, 15, 2, 3, hc); P(29, 15, 2, 3, hc); break;
    case 'spiky': top(); for (let i = 0; i < 5; i++) { P(10 + i * 4, 4, 2, 4, hair); P(11 + i * 4, 2, 1, 2, hair); } break;
    case 'messy': top(); for (const [x, y, w, hh] of [[9, 6, 3, 3], [14, 4, 3, 4], [20, 5, 4, 3], [26, 6, 3, 3], [29, 9, 2, 3]]) P(x, y, w, hh, hair); P(14, 14, 2, 3, hair); P(22, 14, 2, 2, hair); P(15, 5, 1, 1, hairL); break;
    case 'bob': top(); P(9, 13, 4, 16, hair); P(27, 13, 4, 16, hair); P(13, 13, 14, 3, hair); break;
    case 'bun': top(); P(16, 1, 8, 7, hair); P(17, 2, 3, 1, hairL); break;
    case 'twinbuns': top(); P(8, 3, 7, 7, hair); P(25, 3, 7, 7, hair); P(9, 4, 2, 1, hairL); P(26, 4, 2, 1, hairL); break;
    case 'braids': top(); P(7, 18, 4, 22, hair); P(29, 18, 4, 22, hair); for (const y of [24, 30, 36]) { P(7, y, 4, 1, hairD); P(29, y, 4, 1, hairD); } P(7, 40, 4, 2, hc); P(29, 40, 4, 2, hc); break;
    case 'curly': for (let i = 0; i < 6; i++) { P(8 + i * 4, 5 + (i % 2), 5, 5, hair); P(9 + i * 4, 6 + (i % 2), 1, 1, hairL); } P(8, 10, 4, 10, hair); P(28, 10, 4, 10, hair); P(12, 10, 16, 3, hair); break;
    case 'afro': P(8, 5, 24, 9, hair); P(10, 13, 20, 2, hair); for (const [x, y] of [[9, 6], [14, 4], [21, 5], [27, 7], [7, 12], [31, 13], [11, 9], [24, 9]]) P(x, y, 1, 1, hairL); break;
    case 'mohawk': P(17, 2, 6, 11, hair); P(18, 3, 2, 1, hairL); P(10, 12, 2, 5, hairD); P(28, 12, 2, 5, hairD); break;
    case 'undercut': P(10, 12, 3, 7, hairD); P(27, 12, 3, 7, hairD); P(11, 6, 18, 7, hair); P(10, 8, 20, 4, hair); P(20, 12, 9, 2, hair); P(13, 7, 8, 1, hairL); break;
    case 'buzz': P(11, 9, 18, 4, hairD); P(10, 12, 2, 5, hairD); P(28, 12, 2, 5, hairD); break;
    case 'bald': break;
    default: top();
  }

  // ---- hats ----
  switch (av.hat) {
    case 'cap': P(10, 6, 20, 8, hc); P(11, 5, 18, 1, hc); P(5, 12, 14, 2, hcD); P(12, 7, 5, 1, hcL); P(19, 6, 2, 1, '#ffffff'); break;
    case 'backwards': P(10, 5, 20, 9, hc); P(11, 4, 18, 1, hc); P(12, 6, 5, 1, hcL); P(16, 11, 8, 2, hcD); P(19, 4, 2, 1, hcD); break;
    case 'beanie': P(10, 4, 20, 10, hc); P(10, 11, 20, 3, hcD); P(18, 1, 4, 3, '#ffffff'); for (let x = 11; x < 30; x += 3) P(x, 5, 1, 5, hcL); break;
    case 'bucket': P(11, 5, 18, 7, hc); P(12, 5, 8, 1, hcL); P(7, 11, 26, 3, hcD); P(11, 10, 18, 1, shade(hc, -0.45)); break;
    case 'visor': P(10, 11, 20, 3, hc); P(6, 13, 15, 2, hcD); P(11, 11, 6, 1, hcL); break;
    case 'sunhat': P(12, 4, 16, 8, hc); P(13, 4, 6, 1, hcL); P(2, 11, 36, 3, hc); P(2, 13, 36, 1, hcD); P(12, 10, 16, 1, out2); break;
    case 'beret': P(9, 6, 22, 6, hc); P(26, 4, 6, 4, hc); P(19, 4, 2, 2, hcD); P(10, 11, 20, 1, hcD); P(11, 7, 6, 1, hcL); break;
    case 'bandana': P(10, 9, 20, 5, hc); for (let x = 12; x < 29; x += 4) P(x, 11, 1, 1, '#ffffff'); P(29, 12, 4, 3, hc); P(31, 15, 2, 3, hcD); break;
    default: break;
  }

  // ---- things worn over the face ----
  if (acc.has('glasses') || acc.has('shades')) {
    const lens = acc.has('shades') ? '#1b1838' : null;
    for (const x of [13, 21]) { frame(ctx, ox + x, oy + 18, 6, 5, ink); if (lens) { P(x + 1, 19, 4, 3, lens); P(x + 1, 19, 1, 1, '#7a77a0'); } }
    P(19, 20, 2, 1, ink); P(11, 20, 2, 1, ink); P(27, 20, 2, 1, ink);
  } else if (acc.has('roundglasses')) {
    for (const x of [13, 21]) { P(x + 1, 18, 4, 1, ink); P(x + 1, 22, 4, 1, ink); P(x, 19, 1, 3, ink); P(x + 5, 19, 1, 3, ink); }
    P(19, 19, 2, 1, ink); P(11, 20, 2, 1, ink); P(27, 20, 2, 1, ink);
  }
  if (acc.has('eyepatch')) { P(21, 18, 6, 5, ink); P(11, 16, 10, 1, ink); P(27, 17, 2, 1, ink); }
  if (acc.has('goggles')) { P(10, 11, 20, 2, '#3a3550'); P(12, 9, 7, 5, '#3a3550'); P(21, 9, 7, 5, '#3a3550'); P(13, 10, 5, 3, '#7dd3fc'); P(22, 10, 5, 3, '#7dd3fc'); P(13, 10, 2, 1, '#ffffff'); P(22, 10, 2, 1, '#ffffff'); }
  if (acc.has('headband')) { P(10, 13, 20, 2, hc); P(10, 13, 20, 1, hcL); }
  if (acc.has('headphones')) { P(9, 5, 22, 2, '#2a2640'); P(8, 7, 2, 9, '#2a2640'); P(30, 7, 2, 9, '#2a2640'); P(6, 16, 5, 8, '#2a2640'); P(29, 16, 5, 8, '#2a2640'); P(7, 18, 3, 4, hc); P(30, 18, 3, 4, hc); }
  if (acc.has('earrings')) { P(9, 24, 1, 2, '#ffc93c'); P(30, 24, 1, 2, '#ffc93c'); }
  if (acc.has('flower')) { const f = '#ff5d8f'; P(25, 9, 5, 5, f); P(24, 10, 7, 3, f); P(26, 8, 3, 7, f); P(26, 10, 3, 3, '#ffd45e'); }
}

/** Portrait boxes are remembered while a card draws, so a pattern can go over the card but not the face. */
let portraits = null;
function drawPortrait(ctx, x, y, card, bg) {
  const av = card.avatar;
  const back = av.bg && av.bg !== 'auto' ? av.bg : bg;
  const img = av.sprite ? artImage(av.sprite) : null;
  if (av.sprite) {
    px(ctx, x, y, 40, 48, back ?? '#e9ecf5');
    if (img) {
      // a trainer picture: fit it to the box, keeping crisp pixels for small sprites
      const k = Math.min(40 / img.width, 48 / img.height) * (img.height > img.width * 1.4 ? 1 : 1.15);
      const w = img.width * k, hh = img.height * k;
      ctx.save();
      ctx.beginPath(); ctx.rect(x, y, 40, 48); ctx.clip();
      ctx.imageSmoothingEnabled = img.width > 120;
      ctx.drawImage(img, x + (40 - w) / 2, y + 48 - hh + (hh > 48 ? (hh - 48) * 0.15 : 0), w, hh);
      ctx.restore();
    } else {
      // still loading (or missing): a soft silhouette
      ctx.save(); ctx.globalAlpha = 0.25;
      drawAvatar(ctx, x, y, { ...av, accessories: [], hat: 'none', skin: '#7a77a0', hairColor: '#7a77a0', outfit: '#7a77a0', outfit2: '#7a77a0', eyeColor: '#7a77a0' });
      ctx.restore();
    }
  } else drawAvatar(ctx, x, y, av, { bg: back });
  if (portraits) portraits.push({ m: ctx.getTransform(), x, y, card, bg });
}

function photo(ctx, x, y, card, { bg, border = '#1b1838', scan = false } = {}) {
  px(ctx, x - 1, y - 1, 42, 50, border);
  drawPortrait(ctx, x, y, card, bg);
  if (scan) { ctx.save(); ctx.globalAlpha = 0.18; for (let yy = 0; yy < 48; yy += 2) px(ctx, x, y + yy, 40, 1, '#000000'); ctx.restore(); }
}

/** Security printing over the whole card in the second card colour. */
function cardPattern(ctx, w, h, card) {
  const c = card.accent2 ?? shade(card.accent, 0.35);
  const dark = ['neon', 'aurora'].includes(card.design);
  ctx.save();
  ctx.globalAlpha = dark ? 0.22 : 0.13;
  ctx.fillStyle = c; ctx.strokeStyle = c; ctx.lineWidth = 0.5;
  switch (card.pattern) {
    case 'guilloche': ctx.restore(); guilloche(ctx, w, h, c, dark ? 0.3 : 0.2); return;
    case 'dots': for (let y = 3; y < h; y += 6) for (let x = (y % 12 ? 0 : 3); x < w; x += 6) ctx.fillRect(x, y, 1.2, 1.2); break;
    case 'stripes': for (let x = -h; x < w; x += 7) { ctx.beginPath(); ctx.moveTo(x, h); ctx.lineTo(x + h, 0); ctx.stroke(); } break;
    case 'waves': for (let y = 4; y < h; y += 7) { ctx.beginPath(); for (let x = 0; x <= w; x += 2) { const yy = y + Math.sin(x / 7) * 2; if (x) ctx.lineTo(x, yy); else ctx.moveTo(x, yy); } ctx.stroke(); } break;
    case 'grid': for (let x = 0; x < w; x += 8) ctx.fillRect(x, 0, 0.5, h); for (let y = 0; y < h; y += 8) ctx.fillRect(0, y, w, 0.5); break;
    case 'stars': for (let i = 0; i < 70; i++) { const x = (i * 97) % w, y = (i * 53 + (i % 7) * 11) % h; ctx.fillRect(x - 1.5, y, 3, 0.7); ctx.fillRect(x, y - 1.5, 0.7, 3); } break;
    case 'chevron': for (let y = 0; y < h + 8; y += 8) { ctx.beginPath(); for (let x = 0; x <= w; x += 6) ctx.lineTo(x, y + ((x / 6) % 2 ? 3 : 0)); ctx.stroke(); } break;
    case 'topo': for (let k = 0; k < 9; k++) { ctx.beginPath(); for (let a = 0; a <= Math.PI * 2 + 0.1; a += 0.15) { const r = 8 + k * 9 + Math.sin(a * 3 + k) * 3; const x = w * 0.7 + Math.cos(a) * r * 1.4, y = h * 0.45 + Math.sin(a) * r; if (a) ctx.lineTo(x, y); else ctx.moveTo(x, y); } ctx.stroke(); } break;
    case 'hex': for (let y = 0; y < h + 8; y += 7) for (let x = (Math.round(y / 7) % 2) * 6; x < w + 12; x += 12) { ctx.beginPath(); for (let i = 0; i <= 6; i++) { const a = (Math.PI / 3) * i; ctx.lineTo(x + Math.cos(a) * 4, y + Math.sin(a) * 4); } ctx.stroke(); } break;
    default: break;
  }
  ctx.restore();
}

// ---------- designs ----------
const DESIGNS = {
  classic(ctx, w, h, card, t, num) {
    const a = card.accent;
    px(ctx, 0, 0, w, h, '#f5f7ff');
    guilloche(ctx, w, h, card.accent2 ?? a, 0.12);
    px(ctx, 0, 0, w, 24, a); px(ctx, 0, 24, w, 2, shade(a, -0.3));
    emblem(ctx, 13, 12, 7, '#e5484d');
    text(ctx, 'CAPSULE LINK', 26, 4, onColor(a));
    text(ctx, 'TRAINER IDENTIFICATION', 26, 13, shade(onColor(a) === '#ffffff' ? a : '#ffffff', 0.7));
    photo(ctx, 12, 36, card, { bg: shade(a, 0.75) });
    field(ctx, 'Name', t.name, 64, 32, { size: 20, max: 168 });
    field(ctx, card.title, `No. ${num}`, 64, 62);
    field(ctx, 'Home region', card.region || '—', 64, 86, { max: 100 });
    field(ctx, 'Issued', fmtDate(card.issued), 170, 86);
    if (card.motto) text(ctx, `"${card.motto}"`, 64, 112, shade(a, -0.2), { max: 168 });
    barcode(ctx, 12, 128, 150, 12, num, '#1b1838');
    text(ctx, num.replace('-', ''), 168, 130, '#4a4670');
  },
  booklet(ctx, w, h, card, t, num) {
    const a = card.accent, paper = '#f4ecd6', ink = '#2b2440';
    px(ctx, 0, 0, w, h, paper);
    guilloche(ctx, w, h, card.accent2 ?? a, 0.22);
    for (let x = 0; x < w; x += 4) px(ctx, x, 0, 2, 2, shade(a, 0.4));
    text(ctx, 'TRAINER RECORD', 10, 8, ink);
    text(ctx, 'PAGE 01', w - 10, 8, shade(ink, 0.4), { align: 'right' });
    px(ctx, 10, 20, w - 20, 1, shade(a, -0.1));
    photo(ctx, 12, 30, card, { bg: shade(paper, -0.06) });
    stamp(ctx, w - 30, 104, 13, a, 'OK');
    field(ctx, 'Surname / Name', t.name, 66, 28, { vc: ink, max: 160 });
    field(ctx, 'Class', card.title, 66, 52, { vc: ink });
    field(ctx, 'Region', card.region || '—', 150, 52, { vc: ink, max: 80 });
    field(ctx, 'Record no.', num, 66, 76, { vc: ink });
    field(ctx, 'Date of issue', fmtDate(card.issued), 150, 76, { vc: ink });
    px(ctx, 66, 108, 100, 1, shade(ink, 0.5));
    text(ctx, t.name, 68, 98, shade(a, -0.35), { max: 98 });
    text(ctx, 'signature', 66, 111, shade(ink, 0.5));
    let row = '';
    for (const ch of `${t.name}${num}`.toUpperCase().replace(/[^A-Z0-9]/g, '')) row += `${ch} `;
    text(ctx, row.slice(0, 64), 10, 128, shade(ink, 0.25));
  },
  badge(ctx, w, h, card, t, num) {
    const a = card.accent;
    px(ctx, 0, 0, w, h, '#ffffff');
    px(ctx, 0, 0, w, 58, a);
    for (let y = 0; y < 58; y += 6) px(ctx, 0, y, w, 1, shade(a, 0.1));
    px(ctx, w / 2 - 14, 8, 28, 6, '#1b1838'); px(ctx, w / 2 - 13, 9, 26, 4, shade(a, -0.4)); // lanyard slot
    text(ctx, 'CAPSULE LINK', w / 2, 20, onColor(a), { align: 'center' });
    px(ctx, w / 2 - 26, 34, 52, 60, '#ffffff');
    ctx.save(); ctx.translate(w / 2 - 20, 38);
    px(ctx, -1, -1, 42, 50, '#1b1838'); drawPortrait(ctx, 0, 0, card, shade(a, 0.75));
    ctx.restore();
    text(ctx, t.name, w / 2, 102, '#1b1838', { size: 20, align: 'center', max: w - 12 });
    const tw = card.title.length * 6 + 12;
    px(ctx, w / 2 - tw / 2, 126, tw, 13, a);
    text(ctx, card.title.toUpperCase(), w / 2, 128, onColor(a), { align: 'center' });
    field(ctx, 'Region', card.region || '—', 12, 148, { max: 126 });
    field(ctx, 'Since', fmtDate(card.issued), 12, 172);
    px(ctx, 0, h - 44, w, 44, shade(a, -0.35));
    text(ctx, `No. ${num}`, w / 2, h - 40, '#ffffff', { align: 'center' });
    barcode(ctx, 16, h - 26, w - 32, 14, num, '#ffffff');
  },
  aurora(ctx, w, h, card, t, num) {
    const a = card.accent;
    const g = ctx.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, '#16123a'); g.addColorStop(1, shade(a, -0.55));
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    const bands = ['#ff7eb6', '#ffd45e', '#7dffcf', '#7db8ff', '#c89bff'];
    ctx.save(); ctx.globalAlpha = 0.16;
    for (let y = 0; y < h; y++) for (let i = 0; i < 9; i++) { ctx.fillStyle = bands[i % bands.length]; ctx.fillRect(Math.round(i * 34 - y * 0.6), y, 14, 1); }
    ctx.restore();
    chip(ctx, 14, 40);
    emblem(ctx, w - 18, 16, 8, a, '#ffffff');
    text(ctx, 'TRAINER ID', 14, 12, '#ffffff');
    text(ctx, card.title.toUpperCase(), 14, 22, '#c8c2ff');
    photo(ctx, w - 56, 38, card, { bg: shade(a, 0.3), border: '#ffffff' });
    field(ctx, 'Name', t.name, 14, 66, { lc: '#a8a2e0', vc: '#ffffff', size: 20, max: 160 });
    field(ctx, 'Region', card.region || '—', 14, 96, { lc: '#a8a2e0', vc: '#ffffff', max: 100 });
    field(ctx, 'Issued', fmtDate(card.issued), 120, 96, { lc: '#a8a2e0', vc: '#ffffff' });
    text(ctx, num, 14, 128, '#ffd45e', { size: 20 });
  },
  heritage(ctx, w, h, card, t, num) {
    const a = card.accent, paper = '#fbf6ea';
    px(ctx, 0, 0, w, h, paper);
    px(ctx, 0, 0, 30, h, a);
    for (let y = 0; y < h; y += 10) {
      for (let k = 0; k < 5; k++) { px(ctx, 15 - k, y + k, 1, 1, shade(a, 0.45)); px(ctx, 15 + k, y + k, 1, 1, shade(a, 0.45)); px(ctx, 15 - k, y + 9 - k, 1, 1, shade(a, 0.45)); px(ctx, 15 + k, y + 9 - k, 1, 1, shade(a, 0.45)); }
    }
    frame(ctx, 34, 4, w - 38, h - 8, shade(a, -0.1)); frame(ctx, 36, 6, w - 42, h - 12, shade(a, 0.4));
    emblem(ctx, 15, h - 16, 7, '#ffc93c', '#1b1838');
    text(ctx, 'TRAINER CARD', 44, 12, shade(a, -0.3));
    text(ctx, card.region ? card.region.toUpperCase() : 'CAPSULE LINK', w - 12, 12, shade(a, 0.1), { align: 'right', max: 90 });
    photo(ctx, 44, 30, card, { bg: shade(a, 0.7) });
    field(ctx, 'Name', t.name, 94, 28, { size: 20, vc: '#2b2440', max: 136 });
    field(ctx, 'Rank', card.title, 94, 58);
    field(ctx, 'Card no.', num, 160, 58);
    field(ctx, 'Since', fmtDate(card.issued), 94, 82);
    if (card.motto) text(ctx, card.motto, 44, 108, shade(a, -0.25), { max: 186 });
    barcode(ctx, 44, 124, 186, 12, num, '#2b2440');
  },
  transit(ctx, w, h, card, t, num) {
    const a = card.accent;
    px(ctx, 0, 0, w, h, '#ffffff');
    ctx.fillStyle = a;
    for (let y = 0; y < h; y++) { const x0 = Math.round(w * 0.55 + (h - y) ** 1.35 * 0.55); if (x0 < w) ctx.fillRect(x0, y, w - x0, 1); }
    ctx.fillStyle = shade(a, 0.35);
    for (let y = 0; y < h; y++) { const x0 = Math.round(w * 0.62 + (h - y) ** 1.35 * 0.55); if (x0 < w) ctx.fillRect(x0, y, 3, 1); }
    text(ctx, 'METRO TRAINER PASS', 14, 12, a);
    text(ctx, t.name, 14, 34, '#1b1838', { size: 20, max: 140 });
    text(ctx, card.title.toUpperCase(), 14, 58, '#7a77a0');
    text(ctx, num, 14, 80, '#1b1838', { size: 20 });
    field(ctx, 'Zone', card.region || '—', 14, 108, { max: 80 });
    field(ctx, 'Valid from', fmtDate(card.issued), 96, 108);
    photo(ctx, w - 58, 28, card, { bg: '#e9f1ff', border: '#ffffff' });
  },
  field(ctx, w, h, card, t, num) {
    const a = card.accent, khaki = '#d8c99a', ink = '#2f2a1a';
    px(ctx, 0, 0, w, h, khaki);
    for (let i = 0; i < 400; i++) px(ctx, (i * 73) % w, (i * 151) % h, 1, 1, shade(khaki, -0.08));
    for (let x = 6; x < w - 6; x += 5) { px(ctx, x, 5, 3, 1, shade(khaki, -0.4)); px(ctx, x, h - 6, 3, 1, shade(khaki, -0.4)); }
    for (let y = 6; y < h - 6; y += 5) { px(ctx, 5, y, 1, 3, shade(khaki, -0.4)); px(ctx, w - 6, y, 1, 3, shade(khaki, -0.4)); }
    px(ctx, 12, 12, w - 24, 16, shade(a, -0.15));
    text(ctx, 'FIELD LICENSE', w / 2, 15, '#ffffff', { align: 'center' });
    ctx.save(); ctx.translate(w / 2 - 20, 38);
    drawPortrait(ctx, 0, 0, card, '#efe6c8');
    ctx.restore();
    px(ctx, w / 2 - 25, 35, 10, 4, '#f6f1dc'); px(ctx, w / 2 + 15, 35, 10, 4, '#f6f1dc'); // tape
    stamp(ctx, w - 30, 74, 13, '#a83232', 'OK');
    text(ctx, t.name, w / 2, 94, ink, { size: 20, align: 'center', max: w - 20 });
    field(ctx, 'Class', card.title, 14, 120, { vc: ink, lc: shade(ink, 0.4) });
    field(ctx, 'Area', card.region || '—', 14, 144, { vc: ink, lc: shade(ink, 0.4), max: 120 });
    field(ctx, 'Issued', fmtDate(card.issued), 14, 168, { vc: ink, lc: shade(ink, 0.4) });
    field(ctx, 'License no.', num, 14, 192, { vc: ink, lc: shade(ink, 0.4) });
    barcode(ctx, 14, h - 24, w - 28, 10, num, ink);
  },
  neon(ctx, w, h, card, t, num) {
    const a = card.accent, glow = shade(a, 0.35);
    px(ctx, 0, 0, w, h, '#0b0a1a');
    ctx.save(); ctx.globalAlpha = 0.5;
    const hy = 104;
    for (let i = -12; i <= 12; i++) { ctx.strokeStyle = glow; ctx.beginPath(); ctx.moveTo(w / 2 + i * 6, hy); ctx.lineTo(w / 2 + i * 40, h); ctx.stroke(); }
    for (let k = 0; k < 6; k++) { const y = hy + (h - hy) * (k / 6) ** 1.8; px(ctx, 0, y, w, 1, glow); }
    ctx.restore();
    ctx.save(); ctx.globalAlpha = 0.35; frame(ctx, 2, 2, w - 4, h - 4, glow); ctx.restore();
    frame(ctx, 4, 4, w - 8, h - 8, glow);
    text(ctx, '> TRAINER.ID', 12, 10, '#7dffcf');
    text(ctx, `[${card.title.toUpperCase()}]`, w - 12, 10, glow, { align: 'right' });
    photo(ctx, 14, 26, card, { bg: '#1b1838', border: glow, scan: true });
    field(ctx, 'user', t.name, 64, 24, { lc: '#7a77a0', vc: '#ffffff', size: 20, max: 164 });
    field(ctx, 'id', num, 64, 54, { lc: '#7a77a0', vc: '#7dffcf' });
    field(ctx, 'node', card.region || 'unknown', 64, 76, { lc: '#7a77a0', vc: '#ffffff', max: 90 });
    field(ctx, 'since', fmtDate(card.issued), 160, 76, { lc: '#7a77a0', vc: '#ffffff' });
    if (card.motto) text(ctx, `// ${card.motto}`, 14, 84, '#c8c2ff', { max: 46 });
  },
};

/**
 * Draw a trainer's card. Returns a canvas at the card's pixel size (240×150 or 150×240).
 * trainer: { name, id, card }
 */
export function renderCard(trainer, { card: override } = {}) {
  const card = normalizeCard(override ?? trainer?.card);
  const design = CARD_DESIGNS.find((d) => d.id === card.design) ?? CARD_DESIGNS[0];
  const [w, h] = CARD_SIZE[design.orient];
  const c = document.createElement('canvas');
  c.width = w * RES; c.height = h * RES;
  c.dataset.w = w; c.dataset.h = h;
  const ctx = c.getContext('2d');
  ctx.scale(RES, RES);
  ctx.imageSmoothingEnabled = false;
  const t = { name: trainer?.name || 'Trainer', id: trainer?.id || '' };
  portraits = [];
  (DESIGNS[design.id] ?? DESIGNS.classic)(ctx, w, h, card, t, trainerNumber(t.id));
  const faces = portraits;
  portraits = null;
  if (card.pattern !== 'none') {
    const m = ctx.getTransform();
    cardPattern(ctx, w, h, card);
    for (const f of faces) { ctx.setTransform(f.m); drawPortrait(ctx, f.x, f.y, f.card, f.bg); }
    ctx.setTransform(m);
  }
  c.dataset.orient = design.orient;
  c.dataset.pending = card.avatar.sprite && !artImage(card.avatar.sprite) ? '1' : '';
  return c;
}

/**
 * A card element that tilts and catches the light under the pointer (or the phone's tilt).
 * opts.scale: CSS pixels per card pixel (default 2). opts.tilt: follow the pointer.
 */
export function idCardEl(trainer, { scale = 2, tilt = true, card } = {}) {
  const canvas = renderCard(trainer, { card });
  const wrap = document.createElement('div');
  const fin = normalizeCard(card ?? trainer?.card).finish;
  wrap.className = `idcard ${canvas.dataset.orient} finish-${fin}`;
  wrap.style.setProperty('--w', `${canvas.dataset.w * scale}px`);
  wrap.style.setProperty('--h', `${canvas.dataset.h * scale}px`);
  const inner = document.createElement('div');
  inner.className = 'idcard-inner';
  const holo = document.createElement('div');
  holo.className = 'idcard-holo';
  inner.append(canvas, holo);
  wrap.append(inner);
  if (tilt) {
    const set = (rx, ry, hx) => { inner.style.setProperty('--rx', `${rx}deg`); inner.style.setProperty('--ry', `${ry}deg`); inner.style.setProperty('--hx', `${hx}%`); };
    wrap.addEventListener('pointermove', (e) => {
      const r = wrap.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
      set(-y * 14, x * 18, 50 + x * 90);
    });
    wrap.addEventListener('pointerleave', () => set(0, 0, -60));
  }
  wrap.canvas = canvas;
  if (canvas.dataset.pending) {
    // a trainer picture is still loading: redraw once it arrives
    const off = onUiArt(() => {
      const next = renderCard(trainer, { card });
      if (next.dataset.pending) return;
      off();
      inner.replaceChild(next, wrap.canvas);
      wrap.canvas = next;
    });
  }
  return wrap;
}

/** A round portrait for menus and the sign-in screen. */
export function avatarEl(trainer, size = 40) {
  const card = normalizeCard(trainer?.card);
  const c = document.createElement('canvas');
  c.width = 40; c.height = 40;
  const ctx = c.getContext('2d');
  ctx.fillStyle = card.avatar.bg && card.avatar.bg !== 'auto' ? card.avatar.bg : shade(card.accent, 0.55);
  ctx.fillRect(0, 0, 40, 40);
  const draw = () => {
    if (card.avatar.sprite) {
      const img = artImage(card.avatar.sprite);
      if (!img) return false;
      // head and shoulders of a trainer picture
      const k = 40 / Math.min(img.width, img.height * 0.55);
      ctx.save(); ctx.imageSmoothingEnabled = img.width > 120;
      ctx.drawImage(img, (40 - img.width * k) / 2, 2, img.width * k, img.height * k);
      ctx.restore();
      return true;
    }
    drawAvatar(ctx, 0, 2, card.avatar);
    return true;
  };
  if (!draw()) { const off = onUiArt(() => { if (draw()) off(); }); }
  c.className = 'avatar';
  c.style.width = `${size}px`; c.style.height = `${size}px`;
  return c;
}
