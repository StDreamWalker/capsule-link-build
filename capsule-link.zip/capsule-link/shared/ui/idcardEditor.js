// Editor for the trainer ID card.
// Three parts: the look (a trainer picture you added, or "make your own"), the drawn portrait
// (face, hair, clothes, extras — several extras at once), and the card itself (design, two
// colours, pattern, finish, title, region, motto). Card colours never change the clothes.
import { h, mount } from './dom.js';
import { idCardEl, renderCard, drawAvatar } from './idcard.js';
import { sfx } from './audio.js';
import { listArt, artUrl } from './brandArt.js';
import {
  CARD_DESIGNS, CARD_TITLES, CARD_ACCENTS, CARD_PATTERNS, CARD_FINISHES, AVATAR_OPTIONS, MAX_ACCESSORIES, normalizeCard, randomAvatar,
  CARD_STAMPS, STAMP_INKS, MAX_STAMPS, reissueCard, cardNumber,
} from '../engine/trainerCard.js';

const NAMES = {
  hair: { short: 'Short', sidepart: 'Side part', long: 'Long', wavy: 'Wavy', ponytail: 'Ponytail', pigtails: 'Pigtails', spiky: 'Spiky', messy: 'Messy', bob: 'Bob', bun: 'Bun', twinbuns: 'Twin buns', braids: 'Braids', curly: 'Curly', afro: 'Afro', mohawk: 'Mohawk', undercut: 'Undercut', buzz: 'Buzz cut', bald: 'Bald' },
  eyes: { round: 'Round', wide: 'Wide', lashes: 'Lashes', sharp: 'Sharp', narrow: 'Narrow', happy: 'Happy', sleepy: 'Sleepy', wink: 'Wink' },
  brows: { soft: 'Soft', bold: 'Bold', angled: 'Angled', raised: 'Raised', thin: 'Thin', none: 'None' },
  mouth: { smile: 'Smile', grin: 'Grin', neutral: 'Neutral', open: 'Open', smirk: 'Smirk', pout: 'Pout' },
  facialHair: { none: 'None', stubble: 'Stubble', mustache: 'Mustache', beard: 'Beard', goatee: 'Goatee' },
  hat: { none: 'None', cap: 'Cap', backwards: 'Cap (backwards)', beanie: 'Beanie', bucket: 'Bucket hat', visor: 'Visor', sunhat: 'Sun hat', beret: 'Beret', bandana: 'Bandana' },
  outfitStyle: { tee: 'T-shirt', hoodie: 'Hoodie', jacket: 'Jacket', vest: 'Vest', uniform: 'Uniform', sweater: 'Sweater', coat: 'Coat', track: 'Track top', dress: 'Dress', overalls: 'Overalls' },
  accessories: { glasses: 'Glasses', roundglasses: 'Round glasses', shades: 'Sunglasses', goggles: 'Goggles', headband: 'Headband', headphones: 'Headphones', earrings: 'Earrings', necklace: 'Necklace', scarf: 'Scarf', backpack: 'Backpack', flower: 'Flower clip', freckles: 'Freckles', blush: 'Blush', bandaid: 'Plaster', beautymark: 'Beauty mark', eyepatch: 'Eyepatch', mask: 'Face mask' },
  pattern: { none: 'Plain', guilloche: 'Guilloche', dots: 'Dots', stripes: 'Stripes', waves: 'Waves', grid: 'Grid', stars: 'Stars', chevron: 'Chevron', topo: 'Contours', hex: 'Hexagons', plaid: 'Plaid', scales: 'Scales', circuit: 'Circuit', rays: 'Sunrays', diamonds: 'Diamonds', confetti: 'Confetti' },
  finish: { gloss: 'Gloss', matte: 'Matte', holo: 'Holographic', metal: 'Brushed metal', pearl: 'Pearl', glitter: 'Glitter', frosted: 'Frosted', carbon: 'Carbon fibre' },
  stamp: { region: 'Region', star: 'Star', date: 'Date', paw: 'Paw', ok: 'OK', wave: 'Wave', leaf: 'Leaf', flame: 'Flame', drop: 'Drop', bolt: 'Bolt', heart: 'Heart', crown: 'Crown' },
};
const pretty = (s) => String(s).replace(/^trainers\//, '').replace(/\.png$/i, '').replace(/[-_]+/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());

/**
 * cardEditor({ trainer, onChange(card, name), editName, scale, onAddSprites })
 * onAddSprites: optional async () => void, offered when there are no trainer pictures yet (PC).
 * Returns { el, value() } where value() is { name, card }.
 */
export function cardEditor({ trainer, onChange = () => {}, editName = false, scale = 2, onAddSprites = null, party = [] }) {
  let name = trainer?.name ?? 'Trainer';
  let card = normalizeCard(trainer?.card);
  let tab = 'look';
  let part = 'face';
  let side = 'front';
  let placing = null, ink = STAMP_INKS[0], stampLabel = '', idRegion = '', idNum = '';
  const id = trainer?.id ?? '';
  const preview = h('div', { class: 'preview' });
  const controls = h('div', { class: 'controls' });
  const el = h('div', { class: 'card-editor' }, preview, controls);

  const changed = (renderControls = true) => {
    const cardEl = idCardEl({ name, id, card }, { scale, party, showBack: side === 'back' });
    if (placing) {
      cardEl.classList.add('placing');
      cardEl.addEventListener('click', (e) => {
        if (!cardEl.showingBack || card.stamps.length >= MAX_STAMPS) return;
        const r = cardEl.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        setCard((c) => { c.stamps = [...c.stamps, { k: placing, label: placing === 'region' ? stampLabel.trim() : '', x, y, r: Math.round((Math.random() - 0.5) * 40), c: ink }]; });
      });
    }
    mount(preview, cardEl,
      h('div', { class: 'seg card-side' },
        h('button', { 'aria-pressed': side === 'front' ? 'true' : 'false', onclick: () => { side = 'front'; placing = null; changed(); } }, 'Front'),
        h('button', { 'aria-pressed': side === 'back' ? 'true' : 'false', onclick: () => { side = 'back'; changed(); } }, 'Back')),
      h('p', { class: 'micro dim' }, placing ? (card.stamps.length >= MAX_STAMPS ? `That’s ${MAX_STAMPS} stamps: take some off to add more.` : `Click the back of the card to stamp it (${NAMES.stamp[placing]}).`) : 'Drag the card sideways to spin it round.'));
    if (renderControls) drawControls();
    onChange(card, name);
  };
  const setCard = (fn) => { fn(card); card = normalizeCard(card); sfx('blip'); changed(); };
  const setAv = (k, v) => setCard((c) => { c.avatar[k] = v; });

  const colorRow = (list, cur, fn, label, { allowNone = false } = {}) => h('div', { class: 'swatches', role: 'radiogroup', 'aria-label': label },
    allowNone ? h('button', { class: 'swatch none', title: 'Automatic', 'aria-label': 'Automatic', 'aria-pressed': cur == null || cur === 'auto' ? 'true' : 'false', onclick: () => fn(null) }) : null,
    list.filter((c) => c !== 'auto').map((col) => h('button', { class: 'swatch', style: { background: col }, title: col, 'aria-label': col, 'aria-pressed': col === cur ? 'true' : 'false', onclick: () => fn(col) })),
    h('label', { class: 'swatch custom', title: 'Any colour' }, h('input', { type: 'color', value: /^#/.test(cur ?? '') ? cur : '#888888', 'aria-label': `${label}: any colour`, onchange: (e) => fn(e.target.value) })));
  const chips = (key, cur, fn) => h('div', { class: 'opt-chips', role: 'radiogroup' },
    AVATAR_OPTIONS[key].map((v) => h('button', { class: 'opt-chip', 'aria-pressed': v === cur ? 'true' : 'false', onclick: () => fn(v) }, NAMES[key]?.[v] ?? v)));
  const row = (label, ctl) => h('div', { class: 'opt-row' }, h('span', { class: 'dim' }, label), ctl);

  /** A tiny live portrait for a choice ("what would this hair look like on me?"). */
  function thumb(av, onclick, pressed, title) {
    const c = h('canvas', { width: 40, height: 48, class: 'look-thumb' });
    drawAvatar(c.getContext('2d'), 0, 0, normalizeCard({ avatar: av }).avatar, { bg: '#e9ecf5' });
    return h('button', { class: 'look-pick', 'aria-pressed': pressed ? 'true' : 'false', title, onclick }, c, h('span', { class: 'micro' }, title));
  }

  function lookTab() {
    const sprites = listArt('trainers/');
    return h('div', { class: 'col' },
      h('p', { class: 'dim micro' }, sprites.length
        ? 'Pick a trainer picture, or make your own at the end of the list.'
        : 'Trainer pictures you add show up here first (any PNG in textures/trainers). Or make your own.'),
      h('div', { class: 'look-grid' },
        sprites.map((key) => h('button', { class: 'look-pick sprite', 'aria-pressed': card.avatar.sprite === key ? 'true' : 'false', title: pretty(key), onclick: () => setAv('sprite', key) },
          h('img', { src: artUrl(key), alt: '', loading: 'lazy' }), h('span', { class: 'micro' }, pretty(key)))),
        thumb({ ...card.avatar, sprite: '' }, () => { setAv('sprite', ''); tab = 'portrait'; drawControls(); }, !card.avatar.sprite, 'Make your own')),
      !sprites.length && onAddSprites ? h('button', { class: 'btn small', onclick: async () => { await onAddSprites(); drawControls(); } }, 'Add trainer pictures…') : null);
  }

  function portraitTab() {
    const a = card.avatar;
    const parts = [['face', 'Face'], ['hair', 'Hair'], ['clothes', 'Clothes'], ['extras', 'Extras']];
    let body;
    if (part === 'face') {
      body = [
        row('Skin', colorRow(AVATAR_OPTIONS.skin, a.skin, (c) => setAv('skin', c), 'Skin tone')),
        row('Eyes', chips('eyes', a.eyes, (v) => setAv('eyes', v))),
        row('Eye colour', colorRow(AVATAR_OPTIONS.eyeColor, a.eyeColor, (c) => setAv('eyeColor', c), 'Eye colour')),
        row('Brows', chips('brows', a.brows, (v) => setAv('brows', v))),
        row('Mouth', chips('mouth', a.mouth, (v) => setAv('mouth', v))),
        row('Facial hair', chips('facialHair', a.facialHair, (v) => setAv('facialHair', v))),
      ];
    } else if (part === 'hair') {
      body = [
        h('div', { class: 'look-grid small' }, AVATAR_OPTIONS.hair.map((v) => thumb({ ...a, hair: v, hat: 'none', sprite: '' }, () => setAv('hair', v), a.hair === v, NAMES.hair[v]))),
        row('Hair colour', colorRow(AVATAR_OPTIONS.hairColor, a.hairColor, (c) => setAv('hairColor', c), 'Hair colour')),
        row('Hat', chips('hat', a.hat, (v) => setAv('hat', v))),
        row('Hat & clip colour', colorRow(AVATAR_OPTIONS.hatColor, a.hatColor, (c) => setAv('hatColor', c), 'Hat colour')),
      ];
    } else if (part === 'clothes') {
      body = [
        h('div', { class: 'look-grid small' }, AVATAR_OPTIONS.outfitStyle.map((v) => thumb({ ...a, outfitStyle: v, sprite: '' }, () => setAv('outfitStyle', v), a.outfitStyle === v, NAMES.outfitStyle[v]))),
        row('Main colour', colorRow(AVATAR_OPTIONS.outfit, a.outfit, (c) => setAv('outfit', c), 'Outfit colour')),
        row('Trim colour', colorRow(AVATAR_OPTIONS.outfit2, a.outfit2, (c) => setAv('outfit2', c), 'Trim colour')),
      ];
    } else {
      const on = new Set(a.accessories);
      body = [
        h('p', { class: 'micro dim' }, `Wear up to ${MAX_ACCESSORIES} at once (${on.size} on).`),
        h('div', { class: 'opt-chips' }, AVATAR_OPTIONS.accessories.map((v) => h('button', {
          class: 'opt-chip', 'aria-pressed': on.has(v) ? 'true' : 'false', disabled: !on.has(v) && on.size >= MAX_ACCESSORIES,
          onclick: () => setCard((c) => { const s = new Set(c.avatar.accessories); if (s.has(v)) s.delete(v); else s.add(v); c.avatar.accessories = [...s]; }),
        }, NAMES.accessories[v]))),
        row('Photo background', colorRow(AVATAR_OPTIONS.bg, a.bg, (c) => setAv('bg', c ?? 'auto'), 'Photo background', { allowNone: true })),
      ];
    }
    return h('div', { class: 'col' },
      a.sprite ? h('p', { class: 'note micro' }, 'You are using a trainer picture. Changes here apply when you switch to “Make your own”.') : null,
      h('div', { class: 'seg' }, parts.map(([k, l]) => h('button', { 'aria-pressed': part === k ? 'true' : 'false', onclick: () => { part = k; drawControls(); } }, l))),
      body,
      h('div', { class: 'row' }, h('button', { class: 'btn small', onclick: () => setCard((c) => { c.avatar = { ...randomAvatar(), bg: c.avatar.bg }; }) }, 'Shuffle')));
  }

  function cardTab() {
    const designs = h('div', { class: 'design-grid' }, CARD_DESIGNS.map((d) => {
      const t = renderCard({ name, id, card }, { card: { ...card, design: d.id } });
      return h('button', { class: 'design-pick', 'aria-pressed': d.id === card.design ? 'true' : 'false', title: d.name, onclick: () => setCard((c) => { c.design = d.id; }) },
        t, h('span', { class: 'micro' }, d.name));
    }));
    return h('div', { class: 'col' },
      designs,
      row('Card colour', colorRow(CARD_ACCENTS, card.accent, (c) => setCard((x) => { x.accent = c; }), 'Card colour')),
      row('Second colour', colorRow(CARD_ACCENTS, card.accent2, (c) => setCard((x) => { x.accent2 = c; }), 'Second colour', { allowNone: true })),
      row('Pattern', h('div', { class: 'opt-chips' }, CARD_PATTERNS.map((v) => h('button', { class: 'opt-chip', 'aria-pressed': card.pattern === v ? 'true' : 'false', onclick: () => setCard((c) => { c.pattern = v; }) }, NAMES.pattern[v])))),
      row('Finish', h('div', { class: 'opt-chips' }, CARD_FINISHES.map((v) => h('button', { class: 'opt-chip', 'aria-pressed': card.finish === v ? 'true' : 'false', onclick: () => setCard((c) => { c.finish = v; }) }, NAMES.finish[v])))),
      row('Base colour', colorRow(['#ffffff', '#f5f7ff', '#f4ecd6', '#fff6e6', '#e9f6ef', '#1b1838', '#0b0a1a', '#2a2848', '#d9b45a', '#c0c6d0'], card.base, (c) => setCard((x) => { x.base = c; }), 'Base colour', { allowNone: true })),
      row('Title', h('div', { class: 'row wrap' },
        h('select', { onchange: (e) => { const v = e.target.value; if (v === '__custom') { customTitle = true; drawControls(); } else { customTitle = false; setCard((c) => { c.title = v; }); } } },
          CARD_TITLES.map((t) => h('option', { value: t, selected: !customTitle && t === card.title }, t)), h('option', { value: '__custom', selected: customTitle || !CARD_TITLES.includes(card.title) }, 'Your own…')),
        customTitle || !CARD_TITLES.includes(card.title) ? h('input', { type: 'text', maxLength: 14, value: card.title, placeholder: 'Your title', oninput: (e) => { card.title = e.target.value || 'Trainer'; changed(false); } }) : null)),
      row('Home region', h('input', { type: 'text', maxLength: 18, value: card.region, placeholder: 'Anywhere', oninput: (e) => { card.region = e.target.value; changed(false); } })),
      row('Motto', h('input', { type: 'text', maxLength: 32, value: card.motto, placeholder: 'Optional', oninput: (e) => { card.motto = e.target.value; changed(false); } })),
      h('h3', { class: 'card-sub' }, 'The back'),
      row('Show', h('div', { class: 'opt-chips' }, [['title', 'Trainer class'], ['party', 'Your party']].map(([v, l]) => h('button', { class: 'opt-chip', 'aria-pressed': card.show === v ? 'true' : 'false', onclick: () => { side = 'back'; setCard((c) => { c.show = v; }); } }, l)))),
      row('Magnetic stripe', h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: card.magstripe, onchange: (e) => { side = 'back'; setCard((c) => { c.magstripe = e.target.checked; }); } }), 'Show it')),
      row('Signature', signaturePad()),
      row('Ink stamps', h('div', { class: 'col' },
        h('div', { class: 'opt-chips' }, CARD_STAMPS.map((k) => h('button', { class: 'opt-chip', 'aria-pressed': placing === k ? 'true' : 'false', onclick: () => { placing = placing === k ? null : k; side = 'back'; changed(); } }, NAMES.stamp[k]))),
        placing === 'region' ? h('label', { class: 'row' }, h('span', { class: 'micro dim' }, 'Region on the stamp'), h('input', { type: 'text', maxLength: 12, value: stampLabel, placeholder: card.region || 'Home region', oninput: (e) => { stampLabel = e.target.value; } })) : null,
        h('div', { class: 'row wrap' }, colorRow(STAMP_INKS, ink, (c) => { ink = c ?? STAMP_INKS[0]; drawControls(); }, 'Ink'),
          h('button', { class: 'btn small', disabled: !card.stamps.length, onclick: () => setCard((c) => { c.stamps = c.stamps.slice(0, -1); }) }, 'Undo stamp'),
          h('button', { class: 'btn small', disabled: !card.stamps.length, onclick: () => setCard((c) => { c.stamps = []; }) }, 'Clear stamps')))),
      row('Other trainer IDs', h('div', { class: 'col' },
        h('p', { class: 'micro dim' }, `This card: ${cardNumber(id, card)}. Add IDs from other regions or old saves; they go on the back.`),
        card.history.map((x, i) => h('div', { class: 'row' }, h('span', { class: 'grow mono-num' }, `${x.region ? `${x.region} · ` : ''}${x.num}`),
          h('button', { class: 'btn small ghost', 'aria-label': 'Remove', onclick: () => { side = 'back'; setCard((c) => { c.history = c.history.filter((_, k) => k !== i); }); } }, '✕'))),
        card.history.length < 8 ? h('div', { class: 'row wrap' },
          h('input', { type: 'text', maxLength: 12, placeholder: 'Region (e.g. Hoenn)', value: idRegion, oninput: (e) => { idRegion = e.target.value; } }),
          h('input', { type: 'text', maxLength: 14, placeholder: 'ID number', value: idNum, oninput: (e) => { idNum = e.target.value; } }),
          h('button', { class: 'btn small', onclick: () => { if (!idNum.trim()) return; const entry = { num: idNum.trim(), region: idRegion.trim(), issued: Date.now() }; idNum = ''; idRegion = ''; side = 'back'; setCard((c) => { c.history = [...c.history, entry]; }); } }, 'Add')) : null)));
  }
  let customTitle = false;

  /** Sign with the mouse or a finger: strokes are kept as points across the box (0..1000). */
  function signaturePad() {
    const W = 300, H = 72;
    const cv = h('canvas', { class: 'sig-pad', width: W, height: H });
    const x = cv.getContext('2d');
    let strokes = card.signature.map((st) => st.map((p) => [...p]));
    const paint = () => {
      x.fillStyle = '#ffffff'; x.fillRect(0, 0, W, H);
      x.strokeStyle = '#c8cde0'; x.beginPath(); x.moveTo(10, H - 14); x.lineTo(W - 10, H - 14); x.stroke();
      x.strokeStyle = '#1b2a6a'; x.lineWidth = 2; x.lineCap = 'round'; x.lineJoin = 'round';
      for (const st of strokes) { x.beginPath(); st.forEach(([sx, sy], i) => { const px = (sx / 1000) * W, py = (sy / 1000) * H; if (i) x.lineTo(px, py); else x.moveTo(px, py); }); x.stroke(); }
    };
    let cur = null;
    const at = (e) => { const r = cv.getBoundingClientRect(); return [Math.round(((e.clientX - r.left) / r.width) * 1000), Math.round(((e.clientY - r.top) / r.height) * 1000)]; };
    cv.addEventListener('pointerdown', (e) => { cv.setPointerCapture?.(e.pointerId); cur = [at(e)]; strokes.push(cur); paint(); });
    cv.addEventListener('pointermove', (e) => { if (!cur) return; const p = at(e), q = cur[cur.length - 1]; if (Math.hypot(p[0] - q[0], p[1] - q[1]) > 12) { cur.push(p); paint(); } });
    const end = () => { if (!cur) return; cur = null; side = side === 'back' || card.design !== 'booklet' ? 'back' : side; card.signature = strokes.filter((st) => st.length > 1); card = normalizeCard(card); changed(false); };
    cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
    paint();
    return h('div', { class: 'col' }, cv, h('div', { class: 'row' }, h('button', { class: 'btn small', onclick: () => { strokes = []; setCard((c) => { c.signature = []; }); } }, 'Clear'), h('span', { class: 'micro dim' }, 'Sign in the box.')));
  }

  function drawControls() {
    const tabs = [['look', 'Look'], ['portrait', 'Portrait'], ['card', 'Card']];
    mount(controls,
      editName ? h('label', { class: 'field' }, h('span', null, 'Name on the card'),
        h('input', { type: 'text', id: 'card-name', maxLength: 12, value: name, oninput: (e) => { name = e.target.value.trim() || 'Trainer'; changed(false); } })) : null,
      h('div', { class: 'tabs editor-tabs', role: 'tablist' }, tabs.map(([k, l]) => h('button', { role: 'tab', 'aria-selected': tab === k ? 'true' : 'false', onclick: () => { tab = k; drawControls(); } }, l))),
      tab === 'look' ? lookTab() : tab === 'portrait' ? portraitTab() : cardTab());
  }

  changed();
  return { el, value: () => ({ name, card: normalizeCard(card) }) };
}
