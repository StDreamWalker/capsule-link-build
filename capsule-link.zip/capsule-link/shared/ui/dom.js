// Minimal DOM helpers: h() element builder, toasts and dialogs.
import { sfx } from './audio.js';
import { brandRewriter } from '../engine/brand.js';

// every piece of interface text goes through the brand, so renaming the world takes one setting
let rewrite = (x) => x;
export function setBrand(brand) { rewrite = brandRewriter(brand); }
export const brandText = (s) => rewrite(s);
const TEXT_ATTRS = new Set(['title', 'aria-label', 'placeholder', 'alt']);

export function h(tag, props, ...children) {
  const el = document.createElement(tag);
  if (props) {
    for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style' && typeof v === 'object') {
        for (const [sk, sv] of Object.entries(v)) {
          if (sv == null) continue;
          if (sk.startsWith('--')) el.style.setProperty(sk, sv); else el.style[sk] = sv;
        }
      }
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'html') el.innerHTML = v;
      else if (k in el && k !== 'list' && typeof v !== 'string') el[k] = v;
      else el.setAttribute(k, v === true ? '' : TEXT_ATTRS.has(k) && typeof v === 'string' ? rewrite(v) : v);
    }
  }
  append(el, children);
  return el;
}

function append(el, children) {
  for (const c of children.flat(Infinity)) {
    if (c == null || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(rewrite(String(c))));
  }
}

export function clear(el) { el.replaceChildren(); return el; }
export function mount(el, ...children) {
  // build first, then swap in one step, so a blur handler that re-renders cannot interleave
  const frag = document.createDocumentFragment();
  append(frag, children);
  el.replaceChildren(frag);
  return el;
}

let toastHost = null;
export function toast(text, kind = '') {
  if (!toastHost) { toastHost = h('div', { class: 'toasts', role: 'status', 'aria-live': 'polite' }); document.body.append(toastHost); }
  const t = h('div', { class: `toast ${kind}` }, text);
  toastHost.append(t);
  if (kind === 'err') sfx('error');
  setTimeout(() => t.remove(), kind === 'err' ? 6000 : 3500);
}

/** Show a dialog. build(close) returns the body. Resolves with the value passed to close(). */
export function dialog(title, build, { wide = false } = {}) {
  return new Promise((resolve) => {
    let done = false;
    const close = (v) => { if (done) return; done = true; scrim.remove(); document.removeEventListener('keydown', onKey); resolve(v); };
    const onKey = (e) => { if (e.key === 'Escape') close(null); };
    const box = h('div', { class: 'panel dialog', role: 'dialog', 'aria-modal': 'true', 'aria-label': title, style: wide ? { width: 'min(860px, 100%)' } : null },
      h('div', { class: 'panel-title' }, h('h1', null, title)),
      build(close));
    const scrim = h('div', { class: 'scrim', onclick: (e) => { if (e.target === scrim) close(null); } }, box);
    document.body.append(scrim);
    document.addEventListener('keydown', onKey);
    setTimeout(() => box.querySelector('input, textarea, select, .btn.primary, .btn')?.focus(), 30);
  });
}

/** Put the cursor back at the end of a text box that was just redrawn (so typing doesn't come out backwards). */
export function refocus(input) {
  if (!input) return;
  input.focus();
  try { const n = input.value.length; input.setSelectionRange(n, n); } catch { /* not a text box */ }
}

export function confirmDialog(title, text, { ok = 'OK', cancel = 'Cancel', danger = false } = {}) {
  return dialog(title, (close) => h('div', null,
    h('p', null, text),
    h('div', { class: 'actions' },
      h('button', { class: 'btn', onclick: () => close(false) }, cancel),
      h('button', { class: `btn ${danger ? 'danger' : 'primary'}`, onclick: () => close(true) }, ok))));
}

export function promptDialog(title, label, value = '', { ok = 'Save', maxLength = 40 } = {}) {
  return dialog(title, (close) => {
    const input = h('input', { type: 'text', value, maxLength });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') close(input.value); });
    return h('div', null,
      h('label', { class: 'field' }, h('span', null, label), input),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', onclick: () => close(null) }, 'Cancel'),
        h('button', { class: 'btn primary', onclick: () => close(input.value) }, ok)));
  });
}

/** Choose one item from a list. items: [{ value, label, detail, el }]. Long lists get a search box. */
export function chooseDialog(title, items, { empty = 'Nothing to choose.' } = {}) {
  return dialog(title, (close) => {
    const rows = items.map((it) => ({ it, el: h('button', { class: 'btn choose-row', style: { justifyContent: 'flex-start', minHeight: '56px' }, onclick: () => close(it.value) },
      it.el ?? null, h('span', { class: 'grow col', style: { textAlign: 'left', gap: '2px' } }, h('span', null, it.label), it.detail ? h('span', { class: 'dim choose-detail' }, it.detail) : null)) }));
    // (pictures are only made for the rows you can see, so a list of a thousand stays quick)
    const search = items.length > 12 ? h('input', { type: 'search', placeholder: 'Type to search…', style: { width: '100%' }, oninput: (e) => {
      const q = e.target.value.trim().toLowerCase();
      for (const r of rows) r.el.hidden = !!q && !`${r.it.label} ${r.it.detail ?? ''}`.toLowerCase().includes(q);
    } }) : null;
    if (search) setTimeout(() => search.focus(), 30);
    return h('div', null,
      search,
      items.length ? h('div', { class: 'col', style: { maxHeight: '60vh', overflow: 'auto', padding: '4px' } }, rows.map((r) => r.el))
        : h('p', { class: 'dim' }, empty),
      h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(null) }, 'Cancel')));
  });
}

export function hearts(n, max = 5) {
  return h('span', { class: 'hearts', 'aria-label': `${n} of ${max} hearts` },
    Array.from({ length: max }, (_, i) => (i < n ? '♥' : h('span', { class: 'off' }, '♥'))));
}

export function bar(frac, cls = '') {
  const pct = Math.max(0, Math.min(1, frac)) * 100;
  return h('div', { class: `bar ${cls}`, role: 'meter', 'aria-valuenow': Math.round(pct), 'aria-valuemin': 0, 'aria-valuemax': 100 }, h('i', { style: { width: `${pct}%` } }));
}

export function hpBar(hp, max) {
  const f = max ? hp / max : 0;
  return bar(f, f < 0.2 ? 'hp-low' : f < 0.5 ? 'hp-mid' : '');
}

export function typeChip(idx, typeId) {
  const t = idx.types.get(typeId);
  const color = t?.color ?? '#999';
  const light = luminance(color) > 0.62;
  return h('span', { class: `chip ${light ? 'light' : ''}`, style: { background: color } }, t?.name ?? typeId);
}

export function luminance(hex) {
  const v = parseInt(String(hex).replace('#', ''), 16) || 0;
  const r = (v >> 16) & 255, g = (v >> 8) & 255, b = v & 255;
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
}

export function fmtNum(n) { return Number(n || 0).toLocaleString('en-US'); }

export function timeAgo(t) {
  if (!t) return 'never';
  const s = Math.round((Date.now() - t) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  return `${Math.round(s / 86400)} days ago`;
}

export function download(name, text, type = 'application/json') {
  const a = h('a', { href: URL.createObjectURL(new Blob([text], { type })), download: name });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

export function pickFile(accept) {
  return new Promise((resolve) => {
    const input = h('input', { type: 'file', accept, style: { display: 'none' } });
    input.addEventListener('change', () => { resolve(input.files[0] ?? null); input.remove(); });
    document.body.append(input);
    input.click();
  });
}
