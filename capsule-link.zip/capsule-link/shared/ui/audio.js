// Tiny chiptune synth for cries and interface sounds (Web Audio, no files).
import { CRY_TICK_MS, midiToHz } from '../engine/cry.js';

let ctx = null;
let master = null;
let volume = 0.6;
let enabled = true;

function ac() {
  // browsers refuse sound before the first click or key press
  if (!ctx && typeof navigator !== 'undefined' && navigator.userActivation && !navigator.userActivation.hasBeenActive) return null;
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = volume * 0.3;
    master.connect(ctx.destination);
  }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

/** The sound output for games that make their own sounds: { ctx, out } (null when sound is off or not allowed yet). */
export function audioOut() { if (!enabled) return null; const a = ac(); return a ? { ctx: a, out: master } : null; }

export function setSound(on, vol) {
  enabled = on;
  if (vol != null) volume = vol;
  if (master) master.gain.value = volume * 0.3;
}

function tone(t0, dur, freq, { wave = 'square', gain = 0.5, slide = 0, vibrato = 0 } = {}) {
  const a = ac();
  const osc = a.createOscillator();
  const g = a.createGain();
  osc.type = wave;
  osc.frequency.setValueAtTime(freq, t0);
  if (slide) osc.frequency.linearRampToValueAtTime(freq * slide, t0 + dur);
  if (vibrato) {
    const lfo = a.createOscillator(), lg = a.createGain();
    lfo.frequency.value = 9; lg.gain.value = freq * vibrato;
    lfo.connect(lg); lg.connect(osc.frequency);
    lfo.start(t0); lfo.stop(t0 + dur + 0.02);
  }
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(gain, t0 + 0.004);
  g.gain.setValueAtTime(gain, t0 + Math.max(0.005, dur - 0.02));
  g.gain.linearRampToValueAtTime(0, t0 + dur);
  osc.connect(g); g.connect(master);
  osc.start(t0); osc.stop(t0 + dur + 0.02);
}

function noise(t0, dur, gain = 0.3) {
  const a = ac();
  const len = Math.floor(a.sampleRate * dur);
  const buf = a.createBuffer(1, len, a.sampleRate);
  const d = buf.getChannelData(0);
  let v = 0;
  for (let i = 0; i < len; i++) { if (i % 8 === 0) v = Math.random() * 2 - 1; d[i] = v * (1 - i / len); }
  const src = a.createBufferSource(), g = a.createGain();
  g.gain.value = gain;
  src.buffer = buf; src.connect(g); g.connect(master);
  src.start(t0);
}

/** Play a cry ([{midi, ticks}]). `pitch` shifts by semitones (smaller creatures squeak higher). */
export function playCry(notes, { pitch = 0, speed = 1, contour = null, delay = 0 } = {}) {
  if (!enabled || !notes?.length || !ac()) return 0;
  let t = ctx.currentTime + 0.02 + delay;
  const tick = CRY_TICK_MS / 1000 / speed;
  const total = notes.reduce((a, n) => a + n.ticks, 0) || 1;
  let done = 0;
  for (const n of notes) {
    const dur = n.ticks * tick;
    // speech-like inflection: each note follows the contour at its point in the cry
    const bend = contour ? contourAt(contour, (done + n.ticks / 2) / total) : 0;
    if (n.midi) {
      tone(t, dur, midiToHz(n.midi + pitch + bend), { wave: 'square', gain: 0.45, vibrato: 0.012 });
      tone(t, dur, midiToHz(n.midi + pitch + bend) * 1.003, { wave: 'triangle', gain: 0.25 });
    }
    t += dur;
    done += n.ticks;
  }
  return (t - ctx.currentTime) * 1000;
}
/** Value of a pitch contour [[frac, semis], …] at a point 0..1 along the cry. */
function contourAt(points, f) {
  if (!points?.length) return 0;
  if (f <= points[0][0]) return points[0][1];
  for (let i = 1; i < points.length; i++) if (f <= points[i][0]) { const [a, va] = points[i - 1], [b, vb] = points[i]; return va + ((vb - va) * (f - a)) / Math.max(1e-6, b - a); }
  return points[points.length - 1][1];
}

const SFX = {
  blip: (t) => tone(t, 0.04, 880, { gain: 0.25 }),
  move: (t) => tone(t, 0.03, 660, { gain: 0.18 }),
  back: (t) => tone(t, 0.05, 440, { gain: 0.2, slide: 0.7 }),
  error: (t) => { tone(t, 0.08, 220, { gain: 0.3 }); tone(t + 0.09, 0.12, 180, { gain: 0.3 }); },
  hit: (t) => { noise(t, 0.12, 0.4); tone(t, 0.08, 160, { gain: 0.3, slide: 0.5 }); },
  crit: (t) => { noise(t, 0.2, 0.5); tone(t, 0.15, 220, { gain: 0.35, slide: 0.4 }); },
  miss: (t) => tone(t, 0.18, 600, { wave: 'triangle', gain: 0.3, slide: 0.4 }),
  faint: (t) => tone(t, 0.6, 520, { gain: 0.35, slide: 0.25 }),
  heal: (t) => [0, 1, 2, 3].forEach((i) => tone(t + i * 0.06, 0.06, 660 * Math.pow(1.26, i), { wave: 'triangle', gain: 0.3 })),
  level: (t) => [523, 659, 784, 1047].forEach((f, i) => tone(t + i * 0.09, i === 3 ? 0.25 : 0.09, f, { gain: 0.3 })),
  dock: (t) => { tone(t, 0.08, 988, { wave: 'triangle', gain: 0.35 }); tone(t + 0.09, 0.16, 1319, { wave: 'triangle', gain: 0.35 }); },
  undock: (t) => { tone(t, 0.08, 1319, { wave: 'triangle', gain: 0.3 }); tone(t + 0.09, 0.14, 988, { wave: 'triangle', gain: 0.3 }); },
  heart: (t) => { tone(t, 0.07, 1046, { wave: 'triangle', gain: 0.25 }); tone(t + 0.08, 0.1, 1318, { wave: 'triangle', gain: 0.25 }); },
  munch: (t) => { noise(t, 0.05, 0.2); noise(t + 0.12, 0.05, 0.2); noise(t + 0.24, 0.05, 0.2); },
  win: (t) => [523, 523, 523, 659, 784, 659, 784, 1047].forEach((f, i) => tone(t + i * 0.11, 0.1, f, { gain: 0.28 })),
  boot: (t) => [262, 392, 523, 784].forEach((f, i) => tone(t + i * 0.07, 0.07, f, { wave: 'triangle', gain: 0.3 })),
  key: (t) => { noise(t, 0.015, 0.08); tone(t, 0.012, 1800, { gain: 0.05 }); },
  logon: (t) => [392, 523, 659, 784, 1047].forEach((f, i) => tone(t + i * 0.08, i === 4 ? 0.3 : 0.08, f, { wave: 'square', gain: 0.18 })),
  logoff: (t) => [784, 659, 523, 392].forEach((f, i) => tone(t + i * 0.08, 0.09, f, { wave: 'square', gain: 0.16 })),
  access: (t) => { for (let i = 0; i < 8; i++) tone(t + i * 0.035, 0.03, 600 + i * 140, { wave: 'square', gain: 0.1 }); tone(t + 0.32, 0.25, 1568, { wave: 'triangle', gain: 0.22 }); },
  alert: (t) => [0, 0.16, 0.32].forEach((d) => { tone(t + d, 0.06, 1175, { wave: 'square', gain: 0.14 }); tone(t + d + 0.07, 0.06, 1568, { wave: 'square', gain: 0.14 }); }),
  // a creature turning into light and streaming somewhere else
  transfer: (t) => { tone(t, 0.55, 300, { wave: 'triangle', gain: 0.16, slide: 5 }); for (let i = 0; i < 10; i++) tone(t + 0.05 + i * 0.045, 0.03, 900 + i * 180, { wave: 'square', gain: 0.05 }); tone(t + 0.6, 0.25, 1760, { wave: 'triangle', gain: 0.18 }); },
  materialize: (t) => { for (let i = 0; i < 8; i++) tone(t + i * 0.04, 0.03, 2200 - i * 160, { wave: 'square', gain: 0.05 }); tone(t + 0.34, 0.22, 784, { wave: 'triangle', gain: 0.2 }); tone(t + 0.44, 0.3, 1175, { wave: 'triangle', gain: 0.16 }); },
  beacon: (t) => { tone(t, 0.9, 180, { wave: 'sawtooth', gain: 0.1, slide: 10 }); noise(t + 0.2, 0.6, 0.1); tone(t + 0.85, 0.4, 2093, { wave: 'triangle', gain: 0.15 }); },
  warp: (t) => { tone(t, 0.7, 110, { wave: 'sawtooth', gain: 0.12, slide: 8 }); noise(t + 0.4, 0.3, 0.12); tone(t + 0.62, 0.3, 1319, { wave: 'triangle', gain: 0.2 }); },
};

export function sfx(name) {
  if (!enabled || !SFX[name] || !ac()) return;
  SFX[name](ctx.currentTime + 0.01);
}

// ---------- creature cries with a voice and a mood ----------
// With cries downloaded (cries/<name>.mp3) the real sound plays; otherwise the synth cry. Either
// way each creature has its own slightly different voice, every call varies a little, and how
// they feel changes it: happy is brighter, unhappy is slower, lower and grainier, and now and
// then a content creature "talks" in chopped bits (Sp- Spe- Speech!).
import { spriteNames } from './art.js';
import { cryFor } from '../engine/cry.js';
import { mood as moodOf } from '../engine/care.js';

let cryFile = () => null;
/** fn(path) -> url or null, for paths like "cries/sproutle.mp3". */
export function setCryResolver(fn) { cryFile = fn || (() => null); }
const buffers = new Map();
const hashStr = (s) => { let h = 2166136261; for (const ch of String(s)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0; return h; };

function cryUrl(sp) {
  if (!sp) return null;
  for (const n of spriteNames(sp)) for (const ext of ['mp3', 'ogg', 'wav']) { const u = cryFile(`cries/${n}.${ext}`); if (u) return u; }
  return null;
}
function loadBuffer(url) {
  if (!buffers.has(url)) buffers.set(url, fetch(url).then((r) => r.arrayBuffer()).then((b) => new Promise((res, rej) => ctx.decodeAudioData(b, res, rej))).catch(() => null));
  return buffers.get(url);
}

const SAD = new Set(['hungry', 'bored', 'grubby', 'sleepy', 'sad', 'upset']);
/**
 * How this call should sound: { semis, speed, grain, chop: [[from, to], …] | null, contour: [[frac, semis], …] | null }.
 * About half of all calls are altered: chopped up in a random pattern (Sp- Spe- Speech!), or bent up and down
 * like speech. Happy calls mostly lean up; upset ones lean down and come out grainy. Everyone keeps their own
 * voice: c.cryPitch (semitones, set in the PC's debug editor) or a little offset worked out from their id.
 */
function voice(c, moodId, talk = false) {
  const personal = Number.isFinite(c?.cryPitch) ? c.cryPitch : c?.uid ? ((hashStr(c.uid) % 1000) / 1000 - 0.5) * 1.4 : 0;
  // everyone also has their own way of talking: some quick and clipped, some slow and sing-song
  const h = hashStr(`${c?.uid ?? ''}:talk`);
  const pace = 0.88 + ((h % 100) / 100) * 0.3, swing = 0.6 + (((h >>> 8) % 100) / 100) * 1.4;
  const sad = SAD.has(moodId), happy = moodId === 'happy' || moodId === 'delighted';
  const sleepy = moodId === 'sleepy', upset = moodId === 'upset';
  const lean = sad ? -1 : happy ? 1 : 0;
  const semis = personal + (Math.random() - 0.5) * 0.9 + (sad ? -2.5 - Math.random() * 1.5 : happy ? 0.8 + Math.random() * 1.2 : 0) + (upset ? 1.5 : 0);
  let speed = (sad ? 0.84 : happy ? 1.08 : 1) * (sleepy ? 0.8 : 1) * (upset ? 1.12 : 1) * (0.94 + Math.random() * 0.12);
  if (talk) return { semis, speed: speed * pace, grain: sad && !upset, chop: talkPattern(swing, lean, upset), contour: speechContour(lean, swing) };
  const r = Math.random();
  let chop = null, contour = null;
  if (sleepy && r < 0.4) { contour = [[0, 0.5], [0.4, 0], [1, -3 - Math.random() * 2]]; speed *= 0.85; } // a yawn
  else if (upset && r < 0.4) chop = [[0, 0.3, 1], [0, 0.3, 2], [0, 1, 0]]; // an indignant huff-huff-cry
  else if (r < 0.3) chop = chopPattern();
  else if (r < 0.55) contour = speechContour(lean, swing);
  else if (r < 0.65) contour = wobble(); // a warbly call
  else if (lean) contour = [[0, 0], [1, lean * (0.6 + Math.random() * 1.4)]]; // a little rise (happy) or droop (upset)
  return { semis, speed, grain: sad && !upset, chop, contour };
}
/** Talking: a run of short "syllables" cut from the cry, each pitched a little differently, with gaps. */
function talkPattern(swing, lean, upset) {
  const n = 2 + Math.floor(Math.random() * 4);
  const out = [];
  let pitch = 0;
  for (let i = 0; i < n; i++) {
    const len = 0.12 + Math.random() * (upset ? 0.15 : 0.3);
    const a = Math.random() * (1 - len);
    pitch += (Math.random() - 0.5) * 3 * swing + lean * 0.4;
    const last = i === n - 1;
    out.push([last ? Math.max(0, 1 - len * 1.6) : a, last ? 1 : a + len, Math.max(-5, Math.min(5, pitch + (last ? lean * 1.5 : 0))), 1 + (Math.random() - 0.5) * 0.35]);
  }
  return out;
}
/** A warble: the pitch wavers up and down a few times. */
function wobble() {
  const n = 4 + Math.floor(Math.random() * 5), depth = 0.5 + Math.random() * 1.2;
  return Array.from({ length: n + 1 }, (_, i) => [i / n, (i % 2 ? depth : -depth) * (1 - i / (n * 1.5))]);
}
/** Random ways to cut a cry up: stutters, a skip, a reprise of the end… always finishing on a longer piece. */
function chopPattern() {
  const pick = Math.random();
  const seg = (a, len) => [a, Math.min(1, a + len)];
  if (pick < 0.3) { const n = 1 + Math.floor(Math.random() * 3), len = 0.12 + Math.random() * 0.15; return [...Array.from({ length: n }, () => seg(0, len)), [0, 1]]; } // st-st-stutter
  if (pick < 0.5) return [seg(0, 0.35 + Math.random() * 0.2), seg(0.55 + Math.random() * 0.15, 1)]; // skip the middle
  if (pick < 0.7) return [[0, 1], seg(0.65 + Math.random() * 0.2, 1)]; // echo the end
  if (pick < 0.85) { const a = 0.3 + Math.random() * 0.3; return [seg(a, 0.25), seg(0, 0.3), [0, 1]]; } // jumbled
  if (pick < 0.9) { const out = []; let t = 0; while (t < 0.9 && out.length < 5) { const len = 0.1 + Math.random() * 0.25; out.push(seg(t, len)); t += len + Math.random() * 0.1; } return out; } // syllables with gaps
  if (pick < 0.95) { const len = 0.08 + Math.random() * 0.08; return [...Array.from({ length: 3 + Math.floor(Math.random() * 3) }, (_, i) => [0, len, i * 0.7, 1.3]), [0, 1]]; } // a rising trill
  return [seg(0.5, 0.5), seg(0, 0.5)]; // back to front
}
/** A speech-like rise and fall: a few "syllables" that wander, ending up (a question) or down (a sigh). */
function speechContour(lean, swing = 1) {
  const n = 3 + Math.floor(Math.random() * 3);
  const pts = [[0, 0]];
  let v = 0;
  for (let i = 1; i <= n; i++) {
    v += (Math.random() - 0.5) * 3 * swing + lean * 0.5;
    pts.push([i / (n + 1), Math.max(-4, Math.min(4, v))]);
  }
  pts.push([1, lean > 0 ? Math.abs(v) + 1.5 + Math.random() * 1.5 : lean < 0 ? -Math.abs(v) - 1.5 - Math.random() : v + (Math.random() - 0.5) * 3]);
  return pts;
}

function grainChain(a) {
  // a little bit-crush and muffling: sounds worn out
  const shaper = a.createWaveShaper(), curve = new Float32Array(256);
  for (let i = 0; i < 256; i++) { const x = i / 128 - 1; curve[i] = Math.round(x * 6) / 6; }
  shaper.curve = curve;
  const lp = a.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2200;
  shaper.connect(lp);
  return { input: shaper, output: lp };
}

/**
 * Play a creature's cry. sp: its species; c: the creature (for its own voice and mood), optional;
 * opts.mood overrides the mood. Returns about how long it lasts, in ms.
 */
export function creatureCry(sp, c = null, opts = {}) {
  if (!enabled || !sp || !ac()) return 0;
  const moodId = opts.mood ?? (c?.needs ? moodOf(c).id : 'content');
  const v = voice(c, moodId, !!opts.talk);
  // a fixed way of cutting the cry up (a "word" they've learned: the same pieces every time)
  if (opts.chop) { v.chop = opts.chop; v.contour = null; }
  // fainting: the cry let out in full, then dragged down low and long (a sad, exaggerated wail)
  if (opts.faint) { v.chop = [[0, 0.75, 2, 1.05], [0.35, 1, -6, 0.5]]; v.contour = null; }
  const url = cryUrl(sp);
  if (!url) {
    const notes = cryFor(sp);
    if (!v.chop) return playCry(notes, { pitch: v.semis, speed: v.speed, contour: v.contour });
    // chopped: the same pieces of the tune, one after another
    const total = notes.reduce((a, n) => a + n.ticks, 0);
    let delay = 0;
    for (const [a, b, ps = 0, sp = 1] of v.chop) {
      const part = []; let pos = 0;
      for (const n of notes) { const mid = (pos + n.ticks / 2) / total; if (mid >= a && mid <= b) part.push(n); pos += n.ticks; }
      if (!part.length) part.push(notes[Math.min(notes.length - 1, Math.floor(a * notes.length))]);
      const ms = playCry(part, { pitch: v.semis + ps, speed: v.speed * sp * (b - a < 0.5 ? 1.15 : 1), delay: delay / 1000, contour: opts.talk ? v.contour : null });
      delay = ms + 40 + Math.random() * 50;
    }
    return delay;
  }
  loadBuffer(url).then((buf) => {
    if (!buf) { playCry(cryFor(sp), { pitch: v.semis, speed: v.speed, contour: v.contour }); return; }
    const rate = Math.pow(2, v.semis / 12) * v.speed;
    const pieces = v.chop ?? [[0, 1]];
    let t = ctx.currentTime + 0.02;
    for (const [a, b, ps = 0, sp = 1] of pieces) {
      const src = ctx.createBufferSource(), g = ctx.createGain();
      src.buffer = buf; src.playbackRate.value = rate * Math.pow(2, ps / 12) * sp;
      g.gain.value = 2.2; // recorded cries are quieter than the synth
      if (v.grain) { const ch = grainChain(ctx); src.connect(ch.input); ch.output.connect(g); } else src.connect(g);
      g.connect(master);
      const len = (buf.duration * (b - a)) / (rate * Math.pow(2, ps / 12) * sp);
      // speech-like: bend the pitch along the way (detune is in cents)
      if (v.contour && src.detune) {
        src.detune.setValueAtTime(contourAt(v.contour, 0) * 100, t);
        for (const [f, semis] of v.contour) src.detune.linearRampToValueAtTime(semis * 100, t + f * len);
        // little dips between "syllables"
        for (let k = 1; k < v.contour.length - 1; k++) { const at = t + v.contour[k][0] * len; g.gain.setValueAtTime(2.2, at - 0.03); g.gain.linearRampToValueAtTime(1.1, at); g.gain.linearRampToValueAtTime(2.2, at + 0.03); }
      }
      src.start(t, buf.duration * a, buf.duration * (b - a));
      g.gain.setValueAtTime(2.2, t + Math.max(0.01, len - 0.02)); g.gain.linearRampToValueAtTime(0, t + len);
      t += len + (pieces.length > 1 ? 0.05 + Math.random() * 0.05 : 0);
    }
    if (v.grain) noise(ctx.currentTime + 0.02, Math.min(1.5, t - ctx.currentTime), 0.04);
  });
  return 900;
}
