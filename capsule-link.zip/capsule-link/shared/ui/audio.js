// Tiny chiptune synth for cries and interface sounds (Web Audio, no files).
import { CRY_TICK_MS, midiToHz } from '../engine/cry.js';

let ctx = null;
let master = null;
let volume = 0.6;
let enabled = true;

function ac() {
  // browsers refuse sound before the first click or key press
  if (!ctx && typeof navigator !== 'undefined' && navigator.userActivation && !navigator.userActivation.hasBeenActive) return null;
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = volume * 0.3;
    master.connect(ctx.destination);
  }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

export function setSound(on, vol) {
  enabled = on;
  if (vol != null) volume = vol;
  if (master) master.gain.value = volume * 0.3;
}

function tone(t0, dur, freq, { wave = 'square', gain = 0.5, slide = 0, vibrato = 0 } = {}) {
  const a = ac();
  const osc = a.createOscillator();
  const g = a.createGain();
  osc.type = wave;
  osc.frequency.setValueAtTime(freq, t0);
  if (slide) osc.frequency.linearRampToValueAtTime(freq * slide, t0 + dur);
  if (vibrato) {
    const lfo = a.createOscillator(), lg = a.createGain();
    lfo.frequency.value = 9; lg.gain.value = freq * vibrato;
    lfo.connect(lg); lg.connect(osc.frequency);
    lfo.start(t0); lfo.stop(t0 + dur + 0.02);
  }
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(gain, t0 + 0.004);
  g.gain.setValueAtTime(gain, t0 + Math.max(0.005, dur - 0.02));
  g.gain.linearRampToValueAtTime(0, t0 + dur);
  osc.connect(g); g.connect(master);
  osc.start(t0); osc.stop(t0 + dur + 0.02);
}

function noise(t0, dur, gain = 0.3) {
  const a = ac();
  const len = Math.floor(a.sampleRate * dur);
  const buf = a.createBuffer(1, len, a.sampleRate);
  const d = buf.getChannelData(0);
  let v = 0;
  for (let i = 0; i < len; i++) { if (i % 8 === 0) v = Math.random() * 2 - 1; d[i] = v * (1 - i / len); }
  const src = a.createBufferSource(), g = a.createGain();
  g.gain.value = gain;
  src.buffer = buf; src.connect(g); g.connect(master);
  src.start(t0);
}

/** Play a cry ([{midi, ticks}]). `pitch` shifts by semitones (smaller creatures squeak higher). */
export function playCry(notes, { pitch = 0, speed = 1 } = {}) {
  if (!enabled || !notes?.length || !ac()) return 0;
  let t = ctx.currentTime + 0.02;
  const tick = CRY_TICK_MS / 1000 / speed;
  for (const n of notes) {
    const dur = n.ticks * tick;
    if (n.midi) {
      tone(t, dur, midiToHz(n.midi + pitch), { wave: 'square', gain: 0.45, vibrato: 0.012 });
      tone(t, dur, midiToHz(n.midi + pitch) * 1.003, { wave: 'triangle', gain: 0.25 });
    }
    t += dur;
  }
  return (t - ctx.currentTime) * 1000;
}

const SFX = {
  blip: (t) => tone(t, 0.04, 880, { gain: 0.25 }),
  move: (t) => tone(t, 0.03, 660, { gain: 0.18 }),
  back: (t) => tone(t, 0.05, 440, { gain: 0.2, slide: 0.7 }),
  error: (t) => { tone(t, 0.08, 220, { gain: 0.3 }); tone(t + 0.09, 0.12, 180, { gain: 0.3 }); },
  hit: (t) => { noise(t, 0.12, 0.4); tone(t, 0.08, 160, { gain: 0.3, slide: 0.5 }); },
  crit: (t) => { noise(t, 0.2, 0.5); tone(t, 0.15, 220, { gain: 0.35, slide: 0.4 }); },
  miss: (t) => tone(t, 0.18, 600, { wave: 'triangle', gain: 0.3, slide: 0.4 }),
  faint: (t) => tone(t, 0.6, 520, { gain: 0.35, slide: 0.25 }),
  heal: (t) => [0, 1, 2, 3].forEach((i) => tone(t + i * 0.06, 0.06, 660 * Math.pow(1.26, i), { wave: 'triangle', gain: 0.3 })),
  level: (t) => [523, 659, 784, 1047].forEach((f, i) => tone(t + i * 0.09, i === 3 ? 0.25 : 0.09, f, { gain: 0.3 })),
  dock: (t) => { tone(t, 0.08, 988, { wave: 'triangle', gain: 0.35 }); tone(t + 0.09, 0.16, 1319, { wave: 'triangle', gain: 0.35 }); },
  undock: (t) => { tone(t, 0.08, 1319, { wave: 'triangle', gain: 0.3 }); tone(t + 0.09, 0.14, 988, { wave: 'triangle', gain: 0.3 }); },
  heart: (t) => { tone(t, 0.07, 1046, { wave: 'triangle', gain: 0.25 }); tone(t + 0.08, 0.1, 1318, { wave: 'triangle', gain: 0.25 }); },
  munch: (t) => { noise(t, 0.05, 0.2); noise(t + 0.12, 0.05, 0.2); noise(t + 0.24, 0.05, 0.2); },
  win: (t) => [523, 523, 523, 659, 784, 659, 784, 1047].forEach((f, i) => tone(t + i * 0.11, 0.1, f, { gain: 0.28 })),
  boot: (t) => [262, 392, 523, 784].forEach((f, i) => tone(t + i * 0.07, 0.07, f, { wave: 'triangle', gain: 0.3 })),
  key: (t) => { noise(t, 0.015, 0.08); tone(t, 0.012, 1800, { gain: 0.05 }); },
  logon: (t) => [392, 523, 659, 784, 1047].forEach((f, i) => tone(t + i * 0.08, i === 4 ? 0.3 : 0.08, f, { wave: 'square', gain: 0.18 })),
  logoff: (t) => [784, 659, 523, 392].forEach((f, i) => tone(t + i * 0.08, 0.09, f, { wave: 'square', gain: 0.16 })),
  access: (t) => { for (let i = 0; i < 8; i++) tone(t + i * 0.035, 0.03, 600 + i * 140, { wave: 'square', gain: 0.1 }); tone(t + 0.32, 0.25, 1568, { wave: 'triangle', gain: 0.22 }); },
  alert: (t) => [0, 0.16, 0.32].forEach((d) => { tone(t + d, 0.06, 1175, { wave: 'square', gain: 0.14 }); tone(t + d + 0.07, 0.06, 1568, { wave: 'square', gain: 0.14 }); }),
  // a creature turning into light and streaming somewhere else
  transfer: (t) => { tone(t, 0.55, 300, { wave: 'triangle', gain: 0.16, slide: 5 }); for (let i = 0; i < 10; i++) tone(t + 0.05 + i * 0.045, 0.03, 900 + i * 180, { wave: 'square', gain: 0.05 }); tone(t + 0.6, 0.25, 1760, { wave: 'triangle', gain: 0.18 }); },
  materialize: (t) => { for (let i = 0; i < 8; i++) tone(t + i * 0.04, 0.03, 2200 - i * 160, { wave: 'square', gain: 0.05 }); tone(t + 0.34, 0.22, 784, { wave: 'triangle', gain: 0.2 }); tone(t + 0.44, 0.3, 1175, { wave: 'triangle', gain: 0.16 }); },
  beacon: (t) => { tone(t, 0.9, 180, { wave: 'sawtooth', gain: 0.1, slide: 10 }); noise(t + 0.2, 0.6, 0.1); tone(t + 0.85, 0.4, 2093, { wave: 'triangle', gain: 0.15 }); },
  warp: (t) => { tone(t, 0.7, 110, { wave: 'sawtooth', gain: 0.12, slide: 8 }); noise(t + 0.4, 0.3, 0.12); tone(t + 0.62, 0.3, 1319, { wave: 'triangle', gain: 0.2 }); },
};

export function sfx(name) {
  if (!enabled || !SFX[name] || !ac()) return;
  SFX[name](ctx.currentTime + 0.01);
}
