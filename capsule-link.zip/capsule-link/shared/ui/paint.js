// High-detail pixel painting for the R.A.N.C.H.: foliage, rocks, buildings and scenery drawn
// dab by dab (no anti-aliasing), lit from the upper left, at several times the old resolution.
// Think painted pixel-art backdrops: many small strokes, colour ramps, rim light, soft shadow.
import { hexRgb, shadeHex, rngFrom } from './habitat.js';

const LIGHT = { x: -0.62, y: -0.78 };

export function mk(w, h) {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h));
  const x = c.getContext('2d');
  x.imageSmoothingEnabled = false;
  return { c, x };
}
const rect = (x, px, py, w, h, col) => { x.fillStyle = col; x.fillRect(Math.round(px), Math.round(py), Math.max(1, Math.round(w)), Math.max(1, Math.round(h))); };
/** A filled pixel disc. */
export function dab(x, cx, cy, r, col) {
  x.fillStyle = col;
  const ir = Math.max(0.5, r);
  for (let yy = -Math.ceil(ir); yy <= Math.ceil(ir); yy++) {
    const half = Math.floor(Math.sqrt(Math.max(0, ir * ir - yy * yy)));
    x.fillRect(Math.round(cx - half), Math.round(cy + yy), half * 2 + 1, 1);
  }
}
/** A pixel line of a given width. */
export function line(x, x0, y0, x1, y1, col, w = 1) {
  const n = Math.max(1, Math.ceil(Math.hypot(x1 - x0, y1 - y0)));
  x.fillStyle = col;
  for (let i = 0; i <= n; i++) { const t = i / n; x.fillRect(Math.round(x0 + (x1 - x0) * t - w / 2), Math.round(y0 + (y1 - y0) * t - w / 2), Math.max(1, Math.round(w)), Math.max(1, Math.round(w))); }
}
/** dark→light ramp around a base colour */
export function ramp(base, n = 6, span = 0.5) {
  const out = [];
  for (let i = 0; i < n; i++) { const t = i / (n - 1); out.push(shadeHex(base, t < 0.5 ? -span * (1 - t * 2) * 0.9 : span * (t - 0.5) * 1.4)); }
  return out;
}
/**
 * Fill an ellipse with many lit dabs: dark inside and lower right, light at the upper left edge.
 */
export function clump(x, r, cx, cy, rx, ry, pal, { n = 0, size = [1.5, 3.5], light = 0 } = {}) {
  const count = n || Math.round(rx * ry * 0.55);
  const pts = [];
  for (let i = 0; i < count; i++) {
    const a = r() * Math.PI * 2, d = Math.sqrt(r());
    const nx = Math.cos(a) * d, ny = Math.sin(a) * d;
    const lit = 0.5 - 0.55 * (nx * LIGHT.x + ny * LIGHT.y) + (d - 0.6) * 0.35 + (r() - 0.5) * 0.35 + light;
    pts.push({ px: cx + nx * rx, py: cy + ny * ry, lit, s: size[0] + r() * (size[1] - size[0]) });
  }
  pts.sort((a, b) => a.lit - b.lit);
  for (const p of pts) dab(x, p.px, p.py, p.s, pal[Math.max(0, Math.min(pal.length - 1, Math.floor(p.lit * pal.length)))]);
}
function shadowEllipse(x, cx, cy, rx, ry, a = 0.25) { x.save(); x.globalAlpha = a; dab(x, cx, cy, 1, '#000'); for (let yy = -ry; yy <= ry; yy++) { const half = Math.floor(rx * Math.sqrt(1 - (yy * yy) / (ry * ry))); x.fillStyle = '#10142a'; x.fillRect(Math.round(cx - half), Math.round(cy + yy), half * 2 + 1, 1); } x.restore(); }

// ---------- foliage ----------
export function tree(seed, leaf = '#4f9a3f', { fruit = null, bark = '#6b4a2e', w = 150, h = 200 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  const cx = w / 2, base = h - 4;
  // trunk with bark strokes and root flare
  const tw = w * 0.1;
  const bp = ramp(bark, 5, 0.5);
  for (let y = base - h * 0.45; y < base; y++) {
    const t = (y - (base - h * 0.45)) / (h * 0.45);
    const half = tw / 2 + t * t * tw * 0.9;
    for (let xx = -half; xx <= half; xx++) {
      const lit = 0.55 - (xx / half) * 0.45 + (r() - 0.5) * 0.25;
      rect(x, cx + xx, y, 1, 1, bp[Math.max(0, Math.min(4, Math.floor(lit * 5)))]);
    }
    if (r() < 0.25) rect(x, cx - half * 0.6 + r() * half * 1.2, y, 1, 3 + r() * 5, bp[0]);
  }
  // branches
  for (let i = 0; i < 4; i++) { const sx = cx + (r() - 0.5) * tw, sy = base - h * (0.42 + r() * 0.08); line(x, sx, sy, sx + (r() - 0.5) * w * 0.5, sy - h * (0.12 + r() * 0.12), bp[1], 2); }
  // canopy: several clumps, back ones darker
  const pal = ramp(leaf, 7, 0.55);
  const top = h * 0.08, ch = h * 0.52;
  const clumps = [];
  for (let i = 0; i < 6; i++) clumps.push({ x: cx + (r() - 0.5) * w * 0.5, y: top + ch * (0.35 + r() * 0.45), rx: w * (0.18 + r() * 0.1), ry: h * (0.13 + r() * 0.06) });
  clumps.push({ x: cx, y: top + ch * 0.45, rx: w * 0.36, ry: h * 0.26 });
  clumps.sort((a, b) => a.y - b.y);
  shadowEllipse(x, cx + 6, top + ch * 0.62, w * 0.36, h * 0.2, 0.18);
  for (const k of clumps) clump(x, r, k.x, k.y, k.rx, k.ry, pal, { size: [1.6, 3.6] });
  // highlights and fruit
  for (let i = 0; i < 40; i++) { const a = r() * Math.PI * 2, d = 0.6 + r() * 0.35; dab(x, cx - w * 0.12 + Math.cos(a) * w * 0.3 * d, top + ch * 0.32 + Math.sin(a) * h * 0.2 * d, 1, pal[6]); }
  if (fruit) for (let i = 0; i < 12; i++) { const fx = cx + (r() - 0.5) * w * 0.6, fy = top + ch * (0.35 + r() * 0.55); dab(x, fx, fy, 2.2, fruit); rect(x, fx - 1, fy - 1, 1, 1, '#ffffff'); }
  return c;
}

export function pine(seed, needle = '#2f6b48', { snow = false, w = 110, h = 210 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  const cx = w / 2, base = h - 3;
  const bp = ramp('#5a3a22', 4, 0.45);
  for (let y = base - 30; y < base; y++) for (let xx = -4; xx <= 4; xx++) rect(x, cx + xx, y, 1, 1, bp[xx < -1 ? 2 : xx > 2 ? 0 : 1]);
  const pal = ramp(needle, 6, 0.55);
  const tiers = 6;
  for (let t = 0; t < tiers; t++) {
    const ty = h * 0.04 + t * (h * 0.13), th = h * 0.2, tw = (w * 0.16) + t * (w * 0.065);
    for (let i = 0; i < 260 + t * 60; i++) {
      const v = r(), yy = ty + v * th, half = tw * (0.25 + v * 0.75);
      const u = (r() * 2 - 1);
      const px = cx + u * half;
      const lit = 0.55 - u * 0.35 - v * 0.25 + (r() - 0.5) * 0.3;
      const col = pal[Math.max(0, Math.min(5, Math.floor(lit * 6)))];
      line(x, px, yy, px + (u < 0 ? -2 : 2), yy + 2 + r() * 2, col, 1);
    }
    if (snow) for (let i = 0; i < 70; i++) { const u = r() * 2 - 1; const px = cx + u * tw * 0.9; dab(x, px, ty + th * (0.55 + r() * 0.2) - Math.abs(u) * -6, 1.5 + r(), r() < 0.5 ? '#ffffff' : '#dbe8fa'); }
  }
  return c;
}

export function palm(seed, { w = 150, h = 210 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  const base = h - 3, bend = (r() - 0.5) * 30;
  const pts = [];
  for (let i = 0; i <= 40; i++) { const t = i / 40; pts.push({ x: w / 2 + bend * t * t, y: base - t * h * 0.7 }); }
  pts.forEach((p, i) => { const ww = 9 - i * 0.12; for (let xx = -ww / 2; xx <= ww / 2; xx++) rect(x, p.x + xx, p.y, 1, 1, i % 3 === 0 ? '#7a5634' : xx < 0 ? '#c4935a' : '#9d7244'); });
  const top = pts[pts.length - 1];
  const pal = ramp('#3f9a4a', 6, 0.5);
  for (let f = 0; f < 9; f++) {
    const ang = -Math.PI + (f / 8) * Math.PI + (r() - 0.5) * 0.3, len = w * (0.32 + r() * 0.12);
    for (let i = 0; i < len; i++) {
      const t = i / len;
      const fx = top.x + Math.cos(ang) * i, fy = top.y + Math.sin(ang) * i * 0.55 + t * t * 26;
      rect(x, fx, fy, 2, 2, pal[2]);
      for (const side of [-1, 1]) {
        const ll = (1 - t) * 10 + 3;
        line(x, fx, fy, fx + Math.cos(ang + side * 1.2) * ll * 0.5, fy + ll * 0.7, pal[Math.min(5, Math.max(0, Math.floor((1 - t) * 3 + (side < 0 ? 2 : 0) + r())))], 1);
      }
    }
  }
  for (let i = 0; i < 4; i++) dab(x, top.x - 6 + i * 4, top.y + 6, 3, i % 2 ? '#6b4a2e' : '#8a6234');
  return c;
}

export function bush(seed, leaf = '#4f9a3f', { w = 90, h = 60, flowers = null, berries = null, count = 0 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  shadowEllipse(x, w / 2 + 3, h - 6, w * 0.42, 5, 0.25);
  const pal = ramp(leaf, 6, 0.55);
  clump(x, r, w * 0.32, h * 0.6, w * 0.25, h * 0.32, pal);
  clump(x, r, w * 0.66, h * 0.62, w * 0.26, h * 0.3, pal);
  clump(x, r, w * 0.5, h * 0.45, w * 0.3, h * 0.36, pal);
  if (flowers) for (let i = 0; i < 14; i++) { const fx = w * (0.2 + r() * 0.6), fy = h * (0.25 + r() * 0.5); for (const [dx, dy] of [[0, -1.5], [1.5, 0], [0, 1.5], [-1.5, 0]]) dab(x, fx + dx, fy + dy, 1, flowers); rect(x, fx, fy, 1, 1, '#ffe27a'); }
  const nb = berries ? (count || 12) : 0;
  for (let i = 0; i < nb; i++) { const bx = w * (0.18 + r() * 0.64), by = h * (0.25 + r() * 0.55); dab(x, bx, by, 2.4, shadeHex(berries, -0.25)); dab(x, bx - 0.5, by - 0.5, 1.6, berries); rect(x, bx - 1, by - 1, 1, 1, '#ffffff'); }
  return c;
}

export function grassTuft(seed, base = '#5cbf4a', { w = 40, h = 26 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  const pal = ramp(base, 5, 0.5);
  for (let i = 0; i < 26; i++) {
    const bx = w * 0.15 + r() * w * 0.7, bh = h * (0.4 + r() * 0.6), lean = (r() - 0.5) * 10;
    for (let y = 0; y < bh; y++) { const t = y / bh; rect(x, bx + lean * t * t, h - 1 - y, 1, 1, pal[Math.min(4, Math.floor(t * 4.5))]); }
  }
  return c;
}

export function flowers(seed, colors = ['#ffffff', '#ffd45e', '#ff8fb6'], { w = 46, h = 30 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  for (let i = 0; i < 7; i++) {
    const fx = 5 + r() * (w - 10), fh = h * (0.35 + r() * 0.55), col = colors[Math.floor(r() * colors.length)];
    line(x, fx, h - 1, fx + (r() - 0.5) * 3, h - fh, '#3f8a3a', 1);
    rect(x, fx + 1, h - fh * 0.5, 3, 1, '#4fae40');
    for (const [dx, dy] of [[0, -2], [2, 0], [0, 2], [-2, 0]]) dab(x, fx + dx, h - fh + dy, 1.4, col);
    dab(x, fx, h - fh, 1, '#ffcf3a');
  }
  return c;
}

// ---------- stone and minerals ----------
export function rock(seed, stone = '#8a8296', { w = 90, h = 60, moss = null, snow = false } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  shadowEllipse(x, w / 2 + 4, h - 5, w * 0.45, 5, 0.28);
  const pal = ramp(stone, 7, 0.55);
  // an irregular dome made of facets
  const cx = w / 2, cy = h * 0.95, rx = w * 0.46, ry = h * 0.85;
  const facets = [];
  for (let i = 0; i < 9; i++) facets.push({ a: Math.PI + (i / 8) * Math.PI + (r() - 0.5) * 0.25, k: 0.75 + r() * 0.25 });
  for (let yy = -ry; yy <= 0; yy++) {
    for (let xx = -rx; xx <= rx; xx++) {
      const nx = xx / rx, ny = yy / ry;
      const ang = Math.atan2(ny, nx);
      const f = facets.reduce((b, fc) => (Math.abs(fc.a - ang) < Math.abs(b.a - ang) ? fc : b), facets[0]);
      if (nx * nx + ny * ny > f.k * f.k * (1 - (yy / ry) * 0.05)) continue;
      const fl = 0.55 - 0.6 * (Math.cos(f.a) * LIGHT.x + Math.sin(f.a) * LIGHT.y) * 0.8 - (1 + ny) * 0.15 + (hashN(xx, yy) - 0.5) * 0.12;
      rect(x, cx + xx, cy + yy, 1, 1, pal[Math.max(0, Math.min(6, Math.floor(fl * 7)))]);
    }
  }
  for (let i = 0; i < 4; i++) { const sx = cx + (r() - 0.5) * rx, sy = cy - ry * (0.2 + r() * 0.5); line(x, sx, sy, sx + (r() - 0.5) * 14, sy + 6 + r() * 8, pal[0], 1); }
  if (moss) clump(x, r, cx - rx * 0.2, cy - ry * 0.78, rx * 0.5, ry * 0.15, ramp(moss, 5, 0.4), { size: [1, 2] });
  if (snow) for (let i = 0; i < 120; i++) { const u = r() * 2 - 1; dab(x, cx + u * rx * 0.8, cy - ry * (0.78 - Math.abs(u) * 0.35) + r() * 4, 1.4, r() < 0.6 ? '#ffffff' : '#dce8f8'); }
  return c;
}
function hashN(a, b) { let h = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }

export function crystal(seed, hue = '#c89bff', { w = 70, h = 110, glow = true } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  if (glow) { x.save(); x.globalAlpha = 0.18; dab(x, w / 2, h * 0.6, w * 0.45, hue); x.restore(); }
  const shards = [[w * 0.5, h * 0.98, h * 0.9, w * 0.16], [w * 0.28, h * 0.98, h * 0.55, w * 0.11], [w * 0.72, h * 0.98, h * 0.65, w * 0.12], [w * 0.15, h * 0.98, h * 0.3, w * 0.08]];
  for (const [bx, by, sh, sw] of shards.sort(() => r() - 0.5)) {
    const tip = by - sh, lean = (r() - 0.5) * sw;
    for (let y = tip; y < by; y++) {
      const t = (y - tip) / sh, half = Math.min(sw, t * sw * 3);
      for (let xx = -half; xx <= half; xx++) {
        const side = xx < 0 ? 0.75 : 0.35;
        const col = shadeHex(hue, side - 0.4 + t * 0.15 + (Math.abs(xx) < 1 ? 0.35 : 0));
        rect(x, bx + xx + lean * (1 - t), y, 1, 1, col);
      }
    }
    line(x, bx + lean, tip + 2, bx, by - 2, '#ffffff', 1);
  }
  return c;
}

export function stalagmite(seed, stone = '#5a5470', { w = 50, h = 110 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  const pal = ramp(stone, 6, 0.5);
  for (let y = 0; y < h; y++) {
    const t = y / h, half = 1 + t * t * w * 0.45 + Math.sin(y * 0.4) * 1.2;
    for (let xx = -half; xx <= half; xx++) rect(x, w / 2 + xx, y, 1, 1, pal[Math.max(0, Math.min(5, Math.floor((0.6 - (xx / half) * 0.4 + ((y % 9) < 1 ? -0.25 : 0)) * 6)))]);
  }
  return c;
}

export function cactus(seed, { w = 70, h = 120 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  const pal = ramp('#3f9a4a', 6, 0.5);
  const column = (cx, top, bottom, rw) => {
    for (let y = top; y < bottom; y++) for (let xx = -rw; xx <= rw; xx++) {
      const round = y < top + rw ? Math.sqrt(Math.max(0, rw * rw - (top + rw - y) ** 2)) : rw;
      if (Math.abs(xx) > round) continue;
      const lit = 0.6 - (xx / rw) * 0.45 + ((xx + 100) % 5 === 0 ? -0.25 : 0);
      rect(x, cx + xx, y, 1, 1, pal[Math.max(0, Math.min(5, Math.floor(lit * 6)))]);
    }
    for (let i = 0; i < (bottom - top) / 4; i++) rect(x, cx + (r() - 0.5) * rw * 2, top + r() * (bottom - top), 1, 1, '#f4f0d0');
  };
  column(w / 2, 6, h - 2, 10);
  column(w * 0.2, h * 0.32, h * 0.62, 6); rect(x, w * 0.2, h * 0.58, w * 0.3, 8, pal[2]);
  column(w * 0.8, h * 0.22, h * 0.52, 6); rect(x, w * 0.5, h * 0.46, w * 0.3, 8, pal[2]);
  dab(x, w / 2, 6, 4, '#ff8fb6'); dab(x, w / 2, 6, 1.5, '#ffe27a');
  return c;
}

export function mushroom(seed, cap = '#e5484d', { w = 46, h = 50, glow = false } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  if (glow) { x.save(); x.globalAlpha = 0.2; dab(x, w / 2, h * 0.4, w * 0.48, cap); x.restore(); }
  for (let y = h * 0.45; y < h - 2; y++) for (let xx = -5; xx <= 5; xx++) rect(x, w / 2 + xx, y, 1, 1, xx < -2 ? '#fff6e6' : xx > 2 ? '#d8c8a8' : '#f0e2c8');
  const pal = ramp(cap, 6, 0.5);
  for (let yy = -h * 0.3; yy <= 0; yy++) {
    const half = Math.sqrt(Math.max(0, 1 - (yy / (h * 0.3)) ** 2)) * w * 0.46;
    for (let xx = -half; xx <= half; xx++) { const lit = 0.55 - (xx / half) * 0.3 - (yy / (h * 0.3)) * 0.3; rect(x, w / 2 + xx, h * 0.45 + yy, 1, 1, pal[Math.max(0, Math.min(5, Math.floor(lit * 6)))]); }
  }
  for (let i = 0; i < 5; i++) dab(x, w / 2 + (r() - 0.5) * w * 0.6, h * 0.3 + (r() - 0.5) * 8, 2, '#ffffff');
  return c;
}

export function log(seed, { w = 110, h = 40 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  shadowEllipse(x, w / 2, h - 4, w * 0.45, 4, 0.25);
  const pal = ramp('#7a4a28', 6, 0.5);
  for (let y = 6; y < h - 4; y++) for (let xx = 6; xx < w - 14; xx++) { const t = (y - 6) / (h - 10); rect(x, xx, y, 1, 1, pal[Math.max(0, Math.min(5, Math.floor((0.8 - t * 0.6 + (hashN(xx, y) < 0.08 ? -0.3 : 0)) * 6)))]); }
  for (let yy = 6; yy < h - 4; yy++) { const t = (yy - 6) / (h - 10); const half = Math.sqrt(Math.max(0, 1 - (t * 2 - 1) ** 2)) * 9; for (let xx = -half; xx <= half; xx++) rect(x, w - 14 + xx, yy, 1, 1, Math.hypot(xx / 9, t * 2 - 1) % 0.3 < 0.12 ? '#a8784a' : '#d8a878'); }
  clump(x, r, w * 0.35, 8, 14, 4, ramp('#4f9a3f', 5, 0.4), { size: [1, 2] });
  return c;
}

export function reeds(seed, { w = 50, h = 90 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  for (let i = 0; i < 12; i++) {
    const bx = 4 + r() * (w - 8), bh = h * (0.5 + r() * 0.5), lean = (r() - 0.5) * 8;
    line(x, bx, h - 1, bx + lean, h - bh, r() < 0.5 ? '#6b8a3a' : '#7f9f45', 1);
    if (r() < 0.5) { for (let y = 0; y < 10; y++) rect(x, bx + lean - 1, h - bh + y, 3, 1, y < 2 ? '#a07040' : '#7a4a28'); }
  }
  return c;
}

export function kelp(seed, { w = 50, h = 140 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  for (let s = 0; s < 3; s++) {
    const bx = w * (0.3 + s * 0.2), ph = r() * 6;
    for (let y = 0; y < h * (0.7 + r() * 0.3); y++) {
      const px = bx + Math.sin(y / 10 + ph) * 5;
      rect(x, px, h - y, 3, 1, s === 1 ? '#3fae5a' : '#2f8a4a');
      if (y % 12 === 4) { dab(x, px + 5, h - y, 3, '#4fc06a'); dab(x, px - 3, h - y - 6, 2.5, '#3a9a54'); }
    }
  }
  return c;
}

export function coral(seed, hue = '#ff7a9a', { w = 80, h = 70 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  const pal = ramp(hue, 5, 0.45);
  const branch = (bx, by, ang, len, wd) => {
    if (len < 4) { dab(x, bx, by, wd + 1, pal[4]); return; }
    const ex = bx + Math.cos(ang) * len, ey = by + Math.sin(ang) * len;
    line(x, bx, by, ex, ey, pal[2], wd); line(x, bx - 1, by, ex - 1, ey, pal[1], 1);
    branch(ex, ey, ang - 0.4 - r() * 0.3, len * 0.7, Math.max(1, wd - 1));
    branch(ex, ey, ang + 0.4 + r() * 0.3, len * 0.7, Math.max(1, wd - 1));
  };
  branch(w / 2, h - 2, -Math.PI / 2, h * 0.32, 5);
  return c;
}

// ---------- buildings and props for the farm and the shop ----------
export function barn(seed, { w = 200, h = 170 } = {}) {
  const { c, x } = mk(w, h);
  const wall = ramp('#b8403a', 5, 0.4);
  const top = h * 0.38;
  for (let y = top; y < h; y++) for (let xx = 10; xx < w - 10; xx++) rect(x, xx, y, 1, 1, (xx % 8 === 0) ? wall[1] : (xx < 22 ? wall[3] : wall[2]));
  // roof
  for (let y = 0; y < top + 6; y++) {
    const t = y / (top + 6), half = 12 + t * (w / 2 - 2);
    for (let xx = -half; xx <= half; xx++) rect(x, w / 2 + xx, y + 2, 1, 1, (y % 6 === 0) ? '#5a2420' : xx < 0 ? '#8a3430' : '#6e2a26');
  }
  line(x, w / 2 - 12, 3, 2, top + 8, '#f4ecd6', 3); line(x, w / 2 + 12, 3, w - 2, top + 8, '#f4ecd6', 3);
  // door with cross brace
  const dx = w / 2 - 28, dy = h * 0.55;
  for (let y = dy; y < h; y++) for (let xx = 0; xx < 56; xx++) rect(x, dx + xx, y, 1, 1, xx % 7 === 0 ? '#5a2420' : '#7a302a');
  rect(x, dx, dy, 56, 3, '#f4ecd6'); rect(x, dx, dy, 3, h - dy, '#f4ecd6'); rect(x, dx + 53, dy, 3, h - dy, '#f4ecd6');
  line(x, dx + 2, dy + 2, dx + 54, h - 2, '#f4ecd6', 3); line(x, dx + 54, dy + 2, dx + 2, h - 2, '#f4ecd6', 3);
  // loft window
  rect(x, w / 2 - 14, top + 4, 28, 22, '#f4ecd6'); rect(x, w / 2 - 11, top + 7, 22, 16, '#ffe7a0'); rect(x, w / 2 - 1, top + 7, 2, 16, '#f4ecd6');
  rect(x, 10, h - 3, w - 20, 3, '#4a1c18');
  return c;
}

export function raisedBed(seed, { w = 160, h = 34 } = {}) {
  const { c, x } = mk(w, h);
  const wood = ramp('#9a6a3c', 5, 0.45);
  for (let y = 0; y < h; y++) for (let xx = 0; xx < w; xx++) {
    const plank = Math.floor(y / 11);
    let col = wood[2 + (plank % 2)];
    if (y % 11 === 0) col = wood[0];
    if (hashN(xx, y * 3) < 0.05) col = wood[1];
    if (y < 3) col = wood[4];
    rect(x, xx, y, 1, 1, col);
  }
  for (const px of [3, w / 2, w - 6]) { rect(x, px, 4, 3, h - 4, wood[1]); rect(x, px + 1, 6, 1, 1, '#c8c0b0'); rect(x, px + 1, h - 8, 1, 1, '#c8c0b0'); }
  return c;
}

export function seedling(stage, berry = '#c0306a', seed = 1) {
  const r = rngFrom(seed);
  if (stage <= 0) {
    const { c, x } = mk(30, 24);
    line(x, 15, 23, 15, 12, '#3f8a3a', 2);
    dab(x, 11, 12, 3, '#5cbf5a'); dab(x, 19, 11, 3, '#6fcf58'); rect(x, 10, 10, 2, 1, '#9fe08a');
    return c;
  }
  if (stage === 1) {
    const { c, x } = mk(50, 44);
    for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + (i - 2) * 0.5; line(x, 25, 43, 25 + Math.cos(a) * 18, 43 + Math.sin(a) * 26, '#3f8a3a', 1); dab(x, 25 + Math.cos(a) * 18, 43 + Math.sin(a) * 26, 4, i % 2 ? '#5cbf5a' : '#4fae40'); }
    return c;
  }
  return bush(seed * 13 + 1, '#3f8a3a', { w: 80, h: 64, berries: stage >= 3 ? berry : null, count: stage >= 3 ? 16 + Math.floor(r() * 4) : 0, flowers: stage === 2 ? '#ffffff' : null });
}

export function scarecrow(seed, accent = '#e5484d', { w = 70, h = 120 } = {}) {
  const { c, x } = mk(w, h);
  line(x, w / 2, h - 1, w / 2, 20, '#7a4a28', 4); line(x, 6, 42, w - 6, 42, '#7a4a28', 3);
  for (let y = 38; y < 80; y++) for (let xx = -14; xx <= 14; xx++) rect(x, w / 2 + xx, y, 1, 1, (y + xx) % 9 === 0 ? shadeHex(accent, -0.3) : xx < 0 ? shadeHex(accent, 0.1) : accent);
  for (let i = 0; i < 8; i++) line(x, w / 2 - 14 - 6 + (i % 2) * 3, 42 + i, w / 2 - 22, 46 + i * 2, '#e8c46a', 1);
  dab(x, w / 2, 26, 11, '#f0d9a0'); dab(x, w / 2 - 4, 24, 1.5, '#1b1838'); dab(x, w / 2 + 4, 24, 1.5, '#1b1838'); line(x, w / 2 - 4, 30, w / 2 + 4, 30, '#7a4a28', 1);
  rect(x, w / 2 - 16, 13, 32, 4, '#c9a04a'); rect(x, w / 2 - 9, 2, 18, 12, '#d8b060');
  return c;
}

export function crate(seed, fill = '#c0306a', { w = 60, h = 46 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  for (let i = 0; i < 24; i++) { const bx = 6 + r() * (w - 12), by = 4 + r() * 10; dab(x, bx, by, 3, shadeHex(fill, -0.2)); dab(x, bx - 0.5, by - 0.5, 2, fill); rect(x, bx - 1, by - 1, 1, 1, '#ffffff'); }
  const wood = ramp('#b07a44', 4, 0.4);
  for (let y = 12; y < h; y++) for (let xx = 0; xx < w; xx++) rect(x, xx, y, 1, 1, (y - 12) % 11 < 1 ? wood[0] : xx < 3 || xx > w - 4 ? wood[1] : wood[2 + ((y >> 2) % 2)]);
  return c;
}

export function sunflower(seed, { w = 40, h = 130 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  line(x, w / 2, h - 1, w / 2 + (r() - 0.5) * 6, 26, '#3f8a3a', 3);
  dab(x, w / 2 - 8, h * 0.55, 5, '#4fae40'); dab(x, w / 2 + 8, h * 0.7, 5, '#4fae40');
  for (let i = 0; i < 14; i++) { const a = (i / 14) * Math.PI * 2; dab(x, w / 2 + Math.cos(a) * 12, 22 + Math.sin(a) * 12, 4, i % 2 ? '#ffc93c' : '#f2a516'); }
  dab(x, w / 2, 22, 8, '#6b4423'); for (let i = 0; i < 10; i++) rect(x, w / 2 - 5 + r() * 10, 17 + r() * 10, 1, 1, '#a8703c');
  return c;
}

export function stall(seed, accent = '#e5484d', { w = 240, h = 200 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  const wood = ramp('#a8703c', 5, 0.45);
  // posts
  for (const px of [14, w - 22]) for (let y = 40; y < h; y++) for (let xx = 0; xx < 8; xx++) rect(x, px + xx, y, 1, 1, xx < 2 ? wood[3] : xx > 5 ? wood[1] : wood[2]);
  // awning with scallops
  const stripes = 10, sw = w / stripes;
  for (let i = 0; i < stripes; i++) for (let y = 8; y < 52; y++) for (let xx = 0; xx < sw; xx++) {
    const col = i % 2 ? '#fff6ea' : accent;
    const sh = y > 40 ? -0.15 : 0;
    rect(x, i * sw + xx, y, 1, 1, shadeHex(col, sh + (xx < 2 ? 0.08 : 0)));
  }
  for (let i = 0; i < stripes; i++) { const col = i % 2 ? '#fff6ea' : accent; for (let a = 0; a <= Math.PI; a += 0.05) { const px = i * sw + sw / 2 + Math.cos(a) * sw / 2, py = 52 + Math.sin(a) * 7; rect(x, px, 52, 1, py - 52, shadeHex(col, -0.15)); } }
  rect(x, 0, 4, w, 5, shadeHex(accent, -0.4));
  // shelves of jars and goods
  for (let s = 0; s < 2; s++) {
    const sy = 90 + s * 32;
    rect(x, 24, sy, w - 48, 4, wood[1]);
    for (let i = 0; i < 9; i++) {
      const gx = 32 + i * ((w - 64) / 9), col = ['#e5484d', '#ffc93c', '#3fb26a', '#4ad0ff', '#c04fd8', '#ff8a3d', '#ff8fb6', '#7db8ff', '#f4ecd6'][(i + s * 3) % 9];
      rect(x, gx, sy - 18, 14, 18, shadeHex(col, -0.15)); rect(x, gx + 2, sy - 16, 4, 14, shadeHex(col, 0.35)); rect(x, gx - 1, sy - 21, 16, 4, '#d8d0c0');
    }
  }
  // counter
  for (let y = h - 60; y < h; y++) for (let xx = 8; xx < w - 8; xx++) rect(x, xx, y, 1, 1, y < h - 54 ? wood[4] : ((xx - 8) % 14 === 0 ? wood[0] : wood[2 + ((y >> 3) % 2)]));
  // sign
  rect(x, w / 2 - 40, h - 46, 80, 26, '#f4ecd6'); rect(x, w / 2 - 38, h - 44, 76, 22, '#fffaf0');
  x.fillStyle = shadeHex(accent, -0.3); x.font = '700 16px system-ui, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('SHOP', w / 2, h - 33);
  void r;
  return c;
}

export function lantern(seed, { w = 24, h = 90 } = {}) {
  const { c, x } = mk(w, h);
  line(x, w / 2, h - 1, w / 2, 18, '#4a4670', 3);
  x.save(); x.globalAlpha = 0.25; dab(x, w / 2, 12, 11, '#ffe27a'); x.restore();
  rect(x, w / 2 - 6, 4, 12, 16, '#2a2850'); rect(x, w / 2 - 4, 6, 8, 12, '#ffe27a'); rect(x, w / 2 - 2, 7, 3, 4, '#ffffff');
  return c;
}

export function signboard(text, accent = '#3fb26a', { w = 120, h = 70 } = {}) {
  const { c, x } = mk(w, h);
  const wood = ramp('#9a6a3c', 4, 0.4);
  for (const px of [w * 0.25, w * 0.72]) rect(x, px, 30, 6, h - 30, wood[1]);
  for (let y = 4; y < 38; y++) for (let xx = 4; xx < w - 4; xx++) rect(x, xx, y, 1, 1, (y - 4) % 11 === 0 ? wood[0] : wood[2]);
  rect(x, 8, 8, w - 16, 26, shadeHex(accent, 0.2));
  x.fillStyle = '#ffffff'; x.font = '700 15px system-ui, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText(text, w / 2, 21);
  return c;
}

export function bot(seed, { w = 64, h = 86 } = {}) {
  const { c, x } = mk(w, h);
  shadowEllipse(x, w / 2, h - 4, 20, 4, 0.25);
  const body = ramp('#c8c4dc', 5, 0.4);
  for (let y = 8; y < 44; y++) for (let xx = 8; xx < w - 8; xx++) { const r2 = (y < 14 || y > 38) && (xx < 13 || xx > w - 14); if (!r2) rect(x, xx, y, 1, 1, xx < 16 ? body[4] : xx > w - 16 ? body[1] : body[3]); }
  rect(x, 15, 16, w - 30, 18, '#1b1838'); dab(x, w / 2 - 9, 25, 4, '#7dffcf'); dab(x, w / 2 + 9, 25, 4, '#7dffcf'); rect(x, w / 2 - 10, 23, 2, 2, '#ffffff');
  line(x, w / 2, 8, w / 2, 0, '#8a86a8', 2); dab(x, w / 2, 1, 3, '#ffc93c');
  for (let y = 46; y < 74; y++) for (let xx = 14; xx < w - 14; xx++) rect(x, xx, y, 1, 1, xx < 20 ? body[3] : body[2]);
  rect(x, w / 2 - 8, 54, 16, 8, '#7dffcf');
  for (const px of [18, w - 28]) rect(x, px, 74, 10, 10, '#4a4670');
  rect(x, 4, 50, 8, 18, body[2]); rect(x, w - 12, 50, 8, 18, body[2]);
  return c;
}

// ---------- fences (one repeatable segment) ----------
export function fence(kind, L, seed = 1, { w = 96, h = 88 } = {}) {
  const r = rngFrom(seed * 9 + kind.length);
  const { c, x } = mk(w, h);
  const wood = ramp('#c08a50', 6, 0.5);
  switch (kind) {
    case 'picket': {
      for (const ry of [h * 0.36, h * 0.7]) for (let y = 0; y < 9; y++) for (let xx = 0; xx < w; xx++) rect(x, xx, ry + y, 1, 1, y < 2 ? wood[5] : y > 7 ? wood[0] : wood[3 - ((hashN(xx >> 3, y) < 0.2) ? 1 : 0)]);
      for (let p = 0; p < 4; p++) {
        const px = 4 + p * 24;
        for (let y = 8; y < h; y++) for (let xx = 0; xx < 14; xx++) {
          const tip = y < 16 ? Math.abs(xx - 7) > (y - 8) : false;
          if (tip) continue;
          rect(x, px + xx, y, 1, 1, xx < 3 ? wood[5] : xx > 11 ? wood[1] : (hashN(px + xx, y >> 2) < 0.1 ? wood[2] : wood[4]));
        }
        rect(x, px + 6, h * 0.4, 2, 2, '#6a5a4a'); rect(x, px + 6, h * 0.74, 2, 2, '#6a5a4a');
      }
      break;
    }
    case 'hedge': clump(x, r, w * 0.5, h * 0.58, w * 0.56, h * 0.42, ramp(L.ground[3] ?? '#3f8a3a', 7, 0.6), { size: [1.5, 3.2] }); break;
    case 'rocks': x.drawImage(rock(seed, L.cliff[0], { w: 56, h: 60, moss: L.ground[2] }), 0, h - 60); x.drawImage(rock(seed + 1, L.cliff[1] ?? L.cliff[0], { w: 60, h: 70 }), 38, h - 70); break;
    case 'snowbank': clump(x, r, w / 2, h * 0.7, w * 0.56, h * 0.32, ['#b8cbe4', '#cfdcf0', '#e2ebf8', '#f2f7ff', '#ffffff', '#ffffff'], { size: [2, 4] }); break;
    case 'adobe': { const top = h * 0.2; for (let y = top; y < h; y++) for (let xx = 0; xx < w; xx++) { const row = Math.floor((y - top) / 14), off = row % 2 ? 0 : 16; const mortar = (y - top) % 14 === 0 || (xx + off) % 32 === 0; rect(x, xx, y, 1, 1, mortar ? '#b07a44' : (y - top) < 4 ? '#efc08a' : hashN(xx >> 1, y >> 1) < 0.08 ? '#c99052' : '#d9a066'); } break; }
    case 'rail': for (const ry of [h * 0.3, h * 0.62]) rect(x, 0, ry, w, 6, '#ffffff'); for (const px of [8, w - 16]) { rect(x, px, h * 0.2, 8, h * 0.8, '#f2eeff'); rect(x, px, h * 0.2, 2, h * 0.8, '#ffffff'); } break;
    case 'coral': x.drawImage(coral(seed, '#ff7a9a', { w: 60, h: 70 }), 0, h - 70); x.drawImage(coral(seed + 3, '#ffb23d', { w: 56, h: 80 }), 40, h - 80); break;
    case 'reeds': x.drawImage(reeds(seed, { w, h }), 0, 0); break;
    case 'neon': rect(x, 0, h - 8, w, 8, '#1b1838'); for (const px of [6, w - 14]) { rect(x, px, 6, 8, h - 6, '#2a2850'); rect(x, px, 6, 8, 4, L.grid); } x.save(); x.globalAlpha = 0.85; for (const ry of [h * 0.3, h * 0.5, h * 0.7]) rect(x, 14, ry, w - 28, 2, L.grid); x.restore(); break;
    case 'crystal': x.drawImage(crystal(seed, '#ff9aff', { w: 50, h: 80 }), 0, h - 80); x.drawImage(crystal(seed + 2, '#9ad9ff', { w: 56, h: 88 }), 40, h - 88); break;
    case 'chain': { const m = '#8a90a6'; for (const px of [4, w - 10]) rect(x, px, h * 0.18, 6, h * 0.82, '#5a607a'); rect(x, 0, h * 0.18, w, 4, '#5a607a'); for (let i = -h; i < w; i += 8) { line(x, i, h * 0.2, i + h * 0.8, h, m, 1); line(x, i + h * 0.8, h * 0.2, i, h, m, 1); } break; }
    case 'iron': { const m = '#2a2232'; rect(x, 0, h * 0.3, w, 5, m); rect(x, 0, h - 10, w, 5, m); for (let px = 4; px < w; px += 12) { rect(x, px, h * 0.12, 4, h * 0.88, m); rect(x, px - 2, h * 0.08, 8, 4, '#3a3048'); rect(x, px + 1, h * 0.04, 2, 4, '#4a3e5a'); } break; }
    case 'glass': { x.save(); x.globalAlpha = 0.35; for (let px = 0; px < w; px += 32) { const hue = ['#ff9ad5', '#9af5ff', '#ffe27a'][(px / 32) % 3]; rect(x, px + 2, h * 0.25, 28, h * 0.75, hue); } x.restore(); for (let px = 0; px < w; px += 32) { rect(x, px, h * 0.25, 2, h * 0.75, '#ffffff'); } rect(x, 0, h * 0.25, w, 3, '#ffffff'); break; }
    default: break;
  }
  return c;
}

/** Soft painted cloud. */
export function cloud(seed, { w = 200, h = 80, tint = '#ffffff', shade = '#c9c4ee' } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  const pal = ramp(tint, 5, 0.3).slice(1);
  pal.unshift(shade);
  for (let i = 0; i < 5; i++) clump(x, r, w * (0.2 + i * 0.15), h * (0.55 - Math.sin(i / 4 * Math.PI) * 0.18), w * 0.16, h * 0.32, pal, { size: [2, 4] });
  return c;
}

// ---------- city outskirts ----------
export function lamppost(seed, { w = 40, h = 150, on = true } = {}) {
  const { c, x } = mk(w, h);
  shadowEllipse(x, w / 2, h - 4, 12, 3, 0.25);
  const metal = ramp('#4a5068', 5, 0.45);
  rect(x, w / 2 - 3, 24, 6, h - 28, metal[2]); rect(x, w / 2 - 3, 24, 2, h - 28, metal[4]);
  rect(x, w / 2 - 7, h - 10, 14, 8, metal[1]);
  line(x, w / 2, 26, w / 2 + 10, 14, metal[2], 3);
  rect(x, w / 2 + 2, 6, 16, 10, metal[1]);
  if (on) { x.save(); x.globalAlpha = 0.28; dab(x, w / 2 + 10, 18, 14, '#ffe9a8'); x.restore(); }
  rect(x, w / 2 + 4, 14, 12, 4, on ? '#fff3c4' : '#8a8aa0');
  return c;
}
export function bench(seed, { w = 120, h = 60 } = {}) {
  const { c, x } = mk(w, h);
  shadowEllipse(x, w / 2, h - 3, w * 0.42, 4, 0.25);
  const wood = ramp('#a0683a', 5, 0.45), metal = '#3a3f52';
  for (let i = 0; i < 3; i++) rect(x, 8, 8 + i * 8, w - 16, 6, wood[3 - (i % 2)]);
  for (let i = 0; i < 2; i++) rect(x, 4, 34 + i * 7, w - 8, 6, wood[4 - i]);
  for (const px of [12, w - 18]) { rect(x, px, 8, 6, h - 12, metal); rect(x, px - 2, h - 6, 10, 3, metal); }
  return c;
}
export function hydrant(seed, { w = 34, h = 50 } = {}) {
  const { c, x } = mk(w, h);
  shadowEllipse(x, w / 2, h - 3, 12, 3, 0.25);
  const red = ramp('#d8433a', 5, 0.45);
  for (let y = 10; y < h - 4; y++) for (let xx = 8; xx < w - 8; xx++) rect(x, xx, y, 1, 1, xx < 12 ? red[4] : xx > w - 12 ? red[1] : red[3]);
  dab(x, w / 2, 10, 8, red[3]); rect(x, w / 2 - 2, 0, 4, 4, red[2]);
  rect(x, 2, 20, 6, 8, red[2]); rect(x, w - 8, 20, 6, 8, red[2]); rect(x, 6, h - 6, w - 12, 4, red[0]);
  return c;
}
export function house(seed, { w = 200, h = 170, roof = null, walls = null } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  const roofs = ['#b2453a', '#4a5a8a', '#5a6a4a', '#8a5a3a'], wallsC = ['#f2e6d0', '#e6eef6', '#f6e0d0', '#e8f0dc'];
  const rf = ramp(roof ?? roofs[Math.floor(r() * roofs.length)], 5, 0.45), wl = ramp(walls ?? wallsC[Math.floor(r() * wallsC.length)], 5, 0.25);
  shadowEllipse(x, w / 2, h - 4, w * 0.45, 5, 0.25);
  const top = h * 0.45;
  for (let y = top; y < h - 4; y++) for (let xx = 18; xx < w - 18; xx++) rect(x, xx, y, 1, 1, xx < 30 ? wl[4] : xx > w - 30 ? wl[1] : (y - top) % 10 === 0 ? wl[2] : wl[3]);
  for (let y = 10; y < top + 6; y++) { const half = (y - 10) / (top - 4) * (w / 2 - 6); for (let xx = w / 2 - half; xx < w / 2 + half; xx++) rect(x, xx, y, 1, 1, (y + Math.floor(xx / 6)) % 7 === 0 ? rf[1] : xx < w / 2 ? rf[3] : rf[2]); }
  rect(x, w / 2 - 14, h - 52, 28, 48, '#6a4a32'); rect(x, w / 2 + 8, h - 30, 3, 3, '#ffd45e');
  for (const px of [36, w - 66]) { rect(x, px, top + 18, 30, 26, '#cfe6ff'); rect(x, px + 14, top + 18, 2, 26, wl[0]); rect(x, px, top + 30, 30, 2, wl[0]); rect(x, px + 2, top + 20, 8, 6, '#ffffff'); }
  rect(x, w * 0.7, 18, 14, 30, rf[0]);
  return c;
}
// ---------- spooky forest ----------
export function deadTree(seed, { w = 150, h = 210 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  shadowEllipse(x, w / 2, h - 5, w * 0.3, 5, 0.3);
  const bark = ramp('#4a3a42', 5, 0.4);
  const branch = (x0, y0, ang, len, wd, depth) => {
    const x1 = x0 + Math.cos(ang) * len, y1 = y0 + Math.sin(ang) * len;
    line(x, x0, y0, x1, y1, bark[depth % 2 ? 1 : 2], wd);
    line(x, x0 - wd / 3, y0, x1 - wd / 3, y1, bark[3], Math.max(1, wd / 3));
    if (depth > 0) for (let i = 0; i < 2; i++) branch(x1, y1, ang + (i ? 0.5 : -0.6) + (r() - 0.5) * 0.4, len * (0.55 + r() * 0.2), Math.max(1, wd * 0.6), depth - 1);
  };
  branch(w / 2, h - 6, -Math.PI / 2 + (r() - 0.5) * 0.15, h * 0.36, 10, 4);
  return c;
}
export function grave(seed, { w = 60, h = 70 } = {}) {
  const r = rngFrom(seed);
  const { c, x } = mk(w, h);
  shadowEllipse(x, w / 2, h - 4, w * 0.4, 4, 0.3);
  const st = ramp('#8a8696', 5, 0.45);
  const cross = r() < 0.35;
  if (cross) { rect(x, w / 2 - 4, 6, 8, h - 10, st[3]); rect(x, w / 2 - 16, 18, 32, 8, st[3]); rect(x, w / 2 - 4, 6, 3, h - 10, st[4]); }
  else {
    for (let y = 8; y < h - 4; y++) for (let xx = 10; xx < w - 10; xx++) { if (y < 20 && Math.hypot(xx - w / 2, y - 20) > w / 2 - 10) continue; rect(x, xx, y, 1, 1, xx < 15 ? st[4] : xx > w - 15 ? st[1] : st[3]); }
    rect(x, w / 2 - 12, 28, 24, 2, st[1]); rect(x, w / 2 - 9, 34, 18, 2, st[1]);
    if (r() < 0.6) clump(x, r, w * 0.3, h - 8, 10, 4, ramp('#3f5a3a', 5, 0.4), { size: [1, 2] });
  }
  return c;
}
export function pumpkin(seed, { w = 56, h = 46, lit = true } = {}) {
  const { c, x } = mk(w, h);
  shadowEllipse(x, w / 2, h - 3, w * 0.4, 3, 0.3);
  const o = ramp('#e8822a', 5, 0.45);
  for (const [dx, rr] of [[-12, 13], [12, 13], [0, 16]]) for (let y = -rr; y <= rr; y++) { const half = Math.floor(Math.sqrt(rr * rr - y * y) * 1.1); for (let xx = -half; xx <= half; xx++) rect(x, w / 2 + dx + xx, h - 4 - rr + y, 1, 1, xx < -half * 0.5 ? o[4] : xx > half * 0.5 ? o[1] : o[3]); }
  rect(x, w / 2 - 2, 2, 5, 10, '#4a6a2a');
  if (lit) { const g = '#ffe27a'; rect(x, w / 2 - 10, h - 26, 6, 6, g); rect(x, w / 2 + 4, h - 26, 6, 6, g); for (let i = 0; i < 5; i++) rect(x, w / 2 - 9 + i * 4, h - 14 - (i % 2) * 3, 3, 4, g); }
  return c;
}
// ---------- abstract ----------
/** Simple lit geometry: kind 'cube' | 'orb' | 'pyramid' | 'ring' | 'monolith'. */
export function shape(kind, seed, hue = '#ff7ac8', { w = 90, h = 100 } = {}) {
  const { c, x } = mk(w, h);
  const p = ramp(hue, 7, 0.55);
  shadowEllipse(x, w / 2, h - 4, w * 0.36, 4, 0.22);
  if (kind === 'cube') {
    const s = w * 0.36, cx = w / 2, top = h - 8 - s * 1.7;
    for (let i = 0; i < s; i++) { line(x, cx - s + i, top + s * 0.5 + i * 0.5, cx + i, top + i * 0.5, p[5], 1); line(x, cx - s + i, top + s * 0.5 + i * 0.5, cx - s + i, top + s * 1.5 + i * 0.5, p[3], 1); line(x, cx + i, top + s + i * -0.5 + s * 0, cx + i, top + s * 2 - i * 0.5, p[1], 1); }
  } else if (kind === 'orb') {
    const rr = w * 0.34, cx = w / 2, cy = h - 8 - rr;
    for (let y = -rr; y <= rr; y++) for (let xx = -rr; xx <= rr; xx++) { const d = (xx * xx + y * y) / (rr * rr); if (d > 1) continue; const l = 0.55 - 0.45 * ((xx / rr) * -0.6 + (y / rr) * -0.8) - d * 0.25; rect(x, cx + xx, cy + y, 1, 1, p[Math.max(0, Math.min(6, Math.floor(l * 7)))]); }
    dab(x, cx - rr * 0.35, cy - rr * 0.4, rr * 0.15, '#ffffff');
  } else if (kind === 'pyramid') {
    const base = h - 8, top = base - h * 0.8, cx = w / 2, half = w * 0.42;
    for (let y = top; y < base; y++) { const t = (y - top) / (base - top), hw = half * t; rect(x, cx - hw, y, hw, 1, p[5]); rect(x, cx, y, hw, 1, p[2]); }
  } else if (kind === 'ring') {
    const cx = w / 2, cy = h * 0.45, rr = w * 0.36;
    for (let a = 0; a < Math.PI * 2; a += 0.02) { const l = 0.5 + 0.4 * Math.cos(a + 2.2); dab(x, cx + Math.cos(a) * rr, cy + Math.sin(a) * rr, 5, p[Math.max(0, Math.min(6, Math.floor(l * 7)))]); }
    line(x, cx, cy + rr, cx, h - 6, p[1], 3);
  } else {
    const ww = w * 0.3, top = 4;
    for (let y = top; y < h - 6; y++) { rect(x, w / 2 - ww / 2, y, ww * 0.6, 1, p[3]); rect(x, w / 2 + ww * 0.1, y, ww * 0.4, 1, p[1]); }
    x.save(); x.globalAlpha = 0.85; for (let y = top + 10; y < h - 10; y += 16) rect(x, w / 2 - ww / 2, y, ww, 2, hue); x.restore();
  }
  return c;
}
// ---------- toys (thrown in the R.A.N.C.H. and the care room) ----------
export function toy(kind, { w = 40, h = 40 } = {}) {
  const { c, x } = mk(w, h);
  const cx = w / 2, cy = h / 2;
  switch (kind) {
    case 'ball': { for (let y = -16; y <= 16; y++) for (let xx = -16; xx <= 16; xx++) { if (xx * xx + y * y > 256) continue; const top = y < -1; rect(x, cx + xx, cy + y, 1, 1, top ? (xx < -6 ? '#ff7a6a' : '#e5484d') : (xx < -6 ? '#ffffff' : '#e6e6f0')); } rect(x, cx - 16, cy - 1, 32, 3, '#1b1838'); dab(x, cx, cy, 4, '#1b1838'); dab(x, cx, cy, 2, '#ffffff'); break; }
    case 'duck': { dab(x, cx + 2, cy + 6, 13, '#ffd23f'); dab(x, cx - 6, cy - 6, 8, '#ffd23f'); rect(x, cx - 18, cy - 7, 6, 4, '#ff8a3d'); rect(x, cx - 8, cy - 9, 3, 3, '#1b1838'); dab(x, cx + 6, cy + 2, 4, '#ffe680'); break; }
    case 'plush': { dab(x, cx, cy + 4, 13, '#b07ad8'); dab(x, cx - 9, cy - 10, 5, '#b07ad8'); dab(x, cx + 9, cy - 10, 5, '#b07ad8'); rect(x, cx - 6, cy, 3, 3, '#1b1838'); rect(x, cx + 4, cy, 3, 3, '#1b1838'); rect(x, cx - 2, cy + 6, 5, 2, '#ff8fb6'); break; }
    case 'bell': { for (let y = -12; y < 12; y++) { const half = 6 + (y + 12) * 0.5; rect(x, cx - half, cy + y, half * 2, 1, y < -4 ? '#ffe27a' : '#ffd23f'); } rect(x, cx - 2, cy + 12, 4, 4, '#c98a2a'); rect(x, cx - 6, cy - 4, 3, 10, '#fff6c0'); break; }
    case 'disc': { for (let xx = -17; xx <= 17; xx++) { const hh = Math.round(Math.sqrt(289 - xx * xx) * 0.35); rect(x, cx + xx, cy - hh, 1, hh * 2 + 1, xx < -8 ? '#7ad6ff' : '#3fa6e8'); } rect(x, cx - 12, cy - 2, 24, 2, '#ffffff'); break; }
    case 'feather': { line(x, cx - 12, cy + 12, cx + 10, cy - 12, '#9a6a3a', 2); for (let i = 0; i < 12; i++) { line(x, cx - 8 + i * 1.6, cy + 8 - i * 1.8, cx - 14 + i * 1.6, cy - 2 - i * 1.8, i % 2 ? '#f2a33a' : '#ffd45e', 2); } break; }
    case 'ribbon': { for (let i = 0; i < 18; i++) dab(x, cx - 16 + i * 2, cy + Math.sin(i / 2.5) * 8, 2.5, i % 3 ? '#ff6fa8' : '#ffd0e6'); break; }
    default: dab(x, cx, cy, 14, '#5b9bd5');
  }
  return c;
}

// ---------- dress-up clothes: small pixel pictures placed on a creature ----------
// a = main colour, b = its shade, c = its light, k = outline, w = white, y = gold, g = grey glass
const CLOTHES_ART = {
  bow: ['.kk.....kk.', 'kcak...kack', 'kaabkkkbaak', 'kaabkykbaak', 'kaabkkkbaak', 'kbak...kabk', '.kk.....kk.'],
  tophat: ['..kkkkkkk..', '..kaaaaak..', '..kcaaabk..', '..kcaaabk..', '..kyyyyyk..', 'kkkkkkkkkkk', 'kaaaaaaaaak', 'kkkkkkkkkkk'],
  cap: ['...kkkkk....', '..kcaaaak...', '.kcaaaaabk..', '.kaaawaaabk.', 'kkkkkkkkkkkk', '.....kbbbbbk', '......kkkkk.'],
  scarf: ['kkkkkkkkkkkk', 'kawawawawawk', 'kkkkkkkkkkkk', '.......kaak.', '.......kwak.', '.......kaak.', '.......kkkk.'],
  specs: ['.kkk...kkk.', 'kgggk.kgggk', 'kgwgkkkgwgk', 'kgggk.kgggk', '.kkk...kkk.'],
  shades: ['kkkkkkkkkkk', 'kaaakkkaaak', 'kawakkkawak', '.kak...kak.'],
  flower: ['...kkk...', '.kkcakkk.', 'kcaakaack', 'kaakyykak', '.kkyyykk.', 'kaakyykak', 'kbaakaabk', '.kkbakkk.', '...kkk...'],
  crown: ['k...k...k', 'ky.kyk.yk', 'kyykyykyk', 'kyyyyyyyk', 'kywyaywyk', 'kkkkkkkkk'],
  bandana: ['..kkkkkkk..', '.kaawaaaak.', 'kaaaaawaaak', 'kkkkkkkkkkk', '........kak', '.........kk'],
  star: ['....k....', '...kyk...', 'kkkyyykkk', 'kyyywyyyk', '.kyyyyyk.', '.kyykyyk.', 'kyk...kyk', 'kk.....kk'],
  bell: ['kkkkkkkkkkk', 'kaaaaaaaaak', 'kkkkkykkkkk', '....kyk....', '...kyyyk...', '...kykyk...', '....kkk....'],
  witchhat: ['......kk...', '.....kak...', '....kcak...', '...kcaak...', '..kcaaabk..', '..kyyyyyk..', 'kkkkkkkkkkk', 'kbbbbbbbbbk', 'kkkkkkkkkkk'],
  beanie: ['....kkk....', '...kwwwk...', '..kkkkkkk..', '.kcaaaaabk.', 'kcaaaaaaabk', 'kwkwkwkwkwk', 'kkkkkkkkkkk'],
  headphones: ['...kkkkk...', '..k.....k..', '.k.......k.', 'k.........k', 'kkk.....kkk', 'kaak...kaak', 'kaak...kaak', 'kkk.....kkk'],
  monocle: ['.kkk..', 'kgggk.', 'kgwgk.', 'kgggk.', '.kkk..', '...k..', '....k.', '.....k'],
  heart: ['.kk.kk.', 'kcakaak', 'kaaaaak', '.kaaak.', '..kak..', '...k...'],
};
const clothesCache = new Map();
/** A clothing picture (art: one of CLOTHES_ART, colour: its main colour). Pixel size 1; scale when drawing. */
export function clothes(art, color = '#e5484d') {
  const key = `${art}:${color}`;
  if (clothesCache.has(key)) return clothesCache.get(key);
  const rows = CLOTHES_ART[art] ?? CLOTHES_ART.star;
  const w = Math.max(...rows.map((r) => r.length)), h = rows.length;
  const { c, x } = mk(w, h);
  const pal = { a: color, b: shadeHex(color, -0.3), c: shadeHex(color, 0.35), k: '#1b1830', w: '#ffffff', y: '#ffd23f', g: 'rgba(190,225,255,.55)' };
  rows.forEach((r, j) => { for (let i = 0; i < r.length; i++) if (pal[r[i]]) rect(x, i, j, 1, 1, pal[r[i]]); });
  clothesCache.set(key, c);
  return c;
}
