// Loads the wild-battle bundle (Showdown's simulator and battle screen, built to showdown-battle.js next to
// the page) the first time it's needed, and runs one battle in an overlay.
import { h } from './dom.js';
import { spriteIdOf } from './art.js';

let loading = null;
export function loadShowdown() {
  if (globalThis.CapsuleShowdown) return Promise.resolve(globalThis.CapsuleShowdown);
  loading ??= new Promise((resolve, reject) => {
    const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'showdown.css'; document.head.append(css);
    const s = document.createElement('script'); s.src = 'showdown-battle.js';
    s.onload = () => (globalThis.CapsuleShowdown ? resolve(globalThis.CapsuleShowdown) : reject(new Error('The battle files didn’t start.')));
    s.onerror = () => { loading = null; reject(new Error('The battle files are missing (showdown-battle.js). Reinstall the update.')); };
    document.head.append(s);
  });
  return loading;
}

// which background goes with which place
const BACKDROP = { meadow: 'bg-meadow.jpg', forest: 'bg-forest.jpg', desert: 'bg-desert.jpg', tundra: 'bg-icecave.jpg', volcano: 'bg-earthycave.jpg', shoreline: 'bg-beach.jpg', marsh: 'bg-darkmeadow.jpg',
  cavern: 'bg-dampcave.jpg', skyline: 'bg-skypillar.jpg', spooky: 'bg-darkcity.jpg', seafloor: 'bg-deepsea.jpg', outskirts: 'bg-city.jpg', crystal: 'bg-library.jpg', starfield: 'bg-elite4drake.jpg', synth: 'bg-darkcity.jpg', prism: 'bg-aquacordetown.jpg' };
export const BACKDROP_FILES = [...new Set(Object.values(BACKDROP))];

/**
 * One wild battle in an overlay. ctx: { idx, bank, resolve (texture path → url), trainer }.
 * teams: from wildTeams(). Resolves to Showdown's outcome ({ won, ran, team, out }).
 */
export async function playWildBattle(ctx, teams, { biome = 'meadow', seed = Date.now() } = {}) {
  const SD = await loadShowdown();
  const { idx, bank, resolve } = ctx;
  // Showdown names → this data set's species, for the pictures
  const bySd = new Map();
  for (const sp of idx.ds.species) bySd.set(String(sp.showdownName || sp.name).toLowerCase().replace(/[^a-z0-9]+/g, ''), sp.id);
  const cache = new Map();
  const sprite = (name, { shiny, back }) => {
    const id = bySd.get(String(name).toLowerCase().replace(/[^a-z0-9]+/g, ''));
    if (!id) return null;
    const key = `${id}|${shiny}|${back}`;
    if (cache.has(key)) return cache.get(key);
    const e = bank.get(spriteIdOf({ speciesId: id, shiny }));
    const img = e?.frames?.idle?.[0];
    if (!img || e.waiting) return null;
    const k = 96 / Math.max(img.width, img.height);
    const cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
    const x = cv.getContext('2d'); x.imageSmoothingEnabled = false;
    if (back) { x.translate(cv.width, 0); x.scale(-1, 1); }
    x.drawImage(img, 0, 0, cv.width, cv.height);
    const out = { url: cv.toDataURL(), w: cv.width * (back ? 1.25 : 1), h: cv.height * (back ? 1.25 : 1) };
    cache.set(key, out);
    return out;
  };
  const bg = BACKDROP[biome] ?? 'bg-meadow.jpg';
  const host = h('div', { class: 'wb-host' });
  const scrim = h('div', { class: 'wb-scrim sd' }, h('div', { class: 'wb-sd panel' }, host));
  document.body.append(scrim);
  const r16 = (n) => (Math.abs(Math.imul(n | 0, 2654435761)) >>> 0) % 65536;
  const run = SD.start({
    host, trainer: ctx.trainer || 'You', avatar: ctx.avatar || '', sound: ctx.sound !== false, volume: ctx.volume ?? 0.6, team: teams.team, foe: teams.foe, seed: [r16(seed), r16(seed + 1), r16(seed + 2), r16(seed + 3)],
    sprite, fx: (file) => resolve(`fx/${String(file).toLowerCase()}`), backdrop: resolve(`fx/${bg}.png`) ?? resolve(`fx/${bg}`) ?? `https://play.pokemonshowdown.com/sprites/gen6bgs/${bg}`,
  });
  try { return await run.done; } finally { run.stop(); scrim.remove(); }
}
