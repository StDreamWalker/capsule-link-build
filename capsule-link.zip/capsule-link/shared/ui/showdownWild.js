// Loads the wild-battle bundle (Showdown's simulator and battle screen, built to showdown-battle.js next to
// the page) the first time it's needed, and runs one battle in an overlay.
import { whyNoEffect } from '../engine/battleItems.js';
import { createCreature } from '../engine/creature.js';
import { battleSky } from '../engine/sky.js';
import { h } from './dom.js';
import { spriteIdOf } from './art.js';
import { createBattleStage, battlePlace } from './battleStage.js';

let loading = null;
export function loadShowdown() {
  if (globalThis.CapsuleShowdown) return Promise.resolve(globalThis.CapsuleShowdown);
  loading ??= new Promise((resolve, reject) => {
    const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'showdown.css'; document.head.append(css);
    const s = document.createElement('script'); s.src = 'showdown-battle.js';
    s.onload = () => (globalThis.CapsuleShowdown ? resolve(globalThis.CapsuleShowdown) : reject(new Error('The battle files didn’t start.')));
    s.onerror = () => { loading = null; reject(new Error('The battle files are missing (showdown-battle.js). Reinstall the update.')); };
    document.head.append(s);
  });
  return loading;
}

// which background goes with which place
const BACKDROP = { meadow: 'bg-meadow.jpg', forest: 'bg-forest.jpg', desert: 'bg-desert.jpg', tundra: 'bg-icecave.jpg', volcano: 'bg-earthycave.jpg', shoreline: 'bg-beach.jpg', marsh: 'bg-darkmeadow.jpg',
  cavern: 'bg-dampcave.jpg', skyline: 'bg-skypillar.jpg', spooky: 'bg-darkcity.jpg', seafloor: 'bg-deepsea.jpg', outskirts: 'bg-city.jpg', crystal: 'bg-library.jpg', starfield: 'bg-elite4drake.jpg', synth: 'bg-darkcity.jpg', prism: 'bg-aquacordetown.jpg' };
export const BACKDROP_FILES = [...new Set(Object.values(BACKDROP))];

/**
 * One wild battle in an overlay. ctx: { idx, bank, resolve (texture path → url), trainer }.
 * teams: from wildTeams(). Resolves to Showdown's outcome ({ won, ran, team, out }).
 */
export async function playWildBattle(ctx, teams, { biome = 'meadow', seed = Date.now() } = {}) {
  // the real sky where you are (or what it's been corrected to), unless that's turned off; indoor places ignore it
  const indoorPlace = ['stadium', 'neon', 'cavern', 'crystal', 'seafloor', 'starfield'].includes(biome);
  const ambient = ctx.settings ? battleSky(ctx.settings) : null;
  if (ambient && indoorPlace) ambient.field = null;
  const SD = await loadShowdown();
  const { idx, bank, resolve } = ctx;
  // Showdown names → this data set's species, for the pictures
  const bySd = new Map();
  for (const sp of idx.ds.species) bySd.set(String(sp.showdownName || sp.name).toLowerCase().replace(/[^a-z0-9]+/g, ''), sp.id);
  const cache = new Map();
  const sprite = (name, { shiny, back }) => {
    const id = bySd.get(String(name).toLowerCase().replace(/[^a-z0-9]+/g, ''));
    if (!id) return null;
    const key = `${id}|${shiny}|${back}`;
    if (cache.has(key)) return cache.get(key);
    const e = bank.get(spriteIdOf({ speciesId: id, shiny }));
    const img = e?.frames?.idle?.[0];
    if (!img || e.waiting) return null;
    const k = 96 / Math.max(img.width, img.height);
    const cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k);
    const x = cv.getContext('2d'); x.imageSmoothingEnabled = false;
    if (back) { x.translate(cv.width, 0); x.scale(-1, 1); }
    x.drawImage(img, 0, 0, cv.width, cv.height);
    const out = { url: cv.toDataURL(), w: cv.width * (back ? 1.25 : 1), h: cv.height * (back ? 1.25 : 1) };
    cache.set(key, out);
    return out;
  };
  const bg = BACKDROP[battlePlace(biome).look] ?? BACKDROP[biome] ?? 'bg-meadow.jpg';
  // your trainer picture: the one picked on your ID card, else the one on your Showdown account
  const sdAv = String(ctx.sdAvatar ?? '').trim();
  const cardUrl = ctx.cardSprite ? resolve(ctx.cardSprite) : null;
  const sdLocal = sdAv && !sdAv.startsWith('#') ? resolve(`trainers/${sdAv.toLowerCase()}.png`) : null;
  const trainerUrl = cardUrl ?? sdLocal ?? (sdAv ? SD.avatarUrl?.(sdAv) : null) ?? null;
  const sdAvatarName = cardUrl || sdLocal ? 'capsule-me' : sdAv;
  const host = h('div', { class: 'wb-host' });
  const scrim = h('div', { class: 'wb-scrim sd' }, h('div', { class: 'wb-sd panel' }, host));
  document.body.append(scrim);
  // follows the app's theme (light, dark, or whatever the device uses): Showdown's own dark look for the log
  const darkNow = () => { const t = document.documentElement.dataset.theme; return t ? t === 'dark' : !!globalThis.matchMedia?.('(prefers-color-scheme: dark)').matches; };
  const paintTheme = () => { const d = darkNow(); scrim.classList.toggle('dark', d); host.classList.toggle('dark', d); };
  paintTheme();
  const mq = globalThis.matchMedia?.('(prefers-color-scheme: dark)'); mq?.addEventListener?.('change', paintTheme);
  const themeWatch = new MutationObserver(paintTheme); themeWatch.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  // the 2.5D stage (unless turned off): the app's own scene, acting out what Showdown's screen would show
  // online, anyone's Pokémon: a stand-in creature of that species for the stage (one Showdown has but this data
  // set doesn't: the classic screen then, with Showdown's own pictures)
  const standIns = new Map();
  const standIn = (mon) => {
    const nm = String(mon.species || mon.name || '');
    if (standIns.has(nm)) return standIns.get(nm);
    const id = bySd.get(nm.toLowerCase().replace(/[^a-z0-9]+/g, '')) ?? bySd.get(nm.split('-')[0].toLowerCase().replace(/[^a-z0-9]+/g, ''));
    let c = null;
    try { c = id ? createCreature(idx, id, { level: Number(mon.level) || 50, seed: standIns.size + 1, location: { kind: 'wild' } }) : null; } catch { c = null; }
    if (!c) setTimeout(() => host.classList.remove('cl-sd-3d'), 0);
    standIns.set(nm, c);
    return c;
  };
  let stage = null;
  if (ctx.stage3d !== false) {
    try {
      stage = createBattleStage({ ambient, versus: !!teams.online,
        idx, bank, place: biome, resolveTexture: resolve,
        trainers: { mine: trainerUrl, foe: ctx.foeTrainer ?? globalThis.__clTestFoeTrainer ?? null },
        creatureFor: (mon) => (mon.side === 0 ? ctx.creatures?.[teams.map?.[mon.name]?.uid] ?? null : teams.foeFor?.(mon, bySd) ?? teams.foeCreature ?? null) ?? (teams.online ? standIn(mon) : null),
        speciesFor: (name) => bySd.get(String(name).toLowerCase().replace(/[^a-z0-9]+/g, '')) ?? null,
        classic: () => { host.classList.toggle('cl-sd-3d'); try { localStorage.setItem('clBstClassic', host.classList.contains('cl-sd-3d') ? '0' : '1'); } catch { /* fine */ } },
      });
    } catch (e) { console.error(e); stage = null; }
  }
  const r16 = (n) => (Math.abs(Math.imul(n | 0, 2654435761)) >>> 0) % 65536;
  const run = SD.start({
    host, trainer: ctx.trainer || 'You', avatar: sdAvatarName || '', avatarUrl: trainerUrl, sound: ctx.sound !== false, volume: ctx.volume ?? 0.6, onVolume: ctx.onVolume, onSound: ctx.onSound, bag: ctx.bag ?? [], onUseItem: ctx.onUseItem, whyNoEffect, fieldWeather: ambient?.field ?? null, fieldWeatherText: ambient?.field ? { RainDance: 'It’s raining where you are, and it’s raining here too!', Snowscape: 'It’s snowing where you are, and it’s snowing here too!', SunnyDay: 'It’s a scorching day where you are: the sunlight is harsh!' }[ambient.field] : '', online: teams.online ?? null, foeTeam: teams.foeTeam ?? null, foeName: teams.foeTrainerName ?? '', foeAvatar: teams.foeAvatar ?? '', team: teams.team, foe: teams.foe, seed: [r16(seed), r16(seed + 1), r16(seed + 2), r16(seed + 3)],
    stage, sprite, fx: (file) => resolve(`fx/${String(file).toLowerCase()}`), backdrop: resolve(`fx/${bg}.png`) ?? resolve(`fx/${bg}`) ?? `https://play.pokemonshowdown.com/sprites/gen6bgs/${bg}`,
  });
  try { if (localStorage.getItem('clBstClassic') === '1') host.classList.remove('cl-sd-3d'); } catch { /* fine */ }
  // a double click (or double tap) on the battle itself, not on a button or anything else that does something,
  // puts the battle in full screen; again to come back
  const panelEl = scrim.firstElementChild;
  const isFull = () => document.fullscreenElement === panelEl || panelEl.classList.contains('wb-full');
  const onDbl = (e) => {
    if (e.target.closest('button, input, select, a, label, textarea, [role=button], .pbr-menu, .cl-sd-controls, .has-tooltip')) return;
    e.preventDefault();
    if (isFull()) { panelEl.classList.remove('wb-full'); if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {}); }
    else { panelEl.classList.add('wb-full'); panelEl.requestFullscreen?.().catch(() => {}); }
    setTimeout(() => window.dispatchEvent(new Event('resize')), 60);
  };
  const onFsChange = () => { if (!document.fullscreenElement) panelEl.classList.remove('wb-full'); setTimeout(() => window.dispatchEvent(new Event('resize')), 60); };
  host.addEventListener('dblclick', onDbl);
  document.addEventListener('fullscreenchange', onFsChange);
  if (stage) {
    // back and forth between the 2.5D stage and Showdown's classic screen
    const tog = h('button', { class: 'cl-sd-viewtoggle', type: 'button' });
    const label = () => { tog.textContent = host.classList.contains('cl-sd-3d') ? '▦ Classic view' : '🎥 2.5D view'; };
    tog.onclick = () => { host.classList.toggle('cl-sd-3d'); try { localStorage.setItem('clBstClassic', host.classList.contains('cl-sd-3d') ? '0' : '1'); } catch { /* fine */ } label(); };
    label(); host.prepend(tog);
    // in the 2.5D view the move menu comes up over the battle itself (like the console games), so Showdown's
    // controls live inside the stage; in the classic view they go back below it
    const placeControls = () => {
      const ctl = host.querySelector('.cl-sd-controls'), sd = host.querySelector('.cl-sd-stage');
      if (!ctl || !stage?.el) return;
      if (host.classList.contains('cl-sd-3d')) { if (ctl.parentNode !== stage.el) stage.el.append(ctl); }
      else if (ctl.parentNode === stage.el && sd) sd.after(ctl);
    };
    placeControls();
    new MutationObserver(placeControls).observe(host, { attributes: true, attributeFilter: ['class'] });
  }
  try { return await run.done; } finally { document.removeEventListener('fullscreenchange', onFsChange); if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {}); run.stop(); stage?.destroy(); scrim.remove(); themeWatch.disconnect(); mq?.removeEventListener?.('change', paintTheme); }
}
