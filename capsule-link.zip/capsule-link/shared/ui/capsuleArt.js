// Pixel drawing of a capsule (an upright pod with a glass dome and a light ring).
import { drawSprite } from './art.js';
import { drawBallArt, onUiArt } from './brandArt.js';

const POD = [
  '......########......',
  '....##........##....',
  '...#............#...',
  '..#..............#..',
  '..#..............#..',
  '.#................#.',
  '.#................#.',
  '.#................#.',
  '.#................#.',
  '.#................#.',
  '.#................#.',
  '.##################.',
  '.#RRRRRRRRRRRRRRRR#.',
  '.##################.',
  '.#BBBBBBBBBBBBBBBB#.',
  '.#BBBBBBBBBBBBBBBB#.',
  '.#BBBBBBBBBBBBBBBB#.',
  '..#BBBBBBBBBBBBBB#..',
  '..#BBBBBBBBBBBBBB#..',
  '...#BBBBBBBBBBBB#...',
  '....##BBBBBBBB##....',
  '......########......',
];

/** Draw a capsule at (x, y) top-left, `scale` px per art pixel. */
export function drawCapsule(ctx, x, y, scale, { ring = '#34d1bf', body = '#4a4670', glass = 'rgba(190,225,255,0.45)', lit = true, creature = null, bank = null, t = 0, skin = null, pose = null } = {}) {
  pose = pose ?? (lit || creature ? 'closed' : 'empty');
  // the Nexus Ball has no picture yet: a white sphere for now
  if (skin === 'nexus') { drawNexus(ctx, x, y, 20 * scale, 22 * scale, pose, lit ? ring : null); return; }
  // a ball texture (per ball type and pose) replaces the built-in capsule
  if (drawBallArt(ctx, x, y, 20 * scale, 22 * scale, skin, pose, { glow: lit && pose !== 'empty' ? ring : null })) return;
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  const tilt = { shake1: -0.28, shake3: 0.28 }[pose];
  if (tilt) { ctx.translate(x + 10 * scale, y + 22 * scale); ctx.rotate(tilt); ctx.translate(-(x + 10 * scale), -(y + 22 * scale)); }
  if (pose === 'open') { glass = 'rgba(255,255,255,0.95)'; lit = true; }
  const px = (i, j, c) => { ctx.fillStyle = c; ctx.fillRect(x + i * scale, y + j * scale, scale, scale); };
  // glass interior
  for (let j = 1; j < 11; j++) {
    const row = POD[j];
    const a = row.indexOf('#'), b = row.lastIndexOf('#');
    for (let i = a + 1; i < b; i++) px(i, j, glass);
  }
  if (creature && bank) {
    const entry = bank.get(creature);
    const s = (Math.max(1, Math.floor(scale / 2)) * 32) / (entry.draw || 32);
    drawSprite(ctx, entry, 'idle', Math.floor(t * 2), x + 10 * scale, y + 11 * scale + 1, s);
  }
  const glow = lit ? ring : '#2a2848';
  POD.forEach((row, j) => {
    for (let i = 0; i < row.length; i++) {
      const ch = row[i];
      if (ch === '#') px(i, j, '#1b1838');
      else if (ch === 'R') px(i, j, glow);
      else if (ch === 'B') px(i, j, body);
    }
  });
  // highlights
  px(4, 3, 'rgba(255,255,255,0.8)'); px(3, 4, 'rgba(255,255,255,0.6)'); px(3, 5, 'rgba(255,255,255,0.4)');
  for (let i = 3; i < 17; i++) px(i, 14, 'rgba(255,255,255,0.12)');
  ctx.restore();
}

export const CAPSULE_ART_W = 20;
export const CAPSULE_ART_H = 22;

/** A self-animating <canvas> capsule. */
export function capsuleCanvas(opts, scale = 4) {
  const c = document.createElement('canvas');
  c.width = CAPSULE_ART_W * scale; c.height = CAPSULE_ART_H * scale;
  c.className = 'capsule-art';
  const ctx = c.getContext('2d');
  let raf, t0 = performance.now();
  const pose = opts.pose ?? ((opts.lit ?? true) || opts.creature ? 'closed' : 'empty');
  const paint = (now) => {
    ctx.clearRect(0, 0, c.width, c.height);
    const t = (now - t0) / 1000;
    const pulse = opts.pulse ? Math.sin(t * 3) > 0 : true;
    drawCapsule(ctx, 0, 0, scale, { ...opts, pose, lit: (opts.lit ?? true) && pulse, t });
    if (c.isConnected || now - t0 < 500) raf = requestAnimationFrame(paint);
  };
  raf = requestAnimationFrame(paint);
  c.dispose = () => cancelAnimationFrame(raf);
  return c;
}

/** A small still picture of a ball type (for lists, party rows and the summary). Redraws when art arrives. */
export function ballIcon(skin, size = 18, pose = 'icon') {
  const c = document.createElement('canvas');
  const scale = 2;
  c.width = CAPSULE_ART_W * scale; c.height = CAPSULE_ART_H * scale;
  c.className = 'ball-icon';
  c.style.width = `${size}px`; c.style.height = `${Math.round((size * CAPSULE_ART_H) / CAPSULE_ART_W)}px`;
  const ctx = c.getContext('2d');
  const paint = () => { ctx.clearRect(0, 0, c.width, c.height); drawCapsule(ctx, 0, 0, scale, { skin, pose, lit: false, ring: '#34d1bf' }); };
  paint();
  let seen = false;
  const off = onUiArt(() => { if (c.isConnected) seen = true; else if (seen) { off(); return; } paint(); });
  return c;
}

/** The Nexus Ball, until it has art of its own: a softly shaded white sphere. */
function drawNexus(ctx, x, y, w, h, pose, glow) {
  const r = Math.min(w, h) * 0.42, cx = x + w / 2, cy = y + h - r - h * 0.06;
  const tilt = { shake1: -0.28, shake3: 0.28 }[pose] ?? 0;
  ctx.save();
  if (tilt) { ctx.translate(cx, cy + r); ctx.rotate(tilt); ctx.translate(-cx, -(cy + r)); }
  if (glow) { ctx.shadowColor = glow; ctx.shadowBlur = Math.max(4, w * 0.2); }
  const g = ctx.createRadialGradient(cx - r * 0.35, cy - r * 0.4, r * 0.1, cx, cy, r);
  g.addColorStop(0, '#ffffff'); g.addColorStop(0.7, '#eef0f6'); g.addColorStop(1, '#c6cad6');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
  ctx.shadowBlur = 0; ctx.strokeStyle = 'rgba(80,86,110,.55)'; ctx.lineWidth = Math.max(1, r * 0.08); ctx.stroke();
  ctx.restore();
}
/** The ball a creature shows: a Nexus Ball while it's in one, otherwise the ball it was caught in (a Poké Ball if unknown). */
export function creatureBall(c) { return c?.location?.kind === 'capsule' ? 'nexus' : String(c?.ball || '4'); }
