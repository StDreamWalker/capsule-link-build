// A small open-source language model running on this device (SmolLM2, 135 million parameters, through
// transformers.js), so creatures really take in what you say to them: "Hello" → "Lileep acknowledged your hello.",
// "Sorry, we can't go outside today" → "Porygon is saddened but understands." They still can't talk: it only
// writes the one line saying how they react. It's part of talking to them, not an option: it downloads once in
// the background (about 120 MB) the first time the app runs online, then works offline. Until it's ready, or if
// it can't load, or if what it writes doesn't make sense, the built-in rules answer as before.
const LIB = 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.5.1/dist/transformers.min.js';
const MODELS = [['HuggingFaceTB/SmolLM2-135M-Instruct', 'q4'], ['onnx-community/SmolLM2-135M-Instruct-ONNX', 'q4'], ['HuggingFaceTB/SmolLM2-135M-Instruct', 'fp32']];

const status = { state: 'idle', progress: 0, error: null };
let gen = null, loading = null;
const listeners = new Set();
const tell = () => { for (const f of listeners) { try { f({ ...status }); } catch { /* fine */ } } };

/** Where the model is: { state: 'idle'|'loading'|'ready'|'failed', progress 0..1, error }. */
export function llmStatus() { return { ...status }; }
export function onLlmStatus(fn) { listeners.add(fn); return () => listeners.delete(fn); }

/** Start loading it (in the background; safe to call often). importer: for tests. */
export function warmLlm({ importer = (u) => import(/* @vite-ignore */ u) } = {}) {
  if (gen || loading) return loading ?? Promise.resolve(gen);
  if (typeof navigator !== 'undefined' && navigator.onLine === false && !hasCache()) return Promise.resolve(null);
  status.state = 'loading'; status.progress = 0; status.error = null; tell();
  loading = (async () => {
    const T = await importer(LIB);
    try { T.env.allowLocalModels = false; T.env.useBrowserCache = true; } catch { /* older versions */ }
    const files = new Map();
    const progress_callback = (p) => {
      if (p?.status === 'progress' && p.file) { files.set(p.file, [p.loaded ?? 0, p.total ?? 0]); let a = 0, b = 0; for (const [l, t] of files.values()) { a += l; b += t; } status.progress = b ? a / b : 0; tell(); }
    };
    let lastErr = null;
    for (const [model, dtype] of MODELS) {
      try { gen = await T.pipeline('text-generation', model, { dtype, device: 'wasm', progress_callback }); break; } catch (e) { lastErr = e; }
    }
    if (!gen) throw lastErr ?? new Error('no model');
    try { localStorage.setItem('clLlmCached', '1'); } catch { /* fine */ }
    status.state = 'ready'; status.progress = 1; tell();
    return gen;
  })().catch((e) => { console.warn('language model', e); status.state = 'failed'; status.error = String(e?.message ?? e); loading = null; tell(); return null; });
  return loading;
}
function hasCache() { try { return localStorage.getItem('clLlmCached') === '1'; } catch { return false; } }

// a few examples teach it the job: one sentence, third person, how the creature reacts (it can't speak)
const EXAMPLES = [
  ['Hello!', 'Lileep', 'Lileep acknowledged your hello.'],
  ['Sorry, we can’t go outside today.', 'Porygon', 'Porygon is saddened but understands.'],
  ['You did great in that battle!', 'Pikachu', 'Pikachu puffs up proudly at the praise.'],
  ['Want to go to the beach tomorrow?', 'Squirtle', 'Squirtle bounces with excitement at the idea.'],
  ['I had a really bad day.', 'Eevee', 'Eevee nuzzles up to you to cheer you up.'],
];

/**
 * One line saying how the creature reacts to what was said, or null (then use the rules' own line).
 * c: { name, species, mood, likes, rule } (rule: what the built-in rules made of it, as a hint).
 */
export async function llmReact(text, c, { timeoutMs = 6000 } = {}) {
  if (!gen) return null;
  const name = String(c.name || c.species || 'It');
  const sys = `You narrate how ${name}${c.species && c.species !== name ? `, a ${c.species},` : ''} reacts when its trainer talks to it. ${name} is a Pokémon: it cannot talk, but it understands the gist. Answer with ONE short sentence in the third person that starts with "${name}" and describes its reaction to what was said. ${name} is feeling ${c.mood || 'fine'}.${c.likes ? ` It loves ${c.likes}.` : ''} Don't mention food unless the trainer did.`;
  const messages = [{ role: 'system', content: sys }];
  for (const [said, who, line] of EXAMPLES) { messages.push({ role: 'user', content: `Trainer says to ${who}: "${said}"` }, { role: 'assistant', content: line }); }
  messages.push({ role: 'user', content: `Trainer says to ${name}: "${String(text).slice(0, 200)}"` });
  try {
    const run = gen(messages, { max_new_tokens: 32, do_sample: true, temperature: 0.6, top_p: 0.9, repetition_penalty: 1.1 });
    const out = await Promise.race([run, new Promise((r) => setTimeout(() => r(null), timeoutMs))]);
    if (!out) return null;
    const g = out?.[0]?.generated_text;
    const raw = Array.isArray(g) ? g[g.length - 1]?.content : String(g ?? '');
    return cleanLine(raw, name);
  } catch (e) { console.warn('language model', e); return null; }
}

/** What it wrote, tidied, or null when it doesn't make sense as a reaction. */
export function cleanLine(raw, name) {
  let s = String(raw ?? '').replace(/^["'\s]+|["'\s]+$/g, '').split(/\n/)[0].trim();
  const m = s.match(/^[^.!?]*[.!?]/); if (m) s = m[0];
  if (!s || s.length < 6 || s.length > 140) return null;
  if (!s.toLowerCase().startsWith(String(name).toLowerCase())) return null; // it has to be about them
  if (/\b(I|I'm|I am|my|me)\b/.test(s.slice(String(name).length))) return null; // they can't speak
  if (/[<>{}[\]]|https?:/i.test(s)) return null;
  return /[.!?]$/.test(s) ? s : `${s}.`;
}
