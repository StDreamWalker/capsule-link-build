// Your own battle music: audio files you add (from your own collection) kept in this device's storage, and
// played in battles instead of (or mixed in with) Showdown's tracks. Nothing is uploaded anywhere.
const DB = 'capsule-music', STORE = 'tracks';
function open() {
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(STORE, { keyPath: 'id' });
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
}
async function tx(mode, fn) {
  const db = await open();
  return new Promise((res, rej) => { const t = db.transaction(STORE, mode); const out = fn(t.objectStore(STORE)); t.oncomplete = () => res(out?.result ?? out); t.onerror = () => rej(t.error); });
}
const durationOf = (blob) => new Promise((res) => {
  const a = document.createElement('audio'); const u = URL.createObjectURL(blob);
  a.preload = 'metadata'; a.onloadedmetadata = () => { res(Number.isFinite(a.duration) ? a.duration : 0); URL.revokeObjectURL(u); }; a.onerror = () => { res(0); URL.revokeObjectURL(u); }; a.src = u;
});

/** Your tracks: [{ id, name, dur }] (no audio). */
export async function listTracks() {
  try { const all = await tx('readonly', (s) => s.getAll()); return (all ?? []).map(({ id, name, dur }) => ({ id, name, dur })).sort((a, b) => a.name.localeCompare(b.name)); } catch { return []; }
}
/** Add audio files (from a file picker). Returns how many were added. */
export async function addTracks(files) {
  let n = 0;
  for (const f of files ?? []) {
    if (!/^audio\//.test(f.type) && !/\.(mp3|ogg|oga|m4a|aac|wav|flac|opus|webm)$/i.test(f.name)) continue;
    const dur = await durationOf(f);
    const rec = { id: `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`, name: f.name.replace(/\.[^.]+$/, ''), dur, blob: f };
    await tx('readwrite', (s) => s.put(rec)); n++;
  }
  return n;
}
export async function removeTrack(id) { try { await tx('readwrite', (s) => s.delete(id)); } catch { /* gone */ } }
/** The tracks ready for a battle: [{ key, url, loopend (ms) }]. */
export async function battleTracks() {
  try {
    const all = await tx('readonly', (s) => s.getAll());
    return (all ?? []).filter((r) => r.blob).map((r) => ({ key: `clmusic-${r.id}`, url: URL.createObjectURL(r.blob), loopend: Math.max(4000, Math.round((r.dur || 120) * 1000) - 250), name: r.name }));
  } catch { return []; }
}

/** The little "Battle music" control for a battle screen. h: the dom helper; get/set: the setting. */
export function musicPicker(h, { get, set, toast }) {
  const box = h('div', { class: 'music-pick col', style: { gap: '6px' } });
  const paint = async () => {
    const list = await listTracks(), mode = get() ?? 'showdown';
    const file = h('input', { type: 'file', accept: 'audio/*', multiple: true, style: { display: 'none' }, onchange: async (e) => { const n = await addTracks([...e.target.files]); toast?.(n ? `Added ${n} track${n === 1 ? '' : 's'} for battles.` : 'Those weren’t audio files.', n ? 'ok' : 'err'); if (n && mode === 'showdown') set('mine'); paint(); } });
    box.replaceChildren(
      h('div', { class: 'row wrap', style: { gap: '6px', alignItems: 'center' } },
        h('span', { class: 'dim' }, 'Battle music'),
        h('select', { onchange: (e) => { set(e.target.value); paint(); } },
          [['showdown', 'Showdown’s tracks'], ['mine', 'Your own tracks'], ['mix', 'Both, mixed']].map(([v, l]) => h('option', { value: v, selected: v === mode, disabled: v !== 'showdown' && !list.length }, l))),
        h('button', { class: 'btn small ghost', onclick: () => file.click() }, '+ Add music files'), file),
      list.length ? h('div', { class: 'micro dim' }, list.map((t) => h('span', { class: 'music-chip' }, `♪ ${t.name}`, h('button', { class: 'linklike', title: 'Remove', onclick: async () => { await removeTrack(t.id); paint(); } }, ' ✕')))) : h('p', { class: 'micro dim' }, 'Add your own music (your Battle Revolution soundtrack, say) and battles play it, looping. It stays on this device.'));
  };
  paint();
  return box;
}
