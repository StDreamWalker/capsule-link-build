// A pixel scene with creatures that wander, sleep, eat and react — used by the ranch,
// the desktop buddy and the phone's walking-buddy screen.
import { drawSprite } from './art.js';
import { brandText } from './dom.js';
import { Ambient, groundTop, skyTint } from './biomes.js';
import { SPRITE_SIZE } from './sprites.js';
import { fitSprite } from './creatureSize.js';

const HEART = ['.##.##.', '#######', '#######', '.#####.', '..###..', '...#...'];
const SPARK = ['..#..', '.###.', '#####', '.###.', '..#..'];
const NOTE = ['..##', '..#.', '..#.', '###.', '##..'];
const ZZZ = ['####', '..#.', '.#..', '####'];
const CRUMB = ['##', '##'];
const DROP = ['.#.', '###', '.#.'];
const SHAPES = { hearts: [HEART, '#ff5d8f'], sparkle: [SPARK, '#fff6a0'], note: [NOTE, '#ffffff'], sleep: [ZZZ, '#ffffff'], munch: [CRUMB, '#c98a3a'], sad: [DROP, '#7fb8ff'] };

/** A picture with a soft white border around it (for menu icons on the desktop). */
function outlined(img) {
  const p = 2, c = document.createElement('canvas');
  c.width = img.width + p * 2; c.height = img.height + p * 2;
  const x = c.getContext('2d');
  const m = document.createElement('canvas'); m.width = c.width; m.height = c.height;
  const mx = m.getContext('2d');
  for (let dy = -p; dy <= p; dy++) for (let dx = -p; dx <= p; dx++) if (dx * dx + dy * dy <= p * p + 1) mx.drawImage(img, p + dx, p + dy);
  mx.globalCompositeOperation = 'source-in'; mx.fillStyle = '#ffffff'; mx.fillRect(0, 0, m.width, m.height);
  x.globalAlpha = 0.6; x.drawImage(m, 0, 0); x.globalAlpha = 1;
  x.drawImage(img, p, p);
  return c;
}

function drawShape(ctx, shape, color, x, y) {
  ctx.fillStyle = color;
  shape.forEach((row, j) => { for (let i = 0; i < row.length; i++) if (row[i] === '#') ctx.fillRect(Math.round(x + i), Math.round(y + j), 1, 1); });
}

export class Stage {
  /**
   * opts: { bank, width, height, biome, transparent, ground (y px), spriteScale, onSelect(uid), onPet(uid), onDrop(uid, x, y) }
   */
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.bank = opts.bank;
    this.W = opts.width ?? 320;
    this.H = opts.height ?? 180;
    canvas.width = this.W; canvas.height = this.H;
    this.transparent = !!opts.transparent;
    this.biome = opts.biome ?? 'meadow';
    this.spriteScale = opts.spriteScale ?? 1;
    // optional: (actor) => how tall its visible part should be, in canvas pixels. Without it a
    // sprite is drawn at its own size times spriteScale.
    this.visibleHeight = opts.visibleHeight ?? null;
    // the desktop buddy: menu icons (with a soft white border) when downloaded, and a beam-in
    this.iconMode = !!opts.iconMode;
    this.beam = !!opts.beam;
    this.groundY = opts.ground ?? null;
    this.actors = new Map();
    this.fx = [];
    this.ball = null;
    this.selected = null;
    this.hover = null;
    this.onSelect = opts.onSelect ?? (() => {});
    this.onPet = opts.onPet ?? (() => {});
    this.onDrop = opts.onDrop ?? null;
    this.onHover = opts.onHover ?? null;
    this.showNames = opts.showNames ?? true;
    this.ambient = this.transparent ? null : new Ambient(this.biome, this.W, this.H, 7);
    this.running = false;
    this.last = 0;
    this.drag = null;
    this.bindPointer();
  }

  /** Where and how big an actor's frame is drawn: { size (frame side), visible, box, xOff, bottom }. */
  /** The sprite entry to draw: the outlined menu icon in icon mode, when there is one. */
  entryFor(a) {
    const entry = this.bank.get(a.speciesId);
    if (!this.iconMode || !entry.ownFile?.icon || !entry.frames.icon) return entry;
    if (entry.outlinedOf !== entry.frames.icon) {
      const frames = entry.frames.icon.map(outlined);
      entry.outlined = { size: frames[0].width, draw: frames[0].width, frames: Object.fromEntries(['idle', 'walk', 'sleep', 'happy', 'blink', 'back'].map((k) => [k, frames])) };
      entry.outlinedOf = entry.frames.icon;
    }
    return entry.outlined;
  }

  geom(a) {
    const entry = this.entryFor(a);
    if (!this.visibleHeight) {
      const size = (entry.draw || SPRITE_SIZE) * this.spriteScale;
      return { entry, size, visible: size * 0.85, box: { left: 0.1, right: 0.9, top: 0.15, bottom: 1 }, xOff: 0, bottom: 1, scale: this.spriteScale };
    }
    const visible = this.visibleHeight(a);
    const fit = fitSprite(entry, visible, 0);
    const b = fit.box;
    return { entry, size: fit.size, visible, box: b, xOff: (0.5 - (b.left + b.right) / 2) * fit.size, bottom: b.bottom, scale: fit.size / (entry.draw || SPRITE_SIZE) };
  }

  get ground() { return this.groundY ?? (this.transparent ? this.H - 2 : groundTop(this.biome, this.H) + 6); }

  setBiome(id) {
    this.biome = id;
    if (!this.transparent) this.ambient = new Ambient(id, this.W, this.H, 7);
    for (const a of this.actors.values()) a.y = Math.max(this.ground, Math.min(this.H - 3, a.y));
  }

  /** creatures: [{ uid, speciesId, name, mood, speed }] */
  setCreatures(list) {
    const keep = new Set(list.map((c) => c.uid));
    for (const uid of [...this.actors.keys()]) if (!keep.has(uid)) this.actors.delete(uid);
    for (const c of list) {
      const a = this.actors.get(c.uid);
      if (a) Object.assign(a, { speciesId: c.speciesId, name: c.name, mood: c.mood, speed: c.speed ?? a.speed, sizeMul: c.sizeMul ?? 1 });
      else this.actors.set(c.uid, this.makeActor(c));
    }
  }

  makeActor(c) {
    const gy = this.ground;
    return {
      uid: c.uid, speciesId: c.speciesId, name: c.name, mood: c.mood, sizeMul: c.sizeMul ?? 1,
      x: 20 + Math.random() * (this.W - 40),
      y: this.transparent ? this.H - 2 : gy + Math.random() * Math.max(1, this.H - gy - 6),
      tx: null, ty: null, state: 'idle', timer: 1 + Math.random() * 2, flip: Math.random() < 0.5, appear: this.beam ? 0 : 1,
      frame: 0, ft: 0, blink: 3 + Math.random() * 3, bounce: 0, speed: c.speed ?? 18, hop: 0,
    };
  }

  start() {
    if (this.running) return;
    this.running = true;
    const loop = (t) => {
      if (!this.running) return;
      const dt = Math.min(0.1, (t - (this.last || t)) / 1000);
      this.last = t;
      this.update(dt);
      this.draw();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }
  stop() { this.running = false; cancelAnimationFrame(this.raf); this.last = 0; }

  react(uid, kind, n = 3) {
    const a = this.actors.get(uid);
    if (!a) return;
    if (kind === 'hearts' || kind === 'happy' || kind === 'delighted' || kind === 'play') { a.state = 'happy'; a.timer = 1.6; a.hop = 1; }
    if (kind === 'sleep') { a.state = 'sleep'; a.timer = 8; }
    if (kind === 'munch') { a.state = 'eat'; a.timer = 2; }
    const shape = kind === 'delighted' || kind === 'play' ? 'hearts' : kind === 'listen' ? 'note' : kind === 'happy' ? 'hearts' : kind;
    if (!SHAPES[shape]) return;
    const g = this.geom(a), size = g.visible;
    for (let i = 0; i < n; i++) {
      this.fx.push({ shape, x: a.x - 4 + (Math.random() - 0.5) * size * 0.7, y: a.y - size * 1.05, vy: -10 - Math.random() * 8, vx: (Math.random() - 0.5) * 6, life: 1.4 + i * 0.25, delay: i * 0.18 });
    }
  }

  throwBall() {
    this.ball = { x: 10, y: this.ground - 20, vx: 60 + Math.random() * 30, vy: -40, life: 6 };
    for (const a of this.actors.values()) if (a.state !== 'sleep') { a.state = 'chase'; a.timer = 6; }
  }

  update(dt) {
    this.ambient?.update(dt);
    const g = this.ground;
    for (const a of this.actors.values()) {
      a.ft += dt;
      a.timer -= dt;
      a.blink -= dt;
      if (a.blink < -0.15) a.blink = 2 + Math.random() * 4;
      if (a.hop > 0) a.hop = Math.max(0, a.hop - dt * 2.5);
      if (this.drag?.uid === a.uid && this.drag.moved) continue;
      switch (a.state) {
        case 'walk': case 'chase': {
          let tx = a.tx, ty = a.ty;
          if (a.state === 'chase' && this.ball) { tx = this.ball.x; ty = Math.max(g, Math.min(this.H - 3, this.ball.y + 6)); }
          if (tx == null) { a.state = 'idle'; a.timer = 1; break; }
          const dx = tx - a.x, dy = this.transparent ? 0 : ty - a.y;
          const d = Math.hypot(dx, dy);
          if (d < 2) {
            if (a.state === 'chase' && this.ball) { this.ball.vx = (Math.random() < 0.5 ? -1 : 1) * (50 + Math.random() * 40); this.ball.vy = -50; a.hop = 1; }
            else { a.state = 'idle'; a.timer = 1 + Math.random() * 3; }
            break;
          }
          const sp = a.speed * (a.state === 'chase' ? 2 : 1) * dt;
          a.x += (dx / d) * Math.min(sp, d);
          a.y += (dy / d) * Math.min(sp, d);
          a.flip = dx < 0;
          if (a.timer <= 0 && a.state !== 'chase') { a.state = 'idle'; a.timer = 1 + Math.random() * 2; }
          if (a.state === 'chase' && (!this.ball || a.timer <= 0)) { a.state = 'happy'; a.timer = 1.2; }
          break;
        }
        case 'idle':
          if (a.timer <= 0) {
            const r = Math.random();
            const sleepy = a.mood === 'sleepy';
            if (r < (sleepy ? 0.45 : 0.08)) { a.state = 'sleep'; a.timer = 6 + Math.random() * 10; }
            else if (r < 0.75) {
              a.state = 'walk'; a.timer = 6;
              a.tx = 12 + Math.random() * (this.W - 24);
              a.ty = this.transparent ? a.y : g + Math.random() * Math.max(1, this.H - g - 6);
            } else { a.timer = 1 + Math.random() * 2; a.flip = !a.flip; }
          }
          break;
        case 'sleep':
          if (Math.random() < dt * 0.6) this.fx.push({ shape: 'sleep', x: a.x + 6, y: a.y - this.geom(a).visible * 0.9, vy: -6, vx: 3, life: 1.6, delay: 0, small: true });
          if (a.timer <= 0) { a.state = 'idle'; a.timer = 1; }
          break;
        default:
          if (a.timer <= 0) { a.state = 'idle'; a.timer = 1 + Math.random(); }
      }
      a.x = Math.max(8, Math.min(this.W - 8, a.x));
      if (!this.transparent) a.y = Math.max(g, Math.min(this.H - 3, a.y));
    }
    if (this.ball) {
      const b = this.ball;
      b.vy += 120 * dt; b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
      const floor = this.transparent ? this.H - 4 : g + (this.H - g) / 2;
      if (b.y > floor) { b.y = floor; b.vy *= -0.55; b.vx *= 0.8; }
      if (b.x < 4 || b.x > this.W - 4) b.vx *= -1;
      if (b.life <= 0) this.ball = null;
    }
    this.fx = this.fx.filter((f) => {
      if (f.delay > 0) { f.delay -= dt; return true; }
      f.life -= dt; f.y += f.vy * dt; f.x += f.vx * dt;
      return f.life > 0;
    });
  }

  draw() {
    const { ctx, W, H } = this;
    ctx.imageSmoothingEnabled = false;
    if (this.transparent) ctx.clearRect(0, 0, W, H);
    else {
      ctx.drawImage(this.bank.background('ranch', this.biome, W, H, 3), 0, 0, W, H);
      this.ambient?.draw(ctx);
    }
    const list = [...this.actors.values()].sort((a, b) => a.y - b.y);
    for (const a of list) {
      const g = this.geom(a);
      const { entry } = g;
      const size = g.visible;
      const hop = Math.round(Math.sin(a.hop * Math.PI) * Math.max(2, size * 0.12));
      // shadow
      ctx.fillStyle = 'rgba(20,16,40,0.25)';
      const sw = Math.max(4, Math.round(g.size * (g.box.right - g.box.left) * 0.8));
      ctx.fillRect(Math.round(a.x - sw / 2), Math.round(a.y - 1), sw, 2);
      ctx.fillRect(Math.round(a.x - sw / 2 + 2), Math.round(a.y + 1), sw - 4, 1);
      let anim = 'idle', frame = Math.floor(a.ft * 2);
      if (a.state === 'walk' || a.state === 'chase') { anim = 'walk'; frame = Math.floor(a.ft * 6); }
      else if (a.state === 'sleep') { anim = 'sleep'; frame = Math.floor(a.ft); }
      else if (a.state === 'happy' || a.state === 'eat') { anim = 'happy'; frame = Math.floor(a.ft * 4); }
      else if (a.blink < 0) anim = 'blink';
      const paint = () => drawSprite(ctx, entry, anim, frame, a.x + (!a.flip ? -g.xOff : g.xOff), a.y - hop + 1 + g.size * (1 - g.bottom), g.scale, !a.flip); // sprites face left as drawn: mirror when heading right
      if ((a.appear ?? 1) < 1) {
        // arriving: a beam comes down and the creature fills in from the feet up
        a.appear = Math.min(1, (a.appear ?? 0) + 1 / 70);
        const bw = Math.max(3, Math.round(size * 0.7));
        ctx.fillStyle = `rgba(125,255,207,${(0.55 * (1 - a.appear)).toFixed(3)})`;
        ctx.fillRect(Math.round(a.x - bw / 2), 0, bw, Math.round(a.y));
        const shown = Math.max(0, (a.appear - 0.25) / 0.75);
        ctx.save(); ctx.beginPath(); ctx.rect(0, Math.round(a.y - size * shown), W, Math.ceil(size * shown) + 2); ctx.clip(); paint(); ctx.restore();
        continue;
      }
      paint();
      if (this.selected === a.uid) drawShape(ctx, ['#####', '.###.', '..#..'], '#ffc93c', a.x - 2, a.y - size - 6 - hop);
      if (this.showNames && (this.hover === a.uid || this.selected === a.uid) && a.name) this.label(a.name, a.x, a.y - size - 10 - hop);
    }
    if (this.ball) {
      const b = this.ball;
      drawShape(ctx, ['.###.', '#####', '#####', '#####', '.###.'], '#ff5d5d', b.x - 2, b.y - 2);
      drawShape(ctx, ['.....', '.....', '#####'], '#ffffff', b.x - 2, b.y - 2);
    }
    for (const f of this.fx) {
      if (f.delay > 0) continue;
      const [shape, color] = SHAPES[f.shape];
      ctx.globalAlpha = Math.min(1, f.life * 1.5);
      drawShape(ctx, shape, color, f.x, f.y);
      ctx.globalAlpha = 1;
    }
    if (!this.transparent) {
      const tint = skyTint(this.biome);
      if (tint) { ctx.fillStyle = tint; ctx.fillRect(0, 0, W, H); }
    }
  }

  label(text, x, y) {
    text = brandText(String(text));
    // tiny 3x5 caps are not worth a second font; draw a pill with the canvas font
    const ctx = this.ctx;
    ctx.font = '10px "Capsule Pixel"';
    const w = Math.ceil(ctx.measureText(text).width) + 6;
    const lx = Math.round(Math.max(1, Math.min(this.W - w - 1, x - w / 2))), ly = Math.round(Math.max(1, y - 10));
    ctx.fillStyle = 'rgba(27,24,56,0.85)';
    ctx.fillRect(lx, ly, w, 11);
    ctx.fillStyle = '#ffffff';
    ctx.textBaseline = 'top';
    ctx.fillText(text, lx + 3, ly + 1);
  }

  toLocal(ev) {
    const r = this.canvas.getBoundingClientRect();
    return { x: (ev.clientX - r.left) * (this.W / r.width), y: (ev.clientY - r.top) * (this.H / r.height) };
  }

  hitTest(x, y) {
    const list = [...this.actors.values()].sort((a, b) => b.y - a.y);
    for (const a of list) {
      const g = this.geom(a);
      const half = Math.max(5, g.size * (g.box.right - g.box.left) / 2), tall = Math.max(10, g.visible);
      if (x > a.x - half && x < a.x + half && y > a.y - tall && y < a.y + 2) return a.uid;
    }
    return null;
  }

  bindPointer() {
    const c = this.canvas;
    c.addEventListener('pointerdown', (ev) => {
      const p = this.toLocal(ev);
      const uid = this.hitTest(p.x, p.y);
      this.drag = { uid, start: p, last: p, rub: 0, moved: false, id: ev.pointerId };
      if (uid) { this.selected = uid; this.onSelect(uid); c.setPointerCapture?.(ev.pointerId); }
      else { this.selected = null; this.onSelect(null); }
    });
    c.addEventListener('pointermove', (ev) => {
      const p = this.toLocal(ev);
      const over = this.hitTest(p.x, p.y);
      if (over !== this.hover) { this.hover = over; c.style.cursor = over ? 'grab' : ''; this.onHover?.(over); }
      if (!this.drag?.uid) return;
      const dx = p.x - this.drag.last.x, dy = p.y - this.drag.last.y;
      this.drag.last = p;
      const a = this.actors.get(this.drag.uid);
      if (!a) return;
      if (ev.shiftKey || this.drag.lift) {
        // shift-drag carries the creature somewhere else
        this.drag.lift = true; this.drag.moved = true;
        a.x = p.x; a.y = this.transparent ? a.y : Math.max(this.ground, Math.min(this.H - 3, p.y + 10));
        a.state = 'idle'; a.timer = 2;
        return;
      }
      // rubbing over the creature counts as petting
      this.drag.rub += Math.hypot(dx, dy);
      if (this.drag.rub > 28) {
        this.drag.rub = 0;
        this.react(a.uid, 'hearts', 1);
        this.onPet(a.uid);
      }
    });
    const end = (ev) => {
      if (this.drag?.lift && this.onDrop) this.onDrop(this.drag.uid, this.actors.get(this.drag.uid)?.x, this.actors.get(this.drag.uid)?.y);
      if (this.drag?.uid) c.releasePointerCapture?.(ev.pointerId);
      this.drag = null;
    };
    c.addEventListener('pointerup', end);
    c.addEventListener('pointercancel', end);
    c.addEventListener('pointerleave', () => { if (!this.drag) { this.hover = null; this.onHover?.(null); } });
  }
}
