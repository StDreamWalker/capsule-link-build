// A dropdown you can type into: start typing a name and only the matches show (moves, species,
// natures, items…), instead of scrolling a list of hundreds. options: [{ value, label }].
import { h } from './dom.js';

let n = 0;
export function searchPick(options, value, onPick, { placeholder = 'Type to search…', width = null, allowNone = true } = {}) {
  const id = `sp-${Date.now().toString(36)}-${n++}`;
  // labels must be unique for the browser's list: add the value to any duplicate
  const seen = new Map();
  const opts = options.map((o) => { const k = seen.get(o.label) ?? 0; seen.set(o.label, k + 1); return { ...o, label: k ? `${o.label} (${o.value})` : o.label }; });
  const byLabel = new Map(opts.map((o) => [o.label.toLowerCase(), o.value]));
  const current = () => opts.find((o) => o.value === value)?.label ?? '';
  const input = h('input', {
    type: 'search', list: id, value: current(), placeholder, autocomplete: 'off', class: 'search-pick-input',
    style: width ? { width } : null,
    onfocus: (e) => e.target.select(),
    onchange: (e) => {
      const t = e.target.value.trim();
      if (!t && allowNone) { value = ''; onPick(''); return; }
      let v = byLabel.get(t.toLowerCase());
      // not an exact name: take the only match, or the first that starts with it
      if (v === undefined) { const lt = t.toLowerCase(); const hits = opts.filter((o) => o.label.toLowerCase().includes(lt)); v = (hits.find((o) => o.label.toLowerCase().startsWith(lt)) ?? (hits.length === 1 ? hits[0] : null))?.value; }
      if (v === undefined || v === null) { e.target.value = current(); return; }
      value = v; e.target.value = current(); onPick(v);
    },
  });
  return h('span', { class: 'search-pick' }, input, h('datalist', { id }, opts.map((o) => h('option', { value: o.label }))));
}
