// Battles on Pokémon Showdown's own server, played on the app's battle screen (the 2.5D stage and the Battle
// Revolution menu). Connects to Showdown, picks a name (any name nobody has registered; registered names need
// their password on play.pokemonshowdown.com), then: a Random Battle, a battle with your own party, or a
// challenge to (or from) someone by name. What happens in the battle is entirely Showdown's server: nothing in
// the app changes your creatures (no experience, no HP lost).
import { h } from './dom.js';
import { loadShowdown, playWildBattle } from './showdownWild.js';

const SERVER = 'wss://sim3.psim.us/showdown/websocket';
const toID = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');
const FORMATS = [
  ['gen9randombattle', 'Random Battle', 'A random team each, made by Showdown.'],
  ['gen9anythinggoes', 'Your party: Anything Goes', 'Your own party, checked by Showdown’s rules (it has to be a legal team).'],
  ['gen9nationaldexag', 'Your party: National Dex AG', 'Your own party, with every Pokémon allowed.'],
];
const CUSTOM = 'gen9customgame';

/** A connection to Showdown. fetchText(url) → the text at that address (through the app, so no CORS trouble). */
export function showdownConnection({ fetchText, onGlobal = () => {}, onBattle = () => {} }) {
  const ws = new WebSocket(SERVER);
  const rooms = new Map(); // battle room → { chunk handler, close handler, backlog }
  let challstr = null, user = { name: '', named: false };
  const ready = new Promise((resolve, reject) => {
    ws.onerror = () => reject(new Error('Couldn’t reach Showdown. Check your internet connection.'));
    ws.onclose = () => { for (const r of rooms.values()) r.closed?.(); onGlobal({ kind: 'closed' }); };
    ws.onmessage = (e) => {
      let data = String(e.data), room = '';
      if (data.startsWith('>')) { const nl = data.indexOf('\n'); room = data.slice(1, nl < 0 ? undefined : nl); data = nl < 0 ? '' : data.slice(nl + 1); }
      if (room.startsWith('battle-')) {
        if (!rooms.has(room)) { const r = { backlog: [], on: null, closed: null }; rooms.set(room, r); if (/(^|\n)\|init\|battle/.test(data)) onBattle(room); }
        const r = rooms.get(room);
        if (/(^|\n)\|deinit/.test(data)) { r.closed?.(); rooms.delete(room); return; }
        if (r.on) r.on(data); else r.backlog.push(data);
        return;
      }
      for (const line of data.split('\n')) {
        const [, kind, ...rest] = line.split('|');
        if (kind === 'challstr') { challstr = rest.join('|'); resolve(); }
        else if (kind === 'updateuser') { user = { name: rest[0].replace(/^[ +%@&#~]/, ''), named: rest[1] === '1' }; onGlobal({ kind: 'user', user }); }
        else if (kind === 'popup') onGlobal({ kind: 'popup', text: rest.join('|').replace(/\|\|/g, '\n') });
        else if (kind === 'updatechallenges') { try { onGlobal({ kind: 'challenges', ...JSON.parse(rest.join('|')) }); } catch { /* fine */ } }
        else if (kind === 'updatesearch') { try { onGlobal({ kind: 'search', ...JSON.parse(rest.join('|')) }); } catch { /* fine */ } }
        else if (kind === 'nametaken') onGlobal({ kind: 'popup', text: rest[1] || 'That name is taken.' });
      }
    };
  });
  const send = (text) => { if (ws.readyState === 1) ws.send(text); };
  return {
    ready,
    get user() { return user; },
    /** a name nobody has registered (Showdown asks a registered name for its password) */
    async login(name) {
      await ready;
      const url = `https://play.pokemonshowdown.com/action.php?act=getassertion&userid=${encodeURIComponent(toID(name))}&challstr=${encodeURIComponent(challstr)}`;
      const a = String(await fetchText(url)).trim();
      if (!a || a === ';') throw new Error(`“${name}” is registered on Showdown. Pick a different name (registered names need their password, on play.pokemonshowdown.com).`);
      if (a.startsWith(';;')) throw new Error(a.slice(2));
      if (a.startsWith('<')) throw new Error('Showdown’s login didn’t answer properly. Try again in a moment.');
      send(`|/trn ${name},0,${a}`);
      for (let i = 0; i < 40 && !(user.named && toID(user.name) === toID(name)); i++) await new Promise((r) => setTimeout(r, 150));
      if (!user.named) throw new Error('Showdown didn’t accept that name. Try another.');
      return user;
    },
    search(format, team) { send(`|/utm ${team || 'null'}`); send(`|/search ${format}`); },
    cancel() { send('|/cancelsearch'); },
    challenge(who, format, team) { send(`|/utm ${team || 'null'}`); send(`|/challenge ${who}, ${format}`); },
    accept(who, team) { send(`|/utm ${team || 'null'}`); send(`|/accept ${who}`); },
    reject(who) { send(`|/reject ${who}`); },
    cancelChallenge() { send('|/cancelchallenge'); },
    /** what start() needs to play a battle room */
    room(id) {
      const r = rooms.get(id);
      return {
        onChunk(fn, closed) { r.on = fn; r.closed = closed; for (const d of r.backlog.splice(0)) fn(d); },
        choose(choice, rqid) { send(`${id}|/choose ${choice}${rqid != null ? `|${rqid}` : ''}`); },
        forfeit() { send(`${id}|/forfeit`); },
        isMe(name) { return toID(name) === toID(user.name); },
        close() { send(`|/leave ${id}`); rooms.delete(id); },
      };
    },
    close() { try { ws.close(); } catch { /* gone */ } },
  };
}

/**
 * The online lobby, in a dialog. ctx: what playWildBattle needs (idx, bank, resolve, trainer, settings…);
 * party(): your party as Showdown sets (wildTeams' `team` and `map`); fetchText(url); dialog(title, body, opts).
 */
export async function openShowdownOnline(ctx, { party, fetchText, dialog, getName, setName }) {
  const SD = await loadShowdown();
  let conn = null, busy = false, closeDlg = null;
  const status = h('p', { class: 'micro dim sdo-status', role: 'status' }, 'Not connected.');
  const nameIn = h('input', { type: 'text', maxlength: 18, placeholder: 'Your name on Showdown', value: getName?.() ?? ctx.trainer ?? '' });
  const who = h('input', { type: 'text', maxlength: 18, placeholder: 'Their Showdown name' });
  const fmtSel = h('select', {}, FORMATS.map(([id, label]) => h('option', { value: id }, label)), h('option', { value: CUSTOM }, 'Your party: Custom Game (challenges only, anything goes)'));
  const fmtNote = h('p', { class: 'micro faint' }, FORMATS[0][2]);
  fmtSel.onchange = () => { fmtNote.textContent = FORMATS.find(([id]) => id === fmtSel.value)?.[2] ?? 'Your own party exactly as it is: no rules. Only for challenges.'; };
  const challengesBox = h('div', { class: 'col sdo-challenges' });
  const say = (t) => { status.textContent = t; };
  const mine = () => { const p = party(); return { packed: SD.packTeam(p.team.map(({ hpLeft, ppLeft, ...s }) => s)), map: p.map, count: p.team.length }; };
  const teamFor = (format) => (format === 'gen9randombattle' ? null : mine());

  const play = async (roomId) => {
    if (busy) return; busy = true;
    say('Battle found!');
    const t = currentTeam ?? { map: {} };
    const dlgs = [...document.querySelectorAll('.scrim')]; for (const d of dlgs) d.style.visibility = 'hidden'; // the battle comes up over the lobby
    try {
      await playWildBattle({ ...ctx, foeTrainer: null }, { online: conn.room(roomId), map: t.map ?? {}, team: [], foe: null }, { biome: ctx.biome ?? 'stadium' });
    } catch (e) { console.error(e); say(`The battle stopped: ${e.message}`); }
    for (const d of dlgs) d.style.visibility = '';
    busy = false; currentTeam = null; searchBtn.disabled = false; searchBtn.textContent = 'Find a battle';
    say(`Connected as ${conn.user.name}. Ready for another?`);
  };
  let currentTeam = null;
  const onGlobal = (ev) => {
    if (ev.kind === 'popup') say(ev.text.replace(/<[^>]+>/g, ''));
    else if (ev.kind === 'closed') { say('Disconnected from Showdown.'); conn = null; connectBtn.disabled = false; connectBtn.textContent = 'Connect'; lobby.hidden = true; }
    else if (ev.kind === 'search') { const s = (ev.searching ?? []).length; searchBtn.textContent = s ? 'Cancel search' : 'Find a battle'; if (s) say('Looking for an opponent…'); }
    else if (ev.kind === 'challenges') {
      const from = Object.entries(ev.challengesFrom ?? {});
      challengesBox.replaceChildren(...from.map(([u, f]) => h('div', { class: 'row sdo-chal' }, h('span', {}, `${u} challenges you (${f})`),
        h('button', { class: 'btn small primary', onclick: () => { currentTeam = f.includes('random') ? null : mine(); conn.accept(u, currentTeam?.packed); } }, 'Accept'),
        h('button', { class: 'btn small ghost', onclick: () => conn.reject(u) }, 'Decline'))),
        ev.challengeTo ? h('p', { class: 'micro dim' }, `Waiting for ${ev.challengeTo.to} to answer…`, h('button', { class: 'btn small ghost', onclick: () => conn.cancelChallenge() }, 'Cancel')) : '');
    }
  };
  const connectBtn = h('button', { class: 'btn primary', onclick: async () => {
    const name = nameIn.value.trim();
    if (!toID(name)) { say('Type a name first.'); return; }
    connectBtn.disabled = true; connectBtn.textContent = 'Connecting…';
    try {
      conn?.close();
      conn = showdownConnection({ fetchText, onGlobal, onBattle: (room) => play(room) });
      await conn.ready; const u = await conn.login(name);
      setName?.(u.name);
      say(`Connected as ${u.name}.`); connectBtn.textContent = 'Connected'; lobby.hidden = false;
    } catch (e) { say(e.message); connectBtn.disabled = false; connectBtn.textContent = 'Connect'; conn?.close(); conn = null; }
  } }, 'Connect');
  const searchBtn = h('button', { class: 'btn primary', onclick: () => {
    if (!conn) return;
    if (searchBtn.textContent === 'Cancel search') { conn.cancel(); return; }
    const f = fmtSel.value;
    if (f === CUSTOM) { say('Custom Game is only for challenges: type someone’s name below.'); return; }
    currentTeam = teamFor(f);
    if (currentTeam && !currentTeam.count) { say('Your party is empty.'); return; }
    conn.search(f, currentTeam?.packed); say('Looking for an opponent…');
  } }, 'Find a battle');
  const chalBtn = h('button', { class: 'btn', onclick: () => {
    if (!conn || !toID(who.value)) { say('Type their Showdown name.'); return; }
    currentTeam = teamFor(fmtSel.value); conn.challenge(who.value.trim(), fmtSel.value, currentTeam?.packed); say(`Challenging ${who.value.trim()}…`);
  } }, 'Challenge');
  const lobby = h('div', { class: 'col sdo-lobby', hidden: true },
    h('label', { class: 'col' }, h('span', { class: 'micro dim' }, 'Format'), fmtSel), fmtNote,
    h('div', { class: 'row wrap' }, searchBtn),
    h('div', { class: 'row wrap sdo-chalrow' }, who, chalBtn),
    challengesBox);
  await dialog('Battle on Showdown', (close) => {
    closeDlg = close;
    return h('div', { class: 'col sdo' },
      h('p', { class: 'micro dim' }, 'Real battles against real people on Pokémon Showdown’s server, shown on the app’s battle screen. Nothing that happens there changes your creatures.'),
      h('div', { class: 'row wrap sdo-namerow' }, nameIn, connectBtn), status, lobby,
      h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(null) }, 'Done')));
  });
  void closeDlg;
  conn?.close();
}

/**
 * Watching any Showdown replay on the app's battle screen, just for fun: paste a replay link (or its ID), or open a
 * saved replay file (.html or .log). Nobody's creatures need to be yours. ctx as for openShowdownOnline.
 */
export function replayIdOf(text) {
  const t = String(text ?? '').trim();
  const m = t.match(/replay\.pokemonshowdown\.com\/(?:replay\/)?([a-z0-9]+-[a-z0-9-]+?)(?:\.log|\.json)?(?:[?#].*)?$/i) ?? t.match(/^([a-z0-9]+-\d+(?:-[a-z0-9]+)?)$/i);
  return m ? m[1].replace(/-[a-z0-9]{20,}pw$/i, (x) => x) : null;
}
/** The battle log out of a saved replay page (or the log itself). */
export function replayLogOf(text) {
  const s = String(text ?? '');
  const m = s.match(/<script[^>]*class="battle-log-data"[^>]*>([\s\S]*?)<\/script>/i);
  const log = m ? m[1].replace(/\\\//g, '/') : s;
  return /\|(switch|move|turn|player)\|/.test(log) ? log : null;
}
export async function watchReplay(ctx, { fetchText, dialog }) {
  await loadShowdown();
  const linkIn = h('input', { type: 'text', placeholder: 'https://replay.pokemonshowdown.com/gen9ou-1234567890' });
  const fileIn = h('input', { type: 'file', accept: '.html,.htm,.log,.txt', hidden: true });
  const status = h('p', { class: 'micro dim', role: 'status' }, '');
  let picked = null;
  const play = async (log, title) => {
    const chunks = [log];
    const room = {
      spectate: true, title,
      onChunk(fn) { for (const c of chunks.splice(0)) fn(c); },
      choose() {}, forfeit() {}, isMe() { return false; }, close() {},
    };
    const dlgs = [...document.querySelectorAll('.scrim')]; for (const d of dlgs) d.style.visibility = 'hidden';
    try { await playWildBattle({ ...ctx, foeTrainer: null }, { online: room, map: {}, team: [], foe: null }, { biome: ctx.biome ?? 'stadium' }); }
    catch (e) { console.error(e); status.textContent = `The replay stopped: ${e.message}`; }
    for (const d of dlgs) d.style.visibility = '';
  };
  fileIn.onchange = async () => { const f = fileIn.files?.[0]; if (!f) return; const log = replayLogOf(await f.text()); if (!log) { status.textContent = 'That file doesn’t have a Showdown battle in it.'; return; } picked = { log, title: f.name.replace(/\.[a-z]+$/i, '') }; status.textContent = `Ready: ${picked.title}`; };
  const go = async () => {
    try {
      if (!picked) {
        const id = replayIdOf(linkIn.value);
        if (!id) { status.textContent = 'Paste a replay link from replay.pokemonshowdown.com, or open a saved replay.'; return; }
        status.textContent = 'Fetching the replay…';
        const log = replayLogOf(await fetchText(`https://replay.pokemonshowdown.com/${id}.log`));
        if (!log) { status.textContent = 'Couldn’t find that replay (it may be private or deleted).'; return; }
        picked = { log, title: id };
      }
      status.textContent = '';
      const p = picked; picked = null;
      await play(p.log, p.title);
    } catch (e) { status.textContent = `Couldn’t get the replay: ${e.message}`; }
  };
  await dialog('Watch a replay', (close) => h('div', { class: 'col sdo' },
    h('p', { class: 'micro dim' }, 'Any battle from Pokémon Showdown, played out on the app’s battle screen: paste its replay link, or open a replay you saved.'),
    linkIn, h('div', { class: 'row wrap' }, h('button', { class: 'btn primary', onclick: go }, '▶ Watch'), h('button', { class: 'btn', onclick: () => fileIn.click() }, 'Open a saved replay…'), fileIn),
    status,
    h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(null) }, 'Done'))));
}
