// Mood bubbles: a little face over a creature's head (the R.A.N.C.H. and the desktop buddies).
export const FACES = {
  smile: ['.......', '.#...#.', '.#...#.', '.......', '#.....#', '.#####.', '.......'],
  calm: ['.......', '.......', '##...##', '.......', '.......', '..###..', '.......'],
  tired: ['.......', '.......', '##...##', '.......', '...#...', '..#.#..', '...#...'],
  hungry: ['.......', '.#...#.', '.#...#.', '.......', '..###..', '..#.#..', '..###..'],
  meh: ['.......', '.#...#.', '.#...#.', '.......', '.......', '.#####.', '.......'],
  frown: ['.......', '.#...#.', '.#...#.', '.......', '.#####.', '#.....#', '.......'],
  love: ['.......', '.##.##.', '#######', '#######', '.#####.', '..###..', '...#...'],
  wow: ['.......', '.#...#.', '.#...#.', '.......', '..###..', '..#.#..', '..###..'],
  angry: ['#.....#', '.#...#.', '.......', '.#...#.', '.......', '.#####.', '#.....#'],
  sun: ['...#...', '.#.#.#.', '..###..', '#######', '..###..', '.#.#.#.', '...#...'],
  zzz: ['.......', '####...', '..#....', '.#..###', '####..#', '.....#.', '....###'],
  note: ['...##..', '...#.#.', '...#...', '...#...', '.###...', '####...', '.##....'],
};
export const FACE_COL = { love: '#ff4f86', tired: '#5a6aa8', note: '#5b45c4', frown: '#3b5a9a', angry: '#d6333a', sun: '#e08a00', zzz: '#5a6aa8' };
export const MOOD_FACE = { happy: 'smile', content: 'calm', sleepy: 'tired', hungry: 'hungry', grubby: 'meh', bored: 'frown', upset: 'angry' };

/** Draw a speech bubble with a face. (x, y): the bubble's bottom-left tail point; s: pixel size; pop 0..1 grows it in. */
export function drawFaceBubble(ctx, x, y, s, face, { alpha = 1, pop = 1 } = {}) {
  const rows = FACES[face] ?? FACES.calm;
  const bw = 11 * s, bh = 10 * s;
  const bx = Math.round(x - s * 2), by = Math.round(y - bh - 3 * s);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(x, y); ctx.scale(pop, pop); ctx.translate(-x, -y);
  const blob = (ox, oy, grow, col) => {
    ctx.fillStyle = col;
    ctx.fillRect(bx + ox - grow, by + oy - s - grow, bw + grow * 2, bh + 2 * s + grow * 2);
    ctx.fillRect(bx + ox - s - grow, by + oy - grow, bw + 2 * s + grow * 2, bh + grow * 2);
    ctx.fillRect(bx + ox + s * 2 - grow, by + oy + bh, s * 2 + grow * 2, s * 2 + grow);
    ctx.fillRect(bx + ox + s - grow, by + oy + bh + s * 2, s + grow * 2, s + grow);
  };
  blob(s, s, 0, 'rgba(20,16,40,.35)');
  blob(0, 0, Math.max(1, s / 2), '#2a2448');
  blob(0, 0, 0, '#ffffff');
  ctx.fillStyle = '#e4e8f6'; ctx.fillRect(bx, by + bh - s, bw, s);
  ctx.fillStyle = FACE_COL[face] ?? '#3b3550';
  rows.forEach((row, j) => { for (let i = 0; i < row.length; i++) if (row[i] === '#') ctx.fillRect(bx + (i + 2) * s, by + (j + 1.5) * s, s, s); });
  ctx.restore();
}
