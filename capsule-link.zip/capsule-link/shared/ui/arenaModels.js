// 3D battle arenas, built from low-poly models (like the city ranch's buildings) rather than flat pictures:
// the stadium's tiered stands, roof, floodlights and screen; the colosseum's ring of arched walls; the ruins'
// colonnades and temple; the shrine's gates, hall and cherry trees; the city park's buildings, lamps,
// benches and fountain. Big structures are split into pieces so they sort properly with the creatures.
//
//   arenaProps(kind, { seed, CZ }) → [{ kind, mesh, x, z, h, glow? } | { kind, img, x, z, h, lift? }]
import { mesh, face, box, obox, prism, cone, blob, panel, shade, texQuad } from './models.js';

const rng = (seed) => { let s = (seed >>> 0) || 1; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; };

/** A row of cheering crowd (a picture fixed onto a row of seats). */
function crowdStrip(seed, w = 96, full = 0.88) {
  const r = rng(seed);
  const c = document.createElement('canvas'); c.width = w; c.height = 12;
  const x = c.getContext('2d');
  const shirts = ['#e5484d', '#ffd45e', '#4ad0ff', '#ffffff', '#7dffcf', '#ff8fb6', '#c89bff', '#f2a65a', '#3a6ae8', '#2a2a30', '#5a8a4a'];
  const skins = ['#f2c8a0', '#d8a070', '#a87048', '#7a4a2a', '#ffe0c0'];
  const hair = ['#2a1c14', '#5a3a20', '#d8b060', '#1a1a1a', '#8a4a2a'];
  for (let i = 1; i < w - 5; i += 6) {
    if (r() > full) continue; // an empty seat
    const up = r() < 0.22 ? 2 : 0, sh = shirts[Math.floor(r() * shirts.length)], dx = Math.floor(r() * 2);
    x.fillStyle = sh; x.fillRect(i + dx, 6 - up, 5, 6 + up);
    x.fillStyle = 'rgba(0,0,0,.18)'; x.fillRect(i + dx + 4, 6 - up, 1, 6 + up);
    x.fillStyle = skins[Math.floor(r() * skins.length)]; x.fillRect(i + dx + 1, 3 - up, 3, 3);
    x.fillStyle = hair[Math.floor(r() * hair.length)]; x.fillRect(i + dx + 1, 2 - up, 3, 1);
    if (up && r() < 0.7) { x.fillStyle = sh; x.fillRect(i + dx - 1, 1, 1, 4); x.fillRect(i + dx + 5, 1, 1, 4); } // arms up, cheering
    else if (r() < 0.15) { x.fillStyle = ['#ffd23f', '#e5484d', '#3a6ae8'][Math.floor(r() * 3)]; x.fillRect(i + dx + 4, 0, 3, 3); } // a little flag
  }
  return c;
}
function flag(seed, col) {
  const c = document.createElement('canvas'); c.width = 12; c.height = 24;
  const x = c.getContext('2d');
  x.fillStyle = '#8a7a6a'; x.fillRect(5, 0, 2, 24);
  x.fillStyle = col; x.fillRect(0, 2, 12, 10); x.fillStyle = shade(col, -0.25); x.fillRect(0, 9, 12, 3);
  return c;
}

/** Spread out by `spread` from the middle of the field (the places got bigger in 1.0.0; the models keep their size). */
export const ARENA_SPREAD = { ruins: 1.45, shrine: 1.4, park: 1.4 };
export function arenaProps(kind, opts = {}) {
  const out = buildArena(kind, opts), g = ARENA_SPREAD[kind], CZ = opts.CZ ?? 5;
  if (g) for (const p of out) { p.x *= g; p.z = CZ + (p.z - CZ) * g; if (p.sz != null) { p.sx = (p.sx ?? p.x / g) * g; p.sz = CZ + (p.sz - CZ) * g; } }
  return out;
}
function buildArena(kind, { seed = 1, CZ = 5 } = {}) {
  const out = [];
  const r = rng(seed * 31 + 7);
  const put = (m, x, z, h = 3, extra = {}) => out.push({ kind: 'arena3d', mesh: m, x, z, h, solid: true, ...extra });
  const pic = (img, x, z, h, extra = {}) => out.push({ kind: 'arena', img, x, z, h, solid: true, ...extra });

  // Tiered seating in a local frame: along = across the stand, out = away from the field. Each tier is a riser
  // and a tread, with its row of spectators fixed onto it facing the field (they don't turn with the camera).
  // o = the outward direction [ox, oz]; the mesh is built round the stand's front middle.
  const seating = (m, o, w, { d0 = 0.6, tiers = 10, step = 0.9, rise = 0.62, y0 = 0, cols, crowdSeed, full = 0.9, backWall = true }) => {
    const t = [o[1], -o[0]];
    const P = (la, lo) => [la * t[0] + lo * o[0], la * t[1] + lo * o[1]];
    const quad = (pts, col) => { const k = m.v.length; for (const q of pts) m.v.push(q); face(m, [k, k + 1, k + 2, k + 3], col); };
    for (let k = 0; k < tiers; k++) {
      const a = d0 + k * step, b = a + step, yb = y0 + rise * k, yt = y0 + rise * (k + 1);
      const col = cols[k % cols.length];
      const [p0, p1, q0, q1] = [P(-w / 2, a), P(w / 2, a), P(-w / 2, b), P(w / 2, b)];
      quad([[p0[0], yb, p0[1]], [p0[0], yt, p0[1]], [p1[0], yt, p1[1]], [p1[0], yb, p1[1]]], shade(col, -0.3)); // riser
      quad([[p0[0], yt, p0[1]], [q0[0], yt, q0[1]], [q1[0], yt, q1[1]], [p1[0], yt, p1[1]]], col); // tread
      // that row's crowd, standing on the tread, facing the field
      if (k < tiers - 1 && crowdSeed != null && full > 0) {
        const cA = P(-w / 2, a + 0.28), cB = P(w / 2, a + 0.28);
        texQuad(m, cA, cB, yt - 0.02, yt + 0.44, crowdStrip(crowdSeed + k * 31, Math.round(w * 28), full));
      }
    }
    if (backWall) { const bd = d0 + tiers * step, [b0, b1] = [P(-w / 2, bd), P(w / 2, bd)], top = y0 + rise * tiers + 1.1;
      quad([[b0[0], y0 + rise * tiers, b0[1]], [b0[0], top, b0[1]], [b1[0], top, b1[1]], [b1[0], y0 + rise * tiers, b1[1]]], '#2a2f3c');
      quad([[b1[0], 0, b1[1]], [b1[0], top, b1[1]], [b0[0], top, b0[1]], [b0[0], 0, b0[1]]], '#3a3f4c'); } // its outside
    return { depth: d0 + tiers * step, height: y0 + rise * tiers };
  };

  if (kind === 'stadium') {
    // a big bowl: the field inside a padded barrier, stands all round (the long sides run on round the corners)
    const fx = 14, fzN = CZ - 13, fzF = CZ + 12;
    const seat = ['#2f4a9a', '#2f4a9a', '#c0303a', '#2f4a9a', '#e8b020', '#2f4a9a', '#f0f0f0'];
    const TI = 12, ST = 0.92, RI = 0.62, DEP = 0.6 + TI * ST, SW = 4;
    for (let x0 = -fx; x0 < fx - 0.1; x0 += 2.8) for (const z of [fzN, fzF]) { const m = mesh(); box(m, -1.4, 0, -0.18, 1.4, 1.0, 0.18, '#1f3a8a', { top: '#ffffff' }); panel(m, 0, 0.55, z < CZ ? 0.19 : -0.19, 2.4, 0.32, 0, z < CZ ? 1 : -1, (x0 / 2.8) % 2 ? '#ffd23f' : '#ffffff'); put(m, x0 + 1.4, z, 1); }
    for (let z0 = fzN; z0 < fzF - 0.1; z0 += 2.5) for (const x of [-fx, fx]) { const m = mesh(); box(m, -0.18, 0, -1.25, 0.18, 1.0, 1.25, '#1f3a8a', { top: '#ffffff' }); put(m, x, z0 + 1.25, 1); }
    const stand = (cx, cz, o, w, n) => { const m = mesh(); const cols = Array.from({ length: TI }, (_, k) => (k === 0 ? '#3a3f4c' : shade(seat[(n + Math.floor(k / 3)) % seat.length], (k % 2) * 0.07))); seating(m, o, w, { tiers: TI, step: ST, rise: RI, cols, crowdSeed: seed * 997 + n * 131, full: 0.86 }); put(m, cx, cz, TI * RI + 1); };
    let n = 0;
    for (let x = -fx - DEP; x < fx + DEP - 0.1; x += SW) { const w = Math.min(SW, fx + DEP - x); stand(x + w / 2, fzF + 0.2, [0, 1], w, n++); stand(x + w / 2, fzN - 0.2, [0, -1], w, n++); }
    for (let z = fzN - 0.2; z < fzF + 0.2 - 0.1; z += SW) { const w = Math.min(SW, fzF + 0.2 - z); stand(-fx - 0.2, z + w / 2, [-1, 0], w, n++); stand(fx + 0.2, z + w / 2, [1, 0], w, n++); }
    // a roof over the far stand, on posts
    for (let x0 = -fx - 2; x0 < fx + 2; x0 += 4) {
      const m = mesh(), yR = TI * RI + 3.2;
      box(m, -2, yR, DEP * 0.35, 2, yR + 0.3, DEP + 0.5, '#d8dce8', { top: '#eef0f6' });
      prism(m, 0, DEP + 0.3, 0, yR, 0.16, 0.16, 6, '#8a90a0');
      put(m, x0 + 2, fzF + 0.2, yR, { sz: fzF + DEP });
    }
    // floodlight towers at the corners, outside the stands
    for (const [x, z] of [[-fx - DEP - 2, fzN - DEP - 2], [fx + DEP + 2, fzN - DEP - 2], [-fx - DEP - 2, fzF + DEP + 2], [fx + DEP + 2, fzF + DEP + 2]]) {
      const m = mesh();
      prism(m, 0, 0, 0, 17, 0.4, 0.25, 6, '#7a8090');
      const nz = z < CZ ? 1 : -1, nx = x < 0 ? 1 : -1, l = Math.SQRT2;
      obox(m, 0, 0, 3.6, 0.5, 17, 19.2, Math.atan2(nz, nx) + Math.PI / 2, '#30343e');
      for (let i = 0; i < 4; i++) for (let j = 0; j < 2; j++) panel(m, (nx / l) * 0.27 + (-nz / l) * (-1.3 + i * 0.87), 17.55 + j * 1.05, (nz / l) * 0.27 + (nx / l) * (-1.3 + i * 0.87), 0.7, 0.75, nx / l, nz / l, '#fff8d8');
      put(m, x, z, 19.5, { glow: 2.2, lightY: 18 });
    }
    // the big screen above the far stand
    { const m = mesh(), yS = TI * RI + 4; box(m, -0.35, 0, DEP + 0.6, 0.35, yS, DEP + 1, '#4a505c');
      box(m, -5, yS, DEP + 0.4, 5, yS + 5, DEP + 1.1, '#1c2030');
      panel(m, -2.4, yS + 2.5, DEP + 0.38, 4.4, 4.2, 0, -1, '#d83a3a'); panel(m, 2.4, yS + 2.5, DEP + 0.38, 4.4, 4.2, 0, -1, '#3a6ae8');
      panel(m, 0, yS + 2.5, DEP + 0.37, 0.8, 0.8, 0, -1, '#ffffff');
      put(m, 0, fzF + 0.4, yS + 5, { glow: 0.8, lightY: yS + 2.5 }); }
    // the players' entrance tunnels under the far stand
    for (const x of [-6, 6]) { const m = mesh(); box(m, -1.3, 0, 0, 1.3, 2, 0.7, '#3a3f4c'); panel(m, 0, 0.9, -0.01, 1.8, 1.7, 0, -1, '#0c0e14'); put(m, x, fzF + 0.25, 2); }
    // pennants along the roof
    for (let i = 0; i < 13; i++) pic(flag(seed + i, seat[(i * 2) % seat.length]), -fx + i * (fx * 2 / 12), fzF + DEP, 1.2, { lift: TI * RI + 3.5, decor: true });
    return out;
  }

  if (kind === 'colosseum') {
    // a huge ring: arched walls round the sand, and the seats rising outside them, full of spectators
    const rx = 18, rz = 15, n = 36;
    const stone = '#d8c4a0', dark = '#3a2a20';
    const seatCols = ['#c8b08a', '#bca47e', '#c8b08a', '#b49a74'];
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * Math.PI * 2, a1 = ((i + 1) / n) * Math.PI * 2, am = (a0 + a1) / 2;
      const p0 = [Math.cos(a0) * rx, Math.sin(a0) * rz], p1 = [Math.cos(a1) * rx, Math.sin(a1) * rz];
      const len = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]) + 0.05, ang = Math.atan2(p1[1] - p0[1], p1[0] - p0[0]);
      const cx = (p0[0] + p1[0]) / 2, cz = (p0[1] + p1[1]) / 2;
      const nx = -Math.sin(ang), nz = Math.cos(ang); // facing in, towards the sand
      const m = mesh(), H = 4.6;
      obox(m, 0, 0, len, 1.0, 0, H, ang, stone, { top: shade(stone, 0.15) });
      obox(m, nx * 0.05, nz * 0.05, len + 0.1, 1.2, H, H + 0.35, ang, shade(stone, -0.1));
      for (const [y, hgt] of [[1.4, 2.0], [3.45, 1.2]]) for (const k of [-0.25, 0.25]) panel(m, Math.cos(ang) * len * k + nx * 0.52, y, Math.sin(ang) * len * k + nz * 0.52, len * 0.3, hgt, nx, nz, dark);
      prism(m, p0[0] - cx + nx * 0.8, p0[1] - cz + nz * 0.8, 0, H + 0.2, 0.38, 0.34, 8, '#efe6d2');
      // the seats behind the wall, starting at its top
      seating(m, [-nx, -nz], len + 0.06, { d0: 0.6, y0: H, tiers: 7, step: 0.85, rise: 0.6, cols: seatCols, crowdSeed: seed * 71 + i * 17, full: 0.8 });
      put(m, cx, CZ + cz, H + 5);
      if (i % 4 === 1) { const b = mesh(); obox(b, 0, 0, 0.9, 0.06, 1.8, 4.2, ang, i % 8 === 1 ? '#c0306a' : '#3a6ae8'); put(b, cx + nx * 0.58, CZ + cz + nz * 0.58, 4.2); }
    }
    // torches either side of the gates
    for (const x of [-3.5, 3.5]) { const m = mesh(); prism(m, 0, 0, 0, 2, 0.14, 0.11, 6, '#5a4a3a'); prism(m, 0, 0, 2, 2.3, 0.26, 0.32, 6, '#3a3030'); put(m, x, CZ + rz - 1.4, 2.3, { glow: 0.9, lightY: 2.3 }); }
    return out;
  }

  if (kind === 'ruins') {
    const stone = '#c8c4b4', moss = '#6f9a4a';
    // colonnades either side of the field, many of them broken
    for (const sx of [-1, 1]) for (let i = 0; i < 6; i++) {
      const x = sx * (7.8 + (r() - 0.5) * 0.4), z = -1 + i * 2.4, broken = r() < 0.55, h = broken ? 0.8 + r() * 2.2 : 4;
      const m = mesh();
      box(m, -0.55, 0, -0.55, 0.55, 0.35, 0.55, shade(stone, -0.15), { top: stone });
      prism(m, 0, 0, 0.35, h, 0.38, 0.34, 10, stone);
      if (!broken) box(m, -0.6, h, -0.6, 0.6, h + 0.35, 0.6, shade(stone, 0.05));
      if (r() < 0.6) blob(m, (r() - 0.5) * 0.4, 0.35 + r() * h * 0.6, 0.3, 0.32, 0.25, 0.2, moss, seed + i, { jitter: 0.3 });
      put(m, x, z, h + 0.4);
      if (broken && r() < 0.7) { const f = mesh(); obox(f, 0, 0, 1.3, 0.62, 0, 0.62, r() * 3, shade(stone, -0.05)); put(f, x - sx * (1 + r()), z + (r() - 0.5) * 1.2, 0.6); }
    }
    // lintels still standing on a pair of columns here and there
    { const m = mesh(); box(m, -0.4, 0, -1.6, 0.4, 0.5, 1.6, shade(stone, 0.05)); put(m, -7.8, 4.4, 4.5); }
    // the temple at the back: steps, a row of columns, a pediment
    { const m = mesh(), tz = 14.5;
      for (let k = 0; k < 4; k++) box(m, -6 + k * 0.4, k * 0.35, -1.8 + k * 0.4, 6 - k * 0.4, (k + 1) * 0.35, 2.4, shade(stone, -0.1 + k * 0.04), { top: shade(stone, k * 0.05) });
      for (let i = 0; i < 6; i++) prism(m, -4.2 + i * 1.68, -0.6, 1.4, 5.2, 0.36, 0.32, 10, stone);
      box(m, -5, 5.2, -1.1, 5, 5.8, 1.6, shade(stone, 0.05));
      const b = m.v.length; m.v.push([-5, 5.8, -1.1], [5, 5.8, -1.1], [0, 7.2, -1.1]); // the pediment (facing the field)
      face(m, [b, b + 2, b + 1], shade(stone, -0.05));
      put(m, 0, tz, 7.2); }
    // statues on plinths
    for (const [x, z] of [[-5.2, 11.6], [5.2, 11.6]]) { const m = mesh(); box(m, -0.6, 0, -0.6, 0.6, 1, 0.6, shade(stone, -0.2)); blob(m, 0, 1.6, 0, 0.5, 0.6, 0.45, '#9aa09a', seed + x, { jitter: 0.25 }); blob(m, 0, 2.35, -0.1, 0.32, 0.3, 0.3, '#9aa09a', seed + z); put(m, x, z, 2.7); }
    // a crumbling gateway behind the usual camera
    { const m = mesh(); box(m, -3.2, 0, -0.5, -2.2, 4, 0.5, stone); box(m, 2.2, 0, -0.5, 3.2, 2.6, 0.5, stone); box(m, -3.4, 4, -0.6, 0.6, 4.6, 0.6, shade(stone, 0.05)); put(m, 0, -11.5, 4.6); }
    // overgrowth
    for (let i = 0; i < 14; i++) { const a = r() * Math.PI * 2, d = 10 + r() * 6; const m = mesh(); prism(m, 0, 0, 0, 1.6, 0.18, 0.12, 6, '#6b4a2a'); blob(m, 0, 2.2, 0, 1.2, 1, 1.2, i % 2 ? '#4f8a3a' : '#5f9a44', seed + i * 3); put(m, Math.cos(a) * d * 1.1, CZ + Math.sin(a) * d, 3.2); }
    return out;
  }

  if (kind === 'shrine') {
    const red = '#d0352f', blk = '#2a1c1c', wood = '#8a5a3a';
    const torii = (z, s = 1) => { const m = mesh(); for (const x of [-1.9 * s, 1.9 * s]) prism(m, x, 0, 0, 3.6 * s, 0.2 * s, 0.17 * s, 8, red);
      box(m, -2.4 * s, 2.9 * s, -0.15, 2.4 * s, 3.15 * s, 0.15, red); box(m, -2.9 * s, 3.6 * s, -0.22, 2.9 * s, 3.85 * s, 0.22, blk); box(m, -2.7 * s, 3.45 * s, -0.18, 2.7 * s, 3.6 * s, 0.18, red);
      put(m, 0, z, 3.9 * s); };
    torii(12.6, 1.15); torii(-10.5, 1.15);
    // the hall
    { const m = mesh(), z0 = 0;
      box(m, -4, 0, z0 - 2, 4, 0.8, z0 + 2.4, '#b8b2a8', { top: '#cfc8bc' });
      for (let k = 0; k < 3; k++) box(m, -1.2, 0, z0 - 2.4 - k * 0.3, 1.2, 0.8 - k * 0.27, z0 - 2 - k * 0.3, '#b8b2a8');
      box(m, -3.2, 0.8, z0 - 1.4, 3.2, 3, z0 + 2, wood, { top: wood });
      panel(m, 0, 1.8, z0 - 1.42, 2.2, 1.8, 0, -1, '#f4ead8');
      for (const x of [-3.1, 3.1]) prism(m, x, z0 - 1.5, 0.8, 3, 0.16, 0.16, 8, red);
      const b = m.v.length; // a sweeping gabled roof
      m.v.push([-4.2, 3, z0 - 2.4], [4.2, 3, z0 - 2.4], [4.2, 3, z0 + 3], [-4.2, 3, z0 + 3], [-3.6, 4.8, z0 + 0.3], [3.6, 4.8, z0 + 0.3]);
      const roof = '#3a4a5a';
      const add = (idx, col) => face(m, idx, col);
      add([b, b + 4, b + 5, b + 1], shade(roof, 0.1)); add([b + 2, b + 5, b + 4, b + 3], shade(roof, -0.15)); add([b + 1, b + 5, b + 2], roof); add([b + 3, b + 4, b], roof);
      put(m, 0, 16.5, 4.8); }
    // stone lanterns along the path
    for (const sx of [-1.7, 1.7]) for (let j = 0; j < 3; j++) { const m = mesh(); box(m, -0.3, 0, -0.3, 0.3, 0.2, 0.3, '#9a968e'); prism(m, 0, 0, 0.2, 0.9, 0.1, 0.1, 6, '#a8a49c'); box(m, -0.28, 0.9, -0.28, 0.28, 1.3, 0.28, '#b0aca4'); panel(m, 0, 1.1, -0.29, 0.25, 0.22, 0, -1, '#ffd27a'); cone(m, 0, 0, 1.3, 1.7, 0.42, 6, '#8a867e'); put(m, sx, 10.6 + j * 1.6, 1.7, { glow: 0.6, lightY: 1.1 }); }
    // cherry trees all round, and a low wooden fence
    for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2 + r() * 0.2, d = 10.5 + r() * 3; const m = mesh(); prism(m, 0, 0, 0, 1.8, 0.2, 0.13, 6, '#5a3a2a'); blob(m, 0, 2.5, 0, 1.4, 1.0, 1.4, i % 3 ? '#f2a0c4' : '#e889b2', seed + i); blob(m, 0.4, 3.1, 0.2, 0.9, 0.7, 0.9, '#f8c0d8', seed + i + 50); put(m, Math.cos(a) * d * 1.05, CZ + Math.sin(a) * d * 0.95, 3.6); }
    for (let i = 0; i < 18; i++) { const a = (i / 18) * Math.PI * 2; const x = Math.cos(a) * 9, z = CZ + Math.sin(a) * 7.8; if (z > 11 && Math.abs(x) < 3) continue; if (z < -2 && Math.abs(x) < 3.5) continue; const m = mesh(); obox(m, 0, 0, 3.2, 0.12, 0.45, 0.6, a + Math.PI / 2, wood); prism(m, 0, 0, 0, 0.7, 0.07, 0.07, 4, shade(wood, -0.2)); put(m, x, z, 0.7); }
    return out;
  }

  if (kind === 'prism') {
    // a crystal plaza: tall glassy prisms in pastel colours, pyramids, cubes and rings hanging in the air
    const pastel = ['#ff9ad5', '#9ae8ff', '#fff09a', '#c8a8ff', '#a8ffd8'];
    for (let i = 0; i < 22; i++) {
      const a = (i / 22) * Math.PI * 2 + r() * 0.12, d = 13 + r() * 9, x = Math.cos(a) * d * 1.15, z = CZ + Math.sin(a) * d * 0.95;
      if (z < CZ - 9 && Math.abs(x) < 6) continue; // (clear of the usual camera)
      const col = pastel[i % pastel.length], m = mesh();
      if (i % 3 === 0) { const hgt = 4 + r() * 7; prism(m, 0, 0, 0, hgt, 0.9 + r() * 0.6, 0.15, 6, col); prism(m, 0.9, 0.5, 0, hgt * 0.55, 0.5, 0.1, 6, shade(col, 0.2)); put(m, x, z, hgt, { glow: 0.5, lightY: hgt * 0.8 }); }
      else if (i % 3 === 1) { const hgt = 2.5 + r() * 3; cone(m, 0, 0, 0, hgt, 1.6 + r(), 4, col); put(m, x, z, hgt); }
      else { const y = 2 + r() * 4, sz = 0.6 + r() * 0.8; obox(m, 0, 0, sz * 2, sz * 2, y, y + sz * 2, r() * 3, col, { top: shade(col, 0.25) }); put(m, x, z, y + sz * 2, { glow: 0.4, lightY: y + sz }); }
    }
    // a ring of low glass blocks round the plaza, and gateway rings
    for (let i = 0; i < 26; i++) { const a = (i / 26) * Math.PI * 2, x = Math.cos(a) * 11.5 * 1.1, z = CZ + Math.sin(a) * 11.5 * 0.9; if (z < CZ - 8 && Math.abs(x) < 5) continue; const m = mesh(); obox(m, 0, 0, 2.2, 0.6, 0, 0.7, a + Math.PI / 2, pastel[i % pastel.length], { top: '#ffffff' }); put(m, x, z, 0.7); }
    for (const [x, z] of [[0, CZ + 15], [-14, CZ + 4], [14, CZ + 4]]) { const m = mesh(); const n = 14; for (let k = 0; k < n; k++) { const a0 = (k / n) * Math.PI * 2, a1 = ((k + 1) / n) * Math.PI * 2; const ang = Math.atan2(0, 1); void ang; const p0 = [Math.cos(a0) * 3, 3.6 + Math.sin(a0) * 3], p1 = [Math.cos(a1) * 3, 3.6 + Math.sin(a1) * 3]; const nx = x === 0 ? 0 : 1; box(m, nx ? -0.2 : Math.min(p0[0], p1[0]), Math.min(p0[1], p1[1]), nx ? Math.min(p0[0], p1[0]) : -0.2, nx ? 0.2 : Math.max(p0[0], p1[0]) + 0.05, Math.max(p0[1], p1[1]) + 0.05, nx ? Math.max(p0[0], p1[0]) + 0.05 : 0.2, pastel[k % pastel.length]); } put(m, x, z, 6.6, { glow: 0.8, lightY: 3.6 }); }
    return out;
  }

  if (kind === 'neon') {
    // a neon grid at night: dark monoliths edged in light, glowing arches, pylons, a skyline of light strips
    const neon = ['#ff3dd0', '#3de8ff', '#ffe23a', '#a05aff'];
    for (let i = 0; i < 18; i++) {
      const a = (i / 18) * Math.PI * 2 + r() * 0.1, d = 13 + r() * 8, x = Math.cos(a) * d * 1.15, z = CZ + Math.sin(a) * d * 0.95;
      if (z < CZ - 9 && Math.abs(x) < 6) continue;
      const m = mesh(), col = neon[i % neon.length], hgt = 3 + r() * 8, w = 0.8 + r() * 1.2;
      box(m, -w / 2, 0, -w / 2, w / 2, hgt, w / 2, '#140a2a', { top: '#1e1040' });
      const nx = -Math.cos(a), nz = -Math.sin(a), l = Math.hypot(nx, nz);
      for (const yy of [hgt * 0.25, hgt * 0.55, hgt * 0.85]) panel(m, (nx / l) * (w / 2 + 0.02), yy, (nz / l) * (w / 2 + 0.02), w * 0.85, 0.12, nx / l, nz / l, col);
      box(m, -w / 2 - 0.04, hgt, -w / 2 - 0.04, w / 2 + 0.04, hgt + 0.08, w / 2 + 0.04, col);
      put(m, x, z, hgt, { glow: 0.7, lightY: hgt });
    }
    // glowing arches over the far end and the sides
    for (const [x, z, rot] of [[0, CZ + 13, 0], [-13.5, CZ + 2, 1], [13.5, CZ + 2, 1]]) {
      const m = mesh(), col = neon[(x + 20) % 3 | 0];
      if (rot) { box(m, -0.3, 0, -3.3, 0.3, 5, -2.7, '#1a0c34'); box(m, -0.3, 0, 2.7, 0.3, 5, 3.3, '#1a0c34'); box(m, -0.35, 5, -3.4, 0.35, 5.5, 3.4, '#1a0c34'); panel(m, -0.36, 5.25, 0, 6.4, 0.2, -1, 0, col); panel(m, 0.36, 5.25, 0, 6.4, 0.2, 1, 0, col); for (const zz of [-3, 3]) panel(m, -0.31, 2.5, zz, 0.18, 4.6, -1, 0, col); }
      else { box(m, -3.3, 0, -0.3, -2.7, 5, 0.3, '#1a0c34'); box(m, 2.7, 0, -0.3, 3.3, 5, 0.3, '#1a0c34'); box(m, -3.4, 5, -0.35, 3.4, 5.5, 0.35, '#1a0c34'); panel(m, 0, 5.25, -0.36, 6.4, 0.2, 0, -1, col); for (const xx of [-3, 3]) panel(m, xx, 2.5, -0.31, 0.18, 4.6, 0, -1, col); }
      put(m, x, z, 5.5, { glow: 1.0, lightY: 5.2 });
    }
    // light pylons round the edge of the field
    for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2, x = Math.cos(a) * 11 * 1.1, z = CZ + Math.sin(a) * 11 * 0.9; if (z < CZ - 8 && Math.abs(x) < 5) continue; const m = mesh(), col = neon[i % 2]; prism(m, 0, 0, 0, 1.4, 0.14, 0.1, 6, '#1a0c34'); prism(m, 0, 0, 1.4, 1.75, 0.16, 0.16, 6, col); put(m, x, z, 1.75, { glow: 0.6, lightY: 1.6 }); }
    // the city's skyline far off: towers with strips of light
    for (let i = 0; i < 14; i++) { const a = Math.PI * 0.15 + (i / 13) * Math.PI * 0.7, d = 30 + r() * 6, x = Math.cos(a) * d * 1.2, z = CZ + Math.sin(a) * d; const m = mesh(), w = 2 + r() * 3, hgt = 8 + r() * 14; box(m, -w / 2, 0, -w / 2, w / 2, hgt, w / 2, '#0e0620'); for (let yy = 1.5; yy < hgt; yy += 2.2) panel(m, 0, yy, -(w / 2 + 0.02), w * 0.8, 0.15, 0, -1, neon[(i + Math.round(yy)) % neon.length]); put(m, x, z, hgt); }
    return out;
  }

  if (kind === 'park') {
    // the city park: a court in the middle, a path round it, trees, lamps, benches facing the court, a
    // fountain, hedges, and the city's buildings all around
    for (let i = 0; i < 18; i++) {
      const a = (i / 18) * Math.PI * 2 + r() * 0.15, d = 19 + r() * 6;
      const x = Math.cos(a) * d * 1.15, z = CZ + Math.sin(a) * d, w = 3 + r() * 3, dpt = 3 + r() * 3, hgt = 5 + r() * 11;
      const m = mesh(), col = ['#c8b8a0', '#a8b0c0', '#d8c8b8', '#9098a8', '#b8a090', '#e0d8c8'][i % 6];
      box(m, -w / 2, 0, -dpt / 2, w / 2, hgt, dpt / 2, shade(col, -0.1), { top: shade(col, -0.3) });
      // windows on the side facing the park
      const nx = -Math.cos(a), nz = -Math.sin(a), toward = Math.abs(nx) > Math.abs(nz) ? [Math.sign(nx), 0] : [0, Math.sign(nz)];
      const faceW = toward[0] ? dpt : w;
      for (let fy = 1.2; fy < hgt - 0.8; fy += 1.4) for (let fxx = -faceW / 2 + 0.6; fxx < faceW / 2 - 0.3; fxx += 1.1) {
        const lit = r() < 0.35 ? '#ffe9a8' : '#4a5a78';
        panel(m, toward[0] ? toward[0] * (w / 2 + 0.02) : fxx, fy, toward[1] ? toward[1] * (dpt / 2 + 0.02) : fxx, 0.6, 0.75, toward[0], toward[1], lit);
      }
      put(m, x, z, hgt);
    }
    // trees round the court
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * Math.PI * 2 + 0.1, d = 10.5 + r() * 2;
      const x = Math.cos(a) * d * 1.1, z = CZ + Math.sin(a) * d * 0.95;
      if (z < -1.5 && Math.abs(x) < 4) continue;
      const m = mesh(); prism(m, 0, 0, 0, 1.8, 0.2, 0.14, 6, '#6b4a2a'); blob(m, 0, 2.6, 0, 1.4, 1.2, 1.4, i % 2 ? '#4f9a3f' : '#5aa848', seed + i * 5); blob(m, 0.3, 3.4, -0.2, 0.9, 0.8, 0.9, '#6ab84f', seed + i * 5 + 1);
      put(m, x, z, 4);
    }
    // lamps along the path, benches between them facing the court
    const ring = (k, n, rad) => { const a = (k / n) * Math.PI * 2; return [Math.cos(a) * rad * 1.08, CZ + Math.sin(a) * rad * 0.9, a]; };
    for (let k = 0; k < 10; k++) {
      const [x, z] = ring(k + 0.5, 10, 8.4);
      if (z < -1.5 && Math.abs(x) < 4) continue;
      const m = mesh(); prism(m, 0, 0, 0, 3.2, 0.08, 0.06, 6, '#2a2f3a'); box(m, -0.22, 3.2, -0.22, 0.22, 3.6, 0.22, '#2a2f3a'); box(m, -0.17, 3.25, -0.17, 0.17, 3.55, 0.17, '#fff4c0');
      put(m, x, z, 3.6, { glow: 0.9, lightY: 3.4 });
    }
    for (const k of [1.5, 3.5, 6.5, 8.5]) {
      const [x, z, a] = ring(k, 10, 8.9);
      const m = mesh(); const ang = a + Math.PI / 2;
      obox(m, 0, 0, 1.8, 0.5, 0.42, 0.52, ang, '#9a6a3c', { top: '#b07a48' });
      obox(m, Math.cos(a) * 0.28, Math.sin(a) * 0.28 * 0.9, 1.8, 0.1, 0.52, 1.0, ang, '#9a6a3c');
      for (const s of [-0.75, 0.75]) obox(m, Math.cos(ang) * s, Math.sin(ang) * s, 0.1, 0.45, 0, 0.42, ang, '#2a2f3a');
      put(m, x, z, 1);
    }
    // the fountain at the far end
    { const m = mesh(); prism(m, 0, 0, 0, 0.5, 1.8, 1.8, 14, '#b8b8c4'); prism(m, 0, 0, 0.5, 0.52, 1.6, 1.6, 14, '#5ab0e8', { cap: true }); prism(m, 0, 0, 0.5, 1.4, 0.3, 0.25, 8, '#c8c8d4'); prism(m, 0, 0, 1.4, 1.55, 0.9, 0.9, 10, '#b8b8c4'); prism(m, 0, 0, 1.55, 1.57, 0.8, 0.8, 10, '#7ac8f0'); prism(m, 0, 0, 1.55, 2.3, 0.12, 0.05, 6, '#c8e8ff'); put(m, 0, 15.2, 2.3); }
    // hedges framing it all
    for (let i = 0; i < 12; i++) { const [x, z, a] = ring(i, 12, 12.6); if (z < -2.5 && Math.abs(x) < 6) continue; const m = mesh(); obox(m, 0, 0, 3.4, 0.9, 0, 1.0, a + Math.PI / 2, '#3f8a3a', { top: '#52a048' }); put(m, x, z, 1); }
    return out;
  }
  return out;
}
