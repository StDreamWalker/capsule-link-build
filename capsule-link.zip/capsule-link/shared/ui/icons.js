import { uiArtUrl } from './brandArt.js';
// Line icons (24×24, 1.75 stroke) for the app chrome. Sprites stay pixel art; icons are crisp vectors.
const P = {
  storage: 'M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v11a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5zM4 12h16M12 4v16',
  ranch: 'M3 20h18M5 20v-7l7-5 7 5v7M9.5 20v-4.5h5V20M2 13.5 12 6l10 7.5',
  dock: 'M7 15h10a3 3 0 0 1 3 3v1H4v-1a3 3 0 0 1 3-3zM12 3.5a5 5 0 0 1 5 5V15H7V8.5a5 5 0 0 1 5-5zM7 9h10',
  battle: 'M5 4l7.5 7.5M19 4l-7.5 7.5M3.5 14.5l6 6M14.5 20.5l6-6M7 17l-3 3M17 17l3 3M8 12.5l3.5 3.5M16 12.5 12.5 16',
  id: 'M3.5 7A2.5 2.5 0 0 1 6 4.5h12A2.5 2.5 0 0 1 20.5 7v10a2.5 2.5 0 0 1-2.5 2.5H6A2.5 2.5 0 0 1 3.5 17zM9 13a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM6 16.5c.6-1.5 1.7-2.2 3-2.2s2.4.7 3 2.2M14.5 10h3.5M14.5 13.5h3.5',
  phone: 'M8 2.75h8A1.75 1.75 0 0 1 17.75 4.5v15A1.75 1.75 0 0 1 16 21.25H8a1.75 1.75 0 0 1-1.75-1.75v-15A1.75 1.75 0 0 1 8 2.75zM10.5 18h3',
  lab: 'M9 3h6M10 3v5.5L4.8 17.6A2.3 2.3 0 0 0 6.8 21h10.4a2.3 2.3 0 0 0 2-3.4L14 8.5V3M7.5 14h9',
  settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 13.5a7.7 7.7 0 0 0 0-3l2-1.6-2-3.4-2.4.9a7.6 7.6 0 0 0-2.6-1.5L14 2.5h-4l-.4 2.4A7.6 7.6 0 0 0 7 6.4l-2.4-.9-2 3.4 2 1.6a7.7 7.7 0 0 0 0 3l-2 1.6 2 3.4 2.4-.9a7.6 7.6 0 0 0 2.6 1.5l.4 2.4h4l.4-2.4a7.6 7.6 0 0 0 2.6-1.5l2.4.9 2-3.4z',
  market: 'M4 9.5 5.5 4h13L20 9.5M4 9.5h16M4 9.5a2.7 2.7 0 0 0 5.3 0 2.7 2.7 0 0 0 5.4 0 2.7 2.7 0 0 0 5.3 0M5.5 12.5V20h13v-7.5M10 20v-4.5h4V20',
  activities: 'M12 3.5l2.4 4.9 5.4.8-3.9 3.8.9 5.4L12 15.9l-4.8 2.5.9-5.4-3.9-3.8 5.4-.8zM4 21h16',
  friends: 'M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM2.5 20c.6-3.4 3.2-5.5 6.5-5.5s5.9 2.1 6.5 5.5M16 4.3a3.5 3.5 0 0 1 0 6.4M18.2 14.8c1.8.8 3 2.6 3.3 5.2',
  back: 'M15 5l-7 7 7 7',
  logoff: 'M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 16l-4-4 4-4M6 12h10',
  plus: 'M12 5v14M5 12h14',
  chevron: 'M9 6l6 6-6 6',
  usb: 'M12 3v15M9 6l3-3 3 3M7 10v3l5 3M17 9v2l-5 3M12 18a1.75 1.75 0 1 0 0 3.5 1.75 1.75 0 0 0 0-3.5z',
};

/** An <svg> line icon. */
export function svgIcon(name, { size = 20, cls = 'icon' } = {}) {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', size); svg.setAttribute('height', size);
  svg.setAttribute('fill', 'none'); svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '1.75'); svg.setAttribute('stroke-linecap', 'round'); svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('class', cls);
  const path = document.createElementNS(ns, 'path');
  path.setAttribute('d', P[name] ?? P.plus);
  svg.append(path);
  return svg;
}

/** The Capsule Link mark: an upright capsule with a status light. */
export function logoMark(size = 28) {
  const wrap = document.createElement('span');
  wrap.className = 'logo-mark';
  const custom = uiArtUrl('logo');
  if (custom) {
    const img = document.createElement('img');
    img.src = custom; img.width = size; img.height = size; img.alt = '';
    img.style.objectFit = 'contain';
    wrap.append(img);
    return wrap;
  }
  wrap.innerHTML = `<svg viewBox="0 0 32 32" width="${size}" height="${size}" aria-hidden="true"><defs><linearGradient id="lm" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5b8cff"/><stop offset="1" stop-color="#12b5a5"/></linearGradient></defs><rect x="8" y="3" width="16" height="26" rx="8" fill="url(#lm)"/><path d="M8 15.5h16v5.5a8 8 0 0 1-16 0z" fill="#fff" opacity=".92"/><rect x="8" y="14.5" width="16" height="2" fill="#16171c" opacity=".55"/><circle cx="16" cy="21" r="2" fill="#12b5a5"/></svg>`;
  return wrap;
}
