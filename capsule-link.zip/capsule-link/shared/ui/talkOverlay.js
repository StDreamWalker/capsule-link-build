// Talking to creatures in a yard (the R.A.N.C.H., Quality time): press T, type, Enter. Only the creatures
// you name answer (or everyone listening, if you don't name anyone). They answer like on the phone: a
// picture in a thought bubble over their head, their cry (or a word they know, cut from it), and a line
// at the bottom that fades. What you typed isn't shown over them.
import { h, toast } from './dom.js';
import { itemIcon } from './itemIcon.js';
import { spriteCanvas } from './art.js';
import { creatureCry, sfx } from './audio.js';
import { displayName, speciesOf, itemInfo, wordLabel } from '../engine/index.js';

const MOOD_ICON = { happy: '😊', meh: '😕', sleepy: '💤', worried: '🥺', curious: '❔', content: '🙂', hungry: '🍽️' };

/** A canvas picture for a reply's bubble. */
export function bubblePic(app, out) {
  const b = out?.bubble;
  try {
    if (b?.kind === 'item') return itemIcon(itemInfo(app.idx, b.id) ?? { id: b.id, name: b.id, kind: 'food' }, 32, { idx: app.idx });
    if (b?.kind === 'creature' && app.bank) return spriteCanvas(app.bank, b.speciesId, { scale: 1 });
  } catch { /* fall back to an emoji */ }
  const e = b?.e ?? MOOD_ICON[out?.mood] ?? '❔';
  const cv = document.createElement('canvas'); cv.width = 48; cv.height = 48;
  const x = cv.getContext('2d');
  x.font = '36px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText([...e].slice(0, 2).join(''), 24, 27);
  return cv;
}

/**
 * The talk bar. opts: { app, host (element to put it in), yard, listeners: () => [uid], ask(uid, text, group) → outcome,
 *   onReply(uid, out) }. Returns { open, close, toggle, isOpen, el }.
 */
export function talkOverlay({ app, host, yard, listeners, ask, onReply = null, pick = null, inline = false }) {
  const input = h('input', { type: 'text', class: 'talk-input', maxLength: 200, placeholder: 'Say something… (name someone to talk to just them)' });
  const lines = h('div', { class: 'yard-talk-lines', 'aria-live': 'polite' });
  const el = h('form', { class: 'yard-talk-bar', onsubmit: (e) => { e.preventDefault(); send(input.value); input.value = ''; } },
    h('span', { class: 'yard-talk-key' }, 'T'),
    input,
    h('button', { class: 'btn primary small', type: 'submit' }, 'Say'),
    h('button', { class: 'btn small', type: 'button', title: 'Close (Esc)', onclick: () => close() }, '✕'));
  let open = false;
  if (inline) { const w0 = listeners(); if (w0.length === 1) input.placeholder = `Say something to ${displayName(app.idx, app.save.creatures[w0[0]])}… (try “come here”, “take a nap”, “what do you want to do?”)`; el.classList.add('inline'); el.querySelector('button[title^="Close"]')?.remove(); host.append(el); open = true; }
  input.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); } e.stopPropagation(); });
  host.append(lines);
  function show() {
    if (!open) { host.append(el); open = true; }
    const who = listeners();
    input.placeholder = who.length === 1 ? `Say something to ${displayName(app.idx, app.save.creatures[who[0]])}…` : 'Say something… (name someone to talk to just them)';
    setTimeout(() => input.focus(), 0);
  }
  function close() { if (inline) { input.blur(); return; } if (open) { el.remove(); open = false; } }
  const fade = (node, ms) => { lines.append(node); setTimeout(() => node.classList.add('out'), ms); setTimeout(() => node.remove(), ms + 900); };
  function send(text) {
    text = String(text || '').trim();
    if (!text) return;
    const all = listeners();
    const who = pick ? pick(all, text) : all;
    if (!who.length) { toast('Nobody here to hear you.', 'err'); return; }
    sfx('blip');
    lines.replaceChildren();
    const replies = [];
    for (const uid of who.slice(0, 8)) {
      const out = ask(uid, text, who.length > 1);
      if (out) replies.push([uid, out]);
    }
    // one after another, so the cries don't all land at once
    replies.forEach(([uid, out], i) => setTimeout(() => {
      const c = app.save.creatures[uid];
      if (!c) return;
      yard?.think(uid, bubblePic(app, out), 4.2);
      if (out.emote === 'hearts') yard?.react(uid, 'hearts', 2);
      else if (out.emote === 'note') yard?.react(uid, 'note', 2);
      if (out.note && (replies.length <= 3 || i < 3)) fade(h('div', { class: 'talk-line' }, out.learned ? `${displayName(app.idx, c)} seems to know what “${wordLabel(app.idx, out.learned)}” means now.` : out.note), 4200);
      try { creatureCry(speciesOf(app.idx, c), c, out.pieces ? { chop: out.pieces } : { talk: true, mood: out.mood === 'happy' ? 'happy' : out.mood === 'sleepy' ? 'sleepy' : undefined }); } catch { /* no sound */ }
      if (out.learned) sfx('level');
      if (out.act && yard?.command) yard.command(uid, out.act);
      onReply?.(uid, out);
    }, 450 + i * 520));
    if (replies.length > 3) setTimeout(() => fade(h('div', { class: 'talk-line dim' }, `…and ${replies.length - 3} more of them reacted.`), 4200), 450 + 3 * 520);
  }
  return { open: show, close, toggle: () => (open ? close() : show()), isOpen: () => open, el, destroy: () => { el.remove(); open = false; lines.remove(); } };
}
