// Talking to creatures in a yard (the R.A.N.C.H., Quality time): press T, type, Enter. Only the creatures
// you name answer (or everyone listening, if you don't name anyone). They answer like on the phone: a
// picture in a thought bubble over their head, their cry (or a word they know, cut from it), and a line
// at the bottom that fades. What you typed isn't shown over them.
import { h, toast, confirmDialog } from './dom.js';
import { runChange } from './changeUi.js';
import { itemIcon } from './itemIcon.js';
import { spriteCanvas } from './art.js';
import { creatureCry, sfx } from './audio.js';
import { displayName, speciesOf, itemInfo, wordLabel, mood, topPrefs, inviteOf, directInvite, isAsleep, INVITES, makeEvent, questionOf, answersTo, understand, groupAnswers, namesFor, lastWin, GROUP_STANCES, mindOf, TALK_INTENTS, TALK_EXAMPLES } from '../engine/index.js';
const REQUESTY = /\?|\b(let'?s|wanna|want to|who|anyone|any ?body|everyone|fancy|up for|come (on|with)|shall we|how about)\b/i;
import { warmLlm, llmStatus, llmReact, onLlmStatus, retryLlm, llmIntent, llmRemember } from './localLlm.js';
import { POWERS, powerOf } from '../engine/powers.js';
const ASKS_DO = /\b(can you|could you|would you|will you|please|show (me|us)|let'?s see|use|try|make|do (a|some|your|that|the)|go on|time to)\b|!\s*$|^\s*[a-z][\w' -]{1,20}\s*,/i;

/** How they react, in the on-device language model's words (or the rules' own line until it's ready). */
export function reactLine(app, uid, text, out, { where = null, happening = null } = {}) {
  const c = app.save.creatures[uid];
  // (answers that are facts about them — what they remember, a deal, a song they know — stay in the game's words)
  if (!c || !out?.note || out.learned || out.exact || llmStatus().state !== 'ready') { if (c && out?.note) llmRemember(uid, text, out.note); return Promise.resolve(out?.note ?? null); }
  // asleep (and not woken by it): the game's own line — the model isn't to dream up them waking and wanting things
  const asleep = isAsleep(c) && out.act?.kind !== 'wake';
  if (asleep) { llmRemember(uid, text, out.note); return Promise.resolve(out.note); }
  let likes = ''; try { likes = topPrefs(c, app.idx, 2).map((p) => p.label).join(' and '); } catch { /* fine */ }
  const memories = (c.memories ?? []).slice(-3).map((m) => String(m.text ?? m).slice(0, 90));
  // what's going on in its head (its thoughts, how it feels about you, what it's waiting for, its day), so the words fit it
  let mind = {}; try { mind = mindOf(app.idx, app.save, c); } catch { /* fine */ }
  return llmReact(text, { uid, name: displayName(app.idx, c), species: speciesOf(app.idx, c)?.name, mood: mood(c)?.label?.toLowerCase(), likes, rule: out.note, asleep: false, where, happening, memories, ...mind }).then((l) => {
    if (!l) { llmRemember(uid, text, out.note); return out.note; }
    // the picture follows what they actually made of it: no berry in the bubble unless food came into it
    if (out.bubble?.kind === 'item' && !FOODISH.test(l) && !FOODISH.test(text)) out.bubble = { kind: 'emoji', e: MOOD_ICON[out.mood] ?? '😊' };
    out.llm = true;
    return l;
  }).catch(() => out.note);
}
const FOODISH = /\b(food|berr(y|ies)|snack|eat|ate|hungry|treat|lunch|dinner|breakfast|lick|munch|tast|yum|delicious|cook|feed)/i;

/** A little chip saying how well they understand you: the on-device model loading, ready, or not available. */
export function llmChip() {
  const el = h('span', { class: 'llm-chip', role: 'status' });
  let seen = false, off = null;
  const draw = (st) => {
    if (el.isConnected) seen = true; else if (seen) { off?.(); return; } // (gone from the page: stop listening)
    el.className = `llm-chip ${st.state}`;
    if (st.state === 'ready') { el.textContent = st.upgrading ? `🧠 Understands you · getting smarter… ${Math.round((st.upgrade ?? 0) * 100)}%` : st.model === 'big' ? '🧠 Understands you well' : '🧠 Understands you'; el.title = st.upgrading ? 'The on-device language model is running. A bigger, smarter one (about 500 MB, once) is downloading in the background and takes over when it’s ready.' : 'The on-device language model is running: they take in what you actually say.'; }
    else if (st.state === 'loading') { el.textContent = `🧠 Learning to understand… ${Math.round((st.progress ?? 0) * 100)}%`; el.title = 'Downloading the on-device language model (about 120 MB, once). Until then they go by key words.'; }
    else if (st.state === 'failed') { el.replaceChildren('🧠 Key words only · ', h('button', { class: 'linkish', onclick: () => { retryLlm(); } }, 'retry')); el.title = `The language model couldn't load here (${st.error ?? 'unknown'}). They still go by key words.`; }
    else { el.textContent = '🧠 Key words only (offline)'; el.title = 'Connect to the internet once to download the language model.'; }
  };
  draw(llmStatus());
  off = onLlmStatus(draw);
  return el;
}

const MOOD_ICON = { happy: '😊', meh: '😕', sleepy: '💤', worried: '🥺', curious: '❔', content: '🙂', hungry: '🍽️' };

/** A canvas picture for a reply's bubble. */
export function bubblePic(app, out) {
  const b = out?.bubble;
  try {
    if (b?.kind === 'item') return itemIcon(itemInfo(app.idx, b.id) ?? { id: b.id, name: b.id, kind: 'food' }, 32, { idx: app.idx });
    if (b?.kind === 'creature' && app.bank) return spriteCanvas(app.bank, b.speciesId, { scale: 1 });
  } catch { /* fall back to an emoji */ }
  const e = b?.e ?? MOOD_ICON[out?.mood] ?? '❔';
  const cv = document.createElement('canvas'); cv.width = 48; cv.height = 48;
  const x = cv.getContext('2d');
  x.font = '36px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif';
  x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText([...e].slice(0, 2).join(''), 24, 27);
  return cv;
}

/**
 * The talk bar. opts: { app, host (element to put it in), yard, listeners: () => [uid], ask(uid, text, group) → outcome,
 *   onReply(uid, out) }. Returns { open, close, toggle, isOpen, el }.
 */
export function talkOverlay({ app, host, yard, listeners, ask, onReply = null, pick = null, inline = false, invite = null, onEvolve = null, context = null, doing = null, deal = null }) {
  const input = h('input', { type: 'text', class: 'talk-input', maxLength: 200, placeholder: 'Say something… (name someone to talk to just them)' });
  const lines = h('div', { class: 'yard-talk-lines', 'aria-live': 'polite' });
  const el = h('form', { class: 'yard-talk-bar', onsubmit: (e) => { e.preventDefault(); send(input.value); input.value = ''; } },
    h('span', { class: 'yard-talk-key' }, 'T'),
    input,
    h('button', { class: 'btn primary small', type: 'submit' }, 'Say'),
    h('button', { class: 'btn small', type: 'button', title: 'Close (Esc)', onclick: () => close() }, '✕'),
    llmChip());
  let open = false;
  if (inline) { const w0 = listeners(); if (w0.length === 1) input.placeholder = `Say something to ${displayName(app.idx, app.save.creatures[w0[0]])}… (try “come here”, “take a nap”, “what do you want to do?”)`; el.classList.add('inline'); el.querySelector('button[title^="Close"]')?.remove(); host.append(el); open = true; }
  input.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); } e.stopPropagation(); });
  // (presses on the bar are the bar's: nothing underneath — the yard, its menus — gets them too)
  for (const ev of ['pointerdown', 'mousedown', 'click', 'wheel']) el.addEventListener(ev, (e) => e.stopPropagation());
  el.addEventListener('pointerdown', (e) => { if (e.target === el || e.target.classList?.contains('yard-talk-key')) setTimeout(() => input.focus(), 0); });
  host.append(lines);
  if (typeof window !== 'undefined') window.__understand = (t) => understand(t, { names: namesFor(app.idx, app.save) }); // (handy in the dev tools)
  function show() {
    if (!open) { host.append(el); open = true; }
    warmLlm();
    const who = listeners();
    const tips = ['“who wants to race to the pond?”', '“who likes battling?”', '“whoever wins the next race gets a walk”', '“why are you so happy?”', '“I want to show you some jazz”', '“what did you do today?”', '“do you remember the race?”'];
    const tip = tips[Math.floor(Date.now() / 60000) % tips.length];
    input.placeholder = who.length === 1 ? `Say something to ${displayName(app.idx, app.save.creatures[who[0]])}… (try ${tip})` : `Say something… (try ${tip})`;
    setTimeout(() => input.focus(), 0);
  }
  function close() { if (inline) { input.blur(); return; } if (open) { el.remove(); open = false; } }
  // ---------- the answers card ----------
  let card = null;
  function showAnswers(pool, q, said, given = null) {
    let ans = given ?? [];
    if (!given) { try { ans = answersTo(app.idx, app.save, pool.slice(0, 12), q, { doing }); } catch (e) { console.warn('answers', e); } }
    ans = ans.slice(0, 12);
    if (!ans.length) return;
    card?.remove();
    const shut = () => { card?.remove(); card = null; };
    // they think it over (a moment each, so the app never stalls), then answer one by one
    ans.forEach((a, i) => { try { yard?.think(a.uid, '…', 1 + i * 0.35); } catch { /* fine */ } });
    const rows = ans.map((a) => {
      const c = app.save.creatures[a.uid];
      const row = h('div', { class: 'answer-row pending' },
        spriteCanvas(app.bank, c, { scale: 1 }),
        h('span', { class: 'answer-pic', 'aria-hidden': 'true' }, a.pic),
        h('span', { class: 'answer-text' }, a.text),
        a.inv && invite ? h('button', { class: 'btn small', title: `${displayName(app.idx, c)}: ${a.inv.label}`, onclick: () => { shut(); invite([a.uid], a.inv, said); } }, 'Let’s!') : null);
      return row;
    });
    card = h('div', { class: 'invite-card answers-card', role: 'dialog', 'aria-label': q.label ?? said },
      h('div', { class: 'row', style: { alignItems: 'center', gap: '8px' } }, h('b', { class: 'grow' }, `“${said.length > 60 ? `${said.slice(0, 57)}…` : said}”`), h('button', { class: 'btn small answers-x', 'aria-label': 'Close', onclick: shut }, '✕')),
      h('div', { class: 'col answers-list' }, rows));
    for (const ev of ['pointerdown', 'mousedown', 'click', 'wheel']) card.addEventListener(ev, (e) => e.stopPropagation());
    host.append(card);
    ans.forEach((a, i) => setTimeout(() => {
      const c = app.save.creatures[a.uid]; if (!c || !card) return;
      rows[i].classList.remove('pending');
      try { yard?.think(a.uid, a.pic, 5); if (a.pic === '💕') yard?.react(a.uid, 'hearts', 1.6); } catch { /* fine */ }
      if (a.pic !== '💤') try { creatureCry(speciesOf(app.idx, c), c, { talk: true }); } catch { /* no sound */ }
    }, 700 + i * 380));
    const myCard = card;
    setTimeout(() => { if (card === myCard && !myCard.matches(':hover')) shut(); }, 60000);
  }
  const fade = (node, ms) => { lines.append(node); setTimeout(() => node.classList.add('out'), ms); setTimeout(() => node.remove(), ms + 900); };
  async function send(text) {
    text = String(text || '').trim();
    if (!text) return;
    const all = listeners();
    // what was meant (understand.js): who it's said to, who it's about, and what kind of thing it is
    let P = null;
    try { P = understand(text, { names: namesFor(app.idx, app.save) }); } catch (e) { console.warn('understand', e); }
    const awake = (u) => !isAsleep(app.save.creatures[u]);
    const addressed = (P?.addressees ?? []).filter((u) => all.includes(u));
    const crowd = addressed.length ? addressed : all.filter((u) => !(P?.about ?? []).includes(u) || P?.kind === 'groupQ');
    if (P && all.length) {
      const INV = (id) => INVITES.find((i) => i.id === id);
      // a deal (“whoever wins the next race gets a walk”): everyone listening hears it, and holds you to it
      if (P.kind === 'deal' && deal) { sfx('blip'); lines.replaceChildren(); deal(crowd.filter(awake), P, text); return; }
      // “who wants to battle right now?” — who'd like to, now; “who likes battling?” — their tastes, on a card
      if (P.kind === 'groupQ' && P.stance === 'want' && P.act && invite && INV(P.act.inv)) {
        sfx('blip'); lines.replaceChildren();
        const pool = crowd.filter((u) => awake(u) || P.act.inv === 'nap');
        if (invite(pool, INV(P.act.inv), text, { route: P.route, neg: P.neg }) !== false) return;
      }
      if (P.kind === 'groupQ' && GROUP_STANCES.includes(P.stance)) {
        let rows = null; try { rows = groupAnswers(app.idx, app.save, crowd.filter(awake).length ? crowd.filter(awake) : crowd, P); } catch (e) { console.warn('group answers', e); }
        if (rows?.length) { sfx('blip'); lines.replaceChildren(); showAnswers(crowd, { label: text }, text, rows); return; }
      }
      // “let's race from the hammock to the toy box”, “Cogsy, do you want to go fishing?”: asked of them, they answer, and go
      if ((P.kind === 'propose' || (P.kind === 'ynQ' && P.stance === 'want' && !['snack', 'berries'].includes(P.act?.id))) && P.act && invite && INV(P.act.inv) && (P.kind === 'propose' || addressed.length || all.length <= 2)) {
        sfx('blip'); lines.replaceChildren();
        if (invite((addressed.length ? addressed : all).filter((u) => awake(u) || P.act.inv === 'nap'), INV(P.act.inv), text, { route: P.route, direct: true }) !== false) return;
      }
    }
    // a real question (“who are you friends with?”, “what does everyone want to do?”, “how is everyone?”): each
    // one's actual answer, on a card — from what the game knows about them, so it's right (and instant)
    const q = all.length ? questionOf(text) : null;
    if (q) {
      const named = pick ? pick(all, text, P) : all;
      const pool = ['awake', 'tired'].includes(q.id) ? all : named.length ? named : all;
      if (pool.length) { sfx('blip'); lines.replaceChildren(); showAnswers(pool, q, text); return; }
    }
    // "who wants to …?": asked of the group; the ones who'd like to step forward (the scene handles it). When
    // the rules can't tell what it's for, the language model (if it's running) is asked to place it.
    if (invite && all.length) {
      let inv = inviteOf(text) ?? directInvite(text);
      if ((!inv || inv.id === 'any') && llmStatus().state === 'ready' && REQUESTY.test(text)) {
        for (const u of all.slice(0, 6)) { try { yard?.think(u, '…', 8); } catch { /* fine */ } }
        const id = await llmIntent(text, INVITES.map((i) => ({ id: i.id, label: i.label })));
        if (id) inv = INVITES.find((i) => i.id === id);
      }
      if (inv) {
        // named someone (“Munna, help the others sleep”, “Cogsy and Mindle, race to the tree”)? then just them
        const named = pick ? pick(all, text, P) : all, pool = named.length && named.length < all.length ? named : all;
        sfx('blip'); lines.replaceChildren(); if (invite(pool.filter((u) => !isAsleep(app.save.creatures[u]) || inv.id === 'nap'), inv, text) !== false) return;
      }
    }
    // (said to some of them by name: just them; about someone — “do you like Mindle?” — everyone but Mindle)
    let who = pick ? pick(all, text, P) : addressed.length ? addressed : all;
    // a question with one answer ("does Cogsy like battling?", "who won the race?"): just one of them answers it —
    // the one it's about, or the winner, when they're here
    if (P?.kind === 'thirdQ') { const s0 = P.subject && all.includes(P.subject) && awake(P.subject) ? P.subject : (addressed[0] ?? all.find(awake)); who = s0 ? [s0] : who; }
    if (P?.kind === 'eventQ') { let w0 = null; try { w0 = lastWin(app.idx, app.save, P.act?.id ?? null, P.what === 'lost')?.uid; } catch { /* fine */ } const s0 = w0 && all.includes(w0) && awake(w0) ? w0 : (addressed[0] ?? all.find(awake)); who = s0 ? [s0] : who; }
    if (!who.length) { toast('Nobody here to hear you.', 'err'); return; }
    // asking them to do something the rules can't place (“could you make it feel like a sauna in here?”): the
    // language model (if it's running) picks which of their moves or powers it means
    let heard = text;
    if (llmStatus().state === 'ready' && ASKS_DO.test(text) && !powerOf(text, app.idx) && who.length <= 3) {
      for (const u of who) { try { yard?.think(u, '…', 8); } catch { /* fine */ } }
      const pid = await llmIntent(text, POWERS.map((p) => ({ id: p.id, label: p.label })), { kind: 'power' }).catch(() => null);
      if (pid) heard = `${text} [power:${pid}]`;
    }
    sfx('blip');
    lines.replaceChildren();
    let replies = [];
    for (const uid of who.slice(0, 8)) {
      const out = ask(uid, heard, who.length > 1);
      if (out) replies.push([uid, out]);
    }
    // nobody could make sense of it ("listens closely", "tilts its head"…) and the language model is running: it's asked
    // what kind of thing was said, and then they answer that properly, from their own memories and record
    if (replies.length && replies.every(([, o]) => o.generic) && llmStatus().state === 'ready' && !P?.kind) {
      for (const [u] of replies.slice(0, 4)) { try { yard?.think(u, '…', 8); } catch { /* fine */ } }
      const id = await llmIntent(text, TALK_INTENTS.map((x) => ({ id: x.id, label: x.label })), { kind: 'talk', examples: TALK_EXAMPLES }).catch(() => null);
      const hit = id && TALK_INTENTS.find((x) => x.id === id);
      if (hit) {
        const again = [];
        for (const [uid] of replies) { const out = ask(uid, hit.say, who.length > 1); if (out && !out.generic) again.push([uid, { ...out, understoodAs: hit.label }]); }
        if (again.length) replies = again;
      }
    }
    // (the first few put into the language model's words, while they get ready to answer)
    // while they think it over (in the background), “…” over the head of each one who heard
    const thinking = llmStatus().state === 'ready';
    // (just the first one's put in the model's words: one at a time keeps the computer free — the others answer
    // with their own lines straight away)
    const LLM_N = 1;
    if (thinking) replies.forEach(([uid], i) => { if (i < LLM_N) try { yard?.think(uid, '…', 25); } catch { /* fine */ } });
    let ctx = {}; try { ctx = context?.() ?? {}; } catch { /* fine */ }
    const said = replies.map(([uid, out], i) => (i < LLM_N ? reactLine(app, uid, text, out, ctx) : Promise.resolve(out.note)));
    // one after another, so the cries don't all land at once
    replies.forEach(([uid, out], i) => setTimeout(async () => {
      out = { ...out, note: (await said[i]) ?? out.note };
      const c = app.save.creatures[uid];
      if (!c) return;
      yard?.think(uid, bubblePic(app, out), 4.2);
      if (out.emote === 'hearts') yard?.react(uid, 'hearts', 2);
      else if (out.emote === 'note') yard?.react(uid, 'note', 2);
      if (out.note && (replies.length <= 3 || i < 3)) fade(h('div', { class: 'talk-line' }, out.learned ? `${out.exact && out.note ? `${out.note} ` : ''}(${displayName(app.idx, c)} seems to know what “${wordLabel(app.idx, out.learned)}” means now.)`.replace(/^\((.*)\)$/, '$1') : out.note), out.learned && out.exact ? 6000 : 4200);
      try { creatureCry(speciesOf(app.idx, c), c, out.pieces ? { chop: out.pieces } : { talk: true, mood: out.mood === 'happy' ? 'happy' : out.mood === 'sleepy' ? 'sleepy' : undefined }); } catch { /* no sound */ }
      if (out.learned) sfx('level');
      if (out.act?.kind === 'evolveAsk') { // (it wants to evolve: you say yes or no)
        const key = out.act.key;
        if (onEvolve) onEvolve(uid, key);
        else if (app.commit) setTimeout(() => runChange(app, uid, key).catch(() => {}), 700);
        else if (app.record) setTimeout(async () => { const nm = displayName(app.idx, c), to = app.idx.species.get(out.act.to)?.name ?? 'something new'; if (await confirmDialog(`${nm} wants to evolve!`, `Let ${nm} evolve into ${to}?`, { ok: 'Evolve', cancel: 'Not yet' })) { app.record(makeEvent('change', { uid, key })); sfx('level'); toast(`${nm} evolved into ${to}!`, 'ok'); } }, 700);
      }
      else if (out.act && yard?.command) yard.command(uid, out.act);
      if (out.invite && invite && i === 0) { const inv = INVITES.find((x) => x.id === out.invite); if (inv) setTimeout(() => invite(replies.filter(([, o]) => o.invite === out.invite).map(([u]) => u), inv, text, { direct: true }), 900); }
      onReply?.(uid, out);
    }, 450 + i * 520));
    if (replies.length > 3) setTimeout(() => fade(h('div', { class: 'talk-line dim' }, `…and ${replies.length - 3} more of them reacted.`), 4200), 450 + 3 * 520);
  }
  return { open: show, close, toggle: () => (open ? close() : show()), isOpen: () => open, el, destroy: () => { el.remove(); open = false; lines.remove(); card?.remove(); } };
}
