// Pixel art for things you build in the R.A.N.C.H.: play structures, built-in toys, decorations and
// the Link gate. Same style as paint.js: hard pixels, lit from the upper left, a soft ground shadow.
// Each returns { img, h } where h is how tall it stands, in yard units (a small creature is 1).
import { mk, dab, line, ramp } from './paint.js';
import { shadeHex } from './habitat.js';

const rect = (x, px, py, w, h, col) => { x.fillStyle = col; x.fillRect(Math.round(px), Math.round(py), Math.max(1, Math.round(w)), Math.max(1, Math.round(h))); };
const shadow = (x, cx, cy, rx, ry, a = 0.22) => { x.save(); x.globalAlpha = a; for (let yy = -ry; yy <= ry; yy++) { const half = Math.floor(rx * Math.sqrt(Math.max(0, 1 - (yy * yy) / (ry * ry)))); x.fillStyle = '#10142a'; x.fillRect(Math.round(cx - half), Math.round(cy + yy), half * 2 + 1, 1); } x.restore(); };

const cache = new Map();
export function buildArt(kind, accent = '#e5484d') {
  const key = `${kind}:${accent}`;
  if (!cache.has(key)) cache.set(key, paint(kind, accent));
  return cache.get(key);
}

function paint(kind, accent) {
  switch (kind) {
    case 'slide': {
      const w = 150, h = 120, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 5, w * 0.45, 5);
      const metal = ramp('#9aa6b8', 4, 0.4), sl = ramp(accent, 5, 0.45);
      for (const px of [22, 44]) rect(x, px, 20, 5, h - 26, metal[1]);
      for (let y = 30; y < h - 10; y += 12) rect(x, 22, y, 27, 3, metal[2]);
      rect(x, 18, 18, 34, 6, sl[3]);
      for (let i = 0; i < 90; i++) { const px = 50 + i, py = 22 + i * 0.85 + Math.sin(i / 30) * 4; rect(x, px, py, 2, 8, i < 6 ? sl[4] : sl[2]); rect(x, px, py, 2, 2, sl[4]); }
      return { img: c, h: 2.1 };
    }
    case 'swing': {
      const w = 120, h = 120, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 5, w * 0.42, 5);
      const wood = ramp('#8a5a34', 4, 0.4);
      line(x, 10, h - 4, 30, 8, wood[1], 5); line(x, w - 10, h - 4, w - 30, 8, wood[1], 5);
      rect(x, 26, 6, w - 52, 6, wood[2]);
      line(x, 50, 12, 50, 82, '#b8b0a0', 1); line(x, 70, 12, 70, 82, '#b8b0a0', 1);
      rect(x, 44, 82, 32, 5, accent); rect(x, 44, 82, 32, 2, shadeHex(accent, 0.3));
      return { img: c, h: 2.2 };
    }
    case 'climber': {
      const w = 140, h = 110, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 5, w * 0.45, 5);
      const bars = ramp(accent, 4, 0.4);
      for (let i = 0; i < 6; i++) { const px = 10 + i * 24; line(x, px, h - 6, px + 4, 20, bars[1], 3); }
      for (let y = 26; y < h - 8; y += 16) line(x, 10, y + 4, w - 10, y, bars[2], 3);
      for (let i = 0; i < 5; i++) dab(x, 22 + i * 24, 22, 3, bars[3]);
      return { img: c, h: 1.8 };
    }
    case 'tunnel': {
      const w = 150, h = 70, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, w * 0.46, 5);
      const col = ramp(accent, 5, 0.45);
      for (let yy = 0; yy < 56; yy++) { const half = Math.sqrt(Math.max(0, 1 - ((yy - 56) / 56) ** 2)) * 56; rect(x, 18, h - 6 - yy, w - 36, 1, yy % 9 < 2 ? col[1] : col[3]); if (half < 0) break; }
      for (let yy = -26; yy <= 0; yy++) { const half = Math.sqrt(1 - (yy / 26) ** 2) * 20; rect(x, 18 - half * 0.2, h - 30 + yy, 6, 1, col[4]); }
      dab(x, 22, h - 28, 20, '#1d1630'); dab(x, 22, h - 28, 14, '#0e0a1a');
      return { img: c, h: 1.1 };
    }
    case 'chest': {
      const w = 70, h = 56, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, w * 0.44, 4);
      const wood = ramp('#a0683a', 5, 0.45);
      rect(x, 6, 18, w - 12, h - 24, wood[2]); for (let y = 22; y < h - 6; y += 8) rect(x, 6, y, w - 12, 2, wood[1]);
      rect(x, 4, 8, w - 8, 12, wood[3]); rect(x, 4, 8, w - 8, 3, wood[4]);
      rect(x, w / 2 - 5, 16, 10, 9, '#ffd23f'); rect(x, w / 2 - 2, 19, 4, 4, '#8a5a10');
      dab(x, 18, 8, 5, '#e5484d'); dab(x, w - 20, 7, 4, '#4ad0ff');
      return { img: c, h: 0.8 };
    }
    case 'post': {
      const w = 40, h = 110, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, 16, 4);
      rect(x, 4, h - 12, w - 8, 8, '#8a5a34');
      for (let y = 12; y < h - 12; y++) rect(x, 12, y, 16, 1, y % 4 ? '#d8b77a' : '#b8955a');
      rect(x, 8, 6, 24, 8, accent);
      return { img: c, h: 1.5 };
    }
    case 'hammock': {
      const w = 160, h = 90, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, w * 0.45, 5);
      const wood = ramp('#7a5232', 4, 0.4);
      rect(x, 8, 10, 6, h - 14, wood[1]); rect(x, w - 14, 10, 6, h - 14, wood[1]);
      for (let i = 0; i <= 120; i++) { const t = i / 120, px = 14 + t * (w - 28), py = 22 + Math.sin(t * Math.PI) * 30; rect(x, px, py, 2, 9, i % 10 < 5 ? accent : '#fff6e0'); }
      return { img: c, h: 1.3 };
    }
    case 'fountain': {
      const w = 110, h = 110, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 5, w * 0.46, 6);
      const stone = ramp('#b9b2c8', 5, 0.4);
      for (let yy = 0; yy < 20; yy++) rect(x, 8, h - 26 + yy, w - 16, 1, yy < 4 ? stone[4] : stone[2]);
      rect(x, 14, h - 30, w - 28, 6, '#4aa8ff');
      rect(x, w / 2 - 6, 40, 12, h - 66, stone[3]);
      rect(x, w / 2 - 20, 36, 40, 8, stone[4]);
      for (let i = 0; i < 9; i++) { const a = -Math.PI / 2 + (i - 4) * 0.28; line(x, w / 2, 30, w / 2 + Math.cos(a) * 30, 20 + Math.sin(a) * -4 + Math.abs(i - 4) * 6, '#bfe6ff', 2); }
      return { img: c, h: 1.6 };
    }
    case 'birdbath': {
      const w = 60, h = 80, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, 18, 4);
      const stone = ramp('#c8c2d6', 4, 0.4);
      rect(x, w / 2 - 5, 24, 10, h - 30, stone[2]); rect(x, w / 2 - 12, h - 10, 24, 6, stone[1]);
      rect(x, 6, 16, w - 12, 10, stone[3]); rect(x, 10, 16, w - 20, 4, '#4aa8ff');
      return { img: c, h: 1 };
    }
    case 'statue': {
      const w = 70, h = 120, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, 26, 5);
      const st = ramp('#a8a0ba', 5, 0.45);
      rect(x, 8, h - 30, w - 16, 26, st[2]); rect(x, 8, h - 30, w - 16, 4, st[4]);
      dab(x, w / 2, h - 52, 16, st[3]); dab(x, w / 2 - 10, h - 72, 8, st[3]); dab(x, w / 2 + 10, h - 72, 8, st[3]); dab(x, w / 2, h - 62, 10, st[4]);
      rect(x, w / 2 - 6, h - 64, 3, 3, st[0]); rect(x, w / 2 + 4, h - 64, 3, 3, st[0]);
      return { img: c, h: 1.6 };
    }
    case 'flag': {
      const w = 60, h = 140, { c, x } = mk(w, h);
      shadow(x, 10, h - 4, 10, 3);
      rect(x, 8, 6, 4, h - 10, '#c8c2d6'); dab(x, 10, 6, 4, '#ffd23f');
      for (let i = 0; i < 40; i++) rect(x, 12 + i, 12 + Math.sin(i / 7) * 3, 1, 26, i % 14 < 7 ? accent : shadeHex(accent, 0.25));
      return { img: c, h: 2.4 };
    }
    case 'perch': {
      const w = 60, h = 150, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 4, 18, 4);
      const wood = ramp('#8a5a34', 4, 0.4);
      rect(x, w / 2 - 3, 16, 6, h - 20, wood[1]); rect(x, 6, 14, w - 12, 6, wood[2]); rect(x, 6, 14, w - 12, 2, wood[3]);
      return { img: c, h: 2.6 };
    }
    case 'gate': {
      const w = 220, h = 200, { c, x } = mk(w, h);
      shadow(x, w / 2, h - 6, w * 0.46, 7);
      const st = ramp('#5b45c4', 5, 0.45);
      for (const px of [14, w - 40]) { rect(x, px, 30, 26, h - 36, st[2]); rect(x, px, 30, 6, h - 36, st[4]); }
      for (let i = 0; i <= 60; i++) { const t = i / 60, a = Math.PI * t; rect(x, 26 + t * (w - 52), 40 - Math.sin(a) * 30, 6, 10, st[3]); }
      // the portal: a soft shimmering field between the posts
      x.save(); x.globalAlpha = 0.35; for (let y = 40; y < h - 8; y += 2) rect(x, 40, y, w - 80, 1, y % 6 ? '#7dffcf' : '#c8fff0'); x.restore();
      dab(x, w / 2, 22, 8, '#7dffcf'); dab(x, w / 2, 22, 4, '#ffffff');
      return { img: c, h: 3.4 };
    }
    case 'lily': {
      const w = 40, h = 16, { c, x } = mk(w, h);
      for (let yy = -6; yy <= 6; yy++) { const half = Math.floor(16 * Math.sqrt(1 - (yy / 7) ** 2)); rect(x, w / 2 - half, 8 + yy, half * 2, 1, yy < -2 ? '#7ac85a' : '#4f9a3f'); }
      rect(x, w / 2, 2, 2, 7, '#3a7a30');
      dab(x, w / 2 + 8, 6, 3, '#ffb0d6'); dab(x, w / 2 + 8, 6, 1, '#ffffff');
      return { img: c, h: 0.22 };
    }
    default: return null;
  }
}
