// Choosing which ball picture a creature (or an empty capsule) shows. The list is every ball type
// that has art in the textures folder (ui/ball-<type>.png), plus the standard one.
import { chooseDialog } from './dom.js';
import { ballTypes } from './brandArt.js';
import { ballIcon } from './capsuleArt.js';

export function ballLabel(type) {
  const t = String(type ?? '');
  if (!t || t === 'default') return 'Standard';
  return /^\d+$/.test(t) ? `Type ${t}` : t.replace(/[_-]+/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

/** Resolves to the chosen type ('' for the standard ball) or null when cancelled. */
export async function chooseBall(current = '', { title = 'Which capsule?' } = {}) {
  const types = ['default', ...ballTypes().filter((t) => t !== 'default')];
  const pick = await chooseDialog(title, types.map((t) => ({
    value: t, label: ballLabel(t), detail: (t === 'default' ? !current : t === String(current)) ? 'Current' : '',
    el: ballIcon(t === 'default' ? '' : t, 28, 'closed'),
  })), { empty: 'No capsule pictures yet.' });
  if (pick == null) return null;
  return pick === 'default' ? '' : pick;
}
