// 3D mode: the same scenes drawn as real 3D (three.js, loaded once from a CDN and cached by the browser), in
// the spirit of Pokémon Battle Revolution — solid models, real lighting and shadows, a softish sub-1080p picture.
//
// The scene stays the yard's: its camera, its ground, its models (buildings, stands, trees…) and its creatures
// are mirrored into a three.js scene every frame, rendered, and the picture is laid into the yard's canvas where
// the floor, the models and the creatures used to be drawn. Everything else (sky, effects, bubbles, labels) is
// still drawn by the yard over it, so all the scenes — the R.A.N.C.H., battles, quality time and activities —
// get it at once.
//
// Creatures: a 3D model file of your own when you have one for that species (.glb / .gltf, in the folder chosen
// in Settings → 3D mode), otherwise a solid model built from its sprite (each pixel a block, thicker towards the
// middle, so it has real volume and catches the light).
import { getQuality, qualityLevel } from './quality.js';

const THREE_URL = 'https://cdn.jsdelivr.net/npm/three@0.160.0/+esm';
const GLTF_URL = 'https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/loaders/GLTFLoader.js/+esm';
let loading = null, LIB = null;
const KEY = 'cl3d';
/** 3D mode on (this device)? */
export function is3D() { try { return localStorage.getItem(KEY) === '1'; } catch { return false; } }
const subs = new Set();
export function set3D(on) { try { localStorage.setItem(KEY, on ? '1' : '0'); } catch { /* fine */ } if (on) load3D().catch(() => {}); for (const f of subs) { try { f(!!on); } catch { /* fine */ } } }
export function on3D(fn) { subs.add(fn); return () => subs.delete(fn); }
/** Load three.js (and the model loader) once. Resolves to { THREE, GLTFLoader } or throws (offline). */
export function load3D() {
  if (LIB) return Promise.resolve(LIB);
  loading ??= (async () => {
    const THREE = await import(/* @vite-ignore */ THREE_URL);
    let GLTFLoader = null; try { ({ GLTFLoader } = await import(/* @vite-ignore */ GLTF_URL)); } catch { /* models of your own won't load; sprite models still work */ }
    LIB = { THREE, GLTFLoader };
    return LIB;
  })().catch((e) => { loading = null; throw e; });
  return loading;
}
export function lib3D() { return LIB; }

// ---------- your own model files ----------
// The app looks them up by species: "pikachu.glb", "charizard-mega-x.glb", or the National Dex number "025.glb".
let modelSource = null; // async (names[]) => ArrayBuffer | null   (set by the app: the desktop reads a folder)
export function setModelSource(fn) { modelSource = fn; MODEL_CACHE.clear(); }
const MODEL_CACHE = new Map(); // key -> Promise<gltf scene | null>
function modelNames(sp) {
  const id = (s) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const out = [id(sp?.showdownName), id(sp?.name), id(sp?.id)].filter(Boolean);
  if (sp?.no) out.push(String(sp.no).padStart(3, '0'), String(sp.no));
  return [...new Set(out)];
}
function loadModel(sp) {
  if (!modelSource || !LIB?.GLTFLoader || !sp) return Promise.resolve(null);
  const key = sp.id;
  if (!MODEL_CACHE.has(key)) MODEL_CACHE.set(key, (async () => {
    const buf = await modelSource(modelNames(sp)).catch(() => null);
    if (!buf) return null;
    return await new Promise((res) => { try { new LIB.GLTFLoader().parse(buf, '', (g) => res(g), () => res(null)); } catch { res(null); } });
  })());
  return MODEL_CACHE.get(key);
}

// ---------- sprite → solid block model ----------
const VOX = new Map(); // image -> geometry (or null when the picture can't be read)
function voxelFrom(THREE, img, maxSide) {
  if (VOX.has(img)) return VOX.get(img);
  let geo = null;
  try {
    const w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height;
    const k = Math.min(1, maxSide / Math.max(w0, h0)), W = Math.max(1, Math.round(w0 * k)), H = Math.max(1, Math.round(h0 * k));
    const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const g = cv.getContext('2d', { willReadFrequently: true }); g.imageSmoothingEnabled = false; g.drawImage(img, 0, 0, W, H);
    const px = g.getImageData(0, 0, W, H).data;
    const on = (x, y) => x >= 0 && y >= 0 && x < W && y < H && px[(y * W + x) * 4 + 3] > 96;
    // how far each pixel is from the edge (for thickness): a quick two-pass distance
    const D = new Float32Array(W * H).fill(0);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (on(x, y)) D[y * W + x] = Math.min(x > 0 ? D[y * W + x - 1] : 0, y > 0 ? D[(y - 1) * W + x] : 0) + 1;
    for (let y = H - 1; y >= 0; y--) for (let x = W - 1; x >= 0; x--) if (on(x, y)) D[y * W + x] = Math.min(D[y * W + x], (x < W - 1 ? D[y * W + x + 1] : 0) + 1, (y < H - 1 ? D[(y + 1) * W + x] : 0) + 1);
    let top = H, bot = -1, left = W, right = -1;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (on(x, y)) { top = Math.min(top, y); bot = Math.max(bot, y); left = Math.min(left, x); right = Math.max(right, x); }
    if (bot < 0) { VOX.set(img, null); return null; }
    const thick = (x, y) => (on(x, y) ? Math.min(9, 0.9 + Math.sqrt(D[y * W + x]) * 1.6) : 0);
    const pos = [], col = [];
    const cx = (left + right + 1) / 2;
    const quad = (a, b, c, d, r, gg, bb, shade) => { pos.push(...a, ...b, ...c, ...a, ...c, ...d); for (let i = 0; i < 6; i++) col.push(r * shade, gg * shade, bb * shade); };
    for (let y = top; y <= bot; y++) for (let x = left; x <= right; x++) {
      if (!on(x, y)) continue;
      const i = (y * W + x) * 4, lin = (v) => { v /= 255; return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }, r = lin(px[i]), gg = lin(px[i + 1]), bb = lin(px[i + 2]);
      const t = thick(x, y) / 2, X0 = x - cx, X1 = X0 + 1, Y1 = bot + 1 - y, Y0 = Y1 - 1;
      quad([X0, Y0, t], [X1, Y0, t], [X1, Y1, t], [X0, Y1, t], r, gg, bb, 1); // front
      quad([X1, Y0, -t], [X0, Y0, -t], [X0, Y1, -t], [X1, Y1, -t], r, gg, bb, 0.8); // back
      // sides wherever the neighbour is thinner (or empty): the step between them
      const side = (nx, ny, mk) => { const tn = thick(nx, ny) / 2; if (tn >= t) return; mk(tn); };
      side(x - 1, y, (tn) => { quad([X0, Y0, -t], [X0, Y0, -tn], [X0, Y1, -tn], [X0, Y1, -t], r, gg, bb, 0.72); quad([X0, Y0, tn], [X0, Y0, t], [X0, Y1, t], [X0, Y1, tn], r, gg, bb, 0.72); });
      side(x + 1, y, (tn) => { quad([X1, Y0, t], [X1, Y0, tn], [X1, Y1, tn], [X1, Y1, t], r, gg, bb, 0.72); quad([X1, Y0, -tn], [X1, Y0, -t], [X1, Y1, -t], [X1, Y1, -tn], r, gg, bb, 0.72); });
      side(x, y - 1, (tn) => { quad([X0, Y1, t], [X1, Y1, t], [X1, Y1, tn], [X0, Y1, tn], r, gg, bb, 0.95); quad([X0, Y1, -tn], [X1, Y1, -tn], [X1, Y1, -t], [X0, Y1, -t], r, gg, bb, 0.95); });
      side(x, y + 1, (tn) => { quad([X0, Y0, tn], [X1, Y0, tn], [X1, Y0, t], [X0, Y0, t], r, gg, bb, 0.6); quad([X0, Y0, -t], [X1, Y0, -t], [X1, Y0, -tn], [X0, Y0, -tn], r, gg, bb, 0.6); });
    }
    geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    geo.computeVertexNormals();
    geo.userData.h = bot + 1 - top; geo.userData.w = right + 1 - left;
  } catch { geo = null; } // (a picture from another site without permission can't be read: it stays 2D)
  VOX.set(img, geo);
  return geo;
}

// ---------- the yard's models → three.js ----------
const hex = (c) => { const m = /^#?([0-9a-f]{6})$/i.exec(String(c ?? '')); if (!m) return [0.5, 0.5, 0.5]; const n = parseInt(m[1], 16); return [(n >> 16) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; };
function meshFrom(THREE, m) {
  if (m._g3) return m._g3;
  const pos = [], col = [], group = new THREE.Group();
  const P = (i) => { const v = m.v[i]; return [v[0], v[1], -v[2]]; }; // (the yard's z runs the other way)
  for (const f of m.f) {
    if (f.tex) { // a picture on a face (a crowd in the stands): its own textured quad
      try {
        const [i0, i1, i3] = f.tq, i2 = f.i.find((i) => ![i0, i1, i3].includes(i)) ?? i1;
        const g = new THREE.BufferGeometry();
        g.setAttribute('position', new THREE.Float32BufferAttribute([...P(i0), ...P(i1), ...P(i2), ...P(i0), ...P(i2), ...P(i3)], 3));
        g.setAttribute('uv', new THREE.Float32BufferAttribute([0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1], 2));
        g.computeVertexNormals();
        const t = new THREE.CanvasTexture(f.tex); t.magFilter = THREE.NearestFilter; t.colorSpace = THREE.SRGBColorSpace;
        const q = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ map: t, side: THREE.DoubleSide, transparent: true, alphaTest: 0.1 }));
        q.receiveShadow = true; group.add(q);
      } catch { /* skip */ }
      continue;
    }
    const c = f.base ? f.base.map((v) => v / 255) : hex(f.col);
    const lin = c.map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)); // (colours are sRGB; lighting is linear)
    for (let k = 1; k < f.i.length - 1; k++) { pos.push(...P(f.i[0]), ...P(f.i[k]), ...P(f.i[k + 1])); col.push(...lin, ...lin, ...lin); }
  }
  if (pos.length) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.computeVertexNormals();
    const solid = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide, flatShading: true }));
    solid.castShadow = true; solid.receiveShadow = true; group.add(solid);
  }
  m._g3 = group;
  return group;
}

/** One per yard: keeps a three.js scene in step with it and draws it. */
export class Render3D {
  constructor(yard) {
    const { THREE } = LIB;
    this.T = THREE; this.yard = yard;
    this.canvas = document.createElement('canvas');
    this.r = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: qualityLevel() >= 3, alpha: true, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
    this.r.setPixelRatio(1);
    this.r.outputColorSpace = THREE.SRGBColorSpace;
    this.r.shadowMap.enabled = qualityLevel() >= 2;
    this.r.shadowMap.type = qualityLevel() >= 3 ? THREE.PCFSoftShadowMap : THREE.BasicShadowMap;
    this.scene = new THREE.Scene();
    this.cam = new THREE.PerspectiveCamera(50, 16 / 9, 0.3, 400);
    this.hemi = new THREE.HemisphereLight(0xdfefff, 0x5a6a3a, 0.9); this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff4e0, 1.6); this.sun.castShadow = true;
    const sm = qualityLevel() >= 4 ? 2048 : qualityLevel() >= 3 ? 1536 : 1024;
    this.sun.shadow.mapSize.set(sm, sm); this.sun.shadow.bias = -0.0008; this.sun.shadow.normalBias = 0.03;
    Object.assign(this.sun.shadow.camera, { left: -28, right: 28, top: 28, bottom: -28, near: 1, far: 140 });
    this.scene.add(this.sun, this.sun.target);
    // a soft light from the camera's side, so faces turned to you are never lost in shadow (as the old games lit them)
    this.fill = new THREE.DirectionalLight(0xffffff, 0.55); this.scene.add(this.fill, this.fill.target);
    this.lamps = Array.from({ length: 6 }, () => { const l = new THREE.PointLight(0xffffff, 0, 8, 1.6); this.scene.add(l); return l; });
    this.props = new Map(); this.actors = new Map(); this.fences = null; this.floor = null; this.floorSrc = null;
  }
  dispose() { try { this.r.dispose(); } catch { /* fine */ } }
  /** Has a 3D stand-in for this creature (so the yard doesn't draw its picture). */
  has(uid) { return !!this.actors.get(uid)?.obj; }

  syncCamera(y) {
    const { T, cam } = this;
    cam.aspect = y.W / y.H; cam.fov = (2 * Math.atan((y.H / 2) / (y.F ?? y.H * 1.05)) * 180) / Math.PI; cam.updateProjectionMatrix();
    const s = y.ps, c = y.pc, ys = y.ys, yc = y.yc;
    const f = new T.Vector3(ys * c, -s, -yc * c), u = new T.Vector3(ys * s, c, -yc * s);
    cam.position.set(y.cx, y.camY, -y.cz); cam.up.copy(u); cam.lookAt(cam.position.clone().add(f));
  }
  syncLight(y) {
    const { T } = this, sun = y.sun, night = y.tod === 'night' || y.L?.night || y.L?.cave;
    const sky = y.c?.sky1 ?? [200, 220, 240], gr = y.c?.grid ?? [90, 110, 60];
    this.hemi.color.setRGB(sky[0] / 255, sky[1] / 255, sky[2] / 255, T.SRGBColorSpace); this.hemi.groundColor.setRGB(gr[0] / 300, gr[1] / 300, gr[2] / 300, T.SRGBColorSpace);
    this.hemi.intensity = night ? 0.35 : 0.85;
    if (sun) {
      this.sun.visible = true;
      const d = sun.dir; this.sun.position.set(y.cx + d[0] * 60, d[1] * 60, -(y.cz + d[2] * 60)); this.sun.target.position.set(y.cx, 0, -y.cz);
      this.sun.color.setRGB(sun.c[0] / 255, sun.c[1] / 255, sun.c[2] / 255, T.SRGBColorSpace);
      this.sun.intensity = 0.4 + sun.k * 2.6;
      this.sun.castShadow = this.r.shadowMap.enabled && sun.k > 0.06;
    } else { this.sun.visible = !night; this.sun.castShadow = false; this.sun.intensity = 0.5; this.sun.position.set(y.cx + 10, 40, -y.cz + 10); }
    this.fill.position.set(y.cx, y.camY + 3, -y.cz); this.fill.target.position.set(y.cx + y.ys * 10, 0, -(y.cz + y.yc * 10)); this.fill.intensity = night ? 0.2 : 0.55;
    // lamps, fires, glowing moves: the strongest few near the camera
    const lit = (y.lit ?? []).slice().sort((a, b) => b.i - a.i).slice(0, this.lamps.length);
    this.lamps.forEach((L, i) => { const l = lit[i]; if (!l) { L.intensity = 0; return; } L.position.set(l.x, l.y ?? 1, -l.z); L.color.setRGB(l.c[0] / 255, l.c[1] / 255, l.c[2] / 255, T.SRGBColorSpace); L.distance = (l.r ?? 4) * 1.8; L.intensity = (l.i ?? 1) * (night ? 6 : 3); });
    this.scene.fog = new T.Fog(new T.Color().setRGB(sky[0] / 255, sky[1] / 255, sky[2] / 255, T.SRGBColorSpace), 30, 120);
  }
  syncFloor(y) {
    const { T } = this, F = y.floor;
    if (!F) return;
    // water, lava, ice and hot springs are painted over the ground as it's drawn: bake them in (and look again
    // now and then, for a pond just built)
    this.floorTick = (this.floorTick ?? 0) + 1;
    if (this.floorSrc === F && this.floorTick % 90) return;
    const bytes = new Uint8Array(F.col.buffer, F.col.byteOffset, F.col.byteLength).slice();
    const mat = F.mat, wc = y.c?.water ?? [61, 155, 224], t = y.time ?? 0, TX = F.TXW;
    let sum = 0;
    for (let i = 0, j = 0; i < bytes.length; i += 4, j++) {
      bytes[i + 3] = 255; const m = mat?.[j]; if (!m) continue; sum = (sum + m * (j % 997 + 1)) | 0;
      let r, g, b;
      if (m === 1) { const k = ((j % TX) * 7 + ((j / TX) | 0) * 3) % 29 === 0 ? 0.4 : 0.06; r = wc[0] + (255 - wc[0]) * k; g = wc[1] + (255 - wc[1]) * k; b = wc[2] + (255 - wc[2]) * k; }
      else if (m === 2) { const fl = Math.sin((j % TX) * 0.17 + t) * Math.sin(((j / TX) | 0) * 0.13); [r, g, b] = fl > 0.45 ? [255, 226, 122] : fl > -0.2 ? [255, 138, 61] : [229, 72, 45]; }
      else if (m === 4) [r, g, b] = (j % 23) ? [191, 228, 251] : [255, 255, 255];
      else if (m === 5) [r, g, b] = [126, 207, 211];
      else continue;
      bytes[i] = r; bytes[i + 1] = g; bytes[i + 2] = b;
    }
    if (this.floorSrc === F && this.floorSum === sum) return;
    this.floorSrc = F; this.floorSum = sum;
    if (this.floor) { this.scene.remove(this.floor); this.floor.geometry.dispose(); this.floor.material.map?.dispose(); }
    const { X0, Z0, TEX } = y.S;
    const tex = new T.DataTexture(bytes, F.TXW, F.TXH, T.RGBAFormat); tex.magFilter = T.NearestFilter; tex.minFilter = T.NearestFilter; tex.colorSpace = T.SRGBColorSpace; tex.needsUpdate = true;
    tex.wrapS = tex.wrapT = T.RepeatWrapping;
    const w = F.TXW / TEX, d = F.TXH / TEX, big = y.openFloor ? 5 : 1;
    if (big > 1) tex.repeat.set(big, big);
    const g = new T.PlaneGeometry(w * big, d * big); g.rotateX(-Math.PI / 2); // lies flat: the texture's first row at the near edge, like the yard's
    const m = new T.Mesh(g, new T.MeshLambertMaterial({ map: tex }));
    m.position.set(X0 + w / 2, -0.001, -(Z0 + d / 2));
    m.receiveShadow = true;
    this.floor = m; this.scene.add(m);
  }
  syncProps(y) {
    const seen = new Set();
    for (const p of y.props ?? []) {
      if (!p.mesh) continue;
      seen.add(p);
      let o = this.props.get(p);
      if (!o || o.userData.mesh !== p.mesh) { if (o) this.scene.remove(o); o = meshFrom(this.T, p.mesh).clone(); o.userData.mesh = p.mesh; this.props.set(p, o); this.scene.add(o); }
      o.position.set(p.x, p.float ? p.y + Math.sin(y.time + p.bob) * 0.15 : (p.lift ?? 0), -p.z);
    }
    for (const [p, o] of this.props) if (!seen.has(p)) { this.scene.remove(o); this.props.delete(p); }
    // the fence round the yard (one model, many places)
    const FM = y.fenceMesh, S = y.S;
    if (FM && y.fenceImg && !this.fences) {
      this.fences = new this.T.Group(); const seg = 1.6;
      if (FM.x) for (let x = -S.side + seg / 2; x < S.side; x += seg) { const o = meshFrom(this.T, FM.x).clone(); o.position.set(x, 0, -S.back); this.fences.add(o); }
      if (FM.z) for (const sx of [-S.side, S.side]) for (let z = S.z0 - 1.2; z < S.back; z += 1.1) { const o = meshFrom(this.T, FM.z).clone(); o.position.set(sx, 0, -(z + 0.55)); this.fences.add(o); }
      this.scene.add(this.fences);
    }
  }
  syncActors(y) {
    const { T } = this, seen = new Set(), maxSide = [32, 48, 64, 96, 128][qualityLevel()];
    for (const a of y.actors.values()) {
      if (a.ghost) continue;
      seen.add(a.uid);
      let e = this.actors.get(a.uid);
      if (!e) {
        e = { obj: null, kind: null, root: new T.Group() }; this.actors.set(a.uid, e); this.scene.add(e.root);
        const sp = (y.idx ?? y.bank?.idx)?.species?.get?.(String(a.speciesId).split(':')[0]) ?? null;
        // a model file of your own if there is one; meanwhile (and otherwise) blocks from the sprite
        loadModel(sp).then((g) => { if (!g || !this.actors.has(a.uid)) return; const sc = g.scene.clone(true); sc.traverse((n) => { if (n.isMesh) { n.castShadow = true; n.receiveShadow = true; } });
          const box = new T.Box3().setFromObject(sc), hgt = Math.max(0.01, box.max.y - box.min.y); sc.userData.h = hgt; sc.position.y = -box.min.y;
          const holder = new T.Group(); holder.add(sc); if (e.obj) e.root.remove(e.obj); e.obj = holder; e.kind = 'model'; e.root.add(holder);
          if (g.animations?.length) { e.mixer = new T.AnimationMixer(sc); e.clips = g.animations; const idle = g.animations.find((c) => /idle|wait|stand/i.test(c.name)) ?? g.animations[0]; e.mixer.clipAction(idle).play(); } });
      }
      if (!e.obj && e.kind !== 'model') {
        const entry = y.bank?.get?.(a.speciesId), img = entry?.frames?.idle?.[0] ?? entry?.img;
        const geo = img ? voxelFrom(T, img, maxSide) : null;
        if (geo) { const m = new T.Mesh(geo, new T.MeshLambertMaterial({ vertexColors: true, flatShading: true })); m.castShadow = true; m.receiveShadow = true; const holder = new T.Group(); holder.add(m); m.userData.h = geo.userData.h; e.obj = holder; e.kind = 'vox'; e.root.add(holder); }
        else if (img) e.kind = 'none';
      }
      if (!e.obj) continue;
      // size, place, facing and a little life
      const H = y.heightOf?.(a) ?? 1, inner = e.obj.children[0], h0 = inner.userData.h ?? 1, k = H / h0;
      e.obj.scale.setScalar(k * (a.appear ?? 1));
      const moving = a.state === 'walk' || a.state === 'chase' || a.state === 'return';
      const bob = moving ? Math.abs(Math.sin(y.time * 10)) * 0.06 * H : Math.sin(y.time * 2 + a.uid.length) * 0.015 * H;
      const hop = Math.sin((a.hop ?? 0) * Math.PI) * 0.35 * Math.min(1, H);
      const P0 = a.pose; // (a battle's lunges and recoils: the same push, in the world)
      e.root.position.set(a.x + (P0?.dx ?? 0) * H * 0.8, (a.y || 0) + bob + hop - (P0?.dy ?? 0) * H * 0.5, -a.z);
      if (P0) e.obj.rotation.z = -(P0.lean ?? 0); else e.obj.rotation.z = 0;
      // hit: a white flash; a status: tinted
      const mat = inner.material; if (mat?.emissive) { const fl = a.hitFlash > 0 ? 0.85 : 0; const tint = { psn: [0.25, 0, 0.3], brn: [0.35, 0.05, 0], par: [0.3, 0.25, 0], frz: [0, 0.2, 0.35] }[a.tint] ?? [0, 0, 0]; mat.emissive.setRGB(fl + tint[0] * (a.tintK ?? 1), fl + tint[1] * (a.tintK ?? 1), fl + tint[2] * (a.tintK ?? 1)); }
      // which way: away from the camera when seen from behind in battle, otherwise turned mostly to the camera,
      // leaning the way it walks
      const toCam = Math.atan2(y.cx - a.x, a.z - y.cz);
      let yaw = a.battleBack ? toCam + Math.PI : toCam;
      if (!a.battleBack && moving) yaw += (a.flip ? -1 : 1) * 0.55;
      e.root.rotation.y += ((yaw - e.root.rotation.y + Math.PI * 3) % (Math.PI * 2) - Math.PI) * 0.2;
      if (e.kind === 'vox') inner.scale.x = a.flip && !a.battleBack ? -1 : 1;
      e.root.visible = (a.alpha ?? 1) > 0.05 && !a.sink;
      if (e.mixer) e.mixer.update(1 / 60);
    }
    for (const [uid, e] of this.actors) if (!seen.has(uid)) { this.scene.remove(e.root); this.actors.delete(uid); }
  }
  /** Draw the scene; returns the canvas to lay into the yard's picture. */
  render() {
    const y = this.yard;
    if (this.canvas.width !== y.W || this.canvas.height !== y.H) this.r.setSize(y.W, y.H, false);
    this.syncCamera(y); this.syncLight(y); this.syncFloor(y); this.syncProps(y); this.syncActors(y);
    this.r.render(this.scene, this.cam);
    return this.canvas;
  }
}
export { getQuality };

// ---------- a single creature drawn in 3D into a picture (desktop buddies) ----------
// One small 3D view, reused: the creature's model (yours, or blocks from its sprite) lit from the front and
// above, turned the way it's walking; the result is drawn where its sprite would go.
let snap = null;
export function drawModelSnap(ctx, { sp, img, uid, x, y, w, h, turn = 0, t = 0, moving = false, flip = false }) {
  if (!LIB || !img) return false;
  const { THREE: T } = LIB;
  if (!snap) {
    const canvas = document.createElement('canvas'); canvas.width = canvas.height = 256;
    const r = new T.WebGLRenderer({ canvas, alpha: true, antialias: true, preserveDrawingBuffer: true }); r.setPixelRatio(1); r.outputColorSpace = T.SRGBColorSpace;
    const scene = new T.Scene(); scene.add(new T.HemisphereLight(0xffffff, 0x60607a, 1.1)); const key = new T.DirectionalLight(0xffffff, 1.8); key.position.set(-2, 4, 5); scene.add(key);
    const cam = new T.PerspectiveCamera(22, 1, 0.1, 100);
    snap = { r, scene, cam, holder: new T.Group(), models: new Map() }; scene.add(snap.holder);
  }
  let m = snap.models.get(uid);
  if (!m) {
    m = { obj: null }; snap.models.set(uid, m);
    loadModel(sp).then((g) => { if (!g) return; const sc = g.scene.clone(true); const box = new T.Box3().setFromObject(sc); sc.position.y = -box.min.y; sc.userData.h = box.max.y - box.min.y; m.obj = sc; m.kind = 'model'; });
  }
  if (!m.obj) { const geo = voxelFrom(T, img, 96); if (!geo) return false; const mesh = new T.Mesh(geo, new T.MeshLambertMaterial({ vertexColors: true, flatShading: true })); mesh.userData.h = geo.userData.h; m.obj = mesh; m.kind = 'vox'; }
  const o = m.obj, hgt = o.userData.h || 1;
  snap.holder.clear(); snap.holder.add(o);
  o.scale.set(m.kind === 'vox' && !flip ? -1 : 1, 1, 1);
  snap.holder.rotation.y = turn + (moving ? Math.sin(t * 8) * 0.06 : Math.sin(t * 1.3) * 0.12);
  // frame it: the whole creature, a little from above
  const dist = hgt * 4.4; snap.cam.position.set(0, hgt * 0.75, dist); snap.cam.lookAt(0, hgt * 0.48, 0);
  snap.r.render(snap.scene, snap.cam);
  ctx.drawImage(snap.r.domElement, x, y, w, h);
  return true;
}
