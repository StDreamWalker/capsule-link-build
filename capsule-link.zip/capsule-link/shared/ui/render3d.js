// 3D mode: the same scenes drawn as real 3D (three.js, loaded once from a CDN and cached by the browser), in
// the spirit of Pokémon Battle Revolution — solid models, real lighting and shadows, a softish sub-1080p picture.
//
// The scene stays the yard's: its camera, its ground, its models (buildings, stands, trees…) and its creatures
// are mirrored into a three.js scene every frame, rendered, and the picture is laid into the yard's canvas where
// the floor, the models and the creatures used to be drawn. Everything else (sky, effects, bubbles, labels) is
// still drawn by the yard over it, so all the scenes — the R.A.N.C.H., battles, quality time and activities —
// get it at once.
//
// Creatures: a 3D model file of your own when you have one for that species (.glb / .gltf, in the folder chosen
// in Settings → 3D mode), otherwise a solid model built from its sprite (each pixel a block, thicker towards the
// middle, so it has real volume and catches the light).
import { getQuality, qualityLevel } from './quality.js';
import { propMesh, MODEL_KINDS } from './models.js';
import { DEX_NUMS } from './dexNums.js';

const V = '0.160.0', CDN = `https://cdn.jsdelivr.net/npm/three@${V}`;
const THREE_URL = `${CDN}/+esm`;
const GLTF_URL = `${CDN}/examples/jsm/loaders/GLTFLoader.js/+esm`;
const DRACO_URL = `${CDN}/examples/jsm/loaders/DRACOLoader.js/+esm`;
const DRACO_PATH = `${CDN}/examples/jsm/libs/draco/gltf/`; // (the models are squeezed with Draco; its decoder)
let loading = null, LIB = null;
const KEY = 'cl3d';
/** 3D mode on (this device)? */
export function is3D() { try { return localStorage.getItem(KEY) === '1'; } catch { return false; } }
const subs = new Set();
export function set3D(on) { try { localStorage.setItem(KEY, on ? '1' : '0'); } catch { /* fine */ } if (on) load3D().catch(() => {}); for (const f of subs) { try { f(!!on); } catch { /* fine */ } } }
export function on3D(fn) { subs.add(fn); return () => subs.delete(fn); }
/** Load three.js (and the model loader) once. Resolves to { THREE, GLTFLoader, gltf } or throws (offline). */
export function load3D() {
  if (LIB) return Promise.resolve(LIB);
  loading ??= (async () => {
    const THREE = await import(/* @vite-ignore */ THREE_URL);
    let GLTFLoader = null, gltf = null;
    try {
      ({ GLTFLoader } = await import(/* @vite-ignore */ GLTF_URL));
      gltf = new GLTFLoader();
      try { const { DRACOLoader } = await import(/* @vite-ignore */ DRACO_URL); const d = new DRACOLoader(); d.setDecoderPath(DRACO_PATH); gltf.setDRACOLoader(d); } catch { /* only unsqueezed models then */ }
    } catch { /* no models; sprite models still work */ }
    LIB = { THREE, GLTFLoader, gltf };
    return LIB;
  })().catch((e) => { loading = null; throw e; });
  return loading;
}
export function lib3D() { return LIB; }

// ---------- the Pokémon's 3D models ----------
// From the open Pokémon 3D model collection on GitHub (Pokemon-3D-api/assets: one .glb per Pokémon by National Dex
// number, plus shiny, Mega, regional and Gigantamax ones), fetched the first time each is needed and kept on this
// device. On the PC a folder of model files of your own comes first ("pikachu.glb", "charizard-mega-x.glb",
// "025.glb"). A Pokémon with no model anywhere is built from its sprite instead.
export const MODEL_REPO = 'https://raw.githubusercontent.com/Pokemon-3D-api/assets/main/models/opt/';
const WEB_KEY = 'cl3dweb', STORE = 'cl-models-v1';
export function webModelsOn() { try { return localStorage.getItem(WEB_KEY) !== '0'; } catch { return true; } }
export function setWebModels(on) { try { localStorage.setItem(WEB_KEY, on ? '1' : '0'); } catch { /* fine */ } MODEL_CACHE.clear(); }
let modelSource = null; // async (names[]) => ArrayBuffer | null   (set by the app: the desktop reads a folder)
export function setModelSource(fn) { modelSource = fn; MODEL_CACHE.clear(); }
const MODEL_CACHE = new Map(); // key -> Promise<gltf | null>
const slug = (s) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
function modelNames(sp, form) {
  const out = [form && slug(form), slug(sp?.showdownName), slug(sp?.name), slug(sp?.id)].filter(Boolean);
  if (sp?.no) out.push(String(sp.no).padStart(3, '0'), String(sp.no));
  return [...new Set(out)];
}
/** Where in the collection: the form's folder first, then shiny, then the regular one. */
export function webPaths(no, form = '', shiny = false) {
  if (!no) return [];
  const f = slug(form), out = [];
  if (/mega/.test(f)) { if (/mega-?x$/.test(f)) out.push(`x/${no}.glb`); if (/mega-?y$/.test(f)) out.push(`y/${no}.glb`); if (shiny) out.push(`megaShiny/${no}.glb`); out.push(`mega/${no}.glb`); }
  else if (/gmax|gigantamax/.test(f)) out.push(`gmax/${no}.glb`);
  else if (/alola/.test(f)) out.push(`alolan/${no}.glb`);
  else if (/galar/.test(f)) out.push(`galar/${no}.glb`);
  else if (/hisui/.test(f)) out.push(`hisuian/${no}.glb`);
  if (shiny) out.push(`shiny/${no}.glb`);
  out.push(`regular/${no}.glb`);
  return out;
}
/** One model file from the collection (kept on this device after the first time); null if it has none. */
export async function fetchWebModel(path) {
  const url = MODEL_REPO + path, api = typeof window !== 'undefined' ? window.capsule : null;
  // kept on this device: in the app's own folder on the PC, in the browser's storage elsewhere
  let store = null;
  if (api?.modelCacheGet) { const hit = await api.modelCacheGet(path).catch(() => null); if (hit === 'none') return null; if (hit) return hit; }
  else { try { store = await caches.open(STORE); const hit = await store.match(url); if (hit) return hit.status === 200 ? await hit.arrayBuffer() : null; } catch { store = null; } }
  const keep = async (buf) => { try { if (api?.modelCachePut) await api.modelCachePut(path, buf); else await store?.put(url, buf ? new Response(buf.slice(0), { headers: { 'content-type': 'model/gltf-binary' } }) : new Response('', { status: 404 })); } catch { /* fine */ } };
  let res = null; try { res = await fetch(url, { mode: 'cors' }); } catch { return null; } // (offline: try again another time)
  if (res.status === 404) { await keep(null); return null; } // (remember it has none)
  if (!res.ok) return null;
  const buf = await res.arrayBuffer();
  await keep(buf);
  return buf;
}
/** How many models are kept on this device (for Settings). */
export async function webModelCount() { const api = typeof window !== 'undefined' ? window.capsule : null; if (api?.modelCacheCount) return api.modelCacheCount().catch(() => 0); try { const st = await caches.open(STORE); return (await st.keys()).length; } catch { return 0; } }
/** Fetch the models for these creatures (sprite ids) ahead of time (Download everything), and the model
 *  decoder. Resolves to { got, of } (how many have a model in the collection). */
export async function prefetchFor(idx, ids, onEach) {
  try { await Promise.all(['draco_wasm_wrapper.js', 'draco_decoder.wasm'].map((f) => fetch(DRACO_PATH + f).catch(() => null))); } catch { /* fine */ }
  const seen = new Set(), list = [];
  for (const id of ids) { const w = whoIs(idx, id); if (!w.no) continue; const k = `${w.no}|${w.form}|${w.shiny}`; if (!seen.has(k)) { seen.add(k); list.push(w); } }
  const got = await prefetchModels(list, onEach);
  return { got, of: list.length };
}
/** Fetch the models for these creatures ahead of time. */
export async function prefetchModels(list, onEach) {
  let got = 0, i = 0;
  for (const { no, form, shiny } of list) { i++; for (const p of webPaths(no, form, shiny)) { if (await fetchWebModel(p)) { got++; break; } } onEach?.(i, got); }
  return got;
}
// a second copy of a model (its bones and skin with it)
function cloneModel(src) {
  const map = new Map(), out = src.clone(true);
  const walk = (a, b) => { map.set(a, b); for (let i = 0; i < a.children.length; i++) walk(a.children[i], b.children[i]); };
  walk(src, out);
  out.traverse((n) => { if (n.isSkinnedMesh) { const o = [...map.entries()].find(([, v]) => v === n)?.[0]; if (o?.skeleton) { n.bind(new LIB.THREE.Skeleton(o.skeleton.bones.map((bn) => map.get(bn) ?? bn), o.skeleton.boneInverses), o.bindMatrix); } } });
  return out;
}
const parse = (buf) => new Promise((res) => { try { LIB.gltf.parse(buf, '', (g) => res(g), () => res(null)); } catch { res(null); } });
/** The model for a Pokémon (your own file first, then the collection), or null. */
function loadModel(who) {
  const { sp, no, form = '', shiny = false } = who ?? {};
  if (!LIB?.gltf || (!sp && !no)) return Promise.resolve(null);
  const key = `${sp?.id ?? ''}|${no ?? ''}|${form}|${shiny ? 1 : 0}`;
  if (!MODEL_CACHE.has(key)) MODEL_CACHE.set(key, (async () => {
    if (modelSource && sp) { const buf = await modelSource(modelNames(sp, form)).catch(() => null); if (buf) { const g = await parse(buf); if (g) return g; } }
    if (!webModelsOn() || !no) return null;
    for (const path of webPaths(no, form, shiny)) { const buf = await fetchWebModel(path); if (buf) { const g = await parse(buf); if (g) return g; } }
    return null;
  })());
  return MODEL_CACHE.get(key);
}
/** Which Pokémon (Dex number and form, shiny or not) an actor is, from its sprite id ("pikachu",
 *  "charizard-megax:shiny", "sdform~charizard-megax~shiny"). Only real Pokémon (found in Showdown's Pokédex by
 *  name) get a model from the collection: a made-up species keeps its sprite model even if its number matches. */
let DEX = null;
const cid = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');
function whoIs(idx, id) {
  id = String(id ?? ''); const shiny = /[:~]shiny/.test(id);
  const base = id.startsWith('sdform~') ? id.split('~')[1] : id.split(':')[0];
  if (!DEX) { DEX = new Map(); for (const row of DEX_NUMS.split(',')) { const [k, n, f] = row.split(':'); DEX.set(k, { num: +n, forme: f ?? '' }); } }
  const sp = idx?.species?.get?.(base) ?? null;
  const e = DEX.get(cid(base)) ?? (sp && (DEX.get(cid(sp.showdownName)) ?? DEX.get(cid(sp.name)))) ?? null;
  return { sp, no: e?.num > 0 ? e.num : null, form: e?.forme ?? '', shiny };
}

// ---------- sprite → solid block model ----------
const VOX = new Map(); // image -> geometry (or null when the picture can't be read)
function voxelFrom(THREE, img, maxSide) {
  if (VOX.has(img)) return VOX.get(img);
  let geo = null;
  try {
    const w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height;
    const k = Math.min(1, maxSide / Math.max(w0, h0)), W = Math.max(1, Math.round(w0 * k)), H = Math.max(1, Math.round(h0 * k));
    const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const g = cv.getContext('2d', { willReadFrequently: true }); g.imageSmoothingEnabled = false; g.drawImage(img, 0, 0, W, H);
    const px = g.getImageData(0, 0, W, H).data;
    const on = (x, y) => x >= 0 && y >= 0 && x < W && y < H && px[(y * W + x) * 4 + 3] > 96;
    // how far each pixel is from the edge (for thickness): a quick two-pass distance
    const D = new Float32Array(W * H).fill(0);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (on(x, y)) D[y * W + x] = Math.min(x > 0 ? D[y * W + x - 1] : 0, y > 0 ? D[(y - 1) * W + x] : 0) + 1;
    for (let y = H - 1; y >= 0; y--) for (let x = W - 1; x >= 0; x--) if (on(x, y)) D[y * W + x] = Math.min(D[y * W + x], (x < W - 1 ? D[y * W + x + 1] : 0) + 1, (y < H - 1 ? D[(y + 1) * W + x] : 0) + 1);
    let top = H, bot = -1, left = W, right = -1;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (on(x, y)) { top = Math.min(top, y); bot = Math.max(bot, y); left = Math.min(left, x); right = Math.max(right, x); }
    if (bot < 0) { VOX.set(img, null); return null; }
    const thick = (x, y) => (on(x, y) ? Math.min(9, 0.9 + Math.sqrt(D[y * W + x]) * 1.6) : 0);
    const pos = [], col = [];
    const cx = (left + right + 1) / 2;
    const quad = (a, b, c, d, r, gg, bb, shade) => { pos.push(...a, ...b, ...c, ...a, ...c, ...d); for (let i = 0; i < 6; i++) col.push(r * shade, gg * shade, bb * shade); };
    for (let y = top; y <= bot; y++) for (let x = left; x <= right; x++) {
      if (!on(x, y)) continue;
      const i = (y * W + x) * 4, lin = (v) => { v /= 255; return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }, r = lin(px[i]), gg = lin(px[i + 1]), bb = lin(px[i + 2]);
      const t = thick(x, y) / 2, X0 = x - cx, X1 = X0 + 1, Y1 = bot + 1 - y, Y0 = Y1 - 1;
      quad([X0, Y0, t], [X1, Y0, t], [X1, Y1, t], [X0, Y1, t], r, gg, bb, 1); // front
      quad([X1, Y0, -t], [X0, Y0, -t], [X0, Y1, -t], [X1, Y1, -t], r, gg, bb, 0.8); // back
      // sides wherever the neighbour is thinner (or empty): the step between them
      const side = (nx, ny, mk) => { const tn = thick(nx, ny) / 2; if (tn >= t) return; mk(tn); };
      side(x - 1, y, (tn) => { quad([X0, Y0, -t], [X0, Y0, -tn], [X0, Y1, -tn], [X0, Y1, -t], r, gg, bb, 0.72); quad([X0, Y0, tn], [X0, Y0, t], [X0, Y1, t], [X0, Y1, tn], r, gg, bb, 0.72); });
      side(x + 1, y, (tn) => { quad([X1, Y0, t], [X1, Y0, tn], [X1, Y1, tn], [X1, Y1, t], r, gg, bb, 0.72); quad([X1, Y0, -tn], [X1, Y0, -t], [X1, Y1, -t], [X1, Y1, -tn], r, gg, bb, 0.72); });
      side(x, y - 1, (tn) => { quad([X0, Y1, t], [X1, Y1, t], [X1, Y1, tn], [X0, Y1, tn], r, gg, bb, 0.95); quad([X0, Y1, -tn], [X1, Y1, -tn], [X1, Y1, -t], [X0, Y1, -t], r, gg, bb, 0.95); });
      side(x, y + 1, (tn) => { quad([X0, Y0, tn], [X1, Y0, tn], [X1, Y0, t], [X0, Y0, t], r, gg, bb, 0.6); quad([X0, Y0, -t], [X1, Y0, -t], [X1, Y0, -tn], [X0, Y0, -tn], r, gg, bb, 0.6); });
    }
    geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    geo.computeVertexNormals();
    geo.userData.h = bot + 1 - top; geo.userData.w = right + 1 - left; geo.userData.fullH = H; geo.userData.fullW = W;
  } catch { geo = null; } // (a picture from another site without permission can't be read: it stays 2D)
  VOX.set(img, geo);
  return geo;
}

// ---------- the yard's models → three.js ----------
const hex = (c) => { const m = /^#?([0-9a-f]{6})$/i.exec(String(c ?? '')); if (!m) return [0.5, 0.5, 0.5]; const n = parseInt(m[1], 16); return [(n >> 16) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; };
function meshFrom(THREE, m) {
  if (m._g3) return m._g3;
  const pos = [], col = [], group = new THREE.Group();
  const P = (i) => { const v = m.v[i]; return [v[0], v[1], -v[2]]; }; // (the yard's z runs the other way)
  for (const f of m.f) {
    if (f.tex) { // a picture on a face (a crowd in the stands): its own textured quad
      try {
        const [i0, i1, i3] = f.tq, i2 = f.i.find((i) => ![i0, i1, i3].includes(i)) ?? i1;
        const g = new THREE.BufferGeometry();
        g.setAttribute('position', new THREE.Float32BufferAttribute([...P(i0), ...P(i1), ...P(i2), ...P(i0), ...P(i2), ...P(i3)], 3));
        g.setAttribute('uv', new THREE.Float32BufferAttribute([0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1], 2));
        g.computeVertexNormals();
        const t = new THREE.CanvasTexture(f.tex); t.magFilter = THREE.NearestFilter; t.colorSpace = THREE.SRGBColorSpace;
        const q = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ map: t, side: THREE.DoubleSide, transparent: true, alphaTest: 0.1 }));
        q.receiveShadow = true; group.add(q);
      } catch { /* skip */ }
      continue;
    }
    const c = f.base ? f.base.map((v) => v / 255) : hex(f.col);
    const lin = c.map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)); // (colours are sRGB; lighting is linear)
    for (let k = 1; k < f.i.length - 1; k++) { pos.push(...P(f.i[0]), ...P(f.i[k]), ...P(f.i[k + 1])); col.push(...lin, ...lin, ...lin); }
  }
  if (pos.length) {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    g.computeVertexNormals();
    const solid = new THREE.Mesh(g, new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide, flatShading: true }));
    solid.castShadow = true; solid.receiveShadow = true; group.add(solid);
  }
  m._g3 = group;
  return group;
}


// ---------- pictures → shapes ----------
let VM = null; const VOXMAT = (T) => (VM ??= new T.MeshLambertMaterial({ vertexColors: true, flatShading: true }));
const AVG = new Map();
function avgColor(img) {
  if (AVG.has(img)) return AVG.get(img);
  let c = [200, 200, 220];
  try { const cv = document.createElement('canvas'); cv.width = cv.height = 16; const g = cv.getContext('2d', { willReadFrequently: true }); g.drawImage(img, 0, 0, 16, 16); const d = g.getImageData(0, 0, 16, 16).data; let r = 0, gg = 0, b = 0, n = 0; for (let i = 0; i < d.length; i += 4) if (d[i + 3] > 128) { r += d[i]; gg += d[i + 1]; b += d[i + 2]; n++; } if (n) c = [r / n, gg / n, b / n]; } catch { /* fine */ }
  AVG.set(img, c); return c;
}
// the abstract places' shapes: real cubes, balls, pyramids and rings, glossy like a showroom
const SHAPES = {
  cube: (T, h) => { const g = new T.BoxGeometry(h * 0.8, h * 0.8, h * 0.8); g.translate(0, h * 0.4, 0); return g; },
  orb: (T, h) => { const g = new T.SphereGeometry(h / 2, 20, 14); g.translate(0, h / 2, 0); return g; },
  pyramid: (T, h) => { const g = new T.ConeGeometry(h * 0.62, h, 4); g.translate(0, h / 2, 0); return g; },
  ring: (T, h) => { const g = new T.TorusGeometry(h * 0.4, h * 0.09, 10, 28); g.translate(0, h / 2, 0); return g; },
};
function shapeObj(T, p) {
  const c = avgColor(p.img), h = p.h ?? 1;
  const m = new T.Mesh(SHAPES[p.kind](T, h), new T.MeshPhongMaterial({ color: new T.Color().setRGB(c[0] / 255, c[1] / 255, c[2] / 255, T.SRGBColorSpace), shininess: 70, specular: 0x666666, flatShading: p.kind !== 'orb' }));
  m.castShadow = m.receiveShadow = true;
  const g = new T.Group(); g.add(m); g.rotation.y = ((p.x * 7 + p.z * 3) % 6.28); return g;
}
// the far city's buildings: blocks with rows of windows (some lit)
function blockObj(T, p) {
  const w = p.w ?? 2, d = p.d ?? 2, h = p.h ?? 3, stack = p.type === 'stack';
  const base = new T.Color(p.color ?? '#8a8a92');
  const face = (cols, rows, seed) => {
    if (stack) return new T.MeshLambertMaterial({ color: base });
    const cv = document.createElement('canvas'); cv.width = Math.max(8, cols * 8); cv.height = Math.max(8, rows * 8);
    const g = cv.getContext('2d'); g.fillStyle = `#${base.getHexString()}`; g.fillRect(0, 0, cv.width, cv.height);
    for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) { const r = ((i * 73 + j * 31 + seed + (p.seed ?? 0)) % 97) / 97; g.fillStyle = r < 0.15 ? '#fff2c0' : p.type === 'tower' ? '#3a4a6a' : '#4a4a58'; g.fillRect(i * 8 + 2, cv.height - (j + 1) * 8 + 2, 4, 4); }
    const t = new T.CanvasTexture(cv); t.magFilter = T.NearestFilter; t.colorSpace = T.SRGBColorSpace;
    return new T.MeshLambertMaterial({ map: t });
  };
  const rows = Math.max(1, Math.floor(h / (p.type === 'warehouse' || p.type === 'factory' ? 1.6 : 1.1))), cols = Math.max(1, Math.floor(w / 0.9)), side = Math.max(1, Math.floor(d));
  const top = new T.MeshLambertMaterial({ color: base.clone().multiplyScalar(1.1) });
  const fs = face(side, rows, 7), ff = face(cols, rows, 3);
  const g = new T.BoxGeometry(w, h, d); g.translate(0, h / 2, 0);
  const m = new T.Mesh(g, [fs, fs, top, top, ff, ff]); m.castShadow = m.receiveShadow = true;
  const o = new T.Group(); o.add(m); return o;
}

/** One per yard: keeps a three.js scene in step with it and draws it. */
export class Render3D {
  constructor(yard) {
    const { THREE } = LIB;
    this.T = THREE; this.yard = yard;
    this.canvas = document.createElement('canvas');
    this.r = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: qualityLevel() >= 3, alpha: true, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
    this.r.setPixelRatio(1);
    this.r.outputColorSpace = THREE.SRGBColorSpace;
    this.r.shadowMap.enabled = qualityLevel() >= 2;
    this.r.shadowMap.type = qualityLevel() >= 3 ? THREE.PCFSoftShadowMap : THREE.BasicShadowMap;
    this.scene = new THREE.Scene();
    this.cam = new THREE.PerspectiveCamera(50, 16 / 9, 0.3, 400);
    this.noProp = new WeakMap();
    try { (globalThis.__r3d ??= []).push(this); } catch { /* fine */ }
    this.hemi = new THREE.HemisphereLight(0xdfefff, 0x5a6a3a, 0.9); this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff4e0, 1.6); this.sun.castShadow = true;
    const sm = qualityLevel() >= 4 ? 2048 : qualityLevel() >= 3 ? 1536 : 1024;
    this.sun.shadow.mapSize.set(sm, sm); this.sun.shadow.bias = -0.0008; this.sun.shadow.normalBias = 0.03;
    Object.assign(this.sun.shadow.camera, { left: -28, right: 28, top: 28, bottom: -28, near: 1, far: 140 });
    this.scene.add(this.sun, this.sun.target);
    // a soft light from the camera's side, so faces turned to you are never lost in shadow (as the old games lit them)
    this.fill = new THREE.DirectionalLight(0xffffff, 0.55); this.scene.add(this.fill, this.fill.target);
    this.lamps = Array.from({ length: 6 }, () => { const l = new THREE.PointLight(0xffffff, 0, 8, 1.6); this.scene.add(l); return l; });
    this.props = new Map(); this.actors = new Map(); this.fences = null; this.floor = null; this.floorSrc = null;
  }
  dispose() { try { this.r.dispose(); } catch { /* fine */ } }
  /** Has a 3D stand-in for this creature (so the yard doesn't draw its picture). */
  has(uid) { return !!this.actors.get(uid)?.obj; }

  syncCamera(y) {
    const { T, cam } = this;
    cam.aspect = y.W / y.H; cam.fov = (2 * Math.atan((y.H / 2) / (y.F ?? y.H * 1.05)) * 180) / Math.PI; cam.updateProjectionMatrix();
    const s = y.ps, c = y.pc, ys = y.ys, yc = y.yc;
    const f = new T.Vector3(ys * c, -s, -yc * c), u = new T.Vector3(ys * s, c, -yc * s);
    cam.position.set(y.cx, y.camY, -y.cz); cam.up.copy(u); cam.lookAt(cam.position.clone().add(f));
  }
  syncLight(y) {
    const { T } = this, sun = y.sun, night = y.tod === 'night' || y.L?.night || y.L?.cave;
    const sky = y.c?.sky1 ?? [200, 220, 240], gr = y.c?.grid ?? [90, 110, 60];
    this.hemi.color.setRGB(sky[0] / 255, sky[1] / 255, sky[2] / 255, T.SRGBColorSpace); this.hemi.groundColor.setRGB(gr[0] / 300, gr[1] / 300, gr[2] / 300, T.SRGBColorSpace);
    this.hemi.intensity = night ? 0.35 : 0.85;
    if (sun) {
      this.sun.visible = true;
      const d = sun.dir; this.sun.position.set(y.cx + d[0] * 60, d[1] * 60, -(y.cz + d[2] * 60)); this.sun.target.position.set(y.cx, 0, -y.cz);
      this.sun.color.setRGB(sun.c[0] / 255, sun.c[1] / 255, sun.c[2] / 255, T.SRGBColorSpace);
      this.sun.intensity = 0.4 + sun.k * 2.6;
      this.sun.castShadow = this.r.shadowMap.enabled && sun.k > 0.06;
    } else { this.sun.visible = !night; this.sun.castShadow = false; this.sun.intensity = 0.5; this.sun.position.set(y.cx + 10, 40, -y.cz + 10); }
    this.fill.position.set(y.cx, y.camY + 3, -y.cz); this.fill.target.position.set(y.cx + y.ys * 10, 0, -(y.cz + y.yc * 10)); this.fill.intensity = night ? 0.2 : 0.55;
    // lamps, fires, glowing moves: the strongest few near the camera
    const lit = (y.lit ?? []).slice().sort((a, b) => b.i - a.i).slice(0, this.lamps.length);
    this.lamps.forEach((L, i) => { const l = lit[i]; if (!l) { L.intensity = 0; return; } L.position.set(l.x, l.y ?? 1, -l.z); L.color.setRGB(l.c[0] / 255, l.c[1] / 255, l.c[2] / 255, T.SRGBColorSpace); L.distance = (l.r ?? 4) * 1.8; L.intensity = (l.i ?? 1) * (night ? 6 : 3); });
    this.scene.fog = new T.Fog(new T.Color().setRGB(sky[0] / 255, sky[1] / 255, sky[2] / 255, T.SRGBColorSpace), 30, 120);
  }
  syncFloor(y) {
    const { T } = this, F = y.floor;
    if (!F) return;
    // water, lava, ice and hot springs are painted over the ground as it's drawn: bake them in (and look again
    // now and then, for a pond just built)
    this.floorTick = (this.floorTick ?? 0) + 1;
    if (this.floorSrc === F && this.floorTick % 90) return;
    const bytes = new Uint8Array(F.col.buffer, F.col.byteOffset, F.col.byteLength).slice();
    const mat = F.mat, wc = y.c?.water ?? [61, 155, 224], t = y.time ?? 0, TX = F.TXW;
    let sum = 0;
    for (let i = 0, j = 0; i < bytes.length; i += 4, j++) {
      bytes[i + 3] = 255; const m = mat?.[j]; if (!m) continue; sum = (sum + m * (j % 997 + 1)) | 0;
      let r, g, b;
      if (m === 1) { const k = ((j % TX) * 7 + ((j / TX) | 0) * 3) % 29 === 0 ? 0.4 : 0.06; r = wc[0] + (255 - wc[0]) * k; g = wc[1] + (255 - wc[1]) * k; b = wc[2] + (255 - wc[2]) * k; }
      else if (m === 2) { const fl = Math.sin((j % TX) * 0.17 + t) * Math.sin(((j / TX) | 0) * 0.13); [r, g, b] = fl > 0.45 ? [255, 226, 122] : fl > -0.2 ? [255, 138, 61] : [229, 72, 45]; }
      else if (m === 4) [r, g, b] = (j % 23) ? [191, 228, 251] : [255, 255, 255];
      else if (m === 5) [r, g, b] = [126, 207, 211];
      else continue;
      bytes[i] = r; bytes[i + 1] = g; bytes[i + 2] = b;
    }
    if (this.floorSrc === F && this.floorSum === sum) return;
    this.floorSrc = F; this.floorSum = sum;
    if (this.floor) { this.scene.remove(this.floor); this.floor.geometry.dispose(); this.floor.material.map?.dispose(); }
    const { X0, Z0, TEX } = y.S;
    // the ground ends where the yard's does (past it: the far scenery, drawn behind)
    const rows = y.openFloor ? F.TXH : Math.max(1, Math.min(F.TXH, Math.ceil(((y.floorEnd ?? y.S.floorEnd ?? 1e9) - Z0) * TEX)));
    const tex = new T.DataTexture(rows < F.TXH ? bytes.slice(0, rows * F.TXW * 4) : bytes, F.TXW, rows, T.RGBAFormat); tex.magFilter = T.NearestFilter; tex.minFilter = T.NearestFilter; tex.colorSpace = T.SRGBColorSpace; tex.needsUpdate = true;
    tex.wrapS = tex.wrapT = T.RepeatWrapping;
    const w = F.TXW / TEX, d = rows / TEX, big = y.openFloor ? 5 : 1;
    if (big > 1) tex.repeat.set(big, big);
    const g = new T.PlaneGeometry(w * big, d * big); g.rotateX(-Math.PI / 2); // lies flat: the texture's first row at the near edge, like the yard's
    const m = new T.Mesh(g, new T.MeshLambertMaterial({ map: tex }));
    m.position.set(X0 + w / 2, -0.001, -(Z0 + d / 2));
    m.receiveShadow = true;
    this.floor = m; this.scene.add(m);
  }
  // every model in the scene: the yard's own models, and everything that was a picture — trees, bushes and rocks
  // far and near become models, buildings become blocks with windows, the abstract shapes real shapes, and the rest
  // (benches, lamps, shells, flowers, everything you build) solid models made from their pictures
  buildProp(p) {
    const T = this.T, q = qualityLevel();
    if (p.mesh) return meshFrom(T, p.mesh).clone();
    if (p.block) return blockObj(T, p);
    if (!p.img) return null;
    if (MODEL_KINDS.has(p.kind) && !p.float) {
      try { p.mesh3 ??= propMesh(p.kind, p.img, (p.seed ?? Math.round(p.x * 131 + p.z * 17)) | 0, p.h); } catch { p.mesh3 = null; }
      if (p.mesh3) return meshFrom(T, p.mesh3).clone();
    }
    if (SHAPES[p.kind]) return shapeObj(T, p);
    if (q <= 1 && p.outside && (p.h ?? 1) < 0.9) return null; // (on a slow device, the far little things stay pictures)
    const geo = voxelFrom(T, p.img, q <= 1 ? 40 : 64);
    if (!geo) return null;
    const m = new T.Mesh(geo, VOXMAT(T)); m.castShadow = (p.h ?? 1) > 0.7; m.receiveShadow = true;
    m.scale.setScalar((p.h ?? 1) / (geo.userData.fullH || geo.userData.h || 1));
    if (p.flip) m.scale.x *= -1;
    const g = new T.Group(); g.add(m); return g;
  }
  /** Is this prop drawn in 3D (so the yard doesn't draw its picture)? */
  hasProp(p) { return this.props.has(p); }
  syncProps(y) {
    const seen = new Set();
    for (const p of y.props ?? []) {
      let o = this.props.get(p);
      const src = p.mesh ?? p.img ?? p.block;
      if (!o || o.userData.src !== src) {
        if (o) this.scene.remove(o);
        if (this.noProp.has(p) && this.noProp.get(p) === src) continue;
        try { o = this.buildProp(p); } catch { o = null; }
        if (!o) { this.noProp.set(p, src); this.props.delete(p); continue; }
        o.userData.src = src; this.props.set(p, o); this.scene.add(o);
      }
      seen.add(p);
      const lift = p.float ? p.y + Math.sin(y.time + (p.bob ?? 0)) * 0.15 : (p.lift ?? 0);
      o.position.set(p.x, lift, -p.z);
      if (p.spin) o.rotation.y = y.time * p.spin;
      o.visible = !p.hidden;
    }
    for (const [p, o] of this.props) if (!seen.has(p)) { this.scene.remove(o); this.props.delete(p); }
    // the fence round the yard (one model, many places) — built again when the place changes
    const FM = y.fenceMesh, S = y.S;
    if (this.fences && this.fences.userData.fm !== FM) { this.scene.remove(this.fences); this.fences = null; }
    if (FM && y.fenceImg && !this.fences) {
      this.fences = new this.T.Group(); this.fences.userData.fm = FM; const seg = 1.6;
      if (!FM.x || !FM.z) { // a fence that's a picture (rocks, coral, bushes…): solid models made from it
        const T = this.T, geo = voxelFrom(T, y.fenceImg, 64);
        if (geo) {
          const k = (len) => len / (geo.userData.fullW || 1);
          const piece = (len) => { const m = new T.Mesh(geo, VOXMAT(T)); m.scale.setScalar(k(len)); m.castShadow = m.receiveShadow = true; const g = new T.Group(); g.add(m); return g; };
          if (!FM.x) for (let x = -S.side + seg / 2; x < S.side; x += seg) { const o = piece(seg); o.position.set(x, 0, -S.back); this.fences.add(o); }
          if (!FM.z) for (const sx of [-S.side, S.side]) for (let z = S.z0 - 1.2; z < S.back; z += 1.1) { const o = piece(1.2); o.rotation.y = Math.PI / 2; o.position.set(sx, 0, -(z + 0.55)); this.fences.add(o); }
        }
      }
      if (FM.x) for (let x = -S.side + seg / 2; x < S.side; x += seg) { const o = meshFrom(this.T, FM.x).clone(); o.position.set(x, 0, -S.back); this.fences.add(o); }
      if (FM.z) for (const sx of [-S.side, S.side]) for (let z = S.z0 - 1.2; z < S.back; z += 1.1) { const o = meshFrom(this.T, FM.z).clone(); o.position.set(sx, 0, -(z + 0.55)); this.fences.add(o); }
      this.scene.add(this.fences);
    }
  }
  syncActors(y) {
    const { T } = this, seen = new Set(), maxSide = [32, 48, 64, 96, 128][qualityLevel()];
    for (const a of y.actors.values()) {
      if (a.ghost) continue;
      seen.add(a.uid);
      let e = this.actors.get(a.uid);
      if (e && e.sid !== a.speciesId) { this.scene.remove(e.root); this.actors.delete(a.uid); e = null; } // (transformed into something else)
      if (!e) {
        e = { obj: null, kind: null, root: new T.Group(), sid: a.speciesId }; this.actors.set(a.uid, e); this.scene.add(e.root);
        const who = whoIs(y.idx ?? y.bank?.idx, a.speciesId);
        // its 3D model (yours, or from the collection); meanwhile (and when there's none) blocks from the sprite
        loadModel(who).then((g) => { if (!g || !this.actors.has(a.uid)) return; const sc = g._used ? cloneModel(g.scene) : g.scene; g._used = true; sc.traverse((n) => { if (n.isMesh) { n.castShadow = true; n.receiveShadow = true; } });
          sc.updateMatrixWorld(true); const box = new T.Box3().setFromObject(sc, true), hgt = Math.max(0.01, box.max.y - box.min.y); sc.userData.h = hgt; sc.position.y = -box.min.y;
          const holder = new T.Group(); holder.add(sc); if (e.obj) e.root.remove(e.obj); e.obj = holder; e.kind = 'model'; e.root.add(holder);
          if (g.animations?.length) { e.mixer = new T.AnimationMixer(sc); const idle = g.animations.find((c) => /idle|wait|stand|loop/i.test(c.name)); if (idle) e.mixer.clipAction(idle).play(); else { e.act = e.mixer.clipAction(g.animations[0]); e.act.setLoop(T.LoopOnce, 1); e.act.clampWhenFinished = false; } } });
      }
      if (!e.obj && e.kind !== 'model') {
        const entry = y.bank?.get?.(a.speciesId), img = entry?.frames?.idle?.[0] ?? entry?.img;
        const geo = img ? voxelFrom(T, img, maxSide) : null;
        if (geo) { const m = new T.Mesh(geo, new T.MeshLambertMaterial({ vertexColors: true, flatShading: true })); m.castShadow = true; m.receiveShadow = true; const holder = new T.Group(); holder.add(m); m.userData.h = geo.userData.h; e.obj = holder; e.kind = 'vox'; e.root.add(holder); }
        else if (img) e.kind = 'none';
      }
      if (!e.obj) continue;
      // size, place, facing and a little life
      const H = y.heightOf?.(a) ?? 1, inner = e.obj.children[0], h0 = inner.userData.h ?? 1, k = H / h0;
      e.obj.scale.setScalar(k * (a.appear ?? 1));
      const moving = a.state === 'walk' || a.state === 'chase' || a.state === 'return';
      const bob = moving ? Math.abs(Math.sin(y.time * 10)) * 0.06 * H : Math.sin(y.time * 2 + a.uid.length) * 0.015 * H;
      const hop = Math.sin((a.hop ?? 0) * Math.PI) * 0.35 * Math.min(1, H);
      const P0 = a.pose; // (a battle's lunges and recoils: the same push, in the world)
      e.root.position.set(a.x + (P0?.dx ?? 0) * H * 0.8, (a.y || 0) + bob + hop - (P0?.dy ?? 0) * H * 0.5, -a.z);
      if (P0) e.obj.rotation.z = -(P0.lean ?? 0); else e.obj.rotation.z = 0;
      // hit: a white flash; a status: tinted
      const mat = inner.material; if (mat?.emissive) { const fl = a.hitFlash > 0 ? 0.85 : 0; const tint = { psn: [0.25, 0, 0.3], brn: [0.35, 0.05, 0], par: [0.3, 0.25, 0], frz: [0, 0.2, 0.35] }[a.tint] ?? [0, 0, 0]; mat.emissive.setRGB(fl + tint[0] * (a.tintK ?? 1), fl + tint[1] * (a.tintK ?? 1), fl + tint[2] * (a.tintK ?? 1)); }
      // which way: away from the camera when seen from behind in battle, otherwise turned mostly to the camera,
      // leaning the way it walks
      const toCam = Math.atan2(y.cx - a.x, a.z - y.cz);
      let yaw = a.battleBack ? toCam + Math.PI : toCam;
      if (!a.battleBack && moving) yaw += (a.flip ? -1 : 1) * 0.55;
      e.root.rotation.y += ((yaw - e.root.rotation.y + Math.PI * 3) % (Math.PI * 2) - Math.PI) * 0.2;
      if (e.kind === 'vox') inner.scale.x = a.flip && !a.battleBack ? -1 : 1;
      e.root.visible = (a.alpha ?? 1) > 0.05 && !a.sink;
      // its own move animation when it lunges in battle (or does a trick)
      const going = !!(P0 && Math.abs(P0.dx ?? 0) > 0.05) || !!a.doTrick;
      if (e.act && going && !e.wasGoing) e.act.reset().play();
      e.wasGoing = going;
      if (e.mixer) e.mixer.update(1 / 60);
    }
    for (const [uid, e] of this.actors) if (!seen.has(uid)) { this.scene.remove(e.root); this.actors.delete(uid); }
  }
  /** Draw the scene; returns the canvas to lay into the yard's picture. */
  render() {
    const y = this.yard;
    if (this.canvas.width !== y.W || this.canvas.height !== y.H) this.r.setSize(y.W, y.H, false);
    this.syncCamera(y); this.syncLight(y); this.syncFloor(y); this.syncProps(y); this.syncActors(y);
    this.r.render(this.scene, this.cam);
    return this.canvas;
  }
}
export { getQuality };

// ---------- a single creature drawn in 3D into a picture (desktop buddies) ----------
// One small 3D view, reused: the creature's model (yours, or blocks from its sprite) lit from the front and
// above, turned the way it's walking; the result is drawn where its sprite would go.
let snap = null;
export function drawModelSnap(ctx, { sp, idx, id, img, uid, x, y, w, h, turn = 0, t = 0, moving = false, flip = false }) {
  if (!LIB || !img) return false;
  const { THREE: T } = LIB;
  if (!snap) {
    const canvas = document.createElement('canvas'); canvas.width = canvas.height = 256;
    const r = new T.WebGLRenderer({ canvas, alpha: true, antialias: true, preserveDrawingBuffer: true }); r.setPixelRatio(1); r.outputColorSpace = T.SRGBColorSpace;
    const scene = new T.Scene(); scene.add(new T.HemisphereLight(0xffffff, 0x60607a, 1.1)); const key = new T.DirectionalLight(0xffffff, 1.8); key.position.set(-2, 4, 5); scene.add(key);
    const cam = new T.PerspectiveCamera(22, 1, 0.1, 100);
    snap = { r, scene, cam, holder: new T.Group(), models: new Map() }; scene.add(snap.holder);
  }
  let m = snap.models.get(uid); if (m && m.id !== id) { snap.models.delete(uid); m = null; }
  if (!m) {
    m = { obj: null, id }; snap.models.set(uid, m);
    const who = id ? whoIs(idx, id) : whoIs(null, sp?.showdownName ?? sp?.name);
    if (!who.sp) who.sp = sp;
    loadModel(who).then((g) => { if (!g) return; const sc = g._used ? cloneModel(g.scene) : g.scene; g._used = true; sc.updateMatrixWorld(true); const box = new T.Box3().setFromObject(sc, true); sc.position.y = -box.min.y; sc.userData.h = box.max.y - box.min.y; m.obj = sc; m.kind = 'model'; });
  }
  if (!m.obj) { const geo = voxelFrom(T, img, 96); if (!geo) return false; const mesh = new T.Mesh(geo, new T.MeshLambertMaterial({ vertexColors: true, flatShading: true })); mesh.userData.h = geo.userData.h; m.obj = mesh; m.kind = 'vox'; }
  const o = m.obj, hgt = o.userData.h || 1;
  snap.holder.clear(); snap.holder.add(o);
  o.scale.set(m.kind === 'vox' && !flip ? -1 : 1, 1, 1);
  snap.holder.rotation.y = turn + (moving ? Math.sin(t * 8) * 0.06 : Math.sin(t * 1.3) * 0.12);
  // frame it: the whole creature, a little from above
  const dist = hgt * 4.4; snap.cam.position.set(0, hgt * 0.75, dist); snap.cam.lookAt(0, hgt * 0.48, 0);
  snap.r.render(snap.scene, snap.cam);
  ctx.drawImage(snap.r.domElement, x, y, w, h);
  return true;
}
