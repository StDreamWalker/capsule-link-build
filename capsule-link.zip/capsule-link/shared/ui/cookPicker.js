// What to cook: a list of recipes (each with what it needs, and whether the bag has it), or just mix two
// things you have. Returns the activity's `extra` ({ recipe, ingredients, dish }) or null.
import { h, chooseDialog, toast } from './dom.js';
import { itemIcon } from './itemIcon.js';
import { RECIPES, recipeStatus, recipeNeeds, allFoods, isBerry, dishFor, itemInfo, foodBlurb } from '../engine/index.js';

export async function pickCooking(idx, save, c) {
  const foods = allFoods(idx);
  const bag = foods.filter((f) => (save.inventory[f.id] ?? 0) > 0 && !f.unlimited && !String(f.id).startsWith('dish-'));
  const rows = RECIPES.map((r) => ({ r, st: recipeStatus(foods, save.inventory ?? {}, r), dish: itemInfo(idx, `dish-${r.id}`) }))
    .sort((a, b) => (b.st.ok ? 1 : 0) - (a.st.ok ? 1 : 0));
  const pick = await chooseDialog('What shall we cook?', [
    { value: '__mix', label: 'Mix what we have', detail: bag.length >= 2 ? 'Two things from the bag, at random. Who knows!' : 'Needs at least two foods in the bag.', el: h('span', { class: 'cook-mix' }, '🎲') },
    ...rows.map(({ r, st, dish }) => ({
      value: r.id,
      label: `${st.ok ? '✓ ' : ''}${r.name}`,
      detail: `${recipeNeeds(r).join(' + ')}${st.ok ? '' : ` · missing ${st.missing.join(', ')}`} · ${foodBlurb(dish) || r.desc}`,
      el: itemIcon(dish, 28, { idx }),
    })),
  ], { empty: 'Nothing to cook.' });
  if (!pick) return null;
  if (pick === '__mix') {
    if (bag.length < 2 && !(bag.length === 1 && save.inventory[bag[0].id] > 1)) { toast('You need two foods in the bag to mix.', 'err'); return null; }
    const pool = bag.flatMap((f) => Array(Math.min(3, save.inventory[f.id])).fill(f.id));
    const a = pool.splice(Math.floor(Math.random() * pool.length), 1)[0];
    const b = pool.filter((x) => x !== a || (save.inventory[a] ?? 0) > 1)[Math.floor(Math.random() * Math.max(1, pool.length - 1))] ?? pool[0];
    const ingredients = [a, b].filter(Boolean);
    return { ingredients, dish: dishFor(idx, c, ingredients) };
  }
  const row = rows.find((x) => x.r.id === pick);
  if (!row.st.ok) { toast(`${row.r.name} needs ${row.st.missing.join(', ')} more. Grow berries on the farm or buy them at the Market.`, 'err'); return null; }
  void isBerry;
  return { recipe: row.r.id, ingredients: row.st.picks, dish: row.dish };
}
