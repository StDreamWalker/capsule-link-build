# Move animations from Pokémon Showdown

- `battle-animations-moves.ts` is Pokémon Showdown's move animation table, by Guangcong Luo and
  contributors, released under **CC0-1.0** (see the file's header). It is unchanged.
- `battle-animations.ts` holds only `BattleOtherAnims`, taken from Showdown's battle animation engine,
  which is under the **MIT licence**:

  > Copyright (c) 2011-2025 Guangcong Luo and other contributors
  >
  > Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
  > associated documentation files (the "Software"), to deal in the Software without restriction, including
  > without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  > copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the
  > following conditions: The above copyright notice and this permission notice shall be included in all
  > copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
  > ANY KIND.

- `player.js` (Capsule Link's own) plays them on a canvas. The effect pictures themselves (fx/*.png) are
  not included: "Download everything" fetches them from play.pokemonshowdown.com into your textures.
- Source: https://github.com/smogon/pokemon-showdown-client
