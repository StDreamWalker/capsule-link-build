// Stand-in for Showdown's client config: the move animations only ask where the client lives (for a few
// weather backgrounds). Capsule Link draws those as plain colour washes.
export const Config = { routes: { client: 'play.pokemonshowdown.com' } };
