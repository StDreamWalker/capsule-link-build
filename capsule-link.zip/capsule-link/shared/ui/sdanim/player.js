// Plays Pokémon Showdown's own move animations (battle-animations-moves.ts, CC0) on a canvas: a tiny
// stand-in for Showdown's battle scene. The animations place effect pictures in Showdown's battle space
// (attacker near at z = 0, target far at z = 200) and move the two creatures about; here that space is
// mapped onto two points on the canvas (your creature and its target) and drawn every frame.
// Effect pictures come from the textures folder (fx/<file>.png, fetched by "Download everything"); a
// missing one is drawn as a soft glow in the move's colour so nothing is ever blank.
import { BattleMoveAnims } from './battle-animations-moves.ts';
import { BattleOtherAnims } from './battle-animations.ts';

/** Showdown's effect pictures: key → [file, width, height] (from its battle engine, MIT). */
export const SD_EFFECTS = {
  wisp: ['wisp.png', 100, 100], purplewisp: ['purplewisp.png', 100, 100], waterwisp: ['waterwisp.png', 100, 100], mudwisp: ['mudwisp.png', 100, 100], blackwisp: ['blackwisp.png', 100, 100],
  fireball: ['fireball.png', 64, 64], bluefireball: ['bluefireball.png', 64, 64], icicle: ['icicle.png', 80, 60], pinkicicle: ['icicle-pink.png', 80, 60], lightning: ['lightning.png', 41, 229],
  rocks: ['rocks.png', 100, 100], rock1: ['rock1.png', 64, 80], rock2: ['rock2.png', 66, 72], rock3: ['rock3.png', 66, 72], leaf1: ['leaf1.png', 32, 26], leaf2: ['leaf2.png', 40, 26],
  bone: ['bone.png', 29, 29], caltrop: ['caltrop.png', 80, 80], greenmetal1: ['greenmetal1.png', 45, 45], greenmetal2: ['greenmetal2.png', 45, 45], poisoncaltrop: ['poisoncaltrop.png', 80, 80],
  shadowball: ['shadowball.png', 100, 100], energyball: ['energyball.png', 100, 100], electroball: ['electroball.png', 100, 100], mistball: ['mistball.png', 100, 100], iceball: ['iceball.png', 100, 100],
  flareball: ['flareball.png', 100, 100], moon: ['moon.png', 100, 100], pokeball: ['pokeball.png', 24, 24], fist: ['fist.png', 55, 49], fist1: ['fist1.png', 49, 55], foot: ['foot.png', 50, 75],
  topbite: ['topbite.png', 108, 64], bottombite: ['bottombite.png', 108, 64], web: ['web.png', 120, 122], leftclaw: ['leftclaw.png', 44, 60], rightclaw: ['rightclaw.png', 44, 60],
  leftslash: ['leftslash.png', 57, 56], rightslash: ['rightslash.png', 57, 56], leftchop: ['leftchop.png', 100, 130], rightchop: ['rightchop.png', 100, 130], angry: ['angry.png', 30, 30],
  heart: ['heart.png', 30, 30], pointer: ['pointer.png', 100, 100], sword: ['sword.png', 48, 100], impact: ['impact.png', 127, 119], stare: ['stare.png', 100, 35], shine: ['shine.png', 127, 119],
  feather: ['feather.png', 100, 38], shell: ['shell.png', 100, 91], petal: ['petal.png', 60, 60], gear: ['gear.png', 100, 100], alpha: ['alpha.png', 80, 80], omega: ['omega.png', 80, 80],
  rainbow: ['rainbow.png', 128, 128], zsymbol: ['z-symbol.png', 150, 100], ultra: ['ultra.png', 113, 165], hitmark: ['hitmarker.png', 100, 100],
  protect: [null, 100, 70], auroraveil: [null, 100, 50], reflect: [null, 100, 50], safeguard: [null, 100, 50], lightscreen: [null, 100, 50], mist: [null, 100, 50],
};
/** Files to download into textures/fx/. */
export const SD_FX_FILES = [...new Set(Object.values(SD_EFFECTS).map((e) => e[0]).filter(Boolean))];
export const SD_FX_SOURCE = 'https://play.pokemonshowdown.com/fx/';

const sdId = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');
/** For moves Showdown has no animation for: a simple move of the same type (a water move looks like Water Gun). */
const STAND_IN = {
  normal: ['tackle', 'swift', 'growl'], fire: ['firepunch', 'ember', 'sunnyday'], water: ['aquajet', 'watergun', 'raindance'], electric: ['thunderpunch', 'thundershock', 'charge'],
  grass: ['vinewhip', 'magicalleaf', 'growth'], ice: ['icepunch', 'icebeam', 'mist'], fighting: ['karatechop', 'aurasphere', 'bulkup'], poison: ['poisonsting', 'sludge', 'toxic'],
  ground: ['mudslap', 'mudshot', 'sandattack'], flying: ['peck', 'gust', 'roost'], psychic: ['zenheadbutt', 'confusion', 'calmmind'], bug: ['bugbite', 'bugbuzz', 'stringshot'],
  rock: ['rockthrow', 'ancientpower', 'sandstorm'], ghost: ['lick', 'shadowball', 'confuseray'], dragon: ['dragonclaw', 'dragonbreath', 'dragondance'], dark: ['bite', 'darkpulse', 'nastyplot'],
  steel: ['metalclaw', 'flashcannon', 'irondefense'], fairy: ['playrough', 'fairywind', 'charm'],
};
export function standInMove(type, category = 'physical') {
  const set = STAND_IN[type] ?? STAND_IN.normal;
  return set[category === 'special' ? 1 : category === 'status' ? 2 : 0];
}
/** Does Showdown have an animation for this move (by name or id)? */
export function hasMoveAnim(name) { const id = sdId(name); return !!(BattleMoveAnims[id] && typeof BattleMoveAnims[id].anim === 'function'); }

// jQuery easing, as Showdown uses it
const EASE = {
  linear: (x) => x,
  swing: (x) => 0.5 - Math.cos(x * Math.PI) / 2,
  quadUp: (x) => 1 - (1 - x) * (1 - x),
  quadDown: (x) => x * x,
  ballisticUp: (x) => -3 * x * x + 4 * x,
  ballisticDown: (x) => { x = 1 - x; return 1 - (-3 * x * x + 4 * x); },
};

/** Showdown's scene.pos: a battle-space location → a box on its 640×360 stage. */
function pos(loc, obj, sprite = false) {
  const L = { x: 0, y: 0, z: 0, scale: 1, opacity: 1, ...loc };
  if (!L.xscale && L.xscale !== 0) L.xscale = L.scale;
  if (!L.yscale && L.yscale !== 0) L.yscale = L.scale;
  let left = 210, top = 245;
  let scale = sprite ? 2.0 - L.z / 200 : 1.5 - 0.5 * (L.z / 200);
  if (scale < 0.1) scale = 0.1;
  left += (410 - 190) * (L.z / 200);
  top += (135 - 245) * (L.z / 200);
  left += Math.floor(L.x * scale);
  top -= Math.floor(L.y * scale);
  const width = Math.floor(obj.w * scale * L.xscale), height = Math.floor(obj.h * scale * L.yscale);
  return { cx: left, cy: top, width, height, opacity: L.opacity };
}
function transitionMap(transition, p, old, loc) {
  const m = { left: 'linear', top: 'linear', size: 'linear', opacity: 'linear' };
  if (transition === 'ballistic') m.top = p.cy < old.cy ? 'ballisticUp' : 'ballisticDown';
  if (transition === 'ballisticUnder') m.top = p.cy < old.cy ? 'ballisticDown' : 'ballisticUp';
  if (transition === 'ballistic2') m.top = p.cy < old.cy ? 'quadUp' : 'quadDown';
  if (transition === 'ballistic2Back') m.top = (loc.z ?? 0) > 0 ? 'quadUp' : 'quadDown';
  if (transition === 'ballistic2Under') m.top = p.cy < old.cy ? 'quadDown' : 'quadUp';
  if (transition === 'swing') m.left = m.top = m.size = 'swing';
  if (transition === 'accel') m.left = m.top = m.size = 'quadDown';
  if (transition === 'decel') m.left = m.top = m.size = 'quadUp';
  return m;
}
const lerp = (a, b, k) => a + (b - a) * k;

/** A creature in the scene: Showdown's PokemonSprite, reduced to a queue of moves. */
class SdSprite {
  constructor(scene, z, isFront) {
    this.scene = scene; this.x = 0; this.y = 0; this.z = z; this.isFrontSprite = isFront;
    this.sp = { w: 96, h: 96, url: '', gen: 5, self: true };
    this.cursor = 0; this.segs = [];
    this.state = { x: 0, y: 0, z, scale: 1, opacity: 1 };
    this.isMissedPokemon = false;
  }
  behind(o) { return this.z + (this.isFrontSprite ? 1 : -1) * o; }
  behindx(o) { return this.x + (this.isFrontSprite ? 1 : -1) * o; }
  behindy(o) { return this.y + (this.isFrontSprite ? -1 : 1) * o; }
  leftof(o) { return this.x + (this.isFrontSprite ? 1 : -1) * o; }
  delay(t) { this.cursor += t; return this; }
  anim(end, transition) {
    const e = { x: this.x, y: this.y, z: this.z, scale: 1, opacity: 1, time: 500, ...end };
    const t = e.time;
    this.segs.push({ t0: this.cursor, t1: this.cursor + t, from: { ...this.state }, to: { x: e.x, y: e.y, z: e.z, scale: e.scale, xscale: e.xscale, yscale: e.yscale, opacity: e.opacity }, transition });
    this.state = { x: e.x, y: e.y, z: e.z, scale: e.scale, opacity: e.opacity };
    this.cursor += t;
    this.scene.end = Math.max(this.scene.end, this.cursor);
    return this;
  }
  /** Where it is at time t: { dxSd, dySd, scale, opacity } relative to rest, in stage pixels. */
  at(t) {
    const rest = pos({ x: 0, y: 0, z: this.z }, this.sp, true);
    let cur = { x: 0, y: 0, z: this.z, scale: 1, opacity: 1 };
    for (const s of this.segs) {
      if (t >= s.t1) { cur = s.to; continue; }
      if (t < s.t0) break;
      const k = s.t1 > s.t0 ? (t - s.t0) / (s.t1 - s.t0) : 1;
      const a = pos(s.from, this.sp, true), b = pos(s.to, this.sp, true);
      const m = transitionMap(s.transition, b, a, s.to);
      const p = { cx: lerp(a.cx, b.cx, EASE[m.left](k)), cy: lerp(a.cy, b.cy, EASE[m.top](k)), width: lerp(a.width, b.width, EASE[m.size](k)), opacity: lerp(a.opacity, b.opacity, k) };
      return { dx: p.cx - rest.cx, dy: p.cy - rest.cy, scale: p.width / rest.width, opacity: p.opacity };
    }
    const p = pos(cur, this.sp, true);
    return { dx: p.cx - rest.cx, dy: p.cy - rest.cy, scale: p.width / rest.width, opacity: p.opacity };
  }
}

/** Showdown's BattleScene, only the parts the move animations use. */
class SdScene {
  constructor() {
    this.timeOffset = 0; this.effects = []; this.bgs = []; this.end = 0; this.shakes = [];
    this.battle = { mySide: { x: 0, y: 0, z: 0 }, gameType: 'singles' };
    this.acceleration = 1; this.animating = true; this.gen = 9;
    const chain = { animate: (css, t = 100) => { this.shakes.push({ t0: this.timeOffset, t1: this.timeOffset + t }); return chain; } };
    this.$bg = chain;
  }
  wait(t) { this.timeOffset += t; }
  showEffect(effect, start, end, transition, after) { return this.animateEffect(null, effect, start, end, transition, after); }
  animateEffect(prev, effect, start, end, transition, after) {
    const s = { ...start }, e0 = { ...end };
    if (!s.time) s.time = 0;
    if (!e0.time) e0.time = s.time + 500;
    s.time += this.timeOffset; e0.time += this.timeOffset;
    if (!e0.scale && e0.scale !== 0 && s.scale) e0.scale = s.scale;
    if (!e0.xscale && e0.xscale !== 0 && s.xscale) e0.xscale = s.xscale;
    if (!e0.yscale && e0.yscale !== 0 && s.yscale) e0.yscale = s.yscale;
    const e = { ...s, ...e0 };
    const key = typeof effect === 'string' ? effect : null;
    const def = key ? SD_EFFECTS[key] : null;
    const obj = def ? { w: def[1], h: def[2], file: def[0], key } : { w: effect?.w ?? 96, h: effect?.h ?? 96, self: true };
    const fx = { obj, start: s, end: e, transition, after, t0: s.time, t1: e.time };
    if (prev) prev.killAt = Math.min(prev.killAt ?? Infinity, s.time);
    fx.tEnd = e.time + (after === 'fade' ? 100 : after === 'explode' ? 200 : 0);
    this.end = Math.max(this.end, fx.tEnd);
    this.effects.push(fx);
    return fx;
  }
  backgroundEffect(bg, duration, opacity = 1, delay = 0) {
    const t0 = this.timeOffset + delay;
    this.bgs.push({ bg: String(bg), t0, t1: t0 + duration, opacity });
    this.end = Math.max(this.end, t0 + duration);
  }
  waitFor() {}
}

const WEATHER_BG = { sunnyday: 'rgba(255,190,80,1)', raindance: '#2a4a8a', hail: '#cfe8ff', snow: '#cfe8ff', sandstorm: '#c8a050', desolateland: '#ff7a2a', primordialsea: '#1e3a7a' };
function bgColor(bg) {
  const m = /#[0-9a-f]{3,8}|rgba?\([^)]*\)/i.exec(bg);
  if (m) return m[0];
  const w = /weather-([a-z]+)/i.exec(bg);
  return w ? WEATHER_BG[w[1].toLowerCase()] ?? null : null;
}

/**
 * Prepare one move's animation. Returns null if Showdown has none for it.
 * The result: { duration (ms), frame(ctx, t, view) } where view = { a: {x, y}, d: {x, y} } are the canvas
 * points of the attacker and the target, resolve(path) → url of a texture, tint: the move's colour.
 * frame() draws the effects and returns { attacker, defender } offsets ({ dx, dy, scale, opacity }) to
 * apply to the two creatures, and { shake } (pixels) for the camera.
 */
export function prepareMoveAnim(name, { missed = false } = {}) {
  const id = sdId(name);
  const def = BattleMoveAnims[id];
  if (!def?.anim) return null;
  const scene = new SdScene();
  const attacker = new SdSprite(scene, 0, false), defender = new SdSprite(scene, 200, true);
  defender.isMissedPokemon = missed;
  try { def.prepareAnim?.(scene, [attacker, defender]); def.anim(scene, [attacker, defender]); }
  catch (e) { console.warn('move animation', id, e); return null; }
  const imgs = new Map();
  const image = (resolve, file) => {
    const url = resolve?.(`fx/${file.toLowerCase()}`);
    if (!url) return null;
    let r = imgs.get(url);
    if (!r) { const img = new Image(); r = { img, ok: false }; img.onload = () => { r.ok = true; }; img.src = url; imgs.set(url, r); }
    return r.ok ? r.img : null;
  };
  const duration = Math.max(scene.end, attacker.cursor, defender.cursor) + 50;
  return {
    id, duration,
    frame(ctx, t, { a, d, resolve, tint = '#ffffff', selfImg = null }) {
      // Showdown's stage → the canvas: attacker's spot to ours, target's spot to the target
      const A = { x: 210, y: 245 }, D = { x: 410, y: 135 };
      const vs = { x: D.x - A.x, y: D.y - A.y }, vc = { x: d.x - a.x, y: d.y - a.y };
      const den = vs.x * vs.x + vs.y * vs.y;
      const kr = (vc.x * vs.x + vc.y * vs.y) / den, ki = (vc.y * vs.x - vc.x * vs.y) / den;
      const k = Math.hypot(kr, ki), rot = Math.atan2(ki, kr);
      const T = (x, y) => { const px = x - A.x, py = y - A.y; return { x: a.x + px * kr - py * ki, y: a.y + px * ki + py * kr }; };
      // background washes
      for (const b of scene.bgs) {
        if (t < b.t0 || t > b.t1) continue;
        const col = bgColor(b.bg); if (!col) continue;
        const fade = Math.min(1, (t - b.t0) / 250, (b.t1 - t) / 250);
        ctx.save(); ctx.globalAlpha = Math.max(0, fade) * b.opacity * 0.55; ctx.fillStyle = col; ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height); ctx.restore();
      }
      for (const fx of scene.effects) {
        if (t < fx.t0 || t > fx.tEnd || t >= (fx.killAt ?? Infinity)) continue;
        const sp = pos(fx.start, fx.obj), ep = pos(fx.end, fx.obj);
        let p;
        if (t <= fx.t1) {
          const kk = fx.t1 > fx.t0 ? (t - fx.t0) / (fx.t1 - fx.t0) : 1;
          const m = transitionMap(fx.transition, ep, sp, fx.end);
          p = { cx: lerp(sp.cx, ep.cx, EASE[m.left](kk)), cy: lerp(sp.cy, ep.cy, EASE[m.top](kk)), width: lerp(sp.width, ep.width, EASE[m.size](kk)), height: lerp(sp.height, ep.height, EASE[m.size](kk)), opacity: lerp(sp.opacity, ep.opacity, kk) };
        } else {
          const kk = (t - fx.t1) / (fx.after === 'explode' ? 200 : 100);
          p = { ...ep };
          if (fx.after === 'fade') p.opacity = ep.opacity * (1 - kk);
          if (fx.after === 'explode') { p.width = lerp(ep.width, ep.width * 3, kk); p.height = lerp(ep.height, ep.height * 3, kk); p.opacity = ep.opacity * (1 - kk); }
        }
        if (!(p.opacity > 0.01) || p.width < 1) continue;
        const c = T(p.cx, p.cy), w = p.width * k, h = p.height * k;
        ctx.save();
        ctx.globalAlpha = Math.min(1, p.opacity);
        ctx.translate(c.x, c.y); ctx.rotate(rot);
        const img = fx.obj.self ? selfImg : fx.obj.file ? image(resolve, fx.obj.file) : null;
        if (img) ctx.drawImage(img, -w / 2, -h / 2, w, h);
        else if (!fx.obj.self) {
          // no picture: a soft glow in the move's colour, shaped roughly like the effect
          const g = ctx.createRadialGradient(0, 0, 1, 0, 0, Math.max(w, h) / 2);
          g.addColorStop(0, '#ffffff'); g.addColorStop(0.35, tint); g.addColorStop(1, 'rgba(255,255,255,0)');
          ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, 0, w / 2, h / 2, 0, 0, Math.PI * 2); ctx.fill();
        }
        ctx.restore();
      }
      const off = (s) => { const o = s.at(t); return { dx: o.dx * kr - o.dy * ki, dy: o.dx * ki + o.dy * kr, scale: o.scale, opacity: o.opacity }; };
      const shaking = scene.shakes.some((s) => t >= s.t0 && t <= s.t1);
      return { attacker: off(attacker), defender: off(defender), shake: shaking ? 4 : 0, done: t >= duration };
    },
  };
}
