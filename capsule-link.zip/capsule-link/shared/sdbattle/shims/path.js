// Showdown's simulator only uses `path` to find its data files; in the app they're bundled in.
export const resolve = (...a) => a.join('/').replace(/\/+/g, '/');
export const join = resolve;
export default { resolve, join };
