// Showdown's battle screen draws with jQuery; it expects it as a global.
import $ from '../../../vendor/showdown/jquery.min.cjs';
globalThis.$ = globalThis.jQuery = $;
