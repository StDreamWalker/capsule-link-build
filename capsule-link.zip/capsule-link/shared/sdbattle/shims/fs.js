export const readdirSync = () => [];
export const existsSync = () => false;
export default { readdirSync, existsSync };
