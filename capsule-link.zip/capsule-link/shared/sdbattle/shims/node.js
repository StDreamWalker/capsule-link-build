// node:util, node:crypto and ts-chacha20 stand-ins (battles here always use a numeric seed)
export function isDeepStrictEqual(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
export class Chacha20 { constructor() { throw new Error('Capsule Link battles use a numeric seed.'); } }
export default {};
