// Stand-in: the battle screen here never talks to a server.
export function Net(_url: string): any { return { get: () => Promise.reject(new Error('offline')) }; }
