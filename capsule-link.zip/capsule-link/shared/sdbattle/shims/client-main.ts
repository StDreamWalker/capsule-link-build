// Stand-in for the Showdown client's main module. Only the battle engine (battle-*.ts, MIT) is used;
// the rest of the client (AGPL) is not part of Capsule Link.
const g: any = globalThis as any;
export const Config: any = g.Config ?? (g.Config = {
  routes: { client: 'play.pokemonshowdown.com', root: 'pokemonshowdown.com', users: 'pokemonshowdown.com/users', replays: 'replay.pokemonshowdown.com', dex: 'dex.pokemonshowdown.com' },
  server: { id: 'capsule', host: 'localhost', port: 443 }, customcolors: {}, whitelist: [], testclient: false,
});
const prefs: any = { effectvolume: 50, musicvolume: 0, mute: true, noanim: false, subscribeAndRun() {}, subscribe() {} };
export const PS: any = g.PS ?? (g.PS = { prefs, server: { id: 'capsule' }, connection: null });
