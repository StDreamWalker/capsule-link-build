// Just the simulator (for tests): the same bundle setup as the battle screen uses.
export { BattleStream, getPlayerStreams } from '../../vendor/showdown/sim/battle-stream';
export { Dex } from '../../vendor/showdown/sim/dex';
