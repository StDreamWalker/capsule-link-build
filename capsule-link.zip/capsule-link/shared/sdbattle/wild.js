// Wild battles on Pokémon Showdown's own simulator and battle screen, both running inside the app (no
// account, no server, no internet). Built into its own file (showdown-battle.js) and loaded the first time
// a wild battle starts; it sets window.CapsuleShowdown.
//   knows(kind, name)           does Showdown know this species / move / item / ability?
//   start(opts) → { done, stop } a battle in opts.host; `done` resolves to the outcome (see below)
import './shims/jquery-global.js';
import { BattleStream, getPlayerStreams } from '../../vendor/showdown/sim/battle-stream';
import { Dex as SimDex } from '../../vendor/showdown/sim/dex';
import './globals.js';
import { Battle } from '../../vendor/showdown/client/battle';
import { Dex as ClientDex } from '../../vendor/showdown/client/battle-dex';
import { BattleEffects, BattleBackdrops } from '../../vendor/showdown/client/battle-animations';
import { BattleSound } from '../../vendor/showdown/client/battle-sound';

const $ = globalThis.jQuery;
const toID = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function knows(kind, name) {
  const t = { species: SimDex.species, move: SimDex.moves, item: SimDex.items, ability: SimDex.abilities }[kind];
  return !!t?.get(String(name ?? '')).exists;
}

// ---------- the wild one's mind: mostly the strongest hit, sometimes something else ----------
function wildChoice(sim, req) {
  const me = sim.p2.active[0], foe = sim.p1.active[0];
  const opts = (req.active?.[0]?.moves ?? []).map((m, i) => ({ m, i: i + 1 })).filter(({ m }) => !m.disabled && (m.pp ?? 1) > 0);
  if (!opts.length) return 'move 1';
  const score = ({ m }) => {
    const mv = SimDex.moves.get(m.id);
    if (!foe || !mv.exists) return 10;
    if (mv.category === 'Status') return foe.status || mv.target === 'self' ? 12 : 30;
    if (!SimDex.getImmunity(mv.type, foe)) return 0;
    const eff = 2 ** SimDex.getEffectiveness(mv.type, foe);
    const stab = me?.getTypes?.().includes(mv.type) ? 1.5 : 1;
    return (mv.basePower || 50) * eff * stab * ((mv.accuracy === true ? 100 : mv.accuracy) / 100);
  };
  const scored = opts.map((o) => ({ ...o, s: score(o) * (0.75 + Math.random() * 0.5) })).sort((a, b) => b.s - a.s);
  const pick = Math.random() < 0.8 ? scored[0] : scored[Math.floor(Math.random() * scored.length)];
  return `move ${pick.i}`;
}

/**
 * opts: {
 *   host,                       the element to fill
 *   trainer,                    your name
 *   team: [set],                Showdown sets for your party (name = a unique nickname), plus hpLeft / ppLeft
 *   foe: set,                   the wild one
 *   seed: [n, n, n, n],
 *   sprite(species, { shiny, back }) → { url, w, h } | null      your own pictures (else Showdown's online ones)
 *   fx(file) → url | null,      Showdown effect pictures saved by Download everything (else online)
 *   backdrop: url | null,
 * }
 * done → { won, ran, lost, team: { name: { hp, maxhp, status, pp: [n] , fainted } }, out: [names that battled], turns }
 */
function start(opts) {
  // pictures: the app's own sprites and effect files where it has them
  const fallbackSprite = ClientDex.getSpriteData.bind(ClientDex);
  ClientDex.getSpriteData = (pokemon, isFront, o = {}) => {
    const base = fallbackSprite(pokemon, isFront, o);
    const name = typeof pokemon === 'string' ? pokemon : pokemon?.speciesForme ?? pokemon?.name ?? '';
    const mine = opts.sprite?.(name, { shiny: !!(o.shiny ?? pokemon?.shiny), back: !isFront });
    return mine ? { ...base, url: mine.url, w: mine.w, h: mine.h, y: 0, pixelated: true, isFrontSprite: isFront, cryurl: '' } : base;
  };
  for (const id in BattleEffects) {
    const e = BattleEffects[id];
    if (!e.url) continue;
    e.__file = e.__file ?? e.url.split('/').pop();
    e.url = opts.fx?.(e.__file) ?? `https://play.pokemonshowdown.com/fx/${e.__file}`;
  }
  BattleSound.muted = true;

  const host = opts.host;
  host.innerHTML = '';
  host.classList.add('cl-sd');
  const frame = $('<div class="battle"></div>'), logFrame = $('<div class="battle-log"></div>');
  const stage = $('<div class="cl-sd-stage"></div>').append(frame, logFrame);
  const controls = $('<div class="cl-sd-controls battle-controls" role="group" aria-label="Your move"></div>');
  $(host).append(stage, controls);

  const battle = new Battle({ $frame: frame, $logFrame: logFrame, id: 'capsule-wild', autoresize: false });
  battle.setMute?.(true);
  if (opts.backdrop) { battle.scene.backdropImage = ''; battle.scene.$bg?.css({ 'background-image': `url("${opts.backdrop}")`, 'background-size': 'cover', 'background-position': 'center' }); }

  const stream = new BattleStream();
  const ps = getPlayerStreams(stream);
  let request = null, ended = false, ran = false, won = null;
  const out = new Set();
  let resolveDone;
  const done = new Promise((r) => { resolveDone = r; });

  const finish = () => {
    if (finish.called) return; finish.called = true;
    const sim = stream.battle;
    const team = {};
    for (const p of sim?.p1?.pokemon ?? []) team[p.set.name] = { hp: p.fainted ? 0 : p.hp, maxhp: p.maxhp, status: p.status || null, pp: p.baseMoveSlots.map((m) => m.pp), fainted: !!p.fainted };
    controls.html(`<div class="whatdo">${won ? 'You won!' : ran ? 'Got away safely.' : 'Everyone needs a rest…'}</div><button class="button cl-sd-continue" type="button">Continue</button>`);
    controls.find('.cl-sd-continue').on('click', () => resolveDone({ won: !!won, ran, lost: !won && !ran, team, out: [...out], turns: battle.turn }));
  };

  // the screen: everything your side can see
  (async () => {
    for await (const chunk of ps.p1) {
      for (const line of chunk.split('\n')) {
        if (line.startsWith('|request|')) { const j = line.slice(9); if (j) request = JSON.parse(j); continue; }
        if (line.startsWith('|switch|p1a: ') || line.startsWith('|drag|p1a: ')) out.add(line.split('|')[2].slice(5));
        if (line.startsWith('|win|')) { won = line.slice(5) === opts.trainer; ended = true; }
        if (line.startsWith('|tier|') || line.startsWith('|rule|')) continue;
        battle.add(line);
      }
      if (ended) { battle.subscribe((ev) => { if (ev === 'atqueueend') finish(); }); if (battle.atQueueEnd) finish(); }
      else showControls();
    }
  })().catch((e) => { console.error(e); controls.text(`The battle stopped: ${e.message}`); });
  // the wild side
  (async () => {
    for await (const chunk of ps.p2) {
      for (const line of chunk.split('\n')) {
        if (!line.startsWith('|request|')) continue;
        const r = JSON.parse(line.slice(9) || 'null');
        if (!r || r.wait) continue;
        if (r.forceSwitch) { ps.p2.write('pass'); continue; }
        if (r.active) ps.p2.write(wildChoice(stream.battle, r));
      }
    }
  })().catch((e) => console.error(e));

  const send = (choice) => { controls.html('<div class="whatdo"><em>Waiting…</em></div>'); ps.p1.write(choice); };
  function showControls() {
    const r = request;
    if (!r || ended) return;
    if (r.wait) { controls.html('<div class="whatdo"><em>Waiting…</em></div>'); return; }
    const side = r.side?.pokemon ?? [];
    const switchable = side.map((p, i) => ({ p, i })).filter(({ p }) => !p.active && !/ fnt$/.test(p.condition));
    const sw = switchable.map(({ p, i }) => {
      const [hp, mx] = String(p.condition).split(' ')[0].split('/').map(Number);
      return `<button class="button cl-sd-switch" data-i="${i + 1}" type="button">${esc(p.ident.slice(4))}<small>${hp}/${mx}</small></button>`;
    }).join('');
    if (r.forceSwitch) {
      controls.html(`<div class="whatdo">Who’s next?</div><div class="switchmenu">${sw || '<em>Nobody left.</em>'}</div>`);
    } else {
      const act = r.active?.[0] ?? { moves: [] };
      const moves = act.moves.map((m, i) => {
        const mv = SimDex.moves.get(m.id);
        const type = mv.exists ? mv.type : 'Normal';
        return `<button class="button type-${type} movebutton" data-i="${i + 1}" type="button" ${m.disabled || m.pp === 0 ? 'disabled' : ''} title="${esc(mv.shortDesc || mv.desc || '')}">${esc(m.move)}<br /><small class="type">${type}</small> <small class="pp">${m.pp}/${m.maxpp}</small></button>`;
      }).join('');
      const me = side.find((p) => p.active);
      controls.html(
        `<div class="whatdo">What will <strong>${esc(me?.ident?.slice(4) ?? 'your creature')}</strong> do?</div>` +
        `<div class="cl-sd-groups"><div class="movecontrols"><div class="moveselect">Attack</div><div class="movemenu">${moves}</div></div>` +
        `<div class="switchcontrols"><div class="switchselect">Switch</div><div class="switchmenu">${act.trapped ? '<em>Can’t get away!</em>' : sw || '<em>Nobody else can battle.</em>'}</div>` +
        `<div class="cl-sd-run"><button class="button cl-sd-runbtn" type="button" ${act.trapped ? 'disabled' : ''}>Run</button></div></div></div>`);
    }
    controls.find('.movebutton').on('click', (e) => send(`move ${e.currentTarget.dataset.i}`));
    controls.find('.cl-sd-switch').on('click', (e) => send(`switch ${e.currentTarget.dataset.i}`));
    controls.find('.cl-sd-runbtn').on('click', () => {
      ran = true; ended = true;
      battle.add('|');
      battle.add('|-message|Got away safely!');
      finish();
    });
  }

  ps.omniscient.write(`>start ${JSON.stringify({ formatid: 'gen9capsulewild', seed: opts.seed })}\n` +
    `>player p1 ${JSON.stringify({ name: opts.trainer, team: opts.team })}\n` +
    `>player p2 ${JSON.stringify({ name: 'Wild', team: [opts.foe] })}`);
  battle.play?.();

  return { done, stop() { try { stream.destroy?.(); } catch { /* gone */ } try { battle.destroy(); } catch { /* gone */ } host.innerHTML = ''; } };
}

globalThis.CapsuleShowdown = { knows, start, backdrops: BattleBackdrops, version: 1 };
