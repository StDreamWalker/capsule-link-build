// Wild battles on Pokémon Showdown's own simulator and battle screen, both running inside the app (no
// account, no server, no internet). Built into its own file (showdown-battle.js) and loaded the first time
// a wild battle starts; it sets window.CapsuleShowdown.
//   knows(kind, name)           does Showdown know this species / move / item / ability?
//   start(opts) → { done, stop } a battle in opts.host; `done` resolves to the outcome (see below)
import './shims/jquery-global.js';
import { BattleStream, getPlayerStreams } from '../../vendor/showdown/sim/battle-stream';
import { Dex as SimDex } from '../../vendor/showdown/sim/dex';
import { Teams } from '../../vendor/showdown/sim/teams';
import './globals.js';
import { Battle } from '../../vendor/showdown/client/battle';
import { Dex as ClientDex } from '../../vendor/showdown/client/battle-dex';
import { BattleEffects, BattleBackdrops } from '../../vendor/showdown/client/battle-animations';
import { BattleSound } from '../../vendor/showdown/client/battle-sound';

const $ = globalThis.jQuery;
const toID = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// ---------- Showdown stays Showdown ----------
// The simulator's own tables (moves, abilities, items, conditions, Pokédex, type chart) must never be touched
// by anything else in the page: Showdown's battle screen gets copies of its own (globals.js), and the
// simulator's are fingerprinted before and after every battle. A difference is reported, never ignored.
function simFingerprint() {
  const d = SimDex.data;
  let h = 2166136261 >>> 0, n = 0;
  const mix = (s) => { for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619) >>> 0; };
  for (const t of ['Moves', 'Abilities', 'Items', 'Conditions', 'Pokedex', 'TypeChart', 'Learnsets', 'FormatsData']) {
    const tab = d[t]; if (!tab) continue;
    for (const id of Object.keys(tab).sort()) {
      const e = tab[id]; n++;
      mix(id);
      if (!e || typeof e !== 'object') { mix(String(e)); continue; }
      for (const k of Object.keys(e).sort()) { const v = e[k]; mix(k); mix(typeof v === 'function' ? `f${v.length}` : v && typeof v === 'object' ? `o${Object.keys(v).length}` : String(v)); }
    }
  }
  return `${n}:${h.toString(16)}`;
}
let SIM_PRINT = null;
function checkSimIntact() {
  try {
    const now = simFingerprint();
    SIM_PRINT = SIM_PRINT ?? now;
    const shared = ['BattleMovedex', 'BattleAbilities', 'BattleItems', 'BattlePokedex', 'BattleTypeChart'].filter((g) => globalThis[g] && Object.values(SimDex.data).includes(globalThis[g]));
    const ok = now === SIM_PRINT && !shared.length;
    if (!ok) console.error('Capsule Link: Pokémon Showdown\'s simulator data was changed during the battle', { before: SIM_PRINT, now, shared });
    return ok;
  } catch (e) { console.warn('showdown check', e); return true; }
}

function knows(kind, name) {
  const t = { species: SimDex.species, move: SimDex.moves, item: SimDex.items, ability: SimDex.abilities }[kind];
  return !!t?.get(String(name ?? '')).exists;
}

// ---------- the wild one's mind: mostly the strongest hit, sometimes something else ----------
function wildChoice(sim, req) {
  const me = sim.p2.active[0], foe = sim.p1.active[0];
  const opts = (req.active?.[0]?.moves ?? []).map((m, i) => ({ m, i: i + 1 })).filter(({ m }) => !m.disabled && (m.pp ?? 1) > 0);
  if (!opts.length) return 'move 1';
  const score = ({ m }) => {
    const mv = SimDex.moves.get(m.id);
    if (!foe || !mv.exists) return 10;
    if (mv.category === 'Status') return foe.status || mv.target === 'self' ? 12 : 30;
    if (!SimDex.getImmunity(mv.type, foe)) return 0;
    const eff = 2 ** SimDex.getEffectiveness(mv.type, foe);
    const stab = me?.getTypes?.().includes(mv.type) ? 1.5 : 1;
    return (mv.basePower || 50) * eff * stab * ((mv.accuracy === true ? 100 : mv.accuracy) / 100);
  };
  const scored = opts.map((o) => ({ ...o, s: score(o) * (0.75 + Math.random() * 0.5) })).sort((a, b) => b.s - a.s);
  const pick = Math.random() < 0.8 ? scored[0] : scored[Math.floor(Math.random() * scored.length)];
  return `move ${pick.i}`;
}

// ---------- the 2.5D stage: everything Showdown's battle screen animates, told to the app's own scene ----------
// Showdown's screen keeps running (hidden) so the battle's pace stays exactly Showdown's; each animation it
// starts is passed on as a small event.
function hookScene(battle, sink) {
  const sc = battle.scene;
  const info = (p) => p && p.side ? ({
    side: p.side.isFar ? 1 : 0, species: p.speciesForme ?? p.species ?? '', name: p.name ?? '', hp: p.hp, maxhp: p.maxhp || 100,
    pct: p.maxhp ? Math.max(0, Math.min(1, p.hp / p.maxhp)) : 0, status: p.status || '', level: p.level ?? 100, gender: p.gender ?? '',
    shiny: !!p.shiny, fainted: !!p.fainted || p.hp <= 0, ident: p.ident ?? '', tera: p.terastallized || '', boosts: { ...(p.boosts ?? {}) }, vol: Object.keys(p.volatiles ?? {}),
    // the form it's in right now (Castform in the rain, a Mega, Aegislash's Blade Forme, …) and the one it came in as
    base: p.baseSpeciesForme ?? p.details?.split(',')[0] ?? '', sprite: spriteForme(p), types: typesOf(p),
  }) : null;
  // what it looks like: a Pokémon transformed into another (Transform, Imposter) looks like that one
  function spriteForme(p) { try { return p.volatiles?.formechange?.[1] ?? p.volatiles?.transform?.[1]?.speciesForme ?? p.speciesForme ?? p.species ?? ''; } catch { return p.speciesForme ?? ''; } }
  function typesOf(p) { try { const t = p.volatiles?.typechange?.[1]; if (t) return String(t).split('/'); return [...(ClientDex.species.get(spriteForme(p)).types ?? [])]; } catch { return []; } }
  const team = () => [battle.nearSide ?? battle.sides[0], battle.farSide ?? battle.sides[1]].map((sd) => {
    const n = Math.max(sd.totalPokemon || 0, sd.pokemon.length);
    return Array.from({ length: n }, (_, i) => { const p = sd.pokemon[i]; return p ? { fainted: !!p.fainted || p.hp <= 0, status: p.status || '', seen: true } : { seen: false }; });
  });
  const terrainNow = () => { try { const t = (battle.pseudoWeather ?? []).map((p) => String(p[0])).find((n) => /terrain/i.test(n)); return t ? t.toLowerCase().replace(/[^a-z]/g, '') : ''; } catch { return ''; } };
  const send = (ev) => { try { sink.event({ ...ev, team: team(), weather: battle.weather || '', terrain: terrainNow() }); } catch (e) { console.warn('stage', e); } };
  const wrap = (obj, name, make) => {
    const orig = obj?.[name];
    if (typeof orig !== 'function') return;
    obj[name] = function (...a) {
      let ev = null;
      try { ev = make(...a); } catch (e) { console.warn(e); }
      const out = orig.apply(this, a);
      if (ev) send({ t: name, ...ev });
      // the 2.5D stage's pacing: a little longer on each move, hit and faint, so the camera can follow
      // (scaled with Showdown's speed: none at all on the fastest)
      try { const ms = sink.pace?.()?.[name]; if (ms && this.animating !== false && typeof this.wait === 'function') this.wait(ms / Math.max(1, this.acceleration || 1)); } catch { /* fine */ }
      return out;
    };
  };
  const moveInfo = (id) => {
    const mv = SimDex.moves.get(id);
    // everything the stage needs to choose how a move looks (multi-hit, draining, trapping, priority, …)
    return { id: mv.id || toID(id), name: mv.name || String(id), type: mv.type || 'Normal', cat: mv.category || 'Physical', flags: { ...(mv.flags ?? {}) }, bp: mv.basePower || 0, target: mv.target || 'normal',
      priority: mv.priority || 0, multihit: mv.multihit ?? null, drain: !!mv.drain, heal: !!(mv.heal || mv.flags?.heal), status: mv.status || null, volatile: mv.volatileStatus || mv.self?.volatileStatus || null,
      boosts: mv.boosts ?? null, selfBoost: mv.selfBoost?.boosts ?? mv.self?.boosts ?? null, weather: mv.weather || null, terrain: mv.terrain || null, side: mv.sideCondition || mv.slotCondition || null,
      field: mv.pseudoWeather || null, ohko: !!mv.ohko, selfdestruct: !!mv.selfdestruct, recoil: !!(mv.recoil || mv.hasCrashDamage), switches: !!mv.selfSwitch, forceSwitch: !!mv.forceSwitch,
      charge: !!mv.flags?.charge, recharge: !!mv.flags?.recharge, stalling: !!mv.stallingMove, secondaryStatus: mv.secondary?.status || null };
  };
  wrap(sc, 'animSummon', (p) => ({ mon: info(p) }));
  wrap(sc, 'animDragIn', (p) => ({ mon: info(p) }));
  wrap(sc, 'animUnsummon', (p) => ({ mon: info(p) }));
  wrap(sc, 'animDragOut', (p) => ({ mon: info(p) }));
  wrap(sc, 'animFaint', (p) => ({ mon: info(p) }));
  wrap(sc, 'damageAnim', (p) => ({ mon: info(p) }));
  wrap(sc, 'healAnim', (p) => ({ mon: info(p) }));
  wrap(sc, 'updateStatbar', (p) => ({ mon: info(p) }));
  wrap(sc, 'animTransform', (p) => ({ mon: info(p) }));
  // What this move is about to do, read ahead in the battle log, so the stage can act it out exactly: how many
  // hits really land, a critical hit, super effective or not, no effect, a miss, blocked by Protect, a
  // substitute taking it, a knockout.
  const ahead = () => {
    const q = battle.stepQueue ?? [], o = { hits: 0, crit: false, superEff: false, resisted: false, immune: false, miss: false, blocked: null, sub: false, ko: false, failed: false };
    for (let i = (battle.currentStep ?? 0) + 1; i < q.length && i < (battle.currentStep ?? 0) + 40; i++) {
      const l = String(q[i] ?? '');
      if (/^\|-anim\|/.test(l)) { o.moreAnim = true; break; }
      if (/^\|(move|turn|upkeep|cant|switch|drag|win|tie)\|/.test(l) || l === '|upkeep') break;
      const p = l.split('|');
      if (p[1] === '-damage' && !/\[from\]/.test(l)) o.hits++;
      else if (p[1] === '-hitcount') o.hits = Math.max(o.hits, Number(p[3]) || 0);
      else if (p[1] === '-crit') o.crit = true;
      else if (p[1] === '-supereffective') o.superEff = true;
      else if (p[1] === '-resisted') o.resisted = true;
      else if (p[1] === '-immune') o.immune = true;
      else if (p[1] === '-miss') o.miss = true;
      else if (p[1] === '-fail') o.failed = true;
      else if (p[1] === 'faint') o.ko = true;
      else if (p[1] === '-activate' && /move: (Protect|Detect|King's Shield|Spiky Shield|Baneful Bunker|Silk Trap|Burning Bulwark|Obstruct|Max Guard|Mat Block|Quick Guard|Wide Guard|Crafty Shield)/.test(l)) o.blocked = /move: ([^|]+)/.exec(l)[1];
      else if (p[1] === '-activate' && /Substitute\|\[damage\]/.test(l)) { o.sub = true; o.hits++; }
    }
    return o;
  };
  // a miss: Showdown aims the move at an empty spot (its 'missed' stand-in) on the target's side
  wrap(sc, 'runMoveAnim', (id, parts) => { const miss = !!parts?.[1]?.sprite?.isMissedPokemon; const from = info(parts?.[0]); let out = null; try { out = ahead(); } catch { /* fine */ } const again = /^\|-anim\|/.test(String(battle.stepQueue?.[battle.currentStep] ?? '')); return { move: moveInfo(id), from, to: miss ? null : info(parts?.[1]), miss: miss || !!out?.miss, spread: (parts?.length ?? 0) > 2, outcome: out, again }; });
  wrap(sc, 'runPrepareAnim', (id, a, d) => ({ move: moveInfo(id), from: info(a), to: info(d) }));
  wrap(sc, 'runOtherAnim', (id, parts) => ({ id: String(id), from: info(parts?.[0]), to: info(parts?.[1]) }));
  wrap(sc, 'runStatusAnim', (id, parts) => ({ id: String(id), mon: info(parts?.[0]) }));
  wrap(sc, 'runResidualAnim', (id, p) => ({ id: String(id), mon: info(p) }));
  wrap(sc, 'resultAnim', (p, result, type) => ({ mon: info(p), text: String(result ?? '').replace(/<[^>]+>/g, ''), kind: type }));
  wrap(sc, 'abilityActivateAnim', (p, result) => ({ mon: info(p), text: String(result ?? '') }));
  wrap(sc, 'typeAnim', (p, types) => ({ mon: info(p), text: String(types ?? '') }));
  wrap(sc, 'updateWeather', () => ({}));
  wrap(sc, 'message', (m) => ({ text: String(m ?? '').replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#39;|&apos;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim() }));
  wrap(sc, 'incrementTurn', () => ({ turn: battle.turn + 1 }));
  wrap(sc, 'beforeMove', (p) => ({ mon: info(p) }));
  sink.init?.({
    listenTooltips: (el) => { try { sc.tooltips?.listen(el); } catch { /* no tooltips */ } },
    moveInfo,
  });
}

/**
 * opts: {
 *   host,                       the element to fill
 *   trainer,                    your name
 *   team: [set],                Showdown sets for your party (name = a unique nickname), plus hpLeft / ppLeft
 *   foe: set,                   the wild one
 *   seed: [n, n, n, n],
 *   sprite(species, { shiny, back }) → { url, w, h } | null      your own pictures (else Showdown's online ones)
 *   fx(file) → url | null,      Showdown effect pictures saved by Download everything (else online)
 *   backdrop: url | null,
 * }
 * done → { won, ran, lost, team: { name: { hp, maxhp, status, pp: [n] , fainted } }, out: [names that battled], turns }
 */
function start(opts) {
  // pictures: Showdown's own sprites (forms and all, as on play.pokemonshowdown.com); a creature Showdown
  // doesn't draw falls back to the app's picture. Effect pictures come from Download everything when saved.
  if (!ClientDex.__capsuleSprites) {
    const original = ClientDex.getSpriteData.bind(ClientDex);
    ClientDex.__capsuleSprites = true;
    ClientDex.getSpriteData = (pokemon, isFront, o = {}) => {
      const base = original(pokemon, isFront, o);
      const name = typeof pokemon === 'string' ? pokemon : pokemon?.speciesForme ?? pokemon?.name ?? '';
      // offline, Showdown's pictures can't load: the app's own then
      if ((SimDex.species.get(name).exists && navigator.onLine !== false) || !ClientDex.__capsuleFallback) return base;
      const mine = ClientDex.__capsuleFallback(name, { shiny: !!(o.shiny ?? pokemon?.shiny), back: !isFront });
      return mine ? { ...base, url: mine.url, w: mine.w, h: mine.h, y: 0, pixelated: true, isFrontSprite: isFront, cryurl: '' } : base;
    };
  }
  ClientDex.__capsuleFallback = opts.sprite ?? null;
  // your trainer picture: a picture of your own (from your ID card) shows on Showdown's screen too
  if (!ClientDex.__capsuleAvatar) { const orig = ClientDex.resolveAvatar.bind(ClientDex); ClientDex.resolveAvatar = (av) => (av === 'capsule-me' && ClientDex.__capsuleAvatar?.() ? ClientDex.__capsuleAvatar() : orig(av)); }
  ClientDex.__capsuleAvatar = () => opts.avatarUrl ?? null;
  for (const id in BattleEffects) {
    const e = BattleEffects[id];
    if (!e.url) continue;
    e.__file = e.__file ?? e.url.split('/').pop();
    e.url = opts.fx?.(e.__file) ?? `https://play.pokemonshowdown.com/fx/${e.__file}`;
  }
  // sounds and music, from Showdown (when online), at the app's volume
  BattleSound.setMute?.(!opts.sound);
  try { globalThis.__clBattleSound = BattleSound; } catch { /* fine */ }
  let volume = Math.max(0, Math.min(1, Number(opts.volume ?? 0.6)));
  // Showdown's own volume controls (loudness, as its sliders do); music a little under the effects
  // (Showdown only sets the music's volume when a track starts, so the track that's playing is set here too,
  // or a change wouldn't be heard until the sound was muted and unmuted)
  const applyVolume = () => {
    BattleSound.setEffectVolume(Math.round(volume * 100)); BattleSound.setBgmVolume(Math.round(volume * 60));
    try { for (const b of BattleSound.bgm ?? []) if (b.sound) b.sound.volume = Math.max(0, Math.min(1, (BattleSound.muted ? 0 : BattleSound.bgmVolume) / 100)); } catch { /* fine */ }
    try { for (const a of Object.values(BattleSound.soundCache ?? {})) if (a && !a.paused && !(BattleSound.bgm ?? []).some((b) => b.sound === a)) a.volume = Math.max(0, Math.min(1, BattleSound.effectVolume / 100)); } catch { /* fine */ }
  };
  applyVolume();

  const host = opts.host;
  host.innerHTML = '';
  host.classList.add('cl-sd');
  const frame = $('<div class="battle"></div>'), logFrame = $('<div class="battle-log"></div>');
  const stage = $('<div class="cl-sd-stage"></div>').append(frame, logFrame);
  const controls = $('<div class="cl-sd-controls battle-controls" role="group" aria-label="Your move"></div>');
  $(host).append(stage, controls);

  const battle = new Battle({ $frame: frame, $logFrame: logFrame, id: 'capsule-wild', autoresize: false });
  battle.pokemonControlled = 1;
  // the app's own 2.5D scene takes the battle screen's place (Showdown's keeps running underneath, unseen)
  if (opts.stage) {
    host.classList.add('cl-sd-3d');
    stage.prepend(opts.stage.el);
    hookScene(battle, opts.stage);
  }
  battle.scene.tooltips?.listen(controls[0]);
  battle.setMute?.(!opts.sound); // sound on unless it's switched off in the app's settings
  if (opts.backdrop) { battle.scene.backdropImage = ''; battle.scene.$bg?.css({ 'background-image': `url("${opts.backdrop}")`, 'background-size': 'cover', 'background-position': 'center' }); }

  // online (a battle on Showdown's own server): its messages instead of the simulator here
  const online = opts.online ?? null;
  if (online) try { const D = globalThis.BattleText?.en?.Default?.default; if (D && globalThis.__clTrainerText) Object.assign(D, globalThis.__clTrainerText); } catch { /* fine */ }
  const stream = online ? { battle: null, destroy() {} } : new BattleStream();
  const ps = online ? null : getPlayerStreams(stream);
  let request = null, ended = false, ran = false, won = null;
  const out = new Set();
  checkSimIntact(); // the simulator's data as Showdown made it (first battle), or as it was then (later ones)
  let resolveDone;
  const done = new Promise((r) => { resolveDone = r; });

  // Showdown's own speeds (as in its Options: animation speed)
  const SPEEDS = { slow: [700, 1500], normal: [450, 300], fast: [150, 1], hyperfast: [60, 1] };
  let speed = 'normal';
  try { speed = localStorage.getItem('clSdSpeed') || 'normal'; } catch { /* default */ }
  const applySpeed = () => { const [fade, shown] = SPEEDS[speed] ?? SPEEDS.normal; battle.messageFadeTime = fade; battle.messageShownTime = shown; battle.scene.updateAcceleration?.(); };
  applySpeed();
  // the request as Showdown's own battle room keeps it: health parsed out of "hp/max status"
  const readSide = (r) => {
    for (const p of r?.side?.pokemon ?? []) {
      const [hpPart, st] = String(p.condition ?? '').split(' ');
      const [hp, mx] = hpPart.split('/').map(Number);
      p.hp = st === 'fnt' ? 0 : hp || 0; p.maxhp = mx || (st === 'fnt' ? p.maxhp ?? 0 : hp || 0);
      p.status = st && st !== 'fnt' ? st : ''; p.fainted = st === 'fnt';
      p.name = p.name ?? p.ident.slice(4); p.speciesForme = p.speciesForme ?? String(p.details).split(',')[0];
    }
    return r?.side?.pokemon ?? null;
  };
  // like on Showdown, your choices only appear once the turn has finished playing out, and only one counts
  let waitingForQueue = false, chosen = false;
  battle.subscribe((ev) => {
    if (ev !== 'atqueueend') return;
    if (ended) finish();
    else if (waitingForQueue) { waitingForQueue = false; showControls(); }
  });
  const playing = () => {
    controls.html(`<div class="whatdo"><em>…</em></div><button class="button cl-sd-skip" type="button" title="Skip to the end of this turn">Skip turn ▸▸</button>${soundButton()}${speedPicker()}`);
    wireSound();
    controls.find('.cl-sd-skip').on('click', () => { try { battle.skipTurn(); } catch { /* fine */ } });
    wireSpeed();
  };
  const speedPicker = () => `<label class="cl-sd-speed">Speed <select>${Object.keys(SPEEDS).map((k) => `<option value="${k}" ${k === speed ? 'selected' : ''}>${{ slow: 'Slow', normal: 'Normal', fast: 'Fast', hyperfast: 'Hyperfast' }[k]}</option>`).join('')}</select></label>`;
  const wireSpeed = () => controls.find('.cl-sd-speed select').on('change', (e) => { speed = e.target.value; try { localStorage.setItem('clSdSpeed', speed); } catch { /* fine */ } applySpeed(); });

  const finish = () => {
    if (finish.called) return; finish.called = true;
    if (online) {
      const verdict = online.spectate ? (winnerName ? `${winnerName} won the battle!` : 'The battle is over.') : won ? 'You won!' : ran ? 'You forfeited.' : won === false ? 'You lost. Good game!' : 'The battle is over.';
      controls.html(`<div class="whatdo">${verdict}</div><button class="button cl-sd-continue" type="button">${online.spectate ? 'Done' : 'Continue'}</button>`);
      controls.find('.cl-sd-continue').on('click', () => resolveDone({ won: !!won, ran, lost: won === false, team: {}, out: [...out], turns: battle.turn, online: true }));
      return;
    }
    const sim = stream.battle;
    const team = {};
    for (const p of sim?.p1?.pokemon ?? []) team[p.set.name] = { hp: p.fainted ? 0 : p.hp, maxhp: p.maxhp, status: p.status || null, pp: p.baseMoveSlots.map((m) => m.pp), fainted: !!p.fainted };
    controls.html(`<div class="whatdo">${won ? 'You won!' : ran ? (opts.foeTeam?.length ? 'You gave in.' : 'Got away safely.') : 'Everyone needs a rest…'}</div><button class="button cl-sd-continue" type="button">Continue</button>`);
    const intact = checkSimIntact();
    controls.find('.cl-sd-continue').on('click', () => resolveDone({ won: !!won, ran, lost: !won && !ran, team, out: [...out], turns: battle.turn, showdownIntact: intact }));
  };

  // the screen: everything your side can see
  let me = 'p1', winnerName = '';
  const consume = (chunk) => {
    for (const line of chunk.split('\n')) {
      if (line.startsWith('|request|')) {
        const j = line.slice(9); if (!j) continue;
        request = JSON.parse(j); chosen = false;
        if (online && request.side?.id && request.side.id !== me) { me = request.side.id; battle.setViewpoint?.(me); }
        battle.myPokemon = readSide(request); fieldWeather();
        if (request.teamPreview) { online?.choose('default', request.rqid); chosen = true; request = { wait: true }; }
        continue;
      }
      if (online && line.startsWith('|error|')) { // a choice the server didn't take: choose again
        battle.add(`|-message|${line.slice(7).replace(/^\[[^\]]*\]\s*/, '')}`); chosen = false; if (request && !request.wait) showControls(); continue;
      }
      if (line.startsWith(`|switch|${me}a: `) || line.startsWith(`|drag|${me}a: `)) out.add(line.split('|')[2].slice(5));
      if (line.startsWith('|win|')) { const w = line.slice(5); winnerName = w; won = online ? online.isMe(w) : w === opts.trainer; ended = true; }
      if (line === '|tie' || line.startsWith('|tie|')) { won = online ? false : won; ended = true; }
      if (line.startsWith('|tier|') || line.startsWith('|rule|') || line.startsWith('|t:|') || line.startsWith('|init|') || line.startsWith('|title|') || line.startsWith('|inactive')) continue;
      battle.add(line);
    }
    if (ended) { if (battle.atQueueEnd) finish(); }
    else if (request && !request.wait && !chosen) {
      if (battle.atQueueEnd) showControls();
      else { waitingForQueue = true; playing(); }
    }
  };
  // watching a replay: nothing to choose, just a way out (and how far along it is)
  if (online?.spectate) {
    const spectating = () => { if (ended) return; host.classList.add('cl-sd-spectating'); controls.html(`<div class="whatdo"><em>${online.title ? online.title.replace(/[<>&]/g, '') : 'Replay'}</em></div><button class="button cl-sd-skip" type="button" title="Skip to the end of this turn">Skip turn ▸▸</button><button class="button cl-sd-continue" type="button">Stop watching</button>${speedPicker()}`); wireSpeed(); controls.find('.cl-sd-skip').on('click', () => { try { battle.skipTurn(); } catch { /* fine */ } }); controls.find('.cl-sd-continue').on('click', () => { ended = true; resolveDone({ won: false, ran: true, team: {}, out: [], turns: battle.turn, online: true }); }); };
    spectating();
  }
  if (online) online.onChunk((chunk) => { try { consume(chunk); } catch (e) { console.error(e); } }, () => { if (!ended) { ended = true; battle.add('|-message|Lost the connection to Showdown.'); finish(); } });
  else (async () => { for await (const chunk of ps.p1) consume(chunk); })().catch((e) => { console.error(e); controls.text(`The battle stopped: ${e.message}`); });
  // the wild side
  if (!online) (async () => {
    for await (const chunk of ps.p2) {
      for (const line of chunk.split('\n')) {
        if (!line.startsWith('|request|')) continue;
        const r = JSON.parse(line.slice(9) || 'null');
        if (!r || r.wait) continue;
        if (r.forceSwitch) {
          // a trainer sends out their next one (the healthiest-looking first in line); a wild one has no one
          const next = (r.side?.pokemon ?? []).findIndex((p) => !p.active && !/ fnt$/.test(p.condition));
          ps.p2.write(next >= 0 ? `switch ${next + 1}` : 'pass'); continue;
        }
        if (r.active) ps.p2.write(wildChoice(stream.battle, r));
      }
    }
  })().catch((e) => console.error(e));

  // The real weather where you are, as the games' overworld weather: rain (or snow, or harsh sun on a hot day)
  // that lasts the whole battle, set through the simulator's own field.setWeather before the first turn
  let fieldDone = !opts.fieldWeather || !!online;
  function fieldWeather() {
    if (fieldDone) return; fieldDone = true;
    try {
      const sim = stream.battle, src = sim?.p2?.active?.[0] ?? sim?.p1?.active?.[0];
      if (!sim || !src || sim.field.weather) return;
      sim.add('-message', opts.fieldWeatherText || 'The weather where you are carries into the battle!');
      if (sim.field.setWeather(opts.fieldWeather, src)) sim.field.weatherState.duration = 0; // (0: it never runs out)
      sim.sendUpdates?.();
    } catch (e) { console.warn('weather', e); }
  }

  // ---------- the bag: items used in battle (medicine, status heals, revives, PP, X items, berries) ----------
  // Using one takes your creature's turn, as in the games: its own action is dropped and the item is used at
  // the start of the turn, through the simulator's own methods (heal, cureStatus, boostBy…) so its log, the
  // request and the end-of-battle result all see it. Showdown's code isn't changed: only this battle object.
  const bag = (opts.bag ?? []).map((b) => ({ ...b }));
  const simMon = (p) => ({ name: p.name, hp: p.hp, maxhp: p.maxhp, status: p.status, fainted: !!p.fainted, confused: !!p.volatiles?.confusion, moves: p.moveSlots.map((m) => ({ id: m.id, move: m.move, pp: m.pp, maxpp: m.maxpp })) });
  function bagScreen($bag, { level, act }) {
    const sim = stream.battle, side = sim?.p1;
    const grid = $bag.find('.pbr-grid'), note = $bag.closest('.pbr-menu').find('.pbr-prompt');
    const prompt0 = note.text();
    const back = () => { note.text(prompt0); level('main'); };
    $bag.find('.pbr-back').off('click').on('click', back);
    const say = (t) => note.text(t);
    const list = () => {
      const items = bag.filter((b) => b.count > 0);
      say(items.length ? 'Use which item?' : '');
      grid.html(items.length ? items.map((b, i) => `<button class="pbr-panel pbr-item" data-k="${i}" type="button" title="${esc(b.desc)}"><span class="nm">${esc(b.name)}</span><span class="ct">×${b.count}</span><span class="ds">${esc(b.desc)}</span></button>`).join('') : '<em>Nothing in the bag can be used in a battle. (Held items are given to someone to hold before the battle.)</em>');
      grid.find('.pbr-item').on('click', (e) => pickWho(items[Number(e.currentTarget.dataset.k)]));
      $bag.find('.pbr-back').off('click').on('click', back);
    };
    const pickWho = (b) => {
      const mons = (side?.pokemon ?? []).map((p, slot) => ({ p, slot })).filter(({ p }) => (b.target === 'fainted' ? p.fainted : b.target === 'active' ? p.isActive : !p.fainted));
      if (b.target === 'active' && mons.length === 1) return pickMove(b, mons[0]);
      say(`Use the ${b.name} on who?`);
      grid.html(mons.length ? mons.map(({ p, slot }) => { const pct = Math.round((100 * p.hp) / (p.maxhp || 1)); return `<button class="pbr-panel pbr-mon" data-s="${slot}" type="button"><span class="nm">${esc(p.name)}</span><span class="lv">${p.fainted ? 'FNT' : p.status ? p.status.toUpperCase() : `Lv. ${p.level}`}</span><span class="hp"><span class="${pct > 50 ? 'g' : pct > 20 ? 'y' : 'r'}" style="width:${pct}%"></span></span><span class="num">${p.hp}/${p.maxhp}</span></button>`; }).join('') : `<em>${b.target === 'fainted' ? 'Nobody has fainted.' : 'Nobody to use it on.'}</em>`);
      grid.find('.pbr-mon').on('click', (e) => { const m = mons.find((x) => x.slot === Number(e.currentTarget.dataset.s)); if (m) pickMove(b, m); });
      $bag.find('.pbr-back').off('click').on('click', list);
    };
    const pickMove = (b, m) => {
      if (!b.needsMove) return useIt(b, m, null);
      say(`Restore PP to which of ${m.p.name}’s moves?`);
      grid.html(m.p.moveSlots.map((mv, i) => `<button class="pbr-panel pbr-move" data-i="${i}" type="button"><span class="nm">${esc(mv.move)}</span><span class="pp">${mv.pp}/${mv.maxpp}</span></button>`).join(''));
      grid.find('.pbr-move').on('click', (e) => useIt(b, m, Number(e.currentTarget.dataset.i)));
      $bag.find('.pbr-back').off('click').on('click', () => pickWho(b));
    };
    const useIt = (b, m, moveIndex) => {
      const why = opts.whyNoEffect?.(b.use, simMon(m.p), moveIndex);
      if (why) { say(why); return; }
      b.count--;
      try { opts.onUseItem?.(b.id); } catch (e) { console.warn(e); }
      useItem(b, m.p, moveIndex, act);
    };
    list();
  }
  function useItem(b, target, moveIndex, act) {
    const sim = stream.battle, side = sim.p1, user = side.active[0];
    const orig = sim.turnLoop;
    sim.turnLoop = function (...a) {
      sim.turnLoop = orig;
      try {
        // the trainer's turn instead of the creature's
        sim.queue.list = sim.queue.list.filter((x) => !(x.pokemon === user && ['move', 'beforeTurnMove', 'priorityChargeMove'].includes(x.choice)));
        const u = b.use, an = /^[aeiou]/i.test(b.name) ? 'an' : 'a';
        sim.add('-message', `${opts.trainer} used ${an} ${b.name}${target === user ? '' : ` on ${target.name}`}!`);
        if (u.revive) {
          Object.assign(target, { fainted: false, faintQueued: false, subFainted: false, status: '', hp: 1 });
          target.sethp(Math.max(1, Math.floor(target.maxhp * u.revive))); side.pokemonLeft++;
          sim.add('-heal', target, target.getHealth, '[silent]'); sim.add('-message', `${target.name} was revived!`);
        }
        if (u.full || u.hp || u.frac) { const d = target.heal(u.full ? target.maxhp : u.frac ? Math.floor(target.maxhp * u.frac) : u.hp); if (d) sim.add('-heal', target, target.getHealth); }
        if (u.cure && target.status && (u.cure === true || u.cure === target.status || (u.cure === 'psn' && target.status === 'tox'))) target.cureStatus();
        if (u.confusion && target.volatiles?.confusion) target.removeVolatile('confusion');
        if (u.pp) {
          const ids = u.one ? [target.moveSlots[moveIndex ?? 0]?.id] : target.moveSlots.map((m) => m.id);
          for (const list of [target.moveSlots, target.baseMoveSlots]) for (const ms of list) if (ids.includes(ms.id)) ms.pp = Math.min(ms.maxpp, ms.pp + u.pp);
          sim.add('-message', `${target.name}’s PP was restored.`);
        }
        if (u.boost) for (const [k, v] of Object.entries(u.boost)) { const d = target.boostBy({ [k]: v }); sim.add('-boost', target, k, d); }
        if (u.crit && !target.addVolatile('focusenergy')) sim.add('-fail', target);
        if (u.mist && !side.addSideCondition('mist')) sim.add('-fail', target);
      } catch (e) { console.warn('bag', e); }
      return orig.apply(this, a);
    };
    // any move will do as the choice: it's dropped before the turn runs
    const i = Math.max(0, (act.moves ?? []).findIndex((m) => !m.disabled && m.pp !== 0));
    send(`move ${i + 1}`);
  }

  const send = (choice) => {
    if (chosen) return; // a double click doesn't pick twice (or pick next turn's move early)
    chosen = true;
    controls.html(`<div class="whatdo"><em>${online ? 'Waiting for your opponent…' : 'Waiting…'}</em></div>`);
    if (online) online.choose(choice, request?.rqid); else ps.p1.write(choice);
  };
  // sound on/off, in every state of the controls (it shows in the 2.5D view too)
  // sound on/off and the battle's volume (cries, move sounds and music), kept for next time
  const icon = () => (BattleSound.muted || volume <= 0 ? '🔇' : volume < 0.4 ? '🔈' : volume < 0.75 ? '🔉' : '🔊');
  const soundButton = () => `<span class="cl-sd-sound"><button class="button cl-sd-mute" type="button" title="Sound on or off" aria-label="Sound on or off">${icon()}</button><input class="cl-sd-vol" type="range" min="0" max="1" step="0.05" value="${volume}" title="Battle volume" aria-label="Battle volume" /></span>`;
  function wireSound() {
    controls.find('.cl-sd-mute').off('click').on('click', (e) => { const m = !BattleSound.muted; battle.setMute?.(m); BattleSound.setMute(m); if (!m) battle.scene.updateBgm?.(); e.currentTarget.textContent = icon(); opts.onSound?.(!m); });
    controls.find('.cl-sd-vol').off('input change').on('input change', (e) => {
      volume = Number(e.target.value); applyVolume();
      if (volume > 0 && BattleSound.muted) { battle.setMute?.(false); BattleSound.setMute(false); battle.scene.updateBgm?.(); opts.onSound?.(true); }
      controls.find('.cl-sd-mute').text(icon());
      if (e.type === 'change') opts.onVolume?.(volume);
    });
  }
  function showControls() {
    const r = request;
    if (!r || ended) return;
    if (r.wait) { controls.html('<div class="whatdo"><em>Waiting…</em></div>'); return; }
    const side = r.side?.pokemon ?? [];
    const switchable = side.map((p, i) => ({ p, i })).filter(({ p }) => !p.active && !/ fnt$/.test(p.condition));
    const sw = switchable.map(({ p, i }) => {
      const [hp, mx] = String(p.condition).split(' ')[0].split('/').map(Number);
      const pct = Math.max(0, Math.min(100, Math.round((100 * hp) / (mx || 1))));
      const col = pct > 50 ? '' : pct > 20 ? ' hpbar-yellow' : ' hpbar-red';
      return `<button class="button cl-sd-switch has-tooltip" data-i="${i + 1}" data-tooltip="switchpokemon|${i}" type="button"><span class="picon" style="${esc(ClientDex.getPokemonIcon(p))}"></span>${esc(p.ident.slice(4))}<span class="hpbar${col}"><span style="width:${pct}%"></span></span></button>`;
    }).join('');
    const TYPE_SHORT = { Normal: 'NORMAL', Fire: 'FIRE', Water: 'WATER', Electric: 'ELECTR', Grass: 'GRASS', Ice: 'ICE', Fighting: 'FIGHT', Poison: 'POISON', Ground: 'GROUND', Flying: 'FLYING', Psychic: 'PSYCHC', Bug: 'BUG', Rock: 'ROCK', Ghost: 'GHOST', Dragon: 'DRAGON', Dark: 'DARK', Steel: 'STEEL', Fairy: 'FAIRY', Stellar: 'STELLR' };
    const pbrParty = switchable.map(({ p, i }) => {
      const [hp, mx] = String(p.condition).split(' ')[0].split('/').map(Number);
      const pct = Math.max(0, Math.min(100, Math.round((100 * hp) / (mx || 1))));
      return `<button class="pbr-panel pbr-mon has-tooltip" data-i="${i + 1}" data-tooltip="switchpokemon|${i}" type="button"><span class="picon" style="${esc(ClientDex.getPokemonIcon(p))}"></span><span class="nm">${esc(p.ident.slice(4))}</span><span class="lv">Lv. ${esc(String(p.details).match(/L(\d+)/)?.[1] ?? '100')}</span><span class="hp"><span class="${pct > 50 ? 'g' : pct > 20 ? 'y' : 'r'}" style="width:${pct}%"></span></span><span class="num">${hp}/${mx}</span></button>`;
    }).join('');
    // Battle Revolution's menu: FIGHT / POKéMON / GIVE IN, then the four moves (or the party) on their own screen
    const pbrMenu = ({ level = 'main', prompt, moves: mv = '', party = '', canBack = true, gimmicks: gm = '', trapped = false }) =>
      `<div class="pbr-menu" data-level="${level}"><div class="pbr-prompt">${prompt}</div>` +
      `<div class="pbr-main"><button class="pbr-panel pbr-fight" type="button">FIGHT</button><div class="pbr-row"><button class="pbr-panel pbr-pokemon" type="button" ${party ? '' : 'disabled'}>POKéMON</button><button class="pbr-panel pbr-bagbtn" type="button" ${online ? 'disabled title="No bag in online battles"' : ''}>BAG</button><button class="pbr-panel pbr-givein" type="button" ${trapped && !online ? 'disabled' : ''}>GIVE IN</button></div></div>` +
      `<div class="pbr-bag"><div class="pbr-grid"></div><button class="pbr-panel pbr-back" type="button" title="Back (Esc)">BACK</button></div>` +
      `<div class="pbr-moves"><div class="pbr-grid">${mv}</div>${canBack ? '<button class="pbr-panel pbr-back" type="button" title="Back (Esc)">BACK</button>' : ''}${gm ? `<div class="pbr-gimmicks">${gm}</div>` : ''}</div>` +
      `<div class="pbr-party"><div class="pbr-grid">${party || '<em>Nobody else can battle.</em>'}</div>${canBack ? '<button class="pbr-panel pbr-back" type="button" title="Back (Esc)">BACK</button>' : ''}</div></div>`;
    if (r.forceSwitch) {
      controls.html(`<div class="whatdo">Who’s next?</div><div class="switchmenu">${sw || '<em>Nobody left.</em>'}</div>` + pbrMenu({ level: 'party', prompt: 'Who will you send out?', party: pbrParty, canBack: false }));
    } else {
      const act = r.active?.[0] ?? { moves: [] };
      const moves = act.moves.map((m, i) => {
        const mv = SimDex.moves.get(m.id);
        const type = mv.exists ? mv.type : 'Normal';
        return `<button class="button type-${type} movebutton has-tooltip" data-i="${i + 1}" data-tooltip="move|${esc(m.id)}|0" type="button" ${m.disabled || m.pp === 0 ? 'disabled' : ''}>${esc(m.move)}<br /><small class="type">${type}</small> <small class="pp">${m.pp}/${m.maxpp}</small></button>`;
      }).join('');
      const me = side.find((p) => p.active);
      // Showdown's extra options for this turn, when the battle allows them
      const gimmicks = [
        act.canMegaEvo && ['mega', 'Mega Evolution'], act.canMegaEvoX && ['megax', 'Mega Evolution X'], act.canMegaEvoY && ['megay', 'Mega Evolution Y'],
        act.canUltraBurst && ['ultra', 'Ultra Burst'], act.canZMove && ['zmove', 'Z-Power'], act.canDynamax && ['dynamax', 'Dynamax'],
        act.canTerastallize && ['terastallize', `Terastallize <small>(${esc(act.canTerastallize)})</small>`],
      ].filter(Boolean).map(([k, label]) => `<label class="cl-sd-gimmick"><input type="checkbox" name="${k}" /> ${label}</label>`).join('');
      controls.html(
        soundButton() +
        `<div class="whatdo">What will <strong>${esc(me?.ident?.slice(4) ?? 'your creature')}</strong> do?</div>` +
        `<div class="cl-sd-groups"><div class="movecontrols"><div class="moveselect">Attack</div><div class="movemenu">${moves}</div>${gimmicks ? `<div class="cl-sd-gimmicks">${gimmicks}</div>` : ''}</div>` +
        `<div class="switchcontrols"><div class="switchselect">Switch</div><div class="switchmenu">${act.trapped ? '<em>Can’t get away!</em>' : sw || '<em>Nobody else can battle.</em>'}</div>` +
        `<div class="cl-sd-run"><button class="button cl-sd-runbtn" type="button" ${act.trapped && !online ? 'disabled' : ''}>Run</button></div></div></div>` +
        pbrMenu({ prompt: `What will ${esc((me?.ident?.slice(4) ?? 'your creature').toUpperCase())} do?`, trapped: !!act.trapped, party: act.trapped ? '' : pbrParty, gimmicks: gimmicks.replace(/cl-sd-gimmick"/g, 'cl-sd-gimmick pbr-gimmick"').replace(/name="/g, 'data-g="'),
          moves: act.moves.map((m, i) => { const mv = SimDex.moves.get(m.id); const type = mv.exists ? mv.type : 'Normal';
            return `<button class="pbr-panel pbr-move type-${type} has-tooltip" data-i="${i + 1}" data-tooltip="move|${esc(m.id)}|0" type="button" ${m.disabled || m.pp === 0 ? 'disabled' : ''}><span class="nm">${esc(m.move)}</span><span class="ty t-${type}">${TYPE_SHORT[type] ?? type.toUpperCase()}</span><span class="pp">${m.pp}/${m.maxpp}</span></button>`; }).join('') }));
    }
    wireSound();
    controls.find('.movebutton').on('click', (e) => {
      const g = controls.find('.cl-sd-gimmick input:checked').attr('name');
      send(`move ${e.currentTarget.dataset.i}${g ? ` ${g}` : ''}`);
    });
    // only one gimmick at a time; Z-Power shows the Z-moves' names like Showdown
    controls.find('.cl-sd-gimmick input').on('change', (e) => { if (e.target.checked) controls.find('.cl-sd-gimmick input').not(e.target).prop('checked', false); });
    controls.append(speedPicker()); wireSpeed();
    controls.find('.cl-sd-switch').on('click', (e) => send(`switch ${e.currentTarget.dataset.i}`));
    // the Battle Revolution menu: its buttons do what the plain ones do
    const menu = controls.find('.pbr-menu');
    const level = (l) => { menu.attr('data-level', l); };
    controls.find('.pbr-fight').on('click', () => level('moves'));
    controls.find('.pbr-pokemon').on('click', () => level('party'));
    controls.find('.pbr-back').on('click', () => level('main'));
    controls.find('.pbr-givein').on('click', () => controls.find('.cl-sd-runbtn').trigger('click'));
    controls.find('.pbr-bagbtn').on('click', () => { level('bag'); bagScreen(controls.find('.pbr-bag'), { level, act: r.active?.[0] ?? { moves: [] } }); });
    controls.find('.pbr-move').on('click', (e) => { const g = controls.find('.pbr-gimmick input:checked').attr('data-g'); send(`move ${e.currentTarget.dataset.i}${g ? ` ${g}` : ''}`); });
    controls.find('.pbr-gimmick input').on('change', (e) => { if (e.target.checked) controls.find('.pbr-gimmick input').not(e.target).prop('checked', false); });
    controls.find('.pbr-mon').on('click', (e) => send(`switch ${e.currentTarget.dataset.i}`));
    controls.off('keydown.pbr').on('keydown.pbr', (e) => { if (e.key === 'Escape' && menu.attr('data-level') !== 'main' && controls.find('.pbr-back').length) { if (menu.attr('data-level') === 'bag') controls.find('.pbr-bag .pbr-back').trigger('click'); else level('main'); } });
    controls.attr('tabindex', '-1');
    controls.find('.cl-sd-runbtn').on('click', () => {
      if (online) { online.forfeit(); ran = true; return; } // the server ends it (|win|), then it finishes as usual
      ran = true; ended = true;
      battle.add('|');
      battle.add(opts.foeTeam?.length ? `|-message|You gave in to ${opts.foeName}.` : '|-message|Got away safely!');
      finish();
    });
  }

  // abilities Showdown doesn't know (a home-made one) become the species' own first ability, as in its
  // teambuilder, so every battle has its real abilities; items it doesn't know are left off
  const fix = (set) => {
    const sp = SimDex.species.get(set.species);
    const out = { ...set };
    if (sp.exists && !knows('ability', out.ability)) out.ability = sp.abilities?.['0'] ?? '';
    if (out.item && !knows('item', out.item)) out.item = '';
    return out;
  };
  if (online) {
    battle.play?.();
    try { globalThis.__clSdBattle = battle; } catch { /* fine */ }
    return { done, stop() { try { online.close?.(); } catch { /* gone */ } try { battle.destroy(); } catch { /* gone */ } host.innerHTML = ''; } };
  }
  opts.team = (opts.team ?? []).map(fix);
  opts.foe = fix(opts.foe);
  const foeTeam = opts.foeTeam?.length ? opts.foeTeam.map(fix) : [opts.foe];
  // "A wild Spiritomb appeared!" for wild ones; a trainer's sends them out ("Cynthia sent out Spiritomb!")
  try { const D = globalThis.BattleText?.en?.Default?.default; const W = opts.foeTeam?.length ? globalThis.__clTrainerText : globalThis.__clWildText; if (D && W) for (const [k, v] of Object.entries(W)) if (v != null) D[k] = v; } catch { /* fine */ }
  ps.omniscient.write(`>start ${JSON.stringify({ formatid: 'gen9capsulewild', seed: opts.seed })}\n` +
    `>player p1 ${JSON.stringify({ name: opts.trainer, avatar: opts.avatar || '', team: opts.team })}\n` +
    `>player p2 ${JSON.stringify({ name: opts.foeName || 'Wild', avatar: opts.foeAvatar || 'unknown', team: foeTeam })}`);
  battle.play?.();
  try { globalThis.__clSdBattle = battle; globalThis.__clSdStream = stream; } catch { /* fine */ }

  return { done, stop() { try { stream.destroy?.(); } catch { /* gone */ } try { battle.destroy(); } catch { /* gone */ } host.innerHTML = ''; } };
}

/** A Showdown trainer avatar ('dawn', 'red', '#custom', …) → the picture's address. */
function avatarUrl(av) { try { return av ? ClientDex.resolveAvatar(String(av)) : null; } catch { return null; } }
// your team in Showdown's packed form, for battles on its server (abilities and items it doesn't know fixed as above)
function packTeam(sets) {
  return Teams.pack((sets ?? []).map((set) => { const sp = SimDex.species.get(set.species); const o = { ...set }; if (sp.exists && !knows('ability', o.ability)) o.ability = sp.abilities?.['0'] ?? ''; if (o.item && !knows('item', o.item)) o.item = ''; return o; }));
}
// a move described the way the battle stage wants it (move practice uses it outside a battle)
function stageMove(id) {
  const mv = SimDex.moves.get(id); const tid = String(id ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');
  return { id: mv.id || tid, name: mv.name || String(id), type: mv.type || 'Normal', cat: mv.category || 'Physical', flags: { ...(mv.flags ?? {}) }, bp: mv.basePower || 0, target: mv.target || 'normal',
    priority: mv.priority || 0, multihit: mv.multihit ?? null, drain: !!mv.drain, heal: !!(mv.heal || mv.flags?.heal), status: mv.status || null, volatile: mv.volatileStatus || mv.self?.volatileStatus || null,
    boosts: mv.boosts ?? null, selfBoost: mv.selfBoost?.boosts ?? mv.self?.boosts ?? null, weather: mv.weather || null, terrain: mv.terrain || null, side: mv.sideCondition || mv.slotCondition || null,
    field: mv.pseudoWeather || null, ohko: !!mv.ohko, selfdestruct: !!mv.selfdestruct, recoil: !!(mv.recoil || mv.hasCrashDamage), switches: !!mv.selfSwitch, forceSwitch: !!mv.forceSwitch,
    charge: !!mv.flags?.charge, recharge: !!mv.flags?.recharge, stalling: !!mv.stallingMove, secondaryStatus: mv.secondary?.status || null, exists: !!mv.exists };
}
globalThis.CapsuleShowdown = { knows, start, avatarUrl, packTeam, stageMove, backdrops: BattleBackdrops, intact: checkSimIntact, version: 2 };
