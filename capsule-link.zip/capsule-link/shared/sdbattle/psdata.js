// The simulator's data, bundled in (Showdown loads these from files at run time).
import { Abilities } from '../../vendor/showdown/data/abilities';
import { Rulesets } from '../../vendor/showdown/data/rulesets';
import { FormatsData } from '../../vendor/showdown/data/formats-data';
import { Items } from '../../vendor/showdown/data/items';
import { Moves } from '../../vendor/showdown/data/moves';
import { Natures } from '../../vendor/showdown/data/natures';
import { Pokedex } from '../../vendor/showdown/data/pokedex';
import { Scripts } from '../../vendor/showdown/data/scripts';
import { Conditions } from '../../vendor/showdown/data/conditions';
import { TypeChart } from '../../vendor/showdown/data/typechart';
import * as AliasModule from '../../vendor/showdown/data/aliases';
import * as T_default from '../../vendor/showdown/data/text/default';
import * as T_moves from '../../vendor/showdown/data/text/moves';
import * as T_abilities from '../../vendor/showdown/data/text/abilities';
import * as T_items from '../../vendor/showdown/data/text/items';
import * as T_names from '../../vendor/showdown/data/text/names';
import * as T_pokedex from '../../vendor/showdown/data/text/pokedex';
import * as T_tags from '../../vendor/showdown/data/text/tags';

const TABLES = { abilities: { Abilities }, rulesets: { Rulesets }, 'formats-data': { FormatsData }, items: { Items }, moves: { Moves }, natures: { Natures }, pokedex: { Pokedex }, scripts: { Scripts }, conditions: { Conditions }, typechart: { TypeChart } };
const TEXT = { default: T_default, moves: T_moves, abilities: T_abilities, items: T_items, names: T_names, pokedex: T_pokedex, tags: T_tags };
const missing = () => { const e = new Error('not bundled'); e.code = 'MODULE_NOT_FOUND'; return e; };
export function psData(filePath) {
  if (/\/mods\//.test(filePath)) throw missing();
  const r = TABLES[String(filePath).split('/').pop()];
  if (!r) throw missing();
  return r;
}
export function psText(filePath) {
  const p = String(filePath);
  if (!/\/text\/[a-z]+$/.test(p)) throw missing(); // other languages aren't bundled
  const r = TEXT[p.split('/').pop()];
  if (!r) throw missing();
  return r;
}
export const psAliases = AliasModule;
// the only format: a wild battle, with hurt creatures starting hurt
export const Formats = [
  {
    name: '[Gen 9] Capsule Wild', mod: 'gen9', searchShow: false,
    ruleset: ['Max Team Size = 24', 'Max Move Count = 24', 'Max Level = 9999', 'Default Level = 100'],
    onBegin() {
      for (const side of this.sides) {
        for (const p of side.pokemon) {
          const s = p.set;
          if (Number.isFinite(s.hpLeft)) p.hp = Math.max(1, Math.min(p.maxhp, Math.round(s.hpLeft)));
          if (Array.isArray(s.ppLeft)) {
            p.moveSlots.forEach((m, i) => { if (Number.isFinite(s.ppLeft[i])) m.pp = Math.max(0, Math.min(m.maxpp, s.ppLeft[i])); });
            p.baseMoveSlots.forEach((m, i) => { if (Number.isFinite(s.ppLeft[i])) m.pp = Math.max(0, Math.min(m.maxpp, s.ppLeft[i])); });
          }
        }
      }
    },
  },
  { name: '[Gen 9] Custom Game', mod: 'gen9', searchShow: false, ruleset: ['Max Team Size = 24', 'Max Move Count = 24', 'Max Level = 9999', 'Default Level = 100'] },
];
