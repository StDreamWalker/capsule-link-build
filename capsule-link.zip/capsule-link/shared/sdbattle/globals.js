// What the battle screen expects to find loaded from Showdown's data files, filled in from the simulator's
// own data instead (so both always agree).
import { Dex as SimDex } from '../../vendor/showdown/sim/dex';

const g = globalThis;
const d = SimDex.data;
g.BattlePokedex = d.Pokedex;
g.BattleMovedex = d.Moves;
g.BattleItems = d.Items;
g.BattleAbilities = d.Abilities;
g.BattleTypeChart = d.TypeChart;
g.BattleAliases = d.Aliases ?? {};
g.BattleFormatsData = d.FormatsData;
const text = JSON.parse(JSON.stringify(SimDex.loadTextData('en'), (k, v) => (k === 'desc' || k === 'shortDesc' ? undefined : v)));
// a wild one "appears", rather than being sent out by a trainer called Wild
if (text.Default?.default) {
  text.Default.default.switchIn = 'A wild {FULLNAME} appeared!';
  text.Default.default.startBattle = '{TRAINER1} set off into the wild!';
  text.Default.default.opposingPokemon = 'the wild {NICKNAME}';
  text.Default.default.opposingTeam = 'the wild one';
}
g.BattleText = { en: text };
