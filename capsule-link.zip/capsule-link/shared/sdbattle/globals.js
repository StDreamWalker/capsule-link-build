// What the battle screen expects to find loaded from Showdown's data files, filled in from the simulator's
// own data instead (so both always agree).
import { Dex as SimDex } from '../../vendor/showdown/sim/dex';

const g = globalThis;
const d = SimDex.data;
// The battle screen caches what it looks up by writing its own simplified objects back into these tables
// (BattleMovedex[id] = its Move…). Sharing the simulator's tables let that overwrite the simulator's data —
// moves lost their effects (Dive's "can't be hit underwater", and anything else with code) whenever the
// screen happened to look a move up first. So the screen gets its own copies.
const copy = (t) => Object.fromEntries(Object.entries(t ?? {}).map(([k, v]) => [k, v && typeof v === 'object' ? { ...v } : v]));
g.BattlePokedex = copy(d.Pokedex);
g.BattleMovedex = copy(d.Moves);
g.BattleItems = copy(d.Items);
g.BattleAbilities = copy(d.Abilities);
g.BattleTypeChart = copy(d.TypeChart);
g.BattleAliases = d.Aliases ?? {};
g.BattleFormatsData = copy(d.FormatsData);
const text = JSON.parse(JSON.stringify(SimDex.loadTextData('en'), (k, v) => (k === 'desc' || k === 'shortDesc' ? undefined : v)));
// a wild one "appears", rather than being sent out by a trainer called Wild
if (text.Default?.default) {
  text.Default.default.switchIn = 'A wild {FULLNAME} appeared!';
  text.Default.default.startBattle = '{TRAINER1} set off into the wild!';
  text.Default.default.opposingPokemon = 'the wild {NICKNAME}';
  text.Default.default.opposingTeam = 'the wild one';
}
g.BattleText = { en: text };
