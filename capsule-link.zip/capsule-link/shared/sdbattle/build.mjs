// Builds the wild-battle bundle: Pokémon Showdown's simulator (MIT) and its battle screen (the client's
// battle-*.ts files, MIT), with jQuery (MIT), all running inside the app. The vendored sources are left as
// they are; the few spots that load files from disk at run time are swapped for bundled data here.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const V = path.join(here, '..', '..', 'vendor', 'showdown');
const S = (f) => path.join(here, 'shims', f);

const plugin = {
  name: 'capsule-showdown',
  setup(b) {
    b.onResolve({ filter: /^(node:util|node:crypto|ts-chacha20)$/ }, () => ({ path: S('node.js') }));
    b.onResolve({ filter: /^fs$/ }, () => ({ path: S('fs.js') }));
    b.onResolve({ filter: /^path$/ }, () => ({ path: S('path.js') }));
    b.onResolve({ filter: /^\.\.\/lib$/ }, () => ({ path: S('lib.js') }));
    b.onResolve({ filter: /\/client-main$/ }, () => ({ path: S('client-main.ts') }));
    b.onResolve({ filter: /\/client-connection$/ }, () => ({ path: S('client-connection.ts') }));
    const psdata = JSON.stringify(path.join(here, 'psdata.js'));
    b.onLoad({ filter: /vendor[\\/]showdown[\\/]sim[\\/](dex|dex-formats|dex-text|teams)\.ts$/ }, (a) => {
      let s = fs.readFileSync(a.path, 'utf8');
      const swap = (from, to) => { if (from instanceof RegExp ? !from.test(s) : !s.includes(from)) throw new Error(`showdown bundle: ${path.basename(a.path)} changed (${from})`); s = s.replace(from, to); };
      if (a.path.endsWith('dex.ts')) {
        swap('const dataObject = require(filePath);', 'const dataObject = __ps.psData(filePath);');
        swap("const exported = require(path.resolve(DATA_DIR, 'aliases'));", 'const exported = __ps.psAliases;');
      } else if (a.path.endsWith('dex-formats.ts')) {
        swap(/customFormats = require\(`\$\{__dirname\}\/\.\.\/config\/custom-formats`\)\.Formats;/, "customFormats = (() => { const e: any = new Error('none'); e.code = 'MODULE_NOT_FOUND'; throw e; })();");
        swap(/let Formats: AnyObject\[\] = require\(`\$\{__dirname\}\/\.\.\/config\/formats`\)\.Formats;/, 'let Formats: AnyObject[] = __ps.Formats;');
      } else if (a.path.endsWith('dex-text.ts')) {
        swap('require.resolve(filePath);', '__ps.psText(filePath);');
        swap('return require(filePath)[exportName];', 'return __ps.psText(filePath)[exportName];');
      } else {
        s = s.replace(/require\(`[^`]*random[^`]*`\)\.default/g, "(() => { throw new Error('Random teams are not bundled.'); })()");
      }
      return { contents: `import * as __ps from ${psdata};\n${s}`, loader: 'ts' };
    });
    b.onLoad({ filter: /vendor[\\/]showdown[\\/]sim[\\/]battle-stream\.ts$/ }, (a) => ({ contents: fs.readFileSync(a.path, 'utf8').replace('let result = eval(message);', 'let result = (0, eval)(message);'), loader: 'ts' }));
    // the move animations borrow other animations by reference when they load, before those exist in a
    // bundle (Showdown loads the two as separate scripts): look them up when the animation plays instead
    b.onLoad({ filter: /vendor[\\/]showdown[\\/]client[\\/]battle-animations-moves\.ts$/ }, (a) => ({
      contents: fs.readFileSync(a.path, 'utf8').replace(/: BattleOtherAnims\.([a-zA-Z]+)\.anim\b/g, ': ((...args: any[]) => (BattleOtherAnims as any).$1.anim(...args)) as any'), loader: 'ts',
    }));
    // the battle screen keeps its effect pictures in a private table: let the app point them at its own copies
    b.onLoad({ filter: /vendor[\\/]showdown[\\/]client[\\/]battle-animations\.ts$/ }, (a) => {
      const s = fs.readFileSync(a.path, 'utf8').replace('const BattleEffects: { [k: string]: SpriteData } = {', 'export const BattleEffects: { [k: string]: SpriteData } = {').replace('const BattleBackdrops = [', 'export const BattleBackdrops = [');
      return { contents: s, loader: 'ts' };
    });
  },
};

/** Build to `outfile` (an IIFE that sets window.CapsuleShowdown). */
export async function buildShowdownBattle(esbuild, outfile, { minify = true } = {}) {
  await esbuild.build({
    entryPoints: [path.join(here, 'wild.js')], bundle: true, format: 'iife', platform: 'browser', target: 'chrome110', outfile,
    plugins: [plugin], define: { __dirname: '"/showdown"', global: 'globalThis' }, minify, legalComments: 'none', charset: 'ascii', logLevel: 'warning',
  });
  return fs.statSync(outfile).size;
}
/** Just the simulator, as an ES module (tests run wild battles with it in Node). */
export async function buildShowdownSim(esbuild, outfile) {
  await esbuild.build({ entryPoints: [path.join(here, 'sim-entry.js')], bundle: true, format: 'esm', platform: 'neutral', outfile, plugins: [plugin], define: { __dirname: '"/showdown"', global: 'globalThis' }, logLevel: 'error', mainFields: ['module', 'main'] });
}
/** Showdown's battle styles (GPLv2, kept as their own file), scoped under .cl-sd so they don't touch the rest of the app. */
export function showdownCss() {
  const raw = ['css/battle.css', 'css/battle-log.css', 'css/sim-types.css'].map((f) => fs.readFileSync(path.join(V, f), 'utf8')).join('\n')
    .replace(/@import[^;]+;/g, '');
  const head = '/* Pokémon Showdown battle styles (play.pokemonshowdown.com/style). License: GPLv2 <http://www.gnu.org/licenses/gpl-2.0.html>. Scoped under .cl-sd for Capsule Link. */\n';
  return head + scope(raw.replace(/\/\*[\s\S]*?\*\//g, ''), '.cl-sd') + '\n' + fs.readFileSync(path.join(here, 'controls.css'), 'utf8');
}
function scope(css, pre) {
  let out = '', i = 0;
  while (i < css.length) {
    const open = css.indexOf('{', i);
    if (open < 0) { out += css.slice(i); break; }
    const sel = css.slice(i, open).trim();
    if (sel.startsWith('@media') || sel.startsWith('@supports')) {
      let depth = 1, j = open + 1;
      while (j < css.length && depth) { if (css[j] === '{') depth++; else if (css[j] === '}') depth--; j++; }
      out += `${sel} {${scope(css.slice(open + 1, j - 1), pre)}}\n`; i = j; continue;
    }
    const close = css.indexOf('}', open);
    const body = css.slice(open + 1, close);
    if (sel.startsWith('@')) out += `${sel} {${body}}\n`;
    else out += `${sel.split(',').map((x) => { x = x.trim(); return /^(html|body|:root)\b/.test(x) ? pre : `${pre} ${x}`; }).join(', ')} {${body}}\n`;
    i = close + 1;
  }
  return out;
}
