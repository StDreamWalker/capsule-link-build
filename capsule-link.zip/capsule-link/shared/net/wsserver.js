// Dependency-free WebSocket server (RFC 6455) for Node. Text/JSON messages only.
import http from 'node:http';
import crypto from 'node:crypto';

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_PAYLOAD = 8 * 1024 * 1024;

function frame(opcode, payload) {
  const len = payload.length;
  let head;
  if (len < 126) head = Buffer.from([0x80 | opcode, len]);
  else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | opcode; head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x80 | opcode; head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([head, payload]);
}

class Connection {
  constructor(socket, req, id) {
    this.socket = socket;
    this.req = req;
    this.id = id;
    this.remote = req.socket.remoteAddress;
    this.buf = Buffer.alloc(0);
    this.fragments = [];
    this.fragOpcode = 0;
    this.open = true;
    this.handlers = { message: [], close: [] };
    this.alive = true;
    socket.on('data', (d) => this.onData(d));
    socket.on('close', () => this.finish());
    socket.on('error', () => this.finish());
  }
  on(evt, fn) { this.handlers[evt].push(fn); }
  emit(evt, ...a) { for (const fn of this.handlers[evt]) { try { fn(...a); } catch (e) { console.error('[ws]', e); } } }
  send(obj) {
    if (!this.open) return;
    const text = typeof obj === 'string' ? obj : JSON.stringify(obj);
    this.socket.write(frame(0x1, Buffer.from(text, 'utf8')));
  }
  close(code = 1000, reason = '') {
    if (!this.open) return;
    const p = Buffer.alloc(2 + Buffer.byteLength(reason));
    p.writeUInt16BE(code, 0); p.write(reason, 2);
    try { this.socket.write(frame(0x8, p)); } catch { /* ignore */ }
    this.socket.end();
    this.finish();
  }
  finish() {
    if (!this.open) return;
    this.open = false;
    this.emit('close');
  }
  onData(chunk) {
    this.buf = Buffer.concat([this.buf, chunk]);
    for (;;) {
      if (this.buf.length < 2) return;
      const b0 = this.buf[0], b1 = this.buf[1];
      const fin = !!(b0 & 0x80), opcode = b0 & 0x0f, masked = !!(b1 & 0x80);
      let len = b1 & 0x7f, off = 2;
      if (len === 126) { if (this.buf.length < 4) return; len = this.buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (this.buf.length < 10) return; len = Number(this.buf.readBigUInt64BE(2)); off = 10; }
      if (len > MAX_PAYLOAD) { this.close(1009, 'Message too big'); return; }
      const maskOff = off;
      if (masked) off += 4;
      if (this.buf.length < off + len) return;
      let payload = this.buf.subarray(off, off + len);
      if (masked) {
        const mask = this.buf.subarray(maskOff, maskOff + 4);
        payload = Buffer.from(payload);
        for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      }
      this.buf = this.buf.subarray(off + len);
      this.handleFrame(fin, opcode, payload);
      if (!this.open) return;
    }
  }
  handleFrame(fin, opcode, payload) {
    if (opcode === 0x8) { this.close(); return; }
    if (opcode === 0x9) { this.socket.write(frame(0xa, payload)); return; }
    if (opcode === 0xa) { this.alive = true; return; }
    if (opcode === 0x1 || opcode === 0x2) {
      if (fin) return this.deliver(payload);
      this.fragOpcode = opcode; this.fragments = [payload]; return;
    }
    if (opcode === 0x0) {
      this.fragments.push(payload);
      if (fin) { const all = Buffer.concat(this.fragments); this.fragments = []; this.deliver(all); }
    }
  }
  deliver(payload) {
    const text = payload.toString('utf8');
    if (this.raw) { this.emit('message', text); return; }
    let msg;
    try { msg = JSON.parse(text); } catch { this.send({ type: 'error', message: 'Messages must be JSON.' }); return; }
    this.emit('message', msg);
  }
  ping() {
    if (!this.alive) { this.close(1001, 'No response'); return; }
    this.alive = false;
    try { this.socket.write(frame(0x9, Buffer.alloc(0))); } catch { /* ignore */ }
  }
}

/**
 * createWsServer({ port, host, onConnection(conn), onHttp(req, res) }) -> { close(), address(), connections }
 */
export function createWsServer({ port, host = '0.0.0.0', onConnection, onHttp, raw = false }) {
  const connections = new Set();
  let nextId = 1;
  const server = http.createServer((req, res) => {
    if (onHttp && onHttp(req, res) !== false) return;
    res.writeHead(426, { 'Content-Type': 'text/plain' });
    res.end('This port speaks WebSocket.');
  });
  server.on('upgrade', (req, socket) => {
    const key = req.headers['sec-websocket-key'];
    if (!key || (req.headers.upgrade || '').toLowerCase() !== 'websocket') { socket.destroy(); return; }
    const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
    socket.write([
      'HTTP/1.1 101 Switching Protocols',
      'Upgrade: websocket',
      'Connection: Upgrade',
      `Sec-WebSocket-Accept: ${accept}`,
      '', '',
    ].join('\r\n'));
    socket.setNoDelay(true);
    const conn = new Connection(socket, req, `c${nextId++}`);
    conn.raw = raw;
    connections.add(conn);
    conn.on('close', () => connections.delete(conn));
    onConnection(conn);
  });
  const heartbeat = setInterval(() => { for (const c of connections) c.ping(); }, 20000);
  heartbeat.unref?.();
  const ready = new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, host, () => resolve());
  });
  return {
    ready,
    connections,
    address: () => server.address(),
    close: () => new Promise((resolve) => {
      clearInterval(heartbeat);
      for (const c of connections) c.close(1001, 'Server closing');
      server.close(() => resolve());
    }),
  };
}
