// WebSocket client for the PC hub or a battle relay (browser / WebView).
import { MSG, PROTOCOL_VERSION } from '../engine/protocol.js';

export class HubClient {
  constructor(opts = {}) {
    this.opts = opts;
    this.ws = null;
    this.status = 'idle';
    this.handlers = new Map();
    this.welcome = null;
    this.reconnect = opts.reconnect ?? false;
    this.retry = 0;
  }

  on(type, fn) {
    if (!this.handlers.has(type)) this.handlers.set(type, new Set());
    this.handlers.get(type).add(fn);
    return () => this.handlers.get(type)?.delete(fn);
  }
  emit(type, msg) {
    for (const fn of this.handlers.get(type) ?? []) { try { fn(msg); } catch (e) { console.error(e); } }
    for (const fn of this.handlers.get('*') ?? []) { try { fn(msg); } catch (e) { console.error(e); } }
  }
  setStatus(s, detail) { this.status = s; this.emit('status', { type: 'status', status: s, detail }); }

  /** Connect and say hello. Resolves with the welcome message, rejects with the hub's error. */
  connect(overrides = {}) {
    Object.assign(this.opts, overrides);
    this.close(true);
    return new Promise((resolve, reject) => {
      let settled = false;
      const url = this.opts.url;
      let ws;
      try { ws = new WebSocket(url); } catch (e) { reject(new Error(`Cannot open ${url}: ${e.message}`)); return; }
      this.ws = ws;
      this.setStatus('connecting');
      const timer = setTimeout(() => { if (!settled) { settled = true; ws.close(); reject(new Error(`No answer from ${url}. Check the address and that both devices are on the same network.`)); } }, this.opts.timeout ?? 6000);
      ws.onopen = () => {
        ws.send(JSON.stringify({
          type: MSG.HELLO, v: PROTOCOL_VERSION,
          deviceId: this.opts.deviceId, name: this.opts.name, kind: this.opts.kind ?? 'phone',
          token: this.opts.token, pairCode: this.opts.pairCode, localToken: this.opts.localToken,
        }));
      };
      ws.onmessage = (ev) => {
        let msg;
        try { msg = JSON.parse(ev.data); } catch { return; }
        if (!settled && msg.type === MSG.WELCOME) {
          settled = true; clearTimeout(timer);
          this.welcome = msg; this.retry = 0;
          if (msg.token) this.opts.token = msg.token;
          this.setStatus('open');
          resolve(msg);
        } else if (!settled && msg.type === MSG.ERROR) {
          settled = true; clearTimeout(timer);
          const err = new Error(msg.message); err.code = msg.code;
          reject(err);
          ws.close();
          return;
        }
        this.emit(msg.type, msg);
      };
      ws.onerror = () => {};
      ws.onclose = () => {
        clearTimeout(timer);
        if (!settled) { settled = true; reject(new Error(`Could not reach ${url}.`)); }
        if (this.ws === ws) {
          this.setStatus('closed');
          if (this.reconnect && !this.closing) {
            const delay = Math.min(30000, 1000 * 2 ** this.retry++);
            setTimeout(() => { if (this.status === 'closed' && !this.closing) this.connect().catch(() => {}); }, delay);
          }
        }
      };
    });
  }

  send(type, data = {}) {
    if (this.ws?.readyState !== 1) throw new Error('Not connected.');
    this.ws.send(JSON.stringify({ type, ...data }));
  }

  /** Send and wait for the next message of `replyType` (or an error). */
  request(type, data, replyType, ms = 8000) {
    return new Promise((resolve, reject) => {
      const offs = [];
      const done = (fn, v) => { offs.forEach((o) => o()); clearTimeout(t); fn(v); };
      const t = setTimeout(() => done(reject, new Error('The hub did not answer in time.')), ms);
      offs.push(this.on(replyType, (m) => done(resolve, m)));
      offs.push(this.on(MSG.ERROR, (m) => done(reject, Object.assign(new Error(m.message), { code: m.code }))));
      try { this.send(type, data); } catch (e) { done(reject, e); }
    });
  }

  close(silent) {
    this.closing = true;
    try { this.ws?.close(); } catch { /* ignore */ }
    this.ws = null;
    this.closing = false;
    if (!silent) this.setStatus('closed');
  }
}
