// Client for the Capsule Link home server (server/home-server.mjs): accounts, friends, messages, gifts,
// trades, yard snapshots and shared creature data. Works from the PC app (and later the phone).
// Nothing here runs unless you sign in to a server; everything else in the app works without one.

export class FriendsClient {
  /** base: 'http://192.168.1.20:47830'; token: from an earlier sign-in (optional). */
  constructor(base, token = null) {
    this.base = String(base ?? '').trim().replace(/\/+$/, '');
    if (this.base && !/^https?:\/\//i.test(this.base)) this.base = `http://${this.base}`;
    this.token = token;
    this.ws = null;
  }
  async call(method, path, body, { raw = false, timeout = 15000 } = {}) {
    if (!this.base) throw new Error('Set the server address first.');
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), timeout);
    try {
      const headers = {};
      if (this.token) headers.Authorization = `Bearer ${this.token}`;
      if (body != null && !raw) headers['Content-Type'] = 'application/json';
      const r = await fetch(`${this.base}${path}`, { method, headers, body: body == null ? undefined : raw ? body : JSON.stringify(body), signal: ctl.signal });
      const type = r.headers.get('content-type') ?? '';
      const data = type.includes('json') ? await r.json() : new Uint8Array(await r.arrayBuffer());
      if (!r.ok) throw Object.assign(new Error(data?.error ?? `The server said ${r.status}.`), { status: r.status });
      return data;
    } catch (e) {
      if (e.name === 'AbortError') throw new Error('The server didn’t answer. Is it running, and is the address right?');
      if (e instanceof TypeError) throw new Error('Couldn’t reach the server. Check the address and that it’s running.');
      throw e;
    } finally { clearTimeout(timer); }
  }
  info() { return this.call('GET', '/api/info'); }
  async signup(username, password, trainerName) { const r = await this.call('POST', '/api/signup', { username, password, trainerName }); this.token = r.token; return r; }
  async login(username, password) { const r = await this.call('POST', '/api/login', { username, password }); this.token = r.token; return r; }
  async logout() { try { await this.call('POST', '/api/logout', {}); } finally { this.token = null; this.ws?.close?.(); } }
  me() { return this.call('GET', '/api/me'); }
  friends() { return this.call('GET', '/api/friends'); }
  request(username) { return this.call('POST', '/api/friends/request', { username }); }
  accept(username) { return this.call('POST', '/api/friends/accept', { username }); }
  remove(username) { return this.call('POST', '/api/friends/remove', { username }); }
  messages(withUser) { return this.call('GET', `/api/messages?with=${encodeURIComponent(withUser)}`); }
  say(to, text) { return this.call('POST', '/api/messages', { to, text }); }
  inbox() { return this.call('GET', '/api/inbox'); }
  gift(to, { items = {}, coins = 0, creature = null, note = '' } = {}) { return this.call('POST', '/api/gifts', { to, items, coins, creature, note }); }
  claimGift(id) { return this.call('POST', '/api/gifts/claim', { id }); }
  offerTrade(to, give, wantNote = '') { return this.call('POST', '/api/trades', { to, give, want: { note: wantNote } }); }
  respondTrade(id, accept, give = {}) { return this.call('POST', '/api/trades/respond', { id, accept, give }); }
  claimTrade(id) { return this.call('POST', '/api/trades/claim', { id }); }
  shareRanch(snapshot) { return this.call('PUT', '/api/ranch', snapshot); }
  visitRanch(username) { return this.call('GET', `/api/ranch/${encodeURIComponent(username)}`); }
  speciesAvailable(ids) { return this.call('POST', '/api/species/missing', { ids }); }
  getSpecies(id) { return this.call('GET', `/api/species/${encodeURIComponent(id)}`); }
  putSpecies(id, record, sprites) { return this.call('PUT', `/api/species/${encodeURIComponent(id)}`, { record, sprites }); }
  getBlob(hash) { return this.call('GET', `/api/blob/${hash}`); }
  putBlob(hash, bytes) { return this.call('PUT', `/api/blob/${hash}`, bytes, { raw: true }); }
  battles() { return this.call('GET', '/api/battles'); }
  inviteBattle(to, showdown, format) { return this.call('POST', '/api/battles', { to, showdown, format }); }
  respondBattle(id, accept, showdown) { return this.call('POST', '/api/battles/respond', { id, accept, showdown }); }
  cancelBattle(id) { return this.call('POST', '/api/battles/cancel', { id }); }

  /** Live notifications (a friend request, a message, a gift…): onNotify({ what, from }). */
  listen(onNotify) {
    if (!this.base || !this.token || typeof WebSocket === 'undefined') return;
    this.onNotify = onNotify;
    try { this.ws?.close(); } catch { /* ignore */ }
    const url = `${this.base.replace(/^http/i, 'ws')}/live`;
    const ws = new WebSocket(url);
    this.ws = ws;
    ws.onopen = () => ws.send(JSON.stringify({ type: 'auth', token: this.token }));
    ws.onmessage = (e) => { try { const m = JSON.parse(e.data); if (m.type === 'notify') onNotify?.(m); } catch { /* ignore */ } };
    ws.onclose = () => { if (this.ws === ws && this.token) setTimeout(() => { if (this.ws === ws) this.listen(onNotify); }, 15000); };
  }
}

/** SHA-256 of some bytes, as hex (browser or Node). */
export async function sha256Hex(bytes) {
  const buf = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Bring in creature data you don't have yet (from a friend's yard or a trade): the species record and its
 * sprites. Sprites you already have are never downloaded again.
 *   haveSpecies(id) → bool, haveSprite(path) → bool, addSpecies(record), saveSprite(path, bytes)
 * Returns { added: [ids], sprites: n, unavailable: [ids] }.
 */
export async function fetchMissingSpecies(client, ids, { haveSpecies, haveSprite, addSpecies, saveSprite }) {
  const want = [...new Set(ids)].filter((id) => !haveSpecies(id));
  const out = { added: [], sprites: 0, unavailable: [] };
  if (!want.length) return out;
  const { available } = await client.speciesAvailable(want);
  out.unavailable = want.filter((id) => !available.includes(id));
  for (const id of available) {
    const s = await client.getSpecies(id);
    await addSpecies(s.record);
    out.added.push(id);
    for (const [anim, hash] of Object.entries(s.sprites ?? {})) {
      const path = anim === 'idle' ? `creatures/${id}.png` : `creatures/${id}-${anim}.png`;
      if (haveSprite(path)) continue;
      const bytes = await client.getBlob(hash);
      await saveSprite(path, bytes);
      out.sprites++;
    }
  }
  return out;
}

/** Share your own data for some species so friends can fetch it. getSprite(path) → bytes | null. */
export async function shareSpecies(client, records, getSprite) {
  let n = 0;
  for (const rec of records) {
    const sprites = {};
    for (const anim of ['idle', 'back', 'icon', 'shiny']) {
      const bytes = await getSprite(anim === 'idle' ? `creatures/${rec.id}.png` : `creatures/${rec.id}-${anim}.png`);
      if (!bytes) continue;
      const hash = await sha256Hex(bytes);
      sprites[anim] = hash;
      await client.putBlob(hash, bytes).catch(() => {});
    }
    await client.putSpecies(rec.id, rec, sprites);
    n++;
  }
  return n;
}
