// Hub logic shared by the PC app (home hub: sync + battles) and the stand-alone relay
// (battles only). Transport-agnostic: give it connections with send()/on()/close().
import { parseTagImage } from '../engine/capsule.js';
import { MSG, PROTOCOL_VERSION, BUMP_WINDOW_MS } from '../engine/protocol.js';
import { toId, SHOWDOWN_DEFAULTS } from '../engine/showdown.js';
import { applyEvent, firstFreeBoxSlot, party, list } from '../engine/save.js';
import { randomId } from '../engine/rng.js';
import { makeVirtualTag } from '../engine/capsuleSync.js';
import { fromHex, toHex } from '../engine/ndef.js';

export class Hub {
  /**
   * opts.mode: 'home' | 'relay'
   * home mode needs: getIdx(), getSave(), onSaveChanged(reason), pairCode (string), localToken
   */
  constructor(opts = {}) {
    this.mode = opts.mode ?? 'home';
    this.name = opts.name ?? 'Capsule Link hub';
    this.getIdx = opts.getIdx ?? (() => null);
    this.getSave = opts.getSave ?? (() => null);
    this.getTextures = opts.getTextures ?? null;
    this.getPhoneUpdate = opts.getPhoneUpdate ?? null; // a newer phone web bundle from an installed update file
    // phone backups kept on the PC: { put(deviceName, backup) -> file, list() -> [{ file, at, summary }], get(file) -> text }
    this.backups = opts.backups ?? null;
    this.phoneApps = new Map(); // what each phone said about its app version on its last sync
    // what is on the PC's dock right now (shown on phones): () => { name, speciesId, level, capsule } | null
    this.getDock = opts.getDock ?? null;
    this.getCries = opts.getCries ?? null; // () => { hash, files: { 'cries/x.mp3': dataUrl } }
    this.onSaveChanged = opts.onSaveChanged ?? (() => {});
    this.pairCode = opts.pairCode ?? String(Math.floor(100000 + Math.random() * 900000));
    this.localToken = opts.localToken ?? randomId(12);
    this.log = opts.log ?? (() => {});
    this.now = opts.now ?? (() => Date.now());
    this.clients = new Map();
    this.waitingCodes = new Map(); // code -> client
    this.bumpers = new Set(); // clients armed for a bump battle
    this.simCapsules = new Map(); // uid -> phone client holding a simulated capsule on the dock
    this.capRequests = new Map(); // relayed request id -> PC client waiting for the reply
  }

  attach(conn) {
    const client = { id: conn.id, conn, authed: false, device: null, name: 'Guest', kind: 'phone', find: null };
    this.clients.set(conn.id, client);
    conn.on('message', (msg) => this.onMessage(client, msg));
    conn.on('close', () => this.onClose(client));
    return client;
  }

  send(client, type, data = {}) { client.conn.send({ type, ...data }); }
  error(client, message, code) { this.send(client, MSG.ERROR, { message, code }); }

  status() {
    return {
      mode: this.mode,
      pairCode: this.pairCode,
      clients: [...this.clients.values()].filter((c) => c.authed).map((c) => ({ id: c.id, name: c.name, kind: c.kind, device: c.device, waiting: !!c.find })),
    };
  }

  /** The PC switched to another trainer: phones paired with the old one reconnect and must pair again. */
  dropPhones() {
    for (const c of [...this.clients.values()]) if (c.authed && c.kind !== 'pc') { try { c.conn.close(4001, 'Another trainer logged on'); } catch { /* gone */ } }
  }

  broadcastChanged(reason, except) {
    for (const c of this.clients.values()) if (c.authed && c !== except) this.send(c, MSG.CHANGED, { reason });
  }

  onMessage(client, msg) {
    try {
      if (msg.type === MSG.PING) return this.send(client, MSG.PONG, { t: msg.t });
      if (msg.type === MSG.HELLO) return this.onHello(client, msg);
      if (!client.authed) return this.error(client, 'Say hello first.', 'auth');
      switch (msg.type) {
        case MSG.PULL: return this.sendState(client, msg);
        case MSG.PUSH: return this.onPush(client, msg);
        case MSG.TAKE: return this.onTake(client, msg);
        case MSG.RETURN: return this.onReturn(client, msg);
        case MSG.FIND: return this.onFind(client, msg);
        case MSG.BUMP: return this.onBump(client, msg);
        case MSG.CANCEL: return this.cancelFind(client, true);
        case MSG.CAP_ATTACH: return this.onCapAttach(client, msg);
        case MSG.CAP_DETACH: return this.onCapDetach(client, msg);
        case MSG.CAP_READ: case MSG.CAP_WRITE: return this.onCapRequest(client, msg);
        case MSG.CAP_REPLY: return this.onCapReply(client, msg);
        case MSG.BACKUP_PUT: case MSG.BACKUP_LIST: case MSG.BACKUP_GET: return this.onBackup(client, msg);
        case MSG.VTAG_LIST: case MSG.VTAG_READ: case MSG.VTAG_WRITE: case MSG.VTAG_TAKE: case MSG.VTAG_GIVE: return this.onVirtualTag(client, msg);
        case MSG.DOCK_GET: return this.send(client, MSG.DOCK, { rid: msg.rid ?? null, dock: this.getDock?.() ?? null });
        default: return this.error(client, `Unknown message ${msg.type}`);
      }
    } catch (e) {
      this.log('hub error', e);
      this.error(client, e.message || String(e));
    }
  }

  onHello(client, msg) {
    client.name = String(msg.name ?? 'Guest').slice(0, 24);
    client.kind = msg.kind ?? 'phone';
    client.device = msg.deviceId ?? client.id;
    if (msg.v && msg.v > PROTOCOL_VERSION) this.log('client is newer than hub', msg.v);
    let token = null;
    if (this.mode === 'relay') client.authed = true;
    else if (msg.localToken && msg.localToken === this.localToken) client.authed = true;
    else {
      const save = this.getSave();
      const dev = save?.devices?.[client.device];
      if (dev && msg.token && dev.token === msg.token) { client.authed = true; token = dev.token; }
      else if (msg.pairCode && String(msg.pairCode).trim() === this.pairCode) {
        token = randomId(16);
        save.devices[client.device] = { name: client.name, token, pairedAt: this.now() };
        client.authed = true;
        this.onSaveChanged('paired');
      }
    }
    if (!client.authed) return this.error(client, 'Enter the pairing code shown on the PC (Phone link screen).', 'pair');
    if (this.mode === 'home') {
      const save = this.getSave();
      if (save.devices[client.device]) { save.devices[client.device].lastSeen = this.now(); save.devices[client.device].name = client.name; }
    }
    const idx = this.getIdx();
    this.send(client, MSG.WELCOME, {
      token, mode: this.mode, hubName: this.name, v: PROTOCOL_VERSION,
      trainer: this.mode === 'home' ? this.getSave().trainer : null,
      datasetHash: idx?.syncHash ?? null,
    });
    this.broadcastChanged('clients', client);
    if (client.kind === 'pc') {
      for (const [uid, phone] of this.simCapsules) this.send(client, MSG.CAP_ATTACHED, { uid, name: phone.name });
    }
  }

  // ---------- the PC's virtual capsules, tapped from a phone ----------
  async onVirtualTag(client, msg) {
    const reply = (data) => this.send(client, MSG.VTAG, { rid: msg.rid ?? null, ...data });
    if (this.mode !== 'home') return reply({ ok: false, error: 'Only a home PC has virtual capsules.' });
    const save = this.getSave();
    const tags = save.virtualTags || (save.virtualTags = {});
    try {
      if (msg.type === MSG.VTAG_LIST) return reply({ ok: true, list: Object.keys(tags).map((uid) => ({ uid, name: save.capsules?.[uid]?.name ?? 'Virtual capsule', docked: this.getDock?.()?.uid === uid, creature: (() => { try { const m = parseTagImage(fromHex(tags[uid])).main; if (!m?.ok || m.empty) return null; const c = save.creatures[m.rec.uid]; return c?.nickname || c?.speciesId || m.rec.nickname || `#${m.rec.speciesNo}`; } catch { return null; } })() })) });
      const uid = String(msg.uid ?? '');
      if (msg.type === MSG.VTAG_GIVE) {
        // the phone hands an emulated ball back: it is the PC's again
        tags[uid] = String(msg.hex ?? '');
        if (msg.capsule) save.capsules[uid] = { ...(save.capsules[uid] ?? {}), ...msg.capsule, holder: 'pc', heldAt: this.now() };
        save.capsules[uid] = save.capsules[uid] ?? { name: `Capsule ${uid.slice(-4)}`, holder: 'pc', heldAt: this.now() };
        if (msg.creature?.uid) {
          const had = save.creatures[msg.creature.uid];
          const c = had && (had.updatedAt ?? 0) > (msg.creature.updatedAt ?? 0) ? had : msg.creature;
          c.location = { kind: 'capsule', tag: uid };
          save.creatures[c.uid] = c;
          save.capsules[uid].uid = c.uid;
        } else if (msg.creature === null) save.capsules[uid].uid = null;
        this.onSaveChanged('vtag');
        return reply({ ok: true, uid });
      }
      if (!tags[uid]) throw new Error('That virtual capsule is not on the PC any more.');
      if (msg.type === MSG.VTAG_READ) return reply({ ok: true, uid, hex: tags[uid] });
      if (msg.type === MSG.VTAG_TAKE) {
        // the phone takes the ball off the PC (the PC no longer has it until it is given back)
        if (this.getDock?.()?.uid === uid) throw new Error('That ball is on the PC dock. Take it off the dock first.');
        const hex = tags[uid];
        delete tags[uid];
        this.onSaveChanged('vtag');
        return reply({ ok: true, uid, hex, capsule: save.capsules?.[uid] ?? null });
      }
      const t = makeVirtualTag(uid, fromHex(tags[uid]));
      await t.writePages(Number(msg.page), fromHex(String(msg.hex ?? '')));
      tags[uid] = toHex(t.mem);
      this.onSaveChanged('vtag');
      return reply({ ok: true, uid });
    } catch (e) { return reply({ ok: false, error: e.message }); }
  }

  // ---------- phone backups ----------
  onBackup(client, msg) {
    const reply = (data) => this.send(client, MSG.BACKUP, { rid: msg.rid ?? null, ...data });
    if (!this.backups || this.mode !== 'home') return reply({ ok: false, error: 'This hub does not keep backups.' });
    try {
      if (msg.type === MSG.BACKUP_PUT) return reply({ ok: true, file: this.backups.put(client.name, msg.backup) });
      if (msg.type === MSG.BACKUP_LIST) return reply({ ok: true, list: this.backups.list() });
      return reply({ ok: true, text: this.backups.get(msg.file) });
    } catch (e) { return reply({ ok: false, error: e.message }); }
  }

  // ---------- simulated capsules (a phone pretending to be a capsule on the dock) ----------
  pcClients() { return [...this.clients.values()].filter((c) => c.authed && c.kind === 'pc'); }

  onCapAttach(client, msg) {
    const uid = String(msg.uid ?? '').toUpperCase().replace(/[^0-9A-F]/g, '').slice(0, 14);
    if (uid.length < 8) return this.error(client, 'That capsule id is not valid.');
    for (const [old, owner] of this.simCapsules) if (owner === client && old !== uid) this.onCapDetach(client, { uid: old });
    this.simCapsules.set(uid, client);
    client.simCapsule = uid;
    for (const pc of this.pcClients()) this.send(pc, MSG.CAP_ATTACHED, { uid, name: client.name });
    this.send(client, MSG.CAP_ATTACHED, { uid, pcs: this.pcClients().length });
  }

  onCapDetach(client, msg) {
    const uid = String(msg.uid ?? client.simCapsule ?? '').toUpperCase();
    if (this.simCapsules.get(uid) !== client) return;
    this.simCapsules.delete(uid);
    client.simCapsule = null;
    for (const pc of this.pcClients()) this.send(pc, MSG.CAP_DETACHED, { uid });
  }

  onCapRequest(client, msg) {
    if (client.kind !== 'pc') return this.error(client, 'Only the PC dock can read capsules.');
    const phone = this.simCapsules.get(String(msg.uid ?? '').toUpperCase());
    if (!phone || !this.clients.has(phone.id)) return this.send(client, MSG.CAP_REPLY, { rid: msg.rid, ok: false, error: 'The simulated capsule is not on the dock any more.' });
    const relay = `${client.id}:${msg.rid}`;
    this.capRequests.set(relay, client);
    if (this.capRequests.size > 500) this.capRequests.delete(this.capRequests.keys().next().value);
    const out = { rid: relay };
    if (msg.type === MSG.CAP_WRITE) { out.page = msg.page; out.hex = msg.hex; }
    this.send(phone, msg.type, out);
  }

  onCapReply(client, msg) {
    const pc = this.capRequests.get(msg.rid);
    if (!pc) return;
    this.capRequests.delete(msg.rid);
    const rid = String(msg.rid).split(':').slice(1).join(':');
    this.send(pc, MSG.CAP_REPLY, { rid: Number(rid) || rid, ok: msg.ok !== false, hex: msg.hex, error: msg.error });
  }

  // ---------- sync (home mode) ----------
  pocketFor(client) {
    const save = this.getSave();
    return list(save).filter((c) => (c.location?.kind === 'phone' && c.location.device === client.device) || c.location?.kind === 'capsule');
  }

  sendState(client, msg = {}, extra = {}) {
    if (this.mode !== 'home') return this.error(client, 'This relay only hosts battles.');
    const save = this.getSave();
    const idx = this.getIdx();
    let textures;
    if (this.getTextures && msg.texturesHash !== undefined) {
      const t = this.getTextures();
      if (t.hash !== msg.texturesHash) textures = t;
    }
    // downloaded cries go separately (they only change when cries are added)
    let cries;
    if (this.getCries && msg.criesHash !== undefined) {
      const k = this.getCries();
      if (k.hash !== msg.criesHash) cries = k;
    }
    // a phone running older app code gets the newer code from an installed update file
    // (only when its Android side is the same one the update was made for)
    // Every sync says why an update was or wasn't offered (appStatus), so neither side is left
    // guessing; the phone can ask to update anyway (msg.app.force) when only the fingerprint differs.
    let appUpdate, appStatus = null;
    const pu = this.getPhoneUpdate?.();
    if (msg.app) {
      const a = msg.app;
      if (!pu) appStatus = { state: 'none' };
      else if (!newerVersion(pu.version, a.version)) appStatus = { state: 'current', version: pu.version };
      else if (pu.version === a.declined && !a.force) appStatus = { state: 'declined', version: pu.version };
      else if (pu.phoneNative !== a.phoneNative) {
        // made for a different Android build. The Android side has rarely changed, and a phone stuck
        // on old code can't ask for it anyway, so offer it and say so; "Use the built-in version"
        // (and the start-up screen) undo it if it doesn't start.
        appStatus = { state: 'offered', version: pu.version, mismatch: true, need: pu.phoneNative ?? null, have: a.phoneNative ?? null };
        appUpdate = { ...pu, nativeMismatch: true, files: stampNative(pu.files, a.phoneNative) };
      } else { appStatus = { state: 'offered', version: pu.version }; appUpdate = pu; }
      this.phoneApps.set(client.device ?? client.name, { name: client.name, version: a.version ?? null, phoneNative: a.phoneNative ?? null, status: appStatus.state, at: this.now() });
    }
    const summary = list(save).map((c) => ({
      uid: c.uid, speciesId: c.speciesId, nickname: c.nickname, level: c.level, friendship: c.friendship, location: c.location,
    }));
    this.send(client, MSG.STATE, {
      trainer: save.trainer,
      pocket: this.pocketFor(client),
      party: party(save).map((c) => c.uid),
      all: summary,
      // the phone carries the satchel (what you packed for it at the PC), not the whole bag
      inventory: save.satchel ?? {},
      satchel: true,
      capsules: save.capsules,
      boxes: save.boxes.map((b) => ({ name: b.name, biome: b.biome })),
      stats: save.stats,
      datasetHash: idx.syncHash,
      dataset: msg.datasetHash !== idx.syncHash ? idx.ds : undefined,
      textures,
      cries,
      appUpdate,
      appStatus,
      dock: this.getDock?.() ?? null,
      ...extra,
    });
  }

  onPush(client, msg) {
    if (this.mode !== 'home') return this.error(client, 'This relay only hosts battles.');
    const save = this.getSave();
    const idx = this.getIdx();
    const results = [];
    // creatures the phone knows about but the PC does not (e.g. read from a capsule written elsewhere)
    for (const c of msg.creatures ?? []) {
      if (c && c.uid && !save.creatures[c.uid] && idx.species.has(c.speciesId)) {
        save.creatures[c.uid] = c;
        if (!c.location) c.location = { kind: 'phone', device: client.device };
        results.push({ id: `import-${c.uid}`, ok: true, imported: true });
      }
    }
    for (const ev of msg.events ?? []) {
      const r = applyEvent(idx, save, ev);
      results.push({ id: ev.id, ok: r.ok, duplicate: r.duplicate, error: r.error, outcome: r.outcome });
    }
    this.onSaveChanged('sync');
    this.broadcastChanged('sync', client);
    this.sendState(client, msg, { acked: results.map((r) => r.id), results });
  }

  onTake(client, msg) {
    const save = this.getSave();
    const moved = [];
    for (const uid of msg.uids ?? []) {
      const c = save.creatures[uid];
      if (!c) continue;
      if (c.location?.kind === 'phone' && c.location.device !== client.device) continue;
      c.location = { kind: 'phone', device: client.device, from: c.location?.kind === 'phone' ? c.location.from : c.location };
      moved.push(uid);
    }
    this.onSaveChanged('pocket');
    this.broadcastChanged('pocket', client);
    this.sendState(client, msg, { taken: moved });
  }

  onReturn(client, msg) {
    const save = this.getSave();
    const idx = this.getIdx();
    const returned = [];
    for (const uid of msg.uids ?? []) {
      const sent = (msg.creatures ?? []).find((x) => x?.uid === uid);
      let c = save.creatures[uid];
      // a creature the PC has never seen (caught on a walk and not synced yet): take it in
      if (!c && sent && idx.species.has(sent.speciesId)) { c = save.creatures[uid] = { ...sent, location: { kind: 'phone', device: client.device } }; }
      if (!c) { returned.push({ uid, ok: false, error: 'The PC doesn’t know this creature. Sync first, then try again.' }); continue; }
      // the phone sends its latest copy so nothing done offline is lost
      if (sent && c.location?.kind === 'phone') Object.assign(c, { ...sent, location: c.location });
      if (c.location?.kind === 'capsule') { returned.push({ uid, ok: false, error: 'It’s inside a ball. Put the ball on the PC dock to bring it home.' }); continue; }
      if (c.location?.kind !== 'phone') { returned.push({ uid, ok: true, already: true }); continue; }
      const back = c.location.from;
      const taken = back && list(save).some((x) => x.uid !== uid && x.location?.kind === back.kind && x.location.box === back.box && x.location.slot === back.slot);
      c.location = back && back.kind !== 'phone' && back.kind !== 'capsule' && !taken ? back : firstFreeBoxSlot(save) ?? { kind: 'ranch' };
      returned.push({ uid, ok: true, to: c.location.kind });
    }
    this.onSaveChanged('pocket');
    this.broadcastChanged('pocket', client);
    this.sendState(client, msg, { returned });
  }

  // ---------- battle pairing ----------
  // Battles are played on Pokémon Showdown. The hub only introduces the two players: who they are on
  // Showdown, which capsules they carry, and which one sends the challenge.
  onFind(client, msg) {
    this.cancelFind(client, false);
    const showdown = String(msg.showdown ?? '').trim();
    if (!toId(showdown)) return this.error(client, 'Set your Showdown name first (Battle screen).', 'showdown');
    client.find = {
      mode: msg.mode === 'code' ? 'code' : 'bump',
      code: msg.code ? String(msg.code).trim().toUpperCase().slice(0, 8) : null,
      name: String(msg.name ?? client.name).slice(0, 24),
      showdown: showdown.slice(0, 18),
      capsules: Array.isArray(msg.capsules) ? msg.capsules.map(String).slice(0, 12) : [],
      format: String(msg.format || SHOWDOWN_DEFAULTS.format).slice(0, 60),
      server: String(msg.server || SHOWDOWN_DEFAULTS.server).slice(0, 200),
      at: this.now(), bumpAt: null,
    };
    this.queue(client);
  }

  queue(client) {
    const f = client.find;
    if (f.mode === 'code') {
      if (!f.code) f.code = randomId(2).toUpperCase();
      const other = this.waitingCodes.get(f.code);
      if (other && other !== client && other.find && this.clients.has(other.id)) {
        this.waitingCodes.delete(f.code);
        return this.match(other, client);
      }
      this.waitingCodes.set(f.code, client);
      return this.send(client, MSG.WAITING, { mode: 'code', code: f.code });
    }
    this.bumpers.add(client);
    this.send(client, MSG.WAITING, { mode: 'bump' });
  }

  onBump(client, msg) {
    if (!client.find || client.find.mode !== 'bump') return this.error(client, 'Start a bump battle first.');
    // phones report how long ago the bump happened (a capsule beacon can arrive a moment late)
    const t = this.now() - Math.min(5000, Math.max(0, Number(msg.elapsed) || 0));
    client.find.bumpAt = t;
    let best = null;
    for (const other of this.bumpers) {
      if (other === client || !other.find?.bumpAt) continue;
      const dt = Math.abs(other.find.bumpAt - t);
      if (dt <= BUMP_WINDOW_MS && (!best || dt < best.dt)) best = { other, dt };
    }
    if (best) {
      this.bumpers.delete(best.other);
      this.bumpers.delete(client);
      return this.match(best.other, client);
    }
    setTimeout(() => {
      if (client.find?.bumpAt === t && this.bumpers.has(client)) {
        client.find.bumpAt = null;
        this.send(client, MSG.NO_MATCH, { message: 'No one bumped back. Make sure your friend is on the bump screen too.' });
      }
    }, BUMP_WINDOW_MS + 200);
  }

  cancelFind(client, notify) {
    if (client.find?.code && this.waitingCodes.get(client.find.code) === client) this.waitingCodes.delete(client.find.code);
    this.bumpers.delete(client);
    client.find = null;
    if (notify) this.send(client, MSG.NO_MATCH, { cancelled: true });
  }

  /** `a` was waiting first, so `a` sends the Showdown challenge and `b` accepts it. */
  match(a, b) {
    if (toId(a.find.showdown) === toId(b.find.showdown)) {
      this.send(b, MSG.ERROR, { message: 'Both phones use the same Showdown name. Each player needs their own.' });
      return;
    }
    const format = a.find.format;
    const pair = [[a, b, 'challenge'], [b, a, 'accept']];
    for (const [me, them, role] of pair) {
      this.send(me, MSG.NOTIFY, { title: 'Battle found', body: `${them.find.name} wants to battle. Opening Showdown…` });
      this.send(me, MSG.MATCHED, {
        role, format, server: a.find.server,
        opponent: { name: them.find.name, showdown: them.find.showdown, capsules: them.find.capsules },
      });
    }
    this.log(`matched ${a.find.showdown} vs ${b.find.showdown}`);
    a.find = b.find = null;
  }

  onClose(client) {
    this.cancelFind(client, false);
    if (client.simCapsule) this.onCapDetach(client, { uid: client.simCapsule });
    this.clients.delete(client.id);
    this.broadcastChanged('clients');
  }
}

/** "0.3.1" newer than "0.3.0"? */
/**
 * The phone keeps an installed update only while its version.json names the phone's own Android
 * build (it checks on every start). For an update offered across a fingerprint difference, the
 * copy sent to that phone carries the phone's own fingerprint so it stays installed.
 */
function stampNative(files, phoneNative) {
  if (!files?.['version.json'] || !phoneNative) return files;
  try {
    const B = globalThis.Buffer;
    const text = B ? B.from(files['version.json'], 'base64').toString('utf8') : atob(files['version.json']);
    const v = JSON.parse(text);
    v.phoneNative = phoneNative;
    const out = JSON.stringify(v);
    return { ...files, 'version.json': B ? B.from(out, 'utf8').toString('base64') : btoa(out) };
  } catch { return files; }
}

export function newerVersion(a, b) {
  const pa = String(a ?? '0').split(/[.-]/).map(Number), pb = String(b ?? '0').split(/[.-]/).map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0; }
  return false;
}
