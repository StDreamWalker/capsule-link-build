// The PokéAtlas in the app: scan a spot on Earth the way the atlas does (elevation, a year of climate, the live
// weather, sea and air, the place's country and region, land cover and places nearby from OpenStreetMap), run the
// atlas's own engine on it, and keep a small table of who lives there. Walks (Look around) and wild battles draw
// from that table instead of hand-picked environments. Every source has the atlas's own fallback when it can't be
// reached, so a scan always gives an answer (just a rougher one offline).
import { atlasCore } from './atlasCore.js';
import { slug } from '../engine/dataset.js';

const H = 3600000, DAY = 24 * H;
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));

async function defaultFetch(url, init = {}, timeout = 20000) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeout);
  try { const r = await fetch(url, { ...init, signal: ctl.signal }); if (!r.ok) throw new Error(`HTTP ${r.status}`); return await r.json(); }
  finally { clearTimeout(t); }
}

// ---------- a small cache that outlives the app (localStorage when there is one) ----------
const mem = new Map();
const CACHE_KEY = 'capsule-atlas-cache:v1';
function diskGet() { try { return JSON.parse(globalThis.localStorage?.getItem(CACHE_KEY) || '{}'); } catch { return {}; } }
function diskSet(o) { try { globalThis.localStorage?.setItem(CACHE_KEY, JSON.stringify(o)); } catch { /* full: fine */ } }
async function cached(key, ttl, fn, { disk = true } = {}) {
  const now = Date.now();
  const m = mem.get(key);
  if (m && now - m.at < ttl) return m.v;
  if (disk) { const d = diskGet()[key]; if (d && now - d.at < ttl) { mem.set(key, d); return d.v; } }
  const v = await fn();
  const rec = { at: now, v };
  mem.set(key, rec);
  if (disk) {
    const o = diskGet(); o[key] = rec;
    const ks = Object.keys(o);
    if (ks.length > 300) for (const k of ks.sort((a, b) => o[a].at - o[b].at).slice(0, ks.length - 300)) delete o[k];
    diskSet(o);
  }
  return v;
}

// ---------- the atlas's own sources (the same services and queries as the atlas page) ----------
function ringPoints(lat, lon, rKm) {
  const pts = [[lat, lon]];
  const dLat = rKm / 111.2, dLon = rKm / (111.2 * Math.max(0.05, Math.cos((lat * Math.PI) / 180)));
  for (let i = 0; i < 8; i++) { const a = (i * Math.PI) / 4; pts.push([clamp(lat + dLat * Math.cos(a), -89.9, 89.9), ((lon + dLon * Math.sin(a) + 540) % 360) - 180]); }
  return pts;
}
const FC = 'https://api.open-meteo.com/v1/forecast', FC_Q = 'current=temperature_2m,relative_humidity_2m,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,wind_gusts_10m,is_day,pressure_msl&hourly=precipitation,wind_speed_250hPa&daily=sunrise,sunset&past_days=7&forecast_days=2&timezone=auto';
const MAR = 'https://marine-api.open-meteo.com/v1/marine', MAR_Q = 'current=wave_height,wave_period,swell_wave_height,swell_wave_period,sea_surface_temperature,ocean_current_velocity,ocean_current_direction';
const AQ = 'https://air-quality-api.open-meteo.com/v1/air-quality', AQ_Q = 'current=pm10,pm2_5,dust,uv_index,us_aqi,nitrogen_dioxide';
const minutesOf = (t) => +t.slice(11, 13) * 60 + +t.slice(14, 16);
function parseForecast(d) {
  const cu = d.current, lt = cu.time, Hh = d.hourly || {}, D = d.daily || {};
  const times = Hh.time || [];
  let i = times.findIndex((t) => t > lt) - 1; if (i === -2) i = times.length - 1; if (i < 0) i = 0;
  const sum = (n) => { let t = 0; for (let k = Math.max(0, i - n + 1); k <= i; k++) t += (Hh.precipitation && Hh.precipitation[k]) || 0; return t; };
  const di = (D.time || []).indexOf(lt.slice(0, 10));
  const date = new Date(`${lt.slice(0, 10)}T00:00:00Z`);
  return {
    temp: cu.temperature_2m, rh: cu.relative_humidity_2m, code: cu.weather_code, cloud: cu.cloud_cover, wind: cu.wind_speed_10m, windDir: cu.wind_direction_10m, gust: cu.wind_gusts_10m,
    isDay: !!cu.is_day, pressure: cu.pressure_msl, localTime: lt, hour: minutesOf(lt) / 60, nowMin: minutesOf(lt), month: +lt.slice(5, 7), dom: +lt.slice(8, 10), dow: date.getUTCDay(),
    doy: Math.floor((date - Date.UTC(date.getUTCFullYear(), 0, 1)) / 86400000) + 1, precip24: sum(24), precip48: sum(48), precip7d: sum(168), rain3h: sum(3),
    jet: Hh.wind_speed_250hPa ? Hh.wind_speed_250hPa[i] : null, sunriseMin: di >= 0 && D.sunrise ? minutesOf(D.sunrise[di]) : null, sunsetMin: di >= 0 && D.sunset ? minutesOf(D.sunset[di]) : null, tz: d.timezone,
  };
}
const parseMarine = (d) => (d && d.current ? { waveH: d.current.wave_height, wavePeriod: d.current.wave_period, swellH: d.current.swell_wave_height, swellPeriod: d.current.swell_wave_period, sst: d.current.sea_surface_temperature, currentV: d.current.ocean_current_velocity, currentDir: d.current.ocean_current_direction } : {});
const parseAQ = (d) => (d && d.current ? { pm25: d.current.pm2_5, pm10: d.current.pm10, dust: d.current.dust, uv: d.current.uv_index, aqi: d.current.us_aqi, no2: d.current.nitrogen_dioxide } : {});

const US_STATES = { alabama: 'AL', alaska: 'AK', arizona: 'AZ', arkansas: 'AR', california: 'CA', colorado: 'CO', connecticut: 'CT', delaware: 'DE', 'district of columbia': 'DC', florida: 'FL', georgia: 'GA', hawaii: 'HI', idaho: 'ID', illinois: 'IL', indiana: 'IN', iowa: 'IA', kansas: 'KS', kentucky: 'KY', louisiana: 'LA', maine: 'ME', maryland: 'MD', massachusetts: 'MA', michigan: 'MI', minnesota: 'MN', mississippi: 'MS', missouri: 'MO', montana: 'MT', nebraska: 'NE', nevada: 'NV', 'new hampshire': 'NH', 'new jersey': 'NJ', 'new mexico': 'NM', 'new york': 'NY', 'north carolina': 'NC', 'north dakota': 'ND', ohio: 'OH', oklahoma: 'OK', oregon: 'OR', pennsylvania: 'PA', 'rhode island': 'RI', 'south carolina': 'SC', 'south dakota': 'SD', tennessee: 'TN', texas: 'TX', utah: 'UT', vermont: 'VT', virginia: 'VA', washington: 'WA', 'west virginia': 'WV', wisconsin: 'WI', wyoming: 'WY' };
const OTHER_SUBS = { ca: { quebec: 'QC', 'québec': 'QC', 'nova scotia': 'NS', 'new brunswick': 'NB', 'prince edward island': 'PE', 'newfoundland and labrador': 'NL', alberta: 'AB', saskatchewan: 'SK', manitoba: 'MB', 'british columbia': 'BC', ontario: 'ON' }, gb: { wales: 'WLS', scotland: 'SCT', 'northern ireland': 'NIR', england: 'ENG' }, jp: { 'kyoto prefecture': '26', kyoto: '26', hokkaido: '01', 'hokkaidō': '01', 'okinawa prefecture': '47', okinawa: '47', 'shizuoka prefecture': '22', 'aichi prefecture': '23' }, es: { catalonia: 'CT', 'basque country': 'PV', andalusia: 'AN' }, in: { kerala: 'KL', rajasthan: 'RJ', ladakh: 'LA', sikkim: 'SK' }, mx: { oaxaca: 'OAX', 'michoacán': 'MIC', michoacan: 'MIC' }, cn: { tibet: 'XZ', xizang: 'XZ', qinghai: 'QH', 'inner mongolia': 'NM', xinjiang: 'XJ', yunnan: 'YN', guangxi: 'GX' } };
function subsFromState(cc, state) {
  if (!cc || !state) return [];
  const k = state.toLowerCase().replace(/ (state|province|autonomous region)$/, '');
  const code = cc === 'us' ? US_STATES[k] : (OTHER_SUBS[cc] || {})[k];
  return code ? [`${cc.toUpperCase()}-${code}`] : [];
}
async function geoNominatim(get, lat, lon, zoom) {
  const d = await get(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat.toFixed(5)}&lon=${lon.toFixed(5)}&zoom=${zoom}&addressdetails=1&accept-language=en`, {}, 9000);
  if (d.error) return { none: true };
  const a = d.address || {};
  if (!a.country_code) return { none: true };
  const subs = Object.entries(a).filter(([k]) => /^ISO3166-2-lvl\d+$/.test(k)).map(([, v]) => v);
  const state = a.state || a.region || a.province || a.state_district || '';
  return { ocean: false, cc: a.country_code, country: a.country, state, place: a.city || a.town || a.village || a.hamlet || a.suburb || a.county || a.municipality || '', placeType: a.city ? 'city' : a.town ? 'town' : (a.village || a.hamlet || a.suburb) ? 'village' : '', subs: subs.length ? subs : subsFromState(a.country_code, state), provider: 'OpenStreetMap Nominatim' };
}
async function geoBDC(get, lat, lon) {
  const d = await get(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat.toFixed(5)}&longitude=${lon.toFixed(5)}&localityLanguage=en`, {}, 9000);
  if (!d.countryCode) return { none: true };
  const cc = d.countryCode.toLowerCase(), subs = [];
  if (d.principalSubdivisionCode) subs.push(d.principalSubdivisionCode);
  ((d.localityInfo || {}).administrative || []).forEach((x) => { if (x.isoCode && /^[A-Z]{2}-/.test(x.isoCode)) subs.push(x.isoCode); });
  return { ocean: false, cc, country: d.countryName, state: d.principalSubdivision || '', place: d.city || d.locality || '', placeType: d.city ? 'city' : d.locality ? 'village' : '', subs: subs.length ? subs : subsFromState(cc, d.principalSubdivision), provider: 'BigDataCloud' };
}
async function geoPhoton(get, lat, lon) {
  const d = await get(`https://photon.komoot.io/reverse?lat=${lat.toFixed(5)}&lon=${lon.toFixed(5)}&lang=en`, {}, 9000);
  const f = (d.features || [])[0]; if (!f || !f.properties.countrycode) return { none: true };
  const p = f.properties, cc = p.countrycode.toLowerCase();
  return { ocean: false, cc, country: p.country, state: p.state || '', place: p.city || p.town || p.village || p.name || '', placeType: p.city ? 'city' : p.town ? 'town' : p.village ? 'village' : '', subs: subsFromState(cc, p.state), provider: 'Photon (komoot)' };
}
function geoOffline(A, lat, lon, noneVotes) {
  let best = null;
  for (const [cc, a, b] of A.COUNTRY_ANCHORS) { const d = A.haversineKm(lat, lon, a, b); if (!best || d < best.d) best = { cc, d }; }
  const far = best.d > 500;
  return { ocean: false, cc: far || best.cc === 'aq' ? '' : best.cc, country: far ? '' : best.cc.toUpperCase(), state: '', place: '', placeType: '', subs: [], estimated: true, maybeOcean: noneVotes > 0 || far, provider: `Offline estimate (nearest reference point ${Math.round(best.d)} km)` };
}
const OVERPASS = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter', 'https://overpass.private.coffee/api/interpreter'];
const OSM_CATS = [
  ['water', ['nwr["natural"="water"]', 'nwr["landuse"~"^(reservoir|basin)$"]']], ['river', ['way["waterway"~"^(river|stream|canal)$"]']], ['coast', ['way["natural"="coastline"]']],
  ['beach', ['nwr["natural"~"^(beach|sand|dune)$"]']], ['wetland', ['nwr["natural"="wetland"]']], ['forest', ['nwr["landuse"="forest"]', 'nwr["natural"="wood"]']],
  ['grass', ['nwr["landuse"~"^(meadow|grass|farmland|orchard|vineyard)$"]', 'nwr["natural"~"^(grassland|heath|scrub)$"]']], ['rock', ['nwr["natural"~"^(bare_rock|scree|cliff|rock|stone)$"]', 'nwr["landuse"="quarry"]']],
  ['glacier', ['nwr["natural"="glacier"]']], ['peak', ['node["natural"="peak"]']], ['volcano', ['node["natural"="volcano"]', 'nwr["natural"~"^(hot_spring|geyser)$"]']], ['cave', ['node["natural"="cave_entrance"]']],
  ['park', ['nwr["leisure"~"^(park|nature_reserve|garden)$"]']], ['residential', ['nwr["landuse"="residential"]']], ['commercial', ['nwr["landuse"~"^(commercial|retail)$"]']],
  ['industrial', ['nwr["landuse"~"^(industrial|railway)$"]', 'nwr["man_made"="works"]']], ['power', ['nwr["power"~"^(plant|substation)$"]']],
  ['trash', ['nwr["landuse"~"^(landfill|brownfield)$"]', 'nwr["industrial"="scrap_yard"]', 'nwr["amenity"~"^(recycling|waste_disposal)$"]']], ['grave', ['nwr["landuse"="cemetery"]', 'nwr["amenity"="grave_yard"]']],
  ['ruins', ['nwr["historic"~"^(ruins|archaeological_site|castle)$"]']], ['worship', ['nwr["amenity"="place_of_worship"]']], ['station', ['node["railway"="station"]']],
];
async function overpass(get, q, timeout) {
  let last;
  for (const ep of OVERPASS) {
    try { return await get(ep, { method: 'POST', body: `data=${encodeURIComponent(q)}`, headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }, timeout); } catch (e) { last = e; }
  }
  throw last;
}

/**
 * Everything the atlas needs about one spot (its "raw" input). Each source is optional: what fails is left out
 * and the atlas estimates it. opts: { radiusKm, osm (land cover and places, the slowest part), fetchJson }.
 * Returns { raw, src: { elev, climate, current, geo, osm, poi: 'ok' | 'fail' | 'off' } }.
 */
export async function scanSpot(lat, lon, { radiusKm = 1.5, osm = true, fetchJson = defaultFetch } = {}) {
  const A = atlasCore(), get = fetchJson;
  const r = radiusKm, rO = Math.min(r, 5), rP = Math.min(r, 3);
  const raw = { lat, lon, radiusKm: r, osmRadiusKm: rO, poiRadiusKm: rP, elev: null, elevSamples: [], climate: null, current: null, cond: null, geo: null, osm: null, poi: null, places: null };
  const src = { elev: 'wait', climate: 'wait', current: 'wait', geo: 'wait', osm: osm ? 'wait' : 'off', poi: osm ? 'wait' : 'off' };
  const g3 = (v) => v.toFixed(3), g2 = (v) => v.toFixed(2);
  const jobs = [
    cached(`el:${g3(lat)},${g3(lon)},${r}`, 60 * DAY, () => { const pts = ringPoints(lat, lon, r); return get(`https://api.open-meteo.com/v1/elevation?latitude=${pts.map((p) => p[0].toFixed(5)).join(',')}&longitude=${pts.map((p) => p[1].toFixed(5)).join(',')}`).then((d) => d.elevation); })
      .then((el) => { raw.elev = el[0]; raw.elevSamples = el; src.elev = 'ok'; }).catch(() => { src.elev = 'fail'; }),
    cached(`cl:${g2(lat)},${g2(lon)}`, 60 * DAY, () => get(`https://archive-api.open-meteo.com/v1/archive?latitude=${lat.toFixed(4)}&longitude=${lon.toFixed(4)}&start_date=2025-01-01&end_date=2025-12-31&daily=temperature_2m_mean,precipitation_sum,snowfall_sum&timezone=auto`, {}, 25000).then((d) => A.summarizeClimateFromDaily(d.daily)))
      .then((c) => { raw.climate = c; src.climate = 'ok'; }).catch(() => { src.climate = 'fail'; }),
    cached(`mc:${g2(lat)},${g2(lon)}`, 10 * 60000, async () => {
      const q = `latitude=${lat.toFixed(4)}&longitude=${lon.toFixed(4)}`;
      const [f, m, a] = await Promise.allSettled([get(`${FC}?${q}&${FC_Q}`), get(`${MAR}?${q}&${MAR_Q}`), get(`${AQ}?${q}&${AQ_Q}`)]);
      if (f.status !== 'fulfilled') throw f.reason;
      const cond = Object.assign(parseForecast(f.value), m.status === 'fulfilled' ? parseMarine(m.value) : {}, a.status === 'fulfilled' ? parseAQ(a.value) : {});
      return { cond, current: { temp: cond.temp, code: cond.code, wind: cond.wind, cloud: cond.cloud, isDay: cond.isDay, localTime: cond.localTime, tz: cond.tz } };
    }, { disk: false }).then((c) => { raw.cond = c.cond; raw.current = c.current; src.current = 'ok'; }).catch(() => { src.current = 'fail'; }),
    cached(`geo:${g2(lat)},${g2(lon)}`, 90 * DAY, async () => {
      let none = 0;
      for (const t of [() => geoNominatim(get, lat, lon, 14), () => geoBDC(get, lat, lon), () => geoPhoton(get, lat, lon), () => geoNominatim(get, lat, lon, 6)]) {
        try { const g = await t(); if (g.none) { none++; if (none >= 2) break; continue; } if (g.cc) return g; } catch { /* next one */ }
      }
      if (none >= 2) return { ocean: true, maybeOcean: true, subs: [], provider: 'Two geocoders found no country here' };
      return geoOffline(A, lat, lon, none);
    }).then((g) => { raw.geo = g; src.geo = g.estimated ? 'warn' : 'ok'; }).catch(() => { raw.geo = geoOffline(A, lat, lon, 0); src.geo = 'warn'; }),
  ];
  if (osm) {
    // (land cover, then the places nearby: one after the other, as the Overpass servers ask)
    jobs.push((async () => {
      try {
        raw.osm = await cached(`osm:${g3(lat)},${g3(lon)},${rO}`, 14 * DAY, async () => {
          const R = Math.round(rO * 1000);
          const q = `[out:json][timeout:40];${OSM_CATS.map(([, parts]) => `(${parts.map((p) => `${p}(around:${R},${lat.toFixed(5)},${lon.toFixed(5)});`).join('')});out count;`).join('')}`;
          const d = await overpass(get, q, 45000);
          const counts = (d.elements || []).filter((e) => e.type === 'count');
          if (counts.length !== OSM_CATS.length) throw new Error('bad count');
          const o = {}; OSM_CATS.forEach(([k], i) => { o[k] = +counts[i].tags.total || 0; }); return o;
        });
        src.osm = 'ok';
      } catch { src.osm = 'fail'; }
      try {
        const p = await cached(`poi:${g3(lat)},${g3(lon)},${rP}`, 14 * DAY, async () => {
          const R = Math.round(rP * 1000), Rp = Math.round(Math.max(rP * 1.5, 3) * 1000), la = lat.toFixed(5), lo = lon.toFixed(5);
          const q = `[out:json][timeout:60];${A.POI_CATS.map(([, parts]) => `(${parts.map((pp) => `${pp}(around:${R},${la},${lo});`).join('')});out count;`).join('')}node["place"~"^(city|town|village|suburb|quarter)$"]["population"](around:${Rp},${la},${lo});out 40;`;
          const d = await overpass(get, q, 65000);
          const els = d.elements || [], counts = els.filter((e) => e.type === 'count');
          if (counts.length !== A.POI_CATS.length) throw new Error('bad count');
          const poi = {}; A.POI_CATS.forEach(([k], i) => { poi[k] = +counts[i].tags.total || 0; });
          const places = els.filter((e) => e.type === 'node' && e.tags && e.tags.population).map((e) => ({ name: e.tags['name:en'] || e.tags.name || '', pop: parseInt(String(e.tags.population).replace(/[^0-9]/g, ''), 10) || 0, lat: e.lat, lon: e.lon, place: e.tags.place }));
          return { poi, places };
        });
        raw.poi = p.poi; raw.places = p.places; src.poi = 'ok';
      } catch { src.poi = 'fail'; }
      // standing on water? (a lake, a river, a reservoir: the sea itself the atlas tells from the elevation)
      try {
        raw.onWater = await cached(`wet:${lat.toFixed(4)},${lon.toFixed(4)}`, 60 * DAY, async () => {
          const d = await overpass(get, `[out:json][timeout:20];is_in(${lat.toFixed(5)},${lon.toFixed(5)})->.a;(area.a["natural"="water"];area.a["landuse"~"^(reservoir|basin)$"];area.a["waterway"="riverbank"];area.a["natural"="bay"];);out count;`, 25000);
          const c = (d.elements || []).find((e) => e.type === 'count');
          return c ? (+c.tags.areas || +c.tags.total || 0) > 0 : false;
        });
        src.water = 'ok';
      } catch { src.water = 'fail'; }
    })());
  }
  await Promise.all(jobs);
  return { raw, src };
}

/** The atlas's sky for the legends (the moon, eclipses), with no live quake or space-weather feeds. */
function skyNow(A) { const now = Date.now(); return { now, kp: null, quakes: null, moon: A.moonInfo(now), eclipse: A.nearestEclipse(now) }; }

/** Run the atlas on a scan: { env, result } exactly as the atlas page shows them (legends included near their lairs). */
export function analyzeRaw(raw, { legendary = true } = {}) {
  const A = atlasCore();
  const env = A.deriveEnv(raw);
  const legends = legendary ? A.evalLegends({ lat: raw.lat, lon: raw.lon }, raw.cond, null, skyNow(A)) : null;
  const result = A.scoreAll(env, A.SPECIES, { includeLegendary: legendary, weather: 'auto', time: 'auto', useConditions: true, legends });
  return { env, result };
}

/** A place's name from a scan, as the atlas writes it. */
export function placeLabel(raw) {
  const g = raw?.geo || {};
  if (g.ocean) return 'Open water';
  if (g.estimated) return g.country ? `${g.country} (estimated)` : `Remote area ${raw.lat.toFixed(2)}°, ${raw.lon.toFixed(2)}°`;
  return [g.place, g.state, g.country].filter(Boolean).slice(0, 2).join(', ') || (raw ? `${raw.lat.toFixed(2)}°, ${raw.lon.toFixed(2)}°` : '');
}

/**
 * The small table kept in the save: who you'd meet here (atlas name, dex, share), what the place is like, and when.
 * rows: [[dex, name, share, legendary 0/1, types]] — the stages making up nearly all encounters.
 */
export function tableFrom({ raw, src }, { env, result } = analyzeRaw(raw), extra = {}) {
  const A = atlasCore();
  const rows = []; let acc = 0;
  for (const r of result.list) {
    if (!(r.p > 0)) continue;
    if (acc > 0.995 && rows.length >= 40 && !r.s.legendary) continue;
    rows.push([r.s.dex, r.s.name, Math.round(r.p * 1e6) / 1e6, r.s.legendary ? 1 : 0, r.s.types.join('/')]);
    acc += r.p;
    if (rows.length >= 260) break;
  }
  const hab = Object.entries(env.H).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([k, v]) => [k, Math.round(v * 100) / 100]);
  return {
    v: 2, at: Date.now(),
    // the climate as the atlas's five classes (0..1 each), every habitat's score, and whether you're on water
    C: Object.fromEntries(Object.entries(env.C ?? {}).map(([k, x]) => [k, Math.round(x * 100) / 100])),
    H: Object.fromEntries(Object.entries(env.H).map(([k, x]) => [k, Math.round(x * 100) / 100])),
    onWater: env.isOcean ? 'sea' : raw.onWater ? 'lake' : false, elev: raw.elev ?? null, seaFrac: env.seaFrac ?? 0, lat: Math.round(raw.lat * 1000) / 1000, lon: Math.round(raw.lon * 1000) / 1000, radiusKm: raw.radiusKm, label: extra.label || placeLabel(raw),
    climate: env.climateClass, realm: env.fauna?.realmName ?? '', biomes: (env.fauna?.biomes ?? []).slice(0, 3).map((b) => b.name), hab, ocean: !!env.isOcean,
    weather: result.goWeather, weatherName: A.WEATHER_LABEL?.[result.goWeather] ?? result.goWeather, night: !!result.night, temp: raw.current?.temp ?? null,
    perHour: env.encountersPerHour, regions: (env.fauna?.regions ?? []).filter((R) => R.kind !== 'phys').slice(-2).map((R) => R.name), src, rows,
    ...extra,
  };
}

/** Scan a spot and make its table in one go. */
export async function atlasTableAt(lat, lon, opts = {}) {
  const scan = await scanSpot(lat, lon, opts);
  return tableFrom(scan, analyzeRaw(scan.raw, opts), opts.label ? { label: opts.label } : {});
}

// ---------- from the atlas's Pokémon to the species in this data set ----------
const FORM_WORD = { alolan: 'alola', galarian: 'galar', hisuian: 'hisui', paldean: 'paldea' };
const SKIP = new Set(['flower', 'striped', 'sea', 'style', 'breed', 'form']);
function formTokens(name) {
  const out = [];
  const m = /^(Alolan|Galarian|Hisuian|Paldean)\s/.exec(name);
  if (m) out.push(FORM_WORD[m[1].toLowerCase()]);
  const p = /\(([^)]+)\)/.exec(name);
  if (p) {
    const whole = slug(p[1]).replace(/-/g, '');
    for (const w of p[1].toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').split(/[^a-z']+/).map((x) => x.replace(/'/g, '')).filter((x) => x.length >= 3 && !SKIP.has(x))) out.push(w);
    if (whole && !out.includes(whole)) out.push(whole);
  }
  return out;
}
const mapCache = new WeakMap();
function speciesMap(idx) {
  let m = mapCache.get(idx);
  if (m) return m;
  const byNo = new Map(), byBase = new Map(), byName = new Map();
  for (const sp of idx.ds.species) {
    if (Number.isFinite(sp.no) && sp.no > 0 && sp.no < 10000 && !sp.baseSpecies && !sp.forme) { if (!byNo.has(sp.no)) byNo.set(sp.no, sp); }
    if (sp.baseSpecies) { const k = slug(sp.baseSpecies); if (!byBase.has(k)) byBase.set(k, []); byBase.get(k).push(sp); }
    byName.set(slug(sp.name).replace(/-/g, ''), sp);
  }
  // (data sets whose forms keep their base's number, with no baseSpecies: group those by number too)
  for (const sp of idx.ds.species) if (sp.forme && !sp.baseSpecies && Number.isFinite(sp.no)) { const b = byNo.get(sp.no); if (b) { const k = slug(b.id); if (!byBase.has(k)) byBase.set(k, []); byBase.get(k).push(sp); } }
  m = { byNo, byBase, byName, rows: new Map() };
  mapCache.set(idx, m);
  return m;
}
/** This data set's species for an atlas row ([dex, name, …]), or null when the data set doesn't have it. */
export function gameSpeciesFor(idx, row) {
  const M = speciesMap(idx);
  const key = `${row[0]}|${row[1]}`;
  if (M.rows.has(key)) return M.rows.get(key);
  let sp = null;
  const base = M.byNo.get(row[0]) ?? M.byName.get(slug(String(row[1]).replace(/\s*\(.*\)$/, '')).replace(/-/g, '')) ?? null;
  const toks = formTokens(String(row[1]));
  if (base && toks.length) {
    const forms = M.byBase.get(slug(base.id)) ?? M.byBase.get(slug(base.name)) ?? [];
    let best = null, bestN = 0;
    for (const f of forms) {
      if (f.battleOnly) continue;
      const s = slug(`${f.forme ?? ''} ${f.id} ${f.name}`).replace(/-/g, ' ');
      const n = toks.filter((t) => s.includes(t)).length;
      if (n > bestN) { best = f; bestN = n; }
    }
    sp = best ?? base;
  } else sp = base;
  if (sp && (sp.unobtainable || sp.battleOnly)) sp = null;
  M.rows.set(key, sp);
  return sp;
}

/**
 * The table as this data set's species: [{ sp, w, row }] (shares added up when two atlas stages land on one
 * species), and how much of the atlas's encounters this data set covers (0..1).
 * filter(sp): only these (for battles: the ones Showdown knows).
 */
export function atlasPool(idx, table, { filter = null, legendary = true } = {}) {
  if (!table?.rows?.length) return { pool: [], coverage: 0 };
  const by = new Map(); let covered = 0, total = 0;
  for (const row of table.rows) {
    total += row[2];
    if (!legendary && row[3]) continue;
    const sp = gameSpeciesFor(idx, row);
    if (!sp || sp.noWild || (filter && !filter(sp))) continue;
    covered += row[2];
    const e = by.get(sp.id);
    if (e) e.w += row[2]; else by.set(sp.id, { sp, w: row[2], row });
  }
  return { pool: [...by.values()].sort((a, b) => b.w - a.w), coverage: total ? covered / total : 0 };
}
/** Enough of this data set lives in the table for the atlas to decide who turns up. */
export const atlasUsable = (idx, table, opts) => { const { pool, coverage } = atlasPool(idx, table, opts); return pool.length >= 4 && coverage >= 0.2; };
/** Weights for the engine (species id → share), or null when the atlas can't be used with this data set. */
export function atlasWeights(idx, table, opts) {
  const { pool, coverage } = atlasPool(idx, table, opts);
  if (pool.length < 4 || coverage < 0.2) return null;
  return new Map(pool.map((e) => [e.sp.id, e.w]));
}

/** The battle stage that looks most like the spot (its strongest habitat). */
export function battlePlaceFor(table) {
  if (!table) return 'meadow';
  // on water, by the atlas: out at sea, under the waves; on a lake or a river, at the water's edge
  if (table.onWater === 'sea') return 'seafloor';
  if (table.onWater === 'lake') return 'shoreline';
  const H = Object.fromEntries(table.hab ?? []);
  const v = (k) => H[k] ?? 0;
  const cands = [
    ['seafloor', table.ocean ? 1.2 : 0], ['shoreline', Math.max(v('b') * (1 - 0.7 * v('d')), table.ocean ? 0 : v('s') * 0.8)], ['volcano', v('v') * 1.3], ['tundra', v('i') * 1.1], ['desert', v('d') * 1.05],
    ['skyline', v('m') * 0.95], ['cavern', v('c') > 0.5 ? v('c') : 0], ['marsh', Math.max(v('p'), v('w') * 0.75)], ['spooky', table.night ? v('y') * 1.2 + v('f') * 0.3 : v('y') * 0.6],
    ['forest', v('f')], ['outskirts', Math.max(v('u'), v('h') * 0.9)], ['meadow', Math.max(v('g'), 0.2)],
  ];
  return cands.sort((a, b) => b[1] - a[1])[0][0];
}

/** One line about a table: "Virginia Beach, Virginia · Humid subtropical · partly cloudy". */
export function tableLine(table) {
  if (!table) return '';
  return [table.label, table.climate?.replace(/\s*\(.*\)$/, ''), table.weather && table.weather !== 'none' ? String(table.weatherName).toLowerCase() : null].filter(Boolean).join(' · ');
}
export const HABITAT_LABEL = { g: 'grassland', f: 'forest', w: 'fresh water', s: 'open sea', b: 'beach & coast', c: 'caves', m: 'mountains', r: 'rocky ground', d: 'desert', v: 'volcanic', u: 'city', h: 'suburbs & parks', p: 'wetland', i: 'snow & ice', e: 'power lines', t: 'industry', y: 'graveyards & ruins' };

// ---------- from this data set's species back to the atlas: where its kind lives ----------
const profCache = new WeakMap();
/** The atlas's profile of a species (its climates, habitats, day or night, types), or null if the atlas lacks it. */
export function atlasProfileFor(idx, sp) {
  if (!sp) return null;
  let m = profCache.get(idx);
  if (!m) {
    m = new Map();
    const A = atlasCore();
    for (const s of A.SPECIES) {
      const g = gameSpeciesFor(idx, [s.dex, s.name]);
      if (!g) continue;
      const exact = /\(|^(Alolan|Galarian|Hisuian|Paldean) /.test(s.name);
      if (!m.has(g.id) || exact) m.set(g.id, { clim: s.clim, hab: s.hab, types: s.types, nocturnal: /n/.test(s.flags), diurnal: /d/.test(s.flags), soc: s.soc, alt: s.alt, cp: s.cp, name: s.name, legendary: !!s.legendary, ub: s.rar === 'U' });
    }
    profCache.set(idx, m);
  }
  const base = sp.baseSpecies ? idx.ds.species.find((x) => x.name === sp.baseSpecies || x.id === slug(sp.baseSpecies)) : null;
  return m.get(sp.id) ?? (base ? m.get(base.id) : null) ?? null;
}
