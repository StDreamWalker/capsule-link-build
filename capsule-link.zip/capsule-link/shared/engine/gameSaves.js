// Game save files: open a save from the games (Red/Blue/Yellow to Scarlet/Violet), see what's in its PC
// boxes and party, bring creatures over, and put creatures that came from that kind of game back in.
//
// Layouts, checksums and encryption follow PKHeX (PKHeX.Core/Saves: SAV1–SAV9SV and SwishCrypto).
//   Red/Blue/Yellow, Gold/Silver/Crystal       32 KB  (.sav; emulators may add a clock at the end)
//   Ruby/Sapphire/Emerald, FireRed/LeafGreen  128 KB
//   Diamond/Pearl/Platinum, HeartGold/SoulSilver, Black/White, Black 2/White 2   512 KB
//   X/Y, Omega Ruby/Alpha Sapphire, Sun/Moon, Ultra Sun/Ultra Moon   the 3DS "main" file (from Checkpoint/JKSM)
//   Sword/Shield, Scarlet/Violet   the Switch "main" file (from JKSV / Checkpoint)
// Sun/Moon and Ultra Sun/Ultra Moon saves are signed by the game, so they can be read but not written here.
//
//   const sav = openGameSave(bytes, 'Pokemon Emerald.sav')
//   sav.boxes[b].slots[s] → { bytes, ext } | null        (party: sav.party)
//   sav.take(b, s) / sav.put(b, s, bytes, ext) → { ok, reason }
//   sav.toBytes() → the changed save, checksums fixed, to write over the old one (keep a backup!)
import { readPkm } from './pkhex.js';
import { GEN1_TO_INTERNAL, GB_CHARS, GB_CHARS_JP, GEN3_CHARS, GEN3_CHARS_JP } from './oldGames.js';

const u16 = (d, o) => d[o] | (d[o + 1] << 8);
const u32 = (d, o) => (d[o] | (d[o + 1] << 8) | (d[o + 2] << 16) | (d[o + 3] << 24)) >>> 0;
const w16 = (d, o, v) => { d[o] = v & 255; d[o + 1] = (v >> 8) & 255; };
const w32 = (d, o, v) => { w16(d, o, v & 0xffff); w16(d, o + 2, (v >>> 16) & 0xffff); };
const be16 = (d, o) => (d[o] << 8) | d[o + 1];

// ---------- checksums ----------
export function crc16ccitt(d, start = 0, end = d.length) {
  let top = 0xff, bot = 0xff;
  for (let i = start; i < end; i++) {
    let x = d[i] ^ top;
    x ^= x >> 4;
    top = (bot ^ (x >> 3) ^ (x << 4)) & 0xff;
    bot = (x ^ (x << 5)) & 0xff;
  }
  return (top << 8) | bot;
}
const CRC16_TABLE = (() => { const t = new Uint16Array(256); for (let i = 0; i < 256; i++) { let c = i; for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xa001 : c >>> 1; t[i] = c; } return t; })();
/** Gen 7's checksum (CRC-16/ARC, inverted). */
export function crc16invert(d, start = 0, end = d.length) { let c = 0xffff; for (let i = start; i < end; i++) c = (CRC16_TABLE[(c ^ d[i]) & 0xff] ^ (c >>> 8)) & 0xffff; return (~c) & 0xffff; }
function sum32(d, start, len) { let c = 0; for (let i = 0; i < len; i += 4) c = (c + u32(d, start + i)) >>> 0; return ((c + (c >>> 16)) & 0xffff); }

// ---------- creature encryption (in-save boxes keep them encrypted) ----------
const BLOCK_POSITION = [0, 1, 2, 3, 0, 1, 3, 2, 0, 2, 1, 3, 0, 3, 1, 2, 0, 2, 3, 1, 0, 3, 2, 1, 1, 0, 2, 3, 1, 0, 3, 2, 2, 0, 1, 3, 3, 0, 1, 2, 2, 0, 3, 1, 3, 0, 2, 1, 1, 2, 0, 3, 1, 3, 0, 2, 2, 1, 0, 3, 3, 1, 0, 2, 2, 3, 0, 1, 3, 2, 0, 1, 1, 2, 3, 0, 1, 3, 2, 0, 2, 1, 3, 0, 3, 1, 2, 0, 2, 3, 1, 0, 3, 2, 1, 0, 0, 1, 2, 3, 0, 1, 3, 2, 0, 2, 1, 3, 0, 3, 1, 2, 0, 2, 3, 1, 0, 3, 2, 1, 1, 0, 2, 3, 1, 0, 3, 2];
const BLOCK_INV = [0, 1, 2, 4, 3, 5, 6, 7, 12, 18, 13, 19, 8, 10, 14, 20, 16, 22, 9, 11, 15, 21, 17, 23, 0, 1, 2, 4, 3, 5, 6, 7];
function shuffleBlocks(d, start, size, sv) {
  const tmp = d.slice(start, start + size * 4);
  for (let b = 0; b < 4; b++) { const from = BLOCK_POSITION[sv * 4 + b]; d.set(tmp.subarray(from * size, from * size + size), start + b * size); }
}
function cryptLCG(d, start, end, seed) {
  for (let i = start; i < end; i += 2) { seed = (Math.imul(0x41c64e6d, seed) + 0x6073) >>> 0; w16(d, i, u16(d, i) ^ (seed >>> 16)); }
}
const sum16 = (d, a, b) => { let x = 0; for (let i = a; i < b; i += 2) x = (x + u16(d, i)) & 0xffff; return x; };
/** gen 4/5 (136 bytes) and gen 6/7 (232 bytes): decrypted copy */
export function decrypt4567(bytes, gen) {
  const d = new Uint8Array(bytes);
  const size = gen >= 6 ? 232 : 136, block = gen >= 6 ? 56 : 32;
  const pv = u32(d, 0), chk = u16(d, 6);
  const sv = (pv >>> 13) & 31;
  cryptLCG(d, 8, size, gen >= 6 ? pv : chk);
  shuffleBlocks(d, 8, block, sv);
  return d;
}
export function encrypt4567(bytes, gen) {
  const d = new Uint8Array(bytes);
  const size = gen >= 6 ? 232 : 136, block = gen >= 6 ? 56 : 32;
  const pv = u32(d, 0), chk = u16(d, 6);
  shuffleBlocks(d, 8, block, BLOCK_INV[(pv >>> 13) & 31]);
  cryptLCG(d, 8, size, gen >= 6 ? pv : chk);
  return d;
}
const isPlain4567 = (d, gen) => sum16(d, 8, gen >= 6 ? 232 : 136) === u16(d, 6);
const GEN3_ORDER = ['GAEM', 'GAME', 'GEAM', 'GEMA', 'GMAE', 'GMEA', 'AGEM', 'AGME', 'AEGM', 'AEMG', 'AMGE', 'AMEG', 'EGAM', 'EGMA', 'EAGM', 'EAMG', 'EMGA', 'EMAG', 'MGAE', 'MGEA', 'MAGE', 'MAEG', 'MEGA', 'MEAG'];
function xor3(d, key) { for (let i = 32; i < 80; i += 4) w32(d, i, (u32(d, i) ^ key) >>> 0); }
/** gen 3: in-save (encrypted, shuffled) → PKHeX file layout (decrypted, G A E M) */
export function decrypt3(bytes) {
  const d = new Uint8Array(bytes);
  const pid = u32(d, 0), key = (pid ^ u32(d, 4)) >>> 0, order = GEN3_ORDER[pid % 24];
  xor3(d, key);
  const tmp = d.slice(32, 80);
  for (let i = 0; i < 4; i++) d.set(tmp.subarray(i * 12, i * 12 + 12), 32 + 'GAEM'.indexOf(order[i]) * 12);
  return d;
}
export function encrypt3(bytes) {
  const d = new Uint8Array(bytes);
  const pid = u32(d, 0), key = (pid ^ u32(d, 4)) >>> 0, order = GEN3_ORDER[pid % 24];
  const tmp = d.slice(32, 80);
  for (let i = 0; i < 4; i++) { const at = 'GAEM'.indexOf(order[i]) * 12; d.set(tmp.subarray(at, at + 12), 32 + i * 12); }
  xor3(d, key);
  return d;
}
const sumPlain3 = (d) => { let x = 0; for (let i = 32; i < 80; i += 2) x = (x + u16(d, i)) & 0xffff; return x; };

// ---------- names ----------
const gbName = (d, o, n, jp) => { let t = ''; for (let i = 0; i < n; i++) { const b = d[o + i]; if (b === 0x50 || b === 0) break; t += (jp ? GB_CHARS_JP : GB_CHARS)[b] ?? ''; } return t; };
const g3Name = (d, o, n, jp) => { let t = ''; for (let i = 0; i < n; i++) { const b = d[o + i]; if (b === 0xff) break; t += (jp ? GEN3_CHARS_JP : GEN3_CHARS)[b] ?? ''; } return t; };
const u16Name = (d, o, n) => { let t = ''; for (let i = 0; i < n; i++) { const c = u16(d, o + i * 2); if (!c || c === 0xffff) break; t += String.fromCharCode(c); } return t; };

// ---------- SHA-256 (for the Switch saves' hash) ----------
const K256 = new Uint32Array([0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]);
export function sha256(...parts) {
  const len = parts.reduce((n, p) => n + p.length, 0);
  const total = ((len + 9 + 63) >> 6) << 6;
  const m = new Uint8Array(total);
  let o = 0; for (const p of parts) { m.set(p, o); o += p.length; }
  m[len] = 0x80;
  const bits = len * 8;
  const dv = new DataView(m.buffer);
  dv.setUint32(total - 8, Math.floor(bits / 4294967296)); dv.setUint32(total - 4, bits >>> 0);
  const H = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
  const w = new Uint32Array(64);
  for (let off = 0; off < total; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4);
    for (let i = 16; i < 64; i++) {
      const a = w[i - 15], b = w[i - 2];
      const s0 = ((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3);
      const s1 = ((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
    }
    let [a, b, c, d, e, f, g, h] = H;
    for (let i = 0; i < 64; i++) {
      const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
      const t1 = (h + S1 + ((e & f) ^ (~e & g)) + K256[i] + w[i]) >>> 0;
      const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
      const t2 = (S0 + ((a & b) ^ (a & c) ^ (b & c))) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0; H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0;
    H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0; H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
  }
  const out = new Uint8Array(32);
  for (let i = 0; i < 8; i++) { out[i * 4] = H[i] >>> 24; out[i * 4 + 1] = (H[i] >>> 16) & 255; out[i * 4 + 2] = (H[i] >>> 8) & 255; out[i * 4 + 3] = H[i] & 255; }
  return out;
}

// ---------- a common shape for every game ----------
function makeSave({ gen, game, format, trainer, data, tail, boxes, party, canWrite = true, whyNot = '', readSlot, writeSlot, clearSlot, finish }) {
  const sav = {
    ok: true, gen, game, format, trainer, canWrite, whyNot, changed: false,
    boxes, party,
    /** First empty slot: { box, slot } or null (in `box` if given). */
    firstEmpty(box = null) {
      for (let b = box ?? 0; b < (box == null ? boxes.length : box + 1); b++) for (let s = 0; s < boxes[b].slots.length; s++) if (!boxes[b].slots[s]) return { box: b, slot: s };
      return null;
    },
    /** Take a creature out of a box slot (it leaves the game). */
    take(box, slot) {
      if (!canWrite) return { ok: false, reason: whyNot };
      if (!boxes[box]?.slots[slot]) return { ok: false, reason: 'That slot is empty.' };
      clearSlot(box, slot);
      sav.changed = true;
      refresh();
      return { ok: true };
    },
    /** Put a creature (its file from this generation) into an empty box slot. */
    put(box, slot, bytes, ext) {
      if (!canWrite) return { ok: false, reason: whyNot };
      if (boxes[box]?.slots[slot]) return { ok: false, reason: 'That slot isn’t empty.' };
      const want = format;
      const fmt = String(ext || '').toLowerCase().replace(/^e/, 'p');
      if (fmt !== want && !(want === 'pk9' && fmt === 'pk9') && !(want === 'pk8' && fmt === 'pk8')) return { ok: false, reason: `This game takes ${want.toUpperCase()} creatures; this one is ${fmt.toUpperCase() || 'from somewhere else'}.` };
      const r = writeSlot(box, slot, new Uint8Array(bytes));
      if (r && r.ok === false) return r;
      sav.changed = true;
      refresh();
      return { ok: true };
    },
    toBytes() {
      finish?.();
      return tail?.length ? concat(data, tail) : new Uint8Array(data);
    },
  };
  function refresh() {
    for (let b = 0; b < boxes.length; b++) for (let s = 0; s < boxes[b].slots.length; s++) boxes[b].slots[s] = readSlot(b, s);
    if (party) for (let s = 0; s < party.length; s++) party[s] = readSlot(-1, s);
  }
  refresh();
  return sav;
}
const concat = (a, b) => { const o = new Uint8Array(a.length + b.length); o.set(a); o.set(b, a.length); return o; };
/** A slot's creature, or null when empty or unreadable. */
function entry(bytes, ext) {
  const pk = readPkm(bytes, `x.${ext}`);
  if (!pk.ok || !(pk.national || pk.speciesInternal)) return null;
  return { bytes, ext, pk };
}

// ---------- Red / Blue / Yellow ----------
function gen1(data, tail) {
  const jp = isListAt(data, 0x2ed5, 30) && isListAt(data, 0x302d, 30) && !(isListAt(data, 0x2f2c, 6) && isListAt(data, 0x30c0, 20));
  const O = jp ? { party: 0x2ed5, cur: 0x302d, curIdx: 0x2842, chk: 0x3594, ot: 0x2598, tid: 0x25fb, starter: 0x29b9, pika: 0x2712 } : { party: 0x2f2c, cur: 0x30c0, curIdx: 0x284c, chk: 0x3523, ot: 0x2598, tid: 0x2605, starter: 0x29c3, pika: 0x271c };
  const cap = jp ? 30 : 20, nboxes = jp ? 8 : 12, nameLen = jp ? 6 : 11;
  const listSize = (n, pkSize) => 1 + (n + 1) + n * pkSize + n * nameLen * 2;
  const boxList = listSize(cap, 33);
  // boxes are packed lists, back to back in two banks; the box you have open lives in the main block
  const bankAt = (b) => (b < nboxes / 2 ? 0x4000 + b * boxList : 0x6000 + (b - nboxes / 2) * boxList);
  const curBox = () => data[O.curIdx] & 0x7f;
  const initialised = () => !!(data[O.curIdx] & 0x80);
  const where = (b) => (b === curBox() ? O.cur : initialised() ? bankAt(b) : -1);
  // a fresh game hasn't set up the other boxes yet: make them empty lists before putting anything there
  const initBoxes = () => {
    if (initialised()) return;
    for (let b = 0; b < nboxes; b++) { if (b === curBox()) continue; const at = bankAt(b); data.fill(0, at, at + boxList); data[at + 1] = 0xff; }
    data[O.curIdx] |= 0x80;
  };
  const starter = data[O.starter];
  const yellow = starter === 0x54 || (!starter && data[O.pika] !== 0);
  const game = yellow ? 'Yellow' : 'Red or Blue';
  const listRead = (at, n, pkSize, slot) => {
    const count = data[at];
    if (slot >= count) return null;
    const sp = data[at + 1 + slot];
    const pkAt = at + 1 + n + 1 + slot * pkSize;
    const otAt = at + 1 + n + 1 + n * pkSize + slot * nameLen;
    const nkAt = otAt + n * nameLen;
    // as PKHeX's one-creature list: count, species, FF, 44 bytes (box ones are 33: the rest is party stats), names
    const out = new Uint8Array(3 + 44 + nameLen * 2);
    out[0] = 1; out[1] = sp; out[2] = 0xff;
    out.set(data.subarray(pkAt, pkAt + Math.min(pkSize, 44)), 3);
    if (pkSize === 33) out[3 + 0x21] = data[pkAt + 3]; // level
    out.set(data.subarray(otAt, otAt + nameLen), 3 + 44);
    out.set(data.subarray(nkAt, nkAt + nameLen), 3 + 44 + nameLen);
    return out;
  };
  const boxes = Array.from({ length: nboxes }, (_, b) => ({ name: `Box ${b + 1}`, slots: new Array(cap).fill(null) }));
  const party = new Array(6).fill(null);
  return makeSave({
    gen: 1, game, format: 'pk1', data, tail,
    trainer: { name: gbName(data, O.ot, nameLen, jp), tid: be16(data, O.tid) },
    boxes, party,
    readSlot: (b, s) => { const at = b < 0 ? O.party : where(b); if (at < 0) return null; const raw = b < 0 ? listRead(at, 6, 44, s) : listRead(at, cap, 33, s); return raw ? entry(raw, 'pk1') : null; },
    clearSlot: (b, s) => listRemove(data, where(b), cap, 33, nameLen, s),
    writeSlot: (b, s, raw) => {
      if (b !== curBox()) initBoxes();
      const at = where(b);
      if (raw.length !== 3 + 44 + nameLen * 2) return { ok: false, reason: jp ? 'That creature is from an international game; this save is Japanese.' : 'That creature is from a Japanese game; this save isn’t.' };
      return listAppend(data, at, cap, 33, nameLen, raw[1] || raw[3], raw.subarray(3, 3 + 33), raw.subarray(47, 47 + nameLen), raw.subarray(47 + nameLen, 47 + nameLen * 2));
    },
    finish: () => { let x = 0; for (let i = O.ot; i < O.chk; i++) x = (x + data[i]) & 255; data[O.chk] = (~x) & 255; },
  });
}
function isListAt(d, at, max) { const n = d[at]; return n <= max && d[at + 1 + n] === 0xff; }
/** Gen 1/2 lists are packed: removing shifts everything after it down. */
function listRemove(data, at, cap, pkSize, nameLen, slot) {
  const n = data[at];
  const sp = at + 1, pk = at + 1 + cap + 1, ot = pk + cap * pkSize, nk = ot + cap * nameLen;
  const shift = (base, size) => { data.copyWithin(base + slot * size, base + (slot + 1) * size, base + n * size); data.fill(0, base + (n - 1) * size, base + n * size); };
  data.copyWithin(sp + slot, sp + slot + 1, sp + n + 1); // species list (with its 0xFF end)
  data[sp + n] = 0x00;
  shift(pk, pkSize); shift(ot, nameLen); shift(nk, nameLen);
  data[at] = n - 1;
  data[sp + n - 1] = 0xff;
}
function listAppend(data, at, cap, pkSize, nameLen, species, pk, ot, nick) {
  const n = data[at];
  if (n >= cap) return { ok: false, reason: 'That box is full.' };
  const sp = at + 1, pkAt = at + 1 + cap + 1, otAt = pkAt + cap * pkSize, nkAt = otAt + cap * nameLen;
  data[sp + n] = species; data[sp + n + 1] = 0xff;
  data.set(pk.subarray(0, pkSize), pkAt + n * pkSize);
  data.set(ot, otAt + n * nameLen); data.set(nick, nkAt + n * nameLen);
  data[at] = n + 1;
  return { ok: true };
}

// ---------- Gold / Silver / Crystal ----------
function gen2(data, tail) {
  const types = [
    ['gs', false, 0x288a, 0x2d6c, 20], ['c', false, 0x2865, 0x2d10, 20], ['gs', true, 0x283e, 0x2d10, 30], ['c', true, 0x281a, 0x2d10, 30],
  ];
  // international Gold/Silver, Crystal; Japanese Gold/Silver, Crystal (party at the first offset, current box at the second)
  const t = types.find(([, , p, c, n]) => isListAt(data, p, 6) && isListAt(data, c, n)) ?? null;
  if (!t) return null;
  const [kind, jp, partyAt, curAt, cap] = t;
  const O = kind === 'c' ? { curIdx: jp ? 0x2700 : 0x2700, chkEnd: 0x2b82, chk1: 0x2d0d, chk2: 0x1f0d } : { curIdx: 0x2724, chkEnd: 0x2d68, chk1: 0x2d69, chk2: 0x7e6d };
  const nameLen = jp ? 6 : 11, nboxes = jp ? 9 : 14, split = jp ? 6 : 7;
  const boxList = 1 + cap + 1 + cap * 32 + cap * nameLen * 2;
  const bankAt = (b) => (b < split ? 0x4000 + b * (boxList + 2) : 0x6000 + (b - split) * (boxList + 2));
  const curBox = () => data[O.curIdx] & 0x7f;
  const listRead = (at, n, pkSize, slot) => {
    const count = data[at];
    if (slot >= count) return null;
    const pkAt = at + 1 + n + 1 + slot * pkSize, otAt = at + 1 + n + 1 + n * pkSize + slot * nameLen, nkAt = otAt + n * nameLen;
    const out = new Uint8Array(3 + 48 + nameLen * 2);
    out[0] = 1; out[1] = data[at + 1 + slot]; out[2] = 0xff;
    out.set(data.subarray(pkAt, pkAt + Math.min(pkSize, 48)), 3);
    out.set(data.subarray(otAt, otAt + nameLen), 3 + 48);
    out.set(data.subarray(nkAt, nkAt + nameLen), 3 + 48 + nameLen);
    return out;
  };
  const boxes = Array.from({ length: nboxes }, (_, b) => ({ name: `Box ${b + 1}`, slots: new Array(cap).fill(null) }));
  const party = new Array(6).fill(null);
  const syncCurrent = (b) => { if (b === curBox()) data.copyWithin(curAt, bankAt(b), bankAt(b) + boxList); };
  return makeSave({
    gen: 2, game: kind === 'c' ? 'Crystal' : 'Gold or Silver', format: 'pk2', data, tail,
    trainer: { name: gbName(data, 0x2009 + 2, nameLen, jp), tid: be16(data, 0x2009) },
    boxes, party,
    readSlot: (b, s) => { const raw = b < 0 ? listRead(partyAt, 6, 48, s) : listRead(bankAt(b), cap, 32, s); return raw ? entry(raw, 'pk2') : null; },
    clearSlot: (b, s) => { listRemove(data, bankAt(b), cap, 32, nameLen, s); syncCurrent(b); },
    writeSlot: (b, s, raw) => {
      if (raw.length !== 3 + 48 + nameLen * 2) return { ok: false, reason: 'That creature is from a game in another language family (Japanese vs. international).' };
      const r = listAppend(data, bankAt(b), cap, 32, nameLen, raw[1] === 0xfd ? 0xfd : raw[3], raw.subarray(3, 3 + 32), raw.subarray(51, 51 + nameLen), raw.subarray(51 + nameLen, 51 + nameLen * 2));
      syncCurrent(b);
      return r;
    },
    finish: () => {
      if (jp) return; // Japanese saves keep their checksum elsewhere; only international ones are written
      let x = 0; for (let i = 0x2009; i <= O.chkEnd; i++) x = (x + data[i]) & 0xffff;
      w16(data, O.chk1, x); w16(data, O.chk2, x);
      // the game keeps a second copy of the main block
      if (kind === 'c') data.copyWithin(0x1209, 0x2009, 0x2009 + 0xb7a);
      else { data.copyWithin(0x15c7, 0x2009, 0x222f); data.copyWithin(0x3d69, 0x222f, 0x23d9); data.copyWithin(0x0c6b, 0x23d9, 0x2856); data.copyWithin(0x7e39, 0x2856, 0x288a); data.copyWithin(0x10e8, 0x288a, 0x2d69); }
    },
    canWrite: !jp, whyNot: jp ? 'Japanese Gold/Silver/Crystal saves can be read but not written here.' : '',
  });
}

// ---------- Ruby / Sapphire / Emerald, FireRed / LeafGreen ----------
function gen3(data, tail) {
  const present = (slot) => { let bits = 0, s0 = -1; for (let i = 0; i < 14; i++) { const o = slot * 0xe000 + i * 0x1000; const id = u16(data, o + 0xff4); if (id >= 14) return null; bits |= 1 << id; if (id === 0) s0 = o; } return bits === 0x3fff ? s0 : null; };
  const a = present(0), b = present(1);
  if (a == null && b == null) return null;
  const slot = a == null ? 1 : b == null ? 0 : (u32(data, b + 0xffc) > u32(data, a + 0xffc) && u32(data, b + 0xffc) !== 0xffffffff) || u32(data, a + 0xffc) === 0xffffffff ? 1 : 0;
  const sectorOf = (id) => { for (let i = 0; i < 14; i++) { const o = slot * 0xe000 + i * 0x1000; if (u16(data, o + 0xff4) === id) return o; } return -1; };
  const small = sectorOf(0);
  const ac = u32(data, small + 0xac);
  const kind = ac === 1 ? 'frlg' : ac === 0 ? 'rs' : (() => { for (let i = 0x890; i < 0xf2c; i++) if (data[small + i]) return 'e'; return 'rs'; })();
  const game = kind === 'frlg' ? 'FireRed or LeafGreen' : kind === 'e' ? 'Emerald' : 'Ruby or Sapphire';
  // the PC lives across sectors 5–13 (0xF80 bytes each): current box (4), 420 creatures × 80, box names
  const pcAt = (off) => { const sec = 5 + Math.floor(off / 0xf80); return sectorOf(sec) + (off % 0xf80); };
  const readPc = (off, len) => { const out = new Uint8Array(len); for (let i = 0; i < len; i++) out[i] = data[pcAt(off + i)]; return out; };
  const writePc = (off, bytes) => { for (let i = 0; i < bytes.length; i++) data[pcAt(off + i)] = bytes[i]; };
  const slotOff = (b, s) => 4 + (b * 30 + s) * 80;
  const large = sectorOf(1);
  const partyAt = large + (kind === 'frlg' ? 0x38 : 0x238);
  const jp = u16(data, small + 6) === 0;
  const names = readPc(4 + 420 * 80, 14 * 9);
  const boxes = Array.from({ length: 14 }, (_, i) => ({ name: g3Name(names, i * 9, 8, jp) || `Box ${i + 1}`, slots: new Array(30).fill(null) }));
  const party = new Array(6).fill(null);
  const touched = new Set();
  return makeSave({
    gen: 3, game, format: 'pk3', data, tail,
    trainer: { name: g3Name(data, small, 7, jp), tid: u16(data, small + 0x0a) },
    boxes, party,
    readSlot: (bx, s) => {
      const raw = bx < 0 ? (s < data[partyAt - 4] ? data.slice(partyAt + s * 100, partyAt + s * 100 + 80) : null) : readPc(slotOff(bx, s), 80);
      if (!raw || (u32(raw, 0) === 0 && u32(raw, 4) === 0)) return null;
      return entry(raw, 'pk3');
    },
    clearSlot: (bx, s) => { writePc(slotOff(bx, s), new Uint8Array(80)); touched.add(1); },
    writeSlot: (bx, s, raw) => {
      let d = raw.subarray(0, 80);
      // a PKHeX file is decrypted and in order: the game wants it encrypted and shuffled
      if (sumPlain3(d) === u16(d, 0x1c)) d = encrypt3(d);
      writePc(slotOff(bx, s), d);
      touched.add(1);
      return { ok: true };
    },
    finish: () => {
      for (let i = 0; i < 14; i++) { const o = slot * 0xe000 + i * 0x1000; w16(data, o + 0xff6, sum32(data, o, 0xf80)); }
    },
  });
}

// ---------- Diamond / Pearl / Platinum, HeartGold / SoulSilver ----------
function gen4(data) {
  const kinds = [['dp', 0xc100, 0xc100, 0x121e0, 0x14, 0x98, 0x64], ['pt', 0xcf2c, 0xcf2c, 0x121e4, 0x14, 0xa0, 0x68], ['hgss', 0xf628, 0xf700, 0x12310, 0x10, 0x98, 0x64]];
  const k = kinds.find(([, gs]) => { const g = data.subarray(0x40000, 0x40000 + gs); return u32(g, gs - 0xc) === gs && [0x20060623, 0x20070903].includes(u32(g, gs - 8)); })
    ?? kinds.find(([, gs]) => u32(data, gs - 0xc) === gs && [0x20060623, 0x20070903].includes(u32(data, gs - 8)));
  if (!k) return null;
  const [kind, gSize, sStart, sSize, footer, partyOff, trainerOff] = k;
  const newer = (a, b) => { const ma = u32(data, a), mb = u32(data, b); if (ma === 0xffffffff) return 1; if (mb === 0xffffffff) return 0; if (ma !== mb) return ma > mb ? 0 : 1; return u32(data, b + 4) > u32(data, a + 4) ? 1 : 0; };
  const g = newer(gSize - 0x14, 0x40000 + gSize - 0x14) ? 0x40000 : 0;
  const s = newer(sStart + sSize - 0x14, 0x40000 + sStart + sSize - 0x14) ? 0x40000 + sStart : sStart;
  const boxAt = (b, slot) => s + (kind === 'hgss' ? b * 0x1000 : 4 + b * 0xff0) + slot * 136;
  const partyAt = g + partyOff;
  const game = { dp: 'Diamond or Pearl', pt: 'Platinum', hgss: 'HeartGold or SoulSilver' }[kind];
  const nameAt = s + (kind === 'hgss' ? 0x12008 : 4 + 18 * 0xff0);
  const boxes = Array.from({ length: 18 }, (_, b) => ({ name: gen4Name(data, nameAt + b * 40, 20) || `Box ${b + 1}`, slots: new Array(30).fill(null) }));
  const party = new Array(6).fill(null);
  return makeSave({
    gen: 4, game, format: 'pk4', data,
    trainer: { name: gen4Name(data, g + trainerOff, 8), tid: u16(data, g + trainerOff + 0x10) },
    boxes, party,
    readSlot: (b, sl) => {
      const at = b < 0 ? (sl < data[partyAt - 4] ? partyAt + sl * 236 : -1) : boxAt(b, sl);
      if (at < 0) return null;
      const raw = data.slice(at, at + 136);
      if (u32(raw, 0) === 0 && u16(raw, 6) === 0) return null;
      return entry(raw, 'pk4');
    },
    clearSlot: (b, sl) => data.fill(0, boxAt(b, sl), boxAt(b, sl) + 136),
    writeSlot: (b, sl, raw) => { let d = raw.subarray(0, 136); if (isPlain4567(d, 4)) d = encrypt4567(d, 4); data.set(d, boxAt(b, sl)); return { ok: true }; },
    finish: () => {
      if (kind === 'hgss') w32(data, s + 18 * 0x1000 + 4, 0x3ffff); // HeartGold/SoulSilver only re-read boxes marked as changed
      w16(data, g + gSize - 2, crc16ccitt(data, g, g + gSize - footer));
      w16(data, s + sSize - 2, crc16ccitt(data, s, s + sSize - footer));
    },
  });
}
// Gen 4's own character table (letters, digits, common marks); anything else is skipped
function gen4Name(d, o, n) {
  let t = '';
  for (let i = 0; i < n; i++) {
    const v = u16(d, o + i * 2);
    if (v === 0xffff || v === 0) break;
    if (v >= 0x0121 && v <= 0x012a) t += String.fromCharCode(48 + v - 0x0121);
    else if (v >= 0x012b && v <= 0x0144) t += String.fromCharCode(65 + v - 0x012b);
    else if (v >= 0x0145 && v <= 0x015e) t += String.fromCharCode(97 + v - 0x0145);
    else t += { 0x01de: ' ', 0x01ab: '!', 0x01ac: '?', 0x01ae: '.', 0x01be: '-', 0x01ad: ',', 0x01b3: "'", 0x01bb: '♂', 0x01bc: '♀' }[v] ?? '';
  }
  return t.trim();
}

// ---------- Black / White, Black 2 / White 2 ----------
function gen5(data) {
  const footerOk = (main, info) => { const f = main - 0x100; return u16(data, f + info + 0x10 - 2) === crc16ccitt(data, f, f + info); };
  const kind = footerOk(0x24000, 0x8c) ? 'bw' : footerOk(0x26000, 0x94) ? 'b2w2' : null;
  if (!kind) return null;
  const table = kind === 'bw' ? 0x23f00 : 0x25f00, tableLen = kind === 'bw' ? 0x8c : 0x94, tableChk = kind === 'bw' ? 0x23f9a : 0x25fa2;
  const boxAt = (b, s) => 0x400 + b * 0x1000 + s * 136;
  const partyAt = 0x18e00;
  const touched = new Set();
  const boxes = Array.from({ length: 24 }, (_, b) => ({ name: u16Name(data, 4 + b * 0x28, 20) || `Box ${b + 1}`, slots: new Array(30).fill(null) }));
  const party = new Array(6).fill(null);
  return makeSave({
    gen: 5, game: kind === 'bw' ? 'Black or White' : 'Black 2 or White 2', format: 'pk5', data,
    trainer: { name: u16Name(data, 0x19404, 8), tid: u16(data, 0x19414) },
    boxes, party,
    readSlot: (b, s) => {
      const at = b < 0 ? (s < data[partyAt + 4] ? partyAt + 8 + s * 220 : -1) : boxAt(b, s);
      if (at < 0) return null;
      const raw = data.slice(at, at + 136);
      if (u32(raw, 0) === 0 && u16(raw, 6) === 0) return null;
      return entry(raw, 'pk5');
    },
    clearSlot: (b, s) => { data.fill(0, boxAt(b, s), boxAt(b, s) + 136); touched.add(b); },
    writeSlot: (b, s, raw) => { let d = raw.subarray(0, 136); if (isPlain4567(d, 5)) d = encrypt4567(d, 5); data.set(d, boxAt(b, s)); touched.add(b); return { ok: true }; },
    finish: () => {
      for (const b of touched) {
        const start = 0x400 + b * 0x1000, chk = crc16ccitt(data, start, start + 0xff0);
        w16(data, start + 0xff2, chk); w16(data, table + 2 * (b + 1), chk);
      }
      w16(data, tableChk, crc16ccitt(data, table, table + tableLen));
    },
  });
}

// ---------- X / Y, Omega Ruby / Alpha Sapphire, Sun / Moon, Ultra Sun / Ultra Moon ----------
function gen67(data) {
  if (u32(data, data.length - 0x1f0) !== 0x42454546) return null; // "BEEF"
  const kinds = { 0x65600: ['xy', 6, 0x14200, 0x22600, 'X or Y', 0x14000, 0x48], 0x76000: ['oras', 6, 0x14200, 0x33000, 'Omega Ruby or Alpha Sapphire', 0x14000, 0x48], 0x6be00: ['sm', 7, 0x1400, 0x4e00, 'Sun or Moon', 0x1200, 0x38], 0x6cc00: ['usum', 7, 0x1600, 0x5200, 'Ultra Sun or Ultra Moon', 0x1400, 0x38] };
  const k = kinds[data.length];
  if (!k) return null;
  const [kind, gen, partyAt, boxAt0, game, statusAt, otOff] = k;
  const bo = data.length - 0x200;
  // the block table after BEEF: length, id, checksum; each block starts on the next 0x200
  const blocks = [];
  for (let i = 0, ofs = 0; i < 200; i++) {
    const at = bo + 0x14 + i * 8;
    if (at + 8 > data.length) break;
    const len = u32(data, at);
    if (!len || len > data.length) break;
    blocks.push({ id: u16(data, at + 4), ofs, len, chkAt: at + 6 });
    ofs += Math.ceil(len / 0x200) * 0x200;
  }
  const boxAt = (b, s) => boxAt0 + (b * 30 + s) * 232;
  const nboxes = gen === 6 ? 31 : 32;
  const touched = new Set();
  const boxes = Array.from({ length: nboxes }, (_, b) => ({ name: `Box ${b + 1}`, slots: new Array(30).fill(null) }));
  const party = new Array(6).fill(null);
  const signed = gen === 7;
  return makeSave({
    gen, game, format: gen === 6 ? 'pk6' : 'pk7', data,
    trainer: { name: u16Name(data, statusAt + otOff, 13), tid: u16(data, statusAt) },
    boxes, party,
    canWrite: !signed, whyNot: signed ? 'Sun/Moon and Ultra Sun/Ultra Moon sign their saves, so creatures can be brought over from them but not put back here. (Use PKHeX to put them back.)' : '',
    readSlot: (b, s) => {
      const at = b < 0 ? (s < data[partyAt + 6 * 260] ? partyAt + s * 260 : -1) : boxAt(b, s);
      if (at < 0) return null;
      const raw = data.slice(at, at + 232);
      if (u32(raw, 0) === 0 && u16(raw, 6) === 0 && u16(raw, 8) === 0) return null;
      return entry(raw, gen === 6 ? 'pk6' : 'pk7');
    },
    clearSlot: (b, s) => { data.fill(0, boxAt(b, s), boxAt(b, s) + 232); touched.add(boxAt(b, s)); },
    writeSlot: (b, s, raw) => { let d = raw.subarray(0, 232); if (isPlain4567(d, 6)) d = encrypt4567(d, 6); data.set(d, boxAt(b, s)); touched.add(boxAt(b, s)); return { ok: true }; },
    finish: () => {
      for (const blk of blocks) {
        if (![...touched].some((o) => o >= blk.ofs && o < blk.ofs + blk.len)) continue;
        w16(data, blk.chkAt, gen === 6 ? crc16ccitt(data, blk.ofs, blk.ofs + blk.len) : crc16invert(data, blk.ofs, blk.ofs + blk.len));
      }
    },
  });
}

// ---------- Sword / Shield, Scarlet / Violet ----------
const INTRO = new Uint8Array([0x9E, 0xC9, 0x9C, 0xD7, 0x0E, 0xD3, 0x3C, 0x44, 0xFB, 0x93, 0x03, 0xDC, 0xEB, 0x39, 0xB4, 0x2A, 0x19, 0x47, 0xE9, 0x63, 0x4B, 0xA2, 0x33, 0x44, 0x16, 0xBF, 0x82, 0xA2, 0xBA, 0x63, 0x55, 0xB6, 0x3D, 0x9D, 0xF2, 0x4B, 0x5F, 0x7B, 0x6A, 0xB2, 0x62, 0x1D, 0xC2, 0x1B, 0x68, 0xE5, 0xC8, 0xB5, 0x3A, 0x05, 0x90, 0x00, 0xE8, 0xA8, 0x10, 0x3D, 0xE2, 0xEC, 0xF0, 0x0C, 0xB2, 0xED, 0x4F, 0x6D]);
const OUTRO = new Uint8Array([0xD6, 0xC0, 0x1C, 0x59, 0x8B, 0xC8, 0xB8, 0xCB, 0x46, 0xE1, 0x53, 0xFC, 0x82, 0x8C, 0x75, 0x75, 0x13, 0xE0, 0x45, 0xDF, 0x32, 0x69, 0x3C, 0x75, 0xF0, 0x59, 0xF8, 0xD9, 0xA2, 0x5F, 0xB2, 0x17, 0xE0, 0x80, 0x52, 0xDB, 0xEA, 0x89, 0x73, 0x99, 0x75, 0x79, 0xAF, 0xCB, 0x2E, 0x80, 0x07, 0xE6, 0xF1, 0x26, 0xE0, 0x03, 0x0A, 0xE6, 0x6F, 0xF6, 0x41, 0xBF, 0x7E, 0x59, 0xC2, 0xAE, 0x55, 0xFD]);
const XORPAD = new Uint8Array([0xA0, 0x92, 0xD1, 0x06, 0x07, 0xDB, 0x32, 0xA1, 0xAE, 0x01, 0xF5, 0xC5, 0x1E, 0x84, 0x4F, 0xE3, 0x53, 0xCA, 0x37, 0xF4, 0xA7, 0xB0, 0x4D, 0xA0, 0x18, 0xB7, 0xC2, 0x97, 0xDA, 0x5F, 0x53, 0x2B, 0x75, 0xFA, 0x48, 0x16, 0xF8, 0xD4, 0x8A, 0x6F, 0x61, 0x05, 0xF4, 0xE2, 0xFD, 0x04, 0xB5, 0xA3, 0x0F, 0xFC, 0x44, 0x92, 0xCB, 0x32, 0xE6, 0x1B, 0xB9, 0xB1, 0x2E, 0x01, 0xB0, 0x56, 0x53, 0x36, 0xD2, 0xD1, 0x50, 0x3D, 0xDE, 0x5B, 0x2E, 0x0E, 0x52, 0xFD, 0xDF, 0x2F, 0x7B, 0xCA, 0x63, 0x50, 0xA4, 0x67, 0x5D, 0x23, 0x17, 0xC0, 0x52, 0xE1, 0xA6, 0x30, 0x7C, 0x2B, 0xB6, 0x70, 0x36, 0x5B, 0x2A, 0x27, 0x69, 0x33, 0xF5, 0x63, 0x7B, 0x36, 0x3F, 0x26, 0x9B, 0xA3, 0xED, 0x7A, 0x53, 0x00, 0xA4, 0x48, 0xB3, 0x50, 0x9E, 0x14, 0xA0, 0x52, 0xDE, 0x7E, 0x10, 0x2B, 0x1B, 0x77, 0x6E]);
const xorpad = (d, end) => { for (let i = 0; i < end; i++) d[i] ^= XORPAD[i % 0x7f]; };
function xorshift(key) {
  let s = key >>> 0, c = 0;
  const adv = (x) => { x ^= x << 2; x >>>= 0; x ^= x >>> 15; x ^= x << 13; return x >>> 0; };
  let pop = 0; for (let k = key >>> 0; k; k &= k - 1) pop++;
  for (let i = 0; i < pop; i++) s = adv(s);
  return () => { const r = (s >>> (c * 8)) & 255; if (c === 3) { s = adv(s); c = 0; } else c++; return r; };
}
const TYPE_SIZE = { 3: 1, 8: 1, 9: 2, 10: 4, 11: 8, 12: 1, 13: 2, 14: 4, 15: 8, 16: 4, 17: 8 };
function switchSave(data) {
  if (data.length < 0x100000) return null;
  const hash = sha256(INTRO, data.subarray(0, data.length - 32), OUTRO);
  for (let i = 0; i < 32; i++) if (hash[i] !== data[data.length - 32 + i]) return null;
  const plain = new Uint8Array(data);
  xorpad(plain, plain.length - 32);
  // walk the blocks; remember where the box and party blocks' bytes are (and their key streams)
  const blocks = new Map();
  let o = 0;
  const end = plain.length - 32;
  while (o < end) {
    const key = u32(plain, o); o += 4;
    const x = xorshift(key);
    const type = plain[o++] ^ x();
    if (type <= 3) continue;
    if (type === 4 || type === 5) {
      const n = (plain[o] ^ x()) | ((plain[o + 1] ^ x()) << 8) | ((plain[o + 2] ^ x()) << 16) | ((plain[o + 3] ^ x()) << 24); o += 4;
      let len = n;
      if (type === 5) { const sub = plain[o++] ^ x(); len = n * (TYPE_SIZE[sub] ?? 1); }
      if (key === 0x0d66012c || key === 0x2985fe5d || key === 0x3aa1a9ad || key === 0xf25c070e || key === 0xe3e89bd1) {
        const dec = new Uint8Array(len); for (let i = 0; i < len; i++) dec[i] = plain[o + i] ^ x();
        blocks.set(key, { at: o, len, dec, key, skip: type === 5 ? 6 : 5 });
      }
      o += len;
    } else o += TYPE_SIZE[type] ?? 0;
  }
  const box = blocks.get(0x0d66012c);
  if (!box) return { ok: false, error: 'This Switch save has no PC boxes this app recognises (Sword/Shield and Scarlet/Violet are supported).' };
  const sv = blocks.has(0x3aa1a9ad) || blocks.has(0xe3e89bd1);
  const party = blocks.get(sv ? 0x3aa1a9ad : 0x2985fe5d);
  const status = blocks.get(sv ? 0xe3e89bd1 : 0xf25c070e);
  const fmt = sv ? 'pk9' : 'pk8';
  const nboxes = Math.min(32, Math.floor(box.len / (30 * 0x158)));
  const boxes = Array.from({ length: nboxes }, (_, b) => ({ name: `Box ${b + 1}`, slots: new Array(30).fill(null) }));
  const partySlots = new Array(6).fill(null);
  const at = (b, s) => (b * 30 + s) * 0x158;
  return makeSave({
    gen: sv ? 9 : 8, game: sv ? 'Scarlet or Violet' : 'Sword or Shield', format: fmt, data,
    trainer: status ? { name: u16Name(status.dec, sv ? 0x10 : 0xb0, 12), tid: u16(status.dec, 0) } : { name: '', tid: 0 },
    boxes, party: partySlots,
    readSlot: (b, s) => {
      const src = b < 0 ? party?.dec : box.dec;
      if (!src) return null;
      const o2 = b < 0 ? s * 0x158 : at(b, s);
      if (b < 0 && s >= (party.dec[6 * 0x158] ?? 0)) return null;
      const raw = src.slice(o2, o2 + 0x158);
      if (u32(raw, 0) === 0 && u16(raw, 6) === 0 && u16(raw, 8) === 0) return null;
      return entry(raw, fmt);
    },
    clearSlot: (b, s) => box.dec.fill(0, at(b, s), at(b, s) + 0x158),
    writeSlot: (b, s, raw) => {
      // box slots hold the party-size (0x158) encrypted file
      const full = new Uint8Array(0x158); full.set(raw.subarray(0, Math.min(raw.length, 0x158)));
      const enc = encryptPkm8(full);
      box.dec.set(enc, at(b, s));
      return { ok: true };
    },
    finish: () => {
      // re-encrypt the box block with its key stream, then the whole file with the pad, and hash it
      const x = xorshift(box.key);
      for (let i = 0; i < box.skip; i++) x();
      for (let i = 0; i < box.len; i++) plain[box.at + i] = box.dec[i] ^ x();
      const out = new Uint8Array(plain);
      xorpad(out, out.length - 32);
      out.set(sha256(INTRO, out.subarray(0, out.length - 32), OUTRO), out.length - 32);
      data.set(out);
    },
  });
}
// Gen 8/9 creature encryption (same as pkhex.js's, kept here so a save can be written without that module's state)
function encryptPkm8(bytes) {
  const d = new Uint8Array(bytes);
  // already encrypted? (its plain checksum won't match)
  let sum = 0; for (let i = 8; i < 0x148; i += 2) sum = (sum + u16(d, i)) & 0xffff;
  if (sum !== u16(d, 6)) return d;
  const ec = u32(d, 0);
  shuffleBlocks(d, 8, 0x50, BLOCK_INV[(ec >>> 13) & 31]);
  cryptLCG(d, 8, 8 + 4 * 0x50, ec);
  if (d.length > 0x148) cryptLCG(d, 0x148, d.length, ec);
  return d;
}

/**
 * Open a game save. Returns the save (see the top of this file) or { ok: false, error }.
 * `name` helps tell formats apart and is used in messages.
 */
export function openGameSave(input, name = '') {
  const bytes = new Uint8Array(input);
  const n = bytes.length;
  const head = (len) => ({ data: bytes.slice(0, len), tail: bytes.slice(len) });
  try {
    // Game Boy: 32 KB (an emulator may add a clock: up to 0x8030)
    if (n >= 0x8000 && n <= 0x8100) {
      const { data, tail } = head(0x8000);
      if (isListAt(data, 0x2f2c, 6) && isListAt(data, 0x30c0, 20) && !gen2Looks(data)) return gen1(data, tail);
      const g2 = gen2(data, tail);
      if (g2) return g2;
      if (isListAt(data, 0x2ed5, 6) && isListAt(data, 0x302d, 30)) return gen1(data, tail);
    }
    if (n >= 0x20000 && n <= 0x20100) { const { data, tail } = head(0x20000); const s = gen3(data, tail); if (s) return s; }
    if (n === 0x80000) { const data = bytes.slice(); const s = gen4(data) ?? gen5(data); if (s) return s; }
    if ([0x65600, 0x76000, 0x6be00, 0x6cc00].includes(n)) { const s = gen67(bytes.slice()); if (s) return s; }
    if (n > 0x100000) { const s = switchSave(bytes.slice()); if (s) return s; }
  } catch (e) {
    return { ok: false, error: `This save couldn’t be read (${e.message}).` };
  }
  if (n === 0x60000 || n === 0x56000 || /\.gci$/i.test(name)) return { ok: false, error: 'Colosseum and XD (GameCube) saves aren’t supported yet. In PKHeX, open the save, then Export the creatures as .ck3/.xk3 → Convert to .pk3, and bring those in.' };
  if (n === 0x380000) return { ok: false, error: 'Pokémon Battle Revolution (Wii) saves aren’t supported yet: open it in PKHeX and export the creatures as .pk4 files instead.' };
  return { ok: false, error: `That doesn’t look like a save this app can open (${(n / 1024).toFixed(0)} KB). Supported: Red/Blue/Yellow through Scarlet/Violet game saves (.sav, or "main" from a 3DS/Switch save manager).` };
}
// Crystal/Gold party offsets overlap gen 1's checks rarely: prefer gen 2 when its lists are both valid
function gen2Looks(d) { return (isListAt(d, 0x288a, 6) && isListAt(d, 0x2d6c, 20)) || (isListAt(d, 0x2865, 6) && isListAt(d, 0x2d10, 20)); }

/** The file of a creature (from c.pk.raw) in the shape a save of that generation stores, or null. */
export function rawForSave(c) {
  const b64 = c?.pk?.raw;
  if (!b64) return null;
  const bin = typeof atob === 'function' ? atob(b64) : Buffer.from(b64, 'base64').toString('binary');
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return { bytes: out, ext: String(c.pk.format || '').toLowerCase().replace(/^e/, 'p') };
}
export { GEN1_TO_INTERNAL };
