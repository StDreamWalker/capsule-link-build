// Catching a wild creature in a battle, the way the main games do it (Generation VIII–IX): the species' catch
// rate, its health, its status, the ball's own bonus (each one's condition as in the games), the low-level
// bonus, then four shake checks, or one for a critical capture. Showdown has no catching, so the battle hands
// the moment over to this (see shared/sdbattle/wild.js), and the caught creature is the very one you battled:
// its genes, temperament, ability, size, shininess and moves, as they were, plus where and how it was met.
//
//   catchRateOf(idx, sp)            → 3..255 (the data set's own, or a careful estimate)
//   ballBonus(ball, ctx)            → { mult, add, sure, why } for that ball in that moment
//   catchCheck(o, rand)             → { caught, shakes, critical, chance }
//   caughtInBattle(idx, foe, o)     → the creature to keep
import { BALL_NAMES_ENGINE as NAMES } from './ballNames.js';
import { addMemory, displayName } from './creature.js';

const clamp = (x, a, b) => Math.max(a, Math.min(b, x));

/** The species' catch rate: the data set's (from the PokéAPI tables), or an estimate from how strong it is. */
export function catchRateOf(idx, sp) {
  if (!sp) return 45;
  if (Number.isFinite(sp.catchRate) && sp.catchRate > 0) return clamp(sp.catchRate, 1, 255);
  if (sp.legendary || sp.mythical || /legend|mythical|sublegend|restricted/i.test(String(sp.tags ?? sp.class ?? ''))) return 3;
  const bst = Object.values(sp.baseStats ?? {}).reduce((a, b) => a + (Number(b) || 0), 0) || 400;
  // (close to the games' own spread: the weakest 255, early evolutions 120–190, middle 90, final forms 45)
  return bst < 300 ? 255 : bst < 360 ? 190 : bst < 420 ? 120 : bst < 470 ? 90 : bst < 540 ? 60 : bst < 600 ? 45 : 25;
}

/**
 * The ball's bonus. ctx: { turn (1 = first), night, cave, water (fishing/surfing spot), underwater,
 *   foe: { types, level, weightkg, baseSpe, gender, speciesId, evolvesWithMoonStone, ultraBeast },
 *   mine: { level, gender, speciesId }, caughtBefore (that species), sleeping }
 */
export function ballBonus(ball, ctx = {}) {
  const n = Number(ball), f = ctx.foe ?? {}, m = ctx.mine ?? {};
  const types = (f.types ?? []).map((x) => String(x).toLowerCase());
  const r = (mult, why = '', add = 0) => ({ mult, add, sure: false, why });
  switch (n) {
    case 1: return { mult: 255, add: 0, sure: true, why: 'It never fails.' };               // Master
    case 2: return r(2);                                                                     // Ultra
    case 3: return r(1.5);                                                                   // Great
    case 5: case 24: return r(1.5);                                                          // Safari, Sport
    case 6: return types.includes('water') || types.includes('bug') ? r(3.5, 'Works well on Water and Bug types.') : r(1); // Net
    case 7: return ctx.underwater || ctx.water ? r(3.5, 'Works well in the water.') : r(1); // Dive
    case 8: return r(Math.max(1, (41 - (f.level ?? 30)) / 10), 'Better on lower-level ones.'); // Nest
    case 9: return ctx.caughtBefore ? r(3.5, 'You’ve caught this kind before.') : r(1);    // Repeat
    case 10: return r(Math.min(4, 1 + ((ctx.turn ?? 1) - 1) * 1229 / 4096), 'Better the longer the battle goes.'); // Timer
    case 13: return ctx.night || ctx.cave ? r(3, 'Works well at night and in caves.') : r(1); // Dusk
    case 15: return (ctx.turn ?? 1) <= 1 ? r(5, 'Best on the very first turn.') : r(1);     // Quick
    case 17: return (f.baseSpe ?? 0) >= 100 ? r(4, 'Works well on fast ones.') : r(1);     // Fast
    case 18: { // Level
      const a = m.level ?? 1, b = f.level ?? 1;
      return r(a >= b * 4 ? 8 : a >= b * 2 ? 4 : a > b ? 2 : 1, 'Better when yours is higher level.');
    }
    case 19: return ctx.water ? r(4, 'Works well on ones from the water.') : r(1);           // Lure
    case 20: { // Heavy: added to the catch rate, by weight
      const w = f.weightkg ?? 0;
      return r(1, 'Better on heavy ones.', w >= 300 ? 30 : w >= 200 ? 20 : w >= 100 ? 0 : -20);
    }
    case 21: return m.speciesId && f.speciesId && m.speciesId === f.speciesId && m.gender && f.gender && m.gender !== f.gender && m.gender !== 'N' ? r(8, 'Same kind, opposite gender.') : r(1); // Love
    case 23: return f.evolvesWithMoonStone ? r(4, 'Works well on ones that evolve with a Moon Stone.') : r(1); // Moon
    case 25: return ctx.sleeping ? r(4, 'Works well on sleeping ones.') : r(1);              // Dream
    case 26: return f.ultraBeast ? r(5) : r(410 / 4096, 'Made for Ultra Beasts; poor on anything else.'); // Beast
    case 31: case 32: case 33: return r(n === 33 ? 2 : n === 32 ? 1.5 : 1);                  // Feather, Wing, Jet (Hisui)
    case 30: return r(2); case 29: return r(1.5);                                            // Ultra, Great (Hisui)
    case 34: case 35: case 36: return r(n === 36 ? 2.75 : n === 35 ? 2.25 : 1);              // Heavy, Leaden, Gigaton (Hisui)
    case 37: return { mult: 255, add: 0, sure: true, why: 'It never fails.' };              // Origin
    default: return r(1);                                                                    // Poké, Premier, Luxury, Heal, Cherish, Friend, …
  }
}

/** The status bonus: asleep or frozen ×2.5, paralysed, burnt or poisoned ×1.5. */
export const statusBonus = (st) => (['slp', 'frz'].includes(st) ? 2.5 : ['par', 'brn', 'psn', 'tox'].includes(st) ? 1.5 : 1);

/**
 * One throw. o: { rate, hp, maxhp, status, level, ball (bonus from ballBonus), dexCaught (how many kinds
 * you've caught: critical captures), rand: () => 0..1 }. → { caught, shakes (0–3, or 1 critical), critical, chance }
 */
export function catchCheck({ rate, hp, maxhp, status = '', level = 50, ball = { mult: 1, add: 0 }, dexCaught = 0 }, rand = Math.random) {
  if (ball.sure) return { caught: true, shakes: 3, critical: false, chance: 1 };
  const R = clamp((rate ?? 45) + (ball.add ?? 0), 1, 255);
  const M = Math.max(1, maxhp || 1), Hp = clamp(hp ?? M, 1, M);
  let a = ((3 * M - 2 * Hp) * R * (ball.mult ?? 1)) / (3 * M);
  a *= statusBonus(status);
  if (level < 13) a *= (36 - 2 * level) / 10; // (Gen VIII–IX: easier to catch low-level ones)
  a = Math.min(255, Math.max(1, a));
  if (a >= 255) return { caught: true, shakes: 3, critical: false, chance: 1 };
  const b = Math.floor(65536 / Math.pow(255 / a, 0.1875));
  const p1 = b / 65536, chance = Math.pow(p1, 4);
  // a critical capture: rarer the fewer kinds you've caught, one shake check
  const critMul = dexCaught > 600 ? 2.5 : dexCaught > 450 ? 2 : dexCaught > 300 ? 1.5 : dexCaught > 150 ? 1 : dexCaught > 30 ? 0.5 : 0;
  if (critMul && rand() * 256 < Math.floor(Math.min(255, a) * critMul) / 6) {
    const ok = rand() * 65536 < b;
    return { caught: ok, shakes: 1, critical: true, chance };
  }
  let shakes = 0;
  for (let i = 0; i < 4; i++) { if (rand() * 65536 < b) shakes++; else break; }
  return { caught: shakes === 4, shakes: Math.min(3, shakes), critical: false, chance };
}

/**
 * The creature caught: the one from the battle (its genes, temperament, ability, size, shininess and moves as
 * they were), with the health, status and PP it was left with, the ball it went into, and where it happened.
 * o: { hp, status, pp: [n], ball, place (label), stage (the battle place), trainer, t, location, turns, critical }
 */
export function caughtInBattle(idx, foe, o = {}) {
  const c = JSON.parse(JSON.stringify(foe));
  const t = o.t ?? Date.now();
  c.location = o.location ?? { kind: 'ranch' };
  c.ball = String(o.ball ?? 4); c.ballSkin = c.ball;
  c.trainer = o.trainer || c.trainer || '';
  c.metAt = t; c.metLevel = c.level; c.metHow = `Caught in a wild battle${o.place ? ` at ${o.place}` : ''}`;
  if (o.place) c.metPlace = o.place;
  if (Number.isFinite(o.hp)) c.hp = Math.max(1, Math.round(o.hp));
  c.status = o.status || null;
  if (Array.isArray(o.pp)) (c.moves ?? []).forEach((m, i) => { if (Number.isFinite(o.pp[i])) m.pp = o.pp[i]; });
  // the Heal Ball heals it; the Friend Ball makes it friendly at once; a Luxury Ball it grows fond of faster
  const n = Number(c.ball);
  if (n === 14) { c.hp = null; c.status = null; for (const m of c.moves ?? []) delete m.pp; }
  if (n === 22) c.friendship = Math.max(c.friendship ?? 0, 150);
  if (n === 11) c.luxury = true;
  c.memories = c.memories ?? [];
  const nm = displayName(idx, c);
  addMemory(c, `${nm} was caught in a ${NAMES[n] ?? 'Poké Ball'} by ${o.trainer || 'its trainer'}${o.place ? ` at ${o.place}` : ''}, after a battle${o.turns ? ` of ${o.turns} turn${o.turns === 1 ? '' : 's'}` : ''}${o.critical ? ' (a critical capture!)' : ''}.`, t, { core: true, keys: o.place ? [`place:${o.place}`] : [] });
  if (o.place) c.prefs = { ...(c.prefs || {}), [`place:${o.place}`]: Math.max(c.prefs?.[`place:${o.place}`] ?? 0, 2) };
  c.caughtInBattle = { at: t, place: o.place ?? '', stage: o.stage ?? '', ball: n, turns: o.turns ?? 0, critical: !!o.critical };
  delete c.wild;
  return c;
}

/** The balls in the bag, for the battle: [{ id, ball, name, count, color }]. */
export function battleBalls(save, ballItems) {
  return (ballItems ?? []).filter((b) => (save.inventory?.[b.id] ?? 0) > 0 && ![16, 27].includes(b.ball)).map((b) => ({ id: b.id, ball: b.ball, name: b.name, count: save.inventory[b.id], color: b.color }));
}

/**
 * One ball thrown at the wild creature in a battle, with everything the games look at.
 * q (from the battle): { ball, hp, maxhp, status, turn, level, types, weightkg, baseSpe, gender, mine: { level, gender, species } }
 * w: { wild (from rollWild), stage, table (the PokéAtlas's reading, for night and water), profile ({ legendary, ub }) }
 */
export function throwAtWild(idx, save, q, { wild, stage = '', table = null, profile = null, mineId = null, t = Date.now() } = {}) {
  const sp = idx.species.get(wild.speciesId);
  const hour = new Date(t).getHours();
  const night = table ? !!table.night : hour >= 19 || hour < 6;
  const owned = new Set(Object.values(save.creatures ?? {}).filter((c) => !c.egg).map((c) => c.speciesId));
  const moon = (sp?.evolutions ?? []).some((e) => /moon ?stone/i.test(String(e.value ?? e.item ?? '')));
  const ub = !!profile?.ub, legend = !!profile?.legendary;
  const bonus = ballBonus(q.ball, {
    turn: q.turn ?? 1, night, cave: ['cavern', 'crystal'].includes(stage), water: ['shoreline', 'seafloor', 'marsh'].includes(stage) || !!table?.onWater, underwater: stage === 'seafloor' || table?.onWater === 'sea',
    foe: { types: q.types ?? sp?.types ?? [], level: q.level ?? wild.level, weightkg: q.weightkg ?? sp?.weight ?? 0, baseSpe: q.baseSpe ?? sp?.baseStats?.spe ?? 0, gender: q.gender, speciesId: wild.speciesId, evolvesWithMoonStone: moon, ultraBeast: ub },
    mine: { level: q.mine?.level ?? 1, gender: q.mine?.gender, speciesId: mineId }, caughtBefore: owned.has(wild.speciesId), sleeping: q.status === 'slp',
  });
  let rate = catchRateOf(idx, sp);
  if (!(Number.isFinite(sp?.catchRate) && sp.catchRate > 0)) { if (ub) rate = 45; else if (legend) rate = 3; }
  const r = catchCheck({ rate, hp: q.hp, maxhp: q.maxhp, status: q.status, level: q.level ?? wild.level, ball: bonus, dexCaught: owned.size });
  return { ...r, why: bonus.why, rate };
}
