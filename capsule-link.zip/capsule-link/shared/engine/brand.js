// Names the apps use for themselves and their world. Stored in the data set (so phones get them
// when they sync) and applied to every piece of interface text, so renaming takes one form.
export const DEFAULT_BRAND = {
  app: 'Capsule Link',
  ball: 'capsule', balls: 'capsules',
  creature: 'creature', creatures: 'creatures',
  company: 'Capsule Link Network',
  product: 'Nexus Ball', // the device's product name, used in the introduction
  pc: 'PC',
};

export function normalizeBrand(b) {
  const o = { ...DEFAULT_BRAND };
  for (const k of Object.keys(DEFAULT_BRAND)) if (typeof b?.[k] === 'string' && b[k].trim()) o[k] = b[k].trim().slice(0, 40);
  if (!b?.balls && b?.ball) o.balls = plural(o.ball);
  if (!b?.creatures && b?.creature) o.creatures = plural(o.creature);
  return o;
}

export function plural(word) {
  const w = String(word);
  if (/(s|x|z|ch|sh)$/i.test(w)) return `${w}es`;
  if (/[^aeiou]y$/i.test(w)) return `${w.slice(0, -1)}ies`;
  return `${w}s`;
}

const caseLike = (sample, word) => {
  if (sample === sample.toUpperCase() && sample.length > 1) return word.toUpperCase();
  if (sample[0] === sample[0].toUpperCase()) return word.replace(/^./, (c) => c.toUpperCase());
  return word;
};

/** "a" or "an" to suit the word that now follows it ("a capsule" → "an orb"). */
function withArticle(art, word) {
  if (!art) return word;
  const an = /^[aeiou]/i.test(word) && !/^(uni|use|usu|eu|one)/i.test(word);
  const a = an ? 'an' : 'a';
  return `${art[0] === 'A' ? a[0].toUpperCase() + a.slice(1) : a} ${word}`;
}

/** A function that rewrites default wording ("Capsule Link", "capsule(s)", "creature(s)") to the brand. */
export function brandRewriter(brand) {
  const b = normalizeBrand(brand);
  const same = Object.keys(DEFAULT_BRAND).every((k) => b[k] === DEFAULT_BRAND[k]);
  if (same) return (s) => s;
  const pairs = [
    [/Nexus Ball/g, () => b.product],
    [/Capsule Link Network/g, () => b.company],
    [/Capsule Link/g, () => b.app],
    [/CAPSULE LINK/g, () => b.app.toUpperCase()],
    [/\bPC\b/g, () => b.pc],
    [/\b(capsules|Capsules|CAPSULES)\b/g, (m) => caseLike(m, b.balls)],
    [/\b(?:(a|an|A|An) )?(capsule|Capsule|CAPSULE)\b/g, (m, art, w) => withArticle(art, caseLike(w, b.ball))],
    [/\b(creatures|Creatures|CREATURES)\b/g, (m) => caseLike(m, b.creatures)],
    [/\b(?:(a|an|A|An) )?(creature|Creature|CREATURE)\b/g, (m, art, w) => withArticle(art, caseLike(w, b.creature))],
  ];
  return (s) => {
    if (typeof s !== 'string' || !s) return s;
    let out = s;
    for (const [re, fn] of pairs) out = out.replace(re, fn);
    return out;
  };
}
