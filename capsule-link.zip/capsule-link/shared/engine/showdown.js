// Battles happen on Pokémon Showdown. This module:
//  - turns your creatures into a Showdown team (importable text and the packed format)
//  - reads a finished Showdown battle log and works out experience, effort and friendship
//    in-house with the Data Lab's formulas
//  - builds the small bridge script the apps inject into their embedded Showdown page, which
//    sends your team with /utm + /challenge or /accept and hands the battle log back.
import { STAT_KEYS, runFormula, slug } from './dataset.js';
import { speciesOf } from './creature.js';
import { battleSpeciesOf } from './forms.js';
import { hashString } from './rng.js';
import { TYPE_BOOSTER } from './shop.js';

/** What Showdown calls the item they hold (a made-up type incense counts as that type's 1.2× booster). */
function heldFor(idx, c) {
  if (c.heldItem) return c.heldItem;
  const id = String(c.heldItemId ?? '');
  if (id.startsWith('incense-')) { const t = idx.types?.get?.(id.slice(8)); return TYPE_BOOSTER[String(t?.name ?? '').toLowerCase()] ?? ''; }
  return '';
}

export const SHOWDOWN_DEFAULTS = {
  server: 'https://play.pokemonshowdown.com',
  format: 'gen9customgame',
};

const SD_STAT = { hp: 'HP', atk: 'Atk', def: 'Def', spa: 'SpA', spd: 'SpD', spe: 'Spe' };

/** Showdown's id rule: lowercase letters and digits only. */
export const toId = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '');

const cleanName = (s, max = 18) => String(s ?? '').replace(/[|,\]\[\n\r]/g, '').trim().slice(0, max);

function abilityFor(sp, c) {
  if (c.ability) return c.ability;
  const list = Array.isArray(sp.abilities) ? sp.abilities : sp.abilities ? Object.values(sp.abilities) : [];
  return list.filter(Boolean)[0] ?? '';
}

/** One creature as a Showdown set. */
export function showdownSet(idx, c, nickname) {
  // the form they were last in, if battles allow it
  const sp = battleSpeciesOf(idx, c) ?? speciesOf(idx, c);
  const species = sp?.showdownName || sp?.name || c.speciesId;
  const t = idx.temperaments.get(c.temper);
  return {
    name: nickname ?? cleanName(c.nickname || species),
    species: cleanName(species, 40),
    item: heldFor(idx, c) ? cleanName(heldFor(idx, c), 40) : '',
    ability: cleanName(abilityFor(sp ?? {}, c), 40),
    moves: c.moves.map((m) => idx.moves.get(m.id)).filter(Boolean).map((mv) => cleanName(mv.showdownName || mv.name, 40)),
    nature: t ? cleanName(t.showdownName || t.name, 20) : '',
    evs: Object.fromEntries(STAT_KEYS.map((k) => [k, Math.max(0, Math.min(255, c.effort?.[k] ?? 0))])),
    ivs: Object.fromEntries(STAT_KEYS.map((k) => [k, Math.max(0, Math.min(31, c.genes?.[k] ?? 31))])),
    level: c.level,
    happiness: Math.max(0, Math.min(255, c.friendship ?? 255)),
    shiny: !!c.shiny,
  };
}

/**
 * A whole team. Nicknames are made unique so the battle log can be matched back to creatures.
 * Returns { sets, text, packed, map: { nickname: uid } }.
 */
export function buildTeam(idx, creatures) {
  const used = new Set();
  const map = {};
  const sets = [];
  for (const c of creatures.slice(0, 6)) {
    if (!speciesOf(idx, c)) continue;
    const sp = speciesOf(idx, c);
    let base = cleanName(c.nickname || sp.showdownName || sp.name) || 'Buddy';
    let name = base, n = 2;
    while (used.has(toId(name))) name = `${base.slice(0, 16)} ${n++}`;
    used.add(toId(name));
    map[name] = c.uid;
    sets.push(showdownSet(idx, c, name));
  }
  return { sets, text: exportTeam(sets), packed: packTeam(sets), map };
}

/** Showdown's importable text format. */
export function exportTeam(sets) {
  return sets.map((s) => {
    const lines = [];
    const head = toId(s.name) === toId(s.species) ? s.species : `${s.name} (${s.species})`;
    lines.push(s.item ? `${head} @ ${s.item}` : head);
    if (s.ability) lines.push(`Ability: ${s.ability}`);
    if (s.level !== 100) lines.push(`Level: ${s.level}`);
    if (s.shiny) lines.push('Shiny: Yes');
    if (s.happiness !== 255) lines.push(`Happiness: ${s.happiness}`);
    const evs = STAT_KEYS.filter((k) => s.evs[k]).map((k) => `${s.evs[k]} ${SD_STAT[k]}`);
    if (evs.length) lines.push(`EVs: ${evs.join(' / ')}`);
    if (s.nature) lines.push(`${s.nature} Nature`);
    const ivs = STAT_KEYS.filter((k) => s.ivs[k] !== 31).map((k) => `${s.ivs[k]} ${SD_STAT[k]}`);
    if (ivs.length) lines.push(`IVs: ${ivs.join(' / ')}`);
    for (const m of s.moves) lines.push(`- ${m}`);
    return lines.join('\n');
  }).join('\n\n');
}

/** Showdown's one-line packed format (what /utm takes). */
export function packTeam(sets) {
  return sets.map((s) => {
    const evs = STAT_KEYS.map((k) => (s.evs[k] ? String(s.evs[k]) : ''));
    const ivs = STAT_KEYS.map((k) => (s.ivs[k] === 31 ? '' : String(s.ivs[k])));
    const species = toId(s.species) === toId(s.name) ? '' : s.species;
    return [
      s.name,
      species,
      toId(s.item),
      toId(s.ability),
      s.moves.map(toId).join(','),
      s.nature,
      evs.every((x) => !x) ? '' : evs.join(','),
      '',
      ivs.every((x) => !x) ? '' : ivs.join(','),
      s.shiny ? 'S' : '',
      s.level === 100 ? '' : String(s.level),
      s.happiness === 255 ? '' : String(s.happiness),
    ].join('|');
  }).join(']');
}

// ---------------------------------------------------------------- reading logs

/** Pull the plain battle log out of a replay JSON, a downloaded replay page, or plain text. */
export function extractLog(input) {
  let text = String(input ?? '').trim();
  if (!text) return '';
  if (text.startsWith('{')) {
    try { const j = JSON.parse(text); if (typeof j.log === 'string') return j.log; if (typeof j.inputLog === 'string') return j.inputLog; } catch { /* not JSON */ }
  }
  const m = /<script[^>]*class="(?:battle-log-data|log)"[^>]*>([\s\S]*?)<\/script>/i.exec(text);
  if (m) text = m[1].replace(/<\\\/script>/g, '</script>');
  // a chunk copied from a websocket capture may start with ">battle-…"
  return text.split('\n').filter((l) => l.startsWith('|') || l === '').join('\n');
}

/** Turns "Species, L50, M, shiny" into { species, level }. */
function parseDetails(details) {
  const parts = String(details).split(',').map((s) => s.trim());
  const lv = parts.find((p) => /^L\d+$/.test(p));
  return { species: parts[0], level: lv ? Number(lv.slice(1)) : 100 };
}

function parseIdent(ident) {
  const m = /^(p\d)([a-z])?: ?(.*)$/.exec(String(ident).trim());
  return m ? { side: m[1], pos: m[2] ?? null, name: m[3] } : null;
}

/**
 * Read a battle log. Returns:
 * { ok, error, id, format, players: {p1, p2}, winner (player name|null), tie,
 *   mons: { p1: {nick: {species, level, fainted}}, p2: … }, kos: [{ side, nick, facedBy: [nick…] }] }
 */
export function parseBattleLog(raw, opts = {}) {
  const log = extractLog(raw);
  const out = { ok: false, id: opts.id ?? null, format: '', players: {}, winner: null, tie: false, mons: { p1: {}, p2: {}, p3: {}, p4: {} }, kos: [], turns: 0 };
  if (!log) { out.error = 'No battle log found.'; return out; }
  const active = { p1: {}, p2: {}, p3: {}, p4: {} };
  const faced = { p1: {}, p2: {}, p3: {}, p4: {} }; // faced[side][nick] = Set of foe nicks seen at the same time
  const foes = (side) => (side === 'p1' || side === 'p3' ? ['p2', 'p4'] : ['p1', 'p3']);
  const meet = () => {
    for (const side of ['p1', 'p2', 'p3', 'p4']) {
      for (const nick of Object.values(active[side])) {
        if (!nick) continue;
        const set = faced[side][nick] || (faced[side][nick] = new Set());
        for (const f of foes(side)) for (const fn of Object.values(active[f])) if (fn) set.add(`${f}|${fn}`);
      }
    }
  };
  for (const line of log.split('\n')) {
    if (!line.startsWith('|')) continue;
    const parts = line.slice(1).split('|');
    const cmd = parts[0];
    switch (cmd) {
      case 'player':
        if (parts[1] && parts[2]) out.players[parts[1]] = parts[2];
        break;
      case 'tier':
        out.format = parts[1] ?? '';
        break;
      case 'turn':
        out.turns = Number(parts[1]) || out.turns;
        break;
      case 'switch': case 'drag': case 'replace': {
        const id = parseIdent(parts[1]);
        if (!id) break;
        const d = parseDetails(parts[2]);
        const mon = out.mons[id.side][id.name] || (out.mons[id.side][id.name] = { species: d.species, level: d.level, fainted: false });
        mon.species = mon.species || d.species;
        mon.level = d.level;
        active[id.side][id.pos ?? 'a'] = id.name;
        meet();
        break;
      }
      case 'detailschange': {
        const id = parseIdent(parts[1]);
        if (id && out.mons[id.side][id.name]) out.mons[id.side][id.name].level = parseDetails(parts[2]).level;
        break;
      }
      case 'faint': {
        const id = parseIdent(parts[1]);
        if (!id) break;
        const mon = out.mons[id.side][id.name];
        if (mon) mon.fainted = true;
        // everyone on the other side who has been out at the same time as this one shares the experience
        const facedBy = [];
        for (const f of foes(id.side)) {
          for (const [nick, set] of Object.entries(faced[f])) {
            // fainted creatures do not share in the experience
            if (set.has(`${id.side}|${id.name}`) && !out.mons[f][nick]?.fainted) facedBy.push(`${f}|${nick}`);
          }
        }
        out.kos.push({ side: id.side, nick: id.name, facedBy });
        if (active[id.side][id.pos ?? 'a'] === id.name) active[id.side][id.pos ?? 'a'] = null;
        break;
      }
      case 'win':
        out.winner = parts[1] ?? null;
        break;
      case 'tie':
        out.tie = true;
        break;
      default: break;
    }
  }
  out.ok = !!(out.winner || out.tie);
  if (!out.ok) out.error = 'This battle has not finished yet (no winner in the log).';
  if (!out.id) out.id = `log-${hashString(log).toString(36)}`;
  return out;
}

/**
 * Which side is mine? Uses the team maps you exported (nickname -> uid) and, if known, your
 * Showdown name. Returns { side, map } or null.
 */
export function findMySide(parsed, teams = [], myName = '') {
  let best = null;
  for (const side of ['p1', 'p2', 'p3', 'p4']) {
    const nicks = Object.keys(parsed.mons[side] ?? {});
    if (!nicks.length) continue;
    for (const t of teams) {
      const hit = nicks.filter((n) => t.map[n]).length;
      const score = hit * 10 + (myName && toId(parsed.players[side]) === toId(myName) ? 5 : 0);
      if (hit && (!best || score > best.score)) best = { side, map: t.map, score };
    }
  }
  if (!best && myName) {
    const side = Object.keys(parsed.players).find((s) => toId(parsed.players[s]) === toId(myName));
    if (side) best = { side, map: {}, score: 1 };
  }
  return best;
}

/**
 * In-house rewards from a Showdown battle, in the same shape the rest of the app uses:
 * { eventId, won, tie, opponent, linked: true, results: [{ uid, name, exp, effort, friendship, won, fainted }], unknown: [species] }
 */
export function battleRewards(idx, parsed, mine, save) {
  const side = mine.side;
  const won = !parsed.tie && toId(parsed.winner) === toId(parsed.players[side]);
  const oppSides = side === 'p1' || side === 'p3' ? ['p2', 'p4'] : ['p1', 'p3'];
  const opponent = oppSides.map((s) => parsed.players[s]).filter(Boolean).join(' & ') || 'Opponent';
  const results = new Map();
  const unknown = new Set();
  const rewardFor = (nick) => {
    const uid = mine.map[nick];
    if (!uid || !save.creatures[uid]) return null;
    if (!results.has(uid)) results.set(uid, { uid, name: nick, exp: 0, effort: {}, friendship: 0, won, fainted: !!parsed.mons[side][nick]?.fainted, took: true });
    return results.get(uid);
  };
  for (const nick of Object.keys(parsed.mons[side])) rewardFor(nick);
  for (const ko of parsed.kos) {
    if (!oppSides.includes(ko.side)) continue;
    const foe = parsed.mons[ko.side][ko.nick];
    const sp = idx.speciesByName.get(slug(foe.species)) ?? idx.ds.species.find((s) => slug(s.showdownName) === slug(foe.species));
    if (!sp) unknown.add(foe.species);
    const earners = ko.facedBy.filter((k) => k.startsWith(`${side}|`)).map((k) => k.split('|')[1]);
    const live = earners.map(rewardFor).filter(Boolean);
    if (!live.length) continue;
    for (const r of live) {
      const c = save.creatures[r.uid];
      r.exp += Math.max(1, Math.floor(runFormula(idx, 'expGain', {
        baseExp: sp?.baseExp ?? 64, foeLevel: foe.level, level: c.level, participants: live.length, linked: 1,
      })));
      for (const [k, v] of Object.entries(sp?.effortYield ?? {})) r.effort[k] = (r.effort[k] ?? 0) + (Number(v) || 0);
    }
  }
  for (const r of results.values()) r.friendship = (won ? 3 : 1) - (r.fainted ? 1 : 0);
  return {
    eventId: `showdown-${toId(parsed.id) || hashString(JSON.stringify(parsed.players)).toString(36)}`,
    battleId: parsed.id, won, tie: parsed.tie, opponent, linked: true, format: parsed.format,
    results: [...results.values()], unknown: [...unknown],
  };
}

/** Accepts "https://replay.pokemonshowdown.com/gen9customgame-123?p2" and returns the .json and .log URLs. */
export function replayUrls(input) {
  let u = String(input ?? '').trim();
  if (!/^https?:\/\//i.test(u)) return null;
  u = u.replace(/[?#].*$/, '').replace(/\/+$/, '').replace(/\.(json|log|html)$/i, '');
  const id = u.split('/').pop();
  return { id: `battle-${id.replace(/^battle-/, '')}`, json: `${u}.json`, log: `${u}.log` };
}

// ---------------------------------------------------------------- bridge script

/**
 * JavaScript the apps inject into their embedded Showdown page before it loads. It watches
 * Showdown's own connection (it never changes what the page shows) and:
 *  - reports your logged-in name,
 *  - for a matched battle: sends `/utm <your team>` then `/challenge` or, once their challenge
 *    arrives, `/accept`,
 *  - when a battle you are in ends, hands its log to the app through window.CapsuleBridge.post().
 * config: { action: 'challenge'|'accept'|null, opponent, format, packed }
 */
export function bridgeScript(config = {}) {
  const cfg = JSON.stringify(config).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  return `(function () {
  if (window.__capsuleLink) { var O = window.__capsuleLink; O.cfg = ${cfg}; O.acted = false; if (O.run) O.run(); if (O.overlay) O.overlay(); return; }
  var S = window.__capsuleLink = { cfg: ${cfg}, user: null, named: false, rooms: {}, done: {}, acted: false, sock: null, sockjs: false };
  function post(o) { try { if (window.CapsuleBridge) window.CapsuleBridge.post(JSON.stringify(o)); } catch (e) {} }
  function toId(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, ''); }
  function send(text) {
    if (!S.sock || S.sock.readyState !== 1) return false;
    S.sock.send(S.sockjs ? JSON.stringify([text]) : text);
    return true;
  }
  S.run = function () {
    var c = S.cfg;
    if (!c || !c.action || S.acted || !S.named) return;
    if (c.action === 'challenge') {
      S.acted = send('|/utm ' + (c.packed || '')) && send('|/challenge ' + c.opponent + ', ' + (c.format || 'gen9customgame'));
      if (S.acted) { post({ type: 'status', text: 'Challenged ' + c.opponent + '.' }); setStatus('Challenged ' + c.opponent + '. Waiting for them to accept.'); }
    } else if (c.action === 'accept' && S.challengers && S.challengers[toId(c.opponent)]) {
      S.acted = send('|/utm ' + (c.packed || '')) && send('|/accept ' + c.opponent);
      if (S.acted) { post({ type: 'status', text: 'Accepted ' + c.opponent + "'s challenge." }); setStatus('Accepted ' + c.opponent + "'s challenge."); }
    }
  };
  // a small Capsule Link panel inside the Showdown page: accept or send challenges with your team
  S.open = false; S.status = '';
  function el(tag, css, text) { var e = document.createElement(tag); if (css) e.style.cssText = css; if (text != null) e.textContent = text; return e; }
  var BTN = 'font:inherit;background:#ffc93c;color:#1b1838;border:2px solid #1b1838;border-radius:3px;padding:2px 8px;cursor:pointer;margin-left:6px';
  function setStatus(t) { S.status = t; overlay(); }
  function accept(id) {
    if (send('|/utm ' + (S.cfg.packed || '')) && send('|/accept ' + id)) { S.acted = true; setStatus('Accepted ' + id + ' with your Capsule team.'); }
  }
  function challenge(name) {
    if (!name) return;
    if (send('|/utm ' + (S.cfg.packed || '')) && send('|/challenge ' + name + ', ' + (S.cfg.format || 'gen9customgame'))) { S.acted = true; setStatus('Challenged ' + name + '. Waiting for them to accept.'); }
  }
  function overlay() {
    if (!S.cfg || !S.cfg.packed || !document.body) return;
    var box = document.getElementById('capsule-link-box');
    if (!box) {
      box = el('div', 'position:fixed;left:8px;bottom:8px;z-index:2147483647;background:#e9f1ff;color:#1b1838;border:2px solid #1b1838;border-radius:4px;font:13px/1.45 system-ui,sans-serif;padding:6px 8px;max-width:280px;box-shadow:0 3px 0 #3a2a8a');
      box.id = 'capsule-link-box';
      document.body.appendChild(box);
    }
    while (box.firstChild) box.removeChild(box.firstChild);
    var ids = Object.keys(S.challengers || {});
    var head = el('div', 'display:flex;align-items:center;gap:6px;cursor:pointer;font-weight:600', (S.open || ids.length ? '\u25BE ' : '\u25B8 ') + 'Capsule team' + (ids.length ? ' \u2022 ' + ids.length + ' challenge' : ''));
    head.onclick = function () { S.open = !S.open; overlay(); };
    box.appendChild(head);
    if (!S.open && !ids.length && !S.status) return;
    if (S.status) box.appendChild(el('div', 'margin-top:4px', S.status));
    for (var i = 0; i < ids.length; i++) {
      (function (id) {
        var row = el('div', 'margin-top:6px', id + ' challenged you');
        var b = el('button', BTN, 'Accept with my team');
        b.onclick = function () { accept(id); };
        row.appendChild(b);
        box.appendChild(row);
      })(ids[i]);
    }
    if (S.open) {
      var row2 = el('div', 'margin-top:6px;display:flex;align-items:center');
      var input = el('input', 'font:inherit;width:120px;border:2px solid #1b1838;border-radius:3px;padding:2px 4px');
      input.placeholder = 'Showdown name';
      var b2 = el('button', BTN, 'Challenge');
      b2.onclick = function () { challenge(input.value.trim()); };
      row2.appendChild(input); row2.appendChild(b2);
      box.appendChild(row2);
      box.appendChild(el('div', 'margin-top:4px;opacity:.75;font-size:12px', 'Use these buttons so your Capsule Link creatures battle and the result comes back to the app.'));
    }
  }
  S.overlay = overlay;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', overlay); else overlay();
  function block(text) {
    var lines = text.split('\\n');
    var room = '';
    if (lines[0] && lines[0].charAt(0) === '>') room = lines.shift().slice(1).trim();
    if (room.indexOf('battle-') === 0) {
      var r = S.rooms[room] || (S.rooms[room] = []);
      for (var i = 0; i < lines.length; i++) {
        var l = lines[i];
        if (l === '|init|battle') { S.rooms[room] = r = []; S.status = ''; S.open = false; overlay(); continue; }
        if (!l || l.charAt(0) !== '|') continue;
        if (l.indexOf('|request|') === 0 || l.indexOf('|c|') === 0 || l.indexOf('|c:|') === 0) continue;
        r.push(l);
        if ((l.indexOf('|win|') === 0 || l === '|tie') && !S.done[room]) {
          S.done[room] = true;
          post({ type: 'battle', room: room, user: S.user, log: r.join('\\n') });
        }
      }
      return;
    }
    for (var j = 0; j < lines.length; j++) {
      var line = lines[j];
      if (line.indexOf('|updateuser|') === 0) {
        var p = line.split('|');
        var name = String(p[2] || '').trim().replace(/^[+%@&#~*$^\\u2605\\u2606]/, '');
        S.user = name; S.named = p[3] === '1';
        post({ type: 'user', name: name, named: S.named });
        S.run();
      } else if (line.indexOf('|updatechallenges|') === 0) {
        try { S.challengers = JSON.parse(line.slice(18)).challengesFrom || {}; } catch (e) { S.challengers = {}; }
        S.run();
        overlay();
      } else if (line.indexOf('|popup|') === 0 && S.acted) {
        var msg = line.slice(7).replace(/\\|\\|/g, '\\n');
        post({ type: 'popup', text: msg });
        setStatus(msg);
      }
    }
  }
  function receive(data) {
    if (typeof data !== 'string' || !data) return;
    var c0 = data.charAt(0);
    if (S.sockjs || c0 === 'o' || c0 === 'h' || (c0 === 'a' && data.charAt(1) === '[') || (c0 === 'c' && data.charAt(1) === '[')) {
      if (c0 === 'a') { S.sockjs = true; try { var arr = JSON.parse(data.slice(1)); for (var i = 0; i < arr.length; i++) block(String(arr[i])); } catch (e) {} }
      else if (c0 === 'o' || c0 === 'h') S.sockjs = true;
      return;
    }
    block(data);
  }
  var Native = window.WebSocket;
  if (!Native) return;
  function Tapped(url, protocols) {
    var ws = protocols === undefined ? new Native(url) : new Native(url, protocols);
    if (/\\/showdown\\//.test(String(url))) {
      S.sock = ws;
      S.sockjs = /\\/showdown\\/\\d+\\/[^/]+\\/websocket/.test(String(url));
      ws.addEventListener('message', function (e) { receive(e.data); });
      ws.addEventListener('open', function () { post({ type: 'connected' }); });
    }
    return ws;
  }
  Tapped.prototype = Native.prototype;
  Tapped.CONNECTING = 0; Tapped.OPEN = 1; Tapped.CLOSING = 2; Tapped.CLOSED = 3;
  window.WebSocket = Tapped;
  post({ type: 'loaded' });
})();`;
}
