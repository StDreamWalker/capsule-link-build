// Questions that want a real answer from each of them — "who are you friends with?", "what does everyone want to
// do?", "how is everyone?", "what's your favourite food?", "who's hungry?" — answered from what the game actually
// knows about each one (their friendships, wants, needs, tastes), not guessed at. Shown as a card of answers, the
// same way "Who wants to …?" shows who'd like to.
//
//   questionOf(text)                                   → { id, label } or null when it isn't one of these
//   answersTo(idx, save, uids, q, { t, doing })         → [{ uid, text, pic, inv? }] (inv: something to do, offered)
import { friendsOf } from './bonds.js';
import { isAsleep, mood, tickNeeds } from './care.js';
import { displayName } from './creature.js';
import { INVITES, tasteFor, volunteers } from './invite.js';
import { topPrefs, prefLabel, dislikes } from './memory.js';

const WHO = String.raw`(?:you|u|ya|everyone|everybody|y'?all|you (?:all|guys|lot)|any ?one|any ?body|each of you|the (?:others|gang|team))`;
const Q = [
  { id: 'friends', label: 'Who are you friends with?', re: new RegExp(String.raw`(who(?:'?s| is| are|m| do)?|which (?:one|of)).{0,40}\b(friends?|pals?|buddy|buddies|besties?|get(?:s)? along|close (?:to|with)|hang (?:out )?with|like (?:the )?(?:most|best))|\b(?:your|ur|everyone'?s) (?:best )?(?:friends?|pals?|buddy)\b.{0,20}\?|do (?:you|any ?one) have (?:a |any )?(?:best )?friends?`) },
  { id: 'want', label: 'What do you want to do?', re: new RegExp(String.raw`what (?:do|does|would|d|should|shall|can|could) (?:${WHO} )?(?:want|wanna|like|feel like|fancy|love)(?: to)?(?: do)?|what (?:should|shall|can) we do|what(?:'?s| is) (?:every(?:one|body) |y'?all )?(?:up for|in the mood for)|anything (?:you(?:'?d)?|${WHO}) (?:want|like|wanna) to do|what(?:'?d| would) you like(?: to do)?|what do you feel like doing`) },
  { id: 'doing', label: 'What are you up to?', re: new RegExp(String.raw`what (?:are|r|is|'re) (?:${WHO} )?(?:doing|up to)|what(?:'?re| are) (?:${WHO} )?up to|wh?at(?:'?s| is) (?:every(?:one|body) )?(?:doing|up to)`) },
  { id: 'feel', label: 'How is everyone?', re: new RegExp(String.raw`how (?:are|r|is|'s|'re) (?:${WHO})(?: (?:doing|feeling|today|getting on))?|how (?:do|does) (?:${WHO}) feel|how(?:'?s| is) (?:every(?:one|body)|it going|life)|(?:are|is) (?:${WHO}) (?:ok|okay|alright|all right|good|happy|well|feeling (?:ok|good|better))|you (?:ok|okay|alright)\?|how(?:'?re| are) (?:${WHO})`) },
  { id: 'favorite', label: 'What’s your favourite?', re: /favou?rites?|fav\b|(?:like|love|enjoy) (?:the )?(?:most|best)|best (?:food|toy|berr|game|thing)/ },
  { id: 'dislike', label: 'What don’t you like?', re: /(?:what|anything) (?:do|does) (?:you|everyone|anyone) (?:not like|dislike|hate|can'?t stand)|least favou?rite|what don'?t you like/ },
  { id: 'hungry', label: 'Who’s hungry?', re: new RegExp(String.raw`(?:who(?:'?s| is)|is (?:${WHO})|are (?:${WHO})|${WHO}) (?:hungry|starving|peckish|famished)|(?:hungry|starving) (?:any ?one|any ?body)\?`) },
  { id: 'tired', label: 'Who’s tired?', re: new RegExp(String.raw`(?:who(?:'?s| is)|is (?:${WHO})|are (?:${WHO})|${WHO}) (?:tired|sleepy|exhausted|worn out|wiped)`) },
  { id: 'awake', label: 'Who’s awake?', re: new RegExp(String.raw`who(?:'?s| is) (?:still )?(?:awake|up)\b|(?:any ?one|any ?body|is (?:${WHO})|are (?:${WHO})) (?:still )?(?:awake|up)\?`) },
  { id: 'strong', label: 'Who’s the strongest?', re: /who(?:'?s| is) (?:the )?(?:strongest|toughest|fastest|best (?:fighter|battler)|highest level|most powerful)|what level (?:are|is)/ },
];
// a favourite of what: the word after "favourite" picks the kind
const FAV_KIND = [[/food|berr|snack|treat|eat|meal|dish/, ['food']], [/toy|play ?thing/, ['toy']], [/game|activit|thing to do|hobb|sport/, ['act', 'activity', 'invite']], [/place|spot|weather|time|season|environment|habitat/, ['env', 'weather', 'time', 'place']], [/cloth|outfit|wear|hat/, ['clothes']], [/music|song|genre/, ['music']]];

/** Whether this is one of the questions they can really answer; which. */
export function questionOf(text) {
  const s = String(text ?? '').toLowerCase().replace(/[’‘]/g, "'").trim();
  if (!s) return null;
  // (a request dressed as a question — "who wants to …?", "can you …?" — isn't one of these)
  if (/\bwho (?:wants|would like|wanna|fancies|is up for)\b|\banyone (?:want|wanna|up for|fancy)\b/.test(s) && !/\bwhat\b/.test(s)) return null;
  const questiony = /\?\s*$/.test(s) || /^(who|what|which|how|are|is|do|does|any ?one|any ?body)\b/.test(s);
  if (!questiony) return null;
  for (const q of Q) if (q.re.test(s)) return { id: q.id, label: q.label, text: s };
  return null;
}

const names = (L) => (L.length <= 2 ? L.join(' and ') : `${L.slice(0, -1).join(', ')} and ${L[L.length - 1]}`);
// what's worth wanting right now (common things that can actually be done from the answers)
const WANTABLE = ['play', 'snack', 'nap', 'fetch', 'ball', 'tag', 'swim', 'race', 'dance', 'hug', 'pets', 'battle', 'gardening', 'fishing', 'cooking', 'scavenging', 'training', 'puzzle', 'obstacle', 'photography', 'movie', 'desktop', 'walk', 'groom', 'stargaze', 'sunbathe', 'explore', 'hideseek', 'sing', 'story'];
const INV = Object.fromEntries(INVITES.map((i) => [i.id, i]));

/** Each one's answer. doing: (uid) → what it's doing in the scene right now, for "what are you up to?". */
export function answersTo(idx, save, uids, q, { t = Date.now(), doing = null } = {}) {
  const out = [];
  for (const uid of uids) {
    const c = save.creatures?.[uid];
    if (!c || c.egg) continue;
    try { tickNeeds(idx, c, t); } catch { /* fine */ }
    const nm = displayName(idx, c), asleep = isAsleep(c, t), n = c.needs ?? {};
    // asleep: no answer, except to “who's asleep / awake”
    if (asleep && q.id !== 'awake' && q.id !== 'tired') { out.push({ uid, text: `${nm} is fast asleep (a little snore).`, pic: '💤' }); continue; }
    let text = '', pic = '💬', inv = null;
    if (q.id === 'friends') {
      const f = friendsOf(c).map((x) => save.creatures?.[x.uid]).filter(Boolean);
      const close = Object.entries(c.bonds ?? {}).filter(([u, v]) => v > 0 && save.creatures?.[u]).sort((a, b) => b[1] - a[1]).map(([u]) => save.creatures[u]);
      const you = (c.friendship ?? 0) >= 180;
      if (f.length) { text = `${nm} points over at ${names(f.slice(0, 3).map((x) => displayName(idx, x)))}${you ? ' — and at you' : ''}.`; pic = '💕'; }
      else if (close.length) { text = `${nm} doesn’t have a close friend yet, but gets on well with ${displayName(idx, close[0])}${you ? ' (and you, of course)' : ''}.`; pic = '🙂'; }
      else { text = you ? `${nm} looks right at you: you’re its best friend.` : `${nm} hasn’t made friends here yet.`; pic = you ? '💕' : '😶'; }
    } else if (q.id === 'want') {
      // whatever it'd most like to do right now (what it's like, how it feels today, how it is: hungry, tired…)
      let best = null;
      for (const id of WANTABLE) { const i = INV[id]; if (!i) continue; let r; try { r = volunteers(idx, save, [uid], i, t); } catch { continue; } const v = r.yes[0]; if (v && (!best || v.score > best.score)) best = { inv: i, score: v.score }; }
      if (best) { inv = best.inv; text = `${nm} wants to ${best.inv.label}${best.score > 0.85 ? ' — really badly' : ''}!`; pic = '❗'; }
      else { text = `${nm} can’t think of anything right now.`; pic = '😶'; }
    } else if (q.id === 'doing') {
      const d = doing?.(uid);
      text = d ? `${nm} is ${d}.` : `${nm} is just hanging around.`; pic = '💬';
    } else if (q.id === 'feel') {
      const m = mood(c, t);
      const why = m.id === 'hungry' ? ' Its tummy is rumbling.' : m.id === 'sleepy' ? ' It can barely keep its eyes open.' : m.id === 'grubby' ? ' It could do with a brush.' : m.id === 'bored' ? ' It wants something to do.' : m.id === 'upset' ? ' It turns its back on you.' : '';
      text = `${nm} is ${m.label.toLowerCase()}.${why}`; pic = { happy: '😊', content: '🙂', hungry: '🍓', sleepy: '😪', grubby: '🫧', bored: '😐', upset: '😠' }[m.id] ?? '🙂';
    } else if (q.id === 'favorite' || q.id === 'dislike') {
      const kinds = FAV_KIND.find(([re]) => re.test(q.text ?? ''))?.[1] ?? null;
      const pool = (q.id === 'favorite' ? topPrefs(c, idx, 30) : dislikes(c, idx, 30)).filter((p) => !kinds || kinds.includes(String(p.key).split(':')[0]));
      if (pool.length) { text = q.id === 'favorite' ? `${nm}’s favourite: ${pool[0].label}${pool[1] ? ` (then ${pool[1].label})` : ''}.` : `${nm} doesn’t like ${pool[0].label}.`; pic = q.id === 'favorite' ? '💕' : '😖'; }
      else if (q.id === 'favorite' && (!kinds || kinds.includes('invite'))) {
        // nothing it's learned to love yet: what it's always been drawn to
        const top = WANTABLE.map((id) => [id, tasteFor(idx, c, id)]).sort((a, b) => b[1] - a[1])[0];
        text = top ? `${nm} has always loved to ${INV[top[0]]?.label ?? top[0]}.` : `${nm} hasn’t picked a favourite yet.`; pic = '💕'; inv = top ? INV[top[0]] : null;
      } else { text = q.id === 'favorite' ? `${nm} hasn’t picked a favourite yet.` : `${nm} can’t think of anything it dislikes.`; pic = '😶'; }
    } else if (q.id === 'hungry') {
      const f = n.fullness ?? 60;
      text = f < 30 ? `${nm} is starving!` : f < 55 ? `${nm} could eat.` : f > 90 ? `${nm} is stuffed.` : `${nm} isn’t hungry.`; pic = f < 55 ? '🍓' : '🙂'; if (f < 55) inv = INV.snack;
    } else if (q.id === 'tired') {
      const e = n.energy ?? 60;
      text = asleep ? `${nm} is already asleep.` : e < 25 ? `${nm} is worn out.` : e < 50 ? `${nm} is getting sleepy.` : `${nm} is full of energy!`; pic = asleep ? '💤' : e < 50 ? '😪' : '⚡'; if (!asleep && e < 35) inv = INV.nap;
    } else if (q.id === 'awake') {
      text = asleep ? `${nm} is asleep.` : `${nm} is awake!`; pic = asleep ? '💤' : '🙋';
    } else if (q.id === 'strong') {
      text = `${nm}: level ${c.level ?? 1}.`; pic = '💪';
    }
    out.push({ uid, text, pic, inv, level: c.level ?? 1 });
  }
  if (q.id === 'strong') out.sort((a, b) => (b.level ?? 0) - (a.level ?? 0));
  if (q.id === 'awake') out.sort((a, b) => (a.pic === '💤') - (b.pic === '💤'));
  return out;
}
export { prefLabel };
