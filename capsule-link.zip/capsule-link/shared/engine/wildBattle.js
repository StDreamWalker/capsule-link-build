// Wild battles, right in the app (Battle Link → Battle a wild creature): your party against one wild
// creature, turn by turn. Damage follows the games' formula (level, power, Attack against Defence, same-type
// bonus, type matchups, a little luck, critical hits); moves can burn, poison, paralyse, put to sleep or
// freeze, raise and lower stats, heal, drain and hit more than once. Held items count: a type incense
// (or a booster like Charcoal) makes that type's moves 1.2× as strong.
// Afterwards the winners share the experience and effort the foe gives (a power item adds 8 to its stat),
// and the damage and used-up PP stay: they heal on their own over a while (care.js → healTick), quicker
// with potions, ethers and berries (useMedicine).
import { createRng } from './rng.js';
import { createCreature, speciesOf, calcStats, displayName, gainExp, addMemory, touch } from './creature.js';
import { typeMultiplier, runFormula } from './dataset.js';
import { STAT_KEYS } from './defaults.js';
import { itemInfo, incenseType, TYPE_BOOSTER, powerItemOf, MEDICINE } from './shop.js';
import { encounterTable } from './walkLife.js';
import { habitatsOf } from './habitats.js';

const STAGE = (s) => (s >= 0 ? (2 + s) / 2 : 2 / (2 - s));
const ACC_STAGE = (s) => (s >= 0 ? (3 + s) / 3 : 3 / (3 - s));
export const STATUS_NAME = { brn: 'burned', psn: 'poisoned', par: 'paralysed', slp: 'asleep', frz: 'frozen' };

/** How hurt they are, and whether they can battle: { hp, max, pp: [left, max], fainted } */
export function condition(idx, c) {
  const max = calcStats(idx, c).hp;
  const hp = c.hp == null ? max : Math.max(0, Math.min(max, c.hp));
  return { hp, max, fainted: hp <= 0, moves: (c.moves ?? []).map((m) => ({ id: m.id, pp: m.pp ?? idx.moves.get(m.id)?.pp ?? 10, max: idx.moves.get(m.id)?.pp ?? m.pp ?? 10 })) };
}
/** Party members that can fight right now. */
export function readyParty(idx, save) {
  return Object.values(save.creatures).filter((c) => c.location?.kind === 'party' && !c.egg).sort((a, b) => (a.location.slot ?? 0) - (b.location.slot ?? 0)).filter((c) => condition(idx, c).hp > 0);
}

/** A wild creature to battle, from a place (biome) and around the party's level. */
export function rollWild(idx, save, { biome = null, seed = Date.now() } = {}) {
  const rng = createRng(seed);
  const party = readyParty(idx, save);
  const avg = party.length ? party.reduce((a, c) => a + c.level, 0) / party.length : 5;
  let pool = idx.ds.species.filter((s) => !s.battleOnly && !s.legendary && !s.mythical);
  if (biome) { const here = pool.filter((s) => habitatsOf(idx, s).includes(biome)); if (here.length) pool = here; }
  else { const t = encounterTable(idx, {}); if (t.length) pool = t.map((r) => idx.species.get(r.id)).filter(Boolean); }
  const sp = pool[Math.floor(rng() * pool.length)] ?? idx.ds.species[0];
  const level = Math.max(2, Math.min(idx.ds.rules.maxLevel ?? 100, Math.round(avg + (rng() * 5 - 3))));
  return { speciesId: sp.id, level, seed: Math.floor(rng() * 2 ** 31), biome };
}

function fighter(idx, c, wild = false) {
  const st = calcStats(idx, c);
  const sp = speciesOf(idx, c);
  return {
    uid: c.uid, wild, name: displayName(idx, c), speciesId: c.formId || c.speciesId, level: c.level, types: sp?.types ?? [], stats: st,
    hp: c.hp == null ? st.hp : Math.max(0, Math.min(st.hp, c.hp)), max: st.hp, status: c.status ?? null, sleep: 0,
    boosts: { atk: 0, def: 0, spa: 0, spd: 0, spe: 0, acc: 0, eva: 0 },
    moves: (c.moves ?? []).map((m) => ({ id: m.id, pp: m.pp ?? idx.moves.get(m.id)?.pp ?? 10 })).filter((m) => idx.moves.get(m.id)),
    heldItemId: c.heldItemId ?? null, heldItem: c.heldItem ?? '', shiny: !!c.shiny, c,
  };
}

/** Start a battle: { foe, side: [fighters], active, turn, log, over, won, seen: Set(uid) } */
export function startWild(idx, save, wild) {
  const foeC = createCreature(idx, wild.speciesId, { level: wild.level, seed: wild.seed, location: { kind: 'wild' } });
  const party = readyParty(idx, save);
  if (!party.length) return { ok: false, reason: 'Nobody in your party can battle right now (they need to heal first, or add someone to the party).' };
  const b = { ok: true, foe: fighter(idx, foeC, true), side: party.map((c) => fighter(idx, c)), active: 0, turn: 0, log: [], over: false, won: null, seen: new Set([party[0].uid]), rng: createRng(wild.seed ^ 0x5eed), wild, events: [] };
  b.log.push(`A wild ${b.foe.name} (Lv. ${b.foe.level}) appeared!`);
  b.log.push(`Go, ${b.side[0].name}!`);
  return b;
}

const heldBoost = (idx, f, type) => {
  const it = f.heldItemId ? itemInfo(idx, f.heldItemId) : null;
  const t = incenseType(idx, it);
  if (t && t === type) return 1.2;
  const tn = String(idx.types?.get?.(type)?.name ?? type ?? '').toLowerCase();
  const booster = TYPE_BOOSTER[tn];
  if (booster && (it?.name === booster || f.heldItem === booster)) return 1.2;
  return 1;
};

/** The damage a move would do (before luck). */
export function damageOf(idx, att, def, mv, rng = Math.random, { crit = false, roll = true } = {}) {
  const power = Number(mv.power) || 0;
  if (!power || mv.category === 'status') return 0;
  const phys = mv.category !== 'special';
  let A = phys ? att.stats.atk : att.stats.spa, D = phys ? def.stats.def : def.stats.spd;
  A *= STAGE(crit ? Math.max(0, att.boosts[phys ? 'atk' : 'spa']) : att.boosts[phys ? 'atk' : 'spa']);
  D *= STAGE(crit ? Math.min(0, def.boosts[phys ? 'def' : 'spd']) : def.boosts[phys ? 'def' : 'spd']);
  if (phys && att.status === 'brn') A *= 0.5;
  let d = Math.floor(Math.floor(Math.floor((2 * att.level) / 5 + 2) * power * (A / Math.max(1, D))) / 50) + 2;
  if (crit) d = Math.floor(d * 1.5);
  if (roll) d = Math.floor(d * (0.85 + rng() * 0.15));
  if (att.types.includes(mv.type)) d = Math.floor(d * 1.5);
  d = Math.floor(d * typeMultiplier(idx, mv.type, def.types));
  d = Math.floor(d * heldBoost(idx, att, mv.type));
  return Math.max(typeMultiplier(idx, mv.type, def.types) === 0 ? 0 : 1, d);
}

const speedOf = (f) => f.stats.spe * STAGE(f.boosts.spe) * (f.status === 'par' ? 0.5 : 1);

/** The wild one's choice: mostly its strongest move, sometimes something else. */
function foeMove(idx, b) {
  const me = b.side[b.active];
  const opts = b.foe.moves.filter((m) => m.pp > 0);
  if (!opts.length) return null;
  const scored = opts.map((m) => { const mv = idx.moves.get(m.id); return { m, s: (mv.power ? damageOf(idx, b.foe, me, mv, () => 0.9, { roll: false }) : 8) + b.rng() * 10 }; });
  scored.sort((x, y) => y.s - x.s);
  return b.rng() < 0.7 ? scored[0].m : scored[Math.floor(b.rng() * scored.length)].m;
}

/** Use a move: logs what happened, returns [{ kind: 'move'|'hit'|'faint'…, … }] for the animations. */
function act(idx, b, user, target, slot) {
  const out = [];
  const mv = idx.moves.get(slot.id);
  if (user.status === 'slp') { if (user.sleep-- > 0) { b.log.push(`${user.name} is fast asleep.`); return out; } user.status = null; b.log.push(`${user.name} woke up!`); }
  if (user.status === 'frz') { if (b.rng() < 0.2) { user.status = null; b.log.push(`${user.name} thawed out!`); } else { b.log.push(`${user.name} is frozen solid!`); return out; } }
  if (user.status === 'par' && b.rng() < 0.25) { b.log.push(`${user.name} is paralysed! It can’t move!`); return out; }
  if (user.flinch) { user.flinch = false; b.log.push(`${user.name} flinched!`); return out; }
  slot.pp = Math.max(0, slot.pp - 1);
  b.log.push(`${user.name} used ${mv.name}!`);
  out.push({ kind: 'move', user: user.uid, target: target.uid, move: mv.id });
  const e = mv.effect ?? {};
  const acc = mv.accuracy == null || mv.accuracy === true ? null : Number(mv.accuracy);
  if (acc && b.rng() * 100 >= acc * ACC_STAGE(user.boosts.acc - target.boosts.eva)) { b.log.push(`${target.name} avoided it!`); out.push({ kind: 'miss' }); return out; }
  const selfTarget = e.target === 'self';
  if (mv.category === 'status' || !(Number(mv.power) > 0)) {
    if (e.heal) { const h = Math.floor(user.max * e.heal); user.hp = Math.min(user.max, user.hp + h); b.log.push(`${user.name} recovered health.`); out.push({ kind: 'heal', uid: user.uid }); }
    if (e.boost) boost(b, selfTarget ? user : target, e.boost);
    if (e.status && !selfTarget) inflict(b, target, e.status, 100);
    if (!e.heal && !e.boost && !e.status) b.log.push('But nothing much happened.');
    return out;
  }
  const hits = Array.isArray(e.hits) ? e.hits[0] + Math.floor(b.rng() * (e.hits[1] - e.hits[0] + 1)) : 1;
  let total = 0;
  for (let i = 0; i < hits && target.hp > 0; i++) {
    const crit = b.rng() < (e.critStage ? 1 / 8 : 1 / 24);
    const d = Math.min(target.hp, damageOf(idx, user, target, mv, b.rng, { crit }));
    target.hp -= d; total += d;
    out.push({ kind: 'hit', uid: target.uid, amount: d, crit });
    if (crit) b.log.push('A critical hit!');
  }
  const m = typeMultiplier(idx, mv.type, target.types);
  if (m === 0) b.log.push(`It doesn’t affect ${target.name}…`);
  else if (m > 1) b.log.push('It’s super effective!');
  else if (m < 1) b.log.push('It’s not very effective…');
  if (hits > 1) b.log.push(`Hit ${hits} times!`);
  if (e.drain && total) { user.hp = Math.min(user.max, user.hp + Math.max(1, Math.floor(total * e.drain))); b.log.push(`${target.name} had its energy drained!`); }
  if (e.recoil && total) { user.hp = Math.max(0, user.hp - Math.max(1, Math.floor(total * e.recoil))); b.log.push(`${user.name} is hit with recoil!`); }
  if (target.hp > 0) {
    const ch = e.chance ?? 100;
    if (e.status && !selfTarget) inflict(b, target, e.status, ch);
    if (e.boost && b.rng() * 100 < ch) boost(b, selfTarget ? user : target, e.boost);
    if (e.flinch && b.rng() * 100 < e.flinch) target.flinch = true;
  }
  return out;
}
function boost(b, f, bo) {
  for (const [k, v] of Object.entries(bo)) {
    const before = f.boosts[k] ?? 0;
    f.boosts[k] = Math.max(-6, Math.min(6, before + v));
    const name = { atk: 'Attack', def: 'Defence', spa: 'Sp. Atk', spd: 'Sp. Def', spe: 'Speed', acc: 'accuracy', eva: 'evasiveness' }[k] ?? k;
    b.log.push(f.boosts[k] === before ? `${f.name}’s ${name} won’t go any ${v > 0 ? 'higher' : 'lower'}!` : `${f.name}’s ${name} ${v > 0 ? (v > 1 ? 'rose sharply' : 'rose') : v < -1 ? 'harshly fell' : 'fell'}!`);
  }
}
function inflict(b, f, st, chance) {
  if (f.status || f.hp <= 0 || b.rng() * 100 >= chance) return;
  f.status = st;
  if (st === 'slp') f.sleep = 1 + Math.floor(b.rng() * 3);
  b.log.push(`${f.name} is ${STATUS_NAME[st] ?? st}!`);
}
function endOfTurn(b, f) {
  if (f.hp <= 0) return;
  if (f.status === 'brn' || f.status === 'psn') { const d = Math.max(1, Math.floor(f.max / (f.status === 'brn' ? 16 : 8))); f.hp = Math.max(0, f.hp - d); b.log.push(`${f.name} is hurt by its ${f.status === 'brn' ? 'burn' : 'poison'}.`); }
}

/**
 * One turn. choice: { move: slotIndex } | { switchTo: index } | { run: true }.
 * Returns { steps (for animations), needSwitch, over }.
 */
export function takeTurn(idx, b, choice) {
  if (b.over) return { steps: [], over: true };
  b.turn++;
  const steps = [];
  const me = b.side[b.active];
  if (choice.run) { b.log.push('Got away safely!'); b.over = true; b.won = null; b.ran = true; return { steps, over: true }; }
  if (choice.switchTo != null && choice.switchTo !== b.active && b.side[choice.switchTo]?.hp > 0) {
    const forced = me.hp <= 0;
    if (!forced) b.log.push(`${me.name}, come back!`);
    b.active = choice.switchTo; b.seen.add(b.side[b.active].uid); b.log.push(`Go, ${b.side[b.active].name}!`);
    steps.push({ kind: 'switch', uid: b.side[b.active].uid });
    // after a faint the next one comes out for free; a switch by choice gives the foe a turn
    if (forced) return { steps };
    const fm = foeMove(idx, b);
    if (fm) steps.push(...act(idx, b, b.foe, b.side[b.active], fm));
  } else {
    const mine = me.moves[choice.move ?? 0];
    const fm = foeMove(idx, b);
    const order = !mine || mine.pp <= 0 ? [['foe', fm]] : !fm ? [['me', mine]]
      : speedOf(me) > speedOf(b.foe) || (speedOf(me) === speedOf(b.foe) && b.rng() < 0.5) ? [['me', mine], ['foe', fm]] : [['foe', fm], ['me', mine]];
    if (mine && mine.pp <= 0) b.log.push(`${me.name} has no PP left for that move!`);
    for (const [who, slot] of order) {
      const user = who === 'me' ? b.side[b.active] : b.foe, target = who === 'me' ? b.foe : b.side[b.active];
      if (user.hp <= 0 || target.hp <= 0 || !slot) continue;
      steps.push(...act(idx, b, user, target, slot));
    }
  }
  for (const f of [b.side[b.active], b.foe]) endOfTurn(b, f);
  if (b.foe.hp <= 0) { b.log.push(`The wild ${b.foe.name} fainted!`); steps.push({ kind: 'faint', uid: b.foe.uid }); b.over = true; b.won = true; return { steps, over: true }; }
  if (b.side[b.active].hp <= 0) {
    b.log.push(`${b.side[b.active].name} fainted!`); steps.push({ kind: 'faint', uid: b.side[b.active].uid });
    if (b.side.every((f) => f.hp <= 0)) { b.log.push('You’re out of creatures that can fight… you hurried away.'); b.over = true; b.won = false; return { steps, over: true }; }
    return { steps, needSwitch: true };
  }
  return { steps };
}

/**
 * What the battle left behind, to keep in the save: everyone's HP, PP and status as they ended up, and
 * (if it was won) experience and effort for those who took part. Returns the event for applyEvent('wild').
 */
export function wildResult(idx, b) {
  const foeSp = speciesOf(idx, b.foe.c);
  const taking = b.won ? b.side.filter((f) => b.seen.has(f.uid) && f.hp > 0) : [];
  return {
    won: !!b.won, ran: !!b.ran, foe: { speciesId: b.foe.c.speciesId, level: b.foe.level, name: b.foe.name },
    party: b.side.map((f) => {
      const share = taking.some((x) => x.uid === f.uid);
      const exp = share ? Math.max(1, Math.floor(runFormula(idx, 'expGain', { baseExp: foeSp?.baseExp ?? 64, foeLevel: b.foe.level, level: f.level, participants: taking.length, linked: 0 }))) : 0;
      const effort = share ? { ...(foeSp?.effortYield ?? {}) } : {};
      return { uid: f.uid, hp: f.hp, status: f.status, pp: f.moves.map((m) => ({ id: m.id, pp: m.pp })), exp, effort };
    }),
  };
}

/** Keep the battle's outcome (used by applyEvent('wild')). Returns per-creature level-up events. */
export function applyWildResult(idx, save, r, t = Date.now()) {
  const out = [];
  for (const p of r.party ?? []) {
    const c = save.creatures[p.uid];
    if (!c) continue;
    c.hp = Math.max(0, p.hp); c.status = p.status ?? null; c.healAt = t;
    for (const m of c.moves ?? []) { const q = p.pp.find((x) => x.id === m.id); if (q) m.pp = q.pp; }
    // effort: what the foe gives, plus a power item's 8
    const pw = powerItemOf(idx, c);
    const eff = { ...(p.effort ?? {}) };
    if (pw && (p.exp || Object.keys(eff).length)) eff[pw.stat] = (eff[pw.stat] ?? 0) + 8;
    c.effort = c.effort || {};
    for (const k of STAT_KEYS) {
      const add = Number(eff[k]) || 0; if (!add) continue;
      const total = STAT_KEYS.reduce((s, kk) => s + (c.effort[kk] ?? 0), 0);
      const room = Math.max(0, Math.min((idx.ds.rules.maxEffortPerStat ?? 252) - (c.effort[k] ?? 0), (idx.ds.rules.maxEffortTotal ?? 510) - total));
      c.effort[k] = (c.effort[k] ?? 0) + Math.min(add, room);
    }
    const before = calcStats(idx, c).hp;
    const events = p.exp ? gainExp(idx, c, p.exp, t) : [];
    if (c.hp > 0 && calcStats(idx, c).hp > before) c.hp += calcStats(idx, c).hp - before;
    if (r.won && p.exp && !c.firsts?.wildWin) { c.firsts = { ...(c.firsts || {}), wildWin: t }; addMemory(c, `Beat a wild ${r.foe?.name ?? 'creature'} in a battle.`, t, { core: false }); }
    if (c.needs) c.needs.energy = Math.max(10, (c.needs.energy ?? 80) - 6);
    touch(c, t);
    out.push({ uid: c.uid, exp: p.exp, effort: eff, events });
  }
  return out;
}

// ---------- healing ----------
export const HEAL_MIN = 20;  // minutes, empty to full HP
export const PP_MIN = 30;    // minutes, empty to full PP
/** Damage and used PP come back on their own over time (called from tickNeeds). */
export function healTick(idx, c, t = Date.now()) {
  const last = c.healAt ?? t;
  c.healAt = t;
  if (c.hp == null && !(c.moves ?? []).some((m) => m.pp != null && m.pp < (idx.moves.get(m.id)?.pp ?? m.pp))) return;
  const mins = Math.max(0, (t - last) / 60000);
  if (!mins) return;
  const max = calcStats(idx, c).hp;
  if (c.hp != null) {
    c._hpAcc = (c._hpAcc ?? 0) + (max * mins) / HEAL_MIN;
    const add = Math.floor(c._hpAcc); c._hpAcc -= add;
    c.hp = Math.min(max, c.hp + add);
    if (c.hp >= max) { c.hp = null; c._hpAcc = 0; }
  }
  if (c.status && mins >= 5) c.status = null;
  for (const m of c.moves ?? []) {
    const mx = idx.moves.get(m.id)?.pp ?? m.pp;
    if (m.pp == null || m.pp >= mx) continue;
    m._acc = (m._acc ?? 0) + (mx * mins) / PP_MIN;
    const add = Math.floor(m._acc); m._acc -= add;
    m.pp = Math.min(mx, m.pp + add);
    if (m.pp >= mx) delete m._acc;
  }
}

const BERRY_HEAL = { oran: { hp: 10 }, sitrus: { frac: 0.25 }, leppa: { pp: 10, one: true }, lum: { cure: true }, cheri: { cure: 'par' }, chesto: { cure: 'slp' }, pecha: { cure: 'psn' }, rawst: { cure: 'brn' }, aspear: { cure: 'frz' }, persim: {}, figy: { frac: 0.33 }, wiki: { frac: 0.33 }, mago: { frac: 0.33 }, aguav: { frac: 0.33 }, iapapa: { frac: 0.33 } };
/** What an item heals, or null: { hp, frac, pp, one, cure, revive }. */
export function healingOf(item) {
  if (!item) return null;
  const own = MEDICINE.find((m) => m.id === item.id || m.name.toLowerCase() === String(item.name ?? '').toLowerCase());
  if (own) return own;
  const b = /^(\w+)\s+berry$/i.exec(String(item.name ?? ''));
  return b && BERRY_HEAL[b[1].toLowerCase()] && Object.keys(BERRY_HEAL[b[1].toLowerCase()]).length ? BERRY_HEAL[b[1].toLowerCase()] : null;
}
/** Use a healing item on someone (moveId: for one-move PP items). { ok, reason?, text } */
export function useMedicine(idx, save, uid, itemId, moveId = null) {
  const c = save.creatures[uid];
  const item = itemInfo(idx, itemId) ?? MEDICINE.find((m) => m.id === itemId);
  const h = healingOf(item);
  if (!c || !h) return { ok: false, reason: 'That doesn’t heal anything.' };
  if ((save.inventory[itemId] ?? 0) <= 0) return { ok: false, reason: 'None left in the bag.' };
  const cond = condition(idx, c);
  const name = displayName(idx, c);
  let did = '';
  if (h.revive) { if (!cond.fainted) return { ok: false, reason: `${name} hasn’t fainted.` }; c.hp = Math.max(1, Math.floor(cond.max * h.revive)); did = `${name} is back on their feet!`; }
  else if (cond.fainted && (h.hp || h.frac)) return { ok: false, reason: `${name} has fainted: use a Revive, or let them rest.` };
  if (h.hp || h.frac) {
    if (cond.hp >= cond.max && !h.cure && !h.pp) return { ok: false, reason: `${name} is already at full health.` };
    const add = h.hp ? h.hp : Math.floor(cond.max * h.frac);
    c.hp = Math.min(cond.max, cond.hp + add); if (c.hp >= cond.max) c.hp = null;
    did = `${name} got ${Math.min(add, cond.max - cond.hp)} HP back.`;
  }
  if (h.cure) { if (c.status && (h.cure === true || h.cure === c.status)) { did += ` ${name} is cured.`; c.status = null; } else if (!did) return { ok: false, reason: `${name} is fine.` }; }
  if (h.pp) {
    const list = (c.moves ?? []).filter((m) => (h.one ? m.id === (moveId ?? [...c.moves].sort((a, b) => (a.pp ?? 99) - (b.pp ?? 99))[0]?.id) : true));
    let n = 0;
    for (const m of list) { const mx = idx.moves.get(m.id)?.pp ?? m.pp; const before = m.pp ?? mx; m.pp = Math.min(mx, before + h.pp); n += m.pp - before; }
    if (!n) return { ok: false, reason: `${name}’s moves are already full.` };
    did = `${did} ${h.one ? `${idx.moves.get(list[0].id)?.name}’s` : 'Their'} PP came back.`.trim();
  }
  save.inventory[itemId]--;
  c.healAt = Date.now();
  return { ok: true, text: did.trim() };
}
