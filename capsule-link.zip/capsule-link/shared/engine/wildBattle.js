// Wild battles (Battle Link → Battle a wild creature): your party against one wild creature, played on
// Pokémon Showdown's own simulator and battle screen running inside the PC app (shared/sdbattle). This module
// is the app's side of it: which creature turns up, the two teams as Showdown sets (hurt creatures start
// hurt, with the PP they have left), and what's kept afterwards: experience and effort for those who won
// (a power item adds 8 to its stat), and the damage and used-up PP, which heal on their own over a while
// (healTick), quicker with potions, ethers and berries (useMedicine).
import { createRng } from './rng.js';
import { createCreature, speciesOf, calcStats, displayName, gainExp, addMemory, touch } from './creature.js';
import { buildTeam, showdownSet } from './showdown.js';
import { battleSpeciesOf } from './forms.js';
import { runFormula } from './dataset.js';
import { STAT_KEYS } from './defaults.js';
import { itemInfo, powerItemOf, MEDICINE } from './shop.js';
import { encounterTable } from './walkLife.js';
import { habitatsOf } from './habitats.js';

export const STATUS_NAME = { brn: 'burned', psn: 'poisoned', par: 'paralysed', slp: 'asleep', frz: 'frozen' };

/** How hurt they are, and whether they can battle: { hp, max, pp: [left, max], fainted } */
export function condition(idx, c) {
  const max = calcStats(idx, c).hp;
  const hp = c.hp == null ? max : Math.max(0, Math.min(max, c.hp));
  return { hp, max, fainted: hp <= 0, moves: (c.moves ?? []).map((m) => ({ id: m.id, pp: m.pp ?? idx.moves.get(m.id)?.pp ?? 10, max: idx.moves.get(m.id)?.pp ?? m.pp ?? 10 })) };
}
/** Party members that can fight right now. */
export function readyParty(idx, save) {
  return Object.values(save.creatures).filter((c) => c.location?.kind === 'party' && !c.egg).sort((a, b) => (a.location.slot ?? 0) - (b.location.slot ?? 0)).filter((c) => condition(idx, c).hp > 0);
}

/** A wild creature to battle, from a place (biome) and around the party's level. */
export function rollWild(idx, save, { biome = null, seed = Date.now(), known = null } = {}) {
  const rng = createRng(seed);
  const party = readyParty(idx, save);
  const avg = party.length ? party.reduce((a, c) => a + c.level, 0) / party.length : 5;
  let pool = idx.ds.species.filter((s) => !s.battleOnly && !s.legendary && !s.mythical && (!known || known(s)));
  if (biome) { const here = pool.filter((s) => habitatsOf(idx, s).includes(biome)); if (here.length) pool = here; }
  else { const t = encounterTable(idx, {}).map((r) => idx.species.get(r.id)).filter((x) => x && (!known || known(x))); if (t.length) pool = t; }
  if (!pool.length) return null;
  const sp = pool[Math.floor(rng() * pool.length)] ?? idx.ds.species[0];
  const level = Math.max(2, Math.min(idx.ds.rules.maxLevel ?? 100, Math.round(avg + (rng() * 5 - 3))));
  return { speciesId: sp.id, level, seed: Math.floor(rng() * 2 ** 31), biome };
}

/**
 * Your party and the wild one as Showdown sets for a wild battle (sim: what Showdown knows, `knows(kind, name)`).
 * Hurt creatures start hurt (hpLeft) with the PP they have left (ppLeft). Returns { team, foe, map: { name: { uid, moves } }, left: [names left out] }.
 */
export function wildTeams(idx, save, wild, knows = () => true) {
  const shown = (sp) => sp?.showdownName || sp?.name || '';
  const party = readyParty(idx, save);
  const ok = party.filter((c) => knows('species', shown(battleSpeciesOf(idx, c) ?? speciesOf(idx, c))));
  const left = party.filter((c) => !ok.includes(c)).map((c) => displayName(idx, c));
  const { sets, map } = buildTeam(idx, ok);
  const out = {};
  const team = sets.map((set) => {
    const c = save.creatures[map[set.name]];
    const moves = (c.moves ?? []).map((m) => ({ m, mv: idx.moves.get(m.id) })).filter(({ mv }) => mv && knows('move', mv.showdownName || mv.name)).slice(0, 4);
    const cond = condition(idx, c);
    out[set.name] = { uid: c.uid, moves: moves.map(({ m }) => m.id) };
    return { ...set, item: set.item && knows('item', set.item) ? set.item : '', ability: set.ability && knows('ability', set.ability) ? set.ability : '',
      moves: moves.length ? moves.map(({ mv }) => mv.showdownName || mv.name) : ['Tackle'], hpLeft: cond.hp, ppLeft: moves.map(({ m }) => m.pp ?? idx.moves.get(m.id)?.pp ?? 10) };
  });
  const foeC = createCreature(idx, wild.speciesId, { level: wild.level, seed: wild.seed, location: { kind: 'wild' } });
  const fs = showdownSet(idx, foeC);
  const fm = fs.moves.filter((m) => knows('move', m));
  const foe = { ...fs, name: shown(speciesOf(idx, foeC)), item: '', ability: fs.ability && knows('ability', fs.ability) ? fs.ability : '', moves: fm.length ? fm : ['Tackle'] };
  return { team, foe, map: out, left, foeName: displayName(idx, foeC) };
}

/**
 * What a Showdown wild battle left behind, for applyWildResult: everyone's HP, PP and status, and (if it was
 * won) experience and effort shared by those who battled and are still standing.
 * res: { won, ran, team: { name: { hp, status, pp: [n], fainted } }, out: [names] }
 */
export function wildOutcome(idx, wild, res, map) {
  const foeSp = idx.species.get(wild.speciesId);
  const names = Object.keys(map);
  const taking = res.won ? names.filter((n) => res.out.includes(n) && !res.team[n]?.fainted) : [];
  const STATUS = { brn: 'brn', psn: 'psn', tox: 'psn', par: 'par', slp: 'slp', frz: 'frz' };
  return {
    won: !!res.won, ran: !!res.ran, foe: { speciesId: wild.speciesId, level: wild.level, name: foeSp?.name ?? 'creature' },
    party: names.map((n) => {
      const t = res.team[n] ?? {};
      const share = taking.includes(n);
      const exp = share ? Math.max(1, Math.floor(runFormula(idx, 'expGain', { baseExp: foeSp?.baseExp ?? 64, foeLevel: wild.level, level: 1, participants: taking.length, linked: 0 }))) : 0;
      return { uid: map[n].uid, hp: Math.max(0, t.hp ?? 0), status: STATUS[t.status] ?? null, pp: map[n].moves.map((id, i) => ({ id, pp: t.pp?.[i] ?? 0 })), exp, effort: share ? { ...(foeSp?.effortYield ?? {}) } : {} };
    }),
  };
}

/** Keep the battle's outcome (used by applyEvent('wild')). Returns per-creature level-up events. */
export function applyWildResult(idx, save, r, t = Date.now()) {
  const out = [];
  for (const p of r.party ?? []) {
    const c = save.creatures[p.uid];
    if (!c) continue;
    c.hp = Math.max(0, p.hp); c.status = p.status ?? null; c.healAt = t;
    for (const m of c.moves ?? []) { const q = p.pp.find((x) => x.id === m.id); if (q) m.pp = q.pp; }
    // effort: what the foe gives, plus a power item's 8
    const pw = powerItemOf(idx, c);
    const eff = { ...(p.effort ?? {}) };
    if (pw && (p.exp || Object.keys(eff).length)) eff[pw.stat] = (eff[pw.stat] ?? 0) + 8;
    c.effort = c.effort || {};
    for (const k of STAT_KEYS) {
      const add = Number(eff[k]) || 0; if (!add) continue;
      const total = STAT_KEYS.reduce((s, kk) => s + (c.effort[kk] ?? 0), 0);
      const room = Math.max(0, Math.min((idx.ds.rules.maxEffortPerStat ?? 252) - (c.effort[k] ?? 0), (idx.ds.rules.maxEffortTotal ?? 510) - total));
      c.effort[k] = (c.effort[k] ?? 0) + Math.min(add, room);
    }
    const before = calcStats(idx, c).hp;
    const events = p.exp ? gainExp(idx, c, p.exp, t) : [];
    if (c.hp > 0 && calcStats(idx, c).hp > before) c.hp += calcStats(idx, c).hp - before;
    if (r.won && p.exp && !c.firsts?.wildWin) { c.firsts = { ...(c.firsts || {}), wildWin: t }; addMemory(c, `Beat a wild ${r.foe?.name ?? 'creature'} in a battle.`, t, { core: false }); }
    if (c.needs) c.needs.energy = Math.max(10, (c.needs.energy ?? 80) - 6);
    touch(c, t);
    out.push({ uid: c.uid, exp: p.exp, effort: eff, events });
  }
  return out;
}

// ---------- healing ----------
export const HEAL_MIN = 20;  // minutes, empty to full HP
export const PP_MIN = 30;    // minutes, empty to full PP
/** Damage and used PP come back on their own over time (called from tickNeeds). */
export function healTick(idx, c, t = Date.now()) {
  const last = c.healAt ?? t;
  c.healAt = t;
  if (c.hp == null && !(c.moves ?? []).some((m) => m.pp != null && m.pp < (idx.moves.get(m.id)?.pp ?? m.pp))) return;
  const mins = Math.max(0, (t - last) / 60000);
  if (!mins) return;
  const max = calcStats(idx, c).hp;
  if (c.hp != null) {
    c._hpAcc = (c._hpAcc ?? 0) + (max * mins) / HEAL_MIN;
    const add = Math.floor(c._hpAcc); c._hpAcc -= add;
    c.hp = Math.min(max, c.hp + add);
    if (c.hp >= max) { c.hp = null; c._hpAcc = 0; }
  }
  if (c.status && mins >= 5) c.status = null;
  for (const m of c.moves ?? []) {
    const mx = idx.moves.get(m.id)?.pp ?? m.pp;
    if (m.pp == null || m.pp >= mx) continue;
    m._acc = (m._acc ?? 0) + (mx * mins) / PP_MIN;
    const add = Math.floor(m._acc); m._acc -= add;
    m.pp = Math.min(mx, m.pp + add);
    if (m.pp >= mx) delete m._acc;
  }
}

const BERRY_HEAL = { oran: { hp: 10 }, sitrus: { frac: 0.25 }, leppa: { pp: 10, one: true }, lum: { cure: true }, cheri: { cure: 'par' }, chesto: { cure: 'slp' }, pecha: { cure: 'psn' }, rawst: { cure: 'brn' }, aspear: { cure: 'frz' }, persim: {}, figy: { frac: 0.33 }, wiki: { frac: 0.33 }, mago: { frac: 0.33 }, aguav: { frac: 0.33 }, iapapa: { frac: 0.33 } };
/** What an item heals, or null: { hp, frac, pp, one, cure, revive }. */
export function healingOf(item) {
  if (!item) return null;
  const own = MEDICINE.find((m) => m.id === item.id || m.name.toLowerCase() === String(item.name ?? '').toLowerCase());
  if (own) return own;
  const b = /^(\w+)\s+berry$/i.exec(String(item.name ?? ''));
  return b && BERRY_HEAL[b[1].toLowerCase()] && Object.keys(BERRY_HEAL[b[1].toLowerCase()]).length ? BERRY_HEAL[b[1].toLowerCase()] : null;
}
/** Use a healing item on someone (moveId: for one-move PP items). { ok, reason?, text } */
export function useMedicine(idx, save, uid, itemId, moveId = null) {
  const c = save.creatures[uid];
  const item = itemInfo(idx, itemId) ?? MEDICINE.find((m) => m.id === itemId);
  const h = healingOf(item);
  if (!c || !h) return { ok: false, reason: 'That doesn’t heal anything.' };
  if ((save.inventory[itemId] ?? 0) <= 0) return { ok: false, reason: 'None left in the bag.' };
  const cond = condition(idx, c);
  const name = displayName(idx, c);
  let did = '';
  if (h.revive) { if (!cond.fainted) return { ok: false, reason: `${name} hasn’t fainted.` }; c.hp = Math.max(1, Math.floor(cond.max * h.revive)); did = `${name} is back on their feet!`; }
  else if (cond.fainted && (h.hp || h.frac)) return { ok: false, reason: `${name} has fainted: use a Revive, or let them rest.` };
  if (h.hp || h.frac) {
    if (cond.hp >= cond.max && !h.cure && !h.pp) return { ok: false, reason: `${name} is already at full health.` };
    const add = h.hp ? h.hp : Math.floor(cond.max * h.frac);
    c.hp = Math.min(cond.max, cond.hp + add); if (c.hp >= cond.max) c.hp = null;
    did = `${name} got ${Math.min(add, cond.max - cond.hp)} HP back.`;
  }
  if (h.cure) { if (c.status && (h.cure === true || h.cure === c.status)) { did += ` ${name} is cured.`; c.status = null; } else if (!did) return { ok: false, reason: `${name} is fine.` }; }
  if (h.pp) {
    const list = (c.moves ?? []).filter((m) => (h.one ? m.id === (moveId ?? [...c.moves].sort((a, b) => (a.pp ?? 99) - (b.pp ?? 99))[0]?.id) : true));
    let n = 0;
    for (const m of list) { const mx = idx.moves.get(m.id)?.pp ?? m.pp; const before = m.pp ?? mx; m.pp = Math.min(mx, before + h.pp); n += m.pp - before; }
    if (!n) return { ok: false, reason: `${name}’s moves are already full.` };
    did = `${did} ${h.one ? `${idx.moves.get(list[0].id)?.name}’s` : 'Their'} PP came back.`.trim();
  }
  save.inventory[itemId]--;
  c.healAt = Date.now();
  return { ok: true, text: did.trim() };
}
