// How a creature feels about where it is: the PokéAtlas's reading of the place (its climate, every habitat, the
// weather and the hour, whether it's water) against the creature itself (the climates and habitats its kind
// lives in, its types, its temperament, what it's seen before and how often it's been here).
//
// A creature made for the snow, carried into the snow, presses up against its ball to watch; one from the
// tropics is bewildered by its first frost (or thrilled, or wants to go home, depending on who it is); a
// sea creature on a city street is quietly unimpressed; a regular at the same park gets bored of it. Firsts
// (the sea, snow, a desert, a volcano…) become memories it keeps.
//
//   profileFromTypes(types)                → a rough profile when the atlas doesn't know the species
//   feelPlace(idx, c, table, profile, o)   → { kind, mood, line, emoji, joy, firsts, score } (o.apply: keep it)
//   FEEL_MOODS                              → how each mood reads
import { displayName, speciesOf, addMemory } from './creature.js';
import { temperStyle } from './personality.js';

const H = 3600000;
const hashOf = (s) => { let h = 2166136261; for (const ch of String(s)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0; return h; };
const pick = (seed, list) => list[hashOf(seed) % list.length];
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));

/** The features a place can have, how strongly (0..1) it has them, and how they read. */
const FEATURES = {
  sea: { name: 'the sea', from: (t) => Math.max(t.onWater === 'sea' ? 1 : 0, (t.H?.s ?? 0) * 0.9, (t.H?.b ?? 0) * 0.8), first: 'saw the sea for the first time' },
  lake: { name: 'the water', from: (t) => Math.max(t.onWater === 'lake' ? 1 : 0, (t.H?.w ?? 0) * 0.85), first: 'saw a lake for the first time' },
  snow: { name: 'the snow', from: (t) => Math.max(t.H?.i ?? 0, t.weather === 'snow' ? 0.9 : 0, Number.isFinite(t.temp) && t.temp <= -3 ? 0.6 : 0), first: 'saw snow for the first time' },
  desert: { name: 'the desert', from: (t) => t.H?.d ?? 0, first: 'saw a desert for the first time' },
  forest: { name: 'the trees', from: (t) => t.H?.f ?? 0, first: 'walked through a real forest for the first time' },
  mountains: { name: 'the mountains', from: (t) => Math.max(t.H?.m ?? 0, (t.elev ?? 0) > 1800 ? 0.8 : 0), first: 'saw the mountains up close for the first time' },
  volcano: { name: 'the volcano', from: (t) => t.H?.v ?? 0, first: 'felt the heat of a volcano for the first time' },
  city: { name: 'the city', from: (t) => t.H?.u ?? 0, first: 'saw a big city for the first time' },
  park: { name: 'the parks and gardens', from: (t) => (t.H?.h ?? 0) * 0.9, first: null },
  marsh: { name: 'the marsh', from: (t) => t.H?.p ?? 0, first: 'waded through its first marsh' },
  caves: { name: 'the caves', from: (t) => t.H?.c ?? 0, first: 'saw a cave for the first time' },
  ruins: { name: 'the old stones and graves', from: (t) => t.H?.y ?? 0, first: 'visited ancient ruins for the first time' },
  power: { name: 'the humming power lines', from: (t) => t.H?.e ?? 0, first: null },
  industry: { name: 'the factories', from: (t) => t.H?.t ?? 0, first: null },
  fields: { name: 'the open fields', from: (t) => t.H?.g ?? 0, first: null },
};
// which types are drawn to which features (and put off by which)
const DRAWN = {
  water: ['sea', 'lake', 'marsh'], ice: ['snow', 'mountains'], fire: ['volcano', 'desert'], grass: ['forest', 'fields', 'park', 'marsh'], bug: ['forest', 'fields', 'park'],
  electric: ['power', 'city', 'industry'], ghost: ['ruins', 'caves'], dark: ['city', 'ruins', 'caves'], rock: ['mountains', 'caves', 'desert'], ground: ['desert', 'caves', 'mountains'],
  poison: ['industry', 'marsh'], flying: ['mountains', 'sea', 'fields'], dragon: ['mountains', 'caves', 'sea'], steel: ['industry', 'city', 'mountains'], psychic: ['ruins'], fairy: ['forest', 'park'],
  normal: ['park', 'fields', 'city'], fighting: ['mountains', 'city'],
};
const PUT_OFF = { fire: ['sea', 'lake', 'snow', 'marsh'], ice: ['desert', 'volcano'], grass: ['desert', 'industry', 'snow'], bug: ['snow', 'industry'], water: ['desert', 'volcano'], ghost: [], electric: ['sea'], rock: ['sea', 'marsh'], ground: ['sea', 'lake', 'marsh'], fairy: ['industry'], steel: ['sea'] };
const HAB_OF = { g: 'fields', f: 'forest', w: 'lake', s: 'sea', b: 'sea', c: 'caves', m: 'mountains', r: 'mountains', d: 'desert', v: 'volcano', u: 'city', h: 'park', p: 'marsh', i: 'snow', e: 'power', t: 'industry', y: 'ruins' };
const CLIM_NAME = { T: 'the tropics', A: 'dry heat', M: 'mild weather', C: 'the cold', P: 'frozen lands' };

/** A rough profile from types alone (for data sets the atlas doesn't cover). */
export function profileFromTypes(types = []) {
  const t = types.map((x) => String(x).toLowerCase());
  const has = (k) => t.includes(k);
  let clim = 'M', hab = 'gh';
  if (has('ice')) { clim = 'CP'; hab = 'im'; } else if (has('fire')) { clim = 'TA'; hab = 'vdr'; } else if (has('water')) { clim = 'TM'; hab = 'wsb'; }
  else if (has('grass') || has('bug')) { clim = 'TM'; hab = 'fgh'; } else if (has('ground') || has('rock')) { clim = 'AM'; hab = 'rdmc'; } else if (has('ghost')) { clim = '*'; hab = 'yc'; }
  else if (has('electric')) { clim = '*'; hab = 'eu'; } else if (has('steel')) { clim = '*'; hab = 'mtu'; } else if (has('poison')) { clim = 'TM'; hab = 'tp'; } else if (has('flying')) { clim = '*'; hab = 'gmf'; }
  else if (has('dragon')) { clim = '*'; hab = 'mc'; }
  return { clim, hab, types: t, nocturnal: has('ghost') || has('dark'), diurnal: false, guessed: true };
}

export const FEEL_MOODS = {
  home: { label: 'Right at home', emoji: '🏡' }, love: { label: 'Loves it here', emoji: '😍' }, like: { label: 'Likes it here', emoji: '🙂' },
  wonder: { label: 'Amazed', emoji: '🤩' }, curious: { label: 'Curious', emoji: '👀' }, bewildered: { label: 'Bewildered', emoji: '😵‍💫' },
  uneasy: { label: 'Uneasy', emoji: '😟' }, hot: { label: 'Too hot', emoji: '🥵' }, cold: { label: 'Too cold', emoji: '🥶' }, homesick: { label: 'Homesick', emoji: '🥺' },
  bored: { label: 'Bored', emoji: '😑' }, meh: { label: 'Unimpressed', emoji: '😐' }, sleepy: { label: 'Sleepy', emoji: '😪' }, lively: { label: 'Wide awake', emoji: '🌙' },
  splash: { label: 'Loves this weather', emoji: '🌧️' }, sulky: { label: 'Hates this weather', emoji: '☔' }, nostalgic: { label: 'Remembers this place', emoji: '💭' },
};

/**
 * How it feels about the place in the table. profile: { clim, hab, types, nocturnal, diurnal } (from the
 * atlas, or profileFromTypes). o: { mode: 'ball' | 'out' | 'camera', apply, t, trainer }.
 * With apply, it's kept: what it has seen (and how often it's been here), a memory of any first, its joy.
 */
export function feelPlace(idx, c, table, profile, o = {}) {
  if (!c || c.egg || !table) return null;
  const t = o.t ?? Date.now(), mode = o.mode ?? 'ball';
  const nm = displayName(idx, c), sp = speciesOf(idx, c);
  const pr = profile ?? profileFromTypes(sp?.types ?? []);
  const types = pr.types?.length ? pr.types : (sp?.types ?? []).map((x) => String(x).toLowerCase());
  const style = (() => { try { return temperStyle(idx, c); } catch { return 'calm'; } })();
  const seen = c.felt ?? {}; // (its own record of places; c.seen is the walks' firsts, which count too)
  const LEGACY = { sea: 'water', lake: 'water', snow: 'snow', desert: 'desert', forest: 'forest', city: 'urban', mountains: 'mountain', caves: 'cave' };
  const walkSeen = c.seen ?? {};
  const label = table.label || 'here';
  const placeKey = `place:${String(label).toLowerCase()}`;
  const visits = seen[placeKey] ?? 0;
  const seed = `${c.uid}:${table.at}:${mode}`;
  const C = table.C ?? {}, Hs = table.H ?? Object.fromEntries(table.hab ?? []);
  // how well the place suits its kind: climate and habitat
  const clim = String(pr.clim ?? '*');
  const climFit = clim.includes('*') ? 0.55 + 0.45 * Math.max(C.M ?? 0, C.T ?? 0, (C.A ?? 0) * 0.8, (C.C ?? 0) * 0.8) - 0.6 * (C.P ?? 0) : clamp([...clim].reduce((a, k) => a + (C[k] ?? 0), 0), 0, 1);
  const habFit = clamp(Math.max(0, ...[...String(pr.hab ?? '')].map((k) => Hs[k] ?? 0)), 0, 1);
  const home = 0.55 * clamp(climFit, 0, 1) + 0.45 * habFit;
  const domClim = Object.entries(C).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'M';
  const coldKind = /^[CP]+$/.test(clim), hotKind = /^[TA]+$/.test(clim);
  const temp = Number.isFinite(table.temp) ? table.temp : null;
  // the place's strongest features, and the ones it's never seen
  const feats = Object.entries(FEATURES).map(([k, f]) => [k, clamp(f.from(table), 0, 1)]).filter(([, v]) => v >= 0.35).sort((a, b) => b[1] - a[1]);
  const top = feats.slice(0, 3).map(([k]) => k);
  const firsts = feats.filter(([k, v]) => v >= 0.45 && FEATURES[k].first && !seen[`f:${k}`] && !(LEGACY[k] && walkSeen[LEGACY[k]])).map(([k]) => k);
  const newClimate = !seen[`clim:${domClim}`] && (C[domClim] ?? 0) >= 0.6;
  const drawn = types.flatMap((x) => DRAWN[x] ?? []), putOff = types.flatMap((x) => PUT_OFF[x] ?? []);
  const likesHere = top.filter((k) => drawn.includes(k) || [...String(pr.hab ?? '')].some((h) => HAB_OF[h] === k));
  const dislikesHere = top.filter((k) => putOff.includes(k));
  const fav = likesHere[0], bad = dislikesHere[0];
  // the moment: weather and the hour
  const wx = table.weather, night = !!table.night;
  const has = (k) => types.includes(k);
  const cands = [];
  const add = (kind, w, line, joy) => { if (w > 0) cands.push({ kind, w, line, joy }); };
  const look = mode === 'camera' ? pick(seed + 'v', ['leans in toward the screen', 'stares at the camera view', 'peers at what you’re showing it'])
    : mode === 'out' ? pick(seed + 'v', ['sniffs the air', 'looks all around', 'takes it all in'])
      : pick(seed + 'v', ['presses up against its ball to look', 'peeks out through its ball', 'shifts in its ball to get a better look']);
  const where = top[0] ? FEATURES[top[0]].name : 'it all';
  // the part of the place that matches its kind best (for "this is where its kind belongs")
  const ownBest = [...String(pr.hab ?? '')].map((k) => [HAB_OF[k], Hs[k] ?? 0]).filter(([k]) => k).sort((a, b) => b[1] - a[1])[0];
  const ownWhere = ownBest && ownBest[1] >= 0.3 ? FEATURES[ownBest[0]].name : where;
  const S = (k) => ({ playful: k.p, bold: k.b, shy: k.s, lazy: k.l, calm: k.c })[style] ?? k.c;

  // right at home: its kind's own climate and habitat
  if (home >= 0.72) add('home', 4 + home * 3, pick(seed, [`${nm} ${look}: ${CLIM_NAME[domClim] ?? 'this'} and ${ownWhere} — this is exactly where its kind belongs.`, `${nm} relaxes completely. ${label} feels like home to it.`, `${nm} ${look} and lets out a happy sound: ${ownWhere}, the air, everything is just right.`]), 6);
  else if (home >= 0.5) add('like', 3 + home * 2, pick(seed, [`${nm} likes it here: ${where} suits it.`, `${nm} ${look} and seems content. Not home, but close.`, `${nm} settles in happily around ${where}.`]), 3);
  // drawn to something here
  if (fav && home < 0.72) add('love', 3.5 + (drawn.includes(fav) ? 1 : 0), pick(seed + fav, [`${nm} can’t take its eyes off ${FEATURES[fav].name}.`, `${nm} ${look} at ${FEATURES[fav].name} — it clearly loves it.`, `${nm} is thrilled by ${FEATURES[fav].name}!`]), 4);
  // something here that its kind dislikes
  if (bad) add('uneasy', 3 + (dislikesHere.length > 1 ? 1 : 0), S({ p: `${nm} keeps its distance from ${FEATURES[bad].name}, but it’s trying to be brave.`, b: `${nm} glares at ${FEATURES[bad].name} like it’s a rival.`, s: `${nm} hides deeper in its ball. ${FEATURES[bad].name[0].toUpperCase()}${FEATURES[bad].name.slice(1)} isn’t for it.`, l: `${nm} turns away from ${FEATURES[bad].name} and pretends to sleep.`, c: `${nm} isn’t comfortable around ${FEATURES[bad].name}.` }), -3);
  // a first: the sea, snow, a desert…
  if (firsts.length) {
    const f = firsts[0], fn = FEATURES[f].name;
    const opposite = (coldKind && ['desert', 'volcano'].includes(f)) || (hotKind && f === 'snow') || (has('water') && f === 'desert') || (has('fire') && ['sea', 'snow', 'lake'].includes(f));
    if (opposite) add('bewildered', 6, S({ p: `${nm} has never seen anything like ${fn}! It’s bewildered, and a little excited.`, b: `${nm} stares at ${fn}, completely baffled, then puffs up to show it isn’t scared.`, s: `${nm} has never seen ${fn} before and doesn’t know what to make of it. It stays very close to you.`, l: `${nm} squints at ${fn}, deeply confused, and decides to think about it later.`, c: `${nm} studies ${fn} for a long time, trying to understand it.` }), 2);
    else if (home >= 0.72 && [...String(pr.hab ?? '')].some((h) => HAB_OF[h] === f)) add('home', 8, pick(seed + 'fh', [`${nm} has never seen ${fn} before, yet somehow it knows: this is where its kind belongs.`, `${nm} ${look} at ${fn} for the very first time, and it feels like coming home.`]), 7);
    else add('wonder', 6.5, S({ p: `${nm} is bouncing in its ball: it just ${FEATURES[f].first.replace('for the first time', 'for the first time ever')}!`, b: `${nm} wants out right now to explore ${fn}. It’s never seen it before!`, s: `${nm} peeks at ${fn} for the first time, wide-eyed. Slowly, it starts to smile.`, l: `${nm} actually sits up for this: ${fn}, for the very first time.`, c: `${nm} goes quiet in awe. It’s never seen ${fn} before.` }), 5);
  } else if (newClimate && (coldKind || hotKind) && domClim !== clim[0]) {
    add('curious', 4, `${nm} has never been somewhere like ${CLIM_NAME[domClim] ?? 'this'}. It ${look}, fascinated.`, 3);
  }
  // made for another climate entirely
  if (coldKind && (temp != null ? temp >= 26 : ['T', 'A'].includes(domClim))) add('hot', 5 + (temp != null ? (temp - 26) / 4 : 1), pick(seed + 'h', [`${nm} is wilting in this heat. Its kind is made for ${CLIM_NAME[clim[0]] ?? 'the cold'}.`, `${nm} is panting a little. Somewhere cooler would be nice.`, `${nm} curls up in the shade of its ball. Too hot!`]), -4);
  if (hotKind && (temp != null ? temp <= 4 : ['C', 'P'].includes(domClim))) add('cold', 5 + (temp != null ? (4 - temp) / 4 : 1), pick(seed + 'c', [`${nm} is shivering. It comes from ${CLIM_NAME[clim[0]] ?? 'somewhere warm'} and this is far too cold.`, `${nm} huddles up for warmth.`, `${nm} would very much like to be somewhere warm, please.`]), -4);
  if (!firsts.length && home < 0.25 && (seen.homeAt ?? 0) > 0 && style !== 'bold') add('homesick', 2.5, `${nm} is quiet. Somewhere more like ${CLIM_NAME[clim[0]] ?? 'home'} is on its mind.`, -1);
  // the weather right now
  if (wx === 'rain') { if (has('water') || has('grass')) add('splash', 3.5, pick(seed + 'r', [`${nm} loves the rain!`, `${nm} is enjoying every drop of this rain.`]), 3); if (has('fire')) add('sulky', 4, `${nm} hates the rain and wants it to stop.`, -3); }
  if (wx === 'snow') { if (has('ice')) add('splash', 4.5, `${nm} is overjoyed: it’s snowing!`, 4); if (has('grass') || has('bug') || has('fire')) add('sulky', 3.5, `${nm} doesn’t like the snow one bit.`, -3); }
  if (wx === 'sunny' && (has('grass') || has('fire'))) add('splash', 3, `${nm} is soaking up the sunshine.`, 2);
  if (wx === 'sunny' && has('ice') && temp != null && temp > 20) add('sulky', 3, `${nm} is squinting in the sun. Too bright and too warm.`, -2);
  if (wx === 'fog' && (has('ghost') || has('dark'))) add('lively', 3.5, `${nm} loves this fog. It feels mysterious.`, 3);
  if (wx === 'windy' && has('flying')) add('splash', 3, `${nm} wants to ride this wind!`, 3);
  // the hour
  if (night && (pr.nocturnal || has('ghost') || has('dark'))) add('lively', 3.2, pick(seed + 'n', [`${nm} is wide awake: this is its time.`, `${nm} perks up now it’s dark.`]), 2);
  if (night && pr.diurnal && !(pr.nocturnal)) add('sleepy', 2.6, `${nm} is getting sleepy. Its kind is up with the sun.`, 0);
  // been here many times
  if (visits >= 6) {
    if (home >= 0.6) add('nostalgic', 2 + Math.min(2, visits / 10), pick(seed + 'b', [`${nm} knows ${label} well by now, and it’s happy to be back.`, `${nm} recognises ${label}. Its favourite spot!`]), 2);
    else add('bored', 2.5 + Math.min(3, visits / 6) * (style === 'playful' || style === 'bold' ? 1.4 : 0.8), S({ p: `${nm} is bored of ${label}. Somewhere new, please!`, b: `${nm} yawns loudly. It’s seen all there is to see at ${label}.`, s: `${nm} is comfortable here at least: it knows ${label} well.`, l: `${nm} doesn’t even look up. It’s been to ${label} plenty of times.`, c: `${nm} has seen ${label} many times. Nothing new today.` }), style === 'shy' ? 1 : -2);
  }
  // shown something through the phone's camera: what it could see (the colours of it)
  const cam = table.cam;
  if (cam) {
    const CAM = {
      green: { love: ['grass', 'bug', 'fairy'], what: 'all that green', yes: [`${nm} gasps at all the green on the screen!`, `${nm} wants to roll around in what you’re showing it. So green!`], no: [`${nm} looks at the leaves on the screen and shrugs.`] },
      blue: { love: ['water', 'flying', 'ice'], what: 'the blue', yes: [`${nm} stares at the blue on the screen, enchanted.`, `${nm} reaches toward the screen: water, or sky, either way it loves it.`], no: [`${nm} watches the blue calmly.`] },
      white: { love: ['ice', 'steel', 'fairy'], what: 'the white', yes: [`${nm} lights up: it’s so bright and white, like snow!`], no: [`${nm} squints at the glare.`] },
      dark: { love: ['ghost', 'dark', 'poison'], what: 'the darkness', yes: [`${nm} loves how dark it is on the screen.`, `${nm} grins at the shadows you’re showing it.`], no: [`${nm} can barely see anything and gets a little nervous.`] },
      warm: { love: ['fire', 'dragon', 'fighting', 'ground'], what: 'the warm colours', yes: [`${nm} gets fired up by the warm colours on the screen!`], no: [`${nm} blinks at all the orange.`] },
      grey: { love: ['steel', 'electric', 'normal', 'rock'], what: 'the grey', yes: [`${nm} studies the stone and concrete with real interest.`], no: [`${nm} isn’t very interested in what you’re showing it.`] },
    }[cam];
    if (CAM) {
      const loves = CAM.love.some((x) => has(x));
      add(loves ? 'love' : (cam === 'dark' && style === 'shy' ? 'uneasy' : 'meh'), loves ? 6 : 2.2, pick(seed + 'cam', loves ? CAM.yes : CAM.no), loves ? 4 : 0);
    }
  }
  // nothing much to say
  add('meh', 1.2 + (home < 0.3 ? 0.6 : 0), S({ p: `${nm} looks around for something fun to do.`, b: `${nm} isn’t impressed by ${label}.`, s: `${nm} watches ${where} quietly from its ball.`, l: `${nm} doesn’t think much of ${label} and goes back to dozing.`, c: `${nm} ${look}, calm and unbothered.` }), 0);
  // a little chance, not just the strongest: different moments, different moods
  for (const x of cands) x.w *= 0.85 + (hashOf(`${seed}:${x.kind}`) % 30) / 100;
  cands.sort((a, b) => b.w - a.w);
  const best = cands[0];
  const out = { kind: best.kind, mood: FEEL_MOODS[best.kind]?.label ?? best.kind, emoji: FEEL_MOODS[best.kind]?.emoji ?? '💭', line: best.line, joy: best.joy, firsts, score: Math.round(home * 100) / 100, also: cands.slice(1, 3).map((x) => x.line), label, mode };
  if (o.apply) {
    c.felt = { ...seen };
    if (c.feltHere?.at !== table.at) c.felt[placeKey] = visits + 1;
    for (const [k] of feats) c.felt[`f:${k}`] = (c.felt[`f:${k}`] ?? 0) + 1;
    c.felt[`clim:${domClim}`] = (c.felt[`clim:${domClim}`] ?? 0) + 1;
    if (home >= 0.72) c.felt.homeAt = t;
    // (and the walks' own firsts, so a walk doesn't call it a first again)
    const ws = { ...walkSeen }; for (const f of firsts) if (LEGACY[f]) ws[LEGACY[f]] = true; if (Object.keys(ws).length) c.seen = ws;
    for (const f of firsts.slice(0, 2)) addMemory(c, `${nm} ${FEATURES[f].first} at ${label}${o.trainer ? `, with ${o.trainer}` : ''}.`, t, { core: true, keys: [`place:${label}`, `feature:${f}`] });
    if (c.feltHere?.at !== table.at && c.needs) c.needs = { ...c.needs, joy: clamp((c.needs.joy ?? 60) + best.joy, 0, 100) };
    c.feltHere = { at: table.at, t, kind: best.kind, line: best.line, label, emoji: out.emoji };
  }
  return out;
}

/** "How do you like it here?" — from what it last felt about where you are (null when it hasn't been anywhere). */
export function hereAnswer(idx, c, t = Date.now()) {
  const f = c?.feltHere;
  if (!f || t - f.t > 12 * H) return null;
  return { note: f.line, exact: true, emote: 'note', mood: ['home', 'love', 'like', 'wonder', 'curious', 'splash', 'lively', 'nostalgic'].includes(f.kind) ? 'happy' : ['meh', 'bored', 'sleepy'].includes(f.kind) ? 'meh' : 'sad', bubble: { kind: 'emoji', e: f.emoji || '💭' } };
}
export const HERE_Q = /\b(?:how do you like|do you like|are you (?:enjoying|liking)|what do you think (?:of|about)|how(?:'s| is| do you feel about)|how are you finding|like it)\b.*\b(?:here|this place|this spot|where we are|it out here|the (?:beach|sea|ocean|snow|city|forest|woods|desert|mountains?|lake|park|view))\b|^\s*(?:isn'?t it (?:nice|beautiful|pretty) here|look where we are|where are we|look at (?:this|that) view)/i;
