// A creature's whole life in bytes: what a future ball with more memory could carry, so a creature
// could even be read by a PC that has never seen it. The tag format v1 (capsule.js) keeps only the
// 128-byte summary; this "full record" adds everything else as small tagged sections:
//
//   bytes 0–127   the v1 MAIN summary (species, level, genes, effort, moves and PP, needs, cry…)
//   then sections: [kind u8][length u16][data]
//     0x01 identity    PID u32, encryption constant u32, shiny type u8, gender u8, size u8, cry pitch i8 (×2),
//                      ball u8, form species number u16, held item index u16, met at u32 (s), met level u8
//     0x02 text        ability, how you met, held item name (each: length u8 + UTF-8)
//     0x03 memories    count u8, each: time u32 (s), flags u8 (bit0 core), length u8, UTF-8 text
//     0x04 likes       count u8, each: key length u8 + key, value i8
//     0x05 friends     count u8, each: uid 8 bytes + bond u8
//     0x06 clothes     count u8, each: item index u16, x u8, y u8, size u8
//     0x07 game data   the original game file (when it came over from a save editor)
//     0x08 journal     like memories (everyday things); optional
//   last 2 bytes: CRC-16 of everything before
// The whole thing can also be deflated (the phone and PC both can), which roughly halves the text.
import { encodeMain, decodeMain, crc16 } from './capsule.js';
import { fromBase64 } from './ndef.js';
import { CLOTHES, HELD } from './shop.js';

const enc = new TextEncoder();
const dec = new TextDecoder();
const GENDER = ['none', 'male', 'female'];
const SHINY = [undefined, 'star', 'square'];

function writer() {
  const parts = [];
  let len = 0;
  const push = (u8) => { parts.push(u8); len += u8.length; };
  return {
    u8: (v) => push(Uint8Array.of(v & 255)),
    i8: (v) => push(Uint8Array.of((v + 256) & 255)),
    u16: (v) => push(Uint8Array.of((v >> 8) & 255, v & 255)),
    u32: (v) => push(Uint8Array.of((v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255)),
    bytes: push,
    str: (s, max = 255) => { let b = enc.encode(String(s ?? '')); if (b.length > max) b = b.slice(0, max); push(Uint8Array.of(b.length)); push(b); },
    get length() { return len; },
    done() { const out = new Uint8Array(len); let o = 0; for (const p of parts) { out.set(p, o); o += p.length; } return out; },
  };
}
const section = (w, kind, body) => { w.u8(kind); w.u16(body.length); w.bytes(body); };
const uidBytes = (uid) => { const s = String(uid).padStart(16, '0').slice(-16); return Uint8Array.from({ length: 8 }, (_, i) => parseInt(s.substr(i * 2, 2), 16) || 0); };
const heldList = (idx) => [...HELD, ...(idx.ds?.items ?? []).filter((i) => i.kind === 'held')];
const clothesList = (idx) => [...CLOTHES, ...(idx.ds?.items ?? []).filter((i) => i.kind === 'clothes')];

/** Encode everything about a creature. opts: { journal: false, gameData: true } */
export function encodeFullRecord(idx, c, opts = {}) {
  const w = writer();
  w.bytes(encodeMain(idx, c, opts));
  // identity
  const id = writer();
  id.u32((c.pid ?? 0) >>> 0); id.u32((c.ec ?? 0) >>> 0);
  id.u8(c.shiny ? Math.max(1, SHINY.indexOf(c.shinyType ?? 'star')) : 0);
  id.u8(Math.max(0, GENDER.indexOf(c.gender ?? 'none')));
  id.u8(Number.isFinite(c.sizeScalar) ? c.sizeScalar : 128);
  id.i8(Number.isFinite(c.cryPitch) ? Math.round(c.cryPitch * 2) : -128);
  id.u8(Math.max(0, Math.min(255, Number(c.ball) || 0)));
  id.u16(c.formId ? idx.species.get(c.formId)?.no ?? 0 : 0);
  id.u16(Math.max(0, heldList(idx).findIndex((i) => i.id === c.heldItemId) + 1));
  id.u32(Math.floor((c.metAt ?? 0) / 1000) >>> 0);
  id.u8(c.metLevel ?? 1);
  section(w, 0x01, id.done());
  const tx = writer();
  tx.str(c.ability); tx.str(c.metHow); tx.str(c.heldItem);
  section(w, 0x02, tx.done());
  const mems = (list) => {
    const m = writer();
    const l = (list ?? []).slice(-255);
    m.u8(l.length);
    for (const x of l) { m.u32(Math.floor((x.t ?? 0) / 1000) >>> 0); m.u8(x.core ? 1 : 0); m.str(x.text, 160); }
    return m.done();
  };
  if (c.memories?.length) section(w, 0x03, mems(c.memories));
  const prefs = Object.entries(c.prefs ?? {});
  if (prefs.length) {
    const p = writer(); p.u8(Math.min(255, prefs.length));
    for (const [k, v] of prefs.slice(0, 255)) { p.str(k, 60); p.i8(Math.max(-10, Math.min(10, Math.round(v)))); }
    section(w, 0x04, p.done());
  }
  const bonds = Object.entries(c.bonds ?? {});
  if (bonds.length) {
    const b = writer(); b.u8(Math.min(255, bonds.length));
    for (const [uid, v] of bonds.slice(0, 255)) { b.bytes(uidBytes(uid)); b.u8(Math.max(0, Math.min(100, Math.round(v)))); }
    section(w, 0x05, b.done());
  }
  if (c.clothes?.length) {
    const cl = writer(); cl.u8(c.clothes.length);
    for (const x of c.clothes) { cl.u16(Math.max(0, clothesList(idx).findIndex((i) => i.id === x.id))); cl.u8(Math.round((x.fx ?? 0) * 255)); cl.u8(Math.round((x.fy ?? 0) * 255)); cl.u8(Math.round((x.s ?? 1) * 64)); }
    section(w, 0x06, cl.done());
  }
  if (opts.gameData !== false && c.pk?.raw) section(w, 0x07, fromBase64(c.pk.raw));
  if (opts.journal && c.journal?.length) section(w, 0x08, mems(c.journal));
  const body = w.done();
  const out = new Uint8Array(body.length + 2);
  out.set(body);
  const crc = crc16(body);
  out[body.length] = crc >> 8; out[body.length + 1] = crc & 255;
  return out;
}

/** Read a full record back: { ok, main, identity, ability, metHow, heldItem, memories, prefs, bonds, clothes, gameData, journal }. */
export function decodeFullRecord(bytes) {
  if (!bytes || bytes.length < 130) return { ok: false, error: 'Too short' };
  const n = bytes.length - 2;
  if (((bytes[n] << 8) | bytes[n + 1]) !== crc16(bytes, 0, n)) return { ok: false, error: 'Checksum mismatch' };
  const main = decodeMain(bytes.slice(0, 128));
  const out = { ok: true, main: main.rec, memories: [], prefs: {}, bonds: {}, clothes: [], journal: [] };
  let o = 128;
  const u16 = (p) => (bytes[p] << 8) | bytes[p + 1];
  const u32 = (p) => ((bytes[p] << 24) | (bytes[p + 1] << 16) | (bytes[p + 2] << 8) | bytes[p + 3]) >>> 0;
  const str = (p) => [dec.decode(bytes.slice(p + 1, p + 1 + bytes[p])), p + 1 + bytes[p]];
  const readMems = (p, end) => { const list = []; let q = p + 1; for (let i = 0; i < bytes[p] && q < end; i++) { const t = u32(q) * 1000, f = bytes[q + 4]; const [text, nq] = str(q + 5); list.push({ t, text, core: !!(f & 1) }); q = nq; } return list; };
  while (o + 3 <= n) {
    const kind = bytes[o], len = u16(o + 1), p = o + 3, end = p + len;
    if (kind === 0x01) out.identity = { pid: u32(p), ec: u32(p + 4), shinyType: SHINY[bytes[p + 8]] ?? null, shiny: bytes[p + 8] > 0, gender: GENDER[bytes[p + 9]], sizeScalar: bytes[p + 10], cryPitch: bytes[p + 11] === 128 ? null : ((bytes[p + 11] << 24) >> 24) / 2, ball: bytes[p + 12], formNo: u16(p + 13), heldIndex: u16(p + 15), metAt: u32(p + 17) * 1000, metLevel: bytes[p + 21] };
    else if (kind === 0x02) { let q = p; [out.ability, q] = str(q); [out.metHow, q] = str(q); [out.heldItem, q] = str(q); }
    else if (kind === 0x03) out.memories = readMems(p, end);
    else if (kind === 0x04) { let q = p + 1; for (let i = 0; i < bytes[p]; i++) { const [k, nq] = str(q); out.prefs[k] = (bytes[nq] << 24) >> 24; q = nq + 1; } }
    else if (kind === 0x05) { for (let i = 0, q = p + 1; i < bytes[p]; i++, q += 9) out.bonds[Array.from(bytes.slice(q, q + 8), (b) => b.toString(16).padStart(2, '0')).join('')] = bytes[q + 8]; }
    else if (kind === 0x06) { for (let i = 0, q = p + 1; i < bytes[p]; i++, q += 5) out.clothes.push({ index: u16(q), fx: bytes[q + 2] / 255, fy: bytes[q + 3] / 255, s: bytes[q + 4] / 64 }); }
    else if (kind === 0x07) out.gameData = bytes.slice(p, end);
    else if (kind === 0x08) out.journal = readMems(p, end);
    o = end;
  }
  return out;
}

/** How big a creature is on a ball, three ways: { summary, full, fullNoGameData, json }. */
export function recordSizes(idx, c) {
  return {
    summary: 160, // v1 tag record: MAIN 128 + WALK 32
    full: encodeFullRecord(idx, c).length,
    fullNoGameData: encodeFullRecord(idx, c, { gameData: false }).length,
    withJournal: encodeFullRecord(idx, c, { journal: true }).length,
    json: JSON.stringify(c).length,
  };
}
