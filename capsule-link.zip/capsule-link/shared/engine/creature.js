// Creature instances: creation, stats, experience, moves, evolution and memories.
import { STAT_KEYS, expForLevel, levelForExp, runFormula, temperMultiplier, expTable } from './dataset.js';
import { createRng, randomId } from './rng.js';

export const MAX_MEMORIES = 60;

export function todayKey(t = Date.now()) {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function createCreature(idx, speciesId, opts = {}) {
  const sp = idx.species.get(speciesId) ?? idx.ds.species[0];
  if (!sp) throw new Error('The dataset has no species yet. Add some in the Data Lab.');
  const rng = opts.rng ?? createRng(opts.seed ?? Math.floor(Math.random() * 4294967296));
  const level = Math.max(1, Math.min(opts.level ?? 5, idx.ds.rules.maxLevel));
  const maxG = idx.ds.rules.maxGenes;
  const genes = Object.fromEntries(STAT_KEYS.map((k) => [k, opts.genes?.[k] ?? rng.int(0, maxG)]));
  const effort = Object.fromEntries(STAT_KEYS.map((k) => [k, opts.effort?.[k] ?? 0]));
  const temper = opts.temper ?? rng.pick(idx.ds.temperaments)?.id ?? null;
  const now = opts.now ?? Date.now();
  const c = {
    uid: opts.uid ?? randomId(8, rng),
    speciesId: sp.id,
    nickname: opts.nickname ?? '',
    level,
    exp: expForLevel(idx, sp.growthRate, level),
    genes, effort, temper,
    moves: [],
    ability: opts.ability ?? speciesAbilities(sp)[0] ?? '',
    heldItem: opts.heldItem ?? '',
    hp: null,
    status: null,
    friendship: Math.min(idx.ds.rules.maxFriendship, opts.friendship ?? sp.baseFriendship ?? 70),
    needs: { fullness: 80, joy: 70, energy: 90, hygiene: 90 },
    needsAt: now,
    careToday: { day: todayKey(now), friendship: 0 },
    walk: { totalSteps: 0, day: todayKey(now), todaySteps: 0, stepsSinceFind: 0 },
    location: opts.location ?? { kind: 'box', box: 0, slot: 0 },
    trainer: opts.trainer ?? '',
    metAt: now,
    metLevel: level,
    metHow: opts.metHow ?? 'Received',
    memories: [],
    rev: 1,
    updatedAt: now,
  };
  c.moves = defaultMoves(idx, sp, level).map((id) => ({ id, pp: idx.moves.get(id)?.pp ?? 10 }));
  c.hp = calcStats(idx, c).hp;
  addMemory(c, `Met at level ${level}.`, now);
  return c;
}

export function speciesAbilities(sp) {
  const a = sp?.abilities;
  if (Array.isArray(a)) return a.filter(Boolean);
  if (a && typeof a === 'object') return Object.values(a).filter(Boolean);
  if (typeof a === 'string') return a.split(/\s*[,/]\s*/).filter(Boolean);
  return [];
}

/** The last four moves a species learns at or below `level`. */
export function defaultMoves(idx, sp, level) {
  const learned = [];
  for (const l of [...sp.learnset].sort((a, b) => a.level - b.level)) {
    if (l.level <= level && idx.moves.has(l.move) && !learned.includes(l.move)) learned.push(l.move);
  }
  return learned.slice(-4);
}

export function speciesOf(idx, c) {
  return idx.species.get(c.speciesId) ?? null;
}

export function displayName(idx, c) {
  return c.nickname || speciesOf(idx, c)?.name || 'Unknown';
}

export function calcStats(idx, c) {
  const sp = speciesOf(idx, c);
  const base = sp?.baseStats ?? {};
  const out = {};
  for (const k of STAT_KEYS) {
    const vars = { base: base[k] ?? 50, genes: c.genes?.[k] ?? 0, effort: c.effort?.[k] ?? 0, level: c.level, key: k };
    if (k === 'hp') out.hp = Math.max(1, Math.floor(runFormula(idx, 'hpStat', vars)));
    else out[k] = Math.max(1, Math.floor(runFormula(idx, 'stat', { ...vars, temper: temperMultiplier(idx, c.temper, k) })));
  }
  return out;
}

export function addMemory(c, text, t = Date.now()) {
  c.memories = c.memories || [];
  c.memories.push({ t, text });
  if (c.memories.length > MAX_MEMORIES) c.memories.splice(0, c.memories.length - MAX_MEMORIES);
}

export function touch(c, t = Date.now()) {
  c.rev = (c.rev || 0) + 1;
  c.updatedAt = t;
}

/** Progress (0..1) toward the next level. */
export function levelProgress(idx, c) {
  const sp = speciesOf(idx, c);
  const table = expTable(idx, sp?.growthRate);
  if (c.level >= idx.ds.rules.maxLevel) return 1;
  const a = table[c.level], b = table[c.level + 1];
  return Math.max(0, Math.min(1, (c.exp - a) / Math.max(1, b - a)));
}

/**
 * Add experience. Returns events: level ups, moves learned automatically (when a slot is free)
 * and moves waiting for a decision (when all four slots are full).
 */
export function gainExp(idx, c, amount, t = Date.now()) {
  const events = [];
  const sp = speciesOf(idx, c);
  if (!sp || amount <= 0) return events;
  const maxLv = idx.ds.rules.maxLevel;
  const cap = expForLevel(idx, sp.growthRate, maxLv);
  const before = calcStats(idx, c);
  c.exp = Math.min(cap, c.exp + Math.floor(amount));
  const newLevel = Math.min(maxLv, levelForExp(idx, sp.growthRate, c.exp));
  while (c.level < newLevel) {
    c.level++;
    events.push({ type: 'level', level: c.level });
    if (c.level % 10 === 0) addMemory(c, `Reached level ${c.level}.`, t);
    for (const l of sp.learnset) {
      if (l.level === c.level && idx.moves.has(l.move) && !c.moves.some((m) => m.id === l.move)) {
        events.push(learnOrPrompt(idx, c, l.move));
      }
    }
  }
  if (events.some((e) => e.type === 'level')) {
    // keep the same amount of damage taken when max HP grows
    const after = calcStats(idx, c);
    c.hp = Math.min(after.hp, (c.hp ?? before.hp) + (after.hp - before.hp));
  }
  const evo = checkEvolution(idx, c);
  if (evo) events.push({ type: 'canEvolve', to: evo.to, method: evo.method });
  return events;
}

export function learnOrPrompt(idx, c, moveId) {
  if (c.moves.length < 4) {
    c.moves.push({ id: moveId, pp: idx.moves.get(moveId)?.pp ?? 10 });
    return { type: 'learned', move: moveId };
  }
  return { type: 'learnPrompt', move: moveId };
}

export function replaceMove(idx, c, slot, moveId) {
  if (slot < 0 || slot > 3) return;
  c.moves[slot] = { id: moveId, pp: idx.moves.get(moveId)?.pp ?? 10 };
}

export function checkEvolution(idx, c) {
  const sp = speciesOf(idx, c);
  for (const e of sp?.evolutions ?? []) {
    if (!idx.species.has(e.to)) continue;
    const v = Number(e.value) || 0;
    if (e.method === 'level' && c.level >= v) return e;
    if (e.method === 'friendship' && c.friendship >= v) return e;
    if (e.method === 'steps' && (c.walk?.totalSteps ?? 0) >= v) return e;
  }
  return null;
}

export function evolve(idx, c, toId, t = Date.now()) {
  const from = speciesOf(idx, c);
  const to = idx.species.get(toId);
  if (!to) return null;
  const before = calcStats(idx, c);
  c.speciesId = to.id;
  const after = calcStats(idx, c);
  c.hp = Math.min(after.hp, (c.hp ?? before.hp) + (after.hp - before.hp));
  addMemory(c, `Grew from ${from?.name ?? '?'} into ${to.name}.`, t);
  const learned = [];
  for (const l of to.learnset) {
    if ((l.level === 0 || l.level === c.level) && idx.moves.has(l.move) && !c.moves.some((m) => m.id === l.move)) {
      learned.push(learnOrPrompt(idx, c, l.move));
    }
  }
  touch(c, t);
  return { from: from?.id, to: to.id, events: learned };
}

/** Full heal (used after battles and when resting in the ranch). */
export function restore(idx, c) {
  c.hp = calcStats(idx, c).hp;
  c.status = null;
  for (const m of c.moves) m.pp = idx.moves.get(m.id)?.pp ?? m.pp;
}

export function friendshipTier(f) {
  if (f >= 250) return { hearts: 5, label: 'Inseparable' };
  if (f >= 200) return { hearts: 4, label: 'Best friends' };
  if (f >= 150) return { hearts: 3, label: 'Close' };
  if (f >= 100) return { hearts: 2, label: 'Friendly' };
  if (f >= 50) return { hearts: 1, label: 'Getting along' };
  return { hearts: 0, label: 'Wary' };
}

/** A compact copy used for battles and phone transfers. */
export function battleSnapshot(idx, c) {
  return {
    uid: c.uid, speciesId: c.speciesId, nickname: c.nickname, level: c.level,
    genes: c.genes, effort: c.effort, temper: c.temper,
    moves: c.moves.map((m) => ({ id: m.id, pp: idx.moves.get(m.id)?.pp ?? m.pp })),
    friendship: c.friendship, trainer: c.trainer,
  };
}
