// The everyday things you'd say to a friend or a pet — "you're so fluffy!", "you're such a lazybones", "it's okay,
// don't be scared", "you can do it!", "I missed you", "tell me a joke", "what are you thinking about?", "high five!"
// — and what it knows of its own Pokémon world: its type and weaknesses, its moves, evolving, its ability, nature,
// ball and where it's from. Plus what's going on in its head (thoughtsOf), which also tells the language model.
//
//   thoughtsOf(idx, save, c, t)                  → [{ w, text, pic, key }] what it's thinking about, most pressing first
//   mindOf(idx, save, c, t)                      → { thoughts, bond, owed, today, kind } short lines for the language model
//   petReply / loreReply (idx, save, c, p, t)    → a reply, or null
//   typeAnswer(idx, save, c, p)                  → a row for "who is weak to fire?" and friends
import { displayName, speciesOf, calcStats, addMemory } from './creature.js';
import { journal } from './memory.js';
import { reasonsFor, ago, tasteOf } from './converse.js';
import { heardSongs } from './music.js';
import { owedOf } from './promises.js';
import { cravingOf, remember } from './dayMemory.js';
import { temperStyle } from './personality.js';
import { friendsOf } from './bonds.js';
import { mood, isAsleep } from './care.js';
import { fluencyOf } from './chat.js';
import { tasteFor, INVITES, whimFor } from './invite.js';
import { GENRE_LABEL, actById } from './lexicon.js';
import { typeNames, typeIn, matchup, weakTo, movesOf, bestMove, evoInfo, originOf, ballName, natureOf } from './lore.js';

const DAY = 86400000;
const hash = (s) => { let x = 2166136261; for (let i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); } return ((x >>> 0) % 10007) / 10007; };
const pickOf = (seed, a) => a[Math.floor(hash(seed) * a.length) % a.length];
const cap = (s) => String(s).charAt(0).toUpperCase() + String(s).slice(1);
const listOf = (a) => (a.length < 2 ? a.join('') : `${a.slice(0, -1).join(', ')} and ${a.at(-1)}`);
const R = (note, extra = {}) => ({ note, exact: true, emote: 'note', mood: 'content', bubble: { kind: 'emoji', e: '💬' }, ...extra });
const E = (e) => ({ kind: 'emoji', e });
const styleOf = (idx, c) => { try { return temperStyle(idx, c); } catch { return 'calm'; } };
const lowTypes = (idx, c) => typeNames(idx, c).map((x) => String(x).toLowerCase()).join(' ');

// ---------- what it's thinking ----------
/** What's on its mind right now, most pressing first. */
export function thoughtsOf(idx, save, c, t = Date.now()) {
  const out = reasonsFor(idx, save, c, t).map((r) => ({ ...r, w: Math.abs(r.w) + 0.1 }));
  const song = heardSongs(c).find((x) => t - x.last < 2 * DAY && x.op >= 1);
  if (song) out.push({ w: 0.7, pic: '🎵', text: `it has ${song.title ? `“${song.title}”` : 'that ' + (GENRE_LABEL[song.genre] ?? 'song')} stuck in its head`, key: 'earworm' });
  const fact = (c.chat?.facts ?? []).find((f) => t - f.t < DAY);
  if (fact?.kind === 'plan') out.push({ w: 0.75, pic: '💭', text: `it's wondering how ${/^(home|school|work|bed|town)$/.test(fact.obj) ? fact.obj : `the ${fact.obj}`} went`, key: 'fact' });
  if (fact?.kind === 'feel' && fact.sign < 0) out.push({ w: 0.9, pic: '🫂', text: `it's a bit worried about you — you said you were ${fact.obj}`, key: 'fact' });
  const here = Object.values(save.creatures ?? {}).filter((o) => o.uid !== c.uid && !o.egg && o.location?.kind === c.location?.kind && (o.location?.box ?? null) === (c.location?.box ?? null));
  const pal = friendsOf(c, 25).map((f) => save.creatures?.[f.uid]).filter(Boolean)[0];
  if (pal) out.push({ w: 0.45, pic: '🤝', text: here.includes(pal) ? `it keeps glancing over at ${displayName(idx, pal)}` : `it's wondering what ${displayName(idx, pal)} is up to`, key: 'pal' });
  const deal = (save.deals ?? []).find((d) => d.state === 'open' && d.heard?.includes(c.uid));
  if (deal) { const keen = (c.hopes ?? []).find((h) => h.dealId === deal.id)?.keen ?? 0.5; if (keen > 0.5) out.push({ w: 0.6 + keen * 0.5, pic: deal.prize?.icon ?? '🏆', text: `it's planning how to win ${deal.cond?.kind === 'battle' ? 'the next battle' : 'the next race'} — ${deal.prize?.label} is on the line`, key: 'deal' }); }
  // what it'd like to do right now (its tastes and today's mood)
  let best = null;
  for (const inv of INVITES.filter((i) => i.act || ['swim', 'battle', 'race', 'nap', 'walk', 'fetch', 'stargaze', 'sunbathe', 'dance'].includes(i.id))) {
    let v = 0; try { v = tasteFor(idx, c, inv.id) * 0.6 + whimFor(c, inv.id, t).day * 0.5; } catch { /* fine */ }
    if (!best || v > best.v) best = { inv, v };
  }
  if (best && best.v > 0.25) out.push({ w: 0.4 + best.v * 0.3, pic: '✨', text: `it's daydreaming about ${actById(best.inv.id)?.ing ?? best.inv.label}`, key: 'want', inv: best.inv.id });
  const sp = speciesOf(idx, c);
  if (sp?.flavor && out.length < 3) out.push({ w: 0.2, pic: '💭', text: `it's lost in thought (${String(sp.flavor).split(/[.!]/)[0].toLowerCase()})`, key: 'nature' });
  return out.sort((a, b) => b.w - a.w);
}

/** A few short lines about how it is, for the language model to stay true to. */
export function mindOf(idx, save, c, t = Date.now()) {
  const th = thoughtsOf(idx, save, c, t).slice(0, 2).map((x) => x.text);
  const f = (c.friendship ?? 0) / (idx.ds?.rules?.maxFriendship ?? 255);
  const tr = c.trust ?? {};
  const bond = f >= 0.85 ? 'adores its trainer' : f >= 0.6 ? 'is very fond of its trainer' : f >= 0.3 ? 'likes its trainer and is warming up' : 'is still getting to know its trainer';
  const owed = owedOf(c)[0];
  const types = typeNames(idx, c);
  const today = (c.today?.notes ?? []).filter((n) => ['won', 'lost', 'kept', 'ate', 'played'].includes(n.kind) && t - n.t < DAY).slice(-2).map((n) => (n.kind === 'won' ? `won ${n.key}` : n.kind === 'lost' ? `lost ${n.key}` : n.kind === 'kept' ? 'got what it was promised' : n.kind === 'ate' ? 'had a snack' : 'played with a friend'));
  return {
    thoughts: th,
    bond: `${bond}${(tr.broken ?? 0) > (tr.kept ?? 0) ? ', but has been let down by broken promises' : (tr.kept ?? 0) >= 2 ? ' and trusts it completely' : ''}`,
    owed: owed ? `${owed.won ? `won ${owed.prize?.label} in ${owed.won}` : `was promised ${owed.prize?.label}`} and is waiting for it` : null,
    today,
    kind: types.length ? `${types.join('/')} type` : null,
    style: styleOf(idx, c),
  };
}

// ---------- friend and pet talk ----------
const TRICKS = {
  highfive: { re: /high[- ]?five/, label: 'high five', act: 'jump', done: (n) => `${n} slaps your hand with a paw. High five!` },
  shake: { re: /shake|paw/, label: 'shake paws', act: 'come', done: (n) => `${n} plonks a paw in your hand and shakes.` },
  rollover: { re: /roll ?over/, label: 'roll over', act: 'spin', done: (n) => `${n} flops over and rolls right round.` },
  playdead: { re: /play dead/, label: 'play dead', act: 'sit', done: (n) => `${n} keels over dramatically… and peeks at you with one eye.` },
  speak: { re: /speak/, label: 'speak', act: 'jump', done: (n) => `${n} lets out its loudest cry!`, cry: true },
  bow: { re: /bow/, label: 'bow', act: 'sit', done: (n) => `${n} takes a very serious little bow.` },
  beg: { re: /beg|sit pretty/, label: 'sit pretty', act: 'sit', done: (n) => `${n} sits up on its back legs and begs, all big eyes.` },
  wave: { re: /wave/, label: 'wave', act: 'jump', done: (n) => `${n} waves at you.` },
  flip: { re: /back ?flip|flip/, label: 'do a backflip', act: 'jump', done: (n) => `${n} leaps and flips — and sticks the landing!` },
  stand: { re: /stand/, label: 'stand up tall', act: 'jump', done: (n) => `${n} stands up as tall as it can.` },
};
const JOKES = [
  [/water|tide/, 'squirts a little jet of water right at your nose'], [/fire|ember/, 'puffs out a smoke ring shaped like a heart'], [/electric|spark/, 'gives you a tiny static zap that makes your hair stand on end'],
  [/grass|sprout/, 'sticks a leaf on your nose and acts like nothing happened'], [/ghost/, 'vanishes, then pops up behind you: boo!'], [/psychic|mind/, 'floats your hat just out of reach'],
  [/ice|frost/, 'makes a lopsided little snowman of you'], [/rock|stone|ground/, 'balances a pebble on its nose, wobbles, and drops it'], [/flying/, 'flaps very dramatically and falls over'],
  [/bug/, 'does a wiggly dance with all its legs'], [/dark|shade/, 'swipes your snack and grins'], [/fairy/, 'sprinkles sparkles all over your head'], [/dragon/, 'lets out a mighty roar… then hiccups'],
  [/poison/, 'blows a stinky bubble and runs off giggling'], [/steel|metal/, 'clanks around stiffly, pretending to be a robot'], [/fighting|brawl/, 'shadow-boxes its own shadow, and loses'],
];
const COMPLIMENT_TRUE = { big: (idx, c) => (speciesOf(idx, c)?.height ?? 0.6) >= 1.2, tall: (idx, c) => (speciesOf(idx, c)?.height ?? 0.6) >= 1.2, tiny: (idx, c) => (speciesOf(idx, c)?.height ?? 0.6) <= 0.4, small: (idx, c) => (speciesOf(idx, c)?.height ?? 0.6) <= 0.5, strong: (idx, c) => (c.level ?? 1) >= 30, shiny: (idx, c) => !!c.shiny };

export function petReply(idx, save, c, p, t = Date.now()) {
  const nm = displayName(idx, c), style = styleOf(idx, c), seed = `${c.uid}:${p.s}:${Math.floor(t / 60000)}`;
  const n = (c.needs = c.needs || {});
  const day = new Date(t).toDateString();
  const tally = (key) => { c.petTalk = c.petTalk?.day === day ? c.petTalk : { day }; c.petTalk[key] = (c.petTalk[key] ?? 0) + 1; return c.petTalk[key]; };
  switch (p.sub) {
    case 'compliment': {
      const w = p.word, k = tally(`c:${w}`), check = COMPLIMENT_TRUE[w];
      if (k === 1) { n.joy = Math.min(100, (n.joy ?? 60) + 3); c.friendship = Math.min(255, (c.friendship ?? 0) + 1); }
      const untrue = check && !check(idx, c);
      const react = { shy: `goes pink and hides its face, secretly thrilled`, bold: `struts about, chest out — it knows`, playful: `wiggles all over with delight`, lazy: `gives a slow, very pleased blink`, calm: `looks quietly pleased` }[style] ?? 'beams';
      const note = untrue ? `${nm} isn't exactly ${w}, but it'll take the compliment. It ${react}.` : k > 3 ? `${nm} has heard that a few times today, and it still ${react.replace(/^goes/, 'goes').replace(/^(\w+)s\b/, '$1s')}.` : `${nm} ${react}.`;
      remember(c, 'chat', 'love', 1, t);
      return R(note, { bubble: E(style === 'shy' ? '☺️' : '💗'), mood: 'happy', emote: 'hearts', yes: true });
    }
    case 'tease': {
      const w = p.word, close = (c.friendship ?? 0) >= 150;
      const fits = (/lazy|couch|lazybones/.test(w) && style === 'lazy') || (/greedy|glutton|chubby|chonky|fat/.test(w) && (n.fullness ?? 60) > 85) || (/grump/.test(w) && mood(c, t).id === 'upset') || (/show-?off/.test(w) && style === 'bold') || (/scaredy/.test(w) && style === 'shy');
      let note, moodS = 'content', pic = '😛';
      if (fits) note = pickOf(seed, [`${nm} can't really argue with that.`, `${nm} gives you a look, but it knows you're right.`]);
      else if (style === 'playful' || close) note = pickOf(seed, [`${nm} blows a raspberry right back at you.`, `${nm} pounces on your foot in revenge.`, `${nm} pretends to be offended, then headbutts you playfully.`]);
      else if (style === 'bold') { note = `${nm} huffs and turns its back on you. How dare you.`; pic = '😤'; }
      else if (style === 'shy') { note = `${nm} looks hurt and shrinks a little. Maybe say sorry?`; pic = '🥺'; moodS = 'meh'; n.joy = Math.max(0, (n.joy ?? 60) - 3); }
      else note = `${nm} pretends it didn't hear that.`;
      return R(note, { bubble: E(pic), mood: moodS, emote: pic === '🥺' ? 'sweat' : 'note' });
    }
    case 'comfort': {
      const m = mood(c, t), rs = reasonsFor(idx, save, c, t).filter((r) => r.w < 0);
      if ((c.upsetUntil ?? 0) > t && (c.friendship ?? 0) >= 80) { c.upsetUntil = Math.min(c.upsetUntil, t + 20000); return R(`${nm} sniffles, then leans into you. It's feeling better already.`, { bubble: E('🫂'), mood: 'happy', emote: 'hearts' }); }
      if (rs.length) { n.joy = Math.min(100, (n.joy ?? 60) + 4); return R(`${nm} presses close. It needed that — ${rs[0].text}.`, { bubble: E('🫂'), mood: 'content', emote: 'hearts' }); }
      return R(m.id === 'happy' ? `${nm} wasn't worried, but it snuggles up anyway.` : `${nm} relaxes and leans against you.`, { bubble: E('🫂'), mood: 'happy', emote: 'hearts' });
    }
    case 'encourage': {
      c.pepTalk = t;
      const deal = (save.deals ?? []).find((d) => d.state === 'open' && d.heard?.includes(c.uid));
      const note = deal ? `${nm} stamps its feet, fired up: it's going to win ${deal.cond?.kind === 'battle' ? 'that battle' : 'that race'} — and ${deal.prize?.label}!` : pickOf(seed, [`${nm} nods, determined. It won't let you down!`, `${nm} puffs itself up, ready for anything.`, `${nm} lets out a fierce little cry. Bring it on!`]);
      return R(note, { bubble: E('🔥'), mood: 'happy', emote: 'exclaim', act: { kind: 'jump' }, yes: true });
    }
    case 'miss': {
      const asked = /did you miss me/.test(p.s), tr = (c.trust?.broken ?? 0) > (c.trust?.kept ?? 0);
      const f = (c.friendship ?? 0) / 255;
      const note = f >= 0.6 ? (asked ? `${nm} runs circles round you. Yes! So much!` : `${nm} nuzzles you hard. It missed you too.`) + (tr ? ' (Though it still remembers that promise.)' : '') : f >= 0.3 ? `${nm} perks up and comes over. It's glad you're here.` : `${nm} watches you, curious. It's starting to notice when you're gone.`;
      return R(note, { bubble: E('💗'), mood: 'happy', emote: 'hearts', act: f >= 0.3 ? { kind: 'come' } : null, yes: f >= 0.3 });
    }
    case 'joke': {
      const tw = lowTypes(idx, c);
      const j = JOKES.filter(([re]) => re.test(tw)).map((x) => x[1]);
      const pool = j.length ? j : ['pulls the silliest face it can', 'chases its own tail until it falls over', 'copies the way you walk, badly'];
      return R(`${nm} ${pickOf(seed, pool)}.`, { bubble: E('😂'), mood: 'happy', emote: 'note', act: { kind: 'spin' } });
    }
    case 'thinking': {
      const th = thoughtsOf(idx, save, c, t);
      if (!th.length) return R(`${nm} isn't thinking about much at all. It's just happy to be here.`, { bubble: E('🍃') });
      const a = th[0], b = th.find((x, i) => i > 0 && x.key !== a.key && x.w > 0.5);
      return R(`${nm} seems to be thinking: ${a.text}${b ? `. And ${b.text}` : ''}.`, { bubble: E(a.pic), mood: 'content', emote: 'note' });
    }
    case 'dream': {
      const th = thoughtsOf(idx, save, c, t).filter((x) => x.w > 0.3);
      const bad = (c.lastBroken && t - c.lastBroken.t < DAY) || (c.upsetUntil ?? 0) > t;
      const d = th.find((x) => ['owed', 'kept', 'won', 'song', 'earworm', 'pal', 'want', 'deal'].some((k) => String(x.key).startsWith(k)));
      const what = bad ? 'a grumpy sort of dream' : d ? d.text.replace(/^it's daydreaming about /, '').replace(/^it('s| has| is| keeps| won)?\s*/, (m) => (/won/.test(m) ? 'winning ' : '')).replace(/^daydreaming about /, '').replace(/^planning how to /, '').replace(/^glancing over at /, '') : 'running through a field of berries';
      return R(isAsleep(c, t) ? `${nm} murmurs and twitches in its sleep — it's dreaming right now.` : `${nm} seems to have dreamt about ${what}.`, { bubble: E(bad ? '😣' : '💤'), mood: 'content' });
    }
    case 'bless': return R(`${nm} sniffles and looks a little embarrassed.`, { bubble: E('🤧'), mood: 'content' });
    case 'trick': return trickReply(idx, save, c, p, t, nm, seed);
    default: return null;
  }
}
function trickReply(idx, save, c, p, t, nm, seed) {
  const id = Object.keys(TRICKS).find((k) => TRICKS[k].re.test(p.word ?? p.s));
  if (!id) return null;
  const T = TRICKS[id];
  if ((c.upsetUntil ?? 0) > t) return R(`${nm} ignores you. It's not doing tricks while it's cross.`, { bubble: E('😤'), mood: 'meh', emote: 'sweat', yes: false });
  if ((c.needs?.energy ?? 60) < 12) return R(`${nm} is too worn out to ${T.label} right now.`, { bubble: E('💤'), mood: 'sleepy', emote: 'zzz', yes: false });
  c.tricks = c.tricks || {};
  const e = (c.tricks[id] = c.tricks[id] || { n: 0, ok: 0 });
  e.n++;
  let fl = 0.3; try { fl = fluencyOf(idx, c); } catch { /* fine */ }
  const chance = e.learned ? 1 : Math.min(0.95, 0.2 + fl * 0.4 + ((c.friendship ?? 0) / 255) * 0.3 + e.n * 0.1);
  const ok = hash(`${seed}:${e.n}`) < chance;
  if (!ok) return R(pickOf(seed, [`${nm} tries its best to ${T.label}, but gets it a bit wrong. Keep practising!`, `${nm} looks at you, unsure what ${T.label} means yet.`, `${nm} does something that is almost a ${T.label}. Almost.`]), { bubble: E('🤔'), mood: 'curious', emote: '?', yes: false });
  e.ok++;
  let note = T.done(nm);
  if (!e.learned && e.ok >= 3) { e.learned = t; note += ` It's got it now: ${nm} knows how to ${T.label}!`; addMemory(c, `Learned to ${T.label} for you.`, t, { core: false }); journal(c, `Learned a trick: ${T.label}.`, t); }
  c.needs = c.needs || {}; c.needs.joy = Math.min(100, (c.needs.joy ?? 60) + 2);
  return R(note, { bubble: E('🌟'), mood: 'happy', emote: 'hearts', act: { kind: T.act }, yes: true, trick: id });
}

// ---------- its Pokémon world ----------
export function loreReply(idx, save, c, p, t = Date.now()) {
  const nm = displayName(idx, c), types = typeNames(idx, c), seed = `${c.uid}:${p.topic}`;
  switch (p.topic) {
    case 'type': {
      const asked = typeIn(idx, p.obj ?? '');
      if (asked) { const yes = (speciesOf(idx, c)?.types ?? []).includes(asked); return R(yes ? `${nm} nods proudly: yes, it's ${idx.types.get(asked)?.name ?? asked} type.` : `${nm} shakes its head: it's ${types.join('/')} type, not ${idx.types.get(asked)?.name ?? asked}.`, { bubble: E(yes ? '✅' : '🙅'), yes }); }
      return R(`${nm} is ${types.length > 1 ? `${types.join(' and ')}` : `${types[0] ?? 'a mystery'}`} type.`, { bubble: E('🔷'), mood: 'content' });
    }
    case 'weak': {
      const w = weakTo(idx, c), asked = typeIn(idx, p.obj ?? '');
      if (asked) {
        const x = matchup(idx, asked, speciesOf(idx, c)?.types ?? []), tn = idx.types.get(asked)?.name ?? asked;
        const note = x === 0 ? `${nm} isn't scared of ${tn} at all — it can't touch it.` : x >= 4 ? `${nm} shudders. ${tn} hits it four times as hard!` : x >= 2 ? `${nm} nods nervously: ${tn} moves hit it hard.` : x < 1 ? `${nm} shrugs off the idea: ${tn} barely hurts it.` : `${nm} isn't especially bothered by ${tn}.`;
        return R(note, { bubble: E(x >= 2 ? '😰' : '😎'), mood: x >= 2 ? 'meh' : 'happy', yes: x >= 2 });
      }
      return R(w.weak.length ? `${nm} would rather not face ${listOf(w.weak.slice(0, 3).map((x) => `${x.name}${x.x >= 4 ? ' (×4!)' : ''}`))} moves.${w.immune.length ? ` But ${listOf(w.immune.map((x) => x.name))} can't touch it.` : ''}` : `${nm} doesn't have any real weaknesses.`, { bubble: E('🛡️') });
    }
    case 'strong': {
      const asked = typeIn(idx, p.obj ?? '');
      const mineMoves = movesOf(idx, c);
      if (asked) {
        const best = mineMoves.map((mv) => ({ mv, x: matchup(idx, mv.type, [asked]) })).sort((a, b) => b.x - a.x)[0];
        const tn = idx.types.get(asked)?.name ?? asked;
        return R(best && best.x >= 2 ? `${nm} grins: its ${best.mv.name} would be great against ${tn}.` : best && best.x < 1 ? `${nm} isn't sure — none of its moves do much to ${tn}.` : `${nm} could hold its own against ${tn}, nothing more.`, { bubble: E(best?.x >= 2 ? '💪' : '🤔'), yes: (best?.x ?? 1) >= 2 });
      }
      const good = [...(idx.types?.values?.() ?? [])].filter((d) => mineMoves.some((mv) => matchup(idx, mv.type, [d.id]) >= 2)).map((d) => d.name);
      return R(good.length ? `${nm}'s moves hit ${listOf(good.slice(0, 4))} types hard.` : `${nm}'s moves don't hit any type especially hard yet.`, { bubble: E('💪') });
    }
    case 'moves': {
      const ms = movesOf(idx, c);
      return R(ms.length ? `${nm} knows ${listOf(ms.map((m) => m.name))}.` : `${nm} doesn't know any moves yet.`, { bubble: E('📜') });
    }
    case 'bestMove': {
      const b = bestMove(idx, c);
      return R(b ? `${nm} shows off ${b.name}${b.power ? ` (power ${b.power})` : ''} — its proudest move.` : `${nm} doesn't have a move worth showing off yet.`, { bubble: E('✨'), mood: 'happy', emote: 'exclaim', act: b ? { kind: 'spin' } : null });
    }
    case 'evolve': {
      const ev = evoInfo(idx, save, c);
      if (ev.final) return R(`${nm} is fully evolved — this is as big as it gets.`, { bubble: E('🏁') });
      const nx = ev.next[0];
      if (ev.can) return R(`${nm} glows faintly… it's ready to evolve into ${nx.name}! (Ask it to evolve when you're both ready.)`, { bubble: E('✨'), mood: 'happy', emote: 'exclaim' });
      if (p.want) { let ts = 0; try { ts = tasteOf(idx, save, c, { act: null, obj: 'evolving' }).score; } catch { /* fine */ } return R(ts >= 0 ? `${nm} nods: one day it wants to become ${nx.name}.` : `${nm} isn't in any hurry to change. It likes being itself.`, { bubble: E('🌱'), yes: ts >= 0 }); }
      const lv = /level (\d+)/.exec(nx.how ?? '');
      return R(`${nm} will evolve into ${listOf(ev.next.map((x) => `${x.name}${x.how ? ` ${x.how}` : ''}`))}.${lv ? ` (It's level ${c.level ?? 1} now${Number(lv[1]) - (c.level ?? 1) <= 3 ? ' — nearly there!' : ''}.)` : nx.why ? ` (Not yet: ${nx.why.replace(/\.$/, '').replace(/^[A-Z]/, (x) => x.toLowerCase())}.)` : ''}`, { bubble: E('🌱') });
    }
    case 'ability': return R(c.ability ? `${nm}'s ability is ${idx.abilities?.get?.(c.ability)?.name ?? String(c.ability).replace(/-/g, ' ')}.` : `${nm} doesn't seem to have a special ability.`, { bubble: E('🌀') });
    case 'nature': {
      const nt = natureOf(idx, c), st = styleOf(idx, c);
      const blurb = { playful: 'always up for a game', lazy: 'laid-back and fond of naps', shy: 'a bit shy until it knows you', bold: 'bold and never backs down', calm: 'easy-going' }[st];
      return R(`${nm} is ${nt.name ? `${/^[aeiou]/i.test(nt.name) ? 'an' : 'a'} ${nt.name} sort` : 'its own sort'} — ${blurb}.${nt.up && nt.up !== nt.down ? ` Good at ${nt.up}, not so much ${nt.down}.` : ''}`, { bubble: E('🪞') });
    }
    case 'origin': {
      const o = originOf(idx, c);
      const when = o.when ? ` ${ago(o.when, t)}` : '';
      const from = o.game ? `${nm} is from ${o.region ? `${o.region} (${o.game})` : o.game}` : null;
      const how = o.how ? String(o.how).replace(/\.$/, '').replace(/^[A-Z]/, (x) => x.toLowerCase()) : '';
      const met = o.how ? `you met${when}${o.level ? ` at level ${o.level}` : ''}${/\s/.test(how) ? ` — ${how}` : ` (${how})`}` : null;
      const mem = o.first && o.first.from === 'game' ? ` It still remembers: ${String(o.first.text).replace(/\.$/, '')}.` : '';
      const place = o.places?.length ? ` It sometimes thinks about ${o.places[Math.floor(hash(seed) * o.places.length)]}.` : '';
      return R(`${from ? `${from}; ` : `${nm} remembers: `}${met ?? 'it has been with you as long as it can remember'}.${mem}${place}`, { bubble: E('🗺️'), mood: 'content' });
    }
    case 'ball': {
      const b = ballName(c), op = hash(`${c.uid}|ball|${b}`) - 0.35 + (/Luxury|Friend|Love|Heal|Dream|Moon|Premier|Cherish/.test(b) ? 0.3 : 0);
      return R(`${nm} lives in ${/^[aeiou]/i.test(b) ? 'an' : 'a'} ${b}${op > 0.2 ? ' — and it loves it. Comfy.' : op < -0.15 ? '. It would quite like a change, if you have a nicer one.' : '. It suits it fine.'}`, { bubble: E('⚪'), mood: op > 0.2 ? 'happy' : 'content', yes: op > 0 });
    }
    case 'health': {
      const st = calcStats(idx, c), hp = c.hp ?? st.hp, frac = st.hp ? hp / st.hp : 1;
      const status = c.status ? String(idx.statuses?.get?.(c.status)?.name ?? c.status).toLowerCase() : null;
      const note = frac <= 0 ? `${nm} has fainted — it needs healing before it can battle again.` : status ? `${nm} is ${status}${frac < 0.5 ? ' and badly hurt' : ''}. A trip to be healed would help.` : frac < 0.35 ? `${nm} is hurting (${hp}/${st.hp} HP). It could really use some healing.` : frac < 0.8 ? `${nm} is a bit battered (${hp}/${st.hp} HP), but fine.` : `${nm} is in perfect shape (${hp}/${st.hp} HP).`;
      return R(note, { bubble: E(frac < 0.35 || status ? '🩹' : '💚'), mood: frac < 0.35 ? 'meh' : 'content', yes: frac < 0.8 || !!status });
    }
    case 'species': {
      const nameW = String(p.obj ?? '').toLowerCase().replace(/s$/, '');
      const named = nameW === '@n' ? save.creatures?.[p.about?.[0] ?? p.named?.[0]] : null;
      if (named && named.uid !== c.uid && String(p.raw).toLowerCase().includes(String(named.nickname ?? displayName(idx, named)).toLowerCase())) {
        const b = c.bonds?.[named.uid] ?? 0;
        return R(b >= 30 ? `${nm} knows ${displayName(idx, named)} well — they're good friends.` : b > 0 ? `${nm} knows ${displayName(idx, named)}; they've played together a bit.` : `${nm} has seen ${displayName(idx, named)} around, but they haven't really met.`, { bubble: { kind: 'creature', uid: named.uid, speciesId: named.formId ?? named.speciesId }, mood: 'content' });
      }
      const sp = named ? speciesOf(idx, named) : [...(idx.species?.values?.() ?? [])].find((x) => String(x.name).toLowerCase() === nameW || String(x.name).toLowerCase() === `${nameW}s`);
      if (!sp) return null;
      if (sp.id === (c.formId ?? c.speciesId) || sp.id === c.speciesId) return R(`${nm} points at itself. That's what it is!`, { bubble: E('😄'), mood: 'happy' });
      const pals = Object.values(save.creatures ?? {}).filter((o) => (o.speciesId === sp.id || o.formId === sp.id) && o.uid !== c.uid);
      const best = pals.sort((a, b) => (c.bonds?.[b.uid] ?? 0) - (c.bonds?.[a.uid] ?? 0))[0];
      const evoOf = (speciesOf(idx, c)?.evolutions ?? []).some((e) => e.to === sp.id) || (sp.evolutions ?? []).some((e) => e.to === c.speciesId);
      const note = best ? `${nm} knows ${displayName(idx, best)} the ${sp.name}${(c.bonds?.[best.uid] ?? 0) >= 30 ? ' — they\'re good friends' : ''}.` : evoOf ? `${nm} perks up: ${sp.name}? That's family — ${(speciesOf(idx, c)?.evolutions ?? []).some((e) => e.to === sp.id) ? 'what it will grow into' : 'what it used to be'}.` : `${nm} has heard of ${sp.name}s, but never met one here.`;
      return R(note, { bubble: { kind: 'creature', speciesId: sp.id }, mood: 'content' });
    }
    case 'level': {
      const st = calcStats(idx, c), sp = speciesOf(idx, c), which = p.which;
      if (which === 'tall' || which === 'big') return R(sp?.height ? `${nm} stands about ${Math.round(sp.height * (c.sizeScale ?? 1) * 100) / 100} m tall.` : `${nm} stretches up as tall as it can.`, { bubble: E('📏') });
      if (which === 'heavy' || which === 'weigh') return R(sp?.weight ? `${nm} weighs about ${sp.weight} kg.` : `${nm} isn't telling.`, { bubble: E('⚖️') });
      if (which === 'fast') return R(`${nm} has a Speed of ${st.spe}.${st.spe > (c.level ?? 1) * 1.3 + 25 ? ' Zoom!' : ''}`, { bubble: E('💨') });
      if (which === 'old') return R(`${nm} has been with you since ${c.metAt ? new Date(c.metAt).toLocaleDateString() : 'as long as it can remember'}.`, { bubble: E('📅') });
      return R(`${nm} is level ${c.level ?? 1}: Attack ${st.atk}, Sp. Atk ${st.spa}, Speed ${st.spe}.`, { bubble: E('💪') });
    }
    default: return null;
  }
}

/** "Who is weak to fire?", "who knows a water move?", "who can evolve?", "who is a grass type?": one creature's row. */
export function typeAnswer(idx, save, c, p) {
  const nm = displayName(idx, c), types = speciesOf(idx, c)?.types ?? [];
  const asked = typeIn(idx, p.obj ?? '');
  const tn = asked ? idx.types.get(asked)?.name ?? asked : p.obj;
  if (p.stance === 'weak' || p.stance === 'strong') {
    if (!asked) return null;
    const x = p.stance === 'weak' ? matchup(idx, asked, types) : Math.max(0, ...movesOf(idx, c).map((mv) => matchup(idx, mv.type, [asked])));
    const text = p.stance === 'weak' ? (x === 0 ? `${nm} can't be touched by ${tn}.` : x >= 2 ? `${nm} is weak to ${tn}${x >= 4 ? ' (four times!)' : ''}.` : x < 1 ? `${nm} resists ${tn}.` : `${nm} takes ${tn} normally.`)
      : (x >= 2 ? `${nm} has a move that's great against ${tn}.` : x < 1 ? `${nm} can barely scratch ${tn}.` : `${nm} has nothing special for ${tn}.`);
    return { text, pic: x >= 2 ? (p.stance === 'weak' ? '😰' : '💪') : x < 1 ? '🛡️' : '😐', v: x };
  }
  if (p.stance === 'knows') {
    const ms = movesOf(idx, c).filter((mv) => (asked ? mv.type === asked : String(mv.name).toLowerCase().includes(String(p.obj).toLowerCase())));
    return { text: ms.length ? `${nm} knows ${listOf(ms.map((m) => m.name))}.` : `${nm} doesn't know a ${tn} move.`, pic: ms.length ? '📜' : '🙅', v: ms.length };
  }
  if (p.stance === 'evolve') {
    const ev = evoInfo(idx, save, c);
    return { text: ev.final ? `${nm} is fully evolved.` : ev.can ? `${nm} is ready to evolve into ${ev.next[0].name}!` : `${nm} will evolve into ${ev.next[0].name} ${ev.next[0].how}.`, pic: ev.can ? '✨' : ev.final ? '🏁' : '🌱', v: ev.can ? 2 : ev.final ? 0 : 1 };
  }
  if (p.stance === 'isType') {
    if (!asked) return null;
    const yes = types.includes(asked);
    return { text: yes ? `${nm} is ${tn} type.` : `${nm} is ${typeNames(idx, c).join('/')} type.`, pic: yes ? '✅' : '➖', v: yes ? 1 : 0 };
  }
  return null;
}

// ---------- for the language model: the kinds of thing a trainer says, so free-form words can find their answer ----------
// (when the rules can't place what was said, the on-device model is asked which of these it is, and the game then
// answers it properly — from the creature's real memories, tastes and record — as if it had been said plainly)
export const TALK_INTENTS = [
  { id: 'why', label: 'asking why it feels the way it does', say: 'why do you feel like that?' },
  { id: 'thinking', label: 'asking what it is thinking about', say: 'what are you thinking about?' },
  { id: 'day', label: 'asking about its day', say: 'what did you do today?' },
  { id: 'feel', label: 'asking how it is', say: 'how are you feeling?' },
  { id: 'compliment', label: 'saying something nice about it', say: "you're so cute!" },
  { id: 'tease', label: 'teasing it', say: "you're so silly" },
  { id: 'comfort', label: 'comforting it', say: "it's okay, don't worry" },
  { id: 'encourage', label: 'cheering it on', say: 'you can do it!' },
  { id: 'miss', label: 'saying you missed it', say: 'I missed you' },
  { id: 'joke', label: 'asking it to be funny', say: 'tell me a joke' },
  { id: 'favourite', label: 'asking its favourite thing to do', say: "what's your favourite thing to do?" },
  { id: 'music', label: 'asking what music it likes', say: 'what kind of music do you like?' },
  { id: 'type', label: 'asking what type it is', say: 'what type are you?' },
  { id: 'weak', label: 'asking about its weaknesses', say: "what's your weakness?" },
  { id: 'moves', label: 'asking what moves it knows', say: 'what moves do you know?' },
  { id: 'evolve', label: 'asking about evolving', say: 'will you evolve?' },
  { id: 'origin', label: 'asking where it is from or how you met', say: 'where are you from?' },
  { id: 'goodat', label: 'asking what it is good at', say: 'what are you good at?' },
  { id: 'trust', label: 'asking how it feels about you', say: 'what do you think of me?' },
  { id: 'dream', label: 'asking about its dreams or sleep', say: 'did you have a nice dream?' },
  { id: 'friends', label: 'asking about its friends', say: 'who is your favourite pokemon?' },
];
export const TALK_EXAMPLES = [
  ["What's got you so chuffed?", 'why'], ["What's going on in that head of yours, buddy?", 'thinking'], ['How was everything today?', 'day'], ['You doing alright, pal?', 'feel'],
  ['Look at those little ears, adorable', 'compliment'], ['You absolute goofball', 'tease'], ['Hey hey, nothing bad is going to happen', 'comfort'], ["Go show them who's boss!", 'encourage'],
  ['It felt like forever since I saw you', 'miss'], ['Make me giggle', 'joke'], ['What do you love doing most?', 'favourite'], ['What tunes are you into?', 'music'],
  ['What element are you?', 'type'], ['What hurts you most in a fight?', 'weak'], ['What attacks have you learned?', 'moves'], ['Are you going to turn into something bigger one day?', 'evolve'],
  ['Where did you grow up?', 'origin'], ['What are your talents?', 'goodat'], ['Am I a good trainer to you?', 'trust'], ['Sweet dreams last night?', 'dream'], ['Who do you hang out with the most?', 'friends'],
  ['The forecast says rain tomorrow.', 'none'],
];
