// Where a species feels at home. A species can like several places: its main habitat (from PokéAPI or
// set in the Data Lab) plus the ones its types suggest (a grass/poison creature likes meadows, forests and
// marshes). Trainers can set the whole list themselves in the Data Lab (species.habitats).

/** Places each type tends to like, best first. */
export const TYPE_HABITATS = {
  grass: ['meadow', 'forest'], bug: ['forest', 'meadow'], poison: ['marsh', 'spooky'], water: ['shoreline', 'marsh'],
  fire: ['volcano', 'desert'], ice: ['tundra'], ground: ['desert', 'cavern'], rock: ['cavern', 'skyline'],
  flying: ['skyline', 'meadow'], electric: ['outskirts', 'skyline'], steel: ['outskirts', 'crystal'],
  psychic: ['starfield', 'crystal'], fairy: ['meadow', 'crystal'], ghost: ['spooky', 'cavern'], dark: ['spooky', 'outskirts'],
  dragon: ['skyline', 'cavern'], fighting: ['skyline', 'outskirts'], normal: ['meadow', 'outskirts'],
};
// the starter set's own type names
const ALIAS = { sprout: 'grass', ember: 'fire', tide: 'water', spark: 'electric', frost: 'ice', spirit: 'ghost', stone: 'rock', gale: 'flying', shade: 'dark', mind: 'psychic', metal: 'steel', wild: 'normal' };

const typeKey = (idx, t) => {
  const k = String(t ?? '').toLowerCase();
  const n = String(idx?.types?.get?.(t)?.name ?? '').toLowerCase();
  return TYPE_HABITATS[k] ? k : TYPE_HABITATS[n] ? n : ALIAS[k] ?? ALIAS[n] ?? null;
};

/** The places a species likes, main one first (2–3 usually). */
export function habitatsOf(idx, sp) {
  if (!sp) return ['meadow'];
  if (Array.isArray(sp.habitats) && sp.habitats.length) return [...new Set([sp.habitats[0], ...sp.habitats])];
  const out = [];
  if (sp.habitat) out.push(sp.habitat);
  const types = (sp.types ?? []).map((t) => typeKey(idx, t)).filter(Boolean);
  // the first type's favourite, then the second type's, then each type's second choice
  for (const i of [0, 1]) for (const t of types) { const b = TYPE_HABITATS[t]?.[i]; if (b && !out.includes(b)) out.push(b); }
  return out.slice(0, 3).length ? out.slice(0, 3) : ['meadow'];
}

/** Does this species like that place? */
export function likesHabitat(idx, sp, biome) { return !!biome && habitatsOf(idx, sp).includes(biome); }

/** Places that are plainly wrong for a type (a fire type in the snow, an ice type by the lava). */
export const TYPE_MISFITS = {
  fire: ['tundra', 'shoreline', 'marsh'], ice: ['volcano', 'desert'], water: ['volcano', 'desert'], grass: ['volcano', 'tundra', 'desert'],
  bug: ['tundra', 'volcano'], electric: ['marsh', 'shoreline'], ghost: ['meadow'], dark: ['meadow'], rock: ['shoreline'], ground: ['shoreline', 'marsh'], fairy: ['spooky', 'volcano'],
};
/** Does this species not belong here at all (so it'd rather keep to the shelter)? */
export function misfitHabitat(idx, sp, biome) {
  if (!sp || !biome || likesHabitat(idx, sp, biome)) return false;
  return (sp.types ?? []).map((t) => typeKey(idx, t)).filter(Boolean).some((t) => (TYPE_MISFITS[t] ?? []).includes(biome));
}
