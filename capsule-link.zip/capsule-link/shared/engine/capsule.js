// Capsule tag format v1.
//
// The capsule is an NFC tag (NTAG215/216 or, ideally, an NTAG I2C plus that the capsule's
// microcontroller can also reach over I2C). User memory (from page 4) holds one NDEF message:
//   record 1: MIME "application/vnd.capsulelink", 160-byte payload = MAIN (128) + WALK (32)
//   record 2: Android Application Record so tapping a capsule opens the phone app
// The MIME type length was chosen so MAIN starts at user byte 32 (page 12, I2C block 3)
// and WALK starts at user byte 160 (page 44, I2C block 11). Both are 16-byte aligned.
// MAIN is written only by the PC/phone. WALK is written by the capsule firmware (steps, bumps)
// and reset by the PC/phone when they sync.
import { TNF, encodeNdefMessage, wrapTlv, findNdefTlv, decodeNdefMessage, concat, toHex } from './ndef.js';
import { STAT_KEYS } from './defaults.js';
import { calcStats, todayKey } from './creature.js';
import { cryFor, CRY_MAX_NOTES } from './cry.js';
import { randomId } from './rng.js';

export const CAPSULE = Object.freeze({
  VERSION: 1,
  MIME: 'application/vnd.capsulelink',
  ANDROID_PACKAGE: 'com.capsulelink.app',
  MAIN_SIZE: 128,
  WALK_SIZE: 32,
  PAYLOAD_SIZE: 160,
  USER_MAIN_OFFSET: 32,
  USER_WALK_OFFSET: 160,
  FIRST_PAGE: 4,
  MAIN_FIRST_PAGE: 12,
  WALK_FIRST_PAGE: 44,
  MODES: ['desk', 'walk', 'battle', 'sleep'],
  STATUS_CODES: [null, 'brn', 'psn', 'par', 'slp', 'frz'],
});

const enc = new TextEncoder();
const dec = new TextDecoder();

export function crc16(bytes, start = 0, end = bytes.length) {
  // CRC-16/CCITT-FALSE: poly 0x1021, init 0xFFFF
  let crc = 0xffff;
  for (let i = start; i < end; i++) {
    crc ^= bytes[i] << 8;
    for (let b = 0; b < 8; b++) crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
  }
  return crc;
}

function writeStr(view, off, len, s) {
  const b = enc.encode(String(s ?? ''));
  let n = Math.min(b.length, len);
  // do not cut a multi-byte character in half
  while (n > 0 && n < b.length && (b[n] & 0xc0) === 0x80) n--;
  for (let i = 0; i < len; i++) view.setUint8(off + i, i < n ? b[i] : 0);
}
function readStr(bytes, off, len) {
  let end = off;
  while (end < off + len && bytes[end] !== 0) end++;
  return dec.decode(bytes.slice(off, end));
}

const hexColor = (c) => {
  const m = /^#?([0-9a-f]{6})$/i.exec(c || '');
  const v = m ? parseInt(m[1], 16) : 0x55ccff;
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
};

/** Encode a creature into the 128-byte MAIN record. */
export function encodeMain(idx, c, opts = {}) {
  const buf = new Uint8Array(CAPSULE.MAIN_SIZE);
  const v = new DataView(buf.buffer);
  const sp = idx.species.get(c.speciesId);
  if (!sp) throw new Error(`Unknown species ${c.speciesId}`);
  buf[0] = 0x43; buf[1] = 0x4c; // "CL"
  buf[2] = CAPSULE.VERSION;
  buf[3] = 0x01; // occupied
  buf[4] = Math.max(0, CAPSULE.MODES.indexOf(opts.mode ?? 'desk'));
  buf[5] = Math.max(0, idx.ds.types.findIndex((t) => t.id === sp.types[0]));
  v.setUint32(6, idx.hash >>> 0);
  const uid = String(c.uid).padStart(16, '0').slice(-16);
  for (let i = 0; i < 8; i++) buf[10 + i] = parseInt(uid.substr(i * 2, 2), 16) || 0;
  v.setUint16(18, sp.no);
  buf[20] = c.level;
  buf[21] = Math.max(0, idx.ds.temperaments.findIndex((t) => t.id === c.temper));
  v.setUint32(22, Math.min(0xffffffff, c.exp >>> 0));
  buf[26] = Math.min(255, c.friendship);
  const n = c.needs || {};
  buf[27] = Math.round(n.fullness ?? 80); buf[28] = Math.round(n.joy ?? 70);
  buf[29] = Math.round(n.energy ?? 90); buf[30] = Math.round(n.hygiene ?? 90);
  buf[31] = Math.max(0, CAPSULE.STATUS_CODES.indexOf(c.status ?? null));
  v.setUint16(32, Math.max(0, Math.min(65535, c.hp ?? calcStats(idx, c).hp)));
  STAT_KEYS.forEach((k, i) => { buf[34 + i] = Math.min(255, c.genes?.[k] ?? 0); buf[40 + i] = Math.min(255, c.effort?.[k] ?? 0); });
  for (let i = 0; i < 4; i++) {
    const m = c.moves[i];
    const mv = m && idx.moves.get(m.id);
    v.setUint16(46 + i * 3, mv ? mv.no : 0);
    buf[48 + i * 3] = mv ? Math.min(255, m.pp ?? mv.pp) : 0;
  }
  v.setUint32(58, (c.walk?.totalSteps ?? 0) >>> 0);
  v.setUint32(62, Math.floor((opts.now ?? Date.now()) / 1000) >>> 0);
  writeStr(v, 66, 12, c.nickname);
  writeStr(v, 78, 10, c.trainer ?? opts.trainer);
  const cry = cryFor(sp).slice(0, CRY_MAX_NOTES);
  buf[88] = cry.length;
  cry.forEach((note, i) => { buf[89 + i * 2] = note.midi; buf[90 + i * 2] = note.ticks; });
  const [r, g, b] = hexColor(opts.ledColor ?? idx.types.get(sp.types[0])?.color);
  buf[113] = r; buf[114] = g; buf[115] = b;
  v.setUint16(116, (opts.syncId ?? 0) & 0xffff);
  v.setUint32(118, (opts.walkCounted ?? 0) >>> 0);
  v.setUint16(126, crc16(buf, 0, 126));
  return buf;
}

export function decodeMain(bytes) {
  if (!bytes || bytes.length < CAPSULE.MAIN_SIZE) return { ok: false, error: 'Record too short' };
  const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes[0] !== 0x43 || bytes[1] !== 0x4c) return { ok: false, error: 'Not a capsule record', empty: bytes.every((b) => b === 0) };
  if (v.getUint16(126) !== crc16(bytes, 0, 126)) return { ok: false, error: 'Capsule data is damaged (checksum mismatch). Write it again from the PC.' };
  if (!(bytes[3] & 1)) return { ok: true, empty: true, rec: { mode: CAPSULE.MODES[bytes[4]] ?? 'desk' } };
  const genes = {}, effort = {};
  STAT_KEYS.forEach((k, i) => { genes[k] = bytes[34 + i]; effort[k] = bytes[40 + i]; });
  const moves = [];
  for (let i = 0; i < 4; i++) {
    const no = v.getUint16(46 + i * 3);
    if (no) moves.push({ no, pp: bytes[48 + i * 3] });
  }
  const cry = [];
  for (let i = 0; i < Math.min(bytes[88], CRY_MAX_NOTES); i++) cry.push({ midi: bytes[89 + i * 2], ticks: bytes[90 + i * 2] });
  return {
    ok: true, empty: false,
    rec: {
      version: bytes[2], flags: bytes[3],
      mode: CAPSULE.MODES[bytes[4]] ?? 'desk',
      typeIndex: bytes[5],
      datasetHash: v.getUint32(6),
      uid: toHex(bytes.slice(10, 18)).toLowerCase(),
      speciesNo: v.getUint16(18),
      level: bytes[20], temperIndex: bytes[21], exp: v.getUint32(22),
      friendship: bytes[26],
      needs: { fullness: bytes[27], joy: bytes[28], energy: bytes[29], hygiene: bytes[30] },
      status: CAPSULE.STATUS_CODES[bytes[31]] ?? null,
      hp: v.getUint16(32), genes, effort, moves,
      totalSteps: v.getUint32(58), updatedAt: v.getUint32(62) * 1000,
      nickname: readStr(bytes, 66, 12), trainer: readStr(bytes, 78, 10),
      cry, led: [bytes[113], bytes[114], bytes[115]],
      syncId: v.getUint16(116), walkCounted: v.getUint32(118),
    },
  };
}

export function emptyMain(mode = 'desk') {
  const buf = new Uint8Array(CAPSULE.MAIN_SIZE);
  buf[0] = 0x43; buf[1] = 0x4c; buf[2] = CAPSULE.VERSION; buf[3] = 0; buf[4] = Math.max(0, CAPSULE.MODES.indexOf(mode));
  new DataView(buf.buffer).setUint16(126, crc16(buf, 0, 126));
  return buf;
}

export function encodeWalk(w = {}) {
  const buf = new Uint8Array(CAPSULE.WALK_SIZE);
  const v = new DataView(buf.buffer);
  buf[0] = 0x57; buf[1] = 0x4b; // "WK"
  v.setUint16(2, (w.syncId ?? 0) & 0xffff);
  v.setUint32(4, (w.steps ?? 0) >>> 0);
  v.setUint16(8, (w.bumpCount ?? 0) & 0xffff);
  v.setUint32(10, (w.lastBumpPeer ?? 0) >>> 0);
  v.setUint32(14, (w.lastBumpAt ?? 0) >>> 0);
  v.setUint16(18, (w.cries ?? 0) & 0xffff);
  v.setUint16(20, (w.wiggles ?? 0) & 0xffff);
  v.setUint16(22, (w.pickups ?? 0) & 0xffff);
  buf[24] = w.battery ?? 255;
  buf[25] = w.fw ?? 0;
  buf[26] = w.flags ?? 0;
  v.setUint16(30, crc16(buf, 0, 30));
  return buf;
}

export function decodeWalk(bytes) {
  if (!bytes || bytes.length < CAPSULE.WALK_SIZE) return { ok: false, error: 'Walk data too short' };
  const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (bytes[0] !== 0x57 || bytes[1] !== 0x4b) return { ok: false, error: 'No walk data' };
  if (v.getUint16(30) !== crc16(bytes, 0, 30)) return { ok: false, error: 'Walk data checksum mismatch' };
  return {
    ok: true,
    walk: {
      syncId: v.getUint16(2), steps: v.getUint32(4), bumpCount: v.getUint16(8),
      lastBumpPeer: v.getUint32(10), lastBumpAt: v.getUint32(14),
      cries: v.getUint16(18), wiggles: v.getUint16(20), pickups: v.getUint16(22),
      battery: bytes[24] === 255 ? null : bytes[24], fw: bytes[25], flags: bytes[26],
    },
  };
}

/** Full user-memory image (from page 4) for formatting or rewriting a capsule. */
export function buildTagImage(mainBytes, walkBytes) {
  const payload = concat([mainBytes, walkBytes]);
  const msg = encodeNdefMessage([
    { tnf: TNF.MIME, type: CAPSULE.MIME, payload },
    { tnf: TNF.EXTERNAL, type: 'android.com:pkg', payload: enc.encode(CAPSULE.ANDROID_PACKAGE) },
  ]);
  const img = wrapTlv(msg);
  // pad to whole pages
  const padded = new Uint8Array(Math.ceil(img.length / 4) * 4);
  padded.set(img);
  return padded;
}

/** Parse tag user memory (bytes from page 4). Returns { ok, main, walk, mainOffset, walkOffset, raw } */
export function parseTagImage(mem) {
  const tlv = findNdefTlv(mem);
  if (!tlv || tlv.message.length === 0) return { ok: false, blank: true, error: 'This tag has no capsule data yet.' };
  let records;
  try { records = decodeNdefMessage(tlv.message); } catch (e) { return { ok: false, error: e.message }; }
  const rec = records.find((r) => r.tnf === TNF.MIME && r.type === CAPSULE.MIME);
  if (!rec) return { ok: false, foreign: true, error: 'This tag holds other data, not a capsule.' };
  if (rec.payload.length < CAPSULE.PAYLOAD_SIZE) return { ok: false, error: 'Capsule record is too short.' };
  const mainOffset = tlv.offset + rec.offset;
  const main = decodeMain(rec.payload.slice(0, CAPSULE.MAIN_SIZE));
  const walk = decodeWalk(rec.payload.slice(CAPSULE.MAIN_SIZE, CAPSULE.PAYLOAD_SIZE));
  return {
    ok: main.ok, error: main.error, main, walk,
    mainOffset, walkOffset: mainOffset + CAPSULE.MAIN_SIZE,
    standardLayout: mainOffset === CAPSULE.USER_MAIN_OFFSET,
  };
}

/** Steps walked since the last sync, safe against a half-finished previous sync. */
export function pendingSteps(mainRec, walk) {
  if (!walk) return 0;
  if (walk.syncId === mainRec.syncId) return walk.steps;
  return Math.max(0, walk.steps - (mainRec.walkCounted ?? 0));
}

export function newSyncId(prev) {
  let id;
  do { id = 1 + Math.floor(Math.random() * 65534); } while (id === prev);
  return id;
}

/** Build a creature object from a capsule record (used when the device has never seen it). */
export function recordToCreature(idx, rec, existing = null, opts = {}) {
  const sp = idx.speciesByNo.get(rec.speciesNo);
  if (!sp) throw new Error(`Species #${rec.speciesNo} is not in this dataset.`);
  const moves = rec.moves.map((m) => {
    const mv = idx.movesByNo.get(m.no);
    return mv ? { id: mv.id, pp: Math.min(m.pp, mv.pp) } : null;
  }).filter(Boolean);
  const now = opts.now ?? Date.now();
  const c = existing ? existing : {
    uid: rec.uid || randomId(8), memories: [], metAt: now, metLevel: rec.level, metHow: 'Arrived in a capsule',
    careToday: { day: todayKey(now), friendship: 0 }, rev: 0,
    walk: { totalSteps: 0, day: todayKey(now), todaySteps: 0, stepsSinceFind: 0 },
  };
  Object.assign(c, {
    speciesId: sp.id, nickname: rec.nickname, level: rec.level, exp: rec.exp,
    genes: rec.genes, effort: rec.effort,
    temper: idx.ds.temperaments[rec.temperIndex]?.id ?? c.temper ?? null,
    moves, hp: rec.hp, status: rec.status, friendship: rec.friendship,
    needs: { ...rec.needs }, needsAt: Math.min(now, rec.updatedAt || now),
    trainer: rec.trainer || c.trainer || '',
  });
  c.walk = c.walk || { totalSteps: 0, day: todayKey(now), todaySteps: 0, stepsSinceFind: 0 };
  c.walk.totalSteps = Math.max(c.walk.totalSteps ?? 0, rec.totalSteps);
  return c;
}

/** Field-by-field description of the layout (used in docs and the dock screen). */
export const MAIN_LAYOUT = [
  [0, 2, 'magic "CL"'], [2, 1, 'format version'], [3, 1, 'flags (bit0 = holds a creature)'],
  [4, 1, 'mode 0 desk / 1 walk / 2 battle / 3 sleep'], [5, 1, 'primary type index'],
  [6, 4, 'dataset fingerprint'], [10, 8, 'creature uid'], [18, 2, 'species number'],
  [20, 1, 'level'], [21, 1, 'temperament index'], [22, 4, 'experience'], [26, 1, 'friendship'],
  [27, 4, 'needs: fullness, joy, energy, tidiness'], [31, 1, 'status'], [32, 2, 'current HP'],
  [34, 6, 'genes (hp atk def spa spd spe)'], [40, 6, 'effort (same order)'],
  [46, 12, '4 moves: uint16 move number + uint8 PP'], [58, 4, 'total steps walked'],
  [62, 4, 'updated at (unix seconds)'], [66, 12, 'nickname (UTF-8)'], [78, 10, 'trainer (UTF-8)'],
  [88, 1, 'cry note count'], [89, 24, 'cry: 12 × (MIDI note, ticks of 40 ms)'],
  [113, 3, 'LED colour RGB'], [116, 2, 'sync id of last sync'], [118, 4, 'walk steps already counted'],
  [122, 4, 'reserved'], [126, 2, 'CRC-16/CCITT-FALSE of bytes 0–125'],
];
export const WALK_LAYOUT = [
  [0, 2, 'magic "WK"'], [2, 2, 'sync id (set by PC/phone on reset)'], [4, 4, 'steps since reset'],
  [8, 2, 'bump count'], [10, 4, 'last bumped capsule (low 4 UID bytes)'], [14, 4, 'last bump time (capsule seconds)'],
  [18, 2, 'cries played'], [20, 2, 'wiggles'], [22, 2, 'times picked up'], [24, 1, 'battery % (255 unknown)'],
  [25, 1, 'firmware version'], [26, 1, 'flags'], [27, 3, 'reserved'], [30, 2, 'CRC-16 of bytes 0–29'],
];
