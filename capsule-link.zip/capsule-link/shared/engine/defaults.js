// Starter dataset: original placeholder creatures, moves and rules.
// Everything here is meant to be replaced from the Data Lab by pasting your own data.

export const STAT_KEYS = ['hp', 'atk', 'def', 'spa', 'spd', 'spe'];

export const DEFAULT_STAT_LABELS = {
  hp: 'HP', atk: 'Attack', def: 'Defense', spa: 'Sp. Attack', spd: 'Sp. Defense', spe: 'Speed',
};

const types = [
  { id: 'plain', name: 'Plain', color: '#b8b19a' },
  { id: 'ember', name: 'Ember', color: '#f0743c' },
  { id: 'tide', name: 'Tide', color: '#4a8de8' },
  { id: 'sprout', name: 'Sprout', color: '#5cbf4c' },
  { id: 'volt', name: 'Volt', color: '#f2cc2e' },
  { id: 'frost', name: 'Frost', color: '#7fd6e6' },
  { id: 'stone', name: 'Stone', color: '#a8875a' },
  { id: 'gale', name: 'Gale', color: '#9fb4f2' },
  { id: 'brawl', name: 'Brawl', color: '#c4453d' },
  { id: 'shade', name: 'Shade', color: '#6a4f8f' },
  { id: 'mind', name: 'Mind', color: '#ee6fa6' },
  { id: 'metal', name: 'Metal', color: '#9aa3b5' },
];

// attacker -> defender -> multiplier (missing = 1)
const typeChart = {
  plain: { stone: 0.5, metal: 0.5, shade: 0 },
  ember: { sprout: 2, frost: 2, metal: 2, tide: 0.5, stone: 0.5, ember: 0.5 },
  tide: { ember: 2, stone: 2, sprout: 0.5, tide: 0.5 },
  sprout: { tide: 2, stone: 2, ember: 0.5, gale: 0.5, sprout: 0.5, metal: 0.5 },
  volt: { tide: 2, gale: 2, stone: 0, sprout: 0.5, volt: 0.5 },
  frost: { sprout: 2, gale: 2, ember: 0.5, metal: 0.5, frost: 0.5 },
  stone: { ember: 2, gale: 2, frost: 2, brawl: 0.5, metal: 0.5 },
  gale: { sprout: 2, brawl: 2, volt: 0.5, stone: 0.5, metal: 0.5 },
  brawl: { plain: 2, stone: 2, metal: 2, frost: 2, gale: 0.5, mind: 0.5, shade: 0.5 },
  shade: { mind: 2, shade: 0.5, brawl: 0.5 },
  mind: { brawl: 2, mind: 0.5, metal: 0.5, shade: 0 },
  metal: { stone: 2, frost: 2, ember: 0.5, tide: 0.5, metal: 0.5 },
};

// 25 temperaments: one raised stat and one lowered stat (same stat = neutral)
const TEMPER_STATS = ['atk', 'def', 'spa', 'spd', 'spe'];
const TEMPER_NAMES = [
  'Steady', 'Gruff', 'Fierce', 'Stubborn', 'Rowdy',
  'Sturdy', 'Mellow', 'Prickly', 'Lazy', 'Stoic',
  'Wise', 'Dreamy', 'Earnest', 'Reckless', 'Pensive',
  'Serene', 'Tender', 'Wary', 'Whimsical', 'Sulky',
  'Skittish', 'Eager', 'Cheery', 'Flighty', 'Breezy',
];
const temperaments = TEMPER_NAMES.map((name, i) => {
  const up = TEMPER_STATS[Math.floor(i / 5)];
  const down = TEMPER_STATS[i % 5];
  return { id: name.toLowerCase(), name, up: up === down ? null : up, down: up === down ? null : down };
});

const growthRates = [
  { id: 'quick', name: 'Quick', formula: 'floor(0.8 * n^3)' },
  { id: 'steady', name: 'Steady', formula: 'n^3' },
  { id: 'slow', name: 'Slow', formula: 'floor(1.25 * n^3)' },
  { id: 'wavy', name: 'Wavy', formula: 'max(0, floor(1.2*n^3 - 15*n^2 + 100*n - 140))' },
  {
    id: 'erratic', name: 'Erratic',
    formula: 'n < 50 ? floor(n^3 * (100 - n) / 50)\n: n < 68 ? floor(n^3 * (150 - n) / 100)\n: n < 98 ? floor(n^3 * floor((1911 - 10*n) / 3) / 500)\n: floor(n^3 * (160 - n) / 100)',
  },
  {
    id: 'fluctuating', name: 'Fluctuating',
    formula: 'n < 15 ? floor(n^3 * (floor((n + 1) / 3) + 24) / 50)\n: n < 36 ? floor(n^3 * (n + 14) / 50)\n: floor(n^3 * (floor(n / 2) + 32) / 50)',
  },
];

const statuses = [
  { id: 'brn', name: 'Scorched', short: 'SCR', color: '#f0743c' },
  { id: 'psn', name: 'Blighted', short: 'BLT', color: '#9b59b6' },
  { id: 'par', name: 'Jolted', short: 'JLT', color: '#f2cc2e' },
  { id: 'slp', name: 'Asleep', short: 'SLP', color: '#8d99ae' },
  { id: 'frz', name: 'Chilled', short: 'CHL', color: '#7fd6e6' },
];

export const DEFAULT_FORMULAS = {
  hpStat: {
    label: 'HP stat',
    vars: 'base, genes, effort, level',
    src: 'floor((2*base + genes + effort/4) * level / 100) + level + 10',
  },
  stat: {
    label: 'Other stats (shown in the apps; Showdown works out its own in battle)',
    vars: 'base, genes, effort, level, temper (1.1 raised / 0.9 lowered / 1)',
    src: 'floor((floor((2*base + genes + effort/4) * level / 100) + 5) * temper)',
  },
  expGain: {
    label: 'Experience after a Showdown battle (per defeated foe)',
    vars: 'baseExp (foe species), foeLevel, level (yours), participants (yours that faced it), linked (always 1)',
    src: 'floor(baseExp * foeLevel / 7 * (linked ? 1.5 : 1) / max(1, participants))',
  },
  walkFriendship: {
    label: 'Friendship from walking',
    vars: 'steps (since last sync), friendship (0–255)',
    src: 'floor(steps / (friendship < 150 ? 160 : 320))',
  },
  walkExp: {
    label: 'Experience from walking',
    vars: 'steps, level',
    src: 'floor(steps / 40)',
  },
  walkFindChance: {
    label: 'Chance to find an item per 500 steps (%)',
    vars: 'friendship',
    src: '20 + friendship / 10',
  },
};

const R = (no, id, name, type, category, power, accuracy, pp, extra = {}) => ({
  no, id, name, type, category, power, accuracy, pp, priority: 0, ...extra,
});

const moves = [
  R(1, 'nudge', 'Nudge', 'plain', 'physical', 40, 100, 35, { desc: 'A friendly shove.' }),
  R(2, 'quick-dart', 'Quick Dart', 'plain', 'physical', 40, 100, 30, { priority: 1, desc: 'Always strikes first.' }),
  R(3, 'rush', 'Rush', 'plain', 'physical', 75, 90, 20, { desc: 'A headlong charge.' }),
  R(4, 'cheer', 'Cheer', 'plain', 'status', 0, null, 20, { effect: { boost: { atk: 1 }, target: 'self' }, desc: 'Raises own Attack.' }),
  R(5, 'stare-down', 'Stare Down', 'plain', 'status', 0, 100, 30, { effect: { boost: { def: -1 }, target: 'foe' }, desc: "Lowers the foe's Defense." }),
  R(6, 'rest-up', 'Rest Up', 'plain', 'status', 0, null, 10, { effect: { heal: 0.5 }, desc: 'Restores half of max HP.' }),
  R(7, 'cinder', 'Cinder', 'ember', 'special', 40, 100, 25, { effect: { status: 'brn', chance: 10 }, desc: 'May scorch the foe.' }),
  R(8, 'flare-rush', 'Flare Rush', 'ember', 'physical', 80, 95, 15, { effect: { recoil: 0.25 }, desc: 'Hurts the user a little.' }),
  R(9, 'kiln-blast', 'Kiln Blast', 'ember', 'special', 100, 85, 5, { effect: { status: 'brn', chance: 30 }, desc: 'Intense heat. May scorch.' }),
  R(10, 'spritz', 'Spritz', 'tide', 'special', 40, 100, 25, { desc: 'A cold splash of water.' }),
  R(11, 'riptide', 'Riptide', 'tide', 'physical', 75, 95, 15, { desc: 'Drags the foe under.' }),
  R(12, 'tidal-crash', 'Tidal Crash', 'tide', 'special', 105, 80, 5, { desc: 'A crushing wave.' }),
  R(13, 'leaf-flick', 'Leaf Flick', 'sprout', 'special', 40, 100, 25, { desc: 'Flicks sharp leaves.' }),
  R(14, 'vine-lash', 'Vine Lash', 'sprout', 'physical', 65, 100, 20, { desc: 'Whips with vines.' }),
  R(15, 'sap-drain', 'Sap Drain', 'sprout', 'special', 60, 100, 15, { effect: { drain: 0.5 }, desc: 'Heals by half the damage dealt.' }),
  R(16, 'spore-cloud', 'Spore Cloud', 'sprout', 'status', 0, 75, 15, { effect: { status: 'slp', target: 'foe' }, desc: 'Puts the foe to sleep.' }),
  R(17, 'static-nip', 'Static Nip', 'volt', 'physical', 45, 100, 30, { effect: { status: 'par', chance: 30 }, desc: 'May jolt the foe.' }),
  R(18, 'arc-bolt', 'Arc Bolt', 'volt', 'special', 85, 100, 15, { effect: { status: 'par', chance: 10 }, desc: 'May jolt the foe.' }),
  R(19, 'stun-pulse', 'Stun Pulse', 'volt', 'status', 0, 90, 20, { effect: { status: 'par', target: 'foe' }, desc: 'Jolts the foe.' }),
  R(20, 'rime-shard', 'Rime Shard', 'frost', 'special', 40, 100, 25, { desc: 'Throws shards of ice.' }),
  R(21, 'glacier-fang', 'Glacier Fang', 'frost', 'physical', 70, 95, 15, { effect: { status: 'frz', chance: 10 }, desc: 'May chill the foe solid.' }),
  R(22, 'whiteout', 'Whiteout', 'frost', 'special', 100, 75, 5, { effect: { status: 'frz', chance: 10 }, desc: 'A blinding blizzard.' }),
  R(23, 'pebble-toss', 'Pebble Toss', 'stone', 'physical', 45, 100, 30, { desc: 'Pelts small stones.' }),
  R(24, 'quarry-crush', 'Quarry Crush', 'stone', 'physical', 90, 90, 10, { desc: 'Drops a slab of rock.' }),
  R(25, 'bulwark', 'Bulwark', 'stone', 'status', 0, null, 20, { effect: { boost: { def: 1, spd: 1 }, target: 'self' }, desc: 'Raises both defenses.' }),
  R(26, 'gust-cutter', 'Gust Cutter', 'gale', 'special', 45, 100, 30, { effect: { critStage: 1 }, desc: 'Lands critical hits more often.' }),
  R(27, 'skydive', 'Skydive', 'gale', 'physical', 85, 90, 10, { desc: 'Dives from high above.' }),
  R(28, 'updraft', 'Updraft', 'gale', 'status', 0, null, 20, { effect: { boost: { spe: 2 }, target: 'self' }, desc: 'Sharply raises Speed.' }),
  R(29, 'jab-combo', 'Jab Combo', 'brawl', 'physical', 18, 100, 20, { effect: { hits: [2, 5] }, desc: 'Hits 2 to 5 times.' }),
  R(30, 'haymaker', 'Haymaker', 'brawl', 'physical', 95, 85, 10, { desc: 'One huge swing.' }),
  R(31, 'focus-up', 'Focus Up', 'brawl', 'status', 0, null, 20, { effect: { boost: { atk: 2 }, target: 'self' }, desc: 'Sharply raises Attack.' }),
  R(32, 'gloom-pulse', 'Gloom Pulse', 'shade', 'special', 75, 100, 15, { effect: { flinch: 20 }, desc: 'May make the foe flinch.' }),
  R(33, 'umbral-bite', 'Umbral Bite', 'shade', 'physical', 70, 100, 15, { desc: 'Bites from the shadows.' }),
  R(34, 'blight-mist', 'Blight Mist', 'shade', 'status', 0, 90, 15, { effect: { status: 'psn', target: 'foe' }, desc: 'Blights the foe.' }),
  R(35, 'mind-poke', 'Mind Poke', 'mind', 'special', 45, 100, 25, { desc: 'A sharp thought.' }),
  R(36, 'thought-lance', 'Thought Lance', 'mind', 'special', 90, 100, 10, { effect: { boost: { spd: -1 }, target: 'foe', chance: 10 }, desc: 'May lower Sp. Defense.' }),
  R(37, 'daydream', 'Daydream', 'mind', 'status', 0, null, 10, { effect: { heal: 0.5 }, desc: 'Restores half of max HP.' }),
  R(38, 'gear-grind', 'Gear Grind', 'metal', 'physical', 40, 90, 15, { effect: { hits: [2, 2] }, desc: 'Hits twice.' }),
  R(39, 'rivet-strike', 'Rivet Strike', 'metal', 'physical', 80, 100, 15, { desc: 'Drives in like a rivet.' }),
  R(40, 'plate-up', 'Plate Up', 'metal', 'status', 0, null, 15, { effect: { boost: { def: 2 }, target: 'self' }, desc: 'Sharply raises Defense.' }),
];

const L = (...pairs) => {
  const out = [];
  for (let i = 0; i < pairs.length; i += 2) out.push({ level: pairs[i], move: pairs[i + 1] });
  return out;
};

const S = (no, id, name, typesArr, stats, extra) => {
  const [hp, atk, def, spa, spd, spe] = stats;
  return {
    no, id, name, types: typesArr,
    baseStats: { hp, atk, def, spa, spd, spe },
    growthRate: 'steady', baseExp: 64, baseFriendship: 70,
    effortYield: {}, habitat: 'meadow', cry: '', flavor: '',
    learnset: [], evolutions: [],
    ...extra,
  };
};

const species = [
  S(1, 'sproutle', 'Sproutle', ['sprout'], [48, 50, 52, 58, 60, 42], {
    growthRate: 'slow', baseExp: 62, habitat: 'forest', effortYield: { spa: 1 },
    cry: 'E5:2 G5:2 C6:4', flavor: 'Naps in sunbeams. The bud on its head opens when it is happy.',
    learnset: L(1, 'nudge', 1, 'stare-down', 5, 'leaf-flick', 9, 'vine-lash', 14, 'sap-drain', 19, 'spore-cloud', 26, 'bulwark'),
    evolutions: [{ to: 'thornback', method: 'level', value: 20 }],
  }),
  S(2, 'thornback', 'Thornback', ['sprout', 'stone'], [74, 82, 92, 76, 80, 51], {
    growthRate: 'slow', baseExp: 160, habitat: 'forest', effortYield: { def: 2 },
    cry: 'C4:4 E4:2 G3:6', flavor: 'Its mossy shell is home to tiny flowers.',
    learnset: L(1, 'nudge', 1, 'leaf-flick', 20, 'quarry-crush', 30, 'sap-drain', 38, 'bulwark'),
  }),
  S(3, 'cindrop', 'Cindrop', ['ember'], [42, 56, 40, 62, 46, 66], {
    growthRate: 'slow', baseExp: 62, habitat: 'volcano', effortYield: { spe: 1 },
    cry: 'A5:1 C6:1 E6:2 A6:3', flavor: 'A flickering droplet of flame that follows warm hands.',
    learnset: L(1, 'nudge', 1, 'cheer', 5, 'cinder', 10, 'quick-dart', 15, 'flare-rush', 25, 'kiln-blast'),
    evolutions: [{ to: 'pyrewing', method: 'level', value: 22 }],
  }),
  S(4, 'pyrewing', 'Pyrewing', ['ember', 'gale'], [70, 84, 68, 98, 74, 96], {
    growthRate: 'slow', baseExp: 170, habitat: 'volcano', effortYield: { spa: 2 },
    cry: 'E5:2 B5:2 E6:6', flavor: 'Rides rising heat from vents to soar for hours.',
    learnset: L(1, 'cinder', 1, 'gust-cutter', 22, 'skydive', 32, 'updraft', 40, 'kiln-blast'),
  }),
  S(5, 'puddlop', 'Puddlop', ['tide'], [55, 48, 58, 52, 56, 40], {
    growthRate: 'slow', baseExp: 62, habitat: 'shoreline', effortYield: { hp: 1 },
    cry: 'C5:2 C5:1 G4:4', flavor: 'Wobbles like jelly. Leaves a damp spot wherever it sits.',
    learnset: L(1, 'nudge', 1, 'stare-down', 4, 'spritz', 11, 'riptide', 17, 'rest-up', 27, 'tidal-crash'),
    evolutions: [{ to: 'tidecrest', method: 'level', value: 21 }],
  }),
  S(6, 'tidecrest', 'Tidecrest', ['tide', 'mind'], [88, 64, 80, 96, 92, 58], {
    growthRate: 'slow', baseExp: 168, habitat: 'seafloor', effortYield: { spd: 2 },
    cry: 'G4:4 D5:4 G5:6', flavor: 'Hums to the tide. Sailors say it can hear storms coming.',
    learnset: L(1, 'spritz', 1, 'mind-poke', 21, 'thought-lance', 30, 'daydream', 36, 'tidal-crash'),
  }),
  S(7, 'zapkit', 'Zapkit', ['volt'], [40, 52, 38, 56, 44, 82], {
    growthRate: 'steady', baseExp: 60, habitat: 'meadow', effortYield: { spe: 1 },
    cry: 'B5:1 B5:1 F6:3', flavor: 'Gets more sparks in its fur the longer you walk together.',
    learnset: L(1, 'quick-dart', 1, 'static-nip', 8, 'cheer', 13, 'stun-pulse', 20, 'arc-bolt'),
    evolutions: [{ to: 'stormlynx', method: 'friendship', value: 200 }],
  }),
  S(8, 'stormlynx', 'Stormlynx', ['volt'], [65, 88, 60, 96, 72, 118], {
    growthRate: 'steady', baseExp: 175, habitat: 'skyline', effortYield: { spe: 2 },
    cry: 'F5:1 B5:1 F6:2 B6:4', flavor: 'Only bonds with someone who has walked many miles beside it.',
    learnset: L(1, 'arc-bolt', 1, 'quick-dart', 30, 'updraft', 40, 'haymaker'),
  }),
  S(9, 'frostuft', 'Frostuft', ['frost'], [52, 46, 54, 60, 62, 44], {
    growthRate: 'steady', baseExp: 60, habitat: 'tundra', effortYield: { spd: 1 },
    cry: 'D6:2 A5:2 D6:2 F6:4', flavor: 'A puff of snow that refuses to melt.',
    learnset: L(1, 'nudge', 1, 'rime-shard', 9, 'stare-down', 15, 'glacier-fang', 24, 'whiteout'),
    evolutions: [{ to: 'glaciox', method: 'steps', value: 10000 }],
  }),
  S(10, 'glaciox', 'Glaciox', ['frost', 'metal'], [82, 92, 108, 78, 88, 52], {
    growthRate: 'steady', baseExp: 172, habitat: 'tundra', effortYield: { def: 2 },
    cry: 'A3:4 E4:4 A4:6', flavor: 'Formed after a long trek through snow. Its horns ring like bells.',
    learnset: L(1, 'glacier-fang', 1, 'plate-up', 30, 'rivet-strike', 40, 'whiteout'),
  }),
  S(11, 'mossling', 'Mossling', ['sprout', 'plain'], [70, 55, 65, 55, 70, 50], {
    growthRate: 'quick', baseExp: 90, habitat: 'marsh', baseFriendship: 100, effortYield: { hp: 2 },
    cry: 'G5:2 E5:2 C5:2 G5:4', flavor: 'Loves being brushed. Rolls in dew every morning.',
    learnset: L(1, 'nudge', 1, 'leaf-flick', 6, 'cheer', 12, 'sap-drain', 18, 'rest-up', 25, 'rush'),
  }),
  S(12, 'gloomoth', 'Gloomoth', ['shade', 'gale'], [60, 50, 55, 85, 75, 90], {
    growthRate: 'quick', baseExp: 140, habitat: 'starfield', effortYield: { spa: 1, spe: 1 },
    cry: 'C5:3 B4:3 A#4:3 A4:6', flavor: 'Drawn to screens left on late at night.',
    learnset: L(1, 'gust-cutter', 1, 'blight-mist', 10, 'gloom-pulse', 18, 'mind-poke', 26, 'updraft'),
  }),
  S(13, 'cogsy', 'Cogsy', ['metal'], [55, 70, 90, 45, 60, 45], {
    growthRate: 'steady', baseExp: 110, habitat: 'skyline', effortYield: { def: 1 },
    cry: 'C5:1 C6:1 C5:1 C6:1 G5:4', flavor: 'Ticks quietly. Winds itself up when nobody is looking.',
    learnset: L(1, 'nudge', 1, 'gear-grind', 10, 'plate-up', 18, 'rivet-strike', 28, 'quarry-crush'),
  }),
  S(14, 'mindle', 'Mindle', ['mind'], [58, 40, 50, 88, 80, 72], {
    growthRate: 'quick', baseExp: 120, habitat: 'crystal', effortYield: { spa: 1 },
    cry: 'E6:2 G#6:2 B6:2 E7:4', flavor: 'Floats an inch off the ground when lost in thought.',
    learnset: L(1, 'mind-poke', 1, 'daydream', 12, 'stare-down', 20, 'thought-lance'),
  }),
  S(15, 'pugnacub', 'Pugnacub', ['brawl'], [72, 90, 60, 35, 55, 60], {
    growthRate: 'quick', baseExp: 115, habitat: 'desert', effortYield: { atk: 1 },
    cry: 'G4:1 G4:1 C5:4', flavor: 'Shadowboxes its own reflection for practice.',
    learnset: L(1, 'nudge', 1, 'focus-up', 8, 'jab-combo', 16, 'pebble-toss', 24, 'haymaker'),
  }),
];

const items = [
  { id: 'kibble', name: 'Kibble', kind: 'food', fullness: 30, joy: 2, desc: 'Everyday food. Never runs out.', unlimited: true },
  { id: 'sweetroot', name: 'Sweetroot', kind: 'food', fullness: 25, joy: 12, friendship: 2, grow: { hours: 3, yield: 3 }, desc: 'A crunchy treat found on walks. Grows on the berry farm.' },
  { id: 'bramble-berry', name: 'Bramble Berry', kind: 'food', fullness: 15, joy: 15, friendship: 2, grow: { hours: 2, yield: 3 }, color: '#c0306a', desc: 'Tart and juicy. Quick to grow.' },
  { id: 'glow-berry', name: 'Glow Berry', kind: 'food', fullness: 8, joy: 25, energy: 10, friendship: 3, grow: { hours: 6, yield: 2 }, color: '#4ad0ff', desc: 'Faintly glowing. Takes a while to ripen.' },
  { id: 'honey-drop', name: 'Honey Drop', kind: 'food', fullness: 10, joy: 20, friendship: 3, desc: 'Sticky and very popular.' },
  { id: 'sun-biscuit', name: 'Sun Biscuit', kind: 'food', fullness: 40, joy: 8, energy: 15, desc: 'Restores energy.' },
  { id: 'toy-ball', name: 'Toy Ball', kind: 'toy', joy: 25, energy: -10, friendship: 2, desc: 'Throw it in the ranch.', unlimited: true },
  { id: 'brush', name: 'Brush', kind: 'groom', hygiene: 40, joy: 8, friendship: 1, desc: 'Keeps coats and scales tidy.', unlimited: true },
  { id: 'bubble-soap', name: 'Bubble Soap', kind: 'groom', hygiene: 80, joy: 4, desc: 'For a full bath.' },
  { id: 'shiny-pebble', name: 'Shiny Pebble', kind: 'keepsake', desc: 'Found while walking. Pretty, but useless.' },
];

export const DEFAULT_RULES = {
  maxLevel: 100,
  maxFriendship: 255,
  maxEffortPerStat: 252,
  maxEffortTotal: 510,
  maxGenes: 31,
  partySize: 6,
  boxCount: 12,
  boxSlots: 30,
  needsDecayPerHour: { fullness: 4, joy: 3, hygiene: 2, energy: 3 },
  needsFloor: 10,
  careFriendshipPerDay: 12,
  walkDailyStepCap: 40000,
  stepsPerFind: 500,
  sleepHours: [22, 7],
};

export function createDefaultDataset() {
  return JSON.parse(JSON.stringify({
    meta: { name: 'Starter set', version: 1, author: 'Capsule Link', note: 'Original placeholder data — replace it in the Data Lab.' },
    statLabels: DEFAULT_STAT_LABELS,
    types, typeChart, temperaments, growthRates, statuses,
    formulas: Object.fromEntries(Object.entries(DEFAULT_FORMULAS).map(([k, v]) => [k, v.src])),
    species, moves, items,
    rules: DEFAULT_RULES,
  }));
}
