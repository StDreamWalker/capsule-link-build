// Trainer ID cards: the data behind the card each profile carries.
// The card lives in save.trainer.card, so it travels to phones with every sync.
// Card designs are original and fictional; they borrow only the idea that ID cards around the
// world come in many shapes (landscape cards, booklet pages, portrait badges…).
//
// The card's own colours (accent, accent2, pattern, finish) are separate from what the portrait
// wears, so you can dress one way and carry a card of a different colour.
// The portrait is either drawn from options below or a trainer picture you add
// (textures/trainers/<name>.png), referenced by avatar.sprite.

export const CARD_DESIGNS = [
  { id: 'classic', name: 'Classic', orient: 'landscape' },
  { id: 'booklet', name: 'Booklet page', orient: 'landscape' },
  { id: 'badge', name: 'Lanyard badge', orient: 'portrait' },
  { id: 'aurora', name: 'Aurora holo', orient: 'landscape' },
  { id: 'heritage', name: 'Heritage', orient: 'landscape' },
  { id: 'transit', name: 'Metro', orient: 'landscape' },
  { id: 'field', name: 'Field license', orient: 'portrait' },
  { id: 'neon', name: 'Neon grid', orient: 'landscape' },
];

export const CARD_TITLES = ['Trainer', 'Ranger', 'Breeder', 'Researcher', 'Collector', 'Walker', 'Explorer', 'Caretaker', 'Ace Trainer', 'Scientist', 'Hiker', 'Swimmer', 'Champion', 'Professor', 'Gym Leader', 'Coordinator'];

export const CARD_ACCENTS = ['#5b45c4', '#e5484d', '#ff8a3d', '#ffc93c', '#3fb26a', '#34d1bf', '#3d7bff', '#c04fd8', '#ff5d8f', '#4a4670', '#1b1838', '#8a5a2a', '#9aa4b2', '#0e7c86'];
export const CARD_PATTERNS = ['none', 'guilloche', 'dots', 'stripes', 'waves', 'grid', 'stars', 'chevron', 'topo', 'hex'];
export const CARD_FINISHES = ['gloss', 'matte', 'holo', 'metal'];

const PALETTE = ['#e5484d', '#ff8a3d', '#ffc93c', '#3fb26a', '#34d1bf', '#3d7bff', '#5b45c4', '#c04fd8', '#ff5d8f', '#1b1838', '#4a4670', '#9aa4b2', '#ffffff', '#8a5a2a'];

export const AVATAR_OPTIONS = {
  skin: ['#ffe8d6', '#ffe0c7', '#f6c9a0', '#eab58c', '#e2a77a', '#c4875a', '#a8703f', '#9a6440', '#6e4428', '#4a2c1a'],
  hair: ['short', 'sidepart', 'long', 'wavy', 'ponytail', 'pigtails', 'spiky', 'messy', 'bob', 'bun', 'twinbuns', 'braids', 'curly', 'afro', 'mohawk', 'undercut', 'buzz', 'bald'],
  hairColor: ['#1b1838', '#2b2118', '#3a2a1a', '#6b3f1f', '#8b4a22', '#a8662c', '#c98a3a', '#e8c46a', '#f3e2a6', '#d9d4e8', '#8c8c99', '#e5484d', '#ff5d8f', '#c04fd8', '#3d7bff', '#3fb26a'],
  eyes: ['round', 'wide', 'lashes', 'sharp', 'narrow', 'happy', 'sleepy', 'wink'],
  eyeColor: ['#1b1838', '#5a3a22', '#8a5a2a', '#2f6fd0', '#2f9a5a', '#7a4fc4', '#c0392b', '#7a8796'],
  brows: ['soft', 'bold', 'angled', 'raised', 'thin', 'none'],
  mouth: ['smile', 'grin', 'neutral', 'open', 'smirk', 'pout'],
  facialHair: ['none', 'stubble', 'mustache', 'beard', 'goatee'],
  hat: ['none', 'cap', 'backwards', 'beanie', 'bucket', 'visor', 'sunhat', 'beret', 'bandana'],
  hatColor: PALETTE,
  outfitStyle: ['tee', 'hoodie', 'jacket', 'vest', 'uniform', 'sweater', 'coat', 'track', 'dress', 'overalls'],
  outfit: PALETTE,
  outfit2: PALETTE,
  accessories: ['glasses', 'roundglasses', 'shades', 'goggles', 'headband', 'headphones', 'earrings', 'necklace', 'scarf', 'backpack', 'flower', 'freckles', 'blush', 'bandaid', 'beautymark', 'eyepatch', 'mask'],
  bg: ['auto', '#dfe7ff', '#ffe3e3', '#fff1c9', '#dcf5e4', '#d9f5f2', '#efe0ff', '#2a2848', '#ffffff'],
};
export const MAX_ACCESSORIES = 4;

/** "0482-1377" style number from the trainer id (stable for a profile). */
export function trainerNumber(id) {
  let h = 2166136261;
  for (const ch of String(id ?? '')) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619) >>> 0; }
  const n = String(h % 100000000).padStart(8, '0');
  return `${n.slice(0, 4)}-${n.slice(4)}`;
}

function pick(list, h, salt) { return list[(h >>> salt) % list.length]; }

/** A random drawn portrait (for "Shuffle" and new profiles). */
export function randomAvatar(rand = Math.random) {
  const r = (l) => l[Math.floor(rand() * l.length)];
  const acc = AVATAR_OPTIONS.accessories.filter(() => rand() < 0.12).slice(0, 2);
  return {
    sprite: '', skin: r(AVATAR_OPTIONS.skin), hair: r(AVATAR_OPTIONS.hair), hairColor: r(AVATAR_OPTIONS.hairColor),
    eyes: r(AVATAR_OPTIONS.eyes), eyeColor: r(AVATAR_OPTIONS.eyeColor), brows: r(AVATAR_OPTIONS.brows.slice(0, 5)), mouth: r(AVATAR_OPTIONS.mouth),
    facialHair: rand() < 0.15 ? r(AVATAR_OPTIONS.facialHair.slice(1)) : 'none', hat: rand() < 0.3 ? r(AVATAR_OPTIONS.hat.slice(1)) : 'none',
    hatColor: r(PALETTE), outfitStyle: r(AVATAR_OPTIONS.outfitStyle), outfit: r(PALETTE), outfit2: r(PALETTE), accessories: acc, bg: 'auto',
  };
}

/** A first card, varied by the trainer id so new profiles do not all look alike. */
export function defaultTrainerCard(name = 'Trainer', id = '') {
  let h = 7;
  for (const ch of `${name}:${id}`) h = (Math.imul(h, 31) + ch.charCodeAt(0)) >>> 0;
  let s = h;
  const rand = () => { s = (Math.imul(s, 1103515245) + 12345) >>> 0; return (s >>> 8) / 16777216; };
  return normalizeCard({
    design: pick(CARD_DESIGNS, h, 1).id,
    accent: pick(CARD_ACCENTS, h, 4),
    title: 'Trainer',
    region: '',
    motto: '',
    issued: Date.now(),
    avatar: { ...randomAvatar(rand), hat: 'none', facialHair: 'none', accessories: [] },
  });
}

const isColor = (c) => typeof c === 'string' && /^#[0-9a-f]{6}$/i.test(c);
const isSprite = (s) => typeof s === 'string' && /^trainers\/[^/]+\.png$/i.test(s);

/** Fill in anything missing and drop anything unknown, so a card from any version renders. */
export function normalizeCard(card) {
  const c = card && typeof card === 'object' ? card : {};
  const a = c.avatar && typeof c.avatar === 'object' ? c.avatar : {};
  const one = (v, list, d) => (list.includes(v) ? v : d);
  const O = AVATAR_OPTIONS;
  // older cards: hats were hair styles and there was a single accessory
  let hair = a.hair, hat = a.hat;
  if (hair === 'cap' || hair === 'beanie') { hat = hat ?? hair; hair = 'short'; }
  let acc = Array.isArray(a.accessories) ? a.accessories : a.accessory && a.accessory !== 'none' ? [a.accessory] : [];
  acc = [...new Set(acc.filter((x) => O.accessories.includes(x)))].slice(0, MAX_ACCESSORIES);
  const accent = isColor(c.accent) ? c.accent : CARD_ACCENTS[0];
  return {
    design: one(c.design, CARD_DESIGNS.map((d) => d.id), 'classic'),
    accent,
    accent2: isColor(c.accent2) ? c.accent2 : null,
    pattern: one(c.pattern, CARD_PATTERNS, 'none'),
    finish: one(c.finish, CARD_FINISHES, 'gloss'),
    title: String(c.title ?? 'Trainer').slice(0, 14) || 'Trainer',
    region: String(c.region ?? '').slice(0, 18),
    motto: String(c.motto ?? '').slice(0, 32),
    issued: Number(c.issued) || Date.now(),
    avatar: {
      sprite: isSprite(a.sprite) ? a.sprite.toLowerCase() : '',
      skin: isColor(a.skin) ? a.skin : O.skin[2],
      hair: one(hair, O.hair, 'short'),
      hairColor: isColor(a.hairColor) ? a.hairColor : O.hairColor[2],
      eyes: one(a.eyes, O.eyes, 'round'),
      eyeColor: isColor(a.eyeColor) ? a.eyeColor : O.eyeColor[0],
      brows: one(a.brows, O.brows, 'soft'),
      mouth: one(a.mouth, O.mouth, a.eyes === 'happy' || a.eyes === 'wink' ? 'smile' : 'neutral'),
      facialHair: one(a.facialHair, O.facialHair, 'none'),
      hat: one(hat, O.hat, 'none'),
      hatColor: isColor(a.hatColor) ? a.hatColor : accent,
      outfitStyle: one(a.outfitStyle, O.outfitStyle, 'tee'),
      outfit: isColor(a.outfit) ? a.outfit : O.outfit[0],
      outfit2: isColor(a.outfit2) ? a.outfit2 : '#ffffff',
      accessories: acc,
      bg: a.bg === 'auto' || isColor(a.bg) ? a.bg : 'auto',
    },
  };
}

/** Make sure a save's trainer has an id and a card. */
export function ensureTrainerCard(save) {
  save.trainer = save.trainer || { name: 'Trainer' };
  if (!save.trainer.id) save.trainer.id = Math.floor(Math.random() * 0xffffffff).toString(16).padStart(8, '0');
  save.trainer.card = save.trainer.card ? normalizeCard(save.trainer.card) : defaultTrainerCard(save.trainer.name, save.trainer.id);
  return save.trainer.card;
}
