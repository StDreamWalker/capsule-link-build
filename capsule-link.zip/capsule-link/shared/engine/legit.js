// While "unlock everything" (debug) is on, things you really buy or find are noted, so they're still yours when
// it goes off. (Kept apart, with no imports, so the shop, blueprints, toys and finds can all use it.)
export function noteLegit(save, kind, id, n = 1) {
  if (!save?.unlockAll?.on) return;
  const L = (save.unlockAll.legit = save.unlockAll.legit || { items: {}, found: {}, toys: {} });
  if (kind === 'item') L.items[id] = (L.items[id] ?? 0) + n;
  else if (kind === 'found') L.found[id] = true;
  else if (kind === 'toy') L.toys[id] = true;
}
