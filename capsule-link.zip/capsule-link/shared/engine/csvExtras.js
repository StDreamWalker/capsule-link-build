// The numbers Showdown's files leave out — base experience, growth rate, effort yield, base
// friendship, catch rate and habitat — read from the open PokéAPI data tables (CSV), matched to your
// species by national number. Paste any of these three files, or let the PC download them:
//   pokemon.csv          id, identifier, species_id, …, base_experience, …, is_default
//   pokemon_species.csv  id, identifier, …, habitat_id, …, capture_rate, base_happiness, …, growth_rate_id, …
//   pokemon_stats.csv    pokemon_id, stat_id, base_stat, effort
import { parseTable } from './importer.js';

export const POKEAPI_CSV = 'https://raw.githubusercontent.com/PokeAPI/pokeapi/master/data/v2/csv';
export const EXTRA_FILES = ['pokemon.csv', 'pokemon_species.csv', 'pokemon_stats.csv'];

const GROWTH = { 1: ['slow'], 2: ['steady', 'medium', 'mediumfast'], 3: ['quick', 'fast'], 4: ['wavy', 'mediumslow'], 5: ['erratic', 'slowthenveryfast'], 6: ['fluctuating', 'fastthenveryslow'] };
const STAT = { 1: 'hp', 2: 'atk', 3: 'def', 4: 'spa', 5: 'spd', 6: 'spe' };
// their habitat list → the scenes used for walks and the R.A.N.C.H.
const HABITAT = { 1: 'cavern', 2: 'forest', 3: 'meadow', 4: 'crystal', 5: 'starfield', 6: 'desert', 7: 'seafloor', 8: 'skyline', 9: 'shoreline' };
const squash = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');

/** Which of the three tables a paste is, or null. */
export function csvExtrasKind(columns) {
  const c = new Set(columns.map(squash));
  if (c.has('statid') && c.has('effort')) return 'stats';
  if (c.has('growthrateid')) return 'species';
  if (c.has('baseexperience') && c.has('speciesid')) return 'pokemon';
  return null;
}

/**
 * Apply any of the tables (text, already split by kind) to the data set in place.
 * tables: { pokemon?: rows, species?: rows, stats?: rows } (rows from parseTable)
 * Returns { updated, report: [] }.
 */
export function applyCsvExtras(ds, tables) {
  const report = [];
  const g = (row, k) => row[Object.keys(row).find((x) => squash(x) === squash(k))];
  const byNo = new Map(ds.species.map((s) => [Number(s.no), s]));
  const touched = new Set();
  // pokemon.csv: the default form of each species carries base experience; remember its row id for stats
  const pokemonToSpecies = new Map();
  for (const row of tables.pokemon ?? []) {
    const sid = Number(g(row, 'species_id')), pid = Number(g(row, 'id'));
    if (String(g(row, 'is_default')) === '0') continue;
    pokemonToSpecies.set(pid, sid);
    const sp = byNo.get(sid);
    const be = Number(g(row, 'base_experience'));
    if (sp && Number.isFinite(be) && be > 0) { sp.baseExp = be; touched.add(sp.id); }
  }
  for (const row of tables.species ?? []) {
    const sp = byNo.get(Number(g(row, 'id')));
    if (!sp) continue;
    const gr = GROWTH[Number(g(row, 'growth_rate_id'))];
    const curve = gr && ds.growthRates.find((x) => gr.includes(squash(x.id)) || gr.includes(squash(x.name)));
    if (curve) sp.growthRate = curve.id;
    const bh = Number(g(row, 'base_happiness'));
    if (Number.isFinite(bh) && g(row, 'base_happiness') !== '') sp.baseFriendship = bh;
    const cr = Number(g(row, 'capture_rate'));
    if (Number.isFinite(cr) && cr > 0) sp.catchRate = cr;
    const hb = HABITAT[Number(g(row, 'habitat_id'))];
    if (hb) sp.habitat = hb;
    touched.add(sp.id);
  }
  if (tables.stats?.length) {
    const effort = new Map();
    for (const row of tables.stats) {
      const pid = Number(g(row, 'pokemon_id'));
      const sid = pokemonToSpecies.get(pid) ?? (pid < 10000 ? pid : null); // without pokemon.csv, default forms share the number
      const sp = sid && byNo.get(sid);
      const key = STAT[Number(g(row, 'stat_id'))];
      if (!sp || !key) continue;
      const e = effort.get(sp) ?? {};
      const v = Number(g(row, 'effort')) || 0;
      if (v) e[key] = v;
      effort.set(sp, e);
    }
    for (const [sp, e] of effort) { sp.effortYield = e; touched.add(sp.id); }
  }
  const unmatched = ds.species.filter((s) => !touched.has(s.id)).length;
  if (unmatched && touched.size) report.push(`${unmatched} of your species were not in these tables (they keep their current values).`);
  return { updated: touched.size, report };
}

/** Parse pasted CSV text into the right slot of `tables`. Returns the kind or null. */
export function addCsvExtrasText(tables, text) {
  const t = parseTable(text);
  const kind = csvExtrasKind(t.columns);
  if (kind) tables[kind] = t.rows;
  return kind;
}
