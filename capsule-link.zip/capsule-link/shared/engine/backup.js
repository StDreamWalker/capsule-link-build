// Backups: one JSON file with everything an app needs to come back exactly as it was.
//   PC:    every trainer profile, the data set (with your names, pictures settings and introduction)
//          and, if you like, your textures
//   phone: the pocket save, linked PCs, capsules simulated on the phone and unsynced steps
// A plain save file from "Export save" (older versions) is read too.

export const BACKUP_FORMAT = 'capsule-link-backup';

const two = (n) => String(n).padStart(2, '0');
const stamp = (d = new Date()) => `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}-${two(d.getHours())}${two(d.getMinutes())}`;

/** app: 'pc' | 'phone'. parts: whatever that app keeps (see the top of this file). */
export function makeBackup(app, version, parts, { reason = 'by hand' } = {}) {
  return { format: BACKUP_FORMAT, app, version: version ?? '0.0.0', created: new Date().toISOString(), reason, ...parts };
}

/** File name for a backup made now. */
export function backupFileName(app, label = '') {
  const name = (label || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24);
  return `capsule-link-${app}-backup${name ? `-${name}` : ''}-${stamp()}.json`;
}

const looksLikeSave = (s) => !!(s && typeof s === 'object' && s.creatures && typeof s.creatures === 'object' && s.boxes);

/**
 * Read a backup (text or an object). Returns
 *   { ok: true, kind: 'pc' | 'phone' | 'save', backup, summary }  or  { ok: false, error }.
 * 'save' is a single trainer's save from an older "Export save".
 */
export function readBackup(input) {
  let b = input;
  if (typeof input === 'string') {
    try { b = JSON.parse(input); } catch { return { ok: false, error: 'That file is not a backup (it is not JSON).' }; }
  }
  if (!b || typeof b !== 'object') return { ok: false, error: 'That file is not a backup.' };
  if (b.format === BACKUP_FORMAT) {
    if (b.app === 'pc') {
      const saves = b.profiles?.saves;
      if (!saves || typeof saves !== 'object' || !Object.values(saves).every(looksLikeSave)) return { ok: false, error: 'This PC backup is damaged: its trainer saves are missing.' };
      return { ok: true, kind: 'pc', backup: b, summary: summarize(b) };
    }
    if (b.app === 'phone') {
      if (!looksLikeSave(b.save)) return { ok: false, error: 'This phone backup is damaged: its save is missing.' };
      return { ok: true, kind: 'phone', backup: b, summary: summarize(b) };
    }
    return { ok: false, error: 'This backup is from an app this version does not know.' };
  }
  if (looksLikeSave(b)) return { ok: true, kind: 'save', backup: b, summary: summarize(b) };
  return { ok: false, error: 'That file is not a backup.' };
}

const count = (n, one, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;
const creaturesIn = (save) => Object.keys(save?.creatures ?? {}).length;

/** One line saying what is in a backup, for confirm dialogs and lists. */
export function summarize(b) {
  const when = b.created ? new Date(b.created).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : null;
  if (b.format !== BACKUP_FORMAT) return `One trainer's save (${b.trainer?.name ?? 'Trainer'}, ${count(creaturesIn(b), 'creature')})`;
  if (b.app === 'pc') {
    const saves = Object.values(b.profiles?.saves ?? {});
    const bits = [
      count(saves.length, 'trainer'),
      count(saves.reduce((n, s) => n + creaturesIn(s), 0), 'creature'),
      b.dataset ? `data set (${count(b.dataset.species?.length ?? 0, 'species', 'species')})` : null,
      b.textures ? count(Object.keys(b.textures).length, 'texture') : null,
    ].filter(Boolean);
    return `PC backup${when ? ` from ${when}` : ''} (v${b.version}): ${bits.join(', ')}`;
  }
  return `Phone backup${when ? ` from ${when}` : ''} (v${b.version}): ${b.save.trainer?.name ?? 'Trainer'}, ${count(creaturesIn(b.save), 'creature')}`;
}
