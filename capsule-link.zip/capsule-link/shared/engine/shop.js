// The shop: a stock that changes every day (berries, battle items, dress-up clothes and incense),
// paid for with coins earned by walking and battling.
//   save.wallet          coins
//   save.shop            { day, bought: { id: n } }   today's purchases (stock is limited)
//   save.incense         { type, until, name }        lit on the phone: that type turns up more on walks
//   c.clothes            [{ id, fx, fy, s }]           worn clothes, placed on the sprite (fractions of its box)
import { createRng, hashString } from './rng.js';
import { todayKey } from './creature.js';
import { blueprintItem } from './ranchBuild.js';
import { DISHES } from './activities.js';

/** Coins for walking (per step) and battles. */
export const EARN = { perSteps: 25, battleWin: 40, battleLoss: 10, linkWin: 60 };

/** Dress-up clothes: small pictures placed anywhere on a creature. art = the picture's shape. */
export const CLOTHES = [
  { id: 'bow', name: 'Ribbon Bow', art: 'bow', color: '#ff5d8f' },
  { id: 'tophat', name: 'Top Hat', art: 'tophat', color: '#3b3550' },
  { id: 'cap', name: 'Sports Cap', art: 'cap', color: '#4a7dff' },
  { id: 'scarf', name: 'Knit Scarf', art: 'scarf', color: '#e5484d' },
  { id: 'specs', name: 'Round Specs', art: 'specs', color: '#2a2a3a' },
  { id: 'shades', name: 'Sunglasses', art: 'shades', color: '#1b1b28' },
  { id: 'flower', name: 'Hair Flower', art: 'flower', color: '#ffd23f' },
  { id: 'crown', name: 'Tiny Crown', art: 'crown', color: '#ffc93c' },
  { id: 'bandana', name: 'Bandana', art: 'bandana', color: '#3fb26a' },
  { id: 'starpin', name: 'Star Pin', art: 'star', color: '#ffe27a' },
  { id: 'bellcollar', name: 'Bell Collar', art: 'bell', color: '#c0306a' },
  { id: 'witchhat', name: 'Pointy Hat', art: 'witchhat', color: '#5a3a8a' },
  { id: 'beanie', name: 'Beanie', art: 'beanie', color: '#ff8a3d' },
  { id: 'headphones', name: 'Headphones', art: 'headphones', color: '#7db8ff' },
  { id: 'monocle', name: 'Monocle', art: 'monocle', color: '#ffc93c' },
  { id: 'heartclip', name: 'Heart Clip', art: 'heart', color: '#ff4f86' },
].map((c) => ({ ...c, id: `clothes-${c.id}`, kind: 'clothes', desc: 'Dress-up. Put it on anyone in the R.A.N.C.H. (they grow to like what you give them).' }));

/**
 * Items held in battle. Names are your own: set "showdownName" in the Data Lab to the item's name in
 * the battle simulator if you want it to work there too (until then it is only for show).
 */
export const HELD = [
  { id: 'held-snack', name: 'Snack Pouch', desc: 'Nibbles a little back each turn.' },
  { id: 'held-band', name: 'Power Band', desc: 'Hits harder, but sticks to one move.' },
  { id: 'held-scarf', name: 'Swift Scarf', desc: 'Moves first, but sticks to one move.' },
  { id: 'held-specs', name: 'Clever Specs', desc: 'Special moves hit harder, but sticks to one move.' },
  { id: 'held-charm', name: 'Focus Charm', desc: 'Hangs on with a sliver of health once.' },
  { id: 'held-gem', name: 'Life Gem', desc: 'Every hit is stronger; costs a little health.' },
  { id: 'held-vest', name: 'Sturdy Vest', desc: 'Takes special hits better.' },
  { id: 'held-claw', name: 'Lucky Claw', desc: 'Sometimes gets to move first.' },
  { id: 'held-boots', name: 'Trail Boots', desc: 'Ignores traps on the ground.' },
  { id: 'held-berry', name: 'Pocket Berry', desc: 'Eats it when health runs low.' },
].map((h) => ({ ...h, kind: 'held', showdownName: '' }));

const PRICE = { food: 30, held: 300, clothes: 140, incense: 160 };

/** Shiny things your creatures turn up on walks: worth nothing to them, good coins at the market. */
export const VALUABLES = [
  { id: 'val-stardust', name: 'Stardust', value: 60, color: '#ffb0d6', rarity: 5, desc: 'Fine, sparkly sand. Sells for a little.' },
  { id: 'val-pearl', name: 'Pearl', value: 90, color: '#f4f0ff', rarity: 4, desc: 'A small, lustrous pearl.' },
  { id: 'val-star-piece', name: 'Star Piece', value: 250, color: '#ff8a8a', rarity: 2, desc: 'A shard of a pretty gem. Sells well.' },
  { id: 'val-nugget', name: 'Gold Nugget', value: 400, color: '#ffd23f', rarity: 2, desc: 'A lump of pure gold.' },
  { id: 'val-big-pearl', name: 'Big Pearl', value: 450, color: '#e9e4ff', rarity: 1, desc: 'A large, gleaming pearl.' },
  { id: 'val-big-nugget', name: 'Big Nugget', value: 1200, color: '#ffc21a', rarity: 0.3, desc: 'A big lump of gold. A rare find!' },
].map((v) => ({ ...v, kind: 'valuable' }));

/** An incense for a type: lit on the phone, creatures of that type turn up more often on walks. */
export const incenseId = (typeId) => `incense-${typeId}`;
export function incenseItems(idx) {
  return [...(idx.types?.values?.() ?? [])].map((t) => ({
    id: incenseId(t.id), name: `${t.name} Incense`, kind: 'incense', type: t.id, color: t.color, hold: true, showdownName: '',
    desc: `When being held: ${t.name}-type moves hit a little harder.`,
    pairDesc: `Or when paired with a capsule: light it on your phone and ${t.name}-type creatures turn up more on walks for an hour.`,
  }));
}

/** Any item by id: the dataset's own, then the shop's clothes, battle items and incense. */
export function itemInfo(idx, id) {
  if (!id) return null;
  const own = idx.items?.get?.(id);
  if (own) return own;
  const c = CLOTHES.find((x) => x.id === id) ?? HELD.find((x) => x.id === id) ?? VALUABLES.find((x) => x.id === id) ?? DISHES.find((x) => x.id === id);
  if (c) return c;
  if (String(id).startsWith('bp-')) return blueprintItem(id);
  if (String(id).startsWith('incense-')) return incenseItems(idx).find((x) => x.id === id) ?? null;
  return null;
}
/** Every food: the data set's, and dishes cooked in Activities. */
export function allFoods(idx) { return [...(idx.ds?.items ?? []).filter((i) => i.kind === 'food'), ...DISHES]; }
/** Every clothing item, the dataset's own included. */
export function allClothes(idx) { return [...CLOTHES, ...(idx.ds?.items ?? []).filter((i) => i.kind === 'clothes')]; }

// ---------- one item, several uses ----------
// Items aren't split into "battle items", "incense" and so on: one berry can be eaten, planted or held;
// one incense can be held in battle or lit on a walk. The description says each way it can be used.
const BERRY_HOLD = 'Or when being held: eats it in battle when its health runs low.';
/** Can a creature hold this item (in battle)? */
export function holdable(item) {
  if (!item) return false;
  return item.kind === 'held' || !!item.hold || (item.kind === 'food' && (!!item.grow || /berry/i.test(item.name ?? '')) && !item.unlimited);
}
/** Every way an item can be used: ['feed', 'plant', 'hold', 'light', 'wear', 'toy', 'groom', 'build', 'sell']. */
export function itemUses(item) {
  if (!item) return [];
  const u = [];
  if (item.kind === 'food') u.push('feed');
  if (item.kind === 'food' && item.grow) u.push('plant');
  if (holdable(item)) u.push('hold');
  if (item.kind === 'incense') u.push('light');
  if (item.kind === 'clothes') u.push('wear');
  if (item.kind === 'toy') u.push('toy');
  if (item.kind === 'groom') u.push('groom');
  if (item.kind === 'blueprint') u.push('build');
  if (!item.unlimited && item.kind !== 'blueprint') u.push('sell');
  return u;
}
/** The full description, with the other ways it can be used ("Or when being held…"). */
export function itemDesc(item) {
  if (!item) return '';
  const parts = [item.desc ?? ''];
  if (item.kind === 'incense' && item.pairDesc) parts.push(item.pairDesc);
  else if (item.kind === 'food' && holdable(item) && item.kind !== 'held') parts.push(item.holdDesc ?? BERRY_HOLD);
  else if (item.kind === 'held' && item.pairDesc) parts.push(item.pairDesc);
  return parts.filter(Boolean).join(' ');
}
/** What the market pays for one (valuables: their worth; everything else: about half what it costs). */
export function sellPrice(item) {
  if (!item || item.unlimited || item.kind === 'blueprint') return 0;
  if (item.kind === 'valuable') return item.value;
  const base = item.price ?? (item.kind === 'food' ? PRICE.food + (item.grow?.hours ?? 2) * 8 : PRICE[item.kind] ?? 20);
  return Math.max(1, Math.floor(base / 2));
}
/** Sell n of an item from the bag (clothes someone is wearing stay). */
export function sell(idx, save, id, n = 1) {
  const item = itemInfo(idx, id);
  const price = sellPrice(item);
  if (!price) return { ok: false, reason: 'The market doesn’t buy that.' };
  let have = save.inventory[id] ?? 0;
  if (item.kind === 'clothes') have -= Object.values(save.creatures).filter((c) => (c.clothes ?? []).some((w) => w.id === id)).length;
  const k = Math.min(n, have);
  if (k <= 0) return { ok: false, reason: item.kind === 'clothes' ? 'Someone is wearing it. Take it off them first.' : 'None left to sell.' };
  save.inventory[id] -= k;
  earn(save, price * k);
  return { ok: true, count: k, coins: price * k };
}
/** Something found on a walk (rng: a seeded rng): { coins } | { item }. */
export function walkFind(idx, rng) {
  const r = rng();
  if (r < 0.4) return { coins: 3 + Math.floor(rng() * 4) * 3 + (rng() < 0.1 ? 25 : 0) };
  if (r < 0.78) {
    const foods = (idx.ds?.items ?? []).filter((i) => i.kind === 'food' && !i.unlimited);
    const other = (idx.ds?.items ?? []).filter((i) => !i.unlimited && i.kind !== 'food' && i.kind !== 'clothes' && i.kind !== 'held');
    const pool = [...foods, ...foods.filter((i) => i.grow), ...other];
    if (pool.length) return { item: pool[Math.floor(rng() * pool.length)].id };
  }
  const total = VALUABLES.reduce((a, v) => a + v.rarity, 0);
  let x = rng() * total;
  for (const v of VALUABLES) { x -= v.rarity; if (x <= 0) return { item: v.id }; }
  return { item: VALUABLES[0].id };
}

export function wallet(save) { return Math.max(0, Math.floor(save.wallet ?? 0)); }
export function earn(save, n) { save.wallet = Math.max(0, (save.wallet ?? 0) + n); return wallet(save); }

/** Today's stock. The same on every device for the same day. */
export function shopStock(idx, save, t = Date.now()) {
  const day = todayKey(t);
  const rng = createRng(hashString(`shop:${day}`));
  const pick = (list, n) => { const pool = [...list]; const out = []; while (pool.length && out.length < n) out.push(pool.splice(Math.floor(rng() * pool.length), 1)[0]); return out; };
  const foods = (idx.ds?.items ?? []).filter((i) => i.kind === 'food' && !i.unlimited);
  const held = [...HELD, ...(idx.ds?.items ?? []).filter((i) => i.kind === 'held')];
  const lines = [
    ...pick(foods, 3).map((item) => ({ item, price: item.price ?? Math.round(PRICE.food + (item.grow?.hours ?? 2) * 8 + (item.joy ?? 0)), stock: 5, section: 'Berries and treats' })),
    ...pick(held, 3).map((item) => ({ item, price: item.price ?? PRICE.held + Math.floor(rng() * 4) * 50, stock: 1, section: 'Gear' })),
    ...pick(incenseItems(idx), 2).map((item) => ({ item, price: PRICE.incense, stock: 3, section: 'Gear' })),
    ...pick(allClothes(idx), 3).map((item) => ({ item, price: item.price ?? PRICE.clothes + Math.floor(rng() * 5) * 20, stock: 1, section: 'Clothes' })),
  ];
  const bought = save.shop?.day === day ? save.shop.bought ?? {} : {};
  return { day, lines: lines.map((l) => ({ ...l, id: l.item.id, left: Math.max(0, l.stock - (bought[l.item.id] ?? 0)) })) };
}
/** Milliseconds until the stock changes (local midnight). */
export function shopResetIn(t = Date.now()) { const d = new Date(t); d.setHours(24, 0, 0, 0); return d.getTime() - t; }

export function buy(idx, save, id, t = Date.now()) {
  const stock = shopStock(idx, save, t);
  const line = stock.lines.find((l) => l.id === id);
  if (!line) return { ok: false, reason: 'That isn’t for sale today.' };
  if (line.left <= 0) return { ok: false, reason: 'Sold out until tomorrow.' };
  if (wallet(save) < line.price) return { ok: false, reason: `Not enough coins (${line.price} needed).` };
  save.wallet = wallet(save) - line.price;
  if (save.shop?.day !== stock.day) save.shop = { day: stock.day, bought: {} };
  save.shop.bought[id] = (save.shop.bought[id] ?? 0) + 1;
  save.inventory[id] = (save.inventory[id] ?? 0) + 1;
  return { ok: true, item: line.item, price: line.price };
}

/** Put a piece of clothing on (or move it): fx, fy are where on the sprite (0..1), s its size. */
export function wear(save, uid, id, fx, fy, s = 1) {
  const c = save.creatures[uid];
  if (!c) return { ok: false, reason: 'Nobody to dress.' };
  c.clothes = (c.clothes ?? []).filter((w) => w.id !== id);
  const owned = save.inventory[id] ?? 0;
  const inUse = Object.values(save.creatures).filter((x) => x.uid !== uid && (x.clothes ?? []).some((w) => w.id === id)).length;
  if (owned - inUse <= 0) return { ok: false, reason: 'Someone else is wearing it. Take it off them first, or buy another.' };
  c.clothes.push({ id, fx: clamp01(fx), fy: clamp01(fy), s: Math.max(0.5, Math.min(2, s)) });
  if (c.clothes.length > 4) c.clothes.shift();
  return { ok: true };
}
export function unwear(save, uid, id) {
  const c = save.creatures[uid];
  if (c) c.clothes = (c.clothes ?? []).filter((w) => w.id !== id);
  return { ok: true };
}
/** Clothes in the bag that nobody is wearing right now. */
export function spareClothes(idx, save) {
  const worn = {};
  for (const c of Object.values(save.creatures)) for (const w of c.clothes ?? []) worn[w.id] = (worn[w.id] ?? 0) + 1;
  return allClothes(idx).map((item) => ({ item, owned: save.inventory[item.id] ?? 0, spare: (save.inventory[item.id] ?? 0) - (worn[item.id] ?? 0) })).filter((x) => x.owned > 0);
}
const clamp01 = (v) => Math.max(0, Math.min(1, Number(v) || 0));

/** Light an incense (from the phone): uses one, lasts an hour of walking time. */
export function lightIncense(idx, save, id, t = Date.now(), minutes = 60) {
  if ((save.inventory[id] ?? 0) <= 0) return { ok: false, reason: 'None left in the bag.' };
  const item = itemInfo(idx, id);
  if (!item || item.kind !== 'incense') return { ok: false, reason: 'That isn’t incense.' };
  save.inventory[id]--;
  save.incense = { id, type: item.type, name: item.name, until: t + minutes * 60000 };
  return { ok: true, incense: save.incense };
}
export function activeIncense(save, t = Date.now()) { return save.incense && save.incense.until > t ? save.incense : null; }
