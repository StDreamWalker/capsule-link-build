// Changing a battle team inside the app (Battle Link), within what each creature could really know:
//   - moves it has learned by levelling up (up to its level): it can always remember those
//   - moves from TMs you own: a TM in the bag teaches any creature that can learn it (Showdown's learnsets
//     say which; without that data, a creature can learn TMs of its own types)
// TMs are items with ids "tm-<move id>". They're sold at the Market and turn up now and then.
// This is the groundwork for more ways to shape a creature later (tutors, egg moves, abilities…).
import { speciesOf, displayName } from './creature.js';

export const TM_PREFIX = 'tm-';
export const tmId = (moveId) => `${TM_PREFIX}${moveId}`;
export const isTm = (id) => String(id ?? '').startsWith(TM_PREFIX);

/** A TM as an item: { id, name, kind: 'tm', move, price, desc }. */
export function tmInfo(idx, id) {
  if (!isTm(id)) return null;
  const mv = idx.moves?.get?.(String(id).slice(TM_PREFIX.length));
  if (!mv) return null;
  const tname = idx.types?.get?.(mv.type)?.name ?? mv.type ?? '';
  return { id, name: `TM ${mv.name}`, kind: 'tm', move: mv.id, color: idx.types?.get?.(mv.type)?.color ?? '#9aa6b8',
    price: Math.round(300 + (Number(mv.power) || 40) * 6), desc: `Teaches ${mv.name} (${tname}${mv.category === 'status' ? ', status' : `, ${mv.power || '—'} power`}) to any creature that can learn it. It isn’t used up.` };
}

/** Could this species learn that move from a TM? */
export function canLearnTm(idx, sp, moveId) {
  if (!sp) return false;
  if (Array.isArray(sp.tms) && sp.tms.length) return sp.tms.includes(moveId);
  const mv = idx.moves?.get?.(moveId);
  return !!mv && (sp.types ?? []).includes(mv.type);
}

/**
 * The moves a creature could use right now: [{ id, name, why: 'known' | 'level' | 'tm', level? }].
 */
export function moveChoices(idx, save, c) {
  const sp = speciesOf(idx, c);
  const out = new Map();
  for (const m of c.moves ?? []) { const mv = idx.moves.get(m.id); if (mv) out.set(m.id, { id: m.id, name: mv.name, why: 'known' }); }
  for (const l of sp?.learnset ?? []) { if (l.level <= (c.level ?? 1) && !out.has(l.move)) { const mv = idx.moves.get(l.move); if (mv) out.set(l.move, { id: l.move, name: mv.name, why: 'level', level: l.level }); } }
  for (const [id, n] of Object.entries(save.inventory ?? {})) {
    if (n <= 0 || !isTm(id)) continue;
    const mid = id.slice(TM_PREFIX.length);
    if (out.has(mid) || !canLearnTm(idx, sp, mid)) continue;
    const mv = idx.moves.get(mid); if (mv) out.set(mid, { id: mid, name: mv.name, why: 'tm' });
  }
  return [...out.values()];
}

/** Set a creature's moves (1–4, each from moveChoices). PP for kept moves stays; new ones start full. */
export function setMoves(idx, save, uid, ids) {
  const c = save.creatures?.[uid];
  if (!c) return { ok: false, reason: 'Nobody to change.' };
  const want = [...new Set((ids ?? []).filter(Boolean))].slice(0, 4);
  if (!want.length) return { ok: false, reason: 'Every creature needs at least one move.' };
  const allowed = new Set(moveChoices(idx, save, c).map((m) => m.id));
  const bad = want.find((id) => !allowed.has(id));
  if (bad) return { ok: false, reason: `${displayName(idx, c)} can’t use ${idx.moves.get(bad)?.name ?? bad} yet (level it up, or get the TM).` };
  const old = new Map((c.moves ?? []).map((m) => [m.id, m]));
  c.moves = want.map((id) => old.get(id) ?? { id, pp: idx.moves.get(id)?.pp ?? 10 });
  return { ok: true };
}

/** A few TMs for today's Market: moves your creatures could actually learn, if there are any. */
export function tmsForShop(idx, save, rng, n = 2) {
  const mine = Object.values(save.creatures ?? {}).filter((c) => !c.egg).map((c) => speciesOf(idx, c)).filter(Boolean);
  const pool = (idx.ds?.moves ?? []).filter((mv) => (mv.power > 0 || mv.category === 'status') && mine.some((sp) => canLearnTm(idx, sp, mv.id)) && !(save.inventory?.[tmId(mv.id)] > 0));
  const out = [];
  while (pool.length && out.length < n) out.push(pool.splice(Math.floor(rng() * pool.length), 1)[0]);
  return out.map((mv) => tmInfo(idx, tmId(mv.id))).filter(Boolean);
}
