// Fossils (very rare finds when scavenging), the Fossil Revival Machine that brings them back to life, and
// the Egg Incubator that keeps eggs in its yard warm. Both machines are blueprints from the Market.
import { createCreature, addMemory, displayName } from './creature.js';
import { eggSteps, EGG_PASSIVE_PER_MIN } from './care.js';

export const FOSSILS = [
  ['helix', 'Helix Fossil', 'Omanyte', '#c8a46a'], ['dome', 'Dome Fossil', 'Kabuto', '#a8845a'], ['amber', 'Old Amber', 'Aerodactyl', '#e8a43a'],
  ['root', 'Root Fossil', 'Lileep', '#9a8a6a'], ['claw', 'Claw Fossil', 'Anorith', '#8a7a5a'], ['skull', 'Skull Fossil', 'Cranidos', '#b0a080'],
  ['armor', 'Armor Fossil', 'Shieldon', '#a09070'], ['cover', 'Cover Fossil', 'Tirtouga', '#7a8a9a'], ['plume', 'Plume Fossil', 'Archen', '#b08a6a'],
  ['jaw', 'Jaw Fossil', 'Tyrunt', '#9a7a5a'], ['sail', 'Sail Fossil', 'Amaura', '#8aa0b0'],
].map(([k, name, species, color]) => ({ id: `fossil-${k}`, name, kind: 'fossil', species, color, price: 0, sprite: `${k}-fossil`.replace('amber-fossil', 'old-amber'),
  desc: `An ancient fossil. A Fossil Revival Machine (Market → Machines) can bring back the ${species} it came from.` }));
export const REVIVE_HOURS = 3;
export const INCUBATOR_SPEED = 3; // extra on top of the usual warmth: four times as fast in all

/** The creature a fossil holds, in this data set (by name or Showdown name), or null. */
export function fossilSpecies(idx, fossil) {
  const want = String(fossil?.species ?? '').toLowerCase();
  const list = idx.ds.species ?? [];
  const exact = list.find((s) => [s.name, s.showdownName, s.id].some((n) => String(n ?? '').toLowerCase() === want));
  if (exact || !list.length) return exact ?? null;
  // other data sets: an old, stony creature stands in (the same one for the same fossil)
  const stony = list.filter((s) => (s.types ?? []).some((t) => /rock|stone|fossil|ground|earth|ancient/i.test(t)));
  const pool = stony.length ? stony : list;
  let h = 0; for (const ch of String(fossil?.id ?? '')) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return pool[h % pool.length];
}
const keyOf = (loc) => (loc?.kind === 'ranch' ? 'ranch' : loc?.kind === 'box' ? loc.box : null);
/** Machines of a kind built in a yard. */
export function machinesIn(save, key, bp) {
  const owner = key === 'ranch' ? save.ranch : save.boxes?.[key];
  return (owner?.build?.features ?? []).filter((f) => f.bp === bp);
}
function homeIn(save, key) {
  if (key === 'ranch') return { kind: 'ranch' };
  const used = new Set(Object.values(save.creatures ?? {}).filter((c) => c.location?.kind === 'box' && c.location.box === key).map((c) => c.location.slot));
  for (let s = 0; s < 30; s++) if (!used.has(s)) return { kind: 'box', box: key, slot: s };
  return { kind: 'ranch' };
}

/** What a revival machine is doing: { idle } | { busy, left, fossil, species } | { ready, fossil, species } */
export function revivalStatus(idx, save, featureId, t = Date.now()) {
  const r = save.revivals?.[featureId];
  if (!r) return { idle: true };
  const fossil = FOSSILS.find((f) => f.id === r.fossil);
  const sp = idx.species.get(r.speciesId);
  return r.until > t ? { busy: true, left: r.until - t, fossil, species: sp } : { ready: true, fossil, species: sp };
}
/** Put a fossil in the machine (featureId) in yard `key`. */
export function startRevival(idx, save, key, featureId, fossilId, t = Date.now()) {
  if (!machinesIn(save, key, 'fossil-machine').some((f) => f.id === featureId)) return { ok: false, reason: 'There’s no Fossil Revival Machine there.' };
  if (save.revivals?.[featureId]) return { ok: false, reason: 'The machine is already working.' };
  if ((save.inventory[fossilId] ?? 0) <= 0) return { ok: false, reason: 'You don’t have that fossil.' };
  const fossil = FOSSILS.find((f) => f.id === fossilId);
  const sp = fossilSpecies(idx, fossil);
  if (!sp) return { ok: false, reason: `Your data set has no ${fossil?.species ?? 'creature'} for it to become (add it in the Data Lab).` };
  save.inventory[fossilId]--;
  (save.revivals = save.revivals || {})[featureId] = { key, fossil: fossilId, speciesId: sp.id, at: t, until: t + REVIVE_HOURS * 3600000 };
  return { ok: true, until: save.revivals[featureId].until, species: sp };
}
/** Take the revived creature out (into the machine's yard). */
export function collectRevival(idx, save, featureId, { trainer = '', t = Date.now() } = {}) {
  const st = revivalStatus(idx, save, featureId, t);
  if (!st.ready) return { ok: false, reason: st.busy ? 'Not ready yet.' : 'The machine is empty.' };
  const r = save.revivals[featureId];
  const c = createCreature(idx, r.speciesId, { level: 20, trainer, location: homeIn(save, r.key), metHow: `Brought back to life from a ${st.fossil?.name ?? 'fossil'}`, now: t });
  c.memories = [];
  addMemory(c, `Woke up in a Fossil Revival Machine, brought back from a ${st.fossil?.name ?? 'fossil'} after a very, very long sleep.`, t, { core: true });
  save.creatures[c.uid] = c;
  delete save.revivals[featureId];
  return { ok: true, creature: c, name: displayName(idx, c) };
}

/** Eggs in yards with an incubator hatch faster: call with the time since the last tick. Returns uids that hatched. */
export function incubate(save, t = Date.now()) {
  const hatched = [];
  for (const c of Object.values(save.creatures ?? {})) {
    if (!c.egg) { delete c.incAt; continue; }
    const key = keyOf(c.location);
    if (key == null || !machinesIn(save, key, 'incubator').length) { delete c.incAt; continue; }
    const last = c.incAt ?? t;
    c.incAt = t;
    const mins = Math.max(0, (t - last) / 60000);
    if (mins > 0 && eggSteps(c, mins * EGG_PASSIVE_PER_MIN * INCUBATOR_SPEED, t)) hatched.push(c.uid);
  }
  return hatched;
}
