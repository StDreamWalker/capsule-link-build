// Changing: evolving, Mega Evolving and other form changes, as menu choices (the R.A.N.C.H., the boxes,
// the desktop). Only what a creature *could* do is offered; what it can't do yet is shown greyed out with
// the reason (level, friendship, steps, an item to use or hold, the weather…).
//
//   changeOptions(idx, save, c, { weather })  → [{ key, kind, label, to, ok, why }]
//   applyChange(idx, save, uid, key, t)       → { ok, reason, text }
//   tickForms(idx, save, t)                   Mega Evolution wears off; item forms end when the item goes
//
// Mega / Primal forms need their stone or orb held and last MEGA_MINUTES. Forms that need an item
// (Giratina's orb, Arceus's plates, …) stay while it's held. Weather forms change by themselves.
// Battle-only forms (Gigantamax, Zen Mode…) aren't offered at home.
import { formsOf, currentFormId, setForm, baseSpeciesOf } from './forms.js';
import { speciesOf, evolve, addMemory, displayName, touch } from './creature.js';

export const MEGA_MINUTES = 30;
const squash = (s) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
const WEATHERY = /sun|sunny|solar|rain|rainy|snow|snowy|hail|ice|frost|wind|fog|mist/i;
const isMega = (f) => /^(mega|primal)/i.test(String(f.forme ?? '')) || /-(mega|primal)/i.test(String(f.sp?.name ?? ''));
const isBattleOnly = (f) => !!f.sp?.battleOnly || /gmax|gigantamax|eternamax|zen|busted|blade|school|complete|crowned|stellar|terastal/i.test(String(f.forme ?? ''));

/** The name of what a creature holds (or ''). */
export function heldName(idx, c) {
  const id = c?.heldItemId;
  return String(id ? (idx.items?.get?.(id)?.name ?? c.heldItem ?? id) : c?.heldItem ?? '');
}
const holds = (idx, c, name) => !!name && squash(heldName(idx, c)) === squash(name);
/** An item in the bag by id or name: its id, or null. */
function bagHas(idx, save, name) {
  const k = squash(name);
  for (const [id, n] of Object.entries(save?.inventory ?? {})) {
    if (n <= 0) continue;
    if (squash(id) === k || squash(id.replace(/^evo-/, '')) === k || squash(idx.items?.get?.(id)?.name) === k) return id;
  }
  return null;
}

/** What a creature could change into right now (and what it can't yet, with why). */
export function changeOptions(idx, save, c, { weather = null } = {}) {
  if (!c || c.egg) return [];
  const out = [];
  const sp = speciesOf(idx, c);
  // evolution
  for (const e of sp?.evolutions ?? []) {
    const to = idx.species.get(e.to);
    if (!to) continue;
    const v = Number(e.value) || 0;
    let ok = false, why = '';
    if (e.method === 'level') { ok = c.level >= v; why = ok ? '' : `Evolves at level ${v} (now ${c.level}).`; }
    else if (e.method === 'friendship') { ok = (c.friendship ?? 0) >= v; why = ok ? '' : `Needs to be closer to you first (friendship ${c.friendship ?? 0} of ${v}).`; }
    else if (e.method === 'steps') { const s = c.walk?.totalSteps ?? 0; ok = s >= v; why = ok ? '' : `Walk ${(v - s).toLocaleString()} more steps together.`; }
    else if (e.method === 'item') { ok = !!bagHas(idx, save, e.value); why = ok ? `Uses a ${e.value}.` : `Needs a ${e.value} (Market → Evolution items).`; }
    else if (e.method === 'trade') { ok = false; why = 'Evolves when traded.'; }
    else { ok = false; why = 'Evolves in a special way.'; }
    out.push({ key: `evo:${to.id}`, kind: 'evolve', to: to.id, label: `Evolve into ${to.name}`, ok, why });
  }
  // forms
  const forms = formsOf(idx, c.speciesId);
  if (forms.length > 1) {
    const cur = currentFormId(idx, c);
    const base = forms[0];
    for (const f of forms.slice(1)) {
      if (f.id === cur) continue;
      if (isBattleOnly(f) && !isMega(f)) continue;
      const need = f.sp?.requiredItem;
      if (isMega(f)) {
        const ok = need ? holds(idx, c, need) : false;
        const word = /primal/i.test(f.forme) ? 'Primal Reversion' : `Mega Evolve${/[XY]$/.test(f.forme) ? ` (${f.forme.slice(-1)})` : ''}`;
        out.push({ key: `form:${f.id}`, kind: 'mega', to: f.id, label: word, ok, why: ok ? `For ${MEGA_MINUTES} minutes.` : need ? `Needs to hold ${need}.` : 'Needs its Mega Stone held.' });
      } else if (WEATHERY.test(f.forme) && !need) {
        out.push({ key: `form:${f.id}`, kind: 'form', to: f.id, label: `${f.forme} Form`, ok: false, why: 'Changes by itself with the weather.' });
      } else if (need) {
        const ok = holds(idx, c, need);
        out.push({ key: `form:${f.id}`, kind: 'form', to: f.id, label: `Change to ${f.forme}`, ok, why: ok ? 'While they hold it.' : `Needs to hold ${need}.` });
      } else {
        out.push({ key: `form:${f.id}`, kind: 'form', to: f.id, label: `Change to ${f.forme}`, ok: true, why: '' });
      }
    }
    if (cur !== c.speciesId && cur !== base.id) out.push({ key: `form:${base.id}`, kind: 'form', to: null, label: 'Back to usual form', ok: true, why: '' });
  }
  void weather;
  return out;
}

/** Do one of changeOptions' choices. */
export function applyChange(idx, save, uid, key, t = Date.now()) {
  const c = save.creatures?.[uid];
  const opt = changeOptions(idx, save, c).find((o) => o.key === key);
  if (!opt) return { ok: false, reason: 'They can’t do that.' };
  if (!opt.ok) return { ok: false, reason: opt.why };
  const name = displayName(idx, c);
  if (opt.kind === 'evolve') {
    const e = (speciesOf(idx, c)?.evolutions ?? []).find((x) => x.to === opt.to);
    if (e?.method === 'item') { const id = bagHas(idx, save, e.value); if (id) save.inventory[id]--; }
    const r = evolve(idx, c, opt.to, t);
    if (!r) return { ok: false, reason: 'Something went wrong.' };
    c.formId = null; delete c.formUntil; delete c.formItem;
    return { ok: true, kind: 'evolve', text: `${name} evolved into ${idx.species.get(opt.to)?.name}!`, events: r.events };
  }
  const f = opt.to ? idx.species.get(opt.to) : null;
  const r = setForm(idx, c, opt.to);
  if (!r.ok) return r;
  if (opt.kind === 'mega') {
    c.formUntil = t + MEGA_MINUTES * 60000; c.formItem = f?.requiredItem ?? null;
    c.firsts = c.firsts || {};
    if (!c.firsts.mega) { c.firsts.mega = t; addMemory(c, `Mega Evolved for the first time, glowing with ${f?.requiredItem ?? 'its stone'}'s power.`, t); }
  } else { delete c.formUntil; c.formItem = f?.requiredItem ?? null; }
  touch(c, t);
  return { ok: true, kind: opt.kind, text: opt.kind === 'mega' ? `${name} Mega Evolved!` : opt.to ? `${name} changed form.` : `${name} is back to their usual form.` };
}

/** Mega Evolution wears off after a while; an item form ends when they stop holding the item. */
export function tickForms(idx, save, t = Date.now()) {
  const ended = [];
  for (const c of Object.values(save.creatures ?? {})) {
    if (!c.formId) continue;
    const timedOut = c.formUntil && c.formUntil <= t;
    const dropped = c.formItem && !holds(idx, c, c.formItem);
    if (!timedOut && !dropped) continue;
    c.formId = null; delete c.formUntil; delete c.formItem;
    ended.push(c.uid);
  }
  return ended;
}

/** Items the data set's evolutions and forms ask for (for the Market): [{ id, name, kind, price, desc }]. */
export function evolutionItems(idx) {
  if (idx._evoItems) return idx._evoItems;
  const names = new Map();
  for (const sp of idx.species.values()) {
    for (const e of sp.evolutions ?? []) if (e.method === 'item' && e.value) names.set(squash(e.value), { name: String(e.value), use: true });
    if (sp.requiredItem) names.set(squash(sp.requiredItem), { name: String(sp.requiredItem), hold: true, mega: isMega({ forme: sp.forme, sp }) });
  }
  idx._evoItems = [...names.values()].map(({ name, use, mega }) => {
    const own = [...(idx.items?.values?.() ?? [])].find((it) => squash(it.name) === squash(name));
    return own ? { ...own, evo: true, hold: own.hold ?? !use } : { id: `evo-${squash(name)}`, name, kind: use ? 'evolution' : 'held', hold: !use, price: mega ? 3000 : use ? 1500 : 2000, evo: true, desc: use ? 'Some creatures evolve when you use this (Evolve, from their menu).' : mega ? 'Held by the right creature, it lets them Mega Evolve for a while.' : 'Held by the right creature, it changes their form.' };
  });
  return idx._evoItems;
}
export { baseSpeciesOf };
