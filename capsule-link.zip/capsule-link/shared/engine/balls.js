// Poké Balls: bought at the market, kept in the bag, and used to move someone into a different ball (from its
// summary). A creature from a game can only go into a ball that game has — and it goes back to its game in it.
//
//   BALL_ITEMS                       the balls as items ('ball-<number>', kind 'ball')
//   ballsForGame(c)                  → ball numbers its game has (null: any — made here, or the game isn't known)
//   ballChoices(save, c)             → [{ ball, name, have }] balls in the bag it can go into
//   reball(save, c, ball)            → { ok } (uses one from the bag)
import { BALL_NAMES_ENGINE as NAMES } from './ballNames.js';

// what each ball costs at the market (rare ones dear; the Master Ball very dear; the Cherish Ball isn't sold)
const PRICE = { 1: 25000, 2: 600, 3: 300, 4: 100, 5: 500, 6: 450, 7: 450, 8: 450, 9: 450, 10: 450, 11: 900, 12: 150, 13: 500, 14: 350, 15: 650, 17: 800, 18: 800, 19: 800, 20: 800, 21: 900, 22: 800, 23: 800, 24: 600, 25: 1500, 26: 1800, 27: 2000, 28: 150, 29: 350, 30: 650, 31: 700, 32: 900, 33: 1200, 34: 700, 35: 900, 36: 1200, 37: 20000 };
const COLOR = { 1: '#8a3ab0', 2: '#ffd23f', 3: '#3f7fff', 4: '#e5484d', 5: '#6a9a3a', 6: '#3ab8c8', 7: '#3a6ae8', 8: '#8ac83a', 9: '#e8803a', 10: '#e8e0d0', 11: '#2a2a2a', 12: '#f4f4f4', 13: '#2a5a3a', 14: '#ff9ac0', 15: '#3a8ae8', 17: '#ff8a3a', 18: '#ffb03a', 19: '#3a9ae8', 20: '#7a8496', 21: '#ff6aa8', 22: '#3ab86a', 23: '#3a4ab8', 24: '#e8a03a', 25: '#ff8ad8', 26: '#3a5ad8', 27: '#9a3ab8' };
export const SOLD_BALLS = Object.keys(PRICE).map(Number);
export const ballItemId = (n) => `ball-${n}`;
export const BALL_ITEMS = SOLD_BALLS.map((n) => ({ id: ballItemId(n), name: NAMES[n] ?? `Ball ${n}`, kind: 'ball', ball: n, price: PRICE[n], color: COLOR[n] ?? '#e5484d', desc: `Move one of yours into a ${NAMES[n] ?? 'ball'} (from its summary). Only balls its own game has.` }));

// the balls each game has (by its version number, or its name)
const R = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);
const GEN3 = R(1, 12), GEN4 = R(1, 16), HGSS = R(1, 24), GEN5 = [...R(1, 16), 25], GEN6 = [...R(1, 16), 25], GEN7 = R(1, 26), LGPE = [1, 2, 3, 4, 12, 16], HISUI = [16, 27, ...R(28, 37)];
const BY_VERSION = { 1: GEN3, 2: GEN3, 3: GEN3, 4: GEN3, 5: GEN3, 15: GEN3, 10: GEN4, 11: GEN4, 12: GEN4, 7: HGSS, 8: HGSS, 20: GEN5, 21: GEN5, 22: GEN5, 23: GEN5, 24: GEN6, 25: GEN6, 26: GEN6, 27: GEN6, 30: GEN7, 31: GEN7, 32: GEN7, 33: GEN7, 42: LGPE, 43: LGPE, 44: GEN7, 45: GEN7, 47: HISUI, 48: GEN7, 49: GEN7, 50: GEN7, 51: GEN7 };
const BY_NAME = [
  [/legends.*arceus|\bpla\b|hisui/i, HISUI], [/let.?s go/i, LGPE], [/heart ?gold|soul ?silver|hgss/i, HGSS],
  [/scarlet|violet|sword|shield|brilliant|shining|bdsp|ultra|\bsun\b|\bmoon\b/i, GEN7], [/\bx\b|\by\b|omega|alpha/i, GEN6],
  [/black|white/i, GEN5], [/diamond|pearl|platinum/i, GEN4],
  [/unbound|cfru|radical red|emerald (crest|rogue)|expansion/i, R(1, 27)], // (romhacks built on the newer engines have them all)
  [/ruby|sapphire|emerald|fire ?red|leaf ?green|colosseum|xd/i, GEN3],
];
/** The ball numbers its game has, or null (any: made here, or its game isn't known). */
export function ballsForGame(c) {
  const o = c?.origin ?? {};
  const v = Number(o.version ?? c?.pk?.version);
  if (BY_VERSION[v]) return BY_VERSION[v];
  const g = String(o.game ?? o.gameText ?? '');
  for (const [re, list] of BY_NAME) if (re.test(g)) return list;
  return null;
}
/** The balls in the bag it could go into (not the one it's in). */
export function ballChoices(save, c) {
  const ok = ballsForGame(c), now = String(c?.ballSkin || c?.ball || '4');
  return BALL_ITEMS.filter((b) => (save.inventory?.[b.id] ?? 0) > 0 && (!ok || ok.includes(b.ball)) && String(b.ball) !== now)
    .map((b) => ({ ball: b.ball, name: b.name, have: save.inventory[b.id] }));
}
/** Into a ball from the bag (one is used). Its game gets the new ball too, when it goes back. */
export function reball(save, c, ball) {
  if (!c) return { ok: false, reason: 'No such creature.' };
  const n = Number(ball), id = ballItemId(n);
  if ((save.inventory?.[id] ?? 0) <= 0) return { ok: false, reason: `No ${NAMES[n] ?? 'ball'} in the bag: buy one at the market.` };
  const ok = ballsForGame(c);
  if (ok && !ok.includes(n)) return { ok: false, reason: `Its game doesn’t have the ${NAMES[n] ?? 'ball'}.` };
  if (String(c.ballSkin || c.ball || '4') === String(n)) return { ok: false, reason: 'It’s already in that ball.' };
  save.inventory[id] -= 1;
  // (the ball it's in now: shown here, and written back into its game data when it goes home)
  c.ballSkin = String(n);
  if (c.pk) c.pk.ballChanged = n;
  return { ok: true, ball: n };
}
