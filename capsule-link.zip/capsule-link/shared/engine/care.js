// Ranch care (needs, petting, feeding, play) and walking friendship.
import { runFormula } from './dataset.js';
import { addMemory, gainExp, todayKey, touch, checkEvolution } from './creature.js';
import { createRng } from './rng.js';

export const NEED_KEYS = ['fullness', 'joy', 'energy', 'hygiene'];
export const NEED_LABELS = { fullness: 'Fullness', joy: 'Joy', energy: 'Energy', hygiene: 'Tidiness' };

const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));

function isSleepTime(idx, t) {
  const [start, end] = idx.ds.rules.sleepHours ?? [22, 7];
  const h = new Date(t).getHours();
  return start > end ? h >= start || h < end : h >= start && h < end;
}

/** Bring needs up to date for the time that passed. Needs never drop below the floor. */
export function tickNeeds(idx, c, t = Date.now()) {
  const last = c.needsAt ?? t;
  const hours = Math.max(0, (t - last) / 3600000);
  if (hours <= 0) return c.needs;
  const decay = idx.ds.rules.needsDecayPerHour;
  const floor = idx.ds.rules.needsFloor ?? 10;
  const n = c.needs || (c.needs = { fullness: 80, joy: 70, energy: 90, hygiene: 90 });
  // inside a ball (carried on a walk or in a capsule) a creature rests: hunger and grooming barely change
  const inBall = c.location?.kind === 'capsule' || c.location?.kind === 'phone';
  for (const k of ['fullness', 'joy', 'hygiene']) n[k] = clamp(n[k] - decay[k] * hours * (inBall && k !== 'joy' ? 0.25 : 1), floor, 100);
  // energy recovers while asleep (night hours or when resting in a capsule on the dock)
  const sleeping = isSleepTime(idx, t) || c.location?.kind === 'capsule';
  n.energy = clamp(n.energy + (sleeping ? 12 : -decay.energy) * hours, floor, 100);
  // an egg warms up over time even without walking, so it always hatches eventually
  if (c.egg) eggSteps(c, hours * 60 * EGG_PASSIVE_PER_MIN, t);
  c.needsAt = t;
  return n;
}

// ---------- eggs ----------
// An egg counts down steps. Walking with it counts double; time alone also counts (about two
// days for an average egg), so an egg left in a box still hatches.
export const EGG_DEFAULT_STEPS = 5120;
const EGG_PASSIVE_PER_MIN = 2, EGG_WALK_RATE = 2;
export function makeEgg(c, steps = EGG_DEFAULT_STEPS, t = Date.now()) {
  const s = Math.max(256, Math.round(steps));
  c.egg = { steps: s, total: s, at: t };
  return c;
}
/** Take steps off an egg; returns true when it hatched just now. */
export function eggSteps(c, n, t = Date.now()) {
  if (!c.egg || !(n > 0)) return false;
  c.egg.steps = Math.max(0, c.egg.steps - n);
  if (c.egg.steps > 0) return false;
  delete c.egg;
  c.hatchedAt = t;
  addMemory(c, 'Hatched from an egg.', t);
  return true;
}
/** 0…1 of the way to hatching. */
export function eggProgress(c) { return c.egg ? 1 - c.egg.steps / (c.egg.total || EGG_DEFAULT_STEPS) : 1; }

// ---------- one-on-one care ----------
const GROOM_STEPS = { wash: { hygiene: 25, joy: 1 }, brush: { hygiene: 15, joy: 4 }, comb: { hygiene: 10, joy: 5 }, towel: { joy: 2 }, dry: { joy: 3 } };
/** Toys anyone can play with in the care room (items of kind "toy" from your data set join them). */
export const CARE_TOYS = [
  { id: 'ball', name: 'Bouncy ball' }, { id: 'feather', name: 'Feather wand' }, { id: 'plush', name: 'Plush' },
  { id: 'bell', name: 'Jingle bell' }, { id: 'ribbon', name: 'Ribbon' },
];
/** Each creature's favourite berry and toy: fixed for life, worked out from its id. */
export function favorites(idx, c) {
  let h = 2166136261;
  for (const ch of String(c?.uid ?? '')) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
  const berries = (idx.ds.items ?? []).filter((i) => i.kind === 'food' && (i.grow || /berry/i.test(i.name)));
  const toys = [...CARE_TOYS, ...(idx.ds.items ?? []).filter((i) => i.kind === 'toy')];
  return { berry: berries.length ? berries[h % berries.length].id : null, toy: toys[(h >>> 8) % toys.length].id };
}

export function mood(c) {
  const n = c.needs || {};
  if (n.energy < 25) return { id: 'sleepy', label: 'Sleepy' };
  if (n.fullness < 30) return { id: 'hungry', label: 'Hungry' };
  if (n.hygiene < 30) return { id: 'grubby', label: 'Needs a brush' };
  if (n.joy < 30) return { id: 'bored', label: 'Bored' };
  if (n.joy > 75 && n.fullness > 50) return { id: 'happy', label: 'Happy' };
  return { id: 'content', label: 'Content' };
}

function addFriendship(idx, c, amount, t) {
  if (!amount) return 0;
  const before = c.friendship;
  c.friendship = clamp(c.friendship + amount, 0, idx.ds.rules.maxFriendship);
  for (const tier of [100, 150, 200, 250]) {
    if (before < tier && c.friendship >= tier) addMemory(c, `Friendship reached ${tier}.`, t);
  }
  return c.friendship - before;
}

/** Friendship earned from care is capped per day so spamming the pet button does not max it out. */
function careFriendship(idx, c, amount, t) {
  const day = todayKey(t);
  if (!c.careToday || c.careToday.day !== day) c.careToday = { day, friendship: 0 };
  const room = Math.max(0, (idx.ds.rules.careFriendshipPerDay ?? 12) - c.careToday.friendship);
  const give = Math.min(room, amount);
  c.careToday.friendship += give;
  return addFriendship(idx, c, give, t);
}

/**
 * Care actions: 'pet', 'feed', 'play', 'groom', 'talk'. Food/toys/grooming items come from
 * the dataset item list; items without `unlimited` are taken from the inventory.
 * Returns { ok, reaction, friendship, needs, consumed }.
 */
export function applyCare(idx, c, action, opts = {}) {
  const t = opts.at ?? Date.now();
  tickNeeds(idx, c, t);
  const n = c.needs;
  let delta = {}, friend = 0, reaction = 'happy', consumed = null;
  const item = opts.item ? idx.items.get(opts.item) : null;

  if (item && !item.unlimited && opts.inventory) {
    if (!(opts.inventory[item.id] > 0)) return { ok: false, reason: `No ${item.name} left.` };
  }

  switch (action) {
    case 'pet':
      delta = { joy: 6 };
      friend = n.joy < 95 ? 1 : 0;
      reaction = 'hearts';
      break;
    case 'tap':
      // a gentle tap on the ball: the creature inside notices you
      delta = { joy: 2 };
      friend = 0.25;
      reaction = 'note';
      break;
    case 'talk':
      delta = { joy: 3 };
      friend = 0.5;
      reaction = 'listen';
      break;
    case 'feed': {
      const food = item?.kind === 'food' ? item : idx.items.get('kibble') ?? { fullness: 30, joy: 2 };
      if (n.fullness >= 95) return { ok: true, reaction: 'full', friendship: 0, needs: n };
      delta = { fullness: food.fullness ?? 20, joy: food.joy ?? 0, energy: food.energy ?? 0 };
      friend = food.friendship ?? 1;
      reaction = (food.joy ?? 0) >= 10 ? 'delighted' : 'munch';
      consumed = food.unlimited ? null : food.id;
      break;
    }
    case 'play': {
      const toy = item?.kind === 'toy' ? item : { joy: 20, energy: -10, friendship: 2 };
      if (n.energy < 15) return { ok: true, reaction: 'tired', friendship: 0, needs: n };
      delta = { joy: toy.joy ?? 20, energy: toy.energy ?? -10, fullness: -4 };
      friend = toy.friendship ?? 2;
      reaction = 'play';
      consumed = toy.unlimited ? null : toy.id ?? null;
      break;
    }
    case 'groom': {
      const tool = item?.kind === 'groom' ? item : { hygiene: 40, joy: 6, friendship: 1 };
      delta = { hygiene: tool.hygiene ?? 40, joy: tool.joy ?? 0 };
      friend = tool.friendship ?? 1;
      reaction = 'sparkle';
      consumed = tool.unlimited ? null : tool.id ?? null;
      break;
    }
    // one-on-one care (the R.A.N.C.H. care room): each step of a proper groom
    case 'wash': case 'brush': case 'comb': case 'towel': case 'dry':
      delta = GROOM_STEPS[action];
      friend = 0.5;
      reaction = 'sparkle';
      break;
    case 'rest':
      delta = { energy: 30 };
      reaction = 'sleep';
      break;
    default:
      return { ok: false, reason: `Unknown action ${action}` };
  }
  // their favourite berry or toy: they light up
  if (opts.favorite) { delta = { ...delta, joy: (delta.joy ?? 0) + 10 }; friend += 2; reaction = 'delighted'; }
  for (const [k, v] of Object.entries(delta)) n[k] = clamp((n[k] ?? 50) + v, 0, 100);
  // little firsts worth remembering
  c.firsts = c.firsts || {};
  const first = (key, text) => { if (!c.firsts[key]) { c.firsts[key] = t; addMemory(c, text, t); } };
  if (action === 'feed' && item) first(`food:${item.id}`, `Tasted ${item.name} for the first time${(item.joy ?? 0) >= 10 ? ' and loved it' : ''}.`);
  if (action === 'play') first('play', 'Played catch together for the first time.');
  if (action === 'groom' || action === 'brush') first('groom', 'Got brushed for the first time.');
  if (action === 'wash') first('wash', 'Had a bath for the first time.');
  if (opts.favorite) first(`fav:${opts.item ?? opts.toy ?? action}`, `Found out how much they love ${item?.name ?? opts.toyName ?? 'that'}.`);
  if (action === 'pet' && c.friendship >= 150) first('pet150', 'Leaned into a pat, completely at ease.');
  if (action === 'tap') first('tap', 'Felt a gentle tap on the capsule while out on a walk.');
  // fractional friendship accumulates
  c._friendFrac = (c._friendFrac ?? 0) + friend;
  const whole = Math.floor(c._friendFrac);
  c._friendFrac -= whole;
  const gained = careFriendship(idx, c, whole, t);
  if (consumed && opts.inventory) opts.inventory[consumed] = Math.max(0, (opts.inventory[consumed] ?? 0) - 1);
  touch(c, t);
  return { ok: true, reaction, friendship: gained, needs: { ...n }, consumed };
}

const STEP_MILESTONES = [1000, 5000, 10000, 25000, 50000, 100000, 250000, 500000, 1000000];

/**
 * Apply steps walked together (from the phone pedometer or a capsule).
 * Deterministic for a given event id so phone and PC compute the same finds.
 */
export function applyWalk(idx, c, steps, opts = {}) {
  const t = opts.at ?? Date.now();
  const rng = createRng(opts.seed ?? `${c.uid}:${t}:${steps}`);
  steps = Math.max(0, Math.floor(steps));
  const out = { steps: 0, friendship: 0, exp: 0, events: [], finds: [] };
  if (!steps) return out;
  if (c.egg) {
    // eggs don't gain anything from a walk except getting closer to hatching
    out.steps = steps;
    if (eggSteps(c, steps * EGG_WALK_RATE, t)) out.events.push({ kind: 'hatched', text: 'The egg hatched!' });
    return out;
  }
  const day = todayKey(t);
  const w = c.walk || (c.walk = { totalSteps: 0, day, todaySteps: 0, stepsSinceFind: 0 });
  if (w.day !== day) { w.day = day; w.todaySteps = 0; }
  const cap = idx.ds.rules.walkDailyStepCap ?? 40000;
  const counted = Math.max(0, Math.min(steps, cap - w.todaySteps));
  if (!w.totalSteps && counted > 0) addMemory(c, 'Went on a first walk together.', t);
  const before = w.totalSteps;
  w.totalSteps += counted;
  w.todaySteps += counted;
  out.steps = counted;
  for (const m of STEP_MILESTONES) {
    if (before < m && w.totalSteps >= m) addMemory(c, `Walked ${m.toLocaleString('en-US')} steps together.`, t);
  }
  out.friendship = addFriendship(idx, c, Math.floor(runFormula(idx, 'walkFriendship', { steps: counted, friendship: c.friendship }, rng)), t);
  out.exp = Math.max(0, Math.floor(runFormula(idx, 'walkExp', { steps: counted, level: c.level }, rng)));
  if (out.exp) out.events.push(...gainExp(idx, c, out.exp, t));
  // walking also keeps a creature happy but tired
  tickNeeds(idx, c, t);
  c.needs.joy = clamp(c.needs.joy + counted / 400, 0, 100);
  c.needs.energy = clamp(c.needs.energy - counted / 800, idx.ds.rules.needsFloor ?? 10, 100);

  const per = idx.ds.rules.stepsPerFind ?? 500;
  w.stepsSinceFind = (w.stepsSinceFind ?? 0) + counted;
  const findable = idx.ds.items.filter((it) => !it.unlimited);
  while (w.stepsSinceFind >= per && findable.length) {
    w.stepsSinceFind -= per;
    const chance = runFormula(idx, 'walkFindChance', { friendship: c.friendship }, rng);
    if (rng() * 100 < chance) out.finds.push(rng.pick(findable).id);
  }
  const evo = checkEvolution(idx, c);
  if (evo && !out.events.some((e) => e.type === 'canEvolve')) out.events.push({ type: 'canEvolve', to: evo.to, method: evo.method });
  touch(c, t);
  return out;
}
