// Ranch care (needs, petting, feeding, play) and walking friendship.
import { quirksOf, hasQuirk, quirkMul, quirkVal, QUIRK_FX } from './quirks.js';
import { noteLegit } from './legit.js';
import { keepPromise } from './promises.js';
import { runFormula } from './dataset.js';
import { addMemory, gainExp, todayKey, touch, checkEvolution } from './creature.js';
import { createRng } from './rng.js';
import { experience, prefBonus } from './memory.js';
import { movementOf } from './forms.js';
import { walkFind, itemInfo } from './shop.js';
import { foodEffects, KIBBLE_FULLNESS } from './foods.js';
import { healTick } from './wildBattle.js';
import { satisfyCraving } from './dayMemory.js';

export const NEED_KEYS = ['fullness', 'joy', 'energy', 'hygiene'];
export const NEED_LABELS = { fullness: 'Fullness', joy: 'Joy', energy: 'Energy', hygiene: 'Tidiness' };

const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));

function isSleepTime(idx, t) {
  const [start, end] = idx.ds.rules.sleepHours ?? [22, 7];
  const h = new Date(t).getHours();
  return start > end ? h >= start || h < end : h >= start && h < end;
}

/** Bring needs up to date for the time that passed. Needs never drop below the floor. */
export function tickNeeds(idx, c, t = Date.now()) {
  // battle damage and used-up PP come back by themselves (wildBattle.js)
  try { healTick(idx, c, t); } catch { /* a creature without stats yet */ }
  const last = c.needsAt ?? t;
  const hours = Math.max(0, (t - last) / 3600000);
  if (hours <= 0) return c.needs;
  const decay = idx.ds.rules.needsDecayPerHour;
  const floor = idx.ds.rules.needsFloor ?? 10;
  const n = c.needs || (c.needs = { fullness: 80, joy: 70, energy: 90, hygiene: 90 });
  // inside a ball (carried on a walk or in a capsule) a creature rests: hunger and grooming barely change
  const inBall = c.location?.kind === 'capsule' || c.location?.kind === 'phone';
  if (!Array.isArray(c.quirks)) quirksOf(idx, c);
  for (const k of ['fullness', 'joy', 'hygiene']) n[k] = clamp(n[k] - decay[k] * hours * (inBall && k !== 'joy' ? 0.25 : 1) * quirkMul(c, QUIRK_FX.decay, k), floor, 100);
  // away for a while (the app closed, you at work): they lived through it — got tired, napped when they needed to and
  // woke up again — rather than all getting tired at once the moment you come back. Only one whose nap happened to
  // fall near the end is still asleep when you return.
  const where = c.location?.kind;
  if (hours > 0.5 && !c.egg && !['capsule', 'phone', 'away', 'daycare', 'game'].includes(where)) {
    livedThrough(idx, c, last, t);
    c.needsAt = t;
    return n;
  }
  // energy recovers while asleep (night hours or when resting in a capsule on the dock)
  const sleeping = isSleepTime(idx, t) || c.location?.kind === 'capsule';
  // a nap: they sleep on (wherever they're moved to) until they wake by themselves, or you wake them
  if (c.sleep) {
    // energy comes back steadily while they sleep: empty to full in 90 minutes (twice as fast from a Dream Ball)
    const until = c.sleep.until ?? t;
    const napped = Math.max(0, (Math.min(t, until) - Math.max(last, c.sleep.since ?? last)) / 3600000);
    n.energy = clamp(n.energy + napped * napRate(c), floor, 100);
    if (t >= until) c.sleep = null;
  }
  const evening = hasQuirk(c, 'early-bird') && new Date(t).getHours() >= 18 ? 1.4 : 1;
  n.energy = clamp(n.energy + (sleeping ? 12 : -decay.energy * quirkMul(c, QUIRK_FX.decay, 'energy') * evening) * hours, floor, 100);
  selfNap(idx, c, t);
  // an egg warms up over time even without walking, so it always hatches eventually
  if (c.egg) eggSteps(c, hours * 60 * EGG_PASSIVE_PER_MIN, t);
  c.needsAt = t;
  return n;
}

/** Energy over a long stretch, hour by hour: tiring by day, resting at night, and napping whenever it ran low. */
function livedThrough(idx, c, from, to) {
  const n = c.needs, floor = idx.ds.rules.needsFloor ?? 10, decay = idx.ds.rules.needsDecayPerHour;
  const H = 3600000;
  let cur = from, guard = 0;
  // (with nobody about and nothing going on, they nap sooner than they would with you there: each at its own
  // point, so they don't all doze off together)
  const own = [...String(c.uid ?? '')].reduce((a, ch) => (a * 31 + ch.charCodeAt(0)) >>> 0, 7) % 21;
  const quietAt = Math.max(selfNapAt(c), 40 + own);
  // (very long absences: the far past doesn't matter, only the last week)
  if (to - cur > 7 * 24 * H) cur = to - 7 * 24 * H;
  while (cur < to && guard++ < 400) {
    // napping: energy back steadily until it wakes by itself
    if (c.sleep && (c.sleep.until ?? 0) > cur) {
      const end = Math.min(to, c.sleep.until);
      n.energy = clamp(n.energy + ((end - cur) / H) * napRate(c), floor, 100);
      cur = end;
      if (cur >= c.sleep.until) c.sleep = null;
      continue;
    }
    if (c.sleep) c.sleep = null;
    const step = Math.min(H, to - cur);
    const night = isSleepTime(idx, cur);
    const evening = hasQuirk(c, 'early-bird') && new Date(cur).getHours() >= 18 ? 1.4 : 1;
    const rate = night ? 12 : -decay.energy * quirkMul(c, QUIRK_FX.decay, 'energy') * evening; // per hour
    const thr = cur - from >= H ? quietAt : selfNapAt(c);
    if (rate < 0 && n.energy + rate * (step / H) < thr && (c.lastNap ?? 0) <= cur - 20 * 60000 && !(c.busyUntil > cur)) {
      // it got tired partway through this hour: it curled up for a nap then
      const dt = Math.max(0, ((n.energy - thr) / -rate) * H);
      cur += dt;
      n.energy = clamp(Math.min(n.energy, thr), floor, 100);
      c.lastNap = cur;
      c.sleep = { since: cur, until: cur + Math.ceil(((napEnd(c) - n.energy) / napRate(c)) * H), self: true };
      continue;
    }
    n.energy = clamp(n.energy + rate * (step / H), floor, 100);
    cur += step;
  }
}

// ---------- eggs ----------
// An egg counts down steps. Walking with it counts double; time alone also counts (about two
// days for an average egg), so an egg left in a box still hatches.
export const EGG_DEFAULT_STEPS = 5120;
export const EGG_PASSIVE_PER_MIN = 2; const EGG_WALK_RATE = 2;
export function makeEgg(c, steps = EGG_DEFAULT_STEPS, t = Date.now()) {
  const s = Math.max(256, Math.round(steps));
  c.egg = { steps: s, total: s, at: t };
  return c;
}
/** Take steps off an egg; returns true when it hatched just now. */
export function eggSteps(c, n, t = Date.now()) {
  if (!c.egg || !(n > 0)) return false;
  c.egg.steps = Math.max(0, c.egg.steps - n);
  if (c.egg.steps > 0) return false;
  delete c.egg;
  c.hatchedAt = t;
  addMemory(c, 'Hatched from an egg.', t);
  return true;
}
/** 0…1 of the way to hatching. */
export function eggProgress(c) { return c.egg ? 1 - c.egg.steps / (c.egg.total || EGG_DEFAULT_STEPS) : 1; }

// ---------- one-on-one care ----------
const GROOM_STEPS = { wash: { hygiene: 25, joy: 1 }, brush: { hygiene: 15, joy: 4 }, comb: { hygiene: 10, joy: 5 }, towel: { joy: 2 }, dry: { joy: 3 } };
/** Toys anyone can play with in the care room (items of kind "toy" from your data set join them). */
export const CARE_TOYS = [
  { id: 'ball', name: 'Bouncy ball' }, { id: 'feather', name: 'Feather wand' }, { id: 'plush', name: 'Plush' },
  { id: 'bell', name: 'Jingle bell' }, { id: 'ribbon', name: 'Ribbon' },
];
// ---------- toys you own ----------
// Everyone starts with four (a bouncy ball, a feather wand, a flying disc and a plush); the rest are bought from the
// market, once, and kept. What you own is what's in the toy bag, the care room and the R.A.N.C.H.'s toy chest.
export const STARTER_TOYS = ['ball', 'feather', 'disc', 'plush'];
export const TOY_SHOP = [
  { id: 'ball', name: 'Bouncy ball', price: 0, desc: 'Bounces everywhere.' },
  { id: 'feather', name: 'Feather wand', price: 0, desc: 'Floats and flutters: impossible not to chase.' },
  { id: 'disc', name: 'Flying disc', price: 0, desc: 'Glides a long way. Fetch!' },
  { id: 'plush', name: 'Plush', price: 0, desc: 'Soft and huggable.' },
  { id: 'duck', name: 'Squeaky duck', price: 180, desc: 'Squeaks when it’s pounced on. Water types love it.' },
  { id: 'bell', name: 'Jingle bell', price: 150, desc: 'Jingles as it rolls.' },
  { id: 'ribbon', name: 'Ribbon', price: 160, desc: 'A long, twirly ribbon that drifts down slowly.' },
  { id: 'yarn', name: 'Yarn ball', price: 140, desc: 'Unravels a little every time it’s batted.' },
  { id: 'bone', name: 'Squeaky bone', price: 200, desc: 'Something to carry around proudly.' },
  { id: 'rope', name: 'Tug rope', price: 240, desc: 'For tug-of-war (and chewing).' },
  { id: 'chew', name: 'Chew ring', price: 220, desc: 'A tough rubber ring that bounces in odd directions.' },
  { id: 'cube', name: 'Puzzle cube', price: 320, desc: 'Rattles with treats inside. Clever ones love it.' },
  { id: 'drum', name: 'Toy drum', price: 380, desc: 'Bang, bang! Music-lovers can’t leave it alone.' },
  { id: 'pinwheel', name: 'Pinwheel', price: 260, desc: 'Spins in the breeze; floats when thrown.' },
  { id: 'beachball', name: 'Beach ball', price: 300, desc: 'Big, light and very bouncy.' },
];
/** The toys you own ([{ id, name }]). (An older save starts with the four starters.) */
export function ownedToys(save) {
  const own = save?.toysOwned ?? Object.fromEntries(STARTER_TOYS.map((id) => [id, true]));
  return TOY_SHOP.filter((t) => own[t.id]).map(({ id, name }) => ({ id, name }));
}
export function ownsToy(save, id) { return !!(save?.toysOwned ?? Object.fromEntries(STARTER_TOYS.map((x) => [x, true])))[id]; }
export function buyToy(save, id) {
  const t = TOY_SHOP.find((x) => x.id === id);
  if (!t) return { ok: false, reason: 'No such toy.' };
  save.toysOwned ??= Object.fromEntries(STARTER_TOYS.map((x) => [x, true]));
  if (save.toysOwned[id]) return { ok: false, reason: `You already have the ${t.name}.` };
  const coins = Math.floor(save.wallet ?? 0);
  if (coins < t.price) return { ok: false, reason: `Not enough coins (${t.price} needed).` };
  save.wallet = coins - t.price; save.toysOwned[id] = true;
  noteLegit(save, 'toy', id);
  return { ok: true, toy: t };
}
/** Each creature's favourite berry and toy: fixed for life, worked out from its id. */
export function favorites(idx, c) {
  let h = 2166136261;
  for (const ch of String(c?.uid ?? '')) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
  const berries = (idx.ds.items ?? []).filter((i) => i.kind === 'food' && (i.grow || /berry/i.test(i.name)));
  const toys = [...CARE_TOYS, ...(idx.ds.items ?? []).filter((i) => i.kind === 'toy')];
  return { berry: berries.length ? berries[h % berries.length].id : null, toy: toys[(h >>> 8) % toys.length].id };
}

export function mood(c, t = Date.now()) {
  const n = c.needs || {};
  if (c.sleep && (c.sleep.until ?? 0) > t) return { id: 'asleep', label: 'Asleep' };
  if ((c.upsetUntil ?? 0) > t) return { id: 'upset', label: 'Upset with you' };
  if (n.energy < 25) return { id: 'sleepy', label: 'Sleepy' };
  if (n.fullness < 30) return { id: 'hungry', label: 'Hungry' };
  if (n.hygiene < 30) return { id: 'grubby', label: 'Needs a brush' };
  if (n.joy < 30) return { id: 'bored', label: 'Bored' };
  if (n.joy > 75 && n.fullness > 50) return { id: 'happy', label: 'Happy' };
  return { id: 'content', label: 'Content' };
}

export function addFriendship(idx, c, amount, t) {
  if (!amount) return 0;
  const before = c.friendship;
  c.friendship = clamp(c.friendship + amount, 0, idx.ds.rules.maxFriendship);
  for (const tier of [100, 150, 200, 250]) {
    if (before < tier && c.friendship >= tier) addMemory(c, tier >= 250 ? 'Became inseparable from their trainer.' : `Friendship reached ${tier}.`, t, { core: tier >= 250 });
  }
  return c.friendship - before;
}

/** Friendship earned from care is capped per day so spamming the pet button does not max it out. */
function careFriendship(idx, c, amount, t) {
  const day = todayKey(t);
  if (!c.careToday || c.careToday.day !== day) c.careToday = { day, friendship: 0 };
  const room = Math.max(0, (idx.ds.rules.careFriendshipPerDay ?? 12) - c.careToday.friendship);
  const give = Math.min(room, amount);
  c.careToday.friendship += give;
  return addFriendship(idx, c, give, t);
}

// ---------- too much of a good thing ----------
// Every direct interaction adds "strain" for that kind of attention; it fades by one every few minutes.
// Past the limit they've had enough: joy drops, friendship dips and they're upset with you for a while.
export const CARE_LIMITS = { pet: 10, talk: 6, play: 6, feed: 8, groom: 6, wash: 8, brush: 10, comb: 10, towel: 10, dry: 10, dress: 6, rest: 2 };
const STRAIN_FADE_MIN = 4;   // minutes for one unit of strain to fade
export const NAP_COOLDOWN_MIN = 90;
function addStrain(c, action, t, add = 1) {
  const s = c.strain || (c.strain = {});
  const cur = s[action];
  const v = Math.max(0, (cur?.v ?? 0) - (cur ? (t - cur.at) / 60000 / STRAIN_FADE_MIN : 0)) + add;
  s[action] = { v: Math.round(v * 100) / 100, at: t };
  return v;
}
/** How worn out on one kind of attention a creature is right now, 0…1+ (1 = had enough). */
export function strainOf(c, action, t = Date.now()) {
  const cur = c.strain?.[action];
  if (!cur) return 0;
  return Math.max(0, cur.v - (t - cur.at) / 60000 / STRAIN_FADE_MIN) / (CARE_LIMITS[action] ?? 8);
}
/** Energy a napping creature gets back per hour (Dream Ball creatures sleep twice as well). */
export const NAP_RATE = 100 / 1.5;
export function isDreamBall(c) { return /dream/i.test(String(c?.ball ?? '')) || String(c?.ball ?? '') === '25' || c?.pk?.ball === 25; }
export function napRate(c, t = Date.now()) { return NAP_RATE * (isDreamBall(c) ? 2 : 1) * quirkMul(c, QUIRK_FX.napRate) * ((c.dreamHelpUntil ?? 0) > t ? 1.5 : 1); } // (a friend sharing its dreams: half as fast again)
/** Energy a nap goes up to (most sleep until full; restless ones wake sooner). */
export const napEnd = (c) => quirkVal(c, QUIRK_FX.napEnd, 100);
/** Energy below which a creature dozes off on its own. */
export const selfNapAt = (c) => quirkVal(c, QUIRK_FX.napAt, 22);
/**
 * Tired creatures nap by themselves: in the ranch, a box yard, the party or on the desktop (not inside
 * a ball out on a walk, where they rest anyway), and not again right after a nap or while upset.
 */
export function selfNap(idx, c, t = Date.now()) {
  if (!c || c.egg || c.sleep || !c.needs) return false;
  const where = c.location?.kind;
  if (where === 'capsule' || where === 'phone' || where === 'away' || where === 'daycare' || where === 'game') return false;
  if (c.needs.energy >= selfNapAt(c)) return false;
  if ((c.lastNap ?? 0) > t - 20 * 60000) return false;
  if (c.busyUntil && c.busyUntil > t) return false;
  c.lastNap = t;
  c.sleep = { since: t, until: t + Math.ceil(((napEnd(c) - c.needs.energy) / napRate(c)) * 3600000), self: true };
  return true;
}
/** Creatures of dreams: they still show feelings while they sleep. */
export const DREAMERS = /munna|musharna|darkrai|cresselia/i;
/** Asleep from a nap right now? */
export function isAsleep(c, t = Date.now()) { return !!(c?.sleep && (c.sleep.until ?? 0) > t); }
/** Minutes of nap left (0: awake). */
export function sleepLeft(c, t = Date.now()) { return isAsleep(c, t) ? Math.ceil((c.sleep.until - t) / 60000) : 0; }
/** Minutes until a nap will do anything again (0: ready). */
export function napWait(c, t = Date.now()) { return Math.max(0, Math.ceil(NAP_COOLDOWN_MIN - (t - (c.lastNap ?? 0)) / 60000)); }
/** Fire-natured creatures don't take baths: brush and comb them clean instead. */
export function avoidsWater(idx, c) {
  const sp = idx.species.get(c.formId ?? c.speciesId) ?? idx.species.get(c.speciesId);
  return sp ? !movementOf(idx, sp, c).water : false;
}
/** Whether waking them now might make them grumpy (only when they're still tired). */
export const wakeRisk = (c) => (c?.needs?.energy ?? 100) < 70;
export const WAKE_HINT = 'They’re still tired, so they might be grumpy if woken now.';
/** What made them upset most recently (kept after it passes, for the journal) and what helps. */
const UPSET_HELP = {
  'woken up while still tired': 'Let them finish their naps. It passes on its own in a minute or two; a favourite berry makes it up to them.',
  'being fussed over too much': 'Give them a little space, then try again gently. A calming berry (Persim, Lum, Nanab, Rawst), Bitter Tonic or Persim Tea helps right away.',
  'being made to play while worn out': 'Let them nap first; play once their energy is back.',
  'being fed when already full': 'Wait until they’re hungry again; offer food when the fullness bar is low.',
  'kibble again and again': 'Mix it up: berries or a home-cooked dish instead of plain kibble.',
};
export function noteUpset(c, reason, t = Date.now()) {
  c.lastUpset = { t, reason, help: UPSET_HELP[reason] ?? 'Some space, then something they like (a favourite berry or toy) makes it better.' };
  (c.today ??= { day: null, notes: [] }).notes?.push?.({ t, kind: 'upset', key: reason, w: 3 });
}
function annoyed(idx, c, t, joy = -8, text = null, reason = null) {
  const n = c.needs;
  if (reason || (c.upsetUntil ?? 0) <= t) c.upsetReason = reason ?? 'being fussed over too much';
  n.joy = clamp(n.joy + joy, 0, 100);
  c.friendship = clamp(c.friendship - 1, 0, idx.ds.rules.maxFriendship);
  c.upsetUntil = t + 8 * 60000;
  c.upsetCount = (c.upsetCount ?? 0) + 1;
  if (!c.upsetReason) c.upsetReason = 'being fussed over too much';
  noteUpset(c, c.upsetReason, t);
  if (text) { c.firsts = c.firsts || {}; if (!c.firsts.upset) { c.firsts.upset = t; addMemory(c, text, t); } }
  touch(c, t);
  return { ok: true, reaction: 'annoyed', friendship: -1, needs: { ...n }, upset: true };
}

/**
 * Care actions: 'pet', 'feed', 'play', 'groom', 'talk'. Food/toys/grooming items come from
 * the dataset item list; items without `unlimited` are taken from the inventory.
 * Returns { ok, reaction, friendship, needs, consumed }.
 */
export function applyCare(idx, c, action, opts = {}) {
  const t = opts.at ?? Date.now();
  tickNeeds(idx, c, t);
  const n = c.needs;
  let delta = {}, friend = 0, reaction = 'happy', consumed = null, craved = false;
  const item = opts.item ? (idx.items.get(opts.item) ?? itemInfo(idx, opts.item)) : null;

  if (item && !item.unlimited && opts.inventory) {
    if (!(opts.inventory[item.id] > 0)) return { ok: false, reason: `No ${item.name} left.` };
  }
  if (c.sleep && (c.sleep.until ?? 0) <= t) c.sleep = null;
  if (c.sleep && action === 'wake') {
    // woken early: they keep the energy they've got back so far; the more tired they still are, the
    // likelier they're grumpy about it (a small thing, over quickly)
    c.sleep = null;
    const chance = Math.max(0, (70 - n.energy) / 100);
    const r = ((t / 7919) % 1 + (c.uid?.length ?? 3) * 0.137) % 1;
    if (r < chance) {
      n.joy = clamp(n.joy - 3, 0, 100);
      c.upsetUntil = Math.max(c.upsetUntil ?? 0, t + 90 * 1000);
      c.upsetReason = 'woken up while still tired';
      noteUpset(c, c.upsetReason, t);
      touch(c, t);
      return { ok: true, reaction: 'grumpy', friendship: 0, needs: { ...n }, woke: true };
    }
    touch(c, t);
    return { ok: true, reaction: 'awake', friendship: 0, needs: { ...n }, woke: true };
  }
  if (action === 'wake') return { ok: true, reaction: 'awake', friendship: 0, needs: { ...n } };
  if (c.sleep && action === 'rest') return { ok: true, asleep: true, reaction: 'sleep', friendship: 0, needs: { ...n } };
  if (c.sleep && !['pet', 'tap'].includes(action)) return { ok: false, asleep: true, reason: 'They’re asleep.' };
  if (c.sleep && action === 'pet') { n.joy = clamp(n.joy + 2, 0, 100); touch(c, t); return { ok: true, reaction: 'sleep', friendship: 0, needs: { ...n } }; }
  if (action === 'wash' && avoidsWater(idx, c)) return { ok: false, reason: 'Water and this one don’t mix. Brush and comb it clean instead.' };
  // direct attention (you clicked them) wears thin; things happening around the yard don't count
  const direct = opts.direct !== false;
  let worn = 0;
  if (direct && CARE_LIMITS[action]) {
    worn = addStrain(c, action, t, opts.weight ?? 1) / CARE_LIMITS[action] * (hasQuirk(c, 'hothead') ? 1.35 : 1);
    if (worn > 1) return annoyed(idx, c, t, -8, 'Got fed up after being fussed over too much.');
  }
  // already happy, tired or full: being pestered anyway is annoying
  if (direct && action === 'play' && n.energy < 15 && !opts.asked) { if (addStrain(c, 'play', t, 2) / CARE_LIMITS.play > 0.6) return annoyed(idx, c, t, -5, null, 'being made to play while worn out'); n.joy = clamp(n.joy - 3, 0, 100); return { ok: true, reaction: 'tired', friendship: 0, needs: { ...n } }; }
  if (direct && action === 'feed' && n.fullness >= 95) { if (addStrain(c, 'feed', t, 2) / CARE_LIMITS.feed > 0.6) return annoyed(idx, c, t, -5, null, 'being fed when already full'); n.joy = clamp(n.joy - 3, 0, 100); return { ok: true, reaction: 'full', friendship: 0, needs: { ...n } }; }
  if (action === 'rest') {
    if (n.energy >= 90) {
      if (direct) n.joy = clamp(n.joy - 3, 0, 100);
      return { ok: true, reaction: 'awake', friendship: 0, needs: { ...n }, reason: 'Not sleepy right now.' };
    }
    c.lastNap = t;
    // a nap lasts until they're full of energy again (90 minutes from empty), unless you wake them first
    c.sleep = { since: t, until: t + Math.ceil(((napEnd(c) - n.energy) / napRate(c)) * 3600000) };
  }

  switch (action) {
    case 'pet':
      delta = { joy: 6 + (hasQuirk(c, 'cuddly') ? 5 : 0) - (hasQuirk(c, 'independent') ? 3 : 0) };
      friend = n.joy < 95 ? 1 : 0;
      reaction = 'hearts';
      break;
    case 'tap':
      // a gentle tap on the ball: the creature inside notices you
      delta = { joy: 2 };
      friend = 0.25;
      reaction = 'note';
      break;
    case 'talk':
      delta = { joy: 3 };
      friend = 0.5;
      reaction = 'listen';
      break;
    case 'feed': {
      const food = item?.kind === 'food' ? item : idx.items.get('kibble') ?? { id: 'kibble', unlimited: true, fullness: KIBBLE_FULLNESS, joy: 2 };
      if (n.fullness >= 95) return { ok: true, reaction: 'full', friendship: 0, needs: n };
      const fx = foodEffects(food);
      delta = { fullness: fx.fullness, joy: fx.joy, energy: fx.energy, ...(fx.hygiene ? { hygiene: fx.hygiene } : {}) };
      if (hasQuirk(c, 'glutton')) delta.joy = (delta.joy ?? 0) + 4;
      if (hasQuirk(c, 'picky')) delta.joy = Math.round((delta.joy ?? 0) * ((c.prefs?.[`food:${food.id}`] ?? 0) >= 2 ? 1.6 : 0.5));
      friend = fx.friendship;
      reaction = fx.joy >= 10 ? 'delighted' : 'munch';
      consumed = food.unlimited ? null : food.id;
      if (!food.unlimited && satisfyCraving(idx, c, food.id, t)) { delta.joy = (delta.joy ?? 0) + 10; friend += 1; reaction = 'delighted'; craved = true; }
      if (fx.calm && (c.upsetUntil ?? 0) > t) { c.upsetUntil = t; c.upsetReason = null; reaction = 'delighted'; }
      if (food.unlimited) {
        // kibble: a little at a time, and lots of it gets old unless they really love it
        delta.fullness = Math.min(delta.fullness, KIBBLE_FULLNESS);
        const day = todayKey(t);
        c.kibble = c.kibble?.day === day ? c.kibble : { day, n: 0 };
        c.kibble.n++;
        const love = c.prefs?.[`food:${food.id}`] ?? 0;
        const tooMuch = c.kibble.n - (love >= 3 ? 10 : love > 0 ? 6 : 3);
        if (tooMuch > 0) {
          delta.joy = (delta.joy ?? 0) - tooMuch * (love < 0 ? 5 : 3);
          friend = 0;
          reaction = 'meh';
          if (tooMuch >= 4) return annoyed(idx, c, t, -6, null, 'kibble again and again');
        }
      }
      break;
    }
    case 'play': {
      const toy = item?.kind === 'toy' ? item : { joy: 20, energy: -10, friendship: 2 };
      // (worn out: no — unless it asked to play itself)
      if (n.energy < 15 && !opts.asked) return { ok: true, reaction: 'tired', friendship: 0, needs: n };
      delta = { joy: toy.joy ?? 20, energy: Math.max(-(n.energy - 2), toy.energy ?? -10), fullness: -4 };
      friend = toy.friendship ?? 2;
      reaction = 'play';
      consumed = toy.unlimited ? null : toy.id ?? null;
      break;
    }
    case 'groom': {
      const tool = item?.kind === 'groom' ? item : { hygiene: 40, joy: 6, friendship: 1 };
      delta = { hygiene: tool.hygiene ?? 40, joy: tool.joy ?? 0 };
      friend = tool.friendship ?? 1;
      reaction = 'sparkle';
      consumed = tool.unlimited ? null : tool.id ?? null;
      break;
    }
    // one-on-one care (the R.A.N.C.H. care room): each step of a proper groom
    case 'wash': case 'brush': case 'comb': case 'towel': case 'dry':
      delta = GROOM_STEPS[action];
      if (hasQuirk(c, 'clean-freak')) delta = { ...delta, joy: (delta.joy ?? 0) + 3 };
      friend = 0.5;
      reaction = 'sparkle';
      break;
    case 'rest':
      delta = {};
      reaction = 'sleep';
      break;
    case 'dress':
      // putting something on them; they come to like what you give them (see experience below)
      delta = { joy: 5 };
      friend = 0.5;
      reaction = 'sparkle';
      break;
    default:
      return { ok: false, reason: `Unknown action ${action}` };
  }
  // what this involved, for their likes and dislikes; things they love bring more joy
  const keys = careKeys(action, item, opts);
  if (keys.length && delta.joy) delta = { ...delta, joy: Math.round(delta.joy * prefBonus(c, keys)) };
  // their favourite berry or toy: they light up
  if (opts.favorite) { delta = { ...delta, joy: (delta.joy ?? 0) + 10 }; friend += 2; reaction = 'delighted'; }
  // nearly fed up: it still works, but less
  if (worn > 0.7 && delta.joy > 0) { delta = { ...delta, joy: Math.round(delta.joy / 3) }; friend /= 3; reaction = action === 'feed' ? reaction : 'meh'; }
  for (const [k, v] of Object.entries(delta)) n[k] = clamp((n[k] ?? 50) + v, 0, 100);
  // little firsts worth remembering
  c.firsts = c.firsts || {};
  // firsts go in the journal; only finding a favourite is worth a core memory
  const first = (key, text, core = false) => { if (!c.firsts[key]) { c.firsts[key] = t; addMemory(c, text, t, { core }); } };
  if (action === 'feed' && item) first(`food:${item.id}`, `Tasted ${item.name} for the first time${(item.joy ?? 0) >= 10 ? ' and loved it' : ''}.`);
  if (action === 'play') first('play', 'Played catch together for the first time.');
  if (action === 'groom' || action === 'brush') first('groom', 'Got brushed for the first time.');
  if (action === 'wash') first('wash', 'Had a bath for the first time.');
  if (action === 'dress') first('dress', 'Got dressed up for the first time.');
  if (opts.favorite) first(`fav:${opts.item ?? opts.toy ?? action}`, `Found out how much they love ${item?.name ?? opts.toyName ?? 'that'}.`, true);
  if (action === 'pet' && c.friendship >= 150) first('pet150', 'Leaned into a pat, completely at ease.');
  if (action === 'tap') first('tap', 'Felt a gentle tap on the capsule while out on a walk.');
  // fractional friendship accumulates
  c._friendFrac = (c._friendFrac ?? 0) + friend;
  const whole = Math.floor(c._friendFrac);
  c._friendFrac -= whole;
  const gained = careFriendship(idx, c, whole, t);
  if (consumed && opts.inventory) opts.inventory[consumed] = Math.max(0, (opts.inventory[consumed] ?? 0) - 1);
  if (keys.length) experience(c, keys, Math.min(10, (delta.joy ?? 0) / 2 + (opts.favorite ? 4 : 0)), { t, label: CARE_LABELS[action], coreChance: 0.006 });
  touch(c, t);
  // something it was promised (a treat it won, the pets it was owed): it knows this is that
  let kept = null;
  try { const pk = action === 'feed' && item ? 'food' : action === 'pet' ? 'pets' : action === 'play' ? 'toy' : null; if (pk) kept = keepPromise(idx, opts.save ?? null, c, pk, t)?.note ?? null; } catch { /* fine */ }
  return { ok: true, reaction, friendship: gained, needs: { ...n }, consumed, worn, craved, kept };
}

const CARE_LABELS = { dress: 'a favourite outfit', wash: 'one long, bubbly bath', brush: 'a slow afternoon of brushing', pet: 'a quiet moment of being petted', play: 'one especially fun game', feed: 'one particularly tasty treat' };
function careKeys(action, item, opts) {
  switch (action) {
    case 'pet': return ['activity:pet'];
    case 'feed': return [`food:${item?.id ?? 'kibble'}`];
    case 'play': return [`toy:${opts.toy ?? item?.id ?? 'ball'}`, opts.fetch ? 'activity:fetch' : 'activity:play'];
    case 'groom': case 'brush': case 'comb': return ['activity:brush'];
    case 'wash': case 'towel': case 'dry': return ['activity:bath'];
    case 'rest': return ['activity:nap'];
    case 'dress': return [`clothes:${item?.id ?? opts.item}`];
    default: return [];
  }
}

/**
 * What a walk was like (from the phone: places nearby, weather, time, speed) and how it felt.
 * ctx: { env: ['water'], places: ['beach'], weather: 'rain', temp, tod, vehicle, speedKmh }
 */
const TOD_WORD = { dawn: 'early-morning', day: 'afternoon', dusk: 'evening', night: 'late-night' };
const WEATHER_ADJ = { sun: 'sunny', clouds: 'cloudy', rain: 'rainy', storm: 'stormy', snow: 'snowy', fog: 'foggy', wind: 'windy' };
const PLACE_PHRASE = { beach: 'on the beach', park: 'through the park', river: 'along the river', cemetery: 'past the old graveyard', 'city-centre': 'through the busy streets', countryside: 'out in the countryside', industrial: 'past the factories', hospital: 'by the hospital', temple: 'past the shrine', sports: 'around the sports ground', farm: 'past the farms', wetland: 'through the marsh', rocky: 'over the rocks', peak: 'up high' };
const ENV_PHRASE = { urban: 'through the city', forest: 'in the woods', water: 'by the water', plains: 'across the fields', mountain: 'in the hills', desert: 'in the desert', snow: 'in the snow', cave: 'underground' };
export function walkKeys(ctx = {}) {
  const keys = [];
  for (const e of ctx.env ?? []) keys.push(`env:${e}`);
  for (const p of ctx.places ?? []) keys.push(`place:${p}`);
  if (ctx.weather) keys.push(`weather:${ctx.weather}`);
  if (Number.isFinite(ctx.temp)) { if (ctx.temp >= 28) keys.push('weather:hot'); else if (ctx.temp <= 3) keys.push('weather:cold'); }
  if (ctx.tod) keys.push(`time:${ctx.tod}`);
  keys.push(ctx.vehicle ? 'activity:car' : (ctx.speedKmh ?? 0) > 8 ? 'activity:run' : 'activity:walk');
  return keys;
}
export function walkExperience(c, ctx, steps, t = Date.now()) {
  const keys = walkKeys(ctx);
  const n = c.needs ?? {};
  let joy = 3 + Math.min(4, steps / 1500) + ((n.joy ?? 60) - 50) / 20 + (ctx.vehicle ? 2 : 0);
  joy *= prefBonus(c, keys);
  const where = ctx.places?.[0] ? PLACE_PHRASE[ctx.places[0]] : ctx.env?.[0] ? ENV_PHRASE[ctx.env[0]] : '';
  const label = ctx.vehicle ? `that ${WEATHER_ADJ[ctx.weather] ?? ''} car ride`.replace(/\s+/g, ' ')
    : `that ${[WEATHER_ADJ[ctx.weather], TOD_WORD[ctx.tod]].filter(Boolean).join(' ')} walk ${where}`.replace(/\s+/g, ' ').trim();
  return experience(c, keys, Math.min(10, joy), { t, label, coreChance: 0.03 });
}

const STEP_MILESTONES = [1000, 5000, 10000, 25000, 50000, 100000, 250000, 500000, 1000000];

/**
 * Apply steps walked together (from the phone pedometer or a capsule).
 * Deterministic for a given event id so phone and PC compute the same finds.
 */
export function applyWalk(idx, c, steps, opts = {}) {
  const t = opts.at ?? Date.now();
  const rng = createRng(opts.seed ?? `${c.uid}:${t}:${steps}`);
  steps = Math.max(0, Math.floor(steps));
  const out = { steps: 0, friendship: 0, exp: 0, events: [], finds: [] };
  if (!steps) return out;
  if (c.egg) {
    // eggs don't gain anything from a walk except getting closer to hatching
    out.steps = steps;
    if (eggSteps(c, steps * EGG_WALK_RATE, t)) out.events.push({ kind: 'hatched', text: 'The egg hatched!' });
    return out;
  }
  const day = todayKey(t);
  const w = c.walk || (c.walk = { totalSteps: 0, day, todaySteps: 0, stepsSinceFind: 0 });
  if (w.day !== day) { w.day = day; w.todaySteps = 0; }
  const cap = idx.ds.rules.walkDailyStepCap ?? 40000;
  const counted = Math.max(0, Math.min(steps, cap - w.todaySteps));
  if (!w.totalSteps && counted > 0) addMemory(c, 'Went on a first walk together.', t);
  // where, when and how the walk went shapes what they come to love (memory.js)
  if (counted > 0 && opts.context) walkExperience(c, opts.context, counted, t);
  const before = w.totalSteps;
  w.totalSteps += counted;
  w.todaySteps += counted;
  out.steps = counted;
  for (const m of STEP_MILESTONES) {
    if (before < m && w.totalSteps >= m) addMemory(c, `Walked ${m.toLocaleString('en-US')} steps together.`, t, { core: m >= 100000 });
  }
  out.friendship = addFriendship(idx, c, Math.floor(runFormula(idx, 'walkFriendship', { steps: counted, friendship: c.friendship }, rng)), t);
  out.exp = Math.max(0, Math.floor(runFormula(idx, 'walkExp', { steps: counted, level: c.level }, rng)));
  if (out.exp) out.events.push(...gainExp(idx, c, out.exp, t));
  // walking also keeps a creature happy but tired
  tickNeeds(idx, c, t);
  c.needs.joy = clamp(c.needs.joy + counted / 400, 0, 100);
  c.needs.energy = clamp(c.needs.energy - counted / 800, idx.ds.rules.needsFloor ?? 10, 100);

  const per = idx.ds.rules.stepsPerFind ?? 500;
  w.stepsSinceFind = (w.stepsSinceFind ?? 0) + counted;
  // now and then: a few coins, a berry, or something shiny to sell
  out.coins = 0;
  while (w.stepsSinceFind >= per) {
    w.stepsSinceFind -= per;
    const chance = runFormula(idx, 'walkFindChance', { friendship: c.friendship }, rng);
    if (rng() * 100 >= chance) continue;
    const f = walkFind(idx, rng);
    if (f.coins) out.coins += f.coins; else if (f.item) out.finds.push(f.item);
  }
  const evo = checkEvolution(idx, c);
  if (evo && !out.events.some((e) => e.type === 'canEvolve')) out.events.push({ type: 'canEvolve', to: evo.to, method: evo.method });
  touch(c, t);
  return out;
}

/**
 * What's going on with them and what would help, in plain words (the R.A.N.C.H. shows it big, bottom left):
 * { mood, title, why, help } or null when they're fine.
 */
export function moodNote(idx, c, name = 'They', t = Date.now()) {
  const m = mood(c, t);
  const liked = Object.entries(c.prefs ?? {}).filter(([k, v]) => k.startsWith('food:') && v >= 2).sort((a, b) => b[1] - a[1]).map(([k]) => itemInfo(idx, k.slice(5))?.name).filter(Boolean);
  const mins = (x) => Math.max(1, Math.ceil((x - t) / 60000));
  if (m.id === 'asleep') return { mood: m.id, title: `${name} is asleep`, why: `Napping: wakes by themselves in about ${mins(c.sleep.until)} min.`, help: 'Let them sleep; they’ll wake up by themselves.' };
  if (m.id === 'upset') {
    const why = c.upsetReason ? `Because of ${c.upsetReason}.` : 'Too much fuss, too fast.';
    return { mood: m.id, title: `${name} is upset with you`, why: `${why} It passes in about ${mins(c.upsetUntil)} min.`, help: `They’d rather have some space. A calming berry (Persim, Lum, Nanab, Rawst) or a Bitter Tonic or Persim Tea makes it better straight away${liked.length ? `, and so might their favourite: ${liked[0]}` : ''}.` };
  }
  if (m.id === 'hungry') return { mood: m.id, title: `${name} is hungry`, why: 'Their tummy is rumbling.', help: liked.length ? `They’d rather have ${liked.slice(0, 2).join(' or ')} than kibble.` : 'Berries fill them up and cheer them up; kibble is fine in small amounts.' };
  if (m.id === 'sleepy') return { mood: m.id, title: `${name} is sleepy`, why: 'Low on energy.', help: 'A nap brings it back (and they sleep on wherever you move them). Leppa, Sitrus or Chesto berries help too.' };
  if (m.id === 'grubby') return { mood: m.id, title: `${name} needs a brush`, why: 'A bit grubby.', help: 'Quality time: wash, brush and comb them.' };
  if (m.id === 'bored') return { mood: m.id, title: `${name} is bored`, why: 'Not much going on.', help: 'Throw a toy, play together, or try an activity.' };
  return null;
}
