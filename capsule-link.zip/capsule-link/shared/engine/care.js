// Ranch care (needs, petting, feeding, play) and walking friendship.
import { runFormula } from './dataset.js';
import { addMemory, gainExp, todayKey, touch, checkEvolution } from './creature.js';
import { createRng } from './rng.js';
import { experience, prefBonus } from './memory.js';
import { movementOf } from './forms.js';
import { walkFind, itemInfo } from './shop.js';

export const NEED_KEYS = ['fullness', 'joy', 'energy', 'hygiene'];
export const NEED_LABELS = { fullness: 'Fullness', joy: 'Joy', energy: 'Energy', hygiene: 'Tidiness' };

const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));

function isSleepTime(idx, t) {
  const [start, end] = idx.ds.rules.sleepHours ?? [22, 7];
  const h = new Date(t).getHours();
  return start > end ? h >= start || h < end : h >= start && h < end;
}

/** Bring needs up to date for the time that passed. Needs never drop below the floor. */
export function tickNeeds(idx, c, t = Date.now()) {
  const last = c.needsAt ?? t;
  const hours = Math.max(0, (t - last) / 3600000);
  if (hours <= 0) return c.needs;
  const decay = idx.ds.rules.needsDecayPerHour;
  const floor = idx.ds.rules.needsFloor ?? 10;
  const n = c.needs || (c.needs = { fullness: 80, joy: 70, energy: 90, hygiene: 90 });
  // inside a ball (carried on a walk or in a capsule) a creature rests: hunger and grooming barely change
  const inBall = c.location?.kind === 'capsule' || c.location?.kind === 'phone';
  for (const k of ['fullness', 'joy', 'hygiene']) n[k] = clamp(n[k] - decay[k] * hours * (inBall && k !== 'joy' ? 0.25 : 1), floor, 100);
  // energy recovers while asleep (night hours or when resting in a capsule on the dock)
  const sleeping = isSleepTime(idx, t) || c.location?.kind === 'capsule';
  n.energy = clamp(n.energy + (sleeping ? 12 : -decay.energy) * hours, floor, 100);
  // an egg warms up over time even without walking, so it always hatches eventually
  if (c.egg) eggSteps(c, hours * 60 * EGG_PASSIVE_PER_MIN, t);
  c.needsAt = t;
  return n;
}

// ---------- eggs ----------
// An egg counts down steps. Walking with it counts double; time alone also counts (about two
// days for an average egg), so an egg left in a box still hatches.
export const EGG_DEFAULT_STEPS = 5120;
const EGG_PASSIVE_PER_MIN = 2, EGG_WALK_RATE = 2;
export function makeEgg(c, steps = EGG_DEFAULT_STEPS, t = Date.now()) {
  const s = Math.max(256, Math.round(steps));
  c.egg = { steps: s, total: s, at: t };
  return c;
}
/** Take steps off an egg; returns true when it hatched just now. */
export function eggSteps(c, n, t = Date.now()) {
  if (!c.egg || !(n > 0)) return false;
  c.egg.steps = Math.max(0, c.egg.steps - n);
  if (c.egg.steps > 0) return false;
  delete c.egg;
  c.hatchedAt = t;
  addMemory(c, 'Hatched from an egg.', t);
  return true;
}
/** 0…1 of the way to hatching. */
export function eggProgress(c) { return c.egg ? 1 - c.egg.steps / (c.egg.total || EGG_DEFAULT_STEPS) : 1; }

// ---------- one-on-one care ----------
const GROOM_STEPS = { wash: { hygiene: 25, joy: 1 }, brush: { hygiene: 15, joy: 4 }, comb: { hygiene: 10, joy: 5 }, towel: { joy: 2 }, dry: { joy: 3 } };
/** Toys anyone can play with in the care room (items of kind "toy" from your data set join them). */
export const CARE_TOYS = [
  { id: 'ball', name: 'Bouncy ball' }, { id: 'feather', name: 'Feather wand' }, { id: 'plush', name: 'Plush' },
  { id: 'bell', name: 'Jingle bell' }, { id: 'ribbon', name: 'Ribbon' },
];
/** Each creature's favourite berry and toy: fixed for life, worked out from its id. */
export function favorites(idx, c) {
  let h = 2166136261;
  for (const ch of String(c?.uid ?? '')) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
  const berries = (idx.ds.items ?? []).filter((i) => i.kind === 'food' && (i.grow || /berry/i.test(i.name)));
  const toys = [...CARE_TOYS, ...(idx.ds.items ?? []).filter((i) => i.kind === 'toy')];
  return { berry: berries.length ? berries[h % berries.length].id : null, toy: toys[(h >>> 8) % toys.length].id };
}

export function mood(c, t = Date.now()) {
  const n = c.needs || {};
  if ((c.upsetUntil ?? 0) > t) return { id: 'upset', label: 'Upset with you' };
  if (n.energy < 25) return { id: 'sleepy', label: 'Sleepy' };
  if (n.fullness < 30) return { id: 'hungry', label: 'Hungry' };
  if (n.hygiene < 30) return { id: 'grubby', label: 'Needs a brush' };
  if (n.joy < 30) return { id: 'bored', label: 'Bored' };
  if (n.joy > 75 && n.fullness > 50) return { id: 'happy', label: 'Happy' };
  return { id: 'content', label: 'Content' };
}

export function addFriendship(idx, c, amount, t) {
  if (!amount) return 0;
  const before = c.friendship;
  c.friendship = clamp(c.friendship + amount, 0, idx.ds.rules.maxFriendship);
  for (const tier of [100, 150, 200, 250]) {
    if (before < tier && c.friendship >= tier) addMemory(c, tier >= 250 ? 'Became inseparable from their trainer.' : `Friendship reached ${tier}.`, t, { core: tier >= 250 });
  }
  return c.friendship - before;
}

/** Friendship earned from care is capped per day so spamming the pet button does not max it out. */
function careFriendship(idx, c, amount, t) {
  const day = todayKey(t);
  if (!c.careToday || c.careToday.day !== day) c.careToday = { day, friendship: 0 };
  const room = Math.max(0, (idx.ds.rules.careFriendshipPerDay ?? 12) - c.careToday.friendship);
  const give = Math.min(room, amount);
  c.careToday.friendship += give;
  return addFriendship(idx, c, give, t);
}

// ---------- too much of a good thing ----------
// Every direct interaction adds "strain" for that kind of attention; it fades by one every few minutes.
// Past the limit they've had enough: joy drops, friendship dips and they're upset with you for a while.
export const CARE_LIMITS = { pet: 10, talk: 6, play: 6, feed: 8, groom: 6, wash: 8, brush: 10, comb: 10, towel: 10, dry: 10, dress: 6, rest: 2 };
const STRAIN_FADE_MIN = 4;   // minutes for one unit of strain to fade
export const NAP_COOLDOWN_MIN = 90;
function addStrain(c, action, t, add = 1) {
  const s = c.strain || (c.strain = {});
  const cur = s[action];
  const v = Math.max(0, (cur?.v ?? 0) - (cur ? (t - cur.at) / 60000 / STRAIN_FADE_MIN : 0)) + add;
  s[action] = { v: Math.round(v * 100) / 100, at: t };
  return v;
}
/** How worn out on one kind of attention a creature is right now, 0…1+ (1 = had enough). */
export function strainOf(c, action, t = Date.now()) {
  const cur = c.strain?.[action];
  if (!cur) return 0;
  return Math.max(0, cur.v - (t - cur.at) / 60000 / STRAIN_FADE_MIN) / (CARE_LIMITS[action] ?? 8);
}
/** Minutes until a nap will do anything again (0: ready). */
export function napWait(c, t = Date.now()) { return Math.max(0, Math.ceil(NAP_COOLDOWN_MIN - (t - (c.lastNap ?? 0)) / 60000)); }
/** Fire-natured creatures don't take baths: brush and comb them clean instead. */
export function avoidsWater(idx, c) {
  const sp = idx.species.get(c.formId ?? c.speciesId) ?? idx.species.get(c.speciesId);
  return sp ? !movementOf(idx, sp, c).water : false;
}
function annoyed(idx, c, t, joy = -8, text = null) {
  const n = c.needs;
  n.joy = clamp(n.joy + joy, 0, 100);
  c.friendship = clamp(c.friendship - 1, 0, idx.ds.rules.maxFriendship);
  c.upsetUntil = t + 8 * 60000;
  c.upsetCount = (c.upsetCount ?? 0) + 1;
  if (text) { c.firsts = c.firsts || {}; if (!c.firsts.upset) { c.firsts.upset = t; addMemory(c, text, t); } }
  touch(c, t);
  return { ok: true, reaction: 'annoyed', friendship: -1, needs: { ...n }, upset: true };
}

/**
 * Care actions: 'pet', 'feed', 'play', 'groom', 'talk'. Food/toys/grooming items come from
 * the dataset item list; items without `unlimited` are taken from the inventory.
 * Returns { ok, reaction, friendship, needs, consumed }.
 */
export function applyCare(idx, c, action, opts = {}) {
  const t = opts.at ?? Date.now();
  tickNeeds(idx, c, t);
  const n = c.needs;
  let delta = {}, friend = 0, reaction = 'happy', consumed = null;
  const item = opts.item ? (idx.items.get(opts.item) ?? itemInfo(idx, opts.item)) : null;

  if (item && !item.unlimited && opts.inventory) {
    if (!(opts.inventory[item.id] > 0)) return { ok: false, reason: `No ${item.name} left.` };
  }
  if (action === 'wash' && avoidsWater(idx, c)) return { ok: false, reason: 'Water and this one don’t mix. Brush and comb it clean instead.' };
  // direct attention (you clicked them) wears thin; things happening around the yard don't count
  const direct = opts.direct !== false;
  let worn = 0;
  if (direct && CARE_LIMITS[action]) {
    worn = addStrain(c, action, t, opts.weight ?? 1) / CARE_LIMITS[action];
    if (worn > 1) return annoyed(idx, c, t, -8, 'Got fed up after being fussed over too much.');
  }
  // already happy, tired or full: being pestered anyway is annoying
  if (direct && action === 'play' && n.energy < 15) { if (addStrain(c, 'play', t, 2) / CARE_LIMITS.play > 0.6) return annoyed(idx, c, t, -5); n.joy = clamp(n.joy - 3, 0, 100); return { ok: true, reaction: 'tired', friendship: 0, needs: { ...n } }; }
  if (direct && action === 'feed' && n.fullness >= 95) { if (addStrain(c, 'feed', t, 2) / CARE_LIMITS.feed > 0.6) return annoyed(idx, c, t, -5); n.joy = clamp(n.joy - 3, 0, 100); return { ok: true, reaction: 'full', friendship: 0, needs: { ...n } }; }
  if (action === 'rest') {
    const wait = napWait(c, t);
    if (wait > 0 || n.energy >= 90) {
      if (direct) n.joy = clamp(n.joy - 3, 0, 100);
      return { ok: true, reaction: 'awake', friendship: 0, needs: { ...n }, reason: wait > 0 ? `Not sleepy: napped not long ago (try again in ${wait} min).` : 'Not sleepy right now.' };
    }
    c.lastNap = t;
  }

  switch (action) {
    case 'pet':
      delta = { joy: 6 };
      friend = n.joy < 95 ? 1 : 0;
      reaction = 'hearts';
      break;
    case 'tap':
      // a gentle tap on the ball: the creature inside notices you
      delta = { joy: 2 };
      friend = 0.25;
      reaction = 'note';
      break;
    case 'talk':
      delta = { joy: 3 };
      friend = 0.5;
      reaction = 'listen';
      break;
    case 'feed': {
      const food = item?.kind === 'food' ? item : idx.items.get('kibble') ?? { fullness: 30, joy: 2 };
      if (n.fullness >= 95) return { ok: true, reaction: 'full', friendship: 0, needs: n };
      delta = { fullness: food.fullness ?? 20, joy: food.joy ?? 0, energy: food.energy ?? 0 };
      friend = food.friendship ?? 1;
      reaction = (food.joy ?? 0) >= 10 ? 'delighted' : 'munch';
      consumed = food.unlimited ? null : food.id;
      break;
    }
    case 'play': {
      const toy = item?.kind === 'toy' ? item : { joy: 20, energy: -10, friendship: 2 };
      if (n.energy < 15) return { ok: true, reaction: 'tired', friendship: 0, needs: n };
      delta = { joy: toy.joy ?? 20, energy: toy.energy ?? -10, fullness: -4 };
      friend = toy.friendship ?? 2;
      reaction = 'play';
      consumed = toy.unlimited ? null : toy.id ?? null;
      break;
    }
    case 'groom': {
      const tool = item?.kind === 'groom' ? item : { hygiene: 40, joy: 6, friendship: 1 };
      delta = { hygiene: tool.hygiene ?? 40, joy: tool.joy ?? 0 };
      friend = tool.friendship ?? 1;
      reaction = 'sparkle';
      consumed = tool.unlimited ? null : tool.id ?? null;
      break;
    }
    // one-on-one care (the R.A.N.C.H. care room): each step of a proper groom
    case 'wash': case 'brush': case 'comb': case 'towel': case 'dry':
      delta = GROOM_STEPS[action];
      friend = 0.5;
      reaction = 'sparkle';
      break;
    case 'rest':
      delta = { energy: 45 };
      reaction = 'sleep';
      break;
    case 'dress':
      // putting something on them; they come to like what you give them (see experience below)
      delta = { joy: 5 };
      friend = 0.5;
      reaction = 'sparkle';
      break;
    default:
      return { ok: false, reason: `Unknown action ${action}` };
  }
  // what this involved, for their likes and dislikes; things they love bring more joy
  const keys = careKeys(action, item, opts);
  if (keys.length && delta.joy) delta = { ...delta, joy: Math.round(delta.joy * prefBonus(c, keys)) };
  // their favourite berry or toy: they light up
  if (opts.favorite) { delta = { ...delta, joy: (delta.joy ?? 0) + 10 }; friend += 2; reaction = 'delighted'; }
  // nearly fed up: it still works, but less
  if (worn > 0.7 && delta.joy > 0) { delta = { ...delta, joy: Math.round(delta.joy / 3) }; friend /= 3; reaction = action === 'feed' ? reaction : 'meh'; }
  for (const [k, v] of Object.entries(delta)) n[k] = clamp((n[k] ?? 50) + v, 0, 100);
  // little firsts worth remembering
  c.firsts = c.firsts || {};
  // firsts go in the journal; only finding a favourite is worth a core memory
  const first = (key, text, core = false) => { if (!c.firsts[key]) { c.firsts[key] = t; addMemory(c, text, t, { core }); } };
  if (action === 'feed' && item) first(`food:${item.id}`, `Tasted ${item.name} for the first time${(item.joy ?? 0) >= 10 ? ' and loved it' : ''}.`);
  if (action === 'play') first('play', 'Played catch together for the first time.');
  if (action === 'groom' || action === 'brush') first('groom', 'Got brushed for the first time.');
  if (action === 'wash') first('wash', 'Had a bath for the first time.');
  if (action === 'dress') first('dress', 'Got dressed up for the first time.');
  if (opts.favorite) first(`fav:${opts.item ?? opts.toy ?? action}`, `Found out how much they love ${item?.name ?? opts.toyName ?? 'that'}.`, true);
  if (action === 'pet' && c.friendship >= 150) first('pet150', 'Leaned into a pat, completely at ease.');
  if (action === 'tap') first('tap', 'Felt a gentle tap on the capsule while out on a walk.');
  // fractional friendship accumulates
  c._friendFrac = (c._friendFrac ?? 0) + friend;
  const whole = Math.floor(c._friendFrac);
  c._friendFrac -= whole;
  const gained = careFriendship(idx, c, whole, t);
  if (consumed && opts.inventory) opts.inventory[consumed] = Math.max(0, (opts.inventory[consumed] ?? 0) - 1);
  if (keys.length) experience(c, keys, Math.min(10, (delta.joy ?? 0) / 2 + (opts.favorite ? 4 : 0)), { t, label: CARE_LABELS[action], coreChance: 0.006 });
  touch(c, t);
  return { ok: true, reaction, friendship: gained, needs: { ...n }, consumed, worn };
}

const CARE_LABELS = { dress: 'a favourite outfit', wash: 'one long, bubbly bath', brush: 'a slow afternoon of brushing', pet: 'a quiet moment of being petted', play: 'one especially fun game', feed: 'one particularly tasty treat' };
function careKeys(action, item, opts) {
  switch (action) {
    case 'pet': return ['activity:pet'];
    case 'feed': return [`food:${item?.id ?? 'kibble'}`];
    case 'play': return [`toy:${opts.toy ?? item?.id ?? 'ball'}`, opts.fetch ? 'activity:fetch' : 'activity:play'];
    case 'groom': case 'brush': case 'comb': return ['activity:brush'];
    case 'wash': case 'towel': case 'dry': return ['activity:bath'];
    case 'rest': return ['activity:nap'];
    case 'dress': return [`clothes:${item?.id ?? opts.item}`];
    default: return [];
  }
}

/**
 * What a walk was like (from the phone: places nearby, weather, time, speed) and how it felt.
 * ctx: { env: ['water'], places: ['beach'], weather: 'rain', temp, tod, vehicle, speedKmh }
 */
const TOD_WORD = { dawn: 'early-morning', day: 'afternoon', dusk: 'evening', night: 'late-night' };
const WEATHER_ADJ = { sun: 'sunny', clouds: 'cloudy', rain: 'rainy', storm: 'stormy', snow: 'snowy', fog: 'foggy', wind: 'windy' };
const PLACE_PHRASE = { beach: 'on the beach', park: 'through the park', river: 'along the river', cemetery: 'past the old graveyard', 'city-centre': 'through the busy streets', countryside: 'out in the countryside', industrial: 'past the factories', hospital: 'by the hospital', temple: 'past the shrine', sports: 'around the sports ground', farm: 'past the farms', wetland: 'through the marsh', rocky: 'over the rocks', peak: 'up high' };
const ENV_PHRASE = { urban: 'through the city', forest: 'in the woods', water: 'by the water', plains: 'across the fields', mountain: 'in the hills', desert: 'in the desert', snow: 'in the snow', cave: 'underground' };
export function walkKeys(ctx = {}) {
  const keys = [];
  for (const e of ctx.env ?? []) keys.push(`env:${e}`);
  for (const p of ctx.places ?? []) keys.push(`place:${p}`);
  if (ctx.weather) keys.push(`weather:${ctx.weather}`);
  if (Number.isFinite(ctx.temp)) { if (ctx.temp >= 28) keys.push('weather:hot'); else if (ctx.temp <= 3) keys.push('weather:cold'); }
  if (ctx.tod) keys.push(`time:${ctx.tod}`);
  keys.push(ctx.vehicle ? 'activity:car' : (ctx.speedKmh ?? 0) > 8 ? 'activity:run' : 'activity:walk');
  return keys;
}
export function walkExperience(c, ctx, steps, t = Date.now()) {
  const keys = walkKeys(ctx);
  const n = c.needs ?? {};
  let joy = 3 + Math.min(4, steps / 1500) + ((n.joy ?? 60) - 50) / 20 + (ctx.vehicle ? 2 : 0);
  joy *= prefBonus(c, keys);
  const where = ctx.places?.[0] ? PLACE_PHRASE[ctx.places[0]] : ctx.env?.[0] ? ENV_PHRASE[ctx.env[0]] : '';
  const label = ctx.vehicle ? `that ${WEATHER_ADJ[ctx.weather] ?? ''} car ride`.replace(/\s+/g, ' ')
    : `that ${[WEATHER_ADJ[ctx.weather], TOD_WORD[ctx.tod]].filter(Boolean).join(' ')} walk ${where}`.replace(/\s+/g, ' ').trim();
  return experience(c, keys, Math.min(10, joy), { t, label, coreChance: 0.03 });
}

const STEP_MILESTONES = [1000, 5000, 10000, 25000, 50000, 100000, 250000, 500000, 1000000];

/**
 * Apply steps walked together (from the phone pedometer or a capsule).
 * Deterministic for a given event id so phone and PC compute the same finds.
 */
export function applyWalk(idx, c, steps, opts = {}) {
  const t = opts.at ?? Date.now();
  const rng = createRng(opts.seed ?? `${c.uid}:${t}:${steps}`);
  steps = Math.max(0, Math.floor(steps));
  const out = { steps: 0, friendship: 0, exp: 0, events: [], finds: [] };
  if (!steps) return out;
  if (c.egg) {
    // eggs don't gain anything from a walk except getting closer to hatching
    out.steps = steps;
    if (eggSteps(c, steps * EGG_WALK_RATE, t)) out.events.push({ kind: 'hatched', text: 'The egg hatched!' });
    return out;
  }
  const day = todayKey(t);
  const w = c.walk || (c.walk = { totalSteps: 0, day, todaySteps: 0, stepsSinceFind: 0 });
  if (w.day !== day) { w.day = day; w.todaySteps = 0; }
  const cap = idx.ds.rules.walkDailyStepCap ?? 40000;
  const counted = Math.max(0, Math.min(steps, cap - w.todaySteps));
  if (!w.totalSteps && counted > 0) addMemory(c, 'Went on a first walk together.', t);
  // where, when and how the walk went shapes what they come to love (memory.js)
  if (counted > 0 && opts.context) walkExperience(c, opts.context, counted, t);
  const before = w.totalSteps;
  w.totalSteps += counted;
  w.todaySteps += counted;
  out.steps = counted;
  for (const m of STEP_MILESTONES) {
    if (before < m && w.totalSteps >= m) addMemory(c, `Walked ${m.toLocaleString('en-US')} steps together.`, t, { core: m >= 100000 });
  }
  out.friendship = addFriendship(idx, c, Math.floor(runFormula(idx, 'walkFriendship', { steps: counted, friendship: c.friendship }, rng)), t);
  out.exp = Math.max(0, Math.floor(runFormula(idx, 'walkExp', { steps: counted, level: c.level }, rng)));
  if (out.exp) out.events.push(...gainExp(idx, c, out.exp, t));
  // walking also keeps a creature happy but tired
  tickNeeds(idx, c, t);
  c.needs.joy = clamp(c.needs.joy + counted / 400, 0, 100);
  c.needs.energy = clamp(c.needs.energy - counted / 800, idx.ds.rules.needsFloor ?? 10, 100);

  const per = idx.ds.rules.stepsPerFind ?? 500;
  w.stepsSinceFind = (w.stepsSinceFind ?? 0) + counted;
  // now and then: a few coins, a berry, or something shiny to sell
  out.coins = 0;
  while (w.stepsSinceFind >= per) {
    w.stepsSinceFind -= per;
    const chance = runFormula(idx, 'walkFindChance', { friendship: c.friendship }, rng);
    if (rng() * 100 >= chance) continue;
    const f = walkFind(idx, rng);
    if (f.coins) out.coins += f.coins; else if (f.item) out.finds.push(f.item);
  }
  const evo = checkEvolution(idx, c);
  if (evo && !out.events.some((e) => e.type === 'canEvolve')) out.events.push({ type: 'canEvolve', to: evo.to, method: evo.method });
  touch(c, t);
  return out;
}
