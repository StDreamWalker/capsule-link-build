// Life on a walk: what a creature in its ball seems to be thinking, and which wild creatures an
// empty ball can pick up. Until balls report real location data, the trainer says what kind of
// place they are walking through (up to two environments, like "urban + forest").
import { createRng } from './rng.js';
import { speciesOf, displayName, addMemory, createCreature } from './creature.js';
import { mood } from './care.js';

export const ENVIRONMENTS = [
  { id: 'urban', label: 'City', hint: 'Streets, buildings, parks between them' },
  { id: 'forest', label: 'Forest', hint: 'Trees, trails, shade' },
  { id: 'water', label: 'Beach / water', hint: 'Coast, lakes, rivers' },
  { id: 'plains', label: 'Fields', hint: 'Open grass, farmland, meadows' },
  { id: 'mountain', label: 'Mountains', hint: 'Hills, rocks, high ground' },
  { id: 'desert', label: 'Desert', hint: 'Dry, sandy, hot' },
  { id: 'snow', label: 'Snow', hint: 'Cold, icy, winter' },
  { id: 'cave', label: 'Underground', hint: 'Tunnels, caves, subways' },
];

// Type affinity per environment. Keys cover common type names and the built-in data set's types.
const TYPE_AFFINITY = {
  urban: { normal: 3, plain: 3, electric: 3, volt: 3, steel: 3, metal: 3, poison: 2, fighting: 2, brawl: 2, dark: 1.5, shade: 1.5, psychic: 1, mind: 1, flying: 1, gale: 1, fire: 0.6, ember: 0.6 },
  forest: { grass: 3, sprout: 3, bug: 3, fairy: 2, poison: 1.5, normal: 1, plain: 1, flying: 1, gale: 1, ghost: 0.8, dark: 0.8, shade: 0.8 },
  water: { water: 4, tide: 4, flying: 1.2, gale: 1.2, ice: 1, frost: 1, dragon: 0.6, electric: 0.5, volt: 0.5 },
  plains: { normal: 3, plain: 3, grass: 2, sprout: 2, flying: 2, gale: 2, bug: 1.5, electric: 1, volt: 1, ground: 1, fairy: 1 },
  mountain: { rock: 3, stone: 3, ground: 2, fighting: 2, brawl: 2, flying: 2, gale: 2, ice: 1, frost: 1, dragon: 1, steel: 1, metal: 1, fire: 0.8, ember: 0.8 },
  desert: { ground: 3, rock: 2, stone: 2, fire: 2, ember: 2, fighting: 1, brawl: 1, dragon: 1, poison: 0.8, bug: 0.6 },
  snow: { ice: 4, frost: 4, water: 1, tide: 1, steel: 1, metal: 1, normal: 0.5 },
  cave: { rock: 2, stone: 2, ground: 2, dark: 2, shade: 2, ghost: 2, poison: 1, steel: 1, metal: 1, dragon: 1, psychic: 0.8, mind: 0.8 },
};
const HABITAT_AFFINITY = {
  urban: ['skyline'], forest: ['forest', 'marsh'], water: ['shoreline', 'seafloor', 'marsh'], plains: ['meadow'],
  mountain: ['volcano', 'crystal', 'cavern'], desert: ['desert', 'volcano'], snow: ['tundra'], cave: ['cavern', 'crystal', 'starfield'],
};
const NIGHT_TYPES = new Set(['dark', 'shade', 'ghost', 'psychic', 'mind', 'fairy']);
const DAY_TYPES = new Set(['grass', 'sprout', 'fire', 'ember', 'bug', 'normal', 'plain', 'flying', 'gale']);

export function timeOfDay(t = Date.now()) {
  const hr = new Date(t).getHours();
  if (hr >= 5 && hr < 8) return 'dawn';
  if (hr >= 8 && hr < 17) return 'day';
  if (hr >= 17 && hr < 20) return 'dusk';
  return 'night';
}

export function normalizeEnv(list) {
  const ok = new Set(ENVIRONMENTS.map((e) => e.id));
  const out = [...new Set((Array.isArray(list) ? list : []).filter((x) => ok.has(x)))].slice(0, 2);
  return out.length ? out : ['plains'];
}

const typeKeys = (idx, sp) => (sp.types ?? []).flatMap((t) => [String(t).toLowerCase(), String(idx.types.get(t)?.name ?? '').toLowerCase()]);
const bst = (sp) => Object.values(sp.baseStats ?? {}).reduce((a, b) => a + (+b || 0), 0);

/** Species that evolve from something else, and how many steps along the line they are. */
function evoDepth(idx) {
  if (idx._evoDepth) return idx._evoDepth;
  const parent = new Map();
  for (const s of idx.ds.species) for (const e of s.evolutions ?? []) if (!parent.has(e.to)) parent.set(e.to, s.id);
  const depth = new Map();
  for (const s of idx.ds.species) {
    let d = 0, cur = s.id;
    const seen = new Set();
    while (parent.has(cur) && !seen.has(cur)) { seen.add(cur); cur = parent.get(cur); d++; }
    depth.set(s.id, d);
  }
  idx._evoDepth = depth;
  return depth;
}

/**
 * Weighted table of who can turn up. ctx: { env: ['urban','forest'], t, walkMinutes, steps }
 * Longer walks open up rarer (evolved, stronger) species; time of day shifts the types.
 */
export function encounterTable(idx, ctx = {}) {
  const env = normalizeEnv(ctx.env);
  const tod = timeOfDay(ctx.t);
  const mins = Math.max(0, ctx.walkMinutes ?? 0);
  const depth = evoDepth(idx);
  const rows = [];
  for (const sp of idx.ds.species) {
    if (sp.noWild || sp.unobtainable) continue;
    const keys = typeKeys(idx, sp);
    let w = 0.25; // anyone can wander anywhere, rarely
    for (const e of env) {
      const aff = TYPE_AFFINITY[e] ?? {};
      w += Math.max(0, ...keys.map((k) => aff[k] ?? 0));
      if (HABITAT_AFFINITY[e]?.includes(sp.habitat) && sp.habitat !== 'meadow') w += 2;
    }
    if (tod === 'night') w *= keys.some((k) => NIGHT_TYPES.has(k)) ? 2.4 : keys.some((k) => DAY_TYPES.has(k)) ? 0.55 : 1;
    else if (tod === 'day') w *= keys.some((k) => DAY_TYPES.has(k)) ? 1.3 : keys.some((k) => NIGHT_TYPES.has(k)) ? 0.6 : 1;
    else w *= keys.some((k) => NIGHT_TYPES.has(k)) ? 1.4 : 1.1; // dawn and dusk mix both
    const d = depth.get(sp.id) ?? 0;
    // evolved forms are uncommon, and become less so the longer you walk
    if (d > 0) w *= Math.min(0.6, (0.08 + mins / 300) / d);
    const total = bst(sp);
    if (total >= 580) w *= mins >= 60 ? 0.02 : 0; // the very strongest only show on long walks, and barely
    else if (total >= 500) w *= Math.min(1, 0.15 + mins / 120);
    if (w > 0) rows.push({ id: sp.id, w });
  }
  const sum = rows.reduce((a, r) => a + r.w, 0) || 1;
  return rows.map((r) => ({ ...r, p: r.w / sum })).sort((a, b) => b.w - a.w);
}

/** Chance (0..1) that the next check on this walk turns something up. */
export function encounterChance(ctx = {}) {
  const mins = Math.max(0, ctx.walkMinutes ?? 0);
  return Math.min(0.6, 0.22 + mins * 0.006);
}

/** Roll a wild encounter: { speciesId, level, catchRate, env, tod, at, seed } or null. */
export function rollEncounter(idx, ctx = {}) {
  const rng = createRng(ctx.seed ?? Date.now());
  if (rng() > encounterChance(ctx)) return null;
  const table = encounterTable(idx, ctx);
  if (!table.length) return null;
  let x = rng() * table.reduce((a, r) => a + r.w, 0);
  let pick = table[0];
  for (const r of table) { x -= r.w; if (x <= 0) { pick = r; break; } }
  const sp = idx.species.get(pick.id);
  const mins = Math.max(0, ctx.walkMinutes ?? 0);
  const d = evoDepth(idx).get(sp.id) ?? 0;
  const base = 3 + Math.min(30, mins / 3) + d * 12;
  const level = Math.max(2, Math.min(idx.ds.rules.maxLevel ?? 100, Math.round(base + (rng() * 6 - 3))));
  // stronger species are harder to hold on to
  // a catch rate from the data (0-255, as the games store it) wins over the estimate from stats
  const catchRate = sp.catchRate
    ? Math.max(0.05, Math.min(0.95, (sp.catchRate / 255) * 1.15 - level / 320))
    : Math.max(0.08, Math.min(0.9, 1.05 - bst(sp) / 720 - level / 160));
  return { speciesId: sp.id, level, catchRate, env: normalizeEnv(ctx.env), tod: timeOfDay(ctx.t), at: ctx.t ?? Date.now(), seed: Math.floor(rng() * 2 ** 31) };
}

/** Throw quality 0..1 from the timing ring → caught? */
export function tryCatch(enc, quality, rngSeed = Date.now()) {
  const rng = createRng(rngSeed);
  const q = Math.max(0, Math.min(1, quality));
  const p = Math.min(0.97, enc.catchRate * (0.45 + q * 1.1) + (q > 0.92 ? 0.15 : 0));
  return { caught: rng() < p, p };
}

const ENV_WORDS = { urban: 'the city', forest: 'the woods', water: 'the water', plains: 'open fields', mountain: 'the hills', desert: 'the desert', snow: 'the snow', cave: 'underground' };
export const envPhrase = (env) => normalizeEnv(env).map((e) => ENV_WORDS[e]).join(' and ');

/** The new creature for a successful catch. */
export function caughtCreature(idx, enc, { trainer = '', location } = {}) {
  const c = createCreature(idx, enc.speciesId, { level: enc.level, seed: enc.seed, trainer, location, metHow: `Caught on a walk in ${envPhrase(enc.env)}` });
  const when = { dawn: 'at dawn', day: 'during the day', dusk: 'at dusk', night: 'at night' }[enc.tod] ?? '';
  c.memories = [];
  addMemory(c, `Met ${trainer || 'their trainer'} on a walk through ${envPhrase(enc.env)} ${when}.`.replace(/\s+\./, '.'), enc.at);
  return c;
}

// ---------- thoughts ----------
const T = {
  any: [
    '{n} is enjoying the smells of the area.',
    '{n} is listening to your footsteps.',
    '{n} shifted around and got comfortable.',
    '{n} seems curious about where you are headed.',
    '{n} is humming quietly inside the capsule.',
    '{n} let out a contented little sound.',
    '{n} is watching the world go by.',
    '{n} seems to like this pace.',
  ],
  urban: ['{n} perked up at the noise of the street.', '{n} is fascinated by all the people.', '{n} wonders what all the lights are.', '{n} caught a whiff of something tasty from a café.'],
  forest: ['{n} likes the sound of the leaves.', '{n} sniffed the fresh air from the trees.', '{n} heard a bird and looked around.', '{n} is calm under all this shade.'],
  water: ['{n} perked up at the sound of the water.', '{n} can smell the salt in the air.', '{n} is watching the waves.', '{n} seems to want a swim.'],
  plains: ['{n} is enjoying the breeze through the grass.', '{n} likes how open everything feels.', '{n} spotted something far off in the field.'],
  mountain: ['{n} is impressed by the view.', '{n} noticed the air getting thinner.', '{n} felt the path climb and braced itself.'],
  desert: ['{n} squinted at the bright sand.', '{n} feels the warmth through the capsule.', '{n} is waiting for a bit of shade.'],
  snow: ['{n} is watching the snow fall.', '{n} heard the crunch of snow under your feet.', '{n} wants to know what snow tastes like.'],
  cave: ['{n} is peering into the dark.', '{n} heard an echo and listened closely.', '{n} feels safe being close to you down here.'],
  night: ['{n} is gazing at the night sky.', '{n} is a little sleepy, but happy to be out.', '{n} likes how quiet it is at night.'],
  dawn: ['{n} is watching the sun come up.', '{n} stretched as the morning started.'],
  dusk: ['{n} is watching the sky turn orange.', '{n} noticed the streetlights coming on.'],
  happy: ['{n} is in a great mood!', '{n} is bouncing around inside the capsule.'],
  sleepy: ['{n} is curled up and dozing.', '{n} yawned. It might be time for a rest soon.'],
  hungry: ['{n} is thinking about food.', '{n}’s tummy rumbled. It would love a meal at the PC.'],
  bored: ['{n} wants to see something new.', '{n} would love to go somewhere different.'],
  long: ['{n} is proud of how far you have walked.', '{n} seems a bit tired, but still happy.'],
  fire: ['{n}’s capsule feels warm in your hand.'],
  water_t: ['{n} is splashing around in its own little way.'],
  electric: ['{n} is giving off a faint static buzz.'],
  ice: ['{n}’s capsule is cool to the touch.'],
  ghost: ['{n} flickered and seemed to disappear for a moment.'],
  grass: ['{n} is soaking up the sunlight.'],
};
const TYPE_THOUGHTS = { fire: 'fire', ember: 'fire', water: 'water_t', tide: 'water_t', electric: 'electric', volt: 'electric', ice: 'ice', frost: 'ice', ghost: 'ghost', shade: 'ghost', grass: 'grass', sprout: 'grass' };

/** Something the creature seems to be thinking right now. ctx: { env, t, walkMinutes, seed } */
export function thoughtFor(idx, c, ctx = {}) {
  const rng = createRng(ctx.seed ?? Date.now());
  const sp = speciesOf(idx, c);
  const pools = [T.any, T.any];
  for (const e of normalizeEnv(ctx.env)) pools.push(T[e], T[e]);
  const tod = timeOfDay(ctx.t);
  if (T[tod]) pools.push(T[tod]);
  const m = mood(c).id;
  if (T[m]) pools.push(T[m], T[m]);
  if ((ctx.walkMinutes ?? 0) > 45) pools.push(T.long);
  for (const k of sp ? typeKeys(idx, sp) : []) if (TYPE_THOUGHTS[k]) pools.push(T[TYPE_THOUGHTS[k]]);
  const pool = pools[Math.floor(rng() * pools.length)].filter((s) => !(tod === 'night' && /sun|sunlight/.test(s)));
  const line = pool[Math.floor(rng() * pool.length)] ?? T.any[0];
  return line.replace(/\{n\}/g, displayName(idx, c));
}

/** Places this creature has not been on a walk before: [{ key, text }]. Record them as 'memory' events. */
const FIRSTS = { urban: 'Saw the city for the first time.', forest: 'Walked through a forest for the first time.', water: 'Saw the water for the first time.', plains: 'Ran through open fields for the first time.', mountain: 'Climbed into the hills for the first time.', desert: 'Felt desert heat for the first time.', snow: 'Saw snow for the first time.', cave: 'Went underground for the first time.', night: 'Went on a walk under the night sky.' };
export function walkFirsts(c, env, t = Date.now()) {
  const seen = c.seen || {};
  const keys = [...normalizeEnv(env)];
  if (timeOfDay(t) === 'night') keys.push('night');
  return keys.filter((k) => !seen[k]).map((k) => ({ key: k, text: FIRSTS[k] }));
}
