// Life on a walk: what a creature in its ball seems to be thinking, and which wild creatures an
// empty ball can pick up. Until balls report real location data, the trainer says what kind of
// place they are walking through (up to two environments, like "urban + forest").
import { sunFor } from './sky.js';
import { createRng } from './rng.js';
import { speciesOf, displayName, addMemory, createCreature } from './creature.js';
import { mood } from './care.js';
import { topPrefs } from './memory.js';
import { baseSpeciesOf } from './forms.js';
import { habitatsOf } from './habitats.js';
const isAlternateForm = (idx, sp) => baseSpeciesOf(idx, sp) !== sp;

export const ENVIRONMENTS = [
  { id: 'urban', label: 'City', hint: 'Streets, buildings, parks between them' },
  { id: 'forest', label: 'Forest', hint: 'Trees, trails, shade' },
  { id: 'water', label: 'Beach / water', hint: 'Coast, lakes, rivers' },
  { id: 'plains', label: 'Fields', hint: 'Open grass, farmland, meadows' },
  { id: 'mountain', label: 'Mountains', hint: 'Hills, rocks, high ground' },
  { id: 'desert', label: 'Desert', hint: 'Dry, sandy, hot' },
  { id: 'snow', label: 'Snow', hint: 'Cold, icy, winter' },
  { id: 'cave', label: 'Underground', hint: 'Tunnels, caves, subways' },
];

// Type affinity per environment. Keys cover common type names and the built-in data set's types.
const TYPE_AFFINITY = {
  urban: { normal: 3, plain: 3, electric: 3, volt: 3, steel: 3, metal: 3, poison: 2, fighting: 2, brawl: 2, dark: 1.5, shade: 1.5, psychic: 1, mind: 1, flying: 1, gale: 1, fire: 0.6, ember: 0.6 },
  forest: { grass: 3, sprout: 3, bug: 3, fairy: 2, poison: 1.5, normal: 1, plain: 1, flying: 1, gale: 1, ghost: 0.8, dark: 0.8, shade: 0.8 },
  water: { water: 4, tide: 4, flying: 1.2, gale: 1.2, ice: 1, frost: 1, dragon: 0.6, electric: 0.5, volt: 0.5 },
  plains: { normal: 3, plain: 3, grass: 2, sprout: 2, flying: 2, gale: 2, bug: 1.5, electric: 1, volt: 1, ground: 1, fairy: 1 },
  mountain: { rock: 3, stone: 3, ground: 2, fighting: 2, brawl: 2, flying: 2, gale: 2, ice: 1, frost: 1, dragon: 1, steel: 1, metal: 1, fire: 0.8, ember: 0.8 },
  desert: { ground: 3, rock: 2, stone: 2, fire: 2, ember: 2, fighting: 1, brawl: 1, dragon: 1, poison: 0.8, bug: 0.6 },
  snow: { ice: 4, frost: 4, water: 1, tide: 1, steel: 1, metal: 1, normal: 0.5 },
  cave: { rock: 2, stone: 2, ground: 2, dark: 2, shade: 2, ghost: 2, poison: 1, steel: 1, metal: 1, dragon: 1, psychic: 0.8, mind: 0.8 },
};
const HABITAT_AFFINITY = {
  urban: ['outskirts'], forest: ['forest', 'marsh', 'spooky'], water: ['shoreline', 'seafloor', 'marsh'], plains: ['meadow'],
  mountain: ['volcano', 'crystal', 'cavern', 'skyline'], desert: ['desert', 'volcano'], snow: ['tundra'], cave: ['cavern', 'crystal', 'starfield'],
};

// ---------- real places nearby (from the phone's location: OpenStreetMap features within a few hundred metres) ----------
// Where types turn up, after the long-running player lore for the location-based game (water by water, ghosts and
// fairies by graveyards and churches, electric by power plants and industry, psychic by hospitals, fighting by gyms
// and stadiums, dragons by landmarks, steel by stations, rock by quarries and car parks, fire in warm, lived-in places).
export const PLACES = {
  beach: { label: 'the beach', env: 'water', types: { water: 3, tide: 3, ground: 1, flying: 1.5, gale: 1.5, psychic: 1, mind: 1 } },
  river: { label: 'the river', env: 'water', types: { water: 3, tide: 3, bug: 1, poison: 0.8, flying: 1, gale: 1 } },
  lake: { label: 'the lake', env: 'water', types: { water: 3, tide: 3, dragon: 0.8, flying: 1, gale: 1, ice: 0.6, frost: 0.6 } },
  harbour: { label: 'the harbour', env: 'water', types: { water: 3, tide: 3, steel: 1.5, metal: 1.5, electric: 1, volt: 1 } },
  wetland: { label: 'the marsh', env: 'water', types: { poison: 3, bug: 2, water: 2, tide: 2, grass: 1, sprout: 1, ghost: 1 } },
  park: { label: 'the park', env: 'plains', types: { grass: 2, sprout: 2, bug: 2, flying: 2, gale: 2, normal: 1.5, plain: 1.5, fairy: 1 } },
  garden: { label: 'the gardens', env: 'plains', types: { grass: 2.5, sprout: 2.5, fairy: 2.5, bug: 2 } },
  playground: { label: 'the playground', env: 'urban', types: { normal: 2, plain: 2, fairy: 1.5, bug: 1, flying: 1, gale: 1 } },
  forest: { label: 'the woods', env: 'forest', types: { grass: 3, sprout: 3, bug: 3, ghost: 1, poison: 1, fairy: 1 } },
  farm: { label: 'the farms', env: 'plains', types: { normal: 2, plain: 2, grass: 2, sprout: 2, flying: 2, gale: 2, ground: 1.5 } },
  cemetery: { label: 'the old graveyard', env: 'urban', types: { ghost: 4, shade: 3, dark: 2.5, fairy: 2.5 } },
  temple: { label: 'the shrine', env: 'urban', types: { fairy: 3, psychic: 2, mind: 2, ghost: 1.5, shade: 1 } },
  hospital: { label: 'the hospital', env: 'urban', types: { psychic: 3.5, mind: 3.5, normal: 1, plain: 1, fairy: 1 } },
  sports: { label: 'the sports ground', env: 'urban', types: { fighting: 3.5, brawl: 3.5, normal: 1.5, plain: 1.5 } },
  industrial: { label: 'the factories', env: 'urban', types: { electric: 2.5, volt: 2.5, steel: 2.5, metal: 2.5, poison: 2, fire: 1.5, ember: 1.5 } },
  power: { label: 'the power station', env: 'urban', types: { electric: 4, volt: 4, steel: 1.5, metal: 1.5 } },
  station: { label: 'the station', env: 'urban', types: { steel: 3, metal: 3, normal: 1.5, plain: 1.5, electric: 1, volt: 1 } },
  parking: { label: 'the car park', env: 'urban', types: { rock: 2, stone: 2, ground: 1.5, ghost: 1, normal: 1, plain: 1 } },
  quarry: { label: 'the quarry', env: 'mountain', types: { rock: 3.5, stone: 3.5, ground: 3, fighting: 1, brawl: 1, steel: 1, metal: 1 } },
  landmark: { label: 'the old landmark', env: 'urban', types: { dragon: 3, fairy: 2, dark: 1.5, shade: 1.5, psychic: 1, mind: 1 } },
  golf: { label: 'the golf course', env: 'plains', types: { dragon: 2, grass: 2, sprout: 2, normal: 1, plain: 1 } },
  residential: { label: 'the houses', env: 'urban', types: { normal: 2, plain: 2, fire: 2, ember: 2, electric: 1.5, volt: 1.5 } },
  shops: { label: 'the shops', env: 'urban', types: { normal: 2.5, plain: 2.5, rock: 1, stone: 1, psychic: 0.8, mind: 0.8 } },
  rocky: { label: 'the rocks', env: 'mountain', types: { rock: 3, stone: 3, ground: 2, fighting: 1.5, brawl: 1.5 } },
  peak: { label: 'the summit', env: 'mountain', types: { flying: 3, gale: 3, rock: 2, stone: 2, ice: 1.5, frost: 1.5, dragon: 1.5 } },
  'hot-spring': { label: 'the hot springs', env: 'mountain', types: { fire: 3.5, ember: 3.5, water: 2, tide: 2, psychic: 1, mind: 1 } },
  cave: { label: 'the cave', env: 'cave', types: { rock: 2, stone: 2, dark: 2, shade: 2, ghost: 2, poison: 1.5, ground: 1.5 } },
  airport: { label: 'the airport', env: 'urban', types: { flying: 3, gale: 3, steel: 2, metal: 2, ground: 1.5 } },
  cinema: { label: 'the cinema', env: 'urban', types: { dark: 3, shade: 3, ghost: 1.5, psychic: 1, mind: 1 } },
  'fire-station': { label: 'the fire station', env: 'urban', types: { fire: 3.5, ember: 3.5, water: 1, tide: 1 } },
  bakery: { label: 'the bakery', env: 'urban', types: { fire: 2.5, ember: 2.5, normal: 1.5, plain: 1.5, fairy: 1 } },
  'city-centre': { label: 'the city centre', env: 'urban', types: { normal: 2, plain: 2, steel: 1.5, metal: 1.5, electric: 1.5, volt: 1.5, psychic: 1, mind: 1, fighting: 1, brawl: 1 } },
  countryside: { label: 'the countryside', env: 'plains', types: { normal: 1.5, plain: 1.5, grass: 1.5, sprout: 1.5, bug: 1.5, ground: 1, flying: 1, gale: 1 } },
};
/** Weather that brings certain types out (rain: water and electric, sun: fire and grass…). */
export const WEATHER_TYPES = {
  sun: ['fire', 'ember', 'grass', 'sprout', 'ground'], clear: ['dark', 'shade', 'fairy', 'psychic', 'mind'], rain: ['water', 'tide', 'electric', 'volt', 'bug'], storm: ['electric', 'volt', 'water', 'tide', 'dragon'],
  clouds: ['fairy', 'fighting', 'brawl', 'poison'], fog: ['dark', 'shade', 'ghost'], snow: ['ice', 'frost', 'steel', 'metal'],
  wind: ['dragon', 'flying', 'gale', 'psychic', 'mind'],
};
/** The kinds of place (environments) a set of nearby places and the temperature add up to. */
export function contextEnv(ctx = {}) {
  const env = [];
  const add = (e) => { if (e && !env.includes(e)) env.push(e); };
  for (const p of ctx.places ?? []) add(PLACES[p]?.env);
  if (Number.isFinite(ctx.temp) && ctx.temp <= 0 || ctx.weather === 'snow') env.unshift('snow');
  if (Number.isFinite(ctx.temp) && ctx.temp >= 32 && (ctx.humidity ?? 50) < 30) env.unshift('desert');
  for (const e of ctx.env ?? []) add(e);
  return normalizeEnv([...new Set(env)]);
}
/** What a place's surroundings mean in words, for memories and the walk screen: "the beach and the park". */
export function placesPhrase(places = []) { return places.slice(0, 2).map((p) => PLACES[p]?.label ?? p).join(' and '); }

const NIGHT_TYPES = new Set(['dark', 'shade', 'ghost', 'psychic', 'mind', 'fairy']);
const DAY_TYPES = new Set(['grass', 'sprout', 'fire', 'ember', 'bug', 'normal', 'plain', 'flying', 'gale']);

/**
 * Dawn, day, dusk or night. sun: { sunrise, sunset } (ms, from the weather service for where you are) and/or
 * { isDay } — real sun times win over the clock, so a winter evening at 5pm is already dusk or night.
 */
export function timeOfDay(t = Date.now(), sun = null) {
  // nothing passed: the real sky where you are, when it's known (Settings → Where you are, or the phone)
  if (!sun || (!sun.sunrise && sun.isDay == null)) sun = sunFor(t) ?? sun;
  if (sun?.sunrise && sun?.sunset) {
    const day0 = new Date(t); day0.setHours(0, 0, 0, 0);
    const clock = (ms) => { const d = new Date(ms); return day0.getTime() + ((d.getHours() * 60 + d.getMinutes()) * 60000); };
    const rise = clock(sun.sunrise), set = clock(sun.sunset), H = 3600000;
    if (t < rise - 0.6 * H) return 'night';
    if (t < rise + H) return 'dawn';
    if (t < set - H) return 'day';
    if (t < set + 0.6 * H) return 'dusk';
    return 'night';
  }
  const hr = new Date(t).getHours();
  if (sun?.isDay === false) return hr >= 4 && hr < 9 ? 'dawn' : hr >= 16 && hr < 21 ? 'dusk' : 'night';
  if (sun?.isDay === true && (hr < 5 || hr >= 20)) return hr < 12 ? 'dawn' : 'dusk';
  if (hr >= 5 && hr < 8) return 'dawn';
  if (hr >= 8 && hr < 17) return 'day';
  if (hr >= 17 && hr < 20) return 'dusk';
  return 'night';
}

export function normalizeEnv(list) {
  const ok = new Set(ENVIRONMENTS.map((e) => e.id));
  const out = [...new Set((Array.isArray(list) ? list : []).filter((x) => ok.has(x)))].slice(0, 2);
  return out.length ? out : ['plains'];
}

const typeKeys = (idx, sp) => (sp.types ?? []).flatMap((t) => [String(t).toLowerCase(), String(idx.types.get(t)?.name ?? '').toLowerCase()]);
const bst = (sp) => Object.values(sp.baseStats ?? {}).reduce((a, b) => a + (+b || 0), 0);

/** Species that evolve from something else, and how many steps along the line they are. */
function evoDepth(idx) {
  if (idx._evoDepth) return idx._evoDepth;
  const parent = new Map();
  for (const s of idx.ds.species) for (const e of s.evolutions ?? []) if (!parent.has(e.to)) parent.set(e.to, s.id);
  const depth = new Map();
  for (const s of idx.ds.species) {
    let d = 0, cur = s.id;
    const seen = new Set();
    while (parent.has(cur) && !seen.has(cur)) { seen.add(cur); cur = parent.get(cur); d++; }
    depth.set(s.id, d);
  }
  idx._evoDepth = depth;
  return depth;
}

/**
 * Weighted table of who can turn up. ctx: { env: ['urban','forest'], t, walkMinutes, steps }
 * Longer walks open up rarer (evolved, stronger) species; time of day shifts the types.
 */
export function encounterTable(idx, ctx = {}) {
  const env = ctx.places?.length || Number.isFinite(ctx.temp) ? contextEnv(ctx) : normalizeEnv(ctx.env);
  const tod = ctx.tod ?? timeOfDay(ctx.t, ctx.sun);
  const mins = Math.max(0, ctx.walkMinutes ?? 0);
  const depth = evoDepth(idx);
  const rows = [];
  for (const sp of idx.ds.species) {
    if (sp.noWild || sp.unobtainable) continue;
    // forms aren't met in the wild (Deoxys turns up as itself, Castform before the weather changes it); regional variants are
    if (sp.battleOnly || isAlternateForm(idx, sp)) continue;
    const keys = typeKeys(idx, sp);
    let w = 0.25; // anyone can wander anywhere, rarely
    for (const e of env) {
      const aff = TYPE_AFFINITY[e] ?? {};
      w += Math.max(0, ...keys.map((k) => aff[k] ?? 0));
      if (habitatsOf(idx, sp).some((hb) => HABITAT_AFFINITY[e]?.includes(hb) && hb !== 'meadow')) w += 2;
    }
    // real places close by count more than the general kind of area
    for (const p of (ctx.places ?? []).slice(0, 4)) w += 0.8 * Math.max(0, ...keys.map((k) => PLACES[p]?.types?.[k] ?? 0));
    if (ctx.weather && WEATHER_TYPES[ctx.weather]?.some((t) => keys.includes(t))) w *= 1.6;
    // incense lit on the phone: its type turns up much more
    if (ctx.incense && keys.includes(String(ctx.incense).toLowerCase())) w = (w + 1) * 4;
    if (tod === 'night') w *= keys.some((k) => NIGHT_TYPES.has(k)) ? 2.4 : keys.some((k) => DAY_TYPES.has(k)) ? 0.55 : 1;
    else if (tod === 'day') w *= keys.some((k) => DAY_TYPES.has(k)) ? 1.3 : keys.some((k) => NIGHT_TYPES.has(k)) ? 0.6 : 1;
    else w *= keys.some((k) => NIGHT_TYPES.has(k)) ? 1.4 : 1.1; // dawn and dusk mix both
    const d = depth.get(sp.id) ?? 0;
    // evolved forms are uncommon, and become less so the longer you walk
    if (d > 0) w *= Math.min(0.6, (0.08 + mins / 300) / d);
    const total = bst(sp);
    if (total >= 580) w *= mins >= 60 ? 0.02 : 0; // the very strongest only show on long walks, and barely
    else if (total >= 500) w *= Math.min(1, 0.15 + mins / 120);
    if (w > 0) rows.push({ id: sp.id, w });
  }
  const sum = rows.reduce((a, r) => a + r.w, 0) || 1;
  return rows.map((r) => ({ ...r, p: r.w / sum })).sort((a, b) => b.w - a.w);
}

/** Chance (0..1) that the next check on this walk turns something up. */
export function encounterChance(ctx = {}) {
  const mins = Math.max(0, ctx.walkMinutes ?? 0);
  return Math.min(0.6, 0.22 + mins * 0.006);
}

/** Roll a wild encounter: { speciesId, level, catchRate, env, tod, at, seed } or null. */
export function rollEncounter(idx, ctx = {}) {
  const rng = createRng(ctx.seed ?? Date.now());
  if (rng() > encounterChance(ctx)) return null;
  const table = encounterTable(idx, ctx);
  if (!table.length) return null;
  let x = rng() * table.reduce((a, r) => a + r.w, 0);
  let pick = table[0];
  for (const r of table) { x -= r.w; if (x <= 0) { pick = r; break; } }
  const sp = idx.species.get(pick.id);
  const mins = Math.max(0, ctx.walkMinutes ?? 0);
  const d = evoDepth(idx).get(sp.id) ?? 0;
  const base = 3 + Math.min(30, mins / 3) + d * 12;
  const level = Math.max(2, Math.min(idx.ds.rules.maxLevel ?? 100, Math.round(base + (rng() * 6 - 3))));
  // stronger species are harder to hold on to
  // a catch rate from the data (0-255, as the games store it) wins over the estimate from stats
  const catchRate = sp.catchRate
    ? Math.max(0.05, Math.min(0.95, (sp.catchRate / 255) * 1.15 - level / 320))
    : Math.max(0.08, Math.min(0.9, 1.05 - bst(sp) / 720 - level / 160));
  return { speciesId: sp.id, level, catchRate, env: ctx.places?.length || Number.isFinite(ctx.temp) ? contextEnv(ctx) : normalizeEnv(ctx.env), places: (ctx.places ?? []).slice(0, 2), weather: ctx.weather ?? null, tod: ctx.tod ?? timeOfDay(ctx.t, ctx.sun), at: ctx.t ?? Date.now(), seed: Math.floor(rng() * 2 ** 31) };
}

/** Throw quality 0..1 from the timing ring → caught? */
export function tryCatch(enc, quality, rngSeed = Date.now()) {
  const rng = createRng(rngSeed);
  const q = Math.max(0, Math.min(1, quality));
  const p = Math.min(0.97, enc.catchRate * (0.45 + q * 1.1) + (q > 0.92 ? 0.15 : 0));
  return { caught: rng() < p, p };
}

const ENV_WORDS = { urban: 'the city', forest: 'the woods', water: 'the water', plains: 'open fields', mountain: 'the hills', desert: 'the desert', snow: 'the snow', cave: 'underground' };
export const envPhrase = (env) => normalizeEnv(env).map((e) => ENV_WORDS[e]).join(' and ');

/** The new creature for a successful catch. */
export function caughtCreature(idx, enc, { trainer = '', location } = {}) {
  const where = enc.places?.length ? `near ${placesPhrase(enc.places)}` : `in ${envPhrase(enc.env)}`;
  const c = createCreature(idx, enc.speciesId, { level: enc.level, seed: enc.seed, trainer, location, metHow: `Caught on a walk ${where}` });
  const when = { dawn: 'at dawn', day: 'during the day', dusk: 'at dusk', night: 'at night' }[enc.tod] ?? '';
  c.memories = [];
  // where you met is one of the things they never forget
  addMemory(c, `Met ${trainer || 'their trainer'} on a walk ${where} ${when}.`.replace(/\s+\./, '.'), enc.at, { core: true, keys: (enc.places ?? []).map((p) => `place:${p}`) });
  if (enc.places?.length) c.prefs = { ...(c.prefs || {}), [`place:${enc.places[0]}`]: 3 };
  return c;
}

// ---------- thoughts ----------
const T = {
  // everyday feelings any creature might have (vague on purpose: relatable, never too specific)
  any: [
    '{n} is enjoying the smells of the area.', '{n} is listening to your footsteps.', '{n} shifted around and got comfortable.',
    '{n} seems curious about where you are headed.', '{n} is humming quietly inside the capsule.', '{n} let out a contented little sound.',
    '{n} is watching the world go by.', '{n} seems to like this pace.', '{n} wants to relax for a while.', '{n} is daydreaming.',
    '{n} feels safe with you.', '{n} is thinking about a nap.', '{n} stretched out as far as the capsule allows.',
    '{n} is in a playful mood.', '{n} wants to explore a little more.', '{n} is quietly content.', '{n} seems a bit restless.',
    '{n} wiggled to get your attention.', '{n} is being very patient.', '{n} is counting something only it can see.',
    '{n} is wondering what is for dinner.', '{n} feels like stretching its legs.', '{n} is trying to catch a sound in the distance.',
    '{n} has a happy little spring in its step today.', '{n} wants a scratch behind the ears.', '{n} is lost in thought.',
    '{n} feels cosy.', '{n} looks like it is smiling.', '{n} gave a small, sleepy sigh.', '{n} is keeping an eye out for you.',
    '{n} wants to show you something.', '{n} perked up for no particular reason.', '{n} is feeling brave today.',
    '{n} is feeling a bit shy right now.', '{n} wants to stay close.', '{n} is enjoying the quiet.', '{n} is enjoying the company.',
    '{n} feels like playing a game.', '{n} wants to try something new.', '{n} is remembering something nice.',
    '{n} wants to be somewhere warm.', '{n} feels a little silly.', '{n} is feeling peaceful.', '{n} wants to go a bit faster.',
    '{n} is fine taking it slow.', '{n} tapped on the inside of the capsule, just to say hi.', '{n} looks proud of itself.',
    '{n} is listening carefully to everything.', '{n} wants a snack.', '{n} feels refreshed.', '{n} is soaking up the moment.',
    '{n} made a funny face.', '{n} seems to be waiting for something.', '{n} is happy just being here.',
  ],
  urban: ['{n} perked up at the noise of the street.', '{n} is fascinated by all the people.', '{n} wonders what all the lights are.', '{n} caught a whiff of something tasty from a café.'],
  forest: ['{n} likes the sound of the leaves.', '{n} sniffed the fresh air from the trees.', '{n} heard a bird and looked around.', '{n} is calm under all this shade.'],
  water: ['{n} perked up at the sound of the water.', '{n} can smell the salt in the air.', '{n} is watching the waves.', '{n} seems to want a swim.'],
  plains: ['{n} is enjoying the breeze through the grass.', '{n} likes how open everything feels.', '{n} spotted something far off in the field.'],
  mountain: ['{n} is impressed by the view.', '{n} noticed the air getting thinner.', '{n} felt the path climb and braced itself.'],
  desert: ['{n} squinted at the bright sand.', '{n} feels the warmth through the capsule.', '{n} is waiting for a bit of shade.'],
  snow: ['{n} is watching the snow fall.', '{n} heard the crunch of snow under your feet.', '{n} wants to know what snow tastes like.'],
  cave: ['{n} is peering into the dark.', '{n} heard an echo and listened closely.', '{n} feels safe being close to you down here.'],
  night: ['{n} is gazing at the night sky.', '{n} is a little sleepy, but happy to be out.', '{n} likes how quiet it is at night.'],
  dawn: ['{n} is watching the sun come up.', '{n} stretched as the morning started.'],
  dusk: ['{n} is watching the sky turn orange.', '{n} noticed the streetlights coming on.'],
  happy: ['{n} is in a great mood!', '{n} is bouncing around inside the capsule.', '{n} could not be happier.'],
  car: ['{n} is watching the world rush past.', '{n} loves the hum of the road.', '{n} is wondering where you are going so fast.', '{n} can feel every turn the car takes.', '{n} pressed close to the window.'],
  bike: ['{n} is holding on tight as you pedal.', '{n} loves the wind rushing by!', '{n} bounces along with every bump.', '{n} wants you to ring the bell.'],
  skate: ['{n} hears the wheels clattering on the pavement.', '{n} sways with you around the corners.', '{n} thinks rolling is much easier than walking.'],
  train: ['{n} is listening to the rhythm of the rails.', '{n} is watching the stations go by.', '{n} is lulled by the rocking carriage.'],
  plane: ['{n} felt its ears pop.', '{n} is amazed at how high up you are.', '{n} is peeking at the clouds below.', '{n} doesn’t quite trust being this far off the ground.'],
  boat: ['{n} is rocking with the waves.', '{n} can smell the water all around.', '{n} is watching the wake behind the boat.'],
  home: ['{n} knows this place: it’s home!', '{n} relaxed the moment you got home.', '{n} is glad to be back home.', '{n} is sniffing around for familiar smells.'],
  leaving: ['{n} is looking back the way home is.', '{n} wonders how far from home you’re going.', '{n} feels a little adventurous, heading out from home.'],
  far: ['{n} is a long way from home and knows it.', '{n} is taking in somewhere completely new.', '{n} is thinking about home, far away.', '{n} wants to remember this faraway place.'],
  returning: ['{n} can tell you’re heading home.', '{n} perked up: this is the way home!', '{n} is looking forward to being home.'],
  sleepy: ['{n} is curled up and dozing.', '{n} yawned. It might be time for a rest soon.'],
  hungry: ['{n} is thinking about food.', '{n}’s tummy rumbled. It would love a meal at the PC.'],
  bored: ['{n} wants to see something new.', '{n} would love to go somewhere different.'],
  long: ['{n} is proud of how far you have walked.', '{n} seems a bit tired, but still happy.'],
  fire: ['{n}’s capsule feels warm in your hand.'],
  water_t: ['{n} is splashing around in its own little way.'],
  electric: ['{n} is giving off a faint static buzz.'],
  ice: ['{n}’s capsule is cool to the touch.'],
  ghost: ['{n} flickered and seemed to disappear for a moment.'],
  grass: ['{n} is soaking up the sunlight.'],
};
// weather (kept apart from places: "snow" is both)
const W = {
  clear: ['{n} is looking up at the clear night sky.', '{n} is counting the stars.', '{n} likes the cool, clear night.', '{n} is watching the moon.'],
  sun: ['{n} is enjoying this weather.', '{n} is basking in the sunshine.', '{n} squints happily at the bright sky.'],
  clouds: ['{n} likes the soft light today.', '{n} is watching the clouds drift.'],
  rain: ['{n} is listening to the rain.', '{n} is staying snug and dry.', '{n} wants to splash in a puddle.'],
  storm: ['{n} flinched at the thunder.', '{n} is watching the storm, wide-eyed.'],
  snow: ['{n} is fascinated by the snowflakes.', '{n} is curled up against the cold.'],
  fog: ['{n} is peering into the fog.', '{n} likes how mysterious everything looks.'],
  wind: ['{n} is enjoying the breeze.', '{n} is holding on against the wind.'],
  hot: ['{n} wants to find some shade.', '{n} is feeling the heat.'],
  cold: ['{n} is shivering a little.', '{n} wants to warm up somewhere.'],
};
const TYPE_THOUGHTS = { fire: 'fire', ember: 'fire', water: 'water_t', tide: 'water_t', electric: 'electric', volt: 'electric', ice: 'ice', frost: 'ice', ghost: 'ghost', shade: 'ghost', grass: 'grass', sprout: 'grass' };

const PLACE_LINES = ['{n} is curious about {p}.', '{n} is taking in {p}.', '{n} noticed {p} nearby.', '{n} wants a closer look at {p}.', '{n} is sniffing the air near {p}.'];
const PLACE_FOND = ['{n} loves {p}! It’s one of its favourite places.', '{n} lit up: {p} again!', '{n} remembers {p} fondly.'];
const LIKE_LINES = ['{n} loves {x}.', '{n} is always happiest with {x}.', '{n} perks up at the thought of {x}.'];
const FRIEND_LINES = ['{n} misses {f}.', '{n} wants to tell {f} all about this.', '{n} is thinking about {f}.'];

/**
 * Something the creature seems to be thinking right now.
 * ctx: { env, t, walkMinutes, seed, weather, temp, vehicle, friendName }
 */
export function thoughtFor(idx, c, ctx = {}) {
  const rng = createRng(ctx.seed ?? Date.now());
  const sp = speciesOf(idx, c);
  // now and then: something they love, or a friend back home
  const likes = topPrefs(c, idx, 3);
  if (likes.length && rng() < 0.12) return LIKE_LINES[Math.floor(rng() * LIKE_LINES.length)].replace('{n}', displayName(idx, c)).replace('{x}', likes[Math.floor(rng() * likes.length)].label);
  if (ctx.friendName && rng() < 0.1) return FRIEND_LINES[Math.floor(rng() * FRIEND_LINES.length)].replace('{n}', displayName(idx, c)).replace('{f}', ctx.friendName);
  const pools = [T.any, T.any, T.any];
  const wx = ctx.weather === 'sun' && (ctx.sun?.isDay === false || (ctx.tod ?? timeOfDay(ctx.t, ctx.sun)) === 'night') ? 'clear' : ctx.weather;
  if (wx && W[wx]) pools.push(W[wx], W[wx]);
  if (Number.isFinite(ctx.temp)) { if (ctx.temp >= 28) pools.push(W.hot); else if (ctx.temp <= 3) pools.push(W.cold); }
  const tod = ctx.tod ?? timeOfDay(ctx.t, ctx.sun);
  const ride = transportOf(ctx);
  if (ride && T[ride]) pools.push(T[ride], T[ride], T[ride]);
  // home: being there, leaving it, being far from it, coming back
  if (ctx.home && T[ctx.home]) pools.push(T[ctx.home], T[ctx.home]);
  for (const e of ctx.places?.length || Number.isFinite(ctx.temp) ? contextEnv(ctx) : normalizeEnv(ctx.env)) pools.push(T[e], T[e]);
  // somewhere real and close by: the park, the river, the old graveyard…
  const near = (ctx.places ?? []).filter((p) => PLACES[p]);
  if (near.length) {
    const p = near[Math.floor(rng() * near.length)];
    const fond = (c.prefs?.[`place:${p}`] ?? 0) >= 4;
    pools.push((fond ? PLACE_FOND : PLACE_LINES).map((l) => l.replace('{p}', PLACES[p].label)), PLACE_LINES.map((l) => l.replace('{p}', PLACES[p].label)));
  }
  if (T[tod]) pools.push(T[tod]);
  const m = mood(c).id;
  if (T[m]) pools.push(T[m], T[m]);
  if ((ctx.walkMinutes ?? 0) > 45) pools.push(T.long);
  for (const k of sp ? typeKeys(idx, sp) : []) if (TYPE_THOUGHTS[k]) pools.push(T[TYPE_THOUGHTS[k]]);
  // nothing about sunshine when the sun is down
  const dark = tod === 'night' || ctx.sun?.isDay === false;
  const pool = pools[Math.floor(rng() * pools.length)].filter((s) => !(dark && /sun|bright sky|basking|sand/i.test(s)));
  const line = pool[Math.floor(rng() * pool.length)] ?? T.any[0];
  return line.replace(/\{n\}/g, displayName(idx, c));
}

/** Places this creature has not been on a walk before: [{ key, text }]. Record them as 'memory' events. */
const FIRSTS = { urban: 'Saw the city for the first time.', forest: 'Walked through a forest for the first time.', water: 'Saw the water for the first time.', plains: 'Ran through open fields for the first time.', mountain: 'Climbed into the hills for the first time.', desert: 'Felt desert heat for the first time.', snow: 'Saw snow for the first time.', cave: 'Went underground for the first time.', night: 'Went on a walk under the night sky.' };
export function walkFirsts(c, env, t = Date.now(), places = []) {
  const seen = c.seen || {};
  const keys = [...normalizeEnv(env)];
  if (timeOfDay(t) === 'night') keys.push('night');
  const out = keys.filter((k) => !seen[k]).map((k) => ({ key: k, text: FIRSTS[k] }));
  // a real place nearby for the first time: the river, the old graveyard…
  for (const p of places.slice(0, 2)) if (PLACES[p] && !seen[`place:${p}`]) out.push({ key: `place:${p}`, text: `Went past ${PLACES[p].label} for the first time.` });
  return out;
}

/**
 * How you are getting about, from speed (km/h) and what is around: 'bike' | 'skate' | 'car' | 'train' | 'plane' | 'boat' | null.
 * ctx: { speedKmh, places, near, vehicle }. Rough on purpose: speed bands, plus water (boat) and rails (train).
 */
export function transportOf(ctx = {}) {
  const v = ctx.speedKmh;
  if (!Number.isFinite(v)) return ctx.vehicle ? 'car' : null;
  const places = ctx.places ?? [];
  const onWater = places.some((p) => ['lake', 'harbour', 'beach', 'river'].includes(p)) && !places.some((p) => ['residential', 'shops', 'city-centre'].includes(p));
  if (v >= 250) return 'plane';
  if (v >= 12 && onWater) return 'boat';
  if (v >= 60 && places.includes('station')) return 'train';
  if (v >= 160) return 'train';
  if (v >= 30) return 'car';
  if (v >= 16) return 'bike';
  if (v >= 9) return 'skate';
  return null;
}

/** Where home is relative to here: 'home' | 'leaving' | 'far' | 'returning' | null. home/here: { lat, lon } (rounded). */
export function homeState(home, here, prevKm = null) {
  if (!home || !here || !Number.isFinite(here.lat) || !Number.isFinite(home.lat)) return null;
  const toR = (d) => (d * Math.PI) / 180;
  const dLat = toR(here.lat - home.lat), dLon = toR(here.lon - home.lon);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toR(home.lat)) * Math.cos(toR(here.lat)) * Math.sin(dLon / 2) ** 2;
  const km = 2 * 6371 * Math.asin(Math.sqrt(a));
  if (km < 0.3) return { state: 'home', km };
  if (km > 40) return { state: 'far', km };
  if (prevKm != null && km < prevKm - 0.2) return { state: 'returning', km };
  if (prevKm != null && km > prevKm + 0.2 && km < 3) return { state: 'leaving', km };
  return { state: null, km };
}
