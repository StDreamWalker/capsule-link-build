// Formula language used by the Data Lab.
//
// A formula is a tiny program: statements separated by newlines or ';'.
//   base = baseExp * foeLevel / 7
//   floor(base * (linked ? 1.5 : 1) / max(1, participants))
// The value of the last statement is the result. Comments start with // or #.
// Supports + - * / % ^ (power), comparisons, && || !, ternary ?:, [array] literals,
// indexing a[i], member access a.b, and the helper functions listed in FUNCTIONS.
// No access to JavaScript globals, so pasted formulas cannot run arbitrary code.

export class FormulaError extends Error {
  constructor(message, pos, src) {
    const where = pos != null && src != null ? lineCol(src, pos) : null;
    super(where ? `${message} (line ${where.line}, col ${where.col})` : message);
    this.pos = pos;
    this.line = where?.line;
    this.col = where?.col;
  }
}

function lineCol(src, pos) {
  let line = 1, col = 1;
  for (let i = 0; i < pos && i < src.length; i++) {
    if (src[i] === '\n') { line++; col = 1; } else col++;
  }
  return { line, col };
}

const OPS = ['**', '==', '!=', '<=', '>=', '&&', '||', '+', '-', '*', '/', '%', '^', '<', '>', '!', '?', ':', '(', ')', '[', ']', ',', '.', '=', ';'];

function tokenize(src) {
  const toks = [];
  let i = 0, depth = 0;
  while (i < src.length) {
    const ch = src[i];
    if (ch === '\n') {
      if (depth === 0) toks.push({ t: 'nl', pos: i });
      i++; continue;
    }
    if (/\s/.test(ch)) { i++; continue; }
    if (ch === '#' || (ch === '/' && src[i + 1] === '/')) {
      while (i < src.length && src[i] !== '\n') i++;
      continue;
    }
    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(src[i + 1]))) {
      const m = /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(src.slice(i));
      toks.push({ t: 'num', v: parseFloat(m[0]), pos: i });
      i += m[0].length; continue;
    }
    if (/[A-Za-z_$]/.test(ch)) {
      const m = /^[A-Za-z_$][A-Za-z0-9_$]*/.exec(src.slice(i));
      toks.push({ t: 'id', v: m[0], pos: i });
      i += m[0].length; continue;
    }
    if (ch === '"' || ch === "'") {
      let j = i + 1, s = '';
      while (j < src.length && src[j] !== ch) {
        if (src[j] === '\\' && j + 1 < src.length) { s += src[j + 1]; j += 2; } else s += src[j++];
      }
      if (j >= src.length) throw new FormulaError('Unclosed text in quotes', i, src);
      toks.push({ t: 'str', v: s, pos: i });
      i = j + 1; continue;
    }
    const op = OPS.find((o) => src.startsWith(o, i));
    if (!op) throw new FormulaError(`Unexpected character "${ch}"`, i, src);
    if (op === '(' || op === '[') depth++;
    if (op === ')' || op === ']') depth = Math.max(0, depth - 1);
    toks.push({ t: 'op', v: op === '**' ? '^' : op, pos: i });
    i += op.length;
  }
  toks.push({ t: 'eof', pos: src.length });
  return toks;
}

const BINARY = {
  '||': 1, '&&': 2,
  '==': 3, '!=': 3,
  '<': 4, '<=': 4, '>': 4, '>=': 4,
  '+': 5, '-': 5,
  '*': 6, '/': 6, '%': 6,
  '^': 8,
};
const CONTINUES_LINE = new Set([...Object.keys(BINARY), '?', ':']);

function parse(src) {
  const toks = tokenize(src);
  let p = 0;
  const peek = (o = 0) => toks[p + o];
  const next = () => toks[p++];
  const isOp = (v, o = 0) => peek(o).t === 'op' && peek(o).v === v;
  const expectOp = (v) => {
    const tk = next();
    if (tk.t !== 'op' || tk.v !== v) throw new FormulaError(`Expected "${v}"`, tk.pos, src);
    return tk;
  };
  const skipNl = () => { while (peek().t === 'nl') p++; };

  function parseExpr(minPrec = 0) {
    let left = parseTernary();
    return left;
  }

  function parseTernary() {
    const cond = parseBinary(0);
    // allow a "?" on the next line
    if (peek().t === 'nl' && peek(1).t === 'op' && peek(1).v === '?') skipNl();
    if (isOp('?')) {
      const q = next();
      skipNl();
      const a = parseTernary();
      skipNl();
      expectOp(':');
      skipNl();
      const b = parseTernary();
      return { k: 'cond', c: cond, a, b, pos: q.pos };
    }
    return cond;
  }

  function parseBinary(minPrec) {
    let left = parseUnary();
    for (;;) {
      if (peek().t === 'nl' && peek(1).t === 'op' && BINARY[peek(1).v] && peek(1).v !== '-' ) skipNl();
      const tk = peek();
      if (tk.t !== 'op' || BINARY[tk.v] == null) break;
      const prec = BINARY[tk.v];
      if (prec < minPrec) break;
      next();
      skipNl();
      // ^ is right associative
      const right = tk.v === '^' ? parseBinaryFrom(prec) : parseBinary(prec + 1);
      left = { k: 'bin', op: tk.v, l: left, r: right, pos: tk.pos };
    }
    return left;
  }
  function parseBinaryFrom(prec) { return parseBinary(prec); }

  function parseUnary() {
    const tk = peek();
    if (tk.t === 'op' && (tk.v === '-' || tk.v === '+' || tk.v === '!')) {
      next();
      const arg = parseUnary();
      return { k: 'un', op: tk.v, a: arg, pos: tk.pos };
    }
    return parsePostfix(parsePrimary());
  }

  function parsePrimary() {
    const tk = next();
    if (tk.t === 'num') return { k: 'lit', v: tk.v };
    if (tk.t === 'str') return { k: 'lit', v: tk.v };
    if (tk.t === 'id') {
      if (tk.v === 'true') return { k: 'lit', v: true };
      if (tk.v === 'false') return { k: 'lit', v: false };
      if (tk.v === 'null') return { k: 'lit', v: null };
      return { k: 'var', name: tk.v, pos: tk.pos };
    }
    if (tk.t === 'op' && tk.v === '(') {
      skipNl();
      const e = parseExpr();
      skipNl();
      expectOp(')');
      return e;
    }
    if (tk.t === 'op' && tk.v === '[') {
      const items = [];
      skipNl();
      if (!isOp(']')) {
        for (;;) {
          skipNl();
          items.push(parseExpr());
          skipNl();
          if (isOp(',')) { next(); continue; }
          break;
        }
      }
      skipNl();
      expectOp(']');
      return { k: 'arr', items };
    }
    if (tk.t === 'eof') throw new FormulaError('Formula ends too early', tk.pos, src);
    if (tk.t === 'nl') throw new FormulaError('Unexpected line break', tk.pos, src);
    throw new FormulaError(`Unexpected "${tk.v}"`, tk.pos, src);
  }

  function parsePostfix(node) {
    for (;;) {
      if (isOp('(')) {
        const open = next();
        const args = [];
        skipNl();
        if (!isOp(')')) {
          for (;;) {
            skipNl();
            args.push(parseExpr());
            skipNl();
            if (isOp(',')) { next(); continue; }
            break;
          }
        }
        expectOp(')');
        node = { k: 'call', fn: node, args, pos: open.pos };
      } else if (isOp('.')) {
        next();
        const id = next();
        if (id.t !== 'id') throw new FormulaError('Expected a name after "."', id.pos, src);
        node = { k: 'mem', o: node, key: { k: 'lit', v: id.v }, pos: id.pos };
      } else if (isOp('[')) {
        const open = next();
        const key = parseExpr();
        expectOp(']');
        node = { k: 'mem', o: node, key, pos: open.pos };
      } else break;
    }
    return node;
  }

  const stmts = [];
  skipNl();
  while (peek().t !== 'eof') {
    if (peek().t === 'id' && isOp('=', 1)) {
      const id = next(); next();
      skipNl();
      stmts.push({ k: 'let', name: id.v, e: parseExpr(), pos: id.pos });
    } else {
      stmts.push({ k: 'expr', e: parseExpr() });
    }
    const tk = peek();
    if (tk.t === 'eof') break;
    if (tk.t === 'nl' || (tk.t === 'op' && tk.v === ';')) {
      while (peek().t === 'nl' || isOp(';')) p++;
      continue;
    }
    throw new FormulaError(`Unexpected "${tk.v ?? tk.t}" — missing an operator or line break?`, tk.pos, src);
  }
  if (!stmts.length) throw new FormulaError('Formula is empty', 0, src);
  return stmts;
}

const num = (x) => (typeof x === 'boolean' ? (x ? 1 : 0) : x);

export const FUNCTIONS = {
  floor: Math.floor, ceil: Math.ceil, round: Math.round, trunc: Math.trunc,
  abs: Math.abs, sqrt: Math.sqrt, pow: Math.pow, log: Math.log, log2: Math.log2, exp: Math.exp,
  min: (...a) => Math.min(...a.flat()), max: (...a) => Math.max(...a.flat()),
  clamp: (x, lo, hi) => Math.min(hi, Math.max(lo, x)),
  lerp: (a, b, t) => a + (b - a) * t,
  sign: Math.sign,
  len: (x) => (x == null ? 0 : x.length ?? 0),
  has: (arr, v) => Array.isArray(arr) ? arr.includes(v) : false,
  sum: (...a) => a.flat().reduce((s, x) => s + x, 0),
  // random helpers use the battle/event RNG supplied in the scope
  rand: null, randInt: null, chance: null,
};

function compileNode(n, src) {
  switch (n.k) {
    case 'lit': { const v = n.v; return () => v; }
    case 'arr': { const items = n.items.map((x) => compileNode(x, src)); return (s) => items.map((f) => f(s)); }
    case 'var': {
      const name = n.name;
      return (s) => {
        if (Object.prototype.hasOwnProperty.call(s.locals, name)) return s.locals[name];
        if (s.vars && Object.prototype.hasOwnProperty.call(s.vars, name)) return s.vars[name];
        if (Object.prototype.hasOwnProperty.call(s.fns, name)) return s.fns[name];
        throw new FormulaError(`Unknown name "${name}"`, n.pos, src);
      };
    }
    case 'un': {
      const a = compileNode(n.a, src);
      if (n.op === '-') return (s) => -num(a(s));
      if (n.op === '+') return (s) => +num(a(s));
      return (s) => !a(s);
    }
    case 'bin': {
      const l = compileNode(n.l, src), r = compileNode(n.r, src);
      switch (n.op) {
        case '+': return (s) => { const x = l(s), y = r(s); return typeof x === 'string' || typeof y === 'string' ? `${x}${y}` : num(x) + num(y); };
        case '-': return (s) => num(l(s)) - num(r(s));
        case '*': return (s) => num(l(s)) * num(r(s));
        case '/': return (s) => { const d = num(r(s)); return d === 0 ? 0 : num(l(s)) / d; };
        case '%': return (s) => { const d = num(r(s)); return d === 0 ? 0 : num(l(s)) % d; };
        case '^': return (s) => Math.pow(num(l(s)), num(r(s)));
        case '==': return (s) => l(s) == r(s); // eslint-disable-line eqeqeq
        case '!=': return (s) => l(s) != r(s); // eslint-disable-line eqeqeq
        case '<': return (s) => l(s) < r(s);
        case '<=': return (s) => l(s) <= r(s);
        case '>': return (s) => l(s) > r(s);
        case '>=': return (s) => l(s) >= r(s);
        case '&&': return (s) => l(s) && r(s);
        case '||': return (s) => l(s) || r(s);
      }
      break;
    }
    case 'cond': {
      const c = compileNode(n.c, src), a = compileNode(n.a, src), b = compileNode(n.b, src);
      return (s) => (c(s) ? a(s) : b(s));
    }
    case 'mem': {
      const o = compileNode(n.o, src), key = compileNode(n.key, src);
      return (s) => {
        const obj = o(s), k = key(s);
        if (obj == null) throw new FormulaError(`Cannot read "${k}" of nothing`, n.pos, src);
        if (k === '__proto__' || k === 'constructor' || k === 'prototype') return undefined;
        if (k === 'length' && (Array.isArray(obj) || typeof obj === 'string')) return obj.length;
        if (typeof obj === 'object' && Object.prototype.hasOwnProperty.call(obj, k)) return obj[k];
        if (Array.isArray(obj)) return obj[num(k)];
        return undefined;
      };
    }
    case 'call': {
      const fn = compileNode(n.fn, src), args = n.args.map((a) => compileNode(a, src));
      return (s) => {
        const f = fn(s);
        if (typeof f !== 'function') throw new FormulaError('That is not a function', n.pos, src);
        return f(...args.map((a) => a(s)));
      };
    }
  }
  throw new FormulaError(`Cannot compile ${n.k}`);
}

const cache = new Map();

export function compileFormula(src) {
  const key = String(src ?? '');
  if (cache.has(key)) return cache.get(key);
  const stmts = parse(key);
  const steps = stmts.map((st) => ({ k: st.k, name: st.name, f: compileNode(st.e, key) }));
  const run = (vars = {}, rng = Math.random) => {
    const fns = Object.assign({}, FUNCTIONS, {
      rand: (a, b) => (a == null ? rng() : b == null ? rng() * a : a + rng() * (b - a)),
      randInt: (a, b) => a + Math.floor(rng() * (b - a + 1)),
      chance: (pct) => rng() * 100 < pct,
    });
    const scope = { locals: {}, vars, fns };
    let last;
    for (const st of steps) {
      const v = st.f(scope);
      if (st.k === 'let') scope.locals[st.name] = v;
      last = v;
    }
    return typeof last === 'boolean' ? last : last;
  };
  run.source = key;
  if (cache.size > 500) cache.clear();
  cache.set(key, run);
  return run;
}

/** Evaluate a formula, returning a number. Throws FormulaError with line/col on mistakes. */
export function evalFormula(src, vars, rng) {
  return compileFormula(src)(vars, rng);
}

/** Check a formula against sample variables; returns {ok, value, error, line, col}. */
export function checkFormula(src, vars, rng) {
  try {
    const value = evalFormula(src, vars, rng ?? (() => 0.5));
    return { ok: true, value };
  } catch (e) {
    return { ok: false, error: e.message, line: e.line, col: e.col };
  }
}
