// Activities: things to do together that use a creature's own nature, not battles. Cooking, gardening,
// fishing, scavenging, an obstacle course, puzzles and photography. Its types, the moves it knows, its
// stats and its temperament all shape how well it does and what you get (a fire creature toasts, a
// water creature lures fish, a psychic one sees through puzzles, a fast one flies round the course).
// The game itself happens on screen; this file works out the helper's knack and the rewards.
import { todayKey, addMemory, displayName, touch, gainExp } from './creature.js';
import { wishedFor } from './tasks.js';
import { STAT_KEYS } from './defaults.js';
import { addFriendship, tickNeeds } from './care.js';
import { experience } from './memory.js';
import { temperStyle } from './personality.js';
import { earn, VALUABLES, powerItemOf, HELD, incenseItems } from './shop.js';
import { gearFor } from './ranchBuild.js';
import { rareFinds } from './finds.js';
import { farmState } from './farm.js';
import { RECIPES, RECIPE_DISHES } from './foods.js';
import { FOSSILS } from './fossils.js';
import { hasQuirk } from './quirks.js';
import { noteDid } from './desires.js';

export const ACTIVITIES = [
  { id: 'cooking', name: 'Cooking', desc: 'Cook two foods from the bag into a dish. Fire creatures toast and roast, water ones stew, grass ones bring herbs.', types: /fire|ember|water|tide|grass|sprout|normal|plain/, stat: 'spa', temper: ['calm', 'bold'], energy: 8 },
  { id: 'gardening', name: 'Gardening', desc: 'Pull weeds on the berry farm. Grass, ground and water creatures make everything grow faster.', types: /grass|sprout|ground|water|tide|bug/, stat: 'def', temper: ['calm', 'lazy'], energy: 10 },
  { id: 'fishing', name: 'Fishing', desc: 'Wait for a bite and reel it in. Water creatures lure fish; electric ones give the line a tingle.', types: /water|tide|electric|volt|ice|frost/, stat: 'spe', temper: ['calm', 'shy'], energy: 6 },
  { id: 'scavenging', name: 'Scavenging', desc: 'Dig for buried treasure. Ground, rock and steel creatures sniff out the good spots.', types: /ground|rock|stone|steel|metal|dark|shade|bug/, stat: 'atk', temper: ['bold', 'playful'], energy: 12 },
  { id: 'obstacle', name: 'Obstacle course', desc: 'Hop the hurdles. Fast, nimble and flying creatures sail over them.', types: /flying|gale|fighting|brawl|electric|volt|normal|plain/, stat: 'spe', temper: ['playful', 'bold'], energy: 18 },
  { id: 'puzzle', name: 'Puzzles', desc: 'Match the tiles. Psychic and clever creatures see the pairs.', types: /psychic|mind|ghost|dragon|steel|metal/, stat: 'spa', temper: ['calm', 'shy'], energy: 5 },
  { id: 'training', name: 'Training', desc: 'Drills: move practice, dodging falling rocks, smashing, catching and swiping. For fun and coins; holding a power item, effort goes into its stat.', types: /fighting|brawl|normal|plain|steel|metal|dragon|fire|ember/, stat: 'atk', temper: ['bold', 'playful'], energy: 16 },
  { id: 'photography', name: 'Photography', desc: 'Catch the perfect shot as they strike a pose. Fairies and showy creatures love the camera.', types: /fairy|normal|plain|psychic|mind|fire|ember|dragon/, stat: 'spe', temper: ['playful', 'bold'], energy: 4 },
];
export const activityOf = (id) => ACTIVITIES.find((a) => a.id === id) ?? null;

/** Dishes from cooking: foods like any other (eat them, give them), better than what went in. */
export const DISHES = [
  { id: 'dish-roast', name: 'Toasted Treat', fullness: 45, joy: 22, energy: 10, friendship: 3, color: '#d07a2a', desc: 'Toasted till golden. Smells amazing.' },
  { id: 'dish-stew', name: 'Berry Stew', fullness: 60, joy: 18, energy: 15, friendship: 3, color: '#a0304a', desc: 'A hearty, warming stew.' },
  { id: 'dish-salad', name: 'Fresh Salad', fullness: 35, joy: 20, energy: 20, friendship: 3, color: '#5cbf4a', desc: 'Crisp and full of herbs.' },
  { id: 'dish-cake', name: 'Honey Cake', fullness: 40, joy: 32, friendship: 4, color: '#f2c14a', desc: 'Sweet, sticky and everyone’s favourite.' },
  { id: 'dish-smoothie', name: 'Berry Smoothie', fullness: 25, joy: 26, energy: 25, friendship: 3, color: '#ff7ab0', desc: 'Cold, fruity and refreshing.' },
  { id: 'dish-kelp', name: 'Crunchy Kelp', fullness: 30, joy: 12, energy: 12, friendship: 2, color: '#3f8a5a', desc: 'Fished out of the water. Salty and crunchy.' },
].map((d) => ({ ...d, kind: 'food', price: 60 + d.joy * 3 })).concat(RECIPE_DISHES);

export const typeWords = (idx, c) => {
  const sp = idx.species.get(c.formId ?? c.speciesId) ?? idx.species.get(c.speciesId);
  return (sp?.types ?? []).flatMap((t) => [String(t).toLowerCase(), String(idx.types?.get(t)?.name ?? '').toLowerCase()]);
};
const moveTypeWords = (idx, c) => (c.moves ?? []).map((m) => idx.moves?.get(m.id ?? m)).filter(Boolean).flatMap((mv) => [String(mv.type ?? '').toLowerCase(), String(idx.types?.get(mv.type)?.name ?? '').toLowerCase()]);

/**
 * How good a creature is at an activity: { score 0…1, perks: ['Knows fire moves: everything toasts nicely', …] }.
 */
export function aptitude(idx, c, actId) {
  const act = activityOf(actId);
  if (!act || !c) return { score: 0, perks: [] };
  const sp = idx.species.get(c.formId ?? c.speciesId) ?? idx.species.get(c.speciesId);
  const tw = typeWords(idx, c), mw = moveTypeWords(idx, c);
  const perks = [];
  let s = 0.25;
  if (tw.some((t) => act.types.test(t))) { s += 0.3; perks.push(`${idx.types?.get(sp?.types?.find((t) => act.types.test(String(t).toLowerCase()) || act.types.test(String(idx.types?.get(t)?.name ?? '').toLowerCase())))?.name ?? 'Its'} type is made for this`); }
  const handy = mw.filter((t) => act.types.test(t)).length;
  if (handy) { s += Math.min(0.2, handy * 0.06); perks.push(`knows ${handy >= 3 ? 'lots of ' : ''}handy moves`); }
  const stat = Number(sp?.baseStats?.[act.stat]) || 60;
  s += Math.max(-0.1, Math.min(0.15, (stat - 70) / 400));
  if (stat >= 100) perks.push(`a natural (${act.stat === 'spe' ? 'very quick' : act.stat === 'spa' ? 'very clever' : act.stat === 'atk' ? 'very strong' : 'very sturdy'})`);
  const style = temperStyle(idx, c);
  if (act.temper.includes(style)) { s += 0.1; perks.push(`${style} temperament suits it`); }
  const love = c.prefs?.[`activity:${act.id}`] ?? 0;
  if (love >= 3) { s += 0.08; perks.push('loves doing this'); }
  s += Math.min(0.1, (c.friendship ?? 0) / 2550);
  // specifics
  if (act.id === 'fishing' && tw.some((t) => /water|tide/.test(t))) perks.push('fish swim right up to it');
  if (act.id === 'cooking' && (tw.some((t) => /fire|ember/.test(t)) || mw.some((t) => /fire|ember/.test(t)))) perks.push('keeps the heat just right');
  if (act.id === 'obstacle' && tw.some((t) => /flying|gale/.test(t))) perks.push('can just fly over things');
  if (act.id === 'puzzle' && tw.some((t) => /psychic|mind/.test(t))) perks.push('sees the answer before you do');
  return { score: Math.max(0.05, Math.min(1, s)), perks: [...new Set(perks)].slice(0, 4) };
}

/** Can they do it right now? { ok, reason } */
export function canDo(idx, save, c, actId) {
  const act = activityOf(actId);
  if (!act || !c) return { ok: false, reason: 'Pick someone to help.' };
  if (c.egg) return { ok: false, reason: 'An egg can’t help just yet.' };
  tickNeeds(idx, c);
  // (something it asked to do itself: however tired it is, it wanted this — it isn't turned away)
  const asked = wishedFor(save, c.uid, actId);
  if (!asked && (c.needs?.energy ?? 50) < act.energy + 5) return { ok: false, reason: `${displayName(idx, c)} is too tired. Let them rest first.` };
  // (dozed off while waiting for you to say yes to what it asked for: it's up like a shot)
  if (asked && c.sleep && (c.sleep.until ?? 0) > Date.now()) c.sleep = null;
  if (c.sleep && (c.sleep.until ?? 0) > Date.now()) return { ok: false, asleep: true, reason: `${displayName(idx, c)} is asleep.` };
  if (!asked && (c.upsetUntil ?? 0) > Date.now()) return { ok: false, reason: `${displayName(idx, c)} is upset with you and doesn’t want to.` };
  return { ok: true };
}

/** The dish two ingredients and a helper make. */
export function dishFor(idx, c, ingredients = []) {
  const tw = typeWords(idx, c), mw = moveTypeWords(idx, c);
  const fire = [...tw, ...mw].some((t) => /fire|ember/.test(t)), water = [...tw, ...mw].some((t) => /water|tide|ice|frost/.test(t)), grass = [...tw, ...mw].some((t) => /grass|sprout/.test(t));
  const names = ingredients.map((id) => idx.items?.get?.(id)?.name ?? id).join(' ').toLowerCase();
  if (/honey|sugar|sweet|cake|drop/.test(names)) return DISHES.find((d) => d.id === 'dish-cake');
  if (fire) return DISHES.find((d) => d.id === (water ? 'dish-stew' : 'dish-roast'));
  if (water) return DISHES.find((d) => d.id === (/berry/.test(names) ? 'dish-smoothie' : 'dish-stew'));
  if (grass) return DISHES.find((d) => d.id === 'dish-salad');
  return DISHES.find((d) => d.id === (/berry/.test(names) ? 'dish-smoothie' : 'dish-roast'));
}

const MAX_REWARDED_PER_DAY = 4;
/**
 * Finish an activity. perf: how well it went on screen (0…1). extra: { ingredients } for cooking.
 * Applies the results to the save and returns { ok, perf, stars (0…3), coins, items: [id], text, firstTime }.
 */
/** The drills (trainingGames.js), by id. */
export const DRILL_NAMES = { moves: 'Move practice', dodge: 'Dodge the rocks', smash: 'Strength', swipe: 'Catch and swipe' };

export function finishActivity(idx, save, uid, actId, perf, extra = {}, t = Date.now(), { check = true } = {}) {
  const c = save.creatures[uid];
  const act = activityOf(actId);
  if (!c || !act) return { ok: false, reason: 'Nobody to do that with.' };
  // the side where it was played checks they're up to it; a replay of the same event elsewhere doesn't
  const chk = check ? canDo(idx, save, c, actId) : { ok: true };
  if (!chk.ok) return chk;
  noteDid(c, actId, { t, joy: Math.max(0, Math.min(1, perf ?? 0.5)) }); // (a little bored of it for a day or two; a good time grows the liking)
  tickNeeds(idx, c, t);
  const apt = aptitude(idx, c, actId).score;
  // gear for this activity (bought as blueprints): better results, an extra find, more coins…
  const G = gearFor(save, actId).reduce((g, b) => { for (const [k2, v] of Object.entries(b.gear ?? {})) g[k2] = (g[k2] ?? 0) + v; return g; }, {});
  const p = Math.max(0, Math.min(1, perf * 0.75 + apt * 0.25 + (G.perf ?? 0)));
  const stars = p >= 0.85 ? 3 : p >= 0.6 ? 2 : p >= 0.3 ? 1 : 0;
  const day = todayKey(t);
  const log = save.activityLog?.day === day ? save.activityLog : (save.activityLog = { day, n: {} });
  const k = act.id === 'training' ? `${uid}:${actId}:${extra.drill ?? 'moves'}` : `${uid}:${actId}`;
  const rewarded = (log.n[k] ?? 0) < MAX_REWARDED_PER_DAY;
  log.n[k] = (log.n[k] ?? 0) + 1;
  const items = [];
  let coins = 0;
  let text = '';
  const name = displayName(idx, c);
  const seedish = (n) => Math.abs(Math.sin(t / 1000 + n * 12.9898) * 43758.5453) % 1;
  if (act.id === 'cooking') {
    const ing = (extra.ingredients ?? []).filter((id) => (save.inventory[id] ?? 0) > 0 || idx.items?.get?.(id)?.unlimited);
    for (const id of ing) if (!idx.items?.get?.(id)?.unlimited) save.inventory[id] = Math.max(0, save.inventory[id] - 1);
    // a recipe makes its own dish; a random mix makes whatever the helper's nature suits
    const recipe = extra.recipe ? RECIPES.find((r) => r.id === extra.recipe) : null;
    const dish = recipe ? DISHES.find((d) => d.id === `dish-${recipe.id}`) : dishFor(idx, c, ing);
    const n = (stars >= 3 ? 2 : stars >= 1 ? 1 : 0) + (G.extra && stars >= 1 && seedish(5) < 0.4 ? 1 : 0);
    if (n) { save.inventory[dish.id] = (save.inventory[dish.id] ?? 0) + n; items.push(...Array(n).fill(dish.id)); text = `${name} helped cook ${n > 1 ? `two ${dish.name}s` : `a ${dish.name}`}!`; }
    else text = 'It burnt a bit. Better luck next time!';
  } else if (act.id === 'gardening') {
    const farm = farmState(save);
    const hours = (0.1 + p * 0.65) * 3600000; // at most about 45 minutes' growth
    let sped = 0;
    for (const pl of farm.plots) if (pl && pl.plantedAt) { pl.plantedAt -= hours; sped++; }
    text = sped ? `The weeds are gone and ${sped} plot${sped > 1 ? 's' : ''} grew about ${Math.round(hours / 3600000 * 10) / 10} hours’ worth.` : 'The beds are tidy. Plant something and it’ll grow happily.';
    if (rewarded && stars >= 2) coins = 10 + stars * 5;
  } else if (act.id === 'fishing') {
    const catches = Math.round(p * 3) + (G.extra && p > 0.6 ? 1 : 0);
    for (let i = 0; i < catches; i++) {
      const r = Math.min(0.999, seedish(i) + (G.rare ? 0.2 : 0));
      const id = r < 0.5 ? 'dish-kelp' : r < 0.8 ? 'val-pearl' : r < 0.93 ? 'val-stardust' : 'val-big-pearl';
      save.inventory[id] = (save.inventory[id] ?? 0) + 1; items.push(id);
    }
    text = catches ? `Reeled in ${catches} thing${catches > 1 ? 's' : ''}!` : 'The fish got away this time.';
  } else if (act.id === 'scavenging') {
    const finds = Math.round(p * 3 + (p > 0.9 ? 1 : 0)) + (hasQuirk(c, 'curious') && p > 0.3 ? 1 : 0) + (G.extra ?? 0);
    const give = (id) => { save.inventory[id] = (save.inventory[id] ?? 0) + 1; items.push(id); };
    // a poor dig turns up the odds and ends: a Mystery Seed, a plain Poké Ball, a Potion, a little Stardust
    if (p < 0.45 && seedish(51) < 0.7) {
      const seed = (idx.ds?.items ?? []).find((it) => /mystery\s*seed/i.test(it.name ?? it.id ?? ''));
      const odds = [seed?.id, 'ball-4', 'ball-4', 'med-potion', 'val-stardust'].filter(Boolean);
      give(odds[Math.floor(seedish(52) * odds.length)]);
    }
    // a great one: a better ball now and then, or something caked in mud (a TM, an incense, gear to hold) to clean up
    if (p >= 0.85 || G.rare) {
      if (seedish(53) < 0.45) { const balls = ['ball-2', 'ball-3', 'ball-13', 'ball-15', 'ball-11', 'ball-25', 'ball-26']; give(balls[Math.floor(seedish(54) * balls.length)]); }
      if (seedish(55) < 0.5) {
        const pool = [...(idx.ds?.items ?? []).filter((it) => it.kind === 'tm' || /incense/i.test(it.name ?? '') || it.kind === 'held').map((it) => it.id), ...HELD.map((x) => x.id)];
        try { for (const it of incenseItems(idx).slice(0, 8)) pool.push(it.id); } catch { /* fine */ }
        if (pool.length) give(`dirty:${pool[Math.floor(seedish(56) * pool.length)]}`);
      }
    }
    for (let i = 0; i < finds; i++) {
      const r = Math.min(0.999, seedish(i + 7) + (G.rare ? 0.15 : 0));
      // very, very rarely: a fossil
      if (seedish(i + 41) < 0.006) { const f = FOSSILS[Math.floor(seedish(i + 43) * FOSSILS.length)]; save.inventory[f.id] = (save.inventory[f.id] ?? 0) + 1; items.push(f.id); text = `${name} dug up something ancient: a ${f.name}!`; continue; }
      if (r < 0.35) coins += 15 + Math.round(r * 60);
      else { const pool = VALUABLES.filter((v) => v.rarity >= (r > 0.95 ? 0.3 : 1)); const v = pool[Math.floor(seedish(i + 3) * pool.length)]; save.inventory[v.id] = (save.inventory[v.id] ?? 0) + 1; items.push(v.id); }
    }
    text = text || (finds ? `${name} dug up ${finds} thing${finds > 1 ? 's' : ''}!` : 'Nothing but dirt this time.');
  } else if (act.id === 'obstacle') {
    coins = Math.round(10 + p * 50);
    text = stars >= 3 ? `${name} flew round the course! A perfect run.` : stars >= 2 ? `A great run from ${name}!` : `${name} made it round. Practice makes perfect!`;
  } else if (act.id === 'puzzle') {
    coins = Math.round(10 + p * 40);
    text = stars >= 2 ? `Solved it together. ${name} looks very pleased.` : `A tricky one. ${name} enjoyed trying.`;
  } else if (act.id === 'training') {
    // for fun and coins; effort only with a power item that suits the drill (all of it into that item's stat)
    const R = idx.ds.rules ?? {};
    const drill = extra.drill === 'glide' ? 'swipe' : extra.drill ?? 'moves';
    const NAMES = { hp: 'HP', atk: 'Attack', def: 'Defence', spa: 'Sp. Atk', spd: 'Sp. Def', spe: 'Speed' };
    const pw = powerItemOf(idx, c);
    const fits = pw && pw.drills.includes(drill);
    coins = rewarded ? Math.round(8 + p * 40) : Math.round(2 + p * 8);
    let gains = [];
    if (fits && rewarded) {
      c.effort = c.effort || {};
      const total = STAT_KEYS.reduce((a2, k2) => a2 + (c.effort[k2] ?? 0), 0);
      const room = Math.max(0, Math.min((R.maxEffortPerStat ?? 252) - (c.effort[pw.stat] ?? 0), (R.maxEffortTotal ?? 510) - total));
      const got = Math.min(room, Math.round((4 + p * 8) * (hasQuirk(c, 'quick-learner') ? 1.25 : 1) * (1 + (G.effort ?? 0))));
      if (got) { c.effort[pw.stat] = (c.effort[pw.stat] ?? 0) + got; gains = [[pw.stat, got]]; }
    }
    text = gains.length ? `${NAMES[gains[0][0]]} +${gains[0][1]} effort (thanks to the ${pw.name}) · +${coins} coins`
      : fits && rewarded ? `${name} is as strong as it can get in ${NAMES[pw.stat]}. +${coins} coins.`
      : pw && !fits ? `The ${pw.name} works in ${pw.drills.map((d) => DRILL_NAMES[d]).join(' or ')}, not this drill: just for fun this time. +${coins} coins.`
      : rewarded ? `A good workout! +${coins} coins. (No effort without a power item: hold one to train a stat.)` : `They’ve trained a lot today: +${coins} coins.`;
    extra.gains = gains;
  } else if (act.id === 'photography') {
    coins = stars >= 2 ? 20 + stars * 10 : 5;
    text = stars >= 3 ? `A perfect shot of ${name}!` : stars >= 2 ? `A lovely picture of ${name}.` : `${name} blinked. Still cute!`;
    if (extra.photo) { const album = (save.album = save.album || []); album.push({ uid, at: t, stars, scene: extra.photo.scene ?? null }); if (album.length > 60) album.shift(); }
  }
  if (G.coins) coins = Math.round(coins * (1 + G.coins));
  if (!rewarded && act.id !== 'training') { coins = Math.round(coins / 4); text += ' (They’ve done lots of this today: smaller rewards until tomorrow.)'; }
  if (coins) earn(save, coins);
  // how it felt: tired, happy (more when it went well and they love it), a little closer
  c.needs.energy = Math.max(idx.ds.rules.needsFloor ?? 10, c.needs.energy - act.energy);
  // their nature's quirks: some love a hard workout, some would rather not
  const hard = act.id === 'training' || act.id === 'obstacle';
  const joyQ = hard ? (hasQuirk(c, 'couch-potato') ? -8 : hasQuirk(c, 'restless') ? 4 : 0) : 0;
  c.needs.joy = Math.max(0, Math.min(100, c.needs.joy + 6 + p * 10 + joyQ));
  if (hard && hasQuirk(c, 'couch-potato')) text += ` ${name} would rather have been napping.`;
  if (rewarded) addFriendship(idx, c, stars >= 2 ? 2 : 1, t);
  experience(c, [`activity:${act.id}`], 3 + p * 6, { t, label: `that ${act.name.toLowerCase()} afternoon`, coreChance: 0.01 });
  c.firsts = c.firsts || {};
  const firstTime = !c.firsts[`act:${act.id}`];
  if (firstTime) { c.firsts[`act:${act.id}`] = t; addMemory(c, `Tried ${act.name.toLowerCase()} together for the first time.`, t); }
  touch(c, t);
  // now and then: a blueprint you hadn't found, or something valuable
  let finds = [];
  if (rewarded) { try { finds = rareFinds(idx, save, act.id === 'scavenging' ? 'scavenging' : 'activity', { perfect: stars >= 3, t }); } catch { /* fine */ } }
  for (const f of finds) { if (f.kind === 'valuable') items.push(f.id); text += f.kind === 'blueprint' ? ` Found a ${f.name}!` : ''; }
  return { ok: true, perf: p, stars: act.id === 'training' ? null : stars, coins, items, text, firstTime, gains: extra.gains ?? null, finds };
}
