// "Who wants to …?" — asking the group, and the ones who'd like to step forward.
// "Who wants to go scavenging?", "Anyone up for a movie?", "Who wants to sit on the desktop while I work?" — each
// matches something the game can really do; the ones who want to (good at it, awake, with the energy, in the mood,
// who like it) volunteer, the rest say why not.
//
//   inviteOf(text)                       → { id, label, act?, verb } or null
//   volunteers(idx, save, uids, inv)      → { yes: [{ uid, why, score }], no: [{ uid, why }] } (best first)
import { aptitude, canDo } from './activities.js';
import { isAsleep, tickNeeds } from './care.js';
import { displayName } from './creature.js';

// what can be asked for, and the words that ask for it
export const INVITES = [
  { id: 'scavenging', act: 'scavenging', label: 'go scavenging', verb: 'Go scavenging', re: /scaveng|treasure|dig(ging)?\b|forag|hunt for|search for/ },
  { id: 'cooking', act: 'cooking', label: 'cook something', verb: 'Cook', re: /cook|bake|kitchen|make (some )?(food|dinner|lunch|a dish)/ },
  { id: 'fishing', act: 'fishing', label: 'go fishing', verb: 'Go fishing', re: /fish/ },
  { id: 'gardening', act: 'gardening', label: 'do some gardening', verb: 'Garden', re: /garden|weed|plant|farm|berr(y|ies) patch/ },
  { id: 'obstacle', act: 'obstacle', label: 'run the obstacle course', verb: 'Run the course', re: /obstacle|hurdle|agility|race|course|run (a|some) lap/ },
  { id: 'puzzle', act: 'puzzle', label: 'do some puzzles', verb: 'Do puzzles', re: /puzzle|brain ?teaser|match(ing)? (game|tiles)/ },
  { id: 'training', act: 'training', label: 'train', verb: 'Train', re: /train|practi[cs]e|drill|work ?out|exercise|spar/ },
  { id: 'photography', act: 'photography', label: 'pose for photos', verb: 'Take photos', re: /photo|picture|pic\b|camera|pose|selfie/ },
  { id: 'movie', label: 'watch a movie', verb: 'Watch together', re: /movie|film|cinema|watch (something|a show|tv|telly)|show night/ },
  { id: 'desktop', label: 'sit on the desktop with you', verb: 'Come out on the desktop', re: /desk ?top|on (my|the) desk|while i (work|study)|keep me company|on (my|the) screen|sit with me/ },
  { id: 'battle', label: 'battle', verb: 'Battle', re: /battle|fight|duel|take on/ },
  { id: 'groom', label: 'have a bath and a brush', verb: 'Quality time', re: /bath|brush|groom|wash|clean up|pamper/ },
  { id: 'nap', label: 'take a nap', verb: 'Nap', re: /nap|sleep|rest|lie down|snooze/ },
  { id: 'walk', label: 'come on a walk', verb: 'Come on a walk', re: /walk|stroll|outside|adventure|come with me|on my phone|explore/ },
  { id: 'snack', label: 'have a snack', verb: 'Snack time', re: /snack|eat|food|treat|berr|lunch|dinner|hungry/ },
  { id: 'play', label: 'play', verb: 'Play', re: /play|game|toy|fetch|catch/ },
  { id: 'dance', label: 'dance', verb: 'Dance', re: /danc|sing|music|party/ },
];
const ASK = /\b(who('?s| is)? (wants?|would like|wanna|fancies|is up for|up for|keen)|who('?d| would) (like|want|love)|anyone (want|wanna|up for|fancy|like)|any ?body (want|wanna|up for)|does anyone|who else wants|who is coming|who'?s coming|who('?ll| will) (come|join))\b/i;

/** What a "who wants to …?" asks for, or null when it isn't one. */
export function inviteOf(text) {
  const s = String(text ?? '').toLowerCase();
  if (!ASK.test(s)) return null;
  const rest = s.replace(ASK, ' ');
  for (const inv of INVITES) if (inv.re.test(rest)) return inv;
  return { id: 'any', label: 'join in', verb: 'Join in', re: null };
}

const energyOf = (c) => c.needs?.energy ?? 60, joyOf = (c) => c.needs?.joy ?? c.needs?.happiness ?? 60;
/** Who'd like to, best first, and the others with why not. */
export function volunteers(idx, save, uids, inv, t = Date.now()) {
  const yes = [], no = [];
  for (const uid of uids) {
    const c = save.creatures[uid];
    if (!c || c.egg) continue;
    try { tickNeeds(idx, c, t); } catch { /* fine */ }
    const name = displayName(idx, c);
    const asleep = isAsleep(c, t);
    if (asleep && inv.id !== 'nap') { no.push({ uid, why: `${name} is fast asleep.` }); continue; }
    if ((c.upsetUntil ?? 0) > t) { no.push({ uid, why: `${name} is still upset with you.` }); continue; }
    let score = 0.3 + Math.min(0.2, (c.friendship ?? 0) / 1275), why = '';
    const en = energyOf(c), joy = joyOf(c), full = c.needs?.fullness ?? c.needs?.hunger ?? 60;
    if (inv.act) {
      const ok = canDo(idx, save, c, inv.act);
      if (!ok.ok) { no.push({ uid, why: ok.reason }); continue; }
      const ap = aptitude(idx, c, inv.act); score = ap.score + (c.prefs?.[`activity:${inv.act}`] ?? 0) * 0.05;
      why = ap.perks[0] ? `${ap.perks[0]}` : 'keen to help';
    } else if (inv.id === 'nap') { score = 1 - en / 100 + (asleep ? 0.5 : 0); why = en < 40 ? 'worn out' : 'could do with a doze'; if (en > 75 && !asleep) { no.push({ uid, why: `${name} is wide awake.` }); continue; } }
    else if (inv.id === 'snack') { score = 1 - full / 100 + 0.2; why = full < 40 ? 'starving' : 'always room for a treat'; if (full > 90) { no.push({ uid, why: `${name} is too full.` }); continue; } }
    else if (inv.id === 'movie' || inv.id === 'desktop') { score += (1 - en / 100) * 0.3 + 0.15; why = en < 50 ? 'happy to sit still for a bit' : inv.id === 'movie' ? 'loves a show' : 'curious about your work'; }
    else if (inv.id === 'battle' || inv.id === 'walk' || inv.id === 'play' || inv.id === 'dance') {
      if (en < 25) { no.push({ uid, why: `${name} is too tired.` }); continue; }
      score += en / 250 + joy / 400; why = inv.id === 'battle' ? ((c.level ?? 1) >= 30 ? 'ready for a challenge' : 'eager to prove itself') : en > 70 ? 'full of beans' : 'up for it';
    } else if (inv.id === 'groom') { score += (100 - (c.needs?.clean ?? c.needs?.hygiene ?? 60)) / 200 + 0.1; why = 'loves being fussed over'; }
    else { score += joy / 300; why = 'happy to join in'; }
    // the grumpy and the shy sometimes just don't fancy it
    const mood = c.mood ?? '';
    if (/sulk|sad|grump/.test(mood)) score -= 0.15;
    const r = ((uid.charCodeAt(uid.length - 1) * 7 + Math.floor(t / 600000)) % 10) / 100; // (a little variety, stable for ten minutes)
    score += r;
    if (score < 0.32) { no.push({ uid, why: `${name} doesn’t fancy it right now.` }); continue; }
    yes.push({ uid, why, score });
  }
  yes.sort((a, b) => b.score - a.score);
  return { yes, no };
}
