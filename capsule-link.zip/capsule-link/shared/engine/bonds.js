// Friendships between creatures that share an enclosure (a box's R.A.N.C.H. yard, or free range).
// Time spent together slowly builds a bond. Creatures alike in more than one way bond faster:
// a shared type, a similar size, the same home habitat, the same favourite toy or berry, liking the
// same things. Every pair also has its own chemistry (some just click), so it never feels formulaic.
// At 60 they become friends (a core memory for both); friends seek each other out in the yard and
// are a little happier together. Apart, a bond fades very slowly; friendships never fully vanish.
import { favorites } from './care.js';
import { addMemory, speciesOf, displayName } from './creature.js';
import { habitatsOf } from './habitats.js';

export const FRIEND_AT = 60;
const MAX_HOURS = 48; // catch up at most two days at a time

const enclosureOf = (c) => (c.location?.kind === 'ranch' ? 'ranch' : c.location?.kind === 'box' ? `box:${c.location.box}` : null);
const hash = (s) => { let h = 2166136261; for (const ch of String(s)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0; return h; };

/** How alike two creatures are: { score, reasons: ['both Water', …] } */
export function similarity(idx, a, b) {
  const sa = speciesOf(idx, a), sb = speciesOf(idx, b);
  const reasons = [];
  let score = 0;
  const shared = (sa?.types ?? []).filter((t) => (sb?.types ?? []).includes(t));
  if (shared.length) { score += 2 * shared.length; reasons.push(`both ${shared.map((t) => idx.types.get(t)?.name ?? t).join('/')}`); }
  const ha = Number(sa?.height) || 1, hb = Number(sb?.height) || 1;
  if (Math.max(ha, hb) / Math.min(ha, hb) < 1.4) { score += 1; reasons.push('about the same size'); }
  if (sa && sb && habitatsOf(idx, sa).some((x) => habitatsOf(idx, sb).includes(x))) { score += 1; reasons.push('from the same kind of place'); }
  if (sa && sb && sa.id === sb.id) { score += 1; reasons.push('the same kind'); }
  const fa = favorites(idx, a), fb = favorites(idx, b);
  if (fa.toy && fa.toy === fb.toy) { score += 2; reasons.push('the same favourite toy'); }
  if (fa.berry && fa.berry === fb.berry) { score += 2; reasons.push('the same favourite berry'); }
  const pa = a.prefs ?? {}, pb = b.prefs ?? {};
  const likesBoth = Object.keys(pa).filter((k) => pa[k] >= 4 && (pb[k] ?? 0) >= 4 && !k.startsWith('friend:'));
  if (likesBoth.length) { score += Math.min(2, likesBoth.length); reasons.push('liking the same things'); }
  return { score, reasons };
}

/** Each pair's own chemistry: 0.4 … 1.6, the same every time for these two. */
export function chemistry(a, b) {
  const k = [a.uid, b.uid].sort().join(':');
  return 0.4 + (hash(k) % 1000) / 833;
}

/** Bring every bond up to date (call when the save is opened and now and then). */
export function tickBonds(idx, save, t = Date.now()) {
  const last = save.bondsAt ?? t;
  save.bondsAt = t;
  const hours = Math.min(MAX_HOURS, Math.max(0, (t - last) / 3600000));
  if (hours < 0.05) return [];
  const groups = new Map();
  const all = Object.values(save.creatures ?? {});
  for (const c of all) { if (c.egg) continue; const e = enclosureOf(c); if (e) (groups.get(e) ?? groups.set(e, []).get(e)).push(c); }
  const together = new Set();
  const news = [];
  for (const members of groups.values()) {
    const m = members.slice(0, 40);
    for (let i = 0; i < m.length; i++) for (let j = i + 1; j < m.length; j++) {
      const a = m[i], b = m[j];
      together.add(`${a.uid}:${b.uid}`); together.add(`${b.uid}:${a.uid}`);
      const sim = similarity(idx, a, b).score;
      const gain = hours * (0.04 + sim * 0.06) * chemistry(a, b); // alike pairs: ~1-2 weeks; strangers: months
      const before = a.bonds?.[b.uid] ?? 0;
      const after = Math.min(100, before + gain);
      (a.bonds = a.bonds || {})[b.uid] = after;
      (b.bonds = b.bonds || {})[a.uid] = after;
      if (before < FRIEND_AT && after >= FRIEND_AT) {
        for (const [x, y] of [[a, b], [b, a]]) {
          const nFriends = Object.values(x.bonds).filter((v) => v >= FRIEND_AT).length;
          addMemory(x, `Became friends with ${displayName(idx, y)}.`, t, { core: nFriends <= 5, friend: y.uid });
        }
        news.push({ a: a.uid, b: b.uid });
      }
      // friends are a little happier together
      if (after >= FRIEND_AT) for (const x of [a, b]) if (x.needs) x.needs.joy = Math.min(100, x.needs.joy + hours * 0.8);
    }
  }
  // apart, bonds fade slowly (friendship never drops below what made them friends… almost)
  for (const c of all) {
    for (const [uid, v] of Object.entries(c.bonds ?? {})) {
      if (!save.creatures[uid]) { delete c.bonds[uid]; continue; }
      if (together.has(`${c.uid}:${uid}`)) continue;
      const floor = v >= FRIEND_AT ? FRIEND_AT - 5 : 0;
      const nv = Math.max(floor, v - hours * 0.05);
      if (nv <= 0) delete c.bonds[uid]; else c.bonds[uid] = nv;
    }
  }
  return news;
}

/** Friends of a creature: [{ uid, bond }], closest first. */
export function friendsOf(c, min = FRIEND_AT) {
  return Object.entries(c?.bonds ?? {}).filter(([, v]) => v >= min).sort((a, b) => b[1] - a[1]).map(([uid, bond]) => ({ uid, bond }));
}

/** Two creatures played together (passing a toy back and forth): their bond grows a little. */
export function playedTogether(idx, save, aUid, bUid, t = Date.now()) {
  const a = save.creatures?.[aUid], b = save.creatures?.[bUid];
  if (!a || !b || a === b) return null;
  const before = a.bonds?.[bUid] ?? 0;
  const after = Math.min(100, before + 0.6 * chemistry(a, b));
  (a.bonds = a.bonds || {})[bUid] = after;
  (b.bonds = b.bonds || {})[aUid] = after;
  if (before < FRIEND_AT && after >= FRIEND_AT) {
    for (const [x, y] of [[a, b], [b, a]]) addMemory(x, `Became friends with ${displayName(idx, y)} over a game in the yard.`, t, { core: true, friend: y.uid });
    return { friends: true };
  }
  return { friends: false };
}
