// Deals and promises. "Whoever wins the next race gets to come on a walk with me": everyone who heard it
// remembers (the ones who'd love a walk most are keenest), the winner is owed that walk — and knows exactly
// why — and when you take it, it celebrates *that*: the walk it won. A promise you never keep is remembered
// too, and makes the next one harder to believe.
//
//   makeDeal(idx, save, parse, uids, t)          → { deal, reactions: [{ uid, keen, note, pic }] }
//   promise(idx, save, c, prize, t, why)          → an owed prize for one of them (a promise made straight to it)
//   settleDeal(idx, save, { kind, winner, uids, goal }, t) → { deal, winner, note, prize, task } or null
//   keepPromise(idx, save, c, kind, t)            → { note, owed } when this was something it was owed, else null
//   checkPromises(idx, save, t)                   → promises gone unkept too long: [{ uid, note }]
//   owedOf(c), openDeal(save, kind), keenOn(idx, save, c, prize)
import { displayName, addMemory, todayKey } from './creature.js';
import { remember } from './dayMemory.js';
import { journal } from './memory.js';
import { tasteFor } from './invite.js';
import { allFoods } from './shop.js';
import { favorites, isAsleep } from './care.js';

export const OWED_DAYS = 3;
const DAY = 86400000;
const hash = (s) => { let x = 2166136261; for (let i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); } return ((x >>> 0) % 10007) / 10007; };
const PRIZE_TASTE = { walk: 'walk', pets: 'pets', toy: 'play', desktop: 'desktop', battle: 'battle', nap: 'nap', food: 'snack' };

/** How much it wants this prize: 0 … 1. */
export function keenOn(idx, save, c, prize) {
  if (!c || !prize) return 0;
  let v = 0.5;
  const tk = PRIZE_TASTE[prize.kind];
  if (tk) { try { v += tasteFor(idx, c, tk) * 0.35; } catch { /* fine */ } }
  if (prize.kind === 'walk') v += ((c.prefs?.['activity:walk'] ?? 0) / 10) * 0.3;
  if (prize.kind === 'food') { v += (55 - (c.needs?.fullness ?? 60)) / 200; if (prize.item) v += ((c.prefs?.[`food:${prize.item}`] ?? 0) / 10) * 0.3; }
  if (prize.kind === 'nap') v += (50 - (c.needs?.energy ?? 60)) / 150;
  if (prize.kind === 'glory' || prize.kind === 'choose') v += /bold|playful/.test(c.styleHint ?? '') ? 0.15 : 0;
  return Math.max(0, Math.min(1, v));
}
const trustOf = (c) => { const tr = c.trust ?? {}; return (tr.kept ?? 0) - (tr.broken ?? 0) * 2; };
export const owedOf = (c) => (c?.owed ?? []).filter(Boolean);
export const openDeal = (save, kind) => (save.deals ?? []).filter((d) => d.state === 'open' && (d.cond?.kind === kind || d.cond?.kind === 'any' || !kind)).sort((a, b) => b.made - a.made)[0] ?? null;

function prizeItem(idx, words) {
  const s = String(words ?? '').toLowerCase();
  return allFoods(idx).find((f) => f.name && s.includes(String(f.name).toLowerCase().replace(/\s*berry$/, '')))?.id ?? null;
}
/** A deal: what has to happen, and what the one who does it gets. Everyone who heard it remembers. */
export function makeDeal(idx, save, parse, uids, t = Date.now()) {
  const prize = { ...parse.prize, item: parse.prize?.kind === 'food' ? prizeItem(idx, parse.prizeWords ?? parse.prize?.words) : null };
  if (prize.item) prize.label = `${/^[aeiou]/i.test(idx.items?.get?.(prize.item)?.name ?? '') ? 'an' : 'a'} ${idx.items?.get?.(prize.item)?.name ?? 'treat'}`;
  const heard = uids.filter((u) => { const c = save.creatures?.[u]; return c && !c.egg && !isAsleep(c, t); });
  save.deals = (save.deals ?? []).filter((d) => !(d.state === 'open' && d.cond?.kind === parse.cond?.kind)).filter((d) => t - d.made < 7 * DAY).slice(-12);
  const deal = { id: `deal-${t.toString(36)}`, made: t, cond: { kind: parse.cond?.kind ?? 'any', next: parse.cond?.next !== false, words: parse.cond?.words ?? '', route: parse.cond?.route ?? parse.route ?? null }, prize, heard, words: parse.raw ?? '', state: 'open' };
  save.deals.push(deal);
  const what = condWords(deal);
  const reactions = heard.map((u) => {
    const c = save.creatures[u], nm = displayName(idx, c), keen = keenOn(idx, save, c, prize), tr = trustOf(c);
    remember(c, 'deal', deal.id, 1 + keen * 2, t);
    c.hopes = [...(c.hopes ?? []).filter((h) => h && t - h.t < 2 * DAY && h.dealId !== deal.id), { dealId: deal.id, keen, t }].slice(-4);
    const seed = `${u}:${deal.id}`, pick = (a) => a[Math.floor(hash(seed) * a.length)];
    let note;
    if (tr <= -2 && keen > 0.4) note = `${nm} perks up at ${prize.label}… then gives you a look. Last time you promised something, it never happened.`;
    else if (keen > 0.78) note = pick([`${nm} is fired up: ${prize.label}?! It's going to win ${what}!`, `${nm} can't sit still. ${cap(prize.label)} is all it can think about now.`, `${nm} is already stretching for ${what}. It wants ${prize.label} badly.`]);
    else if (keen > 0.55) note = pick([`${nm} likes the sound of ${prize.label}. Game on!`, `${nm} nods: ${prize.label} for winning ${what}? Deal.`]);
    else if (keen > 0.35) note = `${nm} shrugs: ${prize.label} would be nice, it supposes.`;
    else note = `${nm} isn't fussed about ${prize.label}, but it'll join in.`;
    return { uid: u, keen, note, pic: prize.icon ?? '✨' };
  });
  return { deal, reactions };
}
const cap = (s) => String(s).charAt(0).toUpperCase() + String(s).slice(1);
function condWords(deal, goal = null) {
  const k = deal.cond?.kind, to = goal ?? deal.cond?.route?.to?.words;
  if (k === 'race') return `the ${deal.cond.next ? 'next ' : ''}race${to ? ` to the ${to.replace(/^the /, '')}` : ''}`;
  if (k === 'battle') return `the ${deal.cond.next ? 'next ' : ''}battle`;
  if (k === 'any') return 'the next game';
  return `the next round of ${k}`;
}

/** A promise made straight to one of them ("I'll take you on a walk later"): it's owed, and it knows why. */
export function promise(idx, save, c, prize, t = Date.now(), why = 'because you promised') {
  if (!c || !prize) return null;
  const o = { id: `owed-${t.toString(36)}-${c.uid.slice(-3)}`, prize: { kind: prize.kind, label: prize.label, icon: prize.icon, item: prize.item ?? null }, why, t, due: t + OWED_DAYS * DAY };
  c.owed = [...owedOf(c).filter((x) => x.prize?.kind !== prize.kind), o].slice(-5);
  remember(c, 'promise', prize.kind, 2, t);
  return o;
}

/**
 * Something happened that a deal was about. ev: { kind: 'race' | 'battle' | an activity, winner, uids, goal }.
 * The winner is owed the prize; it, and the others, remember why.
 */
export function settleDeal(idx, save, { kind, winner, uids = [], goal = null }, t = Date.now()) {
  const deal = openDeal(save, kind);
  if (!deal || !winner) return null;
  const c = save.creatures?.[winner];
  if (!c) return null;
  // (a deal is for the ones who heard it; anyone who wins counts when nobody in particular was listening)
  if (deal.heard?.length && !deal.heard.includes(winner)) return null;
  deal.state = 'won'; deal.winner = winner; deal.wonAt = t;
  const nm = displayName(idx, c), what = condWords({ ...deal, cond: { ...deal.cond, next: false } }, goal);
  const others = uids.filter((u) => u !== winner).map((u) => save.creatures?.[u]).filter(Boolean);
  const why = `for winning ${what}${others.length ? ` against ${others.slice(0, 3).map((o) => displayName(idx, o)).join(' and ')}` : ''}`;
  const prize = { ...deal.prize };
  if (prize.kind === 'food' && !prize.item) { prize.item = favorites(idx, c).berry ?? null; if (prize.item) prize.label = `${/^[aeiou]/i.test(idx.items?.get?.(prize.item)?.name ?? '') ? 'an' : 'a'} ${idx.items?.get?.(prize.item)?.name ?? 'treat'}`; }
  remember(c, 'won', what, 3, t, { deal: deal.id });
  journal(c, `Won ${what} — and with it ${prize.label}, like you promised.`, t);
  c.needs = c.needs || {};
  c.needs.joy = Math.min(100, (c.needs.joy ?? 60) + 6);
  for (const o of others) { remember(o, 'lost', what, 1, t, { to: winner, deal: deal.id }); }
  let task = null, note;
  const nowPrize = ['pets', 'glory', 'choose', 'nap'].includes(prize.kind);
  if (nowPrize) {
    // some prizes are had right away
    deal.state = 'kept';
    const add = { pets: 'gets showered with pets', glory: 'gets the bragging rights', choose: 'gets first pick next time', nap: 'claims the comfiest napping spot' }[prize.kind];
    note = `${nm} wins ${what} and ${add}! It does a little victory lap.`;
    if (prize.kind === 'pets') { c.needs.joy = Math.min(100, c.needs.joy + 8); c.friendship = Math.min(255, (c.friendship ?? 0) + 2); }
    if (prize.kind === 'choose') c.picksNext = t;
    addMemory(c, `Won ${what}${others.length ? ` against ${others.slice(0, 3).map((o) => displayName(idx, o)).join(' and ')}` : ''}, and ${add.replace(/^gets /, 'got ').replace(/^claims /, 'claimed ')}.`, t, { core: false });
  } else {
    const o = promise(idx, save, c, prize, t, why);
    if (o) { o.dealId = deal.id; o.won = what; o.against = others.slice(0, 3).map((x) => displayName(idx, x)); }
    note = `${nm} wins ${what}! It's owed ${prize.label} now — and it won't let you forget it.`;
    task = { id: `task-${winner}-${t.toString(36)}`, uid: winner, made: t, due: t + OWED_DAYS * DAY, kind: prize.kind === 'food' ? 'food' : 'wish', key: prize.kind === 'food' ? undefined : `wish:${prize.kind === 'battle' ? 'battle' : prize.kind === 'desktop' ? 'desktop' : 'walk'}`, item: prize.item ?? undefined, icon: prize.icon ?? '🏆', text: `${nm} won ${what}: you promised it ${prize.label}.`, promise: true };
  }
  return { deal, winner, note, prize, task, why };
}

/** You gave it something it was owed (a walk, a treat…): it remembers that this was the prize, and celebrates it. */
export function keepPromise(idx, save, c, kind, t = Date.now()) {
  if (!c) return null;
  const o = owedOf(c).find((x) => x.prize?.kind === kind);
  if (!o) return null;
  c.owed = owedOf(c).filter((x) => x !== o);
  c.trust = { ...(c.trust ?? {}), kept: (c.trust?.kept ?? 0) + 1 };
  c.needs = c.needs || {};
  c.needs.joy = Math.min(100, (c.needs.joy ?? 60) + 12);
  c.friendship = Math.min(255, (c.friendship ?? 0) + 3);
  const nm = displayName(idx, c);
  const what = { walk: 'the walk', food: o.prize.label?.replace(/^an? /, 'the ') ?? 'the treat', battle: 'the battle', desktop: 'its spot on your desktop', toy: 'the new toy' }[kind] ?? o.prize.label;
  const why = o.why ?? 'because you promised';
  const text = o.won ? `Got ${what} it won in ${o.won}${o.against?.length ? `, beating ${o.against.join(' and ')}` : ''}.${kind === 'walk' ? ' It strutted the whole way.' : ''}` : `Got ${what} you promised it.${kind === 'walk' ? ' It was worth the wait.' : ''}`;
  addMemory(c, text, t, { core: true, kept: true });
  remember(c, 'kept', kind, 3, t, { why });
  if (o.dealId) { const d = (save?.deals ?? []).find((x) => x.id === o.dealId); if (d) d.state = 'kept'; }
  c.lastKept = { kind, why, t, label: o.prize.label, what, won: o.won ?? null };
  return { note: o.won ? `${nm} is beside itself: it's finally getting ${what} it won in ${o.won}!` : `${nm} is beside itself: ${what} you promised it!`, owed: o };
}

/** Promises left too long: they're remembered as broken (a little hurt, and less sure of the next one). */
export function checkPromises(idx, save, t = Date.now()) {
  const out = [];
  for (const c of Object.values(save.creatures ?? {})) {
    const late = owedOf(c).filter((o) => (o.due ?? o.t + OWED_DAYS * DAY) < t);
    if (!late.length) continue;
    c.owed = owedOf(c).filter((o) => !late.includes(o));
    for (const o of late) {
      c.trust = { ...(c.trust ?? {}), broken: (c.trust?.broken ?? 0) + 1 };
      c.needs = c.needs || {};
      c.needs.joy = Math.max(0, (c.needs.joy ?? 60) - 8);
      const text = o.won ? `It won ${o.prize?.label ?? 'a prize'} in ${o.won}, and you never gave it.` : `You promised it ${o.prize?.label ?? 'something'}, and it never happened.`;
      journal(c, text, t);
      addMemory(c, text, t, { core: false, broken: true });
      remember(c, 'upset', `the ${o.prize?.label?.replace(/^an? /, '') ?? 'promise'} you never gave it`, 2, t);
      c.lastBroken = { kind: o.prize?.kind, label: o.prize?.label, why: o.why, t };
      if (o.dealId) { const d = (save.deals ?? []).find((x) => x.id === o.dealId); if (d) d.state = 'broken'; }
      out.push({ uid: c.uid, note: `${displayName(idx, c)} has given up on ${o.prize?.label ?? 'what you promised'}.` });
    }
  }
  return out;
}
