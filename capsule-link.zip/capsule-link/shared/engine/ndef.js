// Minimal NDEF + Type 2 tag TLV encoding (enough for capsule tags).

const enc = new TextEncoder();
const dec = new TextDecoder();

export const TNF = { EMPTY: 0, WELL_KNOWN: 1, MIME: 2, URI: 3, EXTERNAL: 4, UNKNOWN: 5 };

/** records: [{ tnf, type: string|Uint8Array, payload: Uint8Array, id? }] */
export function encodeNdefMessage(records) {
  const parts = [];
  records.forEach((r, i) => {
    const type = typeof r.type === 'string' ? enc.encode(r.type) : r.type ?? new Uint8Array();
    const payload = r.payload ?? new Uint8Array();
    const id = r.id ? (typeof r.id === 'string' ? enc.encode(r.id) : r.id) : null;
    const sr = payload.length < 256;
    let header = (r.tnf ?? TNF.MIME) & 0x07;
    if (i === 0) header |= 0x80; // MB
    if (i === records.length - 1) header |= 0x40; // ME
    if (sr) header |= 0x10; // SR
    if (id) header |= 0x08; // IL
    const head = [header, type.length];
    if (sr) head.push(payload.length);
    else head.push((payload.length >>> 24) & 255, (payload.length >>> 16) & 255, (payload.length >>> 8) & 255, payload.length & 255);
    if (id) head.push(id.length);
    parts.push(Uint8Array.from(head), type);
    if (id) parts.push(id);
    parts.push(payload);
  });
  return concat(parts);
}

export function decodeNdefMessage(bytes) {
  const records = [];
  let p = 0;
  while (p < bytes.length) {
    const header = bytes[p++];
    const tnf = header & 0x07, sr = !!(header & 0x10), il = !!(header & 0x08), me = !!(header & 0x40);
    const typeLen = bytes[p++];
    let payloadLen;
    if (sr) payloadLen = bytes[p++];
    else { payloadLen = ((bytes[p] << 24) | (bytes[p + 1] << 16) | (bytes[p + 2] << 8) | bytes[p + 3]) >>> 0; p += 4; }
    const idLen = il ? bytes[p++] : 0;
    const type = bytes.slice(p, p + typeLen); p += typeLen;
    const id = bytes.slice(p, p + idLen); p += idLen;
    const payload = bytes.slice(p, p + payloadLen); p += payloadLen;
    if (p > bytes.length) throw new Error('NDEF record is cut short');
    records.push({ tnf, type: dec.decode(type), typeBytes: type, id: dec.decode(id), payload, offset: p - payloadLen });
    if (me) break;
  }
  return records;
}

/** Wrap an NDEF message in a Type 2 tag NDEF TLV + terminator. */
export function wrapTlv(message) {
  const len = message.length;
  const head = len < 255 ? [0x03, len] : [0x03, 0xff, (len >> 8) & 255, len & 255];
  return concat([Uint8Array.from(head), message, Uint8Array.of(0xfe)]);
}

/**
 * Find the NDEF message inside raw tag user memory (starting at page 4).
 * Returns { message, offset } where offset is the message start within `mem`.
 */
export function findNdefTlv(mem) {
  let p = 0;
  while (p < mem.length) {
    const t = mem[p];
    if (t === 0x00) { p++; continue; } // NULL TLV
    if (t === 0xfe) return null; // terminator
    let len = mem[p + 1], hdr = 2;
    if (len === 0xff) { len = (mem[p + 2] << 8) | mem[p + 3]; hdr = 4; }
    if (t === 0x03) return { message: mem.slice(p + hdr, p + hdr + len), offset: p + hdr };
    p += hdr + len; // skip lock/memory control TLVs
  }
  return null;
}

export function concat(parts) {
  const total = parts.reduce((s, x) => s + x.length, 0);
  const out = new Uint8Array(total);
  let o = 0;
  for (const x of parts) { out.set(x, o); o += x.length; }
  return out;
}

export function toHex(bytes) {
  return Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('').toUpperCase();
}

export function fromHex(hex) {
  const clean = String(hex).replace(/[^0-9a-f]/gi, '');
  const out = new Uint8Array(clean.length >> 1);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(clean.substr(i * 2, 2), 16);
  return out;
}

export function toBase64(bytes) {
  let s = '';
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s);
}

export function fromBase64(b64) {
  const s = atob(b64);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}
