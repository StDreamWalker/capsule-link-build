// Texting your buddy: tell them what you're doing. They can't answer in words, but they pick up on things
// (food, music, a walk, bedtime, your day…) and react with a cry, a little picture in a speech bubble, a
// mood. Hear a word often enough and it becomes one of theirs: from then on they "say" it back, their own
// way (a cry cut into syllables, like "Pika-pi!"), whenever it comes up.
//
//   chatReply(idx, save, c, text, t) → { say, pieces, mood, emote, bubble, topics, learned, note }
//   applied as an event ('chat') so the PC and phone stay the same: everything here is decided from the
//   text, the time and the creature (no Math.random).
import { displayName, addMemory, touch, speciesOf } from './creature.js';
import { favorites } from './care.js';
import { allFoods } from './shop.js';
import { prefLabel } from './memory.js';
import { quirksOf } from './quirks.js';

export const LEARN_AFTER = 5; // times a word has to come up before it's theirs
const TOPICS = [
  ['food', /\b(eat|eating|ate|food|hungry|snack|snacks|dinner|lunch|breakfast|treat|treats|berry|berries|cook|cooking|yummy|delicious)\b/i, '🍓'],
  ['music', /\b(song|songs|music|listening|tune|playlist|sing|singing|album|concert)\b/i, '🎵'],
  ['walk', /\b(walk|walking|outside|go out|park|run|running|jog|hike|stroll)\b/i, '🚶'],
  ['sleep', /\b(sleep|sleepy|tired|bed|bedtime|nap|good ?night|night night)\b/i, '💤'],
  ['play', /\b(play|playing|game|games|ball|toy|toys|fun)\b/i, '🎾'],
  ['love', /\b(love you|love ya|good (boy|girl|job)|cute|cutie|best buddy|proud of you|adorable)\b/i, '💗'],
  ['hello', /^(hi|hey|hello|yo|hiya|good morning|morning|howdy)\b/i, '👋'],
  ['work', /\b(work|working|school|class|meeting|homework|study|studying|office|job|busy|exam|test)\b/i, '💼'],
  ['sad', /\b(sad|upset|bad day|stressed|lonely|crying|cry|miss you|awful|rough day)\b/i, '🫂'],
  ['happy', /\b(happy|great|awesome|yay|good news|excited|amazing|woohoo)\b/i, '🎉'],
  ['weather', /\b(rain|raining|sunny|snow|snowing|cold|hot|storm|windy|weather)\b/i, '🌦️'],
  ['bath', /\b(bath|wash|clean|shower|brush)\b/i, '🫧'],
  ['car', /\b(car|drive|driving|bus|train|ride)\b/i, '🚗'],
  ['tv', /\b(tv|movie|show|watching|video|youtube|stream)\b/i, '📺'],
  ['friends', /\b(friend|friends|party|hang out|visit)\b/i, '🧑‍🤝‍🧑'],
];
const hash = (s) => { let h = 2166136261; for (const ch of String(s)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0; return h; };
const roll = (seed, n) => hash(seed) % n;

/** A species name in syllables: "Pikachu" → ["Pi", "ka", "chu"], "Bulbasaur" → ["Bul", "ba", "saur"]. */
export function syllables(name) {
  const s = String(name || 'Mon').replace(/[^A-Za-zÀ-ÿ]/g, '').toLowerCase();
  if (!s) return ['Mon'];
  // letters into sounds: a few pairs count as one consonant
  const units = [];
  for (let i = 0; i < s.length; i++) {
    const two = s.slice(i, i + 2);
    if (/^(ch|sh|th|ph|wh|ck|qu|gh)$/.test(two)) { units.push(two); i++; } else units.push(s[i]);
  }
  const isV = (u) => /^[aeiouyàâäéèêëïîôöùûü]$/.test(u);
  const out = [];
  let cur = '', i = 0;
  while (i < units.length) {
    while (i < units.length && !isV(units[i])) cur += units[i++]; // onset
    while (i < units.length && isV(units[i])) cur += units[i++]; // vowels
    // consonants after: one goes to the next syllable; of two or more, the first stays here; at the end, all stay
    let j = i; while (j < units.length && !isV(units[j])) j++;
    const n = j - i;
    if (j >= units.length) { while (i < units.length) cur += units[i++]; }
    else if (n >= 2) cur += units[i++];
    out.push(cur); cur = '';
  }
  if (cur) out.push(cur);
  const syl = out.filter(Boolean).slice(0, 4);
  return syl.map((p, k) => (k === 0 ? p[0].toUpperCase() + p.slice(1) : p));
}
/**
 * How a creature says a word: syllables of its own name (text) and the matching pieces of its cry
 * ([[from, to, semitones, speed]] for creatureCry's chop), always the same for the same word.
 */
export function wordFor(name, key) {
  const syl = syllables(name);
  const h = hash(`${name}:${key}`);
  const n = 2 + (h % 2); // two or three syllables
  const first = syl.slice(0, Math.min(3, syl.length));
  // mostly the start of their name, like "Pika-pi" or "Bul-ba"
  const picks = Array.from({ length: n }, (_, i) => (i === 0 ? syl[0] : first[(h >>> (i * 3)) % first.length]));
  const text = picks.map((p, i) => (i === 0 ? p[0].toUpperCase() + p.slice(1) : p.toLowerCase())).reduce((a, p, i) => a + (i === 1 || (i === 2 && h & 8) ? '-' : '') + p, '');
  const pieces = picks.map((p, i) => {
    const at = syl.indexOf(p) / syl.length, len = 1 / syl.length;
    return [Math.max(0, at), Math.min(1, at + len + 0.08), (((h >>> (8 + i * 4)) % 7) - 3) + (i === n - 1 ? 1 : 0), 1.1];
  });
  return { text: `${text}!`, pieces };
}
/** Their "yes" and "no" (the same every time for them). */
export const yesFor = (name) => { const s = syllables(name); return { text: `${s[0]}-${s[0].toLowerCase()}!`, pieces: [[0, 0.3, 1, 1.2], [0, 0.35, 3, 1.15]] }; };
export const noFor = (name) => { const s = syllables(name); const last = s[s.length - 1]; return { text: `${last[0].toUpperCase()}${last.slice(1)}… ${last.toLowerCase()}.`, pieces: [[0.6, 1, -1, 0.9], [0.65, 1, -4, 0.85]] }; };

/** What they make of a message (and what they learn from it). Changes c (their chat memory, joy). */
export function chatReply(idx, save, c, text, t = Date.now()) {
  const msg = String(text ?? '').trim().slice(0, 400);
  const name = displayName(idx, c);
  const spName = speciesOf(idx, c)?.name ?? name;
  const st = (c.chat = c.chat || { heard: {}, known: {}, n: 0, lastJoyAt: 0, day: '', today: 0 });
  st.n++;
  const seed = `${c.uid}:${msg}:${Math.floor(t / 60000)}`;
  const question = /\?\s*$/.test(msg) || /^(do|does|did|are|is|will|would|can|could|should|want|wanna|how about|shall)\b/i.test(msg);
  const topics = TOPICS.filter(([, re]) => re.test(msg)).map(([k]) => k);
  // foods by name ("an Oran Berry?")
  const foods = allFoods(idx).filter((f) => f.name && new RegExp(`\\b${String(f.name).replace(/\s*berry$/i, '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(msg));
  for (const f of foods.slice(0, 2)) topics.push(`food:${f.id}`);
  if (new RegExp(`\\b${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(msg)) topics.push('name');
  // hearing words: often enough, and it's one of theirs
  let learned = null;
  for (const k of topics) {
    st.heard[k] = (st.heard[k] ?? 0) + 1;
    if (!st.known[k] && st.heard[k] >= LEARN_AFTER && !learned) {
      st.known[k] = t; learned = k;
      if (!c.firsts?.chatWord) { c.firsts = { ...(c.firsts || {}), chatWord: t }; addMemory(c, `Worked out what “${wordLabel(idx, k)}” means, from all your messages.`, t); }
    }
  }
  const mood = c.needs ? (c.needs.energy < 25 ? 'sleepy' : c.needs.fullness < 30 ? 'hungry' : c.needs.joy > 70 ? 'happy' : 'content') : 'content';
  const fav = favorites(idx, c);
  const lazy = quirksOf(idx, c).some((q) => q.id === 'napper' || q.id === 'couch-potato');
  let r = { emote: '?', bubble: null, mood: 'curious', say: null, pieces: null, note: '' };
  const yes = (extra = {}) => ({ ...yesFor(spName), mood: 'happy', emote: 'hearts', ...extra });
  const no = (extra = {}) => ({ ...noFor(spName), mood: 'meh', emote: 'sweat', ...extra });
  const has = (k) => topics.includes(k);
  const known = topics.find((k) => st.known[k] && k !== 'name');
  if (has('food') || topics.some((k) => k.startsWith('food:'))) {
    const asked = topics.find((k) => k.startsWith('food:'))?.slice(5);
    const likes = Object.entries(c.prefs ?? {}).filter(([k, v]) => k.startsWith('food:') && v > 1).sort((a, b) => b[1] - a[1]).map(([k]) => k.slice(5));
    const want = asked && (c.prefs?.[`food:${asked}`] ?? 0) < -1 ? null : asked ?? (c.firsts?.[`fav:${fav.berry}`] ? fav.berry : likes[roll(seed, Math.max(1, likes.length))] ?? fav.berry);
    if (question || mood === 'hungry') r = want ? yes({ bubble: { kind: 'item', id: want }, emote: 'hearts', note: `${name} would love a ${idx.items?.get?.(want)?.name ?? 'snack'}.` }) : no({ bubble: { kind: 'emoji', e: '🙅' }, note: `${name} isn't keen on that one.` });
    else r = { emote: 'note', bubble: { kind: 'item', id: want ?? fav.berry }, mood: 'happy', note: `${name} licks their lips.` };
  } else if (has('music')) {
    const likesMusic = (hash(`${c.uid}:music:${Math.floor(t / 600000)}`) % 10) < (c.temper && /jolly|naive|hasty|cheery|eager|rowdy/i.test(c.temper) ? 8 : 6);
    r = question ? (likesMusic ? yes({ bubble: { kind: 'emoji', e: '🎵' }, emote: 'note', note: `${name} bobs along to it.` }) : no({ bubble: { kind: 'emoji', e: '🎵❌' }, note: `${name} isn't feeling this one.` }))
      : { emote: 'note', bubble: { kind: 'emoji', e: '🎵' }, mood: 'happy', note: `${name} sways a little.` };
  } else if (has('walk')) {
    r = (c.needs?.energy ?? 60) < 30 || lazy && roll(seed, 3) === 0 ? no({ bubble: { kind: 'emoji', e: '💤' }, note: `${name} would rather rest.` }) : yes({ bubble: { kind: 'emoji', e: '🚶' }, emote: 'exclaim', note: `${name} is ready to go!` });
  } else if (has('sleep')) {
    r = { emote: 'zzz', bubble: { kind: 'emoji', e: '💤' }, mood: 'sleepy', note: mood === 'sleepy' ? `${name} yawns. Same.` : `${name} curls up next to the screen.`, ...(question ? yesFor(spName) : {}) };
  } else if (has('love')) {
    r = { ...yesFor(spName), emote: 'hearts', bubble: { kind: 'emoji', e: '💗' }, mood: 'happy', note: `${name} glows.` };
  } else if (has('sad')) {
    r = { emote: 'hearts', bubble: { kind: 'emoji', e: '🫂' }, mood: 'worried', note: `${name} snuggles up to cheer you up.` };
  } else if (has('happy')) {
    r = { ...yesFor(spName), emote: 'exclaim', bubble: { kind: 'emoji', e: '🎉' }, mood: 'happy', note: `${name} celebrates with you!` };
  } else if (has('work')) {
    r = { emote: 'sweat', bubble: { kind: 'emoji', e: '💼' }, mood: 'content', note: `${name} waits patiently for you.` };
  } else if (has('play')) {
    r = (c.needs?.energy ?? 60) < 20 ? no({ bubble: { kind: 'emoji', e: '💤' } }) : yes({ bubble: { kind: 'emoji', e: '🎾' }, emote: 'exclaim', note: `${name} wiggles, ready to play.` });
  } else if (has('hello')) {
    r = { ...yesFor(spName), emote: 'exclaim', bubble: { kind: 'emoji', e: '👋' }, mood: 'happy', note: `${name} perks up.` };
  } else if (topics.length) {
    const tp = TOPICS.find(([k]) => k === topics[0]);
    r = { emote: 'note', bubble: tp ? { kind: 'emoji', e: tp[2] } : null, mood: 'curious', note: `${name} listens closely.`, ...(question ? (roll(seed, 2) ? yesFor(spName) : noFor(spName)) : {}) };
  } else if (question) {
    r = roll(seed, 3) ? yes({ emote: 'note' }) : no();
  } else {
    r = { emote: '?', bubble: { kind: 'emoji', e: '❓' }, mood: 'curious', note: `${name} tilts their head.` };
  }
  // their yes / no as something they say
  if (r.text && !r.say) { r.say = r.text; }
  delete r.text;
  // a word they know: they say it, their own way
  if (known || learned) {
    const k = learned ?? known;
    const w = wordFor(spName, k);
    r.say = w.text; r.pieces = w.pieces;
    r.note = learned ? `${name} said “${w.text}” — they’ve learned “${wordLabel(idx, k)}”!` : r.note;
  }
  // a little joy from being talked to (not too often), and closer for the first few chats each day
  const day = new Date(t).toDateString();
  if (st.day !== day) { st.day = day; st.today = 0; }
  st.today++;
  if (c.needs && t - (st.lastJoyAt ?? 0) > 60000) { c.needs.joy = Math.min(100, c.needs.joy + (r.mood === 'happy' ? 4 : 2)); st.lastJoyAt = t; }
  if (st.today <= 3) c.friendship = Math.min(idx.ds?.rules?.maxFriendship ?? 255, (c.friendship ?? 0) + 1);
  if (st.n === 1) addMemory(c, 'Got their first message from you, all the way from your phone.', t, { core: false });
  touch(c, t);
  return { ...r, topics, learned, knownWords: Object.keys(st.known) };
}
/** The word as you'd say it ("walk", or a food's name). */
export function wordLabel(idx, key) {
  if (key.startsWith('food:')) return idx.items?.get?.(key.slice(5))?.name ?? prefLabel(key, idx);
  return { food: 'food', music: 'music', walk: 'walk', sleep: 'sleep', play: 'play', love: 'love', hello: 'hello', work: 'work', sad: 'sad', happy: 'happy', weather: 'weather', bath: 'bath', car: 'car ride', tv: 'TV', friends: 'friends', name: 'their name' }[key] ?? key;
}
