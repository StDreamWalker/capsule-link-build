// Texting your buddy: tell them what you're doing. They can't answer in words, but they pick up on things
// (food, music, a walk, bedtime, your day…) and react with a cry, a little picture in a speech bubble, a
// mood. Hear a word often enough and it becomes one of theirs: from then on they "say" it back, their own
// way (a cry cut into syllables, like "Pika-pi!"), whenever it comes up.
//
//   chatReply(idx, save, c, text, t) → { say, pieces, mood, emote, bubble, topics, learned, note }
//   applied as an event ('chat') so the PC and phone stay the same: everything here is decided from the
//   text, the time and the creature (no Math.random).
import { displayName, addMemory, touch, speciesOf, todayKey } from './creature.js';
import { favorites } from './care.js';
import { allFoods } from './shop.js';
import { prefLabel } from './memory.js';
import { quirksOf } from './quirks.js';
import { friendsOf } from './bonds.js';
import { remember, cravingOf, setCraving, recall } from './dayMemory.js';
import { changeOptions, applyChange } from './transform.js';
import { applyCare } from './care.js';
import { weatherForm, setForm } from './forms.js';

export const LEARN_AFTER = 5; // times a word has to come up before it's theirs
const TOPICS = [
  ['food', /\b(eat|eating|ate|food|hungry|snack|snacks|dinner|lunch|breakfast|treat|treats|berry|berries|cook|cooking|yummy|delicious)\b/i, '🍓'],
  ['music', /\b(song|songs|music|listening|tune|playlist|sing|singing|album|concert)\b/i, '🎵'],
  ['walk', /\b(walk|walking|outside|go out|park|run|running|jog|hike|stroll)\b/i, '🚶'],
  ['sleep', /\b(sleep|sleepy|tired|bed|bedtime|nap|good ?night|night night)\b/i, '💤'],
  ['play', /\b(play|playing|game|games|ball|toy|toys|fun)\b/i, '🎾'],
  ['love', /\b(love you|love ya|good (boy|girl|job)|cute|cutie|best buddy|proud of you|adorable)\b/i, '💗'],
  ['hello', /^(hi|hey|hello|yo|hiya|good morning|morning|howdy)\b/i, '👋'],
  ['work', /\b(work|working|school|class|meeting|homework|study|studying|office|job|busy|exam|test)\b/i, '💼'],
  ['sad', /\b(sad|upset|bad day|stressed|lonely|crying|cry|miss you|awful|rough day)\b/i, '🫂'],
  ['happy', /\b(happy|great|awesome|yay|good news|excited|amazing|woohoo)\b/i, '🎉'],
  ['weather', /\b(rain|raining|sunny|snow|snowing|cold|hot|storm|windy|weather)\b/i, '🌦️'],
  ['bath', /\b(bath|wash|clean|shower|brush)\b/i, '🫧'],
  ['car', /\b(car|drive|driving|bus|train|ride)\b/i, '🚗'],
  ['tv', /\b(tv|movie|show|watching|video|youtube|stream)\b/i, '📺'],
  ['friends', /\b(friend|friends|party|hang out|visit)\b/i, '🧑‍🤝‍🧑'],
];
const hash = (s) => { let h = 2166136261; for (const ch of String(s)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0; return h; };
const roll = (seed, n) => hash(seed) % n;

/** A species name in syllables: "Pikachu" → ["Pi", "ka", "chu"], "Bulbasaur" → ["Bul", "ba", "saur"]. */
export function syllables(name) {
  const s = String(name || 'Mon').replace(/[^A-Za-zÀ-ÿ]/g, '').toLowerCase();
  if (!s) return ['Mon'];
  // letters into sounds: a few pairs count as one consonant
  const units = [];
  for (let i = 0; i < s.length; i++) {
    const two = s.slice(i, i + 2);
    if (/^(ch|sh|th|ph|wh|ck|qu|gh)$/.test(two)) { units.push(two); i++; } else units.push(s[i]);
  }
  const isV = (u) => /^[aeiouyàâäéèêëïîôöùûü]$/.test(u);
  const out = [];
  let cur = '', i = 0;
  while (i < units.length) {
    while (i < units.length && !isV(units[i])) cur += units[i++]; // onset
    while (i < units.length && isV(units[i])) cur += units[i++]; // vowels
    // consonants after: one goes to the next syllable; of two or more, the first stays here; at the end, all stay
    let j = i; while (j < units.length && !isV(units[j])) j++;
    const n = j - i;
    if (j >= units.length) { while (i < units.length) cur += units[i++]; }
    else if (n >= 2) cur += units[i++];
    out.push(cur); cur = '';
  }
  if (cur) out.push(cur);
  const syl = out.filter(Boolean).slice(0, 4);
  return syl.map((p, k) => (k === 0 ? p[0].toUpperCase() + p.slice(1) : p));
}
/**
 * How a creature says a word: syllables of its own name (text) and the matching pieces of its cry
 * ([[from, to, semitones, speed]] for creatureCry's chop), always the same for the same word.
 */
export function wordFor(name, key) {
  const syl = syllables(name);
  const h = hash(`${name}:${key}`);
  const n = 2 + (h % 2); // two or three syllables
  const first = syl.slice(0, Math.min(3, syl.length));
  // mostly the start of their name, like "Pika-pi" or "Bul-ba"
  const picks = Array.from({ length: n }, (_, i) => (i === 0 ? syl[0] : first[(h >>> (i * 3)) % first.length]));
  const text = picks.map((p, i) => (i === 0 ? p[0].toUpperCase() + p.slice(1) : p.toLowerCase())).reduce((a, p, i) => a + (i === 1 || (i === 2 && h & 8) ? '-' : '') + p, '');
  const pieces = picks.map((p, i) => {
    const at = syl.indexOf(p) / syl.length, len = 1 / syl.length;
    return [Math.max(0, at), Math.min(1, at + len + 0.08), (((h >>> (8 + i * 4)) % 7) - 3) + (i === n - 1 ? 1 : 0), 1.1];
  });
  return { text: `${text}!`, pieces };
}
/** Their "yes" and "no" (the same every time for them). */
export const yesFor = (name) => { const s = syllables(name); return { text: `${s[0]}-${s[0].toLowerCase()}!`, pieces: [[0, 0.3, 1, 1.2], [0, 0.35, 3, 1.15]] }; };
export const noFor = (name) => { const s = syllables(name); const last = s[s.length - 1]; return { text: `${last[0].toUpperCase()}${last.slice(1)}… ${last.toLowerCase()}.`, pieces: [[0.6, 1, -1, 0.9], [0.65, 1, -4, 0.85]] }; };

// How much of what you say they follow (0 … 1). Creatures from a game save who've been trained for many
// levels (and seen a whole region) already understand a fair bit; a freshly caught one hears mostly
// tone. It grows with friendship, words they've learned and every chat.
export function fluencyOf(idx, c) {
  if (!c) return 0;
  const lv = Math.max(1, Math.min(100, c.level ?? 1));
  const fromGame = ['pkhex', 'memory', 'save'].includes(c.origin?.from);
  const met = (c.memories ?? []).filter((m) => m.from === 'game').length;
  let f = fromGame ? 0.15 + 0.5 * Math.min(1, lv / 60) + Math.min(0.1, met * 0.02) : 0.25 * lv / 100;
  f += ((c.friendship ?? 0) / (idx?.ds?.rules?.maxFriendship ?? 255)) * 0.2;
  f += Math.min(0.2, Object.keys(c.chat?.known ?? {}).length * 0.02);
  f += Math.min(0.1, (c.chat?.n ?? 0) / 400);
  return Math.max(0, Math.min(1, f));
}
export const fluencyLabel = (f) => (f >= 0.8 ? 'Understands almost everything you say' : f >= 0.55 ? 'Follows most of what you say' : f >= 0.3 ? 'Picks up quite a few words' : f >= 0.12 ? 'Catches a few words and your tone' : 'Mostly hears your tone');
// how hard a topic is to follow: basic things anyone picks up; questions about themselves take more
const LEVEL = { name: 0, hello: 0, food: 0, love: 0, sleep: 0.05, play: 0.05, walk: 0.15, music: 0.2, bath: 0.2, happy: 0.2, sad: 0.25, weather: 0.3, work: 0.35, car: 0.3, tv: 0.35, friends: 0.35 };
const INTENTS = [
  ['howAreYou', /\b(how are (you|ya|u)|how('| a)?re (you|u)|how do you feel|how('s| is) it going|you ok(ay)?|are you (ok(ay)?|alright|good)|how you doing|feeling (ok|good|alright)\?)/i, 0.35],
  ['wantDo', /\b(what (do|would|should) (you|we) (want to |wanna |like to )?do|what('s| is) the plan|any plans|what shall we do|what to do today|how should we spend)\b/i, 0.35],
  ['wantWhat', /\b(what do you (want|need)|what would you like|anything you (want|need)|what('s| is) wrong|what are you craving)\b/i, 0.4],
  ['likeQ', /\b(do|would) you (like|love|enjoy|want)\b/i, 0.3],
  ['favQ', /\bfavou?rite\b/i, 0.45],
  ['friendQ', /\b(best friend|your friends?|who do you like|who('s| is) your (buddy|pal))\b/i, 0.45],
  ['rememberQ', /\b(remember|yesterday|earlier today|this morning)\b/i, 0.5],
  ['sorry', /\b(sorry|apologi[sz]e|my bad|forgive me)\b/i, 0.3],
  ['thanks', /\b(thank(s| you)|ty|thx)\b/i, 0.2],
  ['comeHere', /\b(come here|come on|c'?mon|over here|this way|let'?s go|follow me)\b/i, 0.15],
  ['scold', /\b(bad (boy|girl|pokemon|mon)|stop (it|that)|naughty|no!|quit it|knock it off)\b/i, 0.1],
  ['goodnight', /\b(good ?night|night night|sweet dreams|time for bed)\b/i, 0.1],
  ['morning', /\b(good morning|morning!|rise and shine|wake up)\b/i, 0.1],
  ['home', /\b(i'?m (home|back)|i('| a)m here|back home)\b/i, 0.15],
];
const POS = /\b(love|great|awesome|good|nice|happy|yay|fun|best|amazing|cute|wonderful|proud|excited|glad|cool|sweet|lovely)\b|[!]{2,}|:\)|❤|😊|😄/i;
const NEG = /\b(hate|bad|sad|awful|terrible|angry|mad|upset|tired|sick|hurt|worst|ugh|annoyed|lonely|bored)\b|:\(|😢|😭/i;
const NOT = /\b(not|don'?t|doesn'?t|didn'?t|no|never|isn'?t|aren'?t|won'?t|can'?t)\b/i;
const STOP = new Set('the a an and or but to of in on at for with you your i me my we our is are was were be been it its this that these those do does did have has had so very just really like what when where who how why can could would should will not dont im youre its there here they them their about from up out get got go going went some any all more much too then than if as by'.split(' '));
const WORDS_MAX = 40;

// Things you can ask them to do. Once they understand the words, they really do it: the R.A.N.C.H.,
// Quality time and the phone carry out the `act` a reply comes back with. lvl: how much they need to follow.
const COMMANDS = [
  ['nap', /\b(take a nap|go (to )?sleep|nap time|time (for a nap|to sleep)|go to bed|get some (rest|sleep)|lie down|rest now|sleep now)\b/i, 0.2],
  ['wake', /\b(wake up|wakey|rise and shine|get up|time to get up)\b/i, 0.1],
  ['come', /\b(come here|come on|c'?mon|over here|this way|let'?s go(?! (for|to|on|out|outside|swimming|fishing))|follow me|come back)\b/i, 0.15],
  ['play', /\b(let'?s play|wanna play\b(?!.*\?)|go play|play fetch|fetch!|catch!|play with (me|the ball))\b/i, 0.2],
  ['sit', /\b(sit( down)?|stay( there)?|wait there|hold still)\b/i, 0.25],
  ['jump', /\b(jump|hop)\b/i, 0.2],
  ['spin', /\b(spin|turn around|twirl)\b/i, 0.3],
  ['dance', /\b(dance|boogie|groove)\b/i, 0.25],
  ['move', /\b(go|walk|run|move|head|fly|swim) (to the |over to the )?(left|right|forward|forwards|back|backwards|away|up|down|that way)\b/i, 0.35],
  ['weather', /\b(make it|let it|start|summon|bring|call|shift (it )?to|change (the weather|it) to|turn (it|the weather) to|use|do a) ?(rain|snow|sun|sunny|sunshine|storm|thunder|hail|wind|windy|fog|foggy|mist|clear|rain dance|sunny day|snowscape|sandstorm)\b|\b(rain dance|sunny day|snowscape|stop the rain|clear (up )?the (sky|skies|weather))\b/i, 0.4],
  ['mega', /\b(mega evolve|mega evolution|go mega|primal)\b/i, 0.4],
  ['revert', /\b(change back|back to normal|turn back|usual form)\b/i, 0.4],
];
const WEATHER_WORD = (m) => (/rain/i.test(m) && !/stop the rain/i.test(m) ? 'rain' : /storm|thunder/i.test(m) ? 'storm' : /snow|hail|snowscape/i.test(m) ? 'snow' : /wind|sandstorm/i.test(m) ? 'windy' : /fog|mist/i.test(m) ? 'fog' : 'clear');
/** Which weather this creature could bring on (from its moves, abilities and kind): a Set of yard weathers. */
export function weatherPowers(idx, c) {
  const sp = speciesOf(idx, c);
  const moves = (c.moves ?? []).map((m) => { const mv = idx.moves.get(m.id); return `${mv?.showdownName ?? ''} ${mv?.name ?? ''}`; }).join(' | ').toLowerCase();
  const abil = [c.ability, ...(Array.isArray(sp?.abilities) ? sp.abilities : Object.values(sp?.abilities ?? {}))].filter(Boolean).join(' ').toLowerCase();
  const kind = `${sp?.showdownName ?? ''} ${sp?.name ?? ''} ${sp?.baseSpecies ?? ''}`.toLowerCase();
  const out = new Set();
  const types = (sp?.types ?? []).join(' ').toLowerCase();
  if (/rain dance/.test(moves) || /drizzle|primordial sea/.test(abil) || /castform|kyogre/.test(kind)) out.add('rain');
  if (/sunny day/.test(moves) || /drought|desolate land|orichalcum/.test(abil) || /castform|groudon|cherrim/.test(kind)) out.add('clear');
  if (/hail|snowscape|chilly reception/.test(moves) || /snow warning/.test(abil) || /castform/.test(kind)) out.add('snow');
  if (out.has('rain') && (/thunder/.test(moves) || /electric/.test(types))) out.add('storm');
  if (/tailwind|whirlwind|hurricane|sandstorm|gust/.test(moves) || /sand stream|wind rider|wind power/.test(abil) || /tornadus/.test(kind)) out.add('windy');
  if (/haze|mist\b|misty terrain/.test(moves)) out.add('fog');
  if (/defog|haze|clear smog|cloud nine|air lock/.test(moves + abil)) out.add('clear');
  return out;
}
const pick = (seed, arr) => arr[roll(seed, arr.length)];
// what they'd like to do (for "what do you want to do today?"): from what they like, their needs and quirks
function wishFor(idx, c, seed) {
  const p = c.prefs ?? {};
  const n = c.needs ?? {};
  if ((n.energy ?? 60) < 25) return { what: 'nap', e: '💤', text: 'curl up somewhere cosy for a nap' };
  if ((n.hygiene ?? 60) < 25) return { what: 'bath', e: '🫧', text: 'get cleaned up' };
  const options = [
    { what: 'walk', e: '🚶', text: 'go for a walk with you', w: 1 + (p['activity:walk'] ?? 0) },
    { what: 'play', e: '🎾', text: 'play with a ball', w: 1.2 + (p['activity:play'] ?? 0) + (quirksOf(idx, c).some((q) => q.id === 'restless') ? 2 : 0) },
    { what: 'nap', e: '🛏️', text: 'have a long lazy nap', w: 0.5 + (p['activity:nap'] ?? 0) + (quirksOf(idx, c).some((q) => q.id === 'napper' || q.id === 'couch-potato') ? 2 : 0) },
    { what: 'friends', e: '🧑‍🤝‍🧑', text: 'hang out with their friends', w: 0.8 + Object.values(c.bonds ?? {}).filter((v) => v >= 60).length * 0.6 },
    { what: 'explore', e: '🧭', text: 'explore somewhere new', w: 0.8 + (quirksOf(idx, c).some((q) => q.id === 'curious') ? 2 : 0) },
    { what: 'music', e: '🎵', text: 'listen to some music', w: 0.6 },
    ...['cooking', 'gardening', 'fishing', 'scavenging', 'obstacle', 'puzzle', 'training', 'photography'].map((a) => ({ what: a, e: { cooking: '🍳', gardening: '🌱', fishing: '🎣', scavenging: '⛏️', obstacle: '🏃', puzzle: '🧩', training: '💪', photography: '📸' }[a], text: { cooking: 'help you cook', gardening: 'help out on the berry farm', fishing: 'go fishing', scavenging: 'dig for treasure', obstacle: 'run the obstacle course', puzzle: 'do some puzzles', training: 'train', photography: 'pose for photos' }[a], w: 0.4 + Math.max(0, p[`activity:${a}`] ?? 0) * 0.8 })),
    { what: 'food', e: '🍽️', text: 'eat something tasty', w: (n.fullness ?? 60) < 45 ? 3 : 0.3 },
  ];
  const total = options.reduce((a, o) => a + Math.max(0.05, o.w), 0);
  let x = (hash(seed) % 10000) / 10000 * total;
  for (const o of options) { x -= Math.max(0.05, o.w); if (x <= 0) return o; }
  return options[0];
}

/** Who a message is for, out of those listening: the ones named in it, or everyone. */
export function chatTargets(idx, save, uids, text) {
  const msg = String(text ?? '');
  const named = uids.filter((u) => {
    const c = save.creatures?.[u];
    if (!c) return false;
    const names = [displayName(idx, c), speciesOf(idx, c)?.name, c.nickname].filter(Boolean);
    return names.some((n) => new RegExp(`\\b${String(n).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(msg));
  });
  return named.length ? named : uids;
}

/** What they make of a message (and what they learn from it). Changes c (their chat memory, joy). */
export function chatReply(idx, save, c, text, t = Date.now(), { group = false } = {}) {
  const msg = String(text ?? '').trim().slice(0, 400);
  const name = displayName(idx, c);
  const spName = speciesOf(idx, c)?.name ?? name;
  const st = (c.chat = c.chat || { heard: {}, known: {}, n: 0, lastJoyAt: 0, day: '', today: 0 });
  st.words = st.words || {};
  st.n++;
  const fl = fluencyOf(idx, c);
  const seed = `${c.uid}:${msg}:${Math.floor(t / 60000)}`;
  const question = /\?\s*$/.test(msg) || /^(do|does|did|are|is|will|would|can|could|should|want|wanna|how about|shall|what|who|how)\b/i.test(msg);
  const negated = NOT.test(msg);
  const tone = POS.test(msg) && !NEG.test(msg) ? 1 : NEG.test(msg) && !POS.test(msg) ? -1 : 0;
  const aboutMe = /\b(i|i'm|im|i am|my|me)\b/i.test(msg) && !/\b(you|your|ya|u)\b/i.test(msg);
  let topics = TOPICS.filter(([, re]) => re.test(msg)).map(([k]) => k);
  // foods by name ("an Oran Berry?")
  const foods = allFoods(idx).filter((f) => f.name && new RegExp(`\\b${String(f.name).replace(/\s*berry$/i, '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(msg));
  for (const f of foods.slice(0, 2)) topics.push(`food:${f.id}`);
  if (new RegExp(`\\b${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(msg)) topics.push('name');
  // understanding: words they know, things simple enough for them, or a lucky guess
  const gets = (k, lvl) => !!st.known[k] || fl >= lvl || roll(`${seed}:${k}`, 100) < 100 * Math.min(1, fl / Math.max(0.01, lvl)) * 0.5;
  const heardTopics = topics.slice();
  topics = topics.filter((k) => gets(k, k.startsWith('food:') ? 0.2 : LEVEL[k] ?? 0.3));
  const intent = INTENTS.find(([k, re, lvl]) => re.test(msg) && gets(`i:${k}`, lvl))?.[0] ?? null;
  // hearing words: often enough (sooner for those who already follow a lot), and it's one of theirs
  const need = Math.max(1, Math.ceil(LEARN_AFTER * (1 - fl)));
  let learned = null;
  for (const k of heardTopics) {
    st.heard[k] = (st.heard[k] ?? 0) + 1;
    if (!st.known[k] && st.heard[k] >= need && !learned) {
      st.known[k] = t; learned = k;
      if (!c.firsts?.chatWord) { c.firsts = { ...(c.firsts || {}), chatWord: t }; addMemory(c, `Worked out what “${wordLabel(idx, k)}” means, from all your messages.`, t); }
    }
  }
  // your own words: names, places, things you say a lot become words they recognise too
  const own = [...new Set((msg.toLowerCase().match(/[a-zà-ÿ']{3,}/g) ?? []).filter((w) => !STOP.has(w) && !TOPICS.some(([, re]) => re.test(w)) && !squashName(name).includes(w)))].slice(0, 6);
  let ownKnown = null;
  for (const w of own) {
    const e = (st.words[w] = st.words[w] || { n: 0 });
    e.n++; e.t = t;
    if (!e.known && e.n >= need * 2) { e.known = t; if (!learned) learned = `w:${w}`; }
    else if (e.known && !ownKnown) ownKnown = w;
  }
  const wk = Object.keys(st.words);
  if (wk.length > WORDS_MAX) { wk.sort((a, b) => (st.words[a].known ? 1e15 : 0) + st.words[a].t - ((st.words[b].known ? 1e15 : 0) + st.words[b].t)); for (const w of wk.slice(0, wk.length - WORDS_MAX)) delete st.words[w]; }

  const mood = c.needs ? (c.needs.energy < 25 ? 'sleepy' : c.needs.fullness < 30 ? 'hungry' : (c.upsetUntil ?? 0) > t ? 'upset' : c.needs.hygiene < 25 ? 'grubby' : c.needs.joy > 70 ? 'happy' : c.needs.joy < 30 ? 'bored' : 'content') : 'content';
  const fav = favorites(idx, c);
  const lazy = quirksOf(idx, c).some((q) => q.id === 'napper' || q.id === 'couch-potato');
  const itemName = (id) => idx.items?.get?.(id)?.name ?? allFoods(idx).find((f) => f.id === id)?.name ?? 'snack';
  const craving = cravingOf(idx, c, t);
  let r = { emote: '?', bubble: null, mood: 'curious', say: null, pieces: null, note: '' };
  const yes = (extra = {}) => ({ ...yesFor(spName), mood: 'happy', emote: 'hearts', ...extra });
  const no = (extra = {}) => ({ ...noFor(spName), mood: 'meh', emote: 'sweat', ...extra });
  const has = (k) => topics.includes(k);
  const known = topics.find((k) => st.known[k] && k !== 'name');
  const likesFood = (id) => (c.prefs?.[`food:${id}`] ?? 0);
  const wantFood = (asked) => (asked && likesFood(asked) < -1 ? null : asked ?? craving ?? (() => {
    const likes = Object.entries(c.prefs ?? {}).filter(([k, v]) => k.startsWith('food:') && v > 1).sort((a, b) => b[1] - a[1]).map(([k]) => k.slice(5));
    return c.firsts?.[`fav:${fav.berry}`] ? fav.berry : likes[roll(seed, Math.max(1, likes.length))] ?? fav.berry;
  })());
  const needLine = () => {
    if (mood === 'hungry') { const w = wantFood(null); if (w) setCraving(c, w, t); return { bubble: w ? { kind: 'item', id: w } : { kind: 'emoji', e: '🍽️' }, mood: 'hungry', emote: 'sweat', note: `${name} is hungry${w ? ` and has ${itemName(w)} on their mind` : ''}.` }; }
    if (mood === 'sleepy') return { bubble: { kind: 'emoji', e: '💤' }, mood: 'sleepy', emote: 'zzz', note: `${name} is worn out and could use a nap.` };
    if (mood === 'upset') return { bubble: { kind: 'emoji', e: '😤' }, mood: 'meh', emote: 'sweat', note: `${name} is still a bit cross about ${c.upsetReason ?? 'earlier'}.` };
    if (mood === 'grubby') return { bubble: { kind: 'emoji', e: '🫧' }, mood: 'meh', emote: 'sweat', note: `${name} feels grubby and wants a wash.` };
    if (mood === 'bored') return { bubble: { kind: 'emoji', e: '🎾' }, mood: 'meh', emote: 'note', note: `${name} is bored and wants to play.` };
    if (craving && !c.today?.craving?.satisfied && roll(`${seed}:crave`, 3) === 0) return { bubble: { kind: 'item', id: craving }, mood: 'happy', emote: 'note', note: `${name} is doing well, but is craving ${itemName(craving)} today.` };
    const w = wishFor(idx, c, `${c.uid}:wish:${todayKey(t)}`);
    return { ...yesFor(spName), bubble: { kind: 'emoji', e: roll(seed, 2) ? '😊' : w.e }, mood: 'happy', emote: 'hearts', note: pick(seed, [`${name} is feeling great.`, `${name} is in a good mood${w.what !== 'food' ? ` and would like to ${w.text}` : ''}.`, `${name} is happy and full of beans.`, `${name} feels good today.`]) };
  };

  const tired = (c.needs?.energy ?? 60) < 20;
  const sulky = (c.upsetUntil ?? 0) > t && fl < 0.6;
  function doCommand(k) {
    const okRun = { ...yesFor(spName), mood: 'happy' };
    if (sulky && k !== 'wake' && k !== 'nap') return { ...noFor(spName), mood: 'meh', emote: 'sweat', bubble: { kind: 'emoji', e: '😤' }, note: pick(seed, [`${name} is still cross and ignores you.`, `${name} turns away. Not in the mood.`]) };
    switch (k) {
      case 'nap':
        if ((c.needs?.energy ?? 60) > 85 && new Date(t).getHours() >= 7 && new Date(t).getHours() < 20) return { ...noFor(spName), mood: 'meh', emote: 'sweat', bubble: { kind: 'emoji', e: '⚡' }, note: pick(seed, [`${name} isn't sleepy at all!`, `${name} has far too much energy for a nap.`]) };
        return { ...okRun, emote: 'zzz', bubble: { kind: 'emoji', e: '💤' }, mood: 'sleepy', note: pick(seed, [`${name} yawns and settles down for a nap.`, `${name} curls up and closes their eyes.`]), act: { kind: 'nap' } };
      case 'wake':
        return asleep ? { ...okRun, emote: 'exclaim', bubble: { kind: 'emoji', e: '☀️' }, note: pick(seed, [`${name} blinks awake.`, `${name} stretches and wakes up.`]), act: { kind: 'wake' } } : { emote: 'note', bubble: { kind: 'emoji', e: '👀' }, mood: 'content', note: `${name} is already wide awake.` };
      case 'come':
        if (tired) return { ...noFor(spName), mood: 'sleepy', emote: 'zzz', bubble: { kind: 'emoji', e: '💤' }, note: `${name} is too worn out to come over.` };
        return { ...okRun, emote: 'exclaim', bubble: { kind: 'emoji', e: '❗' }, note: pick(seed, [`${name} comes running.`, `${name} trots over to you.`, `${name} hurries over.`]), act: { kind: 'come' }, come: true };
      case 'play':
        if (tired) return { ...noFor(spName), mood: 'sleepy', emote: 'zzz', bubble: { kind: 'emoji', e: '💤' }, note: `${name} is too tired to play right now.` };
        return { ...okRun, emote: 'exclaim', bubble: { kind: 'emoji', e: '🎾' }, note: pick(seed, [`${name} bounces around, ready to play!`, `${name} wiggles and waits for the ball.`]), act: { kind: 'play' } };
      case 'sit': return { ...okRun, emote: 'note', bubble: { kind: 'emoji', e: '🪑' }, mood: 'content', note: pick(seed, [`${name} sits down and waits.`, `${name} stays put, watching you.`]), act: { kind: 'sit' } };
      case 'jump': return tired ? { ...noFor(spName), mood: 'sleepy', emote: 'zzz', note: `${name} is too tired to jump.` } : { ...okRun, emote: 'exclaim', bubble: { kind: 'emoji', e: '⤴️' }, note: `${name} jumps up!`, act: { kind: 'jump' } };
      case 'spin': return { ...okRun, emote: 'note', bubble: { kind: 'emoji', e: '🌀' }, note: `${name} spins round and round.`, act: { kind: 'spin' } };
      case 'dance': return { ...okRun, emote: 'note', bubble: { kind: 'emoji', e: '🎶' }, note: pick(seed, [`${name} busts out a little dance.`, `${name} sways and hops to a beat only they can hear.`]), act: { kind: 'dance' } };
      case 'move': {
        const d = (/left/i.test(msg) ? 'left' : /right/i.test(msg) ? 'right' : /forward|up|away|that way/i.test(msg) ? 'away' : 'near');
        if (tired) return { ...noFor(spName), mood: 'sleepy', emote: 'zzz', note: `${name} is too tired to go anywhere.` };
        return { ...okRun, emote: 'note', bubble: { kind: 'emoji', e: { left: '⬅️', right: '➡️', away: '⬆️', near: '⬇️' }[d] }, note: `${name} heads ${d === 'away' ? 'off ahead' : d === 'near' ? 'back towards you' : `to the ${d}`}.`, act: { kind: 'move', dir: d } };
      }
      case 'weather': {
        const want = WEATHER_WORD(msg);
        const can = weatherPowers(idx, c);
        if (!can.has(want)) return { ...noFor(spName), mood: 'meh', emote: 'sweat', bubble: { kind: 'emoji', e: '🤷' }, note: can.size ? `${name} can't make it ${want === 'clear' ? 'sunny' : want}, but could manage ${[...can].map((w) => (w === 'clear' ? 'sunshine' : w)).join(' or ')}.` : `${name} doesn't know how to change the weather.` };
        return { ...okRun, emote: 'exclaim', bubble: { kind: 'emoji', e: { rain: '🌧️', storm: '⛈️', snow: '❄️', windy: '🌬️', fog: '🌫️', clear: '☀️' }[want] }, note: `${name} ${pick(seed, ['concentrates hard…', 'calls to the sky…', 'raises their head to the clouds…'])} ${{ rain: 'and the rain starts to fall!', storm: 'and a storm rolls in!', snow: 'and snow begins to drift down!', windy: 'and the wind picks up!', fog: 'and a mist rolls in.', clear: 'and the sun comes out!' }[want]}`, act: { kind: 'weather', weather: want } };
      }
      case 'mega': case 'revert': {
        const opts = changeOptions(idx, save, c);
        const o = k === 'mega' ? opts.find((x) => x.kind === 'mega') : opts.find((x) => /usual/.test(x.label));
        if (!o) return { ...noFor(spName), mood: 'curious', emote: '?', bubble: { kind: 'emoji', e: '🤷' }, note: k === 'mega' ? `${name} can't Mega Evolve.` : `${name} is already in their usual form.` };
        if (!o.ok) return { ...noFor(spName), mood: 'meh', emote: 'sweat', bubble: { kind: 'emoji', e: '💎' }, note: `${name} would, but: ${o.why}` };
        return { ...okRun, emote: 'exclaim', bubble: { kind: 'emoji', e: k === 'mega' ? '💎' : '🔄' }, note: k === 'mega' ? `${name} glows with power!` : `${name} changes back.`, act: { kind: 'change', key: o.key } };
      }
      default: return { emote: '?', mood: 'curious', note: `${name} tilts their head.` };
    }
  }
  const heardIntent = INTENTS.some(([, re]) => re.test(msg));
  // asking them to do something: if they follow, they do it (the app carries out r.act)
  const cmd = COMMANDS.find(([, re]) => re.test(msg));
  const getsCmd = cmd && (gets(`c:${cmd[0]}`, cmd[2]) || (cmd[0] === 'wake'));
  const asleep = !!(c.sleep && (c.sleep.until ?? 0) > t);
  if (asleep && !(cmd?.[0] === 'wake')) {
    r = { emote: 'zzz', bubble: { kind: 'emoji', e: '💤' }, mood: 'sleepy', note: pick(seed, [`${name} is fast asleep.`, `${name} mumbles something in their sleep.`, `${name} snores softly.`]) };
  } else if (cmd && getsCmd) {
    r = doCommand(cmd[0]);
  } else if (cmd && !topics.length && !intent) {
    r = { emote: '?', bubble: { kind: 'emoji', e: '❓' }, mood: 'curious', note: pick(seed, [`${name} can tell you want something, but not what.`, `${name} watches you, trying to work out what you mean.`, `${name} tilts their head. Not sure what you're asking yet.`]) };
  } else if (!topics.length && !intent && (heardTopics.length || heardIntent)) {
    // they heard something, but it went over their head: they go by your tone
    r = tone > 0 ? { emote: 'note', bubble: { kind: 'emoji', e: '😊' }, mood: 'happy', note: `${name} doesn't quite follow, but likes your cheerful tone.` }
      : tone < 0 ? { emote: 'sweat', bubble: { kind: 'emoji', e: '🥺' }, mood: 'worried', note: `${name} can tell something's wrong, even if not what.` }
      : { emote: '?', bubble: { kind: 'emoji', e: '❓' }, mood: 'curious', note: `${name} tilts their head, trying to follow.` };
  } else if (intent === 'wantDo' || (intent === 'wantWhat' && !/crav|eat|hungry|food|snack/i.test(msg) && mood !== 'hungry')) {
    const w = wishFor(idx, c, `${c.uid}:wish:${todayKey(t)}`);
    if (w.what === 'food') r = needLine();
    else r = { ...yesFor(spName), bubble: { kind: 'emoji', e: w.e }, mood: 'happy', emote: 'note', note: pick(seed, [`${name} would love to ${w.text}.`, `${name} is hoping to ${w.text} today.`, `${name} looks at you hopefully: ${w.text}?`]), wish: w.what };
  } else if (intent === 'howAreYou' || intent === 'wantWhat') {
    r = needLine();
  } else if (intent === 'sorry') {
    if ((c.upsetUntil ?? 0) > t) {
      const forgive = fl >= 0.3 || roll(seed, 3) === 0;
      if (forgive) { c.upsetUntil = Math.min(c.upsetUntil, t + 30000); r = { ...yesFor(spName), bubble: { kind: 'emoji', e: '💗' }, mood: 'happy', emote: 'hearts', note: `${name} forgives you.` }; }
      else r = { bubble: { kind: 'emoji', e: '😤' }, mood: 'meh', emote: 'sweat', note: `${name} isn't ready to forgive you just yet.` };
    } else r = { bubble: { kind: 'emoji', e: '❔' }, mood: 'curious', emote: '?', note: `${name} doesn't know what you're sorry for.` };
  } else if (intent === 'thanks') {
    r = { ...yesFor(spName), bubble: { kind: 'emoji', e: '✨' }, mood: 'happy', emote: 'hearts', note: `${name} puffs up proudly.` };
  } else if (intent === 'scold') {
    r = { bubble: { kind: 'emoji', e: '😢' }, mood: 'worried', emote: 'sweat', note: `${name} droops a little.` };
  } else if (intent === 'friendQ') {
    const best = friendsOf(c)[0];
    const pal = best && save?.creatures?.[best.uid];
    const guest = Object.values(c.guestBonds ?? {}).sort((a, b) => b.bond - a.bond)[0];
    r = pal ? { ...yesFor(spName), bubble: { kind: 'creature', uid: pal.uid, speciesId: pal.formId ?? pal.speciesId }, mood: 'happy', emote: 'hearts', note: `${name} thinks of ${displayName(idx, pal)}.` }
      : guest?.bond >= 30 ? { bubble: { kind: 'creature', speciesId: guest.species }, mood: 'happy', emote: 'note', note: `${name} thinks of ${guest.name} from ${guest.trainer}'s ranch.` }
      : { bubble: { kind: 'emoji', e: '🫂' }, mood: 'content', emote: 'note', note: `${name} looks at you. You're their best friend.` };
  } else if (intent === 'rememberQ') {
    const m = recall(idx, save, c, t);
    r = m ? { bubble: m.kind === 'craving' ? { kind: 'item', id: m.key } : m.kind === 'played' && save?.creatures?.[m.key] ? { kind: 'creature', uid: m.key, speciesId: save.creatures[m.key].formId ?? save.creatures[m.key].speciesId } : { kind: 'emoji', e: m.kind === 'upset' ? '😤' : '💭' }, mood: 'content', emote: 'note', note: `${name} ${m.text}.` }
      : { bubble: { kind: 'emoji', e: '💭' }, mood: 'curious', emote: '?', note: `${name} thinks hard, but nothing comes to mind.` };
  } else if (intent === 'favQ' && (has('food') || foods.length || !topics.length)) {
    const best = Object.entries(c.prefs ?? {}).filter(([k, v]) => k.startsWith('food:') && v >= 2).sort((a, b) => b[1] - a[1])[0];
    r = best ? { ...yesFor(spName), bubble: { kind: 'item', id: best[0].slice(5) }, mood: 'happy', emote: 'hearts', note: `${name} lights up thinking about ${itemName(best[0].slice(5))}.` }
      : { bubble: { kind: 'emoji', e: '🤔' }, mood: 'curious', emote: '?', note: `${name} hasn't found a favourite yet. Keep trying new things!` };
  } else if (intent === 'goodnight') {
    r = { emote: 'zzz', bubble: { kind: 'emoji', e: '🌙' }, mood: 'sleepy', note: mood === 'sleepy' ? `${name} is already half asleep.` : `${name} snuggles down for the night.` };
  } else if (intent === 'morning') {
    r = { ...yesFor(spName), emote: 'exclaim', bubble: { kind: 'emoji', e: '☀️' }, mood: 'happy', note: mood === 'sleepy' ? `${name} blinks awake, still drowsy.` : `${name} stretches and greets the day.` };
  } else if (intent === 'home') {
    r = { ...yesFor(spName), emote: 'exclaim', bubble: { kind: 'emoji', e: '🏠' }, mood: 'happy', note: `${name} rushes over, happy you're back!` };
  } else if (intent === 'comeHere') {
    r = mood === 'sleepy' || (mood === 'upset' && fl < 0.5) ? no({ bubble: { kind: 'emoji', e: mood === 'sleepy' ? '💤' : '😤' }, note: `${name} stays put.` })
      : { ...yesFor(spName), emote: 'exclaim', bubble: { kind: 'emoji', e: '❗' }, mood: 'happy', note: `${name} comes running.`, come: true };
  } else if (has('food') || topics.some((k) => k.startsWith('food:'))) {
    const asked = topics.find((k) => k.startsWith('food:'))?.slice(5);
    if (!asked && aboutMe && !question) {
      r = negated ? { emote: 'note', bubble: { kind: 'emoji', e: '🥺' }, mood: 'curious', note: `${name} hopes there's still a snack for them.` }
        : { emote: 'note', bubble: { kind: 'item', id: wantFood(null) ?? fav.berry }, mood: 'happy', note: `${name} gets hungry just hearing about it.` };
    } else if (asked && aboutMe) {
      r = { emote: 'note', bubble: { kind: 'item', id: asked }, mood: 'happy', note: likesFood(asked) >= 2 ? `${name} is jealous: they love ${itemName(asked)}!` : `${name} sniffs the air, hoping for some.` };
    } else if (asked && (intent === 'likeQ' || question)) {
      const v = likesFood(asked);
      r = v <= -2 ? no({ bubble: { kind: 'item', id: asked }, note: `${name} makes a face. Not a fan of ${itemName(asked)}.` })
        : v >= 2 || asked === craving ? yes({ bubble: { kind: 'item', id: asked }, note: asked === craving ? `${name} has been craving ${itemName(asked)} all day!` : `${name} loves ${itemName(asked)}.` })
        : { ...yesFor(spName), bubble: { kind: 'item', id: asked }, mood: 'curious', emote: 'note', note: `${name} would happily try ${itemName(asked)}.` };
      if (v > -2) setCraving(c, asked, t);
    } else if (question || mood === 'hungry') {
      const want = wantFood(asked);
      if (want && !(negated && !question)) setCraving(c, want, t);
      const again = want && c.today?.craving?.id === want && (c.today.notes ?? []).some((n) => n.kind === 'craving' && n.key === want && n.t < t - 60000);
      r = want ? yes({ bubble: { kind: 'item', id: want }, emote: 'hearts', note: again ? `${name} still wants that ${itemName(want)}.` : `${name} would love a ${itemName(want)}.` }) : no({ bubble: { kind: 'emoji', e: '🙅' }, note: `${name} isn't keen on that one.` });
    } else if (negated) r = { emote: 'sweat', bubble: { kind: 'emoji', e: '🥺' }, mood: 'meh', note: `${name} looks disappointed. No snacks?` };
    else r = { emote: 'note', bubble: { kind: 'item', id: wantFood(asked) ?? fav.berry }, mood: 'happy', note: `${name} licks their lips.` };
  } else if (has('music')) {
    // what they think of a song: the same song gets the same opinion (whatever words you describe it with)
    const songKey = msg.toLowerCase().replace(/\b(do|you|like|this|that|the|song|songs|music|tune|one|it|is|what|about|how|think|of)\b/g, '').replace(/[^a-z0-9]+/g, '') || `now:${Math.floor(t / 900000)}`;
    const lean = /jolly|naive|hasty|cheery|eager|rowdy|playful/i.test(c.temper ?? '') ? 7 : /calm|shy|gentle|quiet/i.test(c.temper ?? '') ? 5 : 6;
    const likesMusic = (hash(`${c.uid}:song:${songKey}`) % 10) < lean;
    r = question ? (likesMusic ? yes({ bubble: { kind: 'emoji', e: '🎵' }, emote: 'note', note: pick(seed, [`${name} bobs along to it.`, `${name} loves this one!`, `${name} hums along, totally into it.`]) }) : no({ bubble: { kind: 'emoji', e: '🙉' }, note: pick(seed, [`${name} isn't feeling this one.`, `${name} covers their ears a little.`, `${name} would rather something else.`]) }))
      : { emote: 'note', bubble: { kind: 'emoji', e: '🎵' }, mood: 'happy', note: pick(seed, [`${name} sways a little.`, `${name} taps along.`]) };
    if (likesMusic) r.act = { kind: 'dance' };
  } else if (has('walk')) {
    if (aboutMe && !question) r = { emote: 'note', bubble: { kind: 'emoji', e: '🚶' }, mood: 'curious', note: (c.prefs?.['activity:walk'] ?? 0) >= 2 ? `${name} wishes they could come too.` : `${name} watches you go.` };
    else r = negated && !question ? { emote: 'sweat', bubble: { kind: 'emoji', e: '😞' }, mood: 'meh', note: `${name} sighs. Maybe later.` }
      : (c.needs?.energy ?? 60) < 30 || lazy && roll(seed, 3) === 0 ? no({ bubble: { kind: 'emoji', e: '💤' }, note: `${name} would rather rest.` }) : yes({ bubble: { kind: 'emoji', e: '🚶' }, emote: 'exclaim', note: `${name} is ready to go!` });
  } else if (has('sleep')) {
    r = aboutMe && !question ? { emote: 'zzz', bubble: { kind: 'emoji', e: '💤' }, mood: 'sleepy', note: `${name} yawns with you.` }
      : { emote: 'zzz', bubble: { kind: 'emoji', e: '💤' }, mood: 'sleepy', note: mood === 'sleepy' ? `${name} yawns. Same.` : negated ? `${name} perks up: not sleepy at all!` : `${name} curls up next to you.`, ...(question ? (mood === 'sleepy' ? yesFor(spName) : noFor(spName)) : {}) };
  } else if (has('love')) {
    r = { ...yesFor(spName), emote: 'hearts', bubble: { kind: 'emoji', e: '💗' }, mood: 'happy', note: (c.friendship ?? 0) >= 200 ? `${name} glows and nuzzles you.` : `${name} glows.` };
  } else if (has('sad')) {
    r = aboutMe || !question ? { emote: 'hearts', bubble: { kind: 'emoji', e: '🫂' }, mood: 'worried', note: `${name} snuggles up to cheer you up.` } : needLine();
  } else if (has('happy')) {
    r = { ...yesFor(spName), emote: 'exclaim', bubble: { kind: 'emoji', e: '🎉' }, mood: 'happy', note: `${name} celebrates with you!` };
  } else if (has('work')) {
    r = { emote: 'sweat', bubble: { kind: 'emoji', e: '💼' }, mood: 'content', note: fl >= 0.5 ? `${name} wishes you luck and waits for you.` : `${name} waits patiently for you.` };
  } else if (has('play')) {
    r = (c.needs?.energy ?? 60) < 20 ? no({ bubble: { kind: 'emoji', e: '💤' }, note: `${name} is too tired to play.` })
      : negated && !question ? { emote: 'sweat', bubble: { kind: 'emoji', e: '😞' }, mood: 'meh', note: `${name} droops. No playtime?` }
      : yes({ bubble: { kind: 'emoji', e: '🎾' }, emote: 'exclaim', note: `${name} wiggles, ready to play.` });
  } else if (has('friends')) {
    const best = friendsOf(c)[0];
    const pal = best && save?.creatures?.[best.uid];
    r = pal ? { bubble: { kind: 'creature', uid: pal.uid, speciesId: pal.formId ?? pal.speciesId }, mood: 'happy', emote: 'note', note: `${name} thinks of ${displayName(idx, pal)}.` } : { emote: 'note', bubble: { kind: 'emoji', e: '🧑‍🤝‍🧑' }, mood: 'curious', note: `${name} listens closely.` };
  } else if (has('hello')) {
    r = { ...yesFor(spName), emote: 'exclaim', bubble: { kind: 'emoji', e: '👋' }, mood: 'happy', note: group ? pick(seed, [`${name} looks up.`, `${name} waves back.`]) : pick(seed, [`${name} perks up.`, `${name} greets you happily.`, `${name} hops over to say hi.`]) };
  } else if (intent === 'likeQ') {
    r = tone >= 0 ? yes({ emote: 'note', note: `${name} nods along.` }) : no();
  } else if (topics.length && topics[0] !== 'name') {
    const tp = TOPICS.find(([k]) => k === topics[0]);
    r = { emote: 'note', bubble: tp ? { kind: 'emoji', e: tp[2] } : null, mood: 'curious', note: `${name} listens closely.`, ...(question ? (roll(seed, 2) ? yesFor(spName) : noFor(spName)) : {}) };
  } else if (has('name')) {
    r = { ...yesFor(spName), emote: 'exclaim', bubble: { kind: 'emoji', e: '❗' }, mood: 'happy', note: `${name} looks right at you.` };
  } else if (ownKnown) {
    r = { emote: 'exclaim', bubble: { kind: 'emoji', e: '💡' }, mood: 'happy', note: `${name} recognises “${ownKnown}”.` };
  } else if (question) {
    r = tone < 0 ? no({ note: `${name} shakes their head.` }) : roll(seed, 3) ? yes({ emote: 'note', note: `${name} nods eagerly.` }) : no({ note: `${name} shakes their head.` });
  } else {
    r = tone > 0 ? { emote: 'note', bubble: { kind: 'emoji', e: '😊' }, mood: 'happy', note: `${name} likes the sound of that.` }
      : tone < 0 ? { emote: 'sweat', bubble: { kind: 'emoji', e: '🥺' }, mood: 'worried', note: `${name} looks at you, concerned.` }
      : { emote: '?', bubble: { kind: 'emoji', e: '❓' }, mood: 'curious', note: `${name} tilts their head.` };
  }
  // their yes / no as something they say
  if (r.text && !r.say) { r.say = r.text; }
  delete r.text;
  // a word they know: they say it, their own way
  if (known || learned) {
    const k = learned ?? known;
    const w = wordFor(spName, k);
    r.say = w.text; r.pieces = w.pieces;
  }
  // today's short-term memory: what you talked about
  for (const k of topics) remember(c, 'chat', k, 1, t);
  if (intent) remember(c, 'chat', `i:${intent}`, 0.5, t);
  // a little joy from being talked to (not too often), and closer for the first few chats each day
  const day = new Date(t).toDateString();
  if (st.day !== day) { st.day = day; st.today = 0; }
  st.today++;
  if (c.needs && t - (st.lastJoyAt ?? 0) > 60000) { c.needs.joy = Math.min(100, c.needs.joy + (r.mood === 'happy' ? 4 : 2)); st.lastJoyAt = t; }
  if (st.today <= 3) c.friendship = Math.min(idx.ds?.rules?.maxFriendship ?? 255, (c.friendship ?? 0) + 1);
  if (st.n === 1) addMemory(c, 'Got their first message from you.', t, { core: false });
  touch(c, t);
  return { ...r, topics, intent, learned, fluency: fl, knownWords: Object.keys(st.known) };
}
const squashName = (n) => String(n).toLowerCase();
/** The word as you'd say it ("walk", or a food's name). */
export function wordLabel(idx, key) {
  if (key.startsWith('w:')) return key.slice(2);
  if (key.startsWith('food:')) return idx.items?.get?.(key.slice(5))?.name ?? prefLabel(key, idx);
  return { food: 'food', music: 'music', walk: 'walk', sleep: 'sleep', play: 'play', love: 'love', hello: 'hello', work: 'work', sad: 'sad', happy: 'happy', weather: 'weather', bath: 'bath', car: 'car ride', tv: 'TV', friends: 'friends', name: 'their name' }[key] ?? key;
}

/** Weather a creature has called up in the yard (lasts a while), or null. save.weatherCall = { kind, until, uid, name }. */
export const WEATHER_CALL_MINUTES = 20;
export function calledWeather(save, t = Date.now()) {
  const w = save?.weatherCall;
  return w && w.until > t ? w : null;
}
/** The yard weather setting to use: what a creature called up, else your setting. */
export function yardWeatherSetting(save, t = Date.now()) {
  return calledWeather(save, t)?.kind ?? save?.settings?.ranchWeather ?? 'real';
}

/**
 * Talk to them and let them do what you asked: chatReply, then the parts that change the save (a nap,
 * waking up, the weather, a form change). Moving about (come, sit, jump, dance…) is up to the screen,
 * from out.act. Returns the reply, with out.done = what happened ({ ok, reason }).
 */
export function talkTo(idx, save, c, text, t = Date.now(), opts = {}) {
  const out = chatReply(idx, save, c, text, t, opts);
  const a = out.act;
  if (!a) return out;
  if (a.kind === 'nap' || a.kind === 'wake') {
    const r = applyCare(idx, c, a.kind === 'nap' ? 'rest' : 'wake', { at: t, inventory: save.inventory, asked: true });
    out.done = { ok: r.ok !== false && r.reaction !== 'awake', reason: r.reason };
    if (a.kind === 'nap' && r.reaction === 'awake') { out.note = `${displayName(idx, c)} lies down, but isn't sleepy enough to drop off.`; delete out.act; }
    else if (r.ok === false && r.reason) out.note = `${displayName(idx, c)} ${a.kind === 'nap' ? "can't settle down right now" : "won't budge"}. (${r.reason})`;
  } else if (a.kind === 'weather') {
    save.weatherCall = { kind: a.weather, until: t + WEATHER_CALL_MINUTES * 60000, uid: c.uid, name: displayName(idx, c) };
    // Castform and the like change with it
    const f = weatherForm(idx, c, { weather: a.weather === 'clear' ? 'sun' : a.weather });
    if (f) setForm(idx, c, f);
    c.firsts = c.firsts || {};
    if (!c.firsts.weatherCall) { c.firsts.weatherCall = t; addMemory(c, `Changed the weather for you for the first time: ${a.weather === 'clear' ? 'sunshine' : a.weather}.`, t, { core: true }); }
    out.done = { ok: true };
  } else if (a.kind === 'change') {
    const r = applyChange(idx, save, c.uid, a.key, t);
    out.done = { ok: r.ok, reason: r.reason };
    if (!r.ok) out.note = `${displayName(idx, c)} tried, but: ${r.reason}`;
  }
  touch(c, t);
  return out;
}
