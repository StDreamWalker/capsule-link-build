// The R.A.N.C.H. task list: things your creatures have said they want (a particular berry, to go somewhere,
// to do something), written down on a page you can open from the R.A.N.C.H. Each one waits for a while
// (a day to a week and a bit); when you've done it, tick it off and the one who asked is happier and closer
// to you, and you get a few items for your trouble. Or turn it down. Creatures from a known game sometimes ask
// to go somewhere from that game ("Pikachu wants to go back to Viridian Forest").
//   save.tasks = [{ id, uid, kind, text, key, icon, made, due, place?, game? }]
import { displayName, addMemory, touch } from './creature.js';
import { cravingOf } from './dayMemory.js';
import { allFoods, itemInfo } from './shop.js';
import { INVITES, tasteFor, whimFor } from './invite.js';
import { rareFinds } from './finds.js';

export const TASKS_MAX = 14;
const DAY = 86400000;
const hash = (s) => { let h = 2166136261; for (const ch of String(s)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0; return h >>> 0; };

// places in each game's region, for creatures that came from it
export const GAME_PLACES = [
  [/red|blue|yellow|firered|leafgreen|let.?s go|\bfrlg\b|\brby\b|kanto/i, 'Kanto', ['Pallet Town', 'Viridian Forest', 'Mt. Moon', 'Cerulean City', 'Rock Tunnel', 'Lavender Town', 'Celadon City', 'the Safari Zone', 'the Seafoam Islands', 'Cinnabar Island', 'the Power Plant', 'Cerulean Cave']],
  [/gold|silver|crystal|heartgold|soulsilver|hgss|johto|crystal clear/i, 'Johto', ['New Bark Town', 'Sprout Tower', 'Ilex Forest', 'the National Park', 'Ecruteak City', 'the Lake of Rage', 'the Ice Path', 'the Whirl Islands', 'the Ruins of Alph', 'the Bell Tower', 'Mt. Silver', 'Union Cave']],
  [/ruby|sapphire|emerald|omega|alpha|oras|hoenn|seaglass|rowe/i, 'Hoenn', ['Littleroot Town', 'Petalburg Woods', 'Granite Cave', 'Mt. Chimney', 'Meteor Falls', 'Fortree City', 'Lilycove City', 'Sootopolis City', 'Sky Pillar', 'Shoal Cave', 'the Safari Zone', 'Mirage Island']],
  [/diamond|pearl|platinum|brilliant|shining|bdsp|sinnoh/i, 'Sinnoh', ['Twinleaf Town', 'Eterna Forest', 'Mt. Coronet', 'Lake Verity', 'the Great Marsh', 'Snowpoint City', 'Iron Island', 'Spear Pillar', 'Valley Windworks', 'Fuego Ironworks', 'Stark Mountain', 'the Grand Underground']],
  [/black|white|\bbw2?\b|unova/i, 'Unova', ['Nuvema Town', 'Pinwheel Forest', 'Castelia City', 'Nimbasa City', 'Chargestone Cave', 'Dragonspiral Tower', 'Twist Mountain', 'the Giant Chasm', 'Abundant Shrine', 'the Relic Castle']],
  [/\bx\b|\by\b|\bxy\b|kalos/i, 'Kalos', ['Vaniville Town', 'Santalune Forest', 'Lumiose City', 'Parfum Palace', 'Glittering Cave', 'Reflection Cave', 'Frost Cavern', 'Terminus Cave', 'the Pokémon Village']],
  [/\bsun\b|\bmoon\b|ultra|usum|\bsm\b|alola/i, 'Alola', ['Iki Town', 'Hau’oli City', 'Verdant Cavern', 'Brooklet Hill', 'Wela Volcano Park', 'the Lush Jungle', 'Vast Poni Canyon', 'Mount Lanakila', 'Ten Carat Hill', 'the Altar of the Sunne']],
  [/sword|shield|swsh|galar/i, 'Galar', ['Postwick', 'the Slumbering Weald', 'the Wild Area', 'Motostoke', 'Glimwood Tangle', 'Hammerlocke', 'Spikemuth', 'Circhester', 'the Isle of Armor', 'the Crown Tundra']],
  [/scarlet|violet|paldea/i, 'Paldea', ['Cabo Poco', 'Mesagoza', 'Casseroya Lake', 'Glaseado Mountain', 'the Asado Desert', 'Tagtree Thicket', 'Area Zero', 'Kitakami', 'Blueberry Academy']],
  [/legends.*arceus|arceus|hisui/i, 'Hisui', ['Jubilife Village', 'the Obsidian Fieldlands', 'the Crimson Mirelands', 'the Cobalt Coastlands', 'the Coronet Highlands', 'the Alabaster Icelands']],
  [/unbound|borrius/i, 'Borrius', ['Frozen Heights', 'Crystal Peak', 'the Thundercap Mountains', 'Dresco Town', 'Flowertown', 'the Grim Woods']],
];
/** The game a creature came from (as the import wrote it), or null. */
export function originGame(c) {
  const o = c?.origin ?? {};
  const g = o.game ?? o.version ?? c?.pk?.game ?? null;
  return g == null ? null : String(g);
}
export function gamePlacesFor(c) {
  const g = originGame(c);
  if (!g) return null;
  const row = GAME_PLACES.find(([re]) => re.test(g));
  return row ? { region: row[1], places: row[2], game: g } : null;
}

const WISHES = [
  ['play', '🎾', 'play catch with you'], ['walk', '🚶', 'go on a long walk'], ['bath', '🫧', 'have a bath'], ['music', '🎵', 'listen to some music together'],
  ['friend', '🧑‍🤝‍🧑', 'play with a friend'], ['groom', '🪮', 'be brushed'], ['explore', '🗺️', 'explore somewhere new'], ['sun', '☀️', 'lie in the sun'],
  ['swim', '🌊', 'go for a swim'], ['nap', '💤', 'take a long nap somewhere cosy'], ['dress', '🎀', 'try on something new'], ['battle', '⚔️', 'have a battle'],
];

/** A new task this creature might ask for now: a food it's craving, something it wants to do, or a place from its game. */
export function wishTask(idx, save, c, t = Date.now(), seed = '') {
  const h = hash(`${c.uid}:${seed}:${Math.floor(t / 3600000)}`);
  const name = displayName(idx, c);
  const days = 1 + (h % 9); // a day to nine days
  const base = { id: `task-${c.uid}-${t.toString(36)}`, uid: c.uid, made: t, due: t + days * DAY };
  const pl = gamePlacesFor(c);
  const roll = h % 10;
  if (pl && roll < 3) {
    const place = pl.places[(h >>> 4) % pl.places.length];
    return { ...base, kind: 'place', key: `place:${place}`, icon: '📍', place, game: pl.game, text: `${name} wants to go back to ${place} (${pl.region}).` };
  }
  const craving = cravingOf(idx, c, t);
  const foods = (idx.ds?.items ?? []).filter((f) => /berry/i.test(f.name ?? '') && f.kind !== 'held');
  // what it most likes doing — an activity, or a battle — goes on the list as often as a food it's craving
  if (roll >= 4 && roll < 7) {
    let best = null, bs = -9;
    for (const inv of INVITES.filter((i) => i.act || i.id === 'battle')) { const W = whimFor(c, inv.id, t); const sc = tasteFor(idx, c, inv.id) * 0.7 + W.day * 0.4 + ((h >>> (inv.id.length % 13)) % 100) / 1000; if (sc > bs) { bs = sc; best = inv; } }
    if (best) return { ...base, kind: 'wish', key: `wish:${best.id}`, act: best.act ?? null, icon: best.id === 'battle' ? '⚔️' : ACT_ICON[best.act] ?? '✨', text: `${name} wants to ${best.label}.` };
  }
  if (roll < 7 && (craving || foods.length)) {
    const id = craving ?? foods[(h >>> 6) % foods.length].id;
    const it = itemInfo(idx, id) ?? allFoods(idx).find((f) => f.id === id);
    return { ...base, kind: 'food', key: `food:${id}`, icon: '🍓', item: id, text: `${name} really wants ${/^[aeiou]/i.test(it?.name ?? '') ? 'an' : 'a'} ${it?.name ?? 'treat'}.` };
  }
  const w = WISHES[(h >>> 8) % WISHES.length];
  return { ...base, kind: 'wish', key: `wish:${w[0]}`, icon: w[1], text: `${name} would love to ${w[2]}.` };
}

/** Write a task down (not if that creature already has one open, or the same thing is already there). Returns it or null. */
export function addTask(save, task) {
  if (!task) return null;
  save.tasks = (save.tasks ?? []).filter(Boolean);
  if (save.tasks.length >= TASKS_MAX) return null;
  if (save.tasks.some((x) => x.uid === task.uid)) return null;
  if (save.tasks.some((x) => x.key === task.key && x.uid === task.uid)) return null;
  save.tasks.push(task);
  return task;
}

/**
 * Now and then (call every few minutes): each creature at the R.A.N.C.H. or in the party may voice a wish, which
 * goes on the list; out-of-date ones come off. rnd() → 0..1. Returns the tasks just added.
 */
export function tickTasks(idx, save, t = Date.now(), rnd = Math.random, { chance = 0.04 } = {}) {
  save.tasks = (save.tasks ?? []).filter((x) => x && x.due > t && save.creatures?.[x.uid]);
  const added = [];
  const who = Object.values(save.creatures ?? {}).filter((c) => !c.egg && ['ranch', 'party', 'box'].includes(c.location?.kind) && c.location?.kind !== 'box');
  for (const c of who) {
    if (rnd() >= chance) continue;
    const task = addTask(save, wishTask(idx, save, c, t, String(rnd())));
    if (task) added.push(task);
  }
  return added;
}

/** You did it: the one who asked is happier and closer to you, and a few items come your way. → { ok, items: [[id, n]], note } */
export function completeTask(idx, save, id, t = Date.now(), rnd = Math.random) {
  const task = (save.tasks ?? []).find((x) => x.id === id);
  if (!task) return { ok: false, reason: 'That one is already off the list.' };
  save.tasks = save.tasks.filter((x) => x.id !== id);
  return rewardWish(idx, save, task, t, rnd);
}
/** What a wish come true gives: joy, friendship, a memory, and a few things for your trouble (task or not). */
export function rewardWish(idx, save, task, t = Date.now(), rnd = Math.random) {
  const c = save.creatures?.[task.uid];
  if (c) {
    c.needs = c.needs ?? {};
    c.needs.joy = Math.min(100, (c.needs.joy ?? 60) + 25);
    c.friendship = Math.min(idx.ds?.rules?.maxFriendship ?? 255, (c.friendship ?? 0) + 12);
    if (task.kind === 'food' && task.item) c.prefs = { ...(c.prefs ?? {}), [`food:${task.item}`]: Math.min(5, (c.prefs?.[`food:${task.item}`] ?? 0) + 1) };
    addMemory(c, task.kind === 'place' ? `Went back to ${task.place} with you. Just like old times!` : `Got what they wished for: ${task.text.replace(/^\S+\s/, '').replace(/\.$/, '')}.`, t);
    touch(c, t);
  }
  // a few things for your trouble: berries and other consumables from what the data set has
  const pool = (idx.ds?.items ?? []).filter((it) => /berry/i.test(it.name ?? '') || ['medicine', 'candy', 'food'].includes(it.kind)).map((it) => it.id);
  const items = [];
  const n = 2 + Math.floor(rnd() * 3);
  for (let i = 0; i < n && pool.length; i++) {
    const it = pool[Math.floor(rnd() * pool.length)];
    const k = 1 + Math.floor(rnd() * 2);
    save.inventory = save.inventory ?? {};
    save.inventory[it] = (save.inventory[it] ?? 0) + k;
    const e = items.find(([x]) => x === it); if (e) e[1] += k; else items.push([it, k]);
  }
  // and now and then something rare for your trouble: a blueprint you hadn't found, or a valuable
  let rare = []; try { rare = rareFinds(idx, save, 'task', { t, rnd }); for (const f of rare) if (f.kind === 'valuable') items.push([f.id, 1]); } catch { /* fine */ }
  return { ok: true, items, task, rare, note: c ? `${displayName(idx, c)} is overjoyed!` : '' };
}
// ---- a wish done right away (“Let's do it now”): it never went on the list, but it counts just the same ----
// The ask is kept for a while; when they've done it with you (that activity, a battle, …) the reward comes, exactly
// as if it had been ticked off the list. (And a matching one already on the list comes off with it.)
const LIVE_FOR = 6 * 3600000;
/** Whether it asked for this itself (a wish it's waiting on, or one on the task list): then being tired doesn't
 * stop it — it wanted to. what: an activity id or a wish name ('play', 'battle', 'race'…). */
export function wishedFor(save, uid, what, t = Date.now()) {
  if (!save || !uid || !what) return false;
  const hit = (w) => w && w.uid === uid && (w.act === what || w.key === `wish:${what}`);
  return (save.liveWishes ?? []).some((w) => hit(w) && t - w.at < LIVE_FOR) || (save.tasks ?? []).some((tk) => tk.kind === 'wish' && hit(tk));
}
export function startWish(save, { uid, key, act = null, icon = '✨', text = '' }, t = Date.now()) {
  if (!uid || !key) return null;
  save.liveWishes = (save.liveWishes ?? []).filter((w) => w && w.uid !== uid && t - w.at < LIVE_FOR);
  const w = { uid, key, act, icon, text, at: t };
  save.liveWishes.push(w);
  return w;
}
/** They did something with you: if it's what they asked for, the wish is granted. what: an activity id, or 'battle', … */
export function finishWish(idx, save, uid, what, t = Date.now(), rnd = Math.random) {
  const L = save.liveWishes ?? [];
  const i = L.findIndex((w) => w && w.uid === uid && t - w.at < LIVE_FOR && (w.act === what || w.key === `wish:${what}`));
  if (i < 0) return null;
  const w = L[i];
  save.liveWishes = L.filter((_, j) => j !== i);
  save.tasks = (save.tasks ?? []).filter((x) => !(x.uid === uid && x.key === w.key));
  return rewardWish(idx, save, { id: `live-${uid}-${t}`, uid, kind: 'wish', key: w.key, icon: w.icon, text: w.text || 'A wish came true.' }, t, rnd);
}
/** Not this time: it comes off the list (they're a little let down). */
export function denyTask(idx, save, id, t = Date.now()) {
  const task = (save.tasks ?? []).find((x) => x.id === id);
  if (!task) return { ok: false };
  save.tasks = save.tasks.filter((x) => x.id !== id);
  const c = save.creatures?.[task.uid];
  if (c?.needs) c.needs.joy = Math.max(0, (c.needs.joy ?? 60) - 4);
  if (c) touch(c, t);
  return { ok: true, task };
}

/** A wish they voiced while you were talking ("what do you want to do?") goes on the list too. */
// ---- things the game can see for itself: done as soon as they happen, ready to collect ----
// what doing each thing counts for (feeding a berry, a bath, a brushing, playing, a nap, a battle won…)
const ACT_ICON = { gardening: '🌱', cooking: '🍳', fishing: '🎣', scavenging: '⛏️', obstacle: '🏃', puzzle: '🧩', training: '💪', photography: '📸' };
const WISH_DONE = { play: ['play'], bath: ['wash'], groom: ['brush', 'comb'], nap: ['rest'], battle: ['battleWon', 'battle'], friend: ['pair'], music: ['music'], dress: ['dress'], walk: ['walk'], swim: ['wash'] };
/** Something happened that a task might have been waiting for: it's ticked off (ready to collect). Returns the tasks done. */
export function noteDone(save, uid, action, itemId = null, t = Date.now()) {
  const done = [];
  for (const tk of save.tasks ?? []) {
    if (!tk || tk.ready || tk.uid !== uid) continue;
    const hit = (tk.kind === 'food' && action === 'feed' && itemId && tk.item === itemId) || (tk.kind === 'wish' && (WISH_DONE[tk.key?.slice(5)] ?? []).includes(action))
      || (tk.kind === 'wish' && action === `act:${tk.act ?? actOfKey(tk.key)}`);
    if (hit) { tk.ready = t; done.push(tk); }
  }
  return done;
}
/** Can the game tell when this one's done by itself? */
// (an activity they asked for: done when they've done that activity with you)
const actOfKey = (key) => INVITES.find((i) => `wish:${i.id}` === key)?.act ?? null;
export const trackable = (tk) => tk?.kind === 'food' || (tk?.kind === 'wish' && (!!WISH_DONE[tk.key?.slice(5)] || !!(tk.act ?? actOfKey(tk.key))));
export function taskFromChat(idx, c, out, t = Date.now()) {
  if (!out) return null;
  const name = displayName(idx, c), days = 1 + (hash(`${c.uid}:${t}`) % 7);
  const base = { id: `task-${c.uid}-${t.toString(36)}`, uid: c.uid, made: t, due: t + days * DAY };
  if (out.wish && out.wish !== 'food') return { ...base, kind: 'wish', key: `wish:${out.wish}`, icon: out.bubble?.e ?? '✨', text: out.note || `${name} has a wish.` };
  if (out.bubble?.kind === 'item' && (out.mood === 'hungry' || out.intent === 'wantWhat' || out.wantFood || /want|crav|love|pictures|would/i.test(out.note ?? ''))) {
    const it = itemInfo(idx, out.bubble.id) ?? allFoods(idx).find((f) => f.id === out.bubble.id);
    return { ...base, kind: 'food', key: `food:${out.bubble.id}`, icon: '🍓', item: out.bubble.id, text: `${name} really wants ${/^[aeiou]/i.test(it?.name ?? '') ? 'an' : 'a'} ${it?.name ?? 'treat'}.` };
  }
  return null;
}
