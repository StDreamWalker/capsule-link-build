// Bringing creatures in from PKHeX: single-creature files saved by PKHeX (.pk8, .pb8, .pk9, and the
// encrypted .ek8/.eb8/.ek9 variants). Layout from PKHeX (PKHeX.Core/PKM/PK9.cs, G8PKM.cs):
// 0x148 bytes stored (0x158 with party stats), four 0x50-byte blocks shuffled by the encryption
// constant and XOR-encrypted with a linear-congruential stream.
//
// What comes across: species (by national number, or by name for a species whose number the file
// encodes differently), nickname, level, nature, abilities, moves and PP, IVs and EVs (as genes and
// effort), friendship, original trainer, when/where/how it was met, and the memories the games
// record. Showdown sets only go the other way: creatures can be sent to Showdown, not taken back.
import { createCreature, addMemory, speciesAbilities } from './creature.js';
import { expForLevel } from './dataset.js';
import { makeEgg } from './care.js';
import { STAT_KEYS } from './defaults.js';

const SIZE_STORED = 0x148;
const SIZE_PARTY = 0x158;
const BLOCK = 0x50;

const BLOCK_POSITION = [
  0, 1, 2, 3, 0, 1, 3, 2, 0, 2, 1, 3, 0, 3, 1, 2, 0, 2, 3, 1, 0, 3, 2, 1,
  1, 0, 2, 3, 1, 0, 3, 2, 2, 0, 1, 3, 3, 0, 1, 2, 2, 0, 3, 1, 3, 0, 2, 1,
  1, 2, 0, 3, 1, 3, 0, 2, 2, 1, 0, 3, 3, 1, 0, 2, 2, 3, 0, 1, 3, 2, 0, 1,
  1, 2, 3, 0, 1, 3, 2, 0, 2, 1, 3, 0, 3, 1, 2, 0, 2, 3, 1, 0, 3, 2, 1, 0,
  // duplicates of 0-7
  0, 1, 2, 3, 0, 1, 3, 2, 0, 2, 1, 3, 0, 3, 1, 2, 0, 2, 3, 1, 0, 3, 2, 1,
  1, 0, 2, 3, 1, 0, 3, 2,
];
const BLOCK_POSITION_INVERT = [0, 1, 2, 4, 3, 5, 6, 7, 12, 18, 13, 19, 8, 10, 14, 20, 16, 22, 9, 11, 15, 21, 17, 23, 0, 1, 2, 4, 3, 5, 6, 7];

export const NATURE_NAMES = ['Hardy', 'Lonely', 'Brave', 'Adamant', 'Naughty', 'Bold', 'Docile', 'Relaxed', 'Impish', 'Lax', 'Timid', 'Hasty', 'Serious', 'Jolly', 'Naive', 'Modest', 'Mild', 'Quiet', 'Bashful', 'Rash', 'Calm', 'Gentle', 'Sassy', 'Careful', 'Quirky'];
const NATURE_STATS = ['atk', 'def', 'spe', 'spa', 'spd'];

/** Game names by version id, for "came from …" memories. */
export const GAME_NAMES = {
  1: 'Sapphire', 2: 'Ruby', 3: 'Emerald', 4: 'FireRed', 5: 'LeafGreen', 7: 'HeartGold', 8: 'SoulSilver',
  10: 'Diamond', 11: 'Pearl', 12: 'Platinum', 15: 'Colosseum / XD', 20: 'White', 21: 'Black', 22: 'White 2', 23: 'Black 2',
  24: 'X', 25: 'Y', 26: 'Alpha Sapphire', 27: 'Omega Ruby', 30: 'Sun', 31: 'Moon', 32: 'Ultra Sun', 33: 'Ultra Moon',
  34: 'GO', 35: 'Red (Virtual Console)', 36: 'Green / Blue (Virtual Console)', 37: 'Blue (Virtual Console)', 38: 'Yellow (Virtual Console)',
  39: 'Gold (Virtual Console)', 40: 'Silver (Virtual Console)', 41: 'Crystal (Virtual Console)', 42: "Let's Go, Pikachu!", 43: "Let's Go, Eevee!",
  44: 'Sword', 45: 'Shield', 47: 'Legends: Arceus', 48: 'Brilliant Diamond', 49: 'Shining Pearl', 50: 'Scarlet', 51: 'Violet',
};

const u16 = (d, o) => d[o] | (d[o + 1] << 8);
const u32 = (d, o) => (d[o] | (d[o + 1] << 8) | (d[o + 2] << 16) | (d[o + 3] << 24)) >>> 0;
const w16 = (d, o, v) => { d[o] = v & 255; d[o + 1] = (v >> 8) & 255; };

function str16(d, o, max = 13) {
  let s = '';
  for (let i = 0; i < max; i++) {
    const c = u16(d, o + i * 2);
    if (!c) break;
    s += String.fromCharCode(c);
  }
  return s.trim();
}

export function checksum(d) {
  let sum = 0;
  for (let i = 8; i < SIZE_STORED; i += 2) sum = (sum + u16(d, i)) & 0xffff;
  return sum;
}

function cryptArray(d, start, end, seed) {
  for (let i = start; i < end; i += 2) {
    seed = (Math.imul(0x41c64e6d, seed) + 0x6073) >>> 0;
    w16(d, i, u16(d, i) ^ (seed >>> 16));
  }
}
function crypt(d, ec) {
  const end = 8 + 4 * BLOCK;
  cryptArray(d, 8, end, ec);
  if (d.length > end) cryptArray(d, end, d.length, ec);
}
function shuffle(d, sv) {
  const tmp = d.slice(8, 8 + 4 * BLOCK);
  for (let b = 0; b < 4; b++) {
    const from = BLOCK_POSITION[sv * 4 + b];
    d.set(tmp.subarray(from * BLOCK, from * BLOCK + BLOCK), 8 + b * BLOCK);
  }
}

/** Decrypted copy of the bytes (files saved by PKHeX are usually already decrypted). */
export function decryptPkm(bytes) {
  const d = new Uint8Array(bytes);
  if (checksum(d) === u16(d, 6) && u16(d, 8) !== 0) return d;
  const ec = u32(d, 0);
  crypt(d, ec);
  shuffle(d, BLOCK_POSITION_INVERT[(ec >>> 13) & 31]);
  return d;
}

/** The opposite, for tests and for writing files back out. */
export function encryptPkm(bytes) {
  const d = new Uint8Array(bytes);
  const ec = u32(d, 0);
  shuffle(d, (ec >>> 13) & 31);
  crypt(d, ec);
  return d;
}

/**
 * Read a PKHeX file. name: the file name (its extension tells the format apart).
 * Returns { ok, error?, fields… } with raw game values; see pkhexToCreature for the mapping.
 */
export function readPkm(bytes, name = '') {
  const ext = (/\.([a-z0-9]+)$/i.exec(name)?.[1] ?? '').toLowerCase();
  if (/^(pa8|pk[1-7]|ck3|xk3|bk4|pb7)$/.test(ext)) return { ok: false, error: `${ext.toUpperCase()} files are not supported yet. Use PKHeX to convert to a Sword/Shield, BDSP or Scarlet/Violet file (.pk8, .pb8 or .pk9).` };
  if (bytes.length !== SIZE_STORED && bytes.length !== SIZE_PARTY) return { ok: false, error: `Unexpected file size (${bytes.length} bytes). Expected a Gen 8/9 file of ${SIZE_STORED} or ${SIZE_PARTY} bytes.` };
  const d = decryptPkm(bytes);
  if (checksum(d) !== u16(d, 6)) return { ok: false, error: 'The checksum does not match. The file may be damaged.' };
  // Sword/Shield and BDSP keep version and language further along than Scarlet/Violet
  let gen = /9$/.test(ext) ? 9 : /8$/.test(ext) ? 8 : 0;
  if (!gen) gen = [50, 51].includes(d[0xce]) ? 9 : 8;
  const versionAt = gen === 9 ? 0xce : 0xde;
  const languageAt = gen === 9 ? 0xd5 : 0xe2;
  const iv32 = u32(d, 0x8c);
  const tid = u16(d, 0x0c), sid = u16(d, 0x0e), pid = u32(d, 0x1c);
  const out = {
    ok: true, gen, format: ext || `pk${gen}`,
    ec: u32(d, 0), pid,
    speciesInternal: u16(d, 0x08),
    heldItem: u16(d, 0x0a),
    tid, sid, trainerId: (((sid << 16) | tid) >>> 0) % 1000000,
    exp: u32(d, 0x10),
    ability: u16(d, 0x14),
    abilityNumber: d[0x16] & 7,
    nature: d[0x20], statNature: d[0x21],
    fateful: !!(d[0x22] & 1), gender: (d[0x22] >> 1) & 3,
    form: u16(d, 0x24),
    evs: { hp: d[0x26], atk: d[0x27], def: d[0x28], spe: d[0x29], spa: d[0x2a], spd: d[0x2b] },
    nickname: str16(d, 0x58),
    moves: [u16(d, 0x72), u16(d, 0x74), u16(d, 0x76), u16(d, 0x78)],
    pp: [d[0x7a], d[0x7b], d[0x7c], d[0x7d]],
    relearn: [u16(d, 0x82), u16(d, 0x84), u16(d, 0x86), u16(d, 0x88)],
    ivs: { hp: iv32 & 31, atk: (iv32 >>> 5) & 31, def: (iv32 >>> 10) & 31, spe: (iv32 >>> 15) & 31, spa: (iv32 >>> 20) & 31, spd: (iv32 >>> 25) & 31 },
    isEgg: !!((iv32 >>> 30) & 1), isNicknamed: !!((iv32 >>> 31) & 1),
    htName: str16(d, 0xa8), currentHandler: d[0xc4], htFriendship: d[0xc8],
    htMemory: { intensity: d[0xc9], id: d[0xca], feeling: d[0xcb], variable: u16(d, 0xcc) },
    version: d[versionAt], language: d[languageAt],
    otName: str16(d, 0xf8), otFriendship: d[0x112],
    otMemory: { intensity: d[0x113], id: d[0x114], variable: u16(d, 0x116), feeling: d[0x118] },
    eggDate: d[0x119] ? { y: 2000 + d[0x119], m: d[0x11a], d: d[0x11b] } : null,
    metDate: d[0x11c] ? { y: 2000 + d[0x11c], m: d[0x11d], d: d[0x11e] } : null,
    eggLocation: u16(d, 0x120), metLocation: u16(d, 0x122),
    ball: d[0x124], metLevel: d[0x125] & 0x7f, otGender: d[0x125] >> 7,
    statLevel: d.length >= SIZE_PARTY ? d[0x148] : 0,
  };
  out.shinyXor = (tid ^ sid ^ (pid >>> 16) ^ (pid & 0xffff)) >>> 0;
  out.shiny = out.shinyXor < 16;
  out.shinyType = !out.shiny ? null : out.shinyXor === 0 ? 'square' : 'star';
  // the rest of what the games keep, so nothing is lost on the way in
  out.markings = u16(d, 0x18);
  out.pokerus = d[0x32];
  out.contest = { cool: d[0x2c], beauty: d[0x2d], cute: d[0x2e], smart: d[0x2f], tough: d[0x30], sheen: d[0x31] };
  out.heightScalar = gen === 9 ? d[0x48] : d[0x50];
  out.weightScalar = gen === 9 ? d[0x49] : d[0x51];
  out.scale = gen === 9 ? d[0x4a] : null;
  out.teraType = gen === 9 ? { original: d[0x94], override: d[0x95] } : null;
  out.hpCurrent = u16(d, 0x8a);
  out.raw = d; // the whole decrypted file, kept with the creature
  // national number: the same as the stored number except for species added in Scarlet/Violet,
  // which the file numbers in its own order — those are matched by name instead
  out.national = gen === 9 && out.speciesInternal > 905 ? null : out.speciesInternal;
  return out;
}

const squash = (s) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');

/** Which species in the data set this file is: { species, how } or { species: null, guess } */
export function matchSpecies(idx, pk) {
  const list = idx.ds.species;
  if (pk.national) {
    const byNo = list.filter((s) => Number(s.no) === pk.national);
    if (byNo.length) return { species: byNo[0], how: 'number' };
  }
  // an un-nicknamed creature carries its species name (in the game's language)
  if (!pk.isNicknamed && pk.nickname) {
    const k = squash(pk.nickname);
    const s = list.find((x) => squash(x.name) === k || squash(x.showdownName) === k || squash(x.id) === k);
    if (s) return { species: s, how: 'name' };
  }
  return { species: null, guess: pk.isNicknamed ? '' : pk.nickname };
}

function b64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return typeof btoa === 'function' ? btoa(s) : Buffer.from(s, 'binary').toString('base64');
}

const dateMs = (dt) => (dt ? new Date(dt.y, Math.max(0, dt.m - 1), dt.d || 1, 12).getTime() : null);
const fmtDate = (dt) => (dt ? new Date(dt.y, Math.max(0, dt.m - 1), dt.d || 1).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : '');
const INTENSITY = ['', 'faint', 'faint', 'clear', 'clear', 'vivid', 'vivid', 'unforgettable'];

/**
 * Turn a read file into a creature for this data set.
 * opts: { species (override), trainer (who is importing), location, now }
 * Returns { creature, notes: [] }.
 */
export function pkhexToCreature(idx, pk, opts = {}) {
  const notes = [];
  const sp = opts.species ?? matchSpecies(idx, pk).species;
  if (!sp) throw new Error('No matching species in your data set.');
  const R = idx.ds.rules;
  // level: party files store it; otherwise from experience on the game's curve, which we
  // approximate with the species' own curve here
  let level = pk.statLevel || 0;
  if (!level) {
    level = 1;
    while (level < (R.maxLevel ?? 100) && expForLevel(idx, sp.growthRate, level + 1) <= pk.exp) level++;
    if (level === 1 && pk.metLevel) level = pk.metLevel;
  }
  level = Math.max(1, Math.min(R.maxLevel ?? 100, level));
  const scaleGene = (v) => Math.round((v * (R.maxGenes ?? 31)) / 31);
  const genes = Object.fromEntries(STAT_KEYS.map((k) => [k, scaleGene(pk.ivs[k] ?? 0)]));
  const effort = Object.fromEntries(STAT_KEYS.map((k) => [k, Math.min(R.maxEffortPerStat ?? 252, pk.evs[k] ?? 0)]));
  // nature: by name, else by the stats it raises and lowers
  const n = pk.statNature < 25 ? pk.statNature : pk.nature;
  const nName = NATURE_NAMES[n] ?? '';
  const up = NATURE_STATS[Math.floor(n / 5)], down = NATURE_STATS[n % 5];
  const temps = idx.ds.temperaments ?? [];
  const temper = temps.find((t) => squash(t.name) === squash(nName) || squash(t.showdownName) === squash(nName))
    ?? (up === down ? temps.find((t) => !t.up || t.up === t.down) : temps.find((t) => t.up === up && t.down === down)) ?? null;
  if (!temper && temps.length) notes.push(`Nature ${nName} has no match in your data set.`);
  // ability by slot
  const abil = speciesAbilities(sp);
  const slot = pk.abilityNumber === 4 ? 2 : pk.abilityNumber === 2 ? 1 : 0;
  const ability = abil[slot] ?? abil[0] ?? '';
  // moves by number
  const moves = [];
  pk.moves.forEach((no, i) => {
    if (!no) return;
    const m = idx.ds.moves.find((x) => Number(x.no) === no);
    if (m) moves.push({ id: m.id, pp: Math.min(pk.pp[i] || m.pp, Math.ceil((m.pp ?? 10) * 1.6)) });
    else notes.push(`Move #${no} is not in your data set, so it was left out.`);
  });
  const handlerIsHt = pk.currentHandler === 1 && pk.htName;
  const friendship = Math.min(R.maxFriendship ?? 255, handlerIsHt ? pk.htFriendship : pk.otFriendship);
  const metAt = dateMs(pk.metDate) ?? opts.now ?? Date.now();
  const game = GAME_NAMES[pk.version] ?? (pk.version ? `game #${pk.version}` : 'another game');
  const c = createCreature(idx, sp.id, {
    level, genes, effort, temper: temper?.id ?? undefined, ability,
    nickname: pk.isNicknamed ? pk.nickname.slice(0, 12) : '',
    friendship, trainer: pk.otName || opts.trainer || '',
    location: opts.location, metHow: `Came over from ${game}`, now: opts.now,
    seed: pk.pid ^ pk.ec,
  });
  if (moves.length) c.moves = moves;
  c.metAt = metAt;
  c.metLevel = pk.metLevel || level;
  c.shiny = pk.shiny;
  c.ball = pk.ball ? String(pk.ball) : ''; // which ball picture it shows (ui/ball-<number>.png)
  c.gender = ['male', 'female', 'none'][pk.gender] ?? 'none';
  c.origin = { from: 'pkhex', game, version: pk.version, ot: pk.otName, otId: pk.trainerId, ball: pk.ball, metLocation: pk.metLocation, format: pk.format, ec: pk.ec, pid: pk.pid };
  // everything hidden the games keep (identity, exact IVs/EVs, shininess, size, tera type…) plus
  // the original file itself, so the creature can be checked or sent back unchanged later
  c.pid = pk.pid; c.ec = pk.ec;
  c.shinyType = pk.shinyType;
  if (Number.isFinite(pk.heightScalar)) c.sizeScalar = pk.heightScalar;
  c.pk = {
    format: pk.format, gen: pk.gen, pid: pk.pid, ec: pk.ec, tid: pk.tid, sid: pk.sid, trainerId: pk.trainerId, shinyXor: pk.shinyXor, shinyType: pk.shinyType,
    ivs: { ...pk.ivs }, evs: { ...pk.evs }, nature: NATURE_NAMES[pk.nature] ?? pk.nature, statNature: NATURE_NAMES[pk.statNature] ?? pk.statNature,
    abilityId: pk.ability, abilityNumber: pk.abilityNumber, form: pk.form, gender: c.gender, heldItem: pk.heldItem, relearn: pk.relearn, moves: pk.moves, pp: pk.pp,
    markings: pk.markings, pokerus: pk.pokerus, contest: pk.contest, heightScalar: pk.heightScalar, weightScalar: pk.weightScalar, scale: pk.scale,
    teraType: pk.teraType, language: pk.language, version: pk.version, otName: pk.otName, otGender: pk.otGender, otFriendship: pk.otFriendship,
    htName: pk.htName, htFriendship: pk.htFriendship, otMemory: pk.otMemory, htMemory: pk.htMemory, metLocation: pk.metLocation, metLevel: pk.metLevel,
    metDate: pk.metDate, eggLocation: pk.eggLocation, eggDate: pk.eggDate, ball: pk.ball, fateful: pk.fateful, exp: pk.exp, isEgg: pk.isEgg,
    raw: pk.raw ? b64(pk.raw) : null,
  };
  c.memories = [];
  const mem = (t, text) => { addMemory(c, text, t); c.memories[c.memories.length - 1].from = 'game'; };
  // the old life, oldest first
  if (pk.isEgg) c.friendship = sp.baseFriendship ?? 70;
  if (pk.isEgg) makeEgg(c, Math.max(1, pk.otFriendship || sp.eggCycles || 20) * 256, opts.now ?? Date.now()); // an egg's friendship byte counts its hatch cycles
  if (pk.eggDate && !pk.isEgg) mem(dateMs(pk.eggDate), `Hatched from an egg${pk.eggDate ? ` on ${fmtDate(pk.eggDate)}` : ''}.`);
  if (pk.fateful) mem(metAt, 'Arrived through a special event.');
  mem(metAt, `Met ${pk.otName || 'their first trainer'} in ${game}${pk.metLevel ? ` at level ${pk.metLevel}` : ''}${pk.metDate ? ` on ${fmtDate(pk.metDate)}` : ''}.`);
  if (pk.otMemory.id) mem(metAt + 1, `Has a ${INTENSITY[pk.otMemory.intensity] || 'clear'} memory of a time with ${pk.otName || 'their trainer'} (memory ${pk.otMemory.id}).`);
  if (pk.htName && pk.htName !== pk.otName) {
    const how = { faint: 'faintly', clear: 'clearly', vivid: 'vividly', unforgettable: 'forever' }[INTENSITY[pk.htMemory.intensity]] ?? 'well';
    mem(metAt + 2, `Spent time with ${pk.htName}${pk.htMemory.id ? `, and remembers it ${how} (memory ${pk.htMemory.id})` : ''}.`);
  }
  if (pk.shiny) mem(metAt + 3, 'Has always had an unusual colouring.');
  addMemory(c, `Streamed into ${'Capsule Link'} from ${game}${opts.trainer ? `, joining ${opts.trainer}` : ''}.`, opts.now ?? Date.now());
  return { creature: c, notes };
}

/** The creature already brought over from this same file, if any. */
export function alreadyImported(save, pk) {
  return Object.values(save.creatures ?? {}).find((c) => c.origin?.from === 'pkhex' && c.origin.ec === pk.ec && c.origin.pid === pk.pid) ?? null;
}

/** A Showdown team export ("Name @ Item / Ability: … / EVs: …"): these never import. */
export function looksLikeShowdownSet(text) {
  return /^[^\n]+\n\s*(Ability|EVs|IVs|Tera Type|Level|Shiny|Happiness)\s*:/m.test(String(text ?? '')) && /^\s*-\s+\S/m.test(String(text ?? ''));
}
