// Bringing creatures in from PKHeX: single-creature files saved by PKHeX (.pk8, .pb8, .pk9, and the
// encrypted .ek8/.eb8/.ek9 variants). Layout from PKHeX (PKHeX.Core/PKM/PK9.cs, G8PKM.cs):
// 0x148 bytes stored (0x158 with party stats), four 0x50-byte blocks shuffled by the encryption
// constant and XOR-encrypted with a linear-congruential stream.
//
// What comes across: species (by national number, or by name for a species whose number the file
// encodes differently), nickname, level, nature, abilities, moves and PP, IVs and EVs (as genes and
// effort), friendship, original trainer, when/where/how it was met, and the memories the games
// record. Showdown sets only go the other way: creatures can be sent to Showdown, not taken back.
import { createCreature, addMemory, speciesAbilities } from './creature.js';
import { expForLevel } from './dataset.js';
import { makeEgg } from './care.js';
import { STAT_KEYS } from './defaults.js';

const SIZE_STORED = 0x148;
const SIZE_PARTY = 0x158;
const BLOCK = 0x50;

const BLOCK_POSITION = [
  0, 1, 2, 3, 0, 1, 3, 2, 0, 2, 1, 3, 0, 3, 1, 2, 0, 2, 3, 1, 0, 3, 2, 1,
  1, 0, 2, 3, 1, 0, 3, 2, 2, 0, 1, 3, 3, 0, 1, 2, 2, 0, 3, 1, 3, 0, 2, 1,
  1, 2, 0, 3, 1, 3, 0, 2, 2, 1, 0, 3, 3, 1, 0, 2, 2, 3, 0, 1, 3, 2, 0, 1,
  1, 2, 3, 0, 1, 3, 2, 0, 2, 1, 3, 0, 3, 1, 2, 0, 2, 3, 1, 0, 3, 2, 1, 0,
  // duplicates of 0-7
  0, 1, 2, 3, 0, 1, 3, 2, 0, 2, 1, 3, 0, 3, 1, 2, 0, 2, 3, 1, 0, 3, 2, 1,
  1, 0, 2, 3, 1, 0, 3, 2,
];
const BLOCK_POSITION_INVERT = [0, 1, 2, 4, 3, 5, 6, 7, 12, 18, 13, 19, 8, 10, 14, 20, 16, 22, 9, 11, 15, 21, 17, 23, 0, 1, 2, 4, 3, 5, 6, 7];

export const NATURE_NAMES = ['Hardy', 'Lonely', 'Brave', 'Adamant', 'Naughty', 'Bold', 'Docile', 'Relaxed', 'Impish', 'Lax', 'Timid', 'Hasty', 'Serious', 'Jolly', 'Naive', 'Modest', 'Mild', 'Quiet', 'Bashful', 'Rash', 'Calm', 'Gentle', 'Sassy', 'Careful', 'Quirky'];
const NATURE_STATS = ['atk', 'def', 'spe', 'spa', 'spd'];

/** Game names by version id, for "came from …" memories. */
export const GAME_NAMES = {
  1: 'Sapphire', 2: 'Ruby', 3: 'Emerald', 4: 'FireRed', 5: 'LeafGreen', 7: 'HeartGold', 8: 'SoulSilver',
  10: 'Diamond', 11: 'Pearl', 12: 'Platinum', 15: 'Colosseum / XD', 20: 'White', 21: 'Black', 22: 'White 2', 23: 'Black 2',
  24: 'X', 25: 'Y', 26: 'Alpha Sapphire', 27: 'Omega Ruby', 30: 'Sun', 31: 'Moon', 32: 'Ultra Sun', 33: 'Ultra Moon',
  34: 'GO', 35: 'Red (Virtual Console)', 36: 'Green / Blue (Virtual Console)', 37: 'Blue (Virtual Console)', 38: 'Yellow (Virtual Console)',
  39: 'Gold (Virtual Console)', 40: 'Silver (Virtual Console)', 41: 'Crystal (Virtual Console)', 42: "Let's Go, Pikachu!", 43: "Let's Go, Eevee!",
  44: 'Sword', 45: 'Shield', 47: 'Legends: Arceus', 48: 'Brilliant Diamond', 49: 'Shining Pearl', 50: 'Scarlet', 51: 'Violet',
};

const u16 = (d, o) => d[o] | (d[o + 1] << 8);
const u32 = (d, o) => (d[o] | (d[o + 1] << 8) | (d[o + 2] << 16) | (d[o + 3] << 24)) >>> 0;
const w16 = (d, o, v) => { d[o] = v & 255; d[o + 1] = (v >> 8) & 255; };

function str16(d, o, max = 13) {
  let s = '';
  for (let i = 0; i < max; i++) {
    const c = u16(d, o + i * 2);
    if (!c) break;
    s += String.fromCharCode(c);
  }
  return s.trim();
}

export function checksum(d) {
  let sum = 0;
  for (let i = 8; i < SIZE_STORED; i += 2) sum = (sum + u16(d, i)) & 0xffff;
  return sum;
}

function cryptArray(d, start, end, seed) {
  for (let i = start; i < end; i += 2) {
    seed = (Math.imul(0x41c64e6d, seed) + 0x6073) >>> 0;
    w16(d, i, u16(d, i) ^ (seed >>> 16));
  }
}
function crypt(d, ec) {
  const end = 8 + 4 * BLOCK;
  cryptArray(d, 8, end, ec);
  if (d.length > end) cryptArray(d, end, d.length, ec);
}
function shuffle(d, sv) {
  const tmp = d.slice(8, 8 + 4 * BLOCK);
  for (let b = 0; b < 4; b++) {
    const from = BLOCK_POSITION[sv * 4 + b];
    d.set(tmp.subarray(from * BLOCK, from * BLOCK + BLOCK), 8 + b * BLOCK);
  }
}

/** Decrypted copy of the bytes (files saved by PKHeX are usually already decrypted). */
export function decryptPkm(bytes) {
  const d = new Uint8Array(bytes);
  if (checksum(d) === u16(d, 6) && u16(d, 8) !== 0) return d;
  const ec = u32(d, 0);
  crypt(d, ec);
  shuffle(d, BLOCK_POSITION_INVERT[(ec >>> 13) & 31]);
  return d;
}

/** The opposite, for tests and for writing files back out. */
export function encryptPkm(bytes) {
  const d = new Uint8Array(bytes);
  const ec = u32(d, 0);
  shuffle(d, (ec >>> 13) & 31);
  crypt(d, ec);
  return d;
}

/**
 * Read a PKHeX file. name: the file name (its extension tells the format apart).
 * Returns { ok, error?, fields… } with raw game values; see pkhexToCreature for the mapping.
 */
export function readPkm(bytes, name = '') {
  const ext = (/\.([a-z0-9]+)$/i.exec(name)?.[1] ?? '').toLowerCase();
  // older generations: fewer details, read what's there (and ask the trainer about the rest)
  const oldGen = /^[pe]k([34567])$/.exec(ext)?.[1] ?? (/^(pk|ek)/.test(ext) ? null : { 80: '3', 100: '3', 136: '45', 220: '5', 236: '4', 232: '67', 260: '67' }[bytes.length]);
  if (oldGen && !/^(pk8|pk9|pb8|ek8|ek9|eb8)$/.test(ext)) {
    const g = oldGen === '45' ? (bytes.length === 220 ? 5 : 0) : oldGen === '67' ? 0 : Number(oldGen);
    if (oldGen === '3' || g === 3) return readOld3(bytes, ext || 'pk3');
    if (oldGen === '4' || oldGen === '5' || oldGen === '45') return readOld45(bytes, ext || 'pk4', Number(oldGen) || null);
    return readOld67(bytes, ext || 'pk7', Number(oldGen) || null);
  }
  if (/^(pk[12]|ck3|xk3|bk4|pb7|pa8)$/.test(ext)) return { ok: false, error: `${ext.toUpperCase()} files can’t be read yet. In PKHeX, use Convert to make a newer file (.pk7, .pk8 or .pk9), then bring that in.` };
  if (bytes.length !== SIZE_STORED && bytes.length !== SIZE_PARTY) return { ok: false, error: `Unexpected file size (${bytes.length} bytes). Expected a Gen 8/9 file of ${SIZE_STORED} or ${SIZE_PARTY} bytes.` };
  const d = decryptPkm(bytes);
  if (checksum(d) !== u16(d, 6)) return { ok: false, error: 'The checksum does not match. The file may be damaged.' };
  // Sword/Shield and BDSP keep version and language further along than Scarlet/Violet
  let gen = /9$/.test(ext) ? 9 : /8$/.test(ext) ? 8 : 0;
  if (!gen) gen = [50, 51].includes(d[0xce]) ? 9 : 8;
  const versionAt = gen === 9 ? 0xce : 0xde;
  const languageAt = gen === 9 ? 0xd5 : 0xe2;
  const iv32 = u32(d, 0x8c);
  const tid = u16(d, 0x0c), sid = u16(d, 0x0e), pid = u32(d, 0x1c);
  const out = {
    ok: true, gen, format: ext || `pk${gen}`,
    ec: u32(d, 0), pid,
    speciesInternal: u16(d, 0x08),
    heldItem: u16(d, 0x0a),
    tid, sid, trainerId: (((sid << 16) | tid) >>> 0) % 1000000,
    exp: u32(d, 0x10),
    ability: u16(d, 0x14),
    abilityNumber: d[0x16] & 7,
    nature: d[0x20], statNature: d[0x21],
    fateful: !!(d[0x22] & 1), gender: (d[0x22] >> 1) & 3,
    form: u16(d, 0x24),
    evs: { hp: d[0x26], atk: d[0x27], def: d[0x28], spe: d[0x29], spa: d[0x2a], spd: d[0x2b] },
    nickname: str16(d, 0x58),
    moves: [u16(d, 0x72), u16(d, 0x74), u16(d, 0x76), u16(d, 0x78)],
    pp: [d[0x7a], d[0x7b], d[0x7c], d[0x7d]],
    relearn: [u16(d, 0x82), u16(d, 0x84), u16(d, 0x86), u16(d, 0x88)],
    ivs: { hp: iv32 & 31, atk: (iv32 >>> 5) & 31, def: (iv32 >>> 10) & 31, spe: (iv32 >>> 15) & 31, spa: (iv32 >>> 20) & 31, spd: (iv32 >>> 25) & 31 },
    isEgg: !!((iv32 >>> 30) & 1), isNicknamed: !!((iv32 >>> 31) & 1),
    htName: str16(d, 0xa8), currentHandler: d[0xc4], htFriendship: d[0xc8],
    htMemory: { intensity: d[0xc9], id: d[0xca], feeling: d[0xcb], variable: u16(d, 0xcc) },
    version: d[versionAt], language: d[languageAt],
    otName: str16(d, 0xf8), otFriendship: d[0x112],
    otMemory: { intensity: d[0x113], id: d[0x114], variable: u16(d, 0x116), feeling: d[0x118] },
    eggDate: d[0x119] ? { y: 2000 + d[0x119], m: d[0x11a], d: d[0x11b] } : null,
    metDate: d[0x11c] ? { y: 2000 + d[0x11c], m: d[0x11d], d: d[0x11e] } : null,
    eggLocation: u16(d, 0x120), metLocation: u16(d, 0x122),
    ball: d[0x124], metLevel: d[0x125] & 0x7f, otGender: d[0x125] >> 7,
    statLevel: d.length >= SIZE_PARTY ? d[0x148] : 0,
  };
  out.shinyXor = (tid ^ sid ^ (pid >>> 16) ^ (pid & 0xffff)) >>> 0;
  out.shiny = out.shinyXor < 16;
  out.shinyType = !out.shiny ? null : out.shinyXor === 0 ? 'square' : 'star';
  // the rest of what the games keep, so nothing is lost on the way in
  out.markings = u16(d, 0x18);
  out.pokerus = d[0x32];
  out.contest = { cool: d[0x2c], beauty: d[0x2d], cute: d[0x2e], smart: d[0x2f], tough: d[0x30], sheen: d[0x31] };
  out.heightScalar = gen === 9 ? d[0x48] : d[0x50];
  out.weightScalar = gen === 9 ? d[0x49] : d[0x51];
  out.scale = gen === 9 ? d[0x4a] : null;
  out.teraType = gen === 9 ? { original: d[0x94], override: d[0x95] } : null;
  out.hpCurrent = u16(d, 0x8a);
  out.raw = d; // the whole decrypted file, kept with the creature
  // national number: the same as the stored number except for species added in Scarlet/Violet,
  // which the file numbers in its own order — those are matched by name instead
  out.national = gen === 9 && out.speciesInternal > 905 ? null : out.speciesInternal;
  return out;
}

const squash = (s) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');

/** Which species in the data set this file is: { species, how } or { species: null, guess } */
export function matchSpecies(idx, pk) {
  const list = idx.ds.species;
  if (pk.national) {
    const byNo = list.filter((s) => Number(s.no) === pk.national);
    if (byNo.length) return { species: byNo[0], how: 'number' };
  }
  // an un-nicknamed creature carries its species name (in the game's language)
  if (!pk.isNicknamed && pk.nickname) {
    const k = squash(pk.nickname);
    const s = list.find((x) => squash(x.name) === k || squash(x.showdownName) === k || squash(x.id) === k);
    if (s) return { species: s, how: 'name' };
  }
  return { species: null, guess: pk.isNicknamed ? '' : pk.nickname };
}

function b64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return typeof btoa === 'function' ? btoa(s) : Buffer.from(s, 'binary').toString('base64');
}

const dateMs = (dt) => (dt ? new Date(dt.y, Math.max(0, dt.m - 1), dt.d || 1, 12).getTime() : null);
const fmtDate = (dt) => (dt ? new Date(dt.y, Math.max(0, dt.m - 1), dt.d || 1).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : '');
const INTENSITY = ['', 'faint', 'faint', 'clear', 'clear', 'vivid', 'vivid', 'unforgettable'];

/**
 * Turn a read file into a creature for this data set.
 * opts: { species (override), trainer (who is importing), location, now }
 * Returns { creature, notes: [] }.
 */
export function pkhexToCreature(idx, pk, opts = {}) {
  const notes = [];
  const sp = opts.species ?? matchSpecies(idx, pk).species;
  if (!sp) throw new Error('No matching species in your data set.');
  const R = idx.ds.rules;
  // level: party files store it; otherwise from experience on the game's curve, which we
  // approximate with the species' own curve here
  let level = pk.statLevel || 0;
  if (!level) {
    level = 1;
    while (level < (R.maxLevel ?? 100) && expForLevel(idx, sp.growthRate, level + 1) <= pk.exp) level++;
    if (level === 1 && pk.metLevel) level = pk.metLevel;
  }
  level = Math.max(1, Math.min(R.maxLevel ?? 100, level));
  const scaleGene = (v) => Math.round((v * (R.maxGenes ?? 31)) / 31);
  const genes = Object.fromEntries(STAT_KEYS.map((k) => [k, scaleGene(pk.ivs[k] ?? 0)]));
  const effort = Object.fromEntries(STAT_KEYS.map((k) => [k, Math.min(R.maxEffortPerStat ?? 252, pk.evs[k] ?? 0)]));
  // nature: by name, else by the stats it raises and lowers
  const n = pk.statNature < 25 ? pk.statNature : pk.nature;
  const nName = NATURE_NAMES[n] ?? '';
  const up = NATURE_STATS[Math.floor(n / 5)], down = NATURE_STATS[n % 5];
  const temps = idx.ds.temperaments ?? [];
  const temper = temps.find((t) => squash(t.name) === squash(nName) || squash(t.showdownName) === squash(nName))
    ?? (up === down ? temps.find((t) => !t.up || t.up === t.down) : temps.find((t) => t.up === up && t.down === down)) ?? null;
  if (!temper && temps.length) notes.push(`Nature ${nName} has no match in your data set.`);
  // ability by slot
  const abil = speciesAbilities(sp);
  const slot = pk.abilityNumber === 4 ? 2 : pk.abilityNumber === 2 ? 1 : 0;
  const ability = abil[slot] ?? abil[0] ?? '';
  // moves by number
  const moves = [];
  pk.moves.forEach((no, i) => {
    if (!no) return;
    const m = idx.ds.moves.find((x) => Number(x.no) === no);
    if (m) moves.push({ id: m.id, pp: Math.min(pk.pp[i] || m.pp, Math.ceil((m.pp ?? 10) * 1.6)) });
    else notes.push(`Move #${no} is not in your data set, so it was left out.`);
  });
  const handlerIsHt = pk.currentHandler === 1 && pk.htName;
  const friendship = Math.min(R.maxFriendship ?? 255, handlerIsHt ? pk.htFriendship : pk.otFriendship);
  const metAt = dateMs(pk.metDate) ?? opts.now ?? Date.now();
  const game = GAME_NAMES[pk.version] ?? (pk.version ? `game #${pk.version}` : 'another game');
  const c = createCreature(idx, sp.id, {
    level, genes, effort, temper: temper?.id ?? undefined, ability,
    nickname: pk.isNicknamed ? pk.nickname.slice(0, 12) : '',
    friendship, trainer: pk.otName || opts.trainer || '',
    location: opts.location, metHow: `Came over from ${game}`, now: opts.now,
    seed: pk.pid ^ pk.ec,
  });
  if (moves.length) c.moves = moves;
  c.metAt = metAt;
  c.metLevel = pk.metLevel || level;
  c.shiny = pk.shiny;
  c.ball = pk.ball ? String(pk.ball) : ''; // which ball picture it shows (ui/ball-<number>.png)
  c.gender = ['male', 'female', 'none'][pk.gender] ?? 'none';
  c.origin = { from: 'pkhex', game, version: pk.version, ot: pk.otName, otId: pk.trainerId, ball: pk.ball, metLocation: pk.metLocation, format: pk.format, ec: pk.ec, pid: pk.pid };
  // everything hidden the games keep (identity, exact IVs/EVs, shininess, size, tera type…) plus
  // the original file itself, so the creature can be checked or sent back unchanged later
  c.pid = pk.pid; c.ec = pk.ec;
  c.shinyType = pk.shinyType;
  if (Number.isFinite(pk.heightScalar)) c.sizeScalar = pk.heightScalar;
  c.pk = {
    format: pk.format, gen: pk.gen, pid: pk.pid, ec: pk.ec, tid: pk.tid, sid: pk.sid, trainerId: pk.trainerId, shinyXor: pk.shinyXor, shinyType: pk.shinyType,
    ivs: { ...pk.ivs }, evs: { ...pk.evs }, nature: NATURE_NAMES[pk.nature] ?? pk.nature, statNature: NATURE_NAMES[pk.statNature] ?? pk.statNature,
    abilityId: pk.ability, abilityNumber: pk.abilityNumber, form: pk.form, gender: c.gender, heldItem: pk.heldItem, relearn: pk.relearn, moves: pk.moves, pp: pk.pp,
    markings: pk.markings, pokerus: pk.pokerus, contest: pk.contest, heightScalar: pk.heightScalar, weightScalar: pk.weightScalar, scale: pk.scale,
    teraType: pk.teraType, language: pk.language, version: pk.version, otName: pk.otName, otGender: pk.otGender, otFriendship: pk.otFriendship,
    htName: pk.htName, htFriendship: pk.htFriendship, otMemory: pk.otMemory, htMemory: pk.htMemory, metLocation: pk.metLocation, metLevel: pk.metLevel,
    metDate: pk.metDate, eggLocation: pk.eggLocation, eggDate: pk.eggDate, ball: pk.ball, fateful: pk.fateful, exp: pk.exp, isEgg: pk.isEgg,
    raw: pk.raw ? b64(pk.raw) : null,
  };
  c.memories = [];
  const mem = (t, text) => { addMemory(c, text, t); c.memories[c.memories.length - 1].from = 'game'; };
  // the old life, oldest first
  if (pk.isEgg) c.friendship = sp.baseFriendship ?? 70;
  if (pk.isEgg) makeEgg(c, Math.max(1, pk.otFriendship || sp.eggCycles || 20) * 256, opts.now ?? Date.now()); // an egg's friendship byte counts its hatch cycles
  if (pk.eggDate && !pk.isEgg) mem(dateMs(pk.eggDate), `Hatched from an egg${pk.eggDate ? ` on ${fmtDate(pk.eggDate)}` : ''}.`);
  if (pk.fateful) mem(metAt, 'Arrived through a special event.');
  mem(metAt, `Met ${pk.otName || 'their first trainer'} in ${game}${pk.metLevel ? ` at level ${pk.metLevel}` : ''}${pk.metDate ? ` on ${fmtDate(pk.metDate)}` : ''}.`);
  if (pk.otMemory.id) mem(metAt + 1, `Has a ${INTENSITY[pk.otMemory.intensity] || 'clear'} memory of a time with ${pk.otName || 'their trainer'} (memory ${pk.otMemory.id}).`);
  if (pk.htName && pk.htName !== pk.otName) {
    const how = { faint: 'faintly', clear: 'clearly', vivid: 'vividly', unforgettable: 'forever' }[INTENSITY[pk.htMemory.intensity]] ?? 'well';
    mem(metAt + 2, `Spent time with ${pk.htName}${pk.htMemory.id ? `, and remembers it ${how} (memory ${pk.htMemory.id})` : ''}.`);
  }
  if (pk.shiny) mem(metAt + 3, 'Has always had an unusual colouring.');
  addMemory(c, `Streamed into ${'Capsule Link'} from ${game}${opts.trainer ? `, joining ${opts.trainer}` : ''}.`, opts.now ?? Date.now());
  return { creature: c, notes };
}

/**
 * A creature sent to PKHeX coming back (the same file, maybe changed there): take the game's side of
 * things from the file (level, effort, genes, moves, nickname, friendship) and keep everything that only
 * lives in Capsule Link (memories, mood, friends, journal). Returns what changed, as words.
 */
export function refreshFromPkm(idx, c, pk) {
  const changed = [];
  const sp = idx.species.get(c.speciesId);
  const R = idx.ds.rules;
  let level = pk.statLevel || 0;
  if (!level && sp) { level = 1; while (level < (R.maxLevel ?? 100) && expForLevel(idx, sp.growthRate, level + 1) <= pk.exp) level++; }
  if (level && level !== c.level) { changed.push(`level ${c.level} → ${level}`); c.level = level; c.exp = expForLevel(idx, sp?.growthRate, level); }
  const effort = Object.fromEntries(STAT_KEYS.map((k) => [k, Math.min(R.maxEffortPerStat ?? 252, pk.evs[k] ?? 0)]));
  if (STAT_KEYS.some((k) => (c.effort?.[k] ?? 0) !== effort[k])) { c.effort = effort; changed.push('effort'); }
  const genes = Object.fromEntries(STAT_KEYS.map((k) => [k, Math.round(((pk.ivs[k] ?? 0) * (R.maxGenes ?? 31)) / 31)]));
  if (STAT_KEYS.some((k) => (c.genes?.[k] ?? 0) !== genes[k])) { c.genes = genes; changed.push('genes'); }
  const moves = pk.moves.filter(Boolean).map((no, i) => { const m = idx.ds.moves.find((x) => Number(x.no) === no); return m ? { id: m.id, pp: pk.pp[i] || m.pp } : null; }).filter(Boolean);
  if (moves.length && moves.map((m) => m.id).join() !== (c.moves ?? []).map((m) => m.id).join()) { c.moves = moves; changed.push('moves'); }
  const nick = pk.isNicknamed ? pk.nickname.slice(0, 12) : '';
  if (nick !== (c.nickname ?? '')) { c.nickname = nick; changed.push('nickname'); }
  const fr = Math.min(R.maxFriendship ?? 255, pk.currentHandler === 1 && pk.htName ? pk.htFriendship : pk.otFriendship);
  if (fr && fr !== c.friendship) { c.friendship = fr; changed.push('friendship'); }
  c.shiny = pk.shiny;
  c.pk = { ...(c.pk ?? {}), format: pk.format, gen: pk.gen, pid: pk.pid, ec: pk.ec, raw: pk.raw ? b64(pk.raw) : c.pk?.raw, exported: { pid: pk.pid, ec: pk.ec } };
  addMemory(c, changed.length ? `Came back from a trip through PKHeX (${changed.join(', ')}).` : 'Came back from a trip through PKHeX.');
  return changed;
}

/** The creature already brought over from this same file, if any. */
export function alreadyImported(save, pk) {
  // a file sent out to PKHeX and brought back: the same creature (with everything that only lives here)
  return Object.values(save.creatures ?? {}).find((c) => ((c.origin?.from === 'pkhex' || c.origin?.from === 'memory') && c.origin.ec === pk.ec && c.origin.pid === pk.pid)
    || (c.pk?.exported && c.pk.exported.ec === pk.ec && c.pk.exported.pid === pk.pid)) ?? null;
}

/** A Showdown team export ("Name @ Item / Ability: … / EVs: …"): these never import. */
export function looksLikeShowdownSet(text) {
  return /^[^\n]+\n\s*(Ability|EVs|IVs|Tera Type|Level|Shiny|Happiness)\s*:/m.test(String(text ?? '')) && /^\s*-\s+\S/m.test(String(text ?? ''));
}


// ---------- older games (Gen 3 to 7): fewer details than today's games keep ----------
const GEN3_ORDER = ['GAEM', 'GAME', 'GEAM', 'GEMA', 'GMAE', 'GMEA', 'AGEM', 'AGME', 'AEGM', 'AEMG', 'AMGE', 'AMEG', 'EGAM', 'EGMA', 'EAGM', 'EAMG', 'EMGA', 'EMAG', 'MGAE', 'MGEA', 'MAGE', 'MAEG', 'MEGA', 'MEAG'];
// Gen 3's own letters (English set): A-Z, a-z, 0-9 and the common marks
function gen3Char(b) {
  if (b >= 0xbb && b <= 0xd4) return String.fromCharCode(65 + b - 0xbb);
  if (b >= 0xd5 && b <= 0xee) return String.fromCharCode(97 + b - 0xd5);
  if (b >= 0xa1 && b <= 0xaa) return String.fromCharCode(48 + b - 0xa1);
  return { 0x00: ' ', 0xab: '!', 0xac: '?', 0xad: '.', 0xae: '-', 0xb0: '…', 0xb1: '“', 0xb2: '”', 0xb3: '‘', 0xb4: '’', 0xb5: '♂', 0xb6: '♀', 0xb8: ',', 0xba: '/' }[b] ?? '';
}
const str3 = (d, o, n) => { let t = ''; for (let i = 0; i < n; i++) { const b = d[o + i]; if (b === 0xff) break; t += gen3Char(b); } return t.trim(); };
// Gen 4's own character table (the common part): digits, letters and a few marks
function gen4Char(v) {
  if (v >= 0x0121 && v <= 0x012a) return String.fromCharCode(48 + v - 0x0121);
  if (v >= 0x012b && v <= 0x0144) return String.fromCharCode(65 + v - 0x012b);
  if (v >= 0x0145 && v <= 0x015e) return String.fromCharCode(97 + v - 0x0145);
  return { 0x01de: ' ', 0x01ab: '!', 0x01ac: '?', 0x01ae: '.', 0x01be: '-', 0x01ad: ',', 0x01b3: "'", 0x01bb: '♂', 0x01bc: '♀' }[v] ?? '';
}
const str4 = (d, o, n) => { let t = ''; for (let i = 0; i < n; i++) { const v = u16(d, o + i * 2); if (v === 0xffff || v === 0) break; t += gen4Char(v); } return t.trim(); };
const str5 = (d, o, n) => { let t = ''; for (let i = 0; i < n; i++) { const v = u16(d, o + i * 2); if (v === 0xffff || v === 0) break; t += String.fromCharCode(v); } return t.trim(); };
const ivsOf = (iv32) => ({ hp: iv32 & 31, atk: (iv32 >>> 5) & 31, def: (iv32 >>> 10) & 31, spe: (iv32 >>> 15) & 31, spa: (iv32 >>> 20) & 31, spd: (iv32 >>> 25) & 31 });
const sum16 = (d, a, b) => { let x = 0; for (let i = a; i < b; i += 2) x = (x + u16(d, i)) & 0xffff; return x; };
/** Blocks back in order: try the usual order and its inverse, keep whichever checks out. */
function unshuffle(d, sv, blockSize, start = 8, check) {
  for (const table of [BLOCK_POSITION, null]) {
    const e = new Uint8Array(d);
    const tmp = e.slice(start, start + 4 * blockSize);
    for (let b = 0; b < 4; b++) {
      const from = table ? table[sv * 4 + b] : BLOCK_POSITION.slice(sv * 4, sv * 4 + 4).indexOf(b);
      e.set(tmp.subarray(from * blockSize, from * blockSize + blockSize), start + b * blockSize);
    }
    if (check(e)) return e;
  }
  return null;
}
const blankOld = (gen, ext) => ({
  ok: true, gen, format: ext, old: true, missing: [],
  contest: null, markings: 0, pokerus: 0, heightScalar: null, weightScalar: null, scale: null, teraType: null,
  htName: '', currentHandler: 0, htFriendship: 0, htMemory: { intensity: 0, id: 0, feeling: 0, variable: 0 }, otMemory: { intensity: 0, id: 0, feeling: 0, variable: 0 },
  eggDate: null, metDate: null, eggLocation: 0, relearn: [0, 0, 0, 0], statNature: 255, fateful: false, form: 0, ability: 0, abilityNumber: 1, language: 2, hpCurrent: 0,
});
function finishOld(out) {
  out.shinyXor = (out.tid ^ out.sid ^ (out.pid >>> 16) ^ (out.pid & 0xffff)) >>> 0;
  out.shiny = out.shinyXor < (out.gen >= 7 ? 16 : 8);
  out.shinyType = out.shiny ? (out.shinyXor === 0 ? 'square' : 'star') : null;
  out.trainerId = out.gen >= 7 ? (((out.sid << 16) | out.tid) >>> 0) % 1000000 : out.tid;
  out.isNicknamed = out.isNicknamed ?? false;
  // what older games never kept: asked about on the way in
  if (!out.metDate) out.missing.push('when');
  out.missing.push('memories');
  if (out.gen <= 5) out.missing.push('personality');
  return out;
}

function readOld3(bytes, ext) {
  let d = new Uint8Array(bytes);
  if (d.length !== 80 && d.length !== 100) return { ok: false, error: `Unexpected size for a Gen 3 file (${d.length} bytes).` };
  const pid = u32(d, 0), otid = u32(d, 4);
  const order = GEN3_ORDER[pid % 24];
  const key = (pid ^ otid) >>> 0;
  const data = d.slice(32, 80);
  const dec = new Uint8Array(48);
  const plain = (() => { let x = 0; for (let i = 0; i < 48; i += 2) x = (x + (data[i] | (data[i + 1] << 8))) & 0xffff; return x; })();
  const decrypted = (() => { const t = new Uint8Array(48); for (let i = 0; i < 48; i += 4) { const v = ((data[i] | (data[i + 1] << 8) | (data[i + 2] << 16) | (data[i + 3] << 24)) ^ key) >>> 0; t[i] = v & 255; t[i + 1] = (v >>> 8) & 255; t[i + 2] = (v >>> 16) & 255; t[i + 3] = v >>> 24; } return t; })();
  const sumOf = (t) => { let x = 0; for (let i = 0; i < 48; i += 2) x = (x + (t[i] | (t[i + 1] << 8))) & 0xffff; return x; };
  const chk = u16(d, 0x1c);
  const src = sumOf(decrypted) === chk ? decrypted : plain === chk ? data : null;
  if (!src) return { ok: false, error: 'The checksum does not match. The file may be damaged.' };
  for (let i = 0; i < 4; i++) dec.set(src.subarray(i * 12, i * 12 + 12), 'GAEM'.indexOf(order[i]) * 12);
  const G = 0, A = 12, E = 24, M = 36;
  const origins = u16(dec, M + 2), iv32 = u32(dec, M + 4);
  const internal = u16(dec, G);
  const out = Object.assign(blankOld(3, ext), {
    ec: pid, pid, tid: otid & 0xffff, sid: otid >>> 16,
    speciesInternal: internal, national: internal >= 1 && internal <= 251 ? internal : null,
    heldItem: u16(dec, G + 2), exp: u32(dec, G + 4), otFriendship: dec[G + 9],
    moves: [u16(dec, A), u16(dec, A + 2), u16(dec, A + 4), u16(dec, A + 6)], pp: [dec[A + 8], dec[A + 9], dec[A + 10], dec[A + 11]],
    evs: { hp: dec[E], atk: dec[E + 1], def: dec[E + 2], spe: dec[E + 3], spa: dec[E + 4], spd: dec[E + 5] },
    ivs: ivsOf(iv32), isEgg: !!((iv32 >>> 30) & 1), abilityNumber: (iv32 >>> 31) ? 2 : 1,
    pokerus: dec[M], metLocation: dec[M + 1], metLevel: origins & 0x7f, version: (origins >> 7) & 15, ball: (origins >> 11) & 15, otGender: origins >> 15,
    nickname: str3(d, 8, 10), otName: str3(d, 0x14, 7), language: u16(d, 0x12), markings: d[0x1b],
    nature: pid % 25, gender: 2, statLevel: d.length === 100 ? d[0x54] : 0, raw: d,
  });
  // older games mark a nickname only by it being different from the species' own name: guess
  out.isNicknamed = false;
  return finishOld(out);
}

function readOld45(bytes, ext, gen) {
  const d0 = new Uint8Array(bytes);
  if (![136, 220, 236].includes(d0.length)) return { ok: false, error: `Unexpected size for a Gen 4/5 file (${d0.length} bytes).` };
  const pid = u32(d0, 0), chk = u16(d0, 6);
  const ok = (e) => sum16(e, 8, 136) === chk;
  let d = ok(d0) ? d0 : null;
  if (!d) { const e = new Uint8Array(d0); cryptArray(e, 8, 136, chk); d = unshuffle(e, ((pid & 0x3e000) >>> 13) % 24, 32, 8, ok); }
  if (!d) return { ok: false, error: 'The checksum does not match. The file may be damaged.' };
  const version = d[0x5f];
  if (!gen) gen = version >= 20 && version <= 23 ? 5 : 4;
  const iv32 = u32(d, 0x38), flags = d[0x40];
  const date = (o) => (d[o] ? { y: 2000 + d[o], m: d[o + 1], d: d[o + 2] } : null);
  const out = Object.assign(blankOld(gen, ext), {
    ec: pid, pid, tid: u16(d, 0x0c), sid: u16(d, 0x0e),
    speciesInternal: u16(d, 0x08), national: u16(d, 0x08),
    heldItem: u16(d, 0x0a), exp: u32(d, 0x10), otFriendship: d[0x14], ability: d[0x15], markings: d[0x16], language: d[0x17],
    evs: { hp: d[0x18], atk: d[0x19], def: d[0x1a], spe: d[0x1b], spa: d[0x1c], spd: d[0x1d] },
    moves: [u16(d, 0x28), u16(d, 0x2a), u16(d, 0x2c), u16(d, 0x2e)], pp: [d[0x30], d[0x31], d[0x32], d[0x33]],
    ivs: ivsOf(iv32), isEgg: !!((iv32 >>> 30) & 1), isNicknamed: !!((iv32 >>> 31) & 1),
    fateful: !!(flags & 1), gender: (flags >> 1) & 3, form: flags >> 3,
    nature: gen === 5 ? d[0x41] : pid % 25,
    nickname: gen === 5 ? str5(d, 0x48, 11) : str4(d, 0x48, 11), version,
    otName: gen === 5 ? str5(d, 0x68, 8) : str4(d, 0x68, 8),
    eggDate: date(0x78), metDate: date(0x7b), eggLocation: u16(d, 0x7e), metLocation: u16(d, 0x80),
    pokerus: d[0x82], ball: d[0x83], metLevel: d[0x84] & 0x7f, otGender: d[0x84] >> 7,
    statLevel: d0.length > 136 ? d0[0x8c] : 0, raw: d,
  });
  return finishOld(out);
}

function readOld67(bytes, ext, gen) {
  const d0 = new Uint8Array(bytes);
  if (d0.length !== 232 && d0.length !== 260) return { ok: false, error: `Unexpected size for a Gen 6/7 file (${d0.length} bytes).` };
  const ec = u32(d0, 0), chk = u16(d0, 6);
  const ok = (e) => sum16(e, 8, 232) === chk;
  let d = ok(d0) ? d0 : null;
  if (!d) { const e = new Uint8Array(d0); cryptArray(e, 8, 232, ec); d = unshuffle(e, (ec >>> 13) & 31, 56, 8, ok); }
  if (!d) return { ok: false, error: 'The checksum does not match. The file may be damaged.' };
  const version = d[0xdf];
  if (!gen) gen = version >= 30 ? 7 : 6;
  const iv32 = u32(d, 0x74), flags = d[0x1d];
  const date = (o) => (d[o] ? { y: 2000 + d[o], m: d[o + 1], d: d[o + 2] } : null);
  const out = Object.assign(blankOld(gen, ext), {
    ec, pid: u32(d, 0x18), tid: u16(d, 0x0c), sid: u16(d, 0x0e),
    speciesInternal: u16(d, 0x08), national: u16(d, 0x08),
    heldItem: u16(d, 0x0a), exp: u32(d, 0x10), ability: d[0x14], abilityNumber: d[0x15], markings: u16(d, 0x16),
    nature: d[0x1c], fateful: !!(flags & 1), gender: (flags >> 1) & 3, form: flags >> 3,
    evs: { hp: d[0x1e], atk: d[0x1f], def: d[0x20], spe: d[0x21], spa: d[0x22], spd: d[0x23] },
    pokerus: d[0x2b], nickname: str5(d, 0x40, 12),
    moves: [u16(d, 0x5a), u16(d, 0x5c), u16(d, 0x5e), u16(d, 0x60)], pp: [d[0x62], d[0x63], d[0x64], d[0x65]],
    relearn: [u16(d, 0x6a), u16(d, 0x6c), u16(d, 0x6e), u16(d, 0x70)],
    ivs: ivsOf(iv32), isEgg: !!((iv32 >>> 30) & 1), isNicknamed: !!((iv32 >>> 31) & 1),
    htName: str5(d, 0x78, 12), htFriendship: d[0xa2], currentHandler: d[0x93],
    htMemory: { intensity: d[0xa4], id: d[0xa5], variable: u16(d, 0xa6), feeling: d[0xa8] },
    otName: str5(d, 0xb0, 12), otFriendship: d[0xca],
    otMemory: { intensity: d[0xcc], id: d[0xcd], variable: u16(d, 0xce), feeling: d[0xd0] },
    eggDate: date(0xd1), metDate: date(0xd4), eggLocation: u16(d, 0xd8), metLocation: u16(d, 0xda),
    ball: d[0xdc], metLevel: d[0xdd] & 0x7f, otGender: d[0xdd] >> 7, version, language: d[0xe3],
    statLevel: d0.length === 260 ? d0[0xec] : 0, raw: d,
  });
  return finishOld(out);
}

/**
 * Questions for what an older game never kept, so the creature's story can still be told:
 * [{ id, ask, kind: 'text' | 'choice', options? }]
 */
/**
 * Questions for the trainer when a creature comes over from PKHeX: what the game never kept (memories,
 * personality, voice) and whatever makes this one *theirs*. Every question is optional.
 * kinds: text | choice | memories (up to 3 lines) | size (0-255 slider with labels) | pitch (semitones, with a Hear button)
 *        | friends (pick from `friends`: [{ uid, name }], creatures from the same game save)
 * opts: { friends }
 */
export function missingQuestions(pk, { friends = [] } = {}) {
  const q = [];
  const old = !!pk.old;
  // where it all started
  if (pk.missing?.includes('when')) q.push({ id: 'when', group: 'Your story', ask: 'Roughly when did you two meet? (a year, or a month and year)', kind: 'text', placeholder: 'e.g. summer 2005' });
  q.push({ id: 'where', group: 'Your story', ask: 'Where did you meet? (a route, a town, a cave…)', kind: 'text', placeholder: 'e.g. Route 102' });
  q.push({ id: 'memories', group: 'Your story', ask: old ? 'Your favourite memories together (up to three — these become core memories)' : 'Any memories the game didn’t keep? (up to three — these become core memories)', kind: 'memories', placeholders: ['e.g. beat the Champion together on the first try', 'e.g. the night it evolved during a thunderstorm', 'e.g. always rode on my shoulder'] });
  // what made them them
  q.push({ id: 'size', group: 'How they were', ask: 'How big were they, compared to most of their kind?', kind: 'size' });
  q.push({ id: 'pitch', group: 'How they were', ask: 'Drag to what their voice sounded like', kind: 'pitch' });
  if (old || pk.missing?.includes('personality')) q.push({ id: 'style', group: 'How they were', ask: 'What were they like?', kind: 'choice', options: [['playful', 'Always up for a fight or a game'], ['calm', 'Steady and dependable'], ['shy', 'Quiet and a bit shy'], ['bold', 'Fearless'], ['lazy', 'Laid-back']] });
  q.push({ id: 'newthing', group: 'How they were', ask: 'When something new turned up, they…', kind: 'choice', options: [['bold', 'ran straight up to it'], ['shy', 'hid behind you'], ['calm', 'watched from a distance'], ['playful', 'tried to play with it'], ['lazy', 'didn’t even look up']] });
  q.push({ id: 'daytime', group: 'How they were', ask: 'Morning person or night owl?', kind: 'choice', options: [['time:dawn', 'Up with the sun'], ['time:day', 'Liveliest in the afternoon'], ['time:night', 'A night owl']] });
  q.push({ id: 'touch', group: 'How they were', ask: 'Being held, petted or brushed?', kind: 'choice', options: [['love', 'Loved it'], ['ok', 'Put up with it'], ['no', 'Not a fan']] });
  q.push({ id: 'love', group: 'How they were', ask: 'What did they love most?', kind: 'choice', options: [['weather:sun', 'Sunny days'], ['weather:rain', 'Rainy days'], ['activity:battle', 'Battling'], ['activity:nap', 'Naps'], ['activity:walk', 'Exploring on foot'], ['env:water', 'Being near water'], ['env:forest', 'The woods'], ['time:night', 'Night time']] });
  q.push({ id: 'hate', group: 'How they were', ask: 'Anything they couldn’t stand?', kind: 'choice', options: [['weather:rain', 'Getting rained on'], ['activity:bath', 'Bath time'], ['env:water', 'Water'], ['time:night', 'The dark'], ['activity:battle', 'Fighting'], ['weather:snow', 'The cold']] });
  if (friends.length) q.push({ id: 'friends', group: 'Their friends', ask: 'Who were they close to? (from the same game — they’ll stay friends here)', kind: 'friends', options: friends.map((f) => [f.uid, f.name]) });
  return q;
}
/** Fill in what the trainer remembered. answers: { when, where, memory | memories[], style, newthing, daytime, touch, love, hate, size, pitch, friends[] } */
export function applyAnswers(c, pk, answers = {}, now = Date.now()) {
  const game = GAME_NAMES[pk.version] ?? 'an older game';
  const tag = (m) => { m.from = 'game'; m.told = true; return m; };
  const sentence = (x) => String(x).trim().replace(/^./, (y) => y.toUpperCase()).replace(/([^.!?])$/, '$1.');
  const when = String(answers.when ?? '').trim(), where = String(answers.where ?? '').trim();
  const yr = /\b(19|20)\d{2}\b/.exec(when)?.[0];
  if (yr && !pk.metDate) c.metAt = new Date(Number(yr), 5, 1).getTime();
  if (when || where) { addMemory(c, `Met ${pk.otName || 'their trainer'}${where ? ` at ${where}` : ''} in ${game}${when ? `, ${when}` : ''}.`, c.metAt ?? now, { core: true }); tag(c.memories.at(-1)); }
  const mems = [answers.memory, ...(answers.memories ?? [])].map((x) => String(x ?? '').trim()).filter(Boolean).slice(0, 3);
  mems.forEach((m, i) => { addMemory(c, sentence(m), (c.metAt ?? now) + 1 + i, { core: true }); tag(c.memories.at(-1)); });
  const style = answers.style || answers.newthing;
  if (style) c.toldStyle = style;
  const prefs = { ...(c.prefs || {}) };
  if (answers.daytime) prefs[answers.daytime] = Math.max(prefs[answers.daytime] ?? 0, 4);
  if (answers.touch === 'love') { prefs['activity:pet'] = 5; prefs['activity:brush'] = 4; }
  if (answers.touch === 'no') { prefs['activity:pet'] = -3; prefs['activity:brush'] = -4; }
  if (answers.love) prefs[answers.love] = 6;
  if (answers.hate && answers.hate !== answers.love) prefs[answers.hate] = -5;
  c.prefs = prefs;
  if (answers.size != null && answers.size !== '' && Number.isFinite(Number(answers.size))) c.sizeScalar = Math.max(0, Math.min(255, Math.round(Number(answers.size))));
  if (answers.pitch != null && answers.pitch !== '' && Number.isFinite(Number(answers.pitch))) c.cryPitch = Math.max(-6, Math.min(6, Number(answers.pitch)));
  if (answers.friends?.length) c.toldFriends = [...new Set(answers.friends)];
  c.pk = { ...(c.pk || {}), answered: true };
  return c;
}

/** The same game save: same original trainer (name and id). */
export function sameSave(a, b) {
  const oa = a?.origin, ob = b?.origin;
  return !!(oa && ob && oa.from === 'pkhex' && ob.from === 'pkhex' && oa.ot && oa.ot === ob.ot && oa.otId === ob.otId);
}

/**
 * Friends from the same game carry on being friends: everyone the trainer named (both ways) starts as
 * friends, and teammates from the same save start out knowing each other a little.
 */
export function linkSaveFriends(save, c, { friendAt = 60, t = Date.now(), nameOf = (x) => x.nickname || 'a teammate' } = {}) {
  const named = new Set(c.toldFriends ?? []);
  for (const o of Object.values(save.creatures ?? {})) {
    if (o.uid === c.uid) continue;
    const both = named.has(o.uid) || (o.toldFriends ?? []).includes(c.uid);
    const base = both ? friendAt + 10 : sameSave(c, o) ? 20 : 0;
    if (!base) continue;
    const v = Math.max(c.bonds?.[o.uid] ?? 0, base);
    (c.bonds = c.bonds || {})[o.uid] = v;
    (o.bonds = o.bonds || {})[c.uid] = Math.max(o.bonds[c.uid] ?? 0, v);
    if (both && !(c.memories ?? []).some((m) => m.friend === o.uid)) {
      addMemory(c, `Old friends with ${nameOf(o)} from ${GAME_NAMES[c.origin?.version] ?? 'their old adventure'}.`, t, { core: true, friend: o.uid });
      addMemory(o, `Old friends with ${nameOf(c)} from ${GAME_NAMES[o.origin?.version] ?? 'their old adventure'}.`, t, { core: true, friend: c.uid });
    }
  }
}
