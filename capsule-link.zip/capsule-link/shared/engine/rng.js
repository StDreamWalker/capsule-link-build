// Small seeded RNG (mulberry32) so battles, walk finds and sprites are reproducible
// on every device that applies the same event.

export function hashString(str) {
  // FNV-1a 32-bit
  let h = 0x811c9dc5;
  const s = String(str);
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

export function createRng(seed = Date.now()) {
  let a = (typeof seed === 'number' ? seed : hashString(seed)) >>> 0;
  const rng = () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  rng.int = (min, max) => min + Math.floor(rng() * (max - min + 1)); // inclusive
  rng.range = (min, max) => min + rng() * (max - min);
  rng.chance = (pct) => rng() * 100 < pct;
  rng.pick = (arr) => arr[Math.floor(rng() * arr.length)];
  rng.state = () => a;
  rng.setState = (s) => { a = s >>> 0; };
  return rng;
}

export function randomId(bytes = 8, rng = Math.random) {
  let out = '';
  for (let i = 0; i < bytes; i++) out += Math.floor(rng() * 256).toString(16).padStart(2, '0');
  return out;
}
