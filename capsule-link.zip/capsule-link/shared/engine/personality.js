// Personality: how a creature tends to behave on its own (in the R.A.N.C.H. and on the desktop), and
// the little field journal you can open during quality time (likes, dislikes, favourites, friends).
//   temper style   playful | lazy | shy | bold | calm   (from its temperament, or its id when it has none)
//   traits         sun-lover, night owl, can't go in water, …   (from its species, types and what it has come to love)
import { favorites, avoidsWater, mood } from './care.js';
import { topPrefs, dislikes, prefLabel } from './memory.js';
import { friendsOf } from './bonds.js';
import { displayName } from './creature.js';
import { quirksOf } from './quirks.js';
import { genreIn } from './lexicon.js';
import { genreTaste } from './music.js';

const STYLE_WORDS = [
  ['playful', /rowdy|eager|cheery|reckless|whimsical|breezy|jolly|naive|hasty|naughty|rash|hardy/],
  ['lazy', /lazy|mellow|dreamy|serene|relaxed|quiet|lax|docile|sassy|placid/],
  ['shy', /skittish|wary|flighty|sulky|timid|careful|bashful|gentle|tender/],
  ['bold', /fierce|gruff|stubborn|prickly|brave|adamant|lonely|impish|bold/],
  ['calm', /steady|sturdy|stoic|wise|earnest|pensive|calm|modest|mild|serious|quirky|bold/],
];
export const TEMPER_STYLE_TEXT = {
  playful: 'Playful: always up for a game, first to chase a toy.',
  lazy: 'Laid-back: loves a nap and takes life slowly.',
  shy: 'Shy: keeps to the edges and warms up slowly.',
  bold: 'Bold: curious, a bit pushy, never backs down.',
  calm: 'Easy-going: content to watch the world go by.',
};

const hashOf = (s) => { let h = 2166136261; for (const ch of String(s)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0; return h; };

/** The broad way a creature behaves, from its temperament. */
export function temperStyle(idx, c) {
  if (c?.toldStyle) return c.toldStyle; // what their trainer remembered (older games didn't keep it)
  const name = `${c?.temper ?? ''} ${idx?.temperaments?.get?.(c?.temper)?.name ?? ''}`.toLowerCase();
  for (const [style, re] of STYLE_WORDS) if (re.test(name)) return style;
  return ['playful', 'lazy', 'shy', 'bold', 'calm'][hashOf(c?.uid) % 5];
}

const typeWords = (idx, sp) => (sp?.types ?? []).flatMap((t) => [String(t).toLowerCase(), String(idx.types?.get(t)?.name ?? '').toLowerCase()]).join(' ');

/** What drives a creature's own little habits. */
export function traitsOf(idx, c) {
  const sp = idx.species.get(c.formId ?? c.speciesId) ?? idx.species.get(c.speciesId);
  const tw = typeWords(idx, sp);
  const p = c.prefs ?? {};
  const night = (p['time:night'] ?? 0) >= 3 || (/dark|shade|ghost|spirit/.test(tw) && (p['time:day'] ?? 0) < 3) || !!sp?.nocturnal;
  const sunLover = (p['weather:sun'] ?? 0) >= 3 || (/fire|ember|grass|sprout/.test(tw) && (p['weather:sun'] ?? 0) > -3);
  const n = c.needs ?? {};
  return {
    temper: temperStyle(idx, c),
    night, sunLover,
    noWater: avoidsWater(idx, c),
    tired: (n.energy ?? 60) < 20,
    full: (n.fullness ?? 50) >= 95,
    upset: mood(c).id === 'upset',
  };
}

const KIND_HEAD = { food: 'Foods', toy: 'Toys', place: 'Places', env: 'Places', weather: 'Weather', time: 'Time of day', activity: 'Things to do', clothes: 'Clothes', feature: 'In the yard', friend: 'Friends' };

/**
 * The field journal: everything you've learned about a creature, sorted.
 * { name, temper, style, favourites: [{ label, value }], likes: { head: [labels] }, dislikes: [labels],
 *   friends: [names], moodLabel, notes: [text] }
 */
import { todayOf } from './dayMemory.js';
import { fluencyOf, fluencyLabel } from './chat.js';
export function journalOf(idx, save, c) {
  const fav = favorites(idx, c);
  const tr = traitsOf(idx, c);
  const p = c.prefs ?? {};
  const best = (prefix) => Object.entries(p).filter(([k, v]) => k.startsWith(prefix) && v >= 1).sort((a, b) => b[1] - a[1])[0]?.[0];
  const found = (key) => !!c.firsts?.[`fav:${key}`];
  const itemName = (id) => idx.items?.get?.(id)?.name ?? String(id ?? '').replace(/-/g, ' ');
  const favourites = [
    { label: 'Favourite berry', value: found(fav.berry) ? itemName(fav.berry) : best('food:') ? prefLabel(best('food:'), idx) : '???', secret: !found(fav.berry) && !best('food:') },
    { label: 'Favourite toy', value: found(fav.toy) ? itemName(fav.toy) : best('toy:') ? prefLabel(best('toy:'), idx) : '???', secret: !found(fav.toy) && !best('toy:') },
    { label: 'Favourite place', value: best('place:') ? prefLabel(best('place:'), idx) : best('env:') ? prefLabel(best('env:'), idx) : '???' },
    { label: 'Favourite time', value: best('time:') ? prefLabel(best('time:'), idx) : tr.night ? 'night (it seems)' : '???' },
    { label: 'Favourite weather', value: best('weather:') ? prefLabel(best('weather:'), idx) : '???' },
    { label: 'In the yard', value: best('feature:') ? prefLabel(best('feature:'), idx) : '???' },
  ];
  const likes = {};
  for (const l of topPrefs(c, idx, 14)) {
    const head = KIND_HEAD[l.key.split(':')[0]] ?? 'Other';
    (likes[head] = likes[head] || []).push(l.label);
  }
  const notes = [];
  if (tr.sunLover) notes.push('Loves to lie in the sun.');
  if (tr.night) notes.push('A night owl: livelier after dark.');
  if (tr.noWater) notes.push('Can’t stand water: brush and comb, never bathe.');
  if ((c.upsetCount ?? 0) >= 3) notes.push('Gets fed up if fussed over too much.');
  if (c.firsts?.reach) notes.push('Once spent ages trying to reach a toy stuck up a tree.');
  return {
    name: displayName(idx, c),
    temper: idx.temperaments?.get?.(c.temper)?.name ?? c.temper ?? '—',
    style: TEMPER_STYLE_TEXT[tr.temper],
    quirks: quirksOf(idx, c),
    favourites,
    likes,
    dislikes: dislikes(c, idx, 8).map((d) => d.label),
    friends: friendsOf(c).slice(0, 6).map((f) => (save?.creatures?.[f.uid] ? displayName(idx, save.creatures[f.uid]) : null)).filter(Boolean),
    // everyone they know, closest first, with how close (including creatures from other trainers' ranches)
    bonds: [
      ...Object.entries(c.bonds ?? {}).filter(([u, v]) => v >= 8 && save?.creatures?.[u]).map(([u, v]) => ({ name: displayName(idx, save.creatures[u]), bond: v, guest: false })),
      ...Object.values(c.guestBonds ?? {}).filter((g) => g.bond >= 2).map((g) => ({ name: g.name, bond: g.bond, guest: true, from: g.trainer, visits: g.visits })),
    ].sort((a, b) => b.bond - a.bond).slice(0, 10).map((b) => ({ ...b, label: b.bond >= 85 ? 'best friends' : b.bond >= 60 ? 'friends' : b.bond >= 30 ? 'getting close' : 'acquaintances' })),
    today: todayOf(idx, save, c),
    understands: fluencyLabel(fluencyOf(idx, c)),
    // the last time they were upset with you: why, and what would help (kept for a few days)
    lastUpset: c.lastUpset && Date.now() - c.lastUpset.t < 3 * 86400000 ? { ...c.lastUpset, now: (c.upsetUntil ?? 0) > Date.now() } : null,
    moodLabel: mood(c).label,
    notes,
  };
}

// ---------- music: what they make of a kind of music ----------
// Everyone has their own ear for it: a lean of their own (from who they are: rowdy ones like it loud, calm ones like it
// soft), shifted by their types, then by how often they've listened to it with you. −1 (not for them) … 1 (loves it).
const LOUD = /rock|metal|punk|edm|techno|house|rap|hip|drum|dubstep|disco|funk|k-?pop|synth/;
const SOFT = /lo-?fi|jazz|classical|ambient|folk|soul|blues|acoustic|soundtrack|r&b|reggae/;
export function musicTaste(idx, c, genre) {
  const g = String(genre ?? '').toLowerCase(); if (!g) return 0;
  // (one taste in music, the same whether it's heard on the desktop or played to it in a chat)
  const known = genreIn(g); if (known && c) return Math.round(genreTaste(idx, c, known) * 100) / 100;
  const sp = idx?.species?.get?.(c?.formId ?? c?.speciesId) ?? idx?.species?.get?.(c?.speciesId);
  const tw = typeWords(idx?.types ? idx : { types: new Map() }, sp), style = temperStyle(idx, c);
  let v = ((hashOf(`${c?.uid}:${g}`) % 1000) / 1000) * 1.1 - 0.45; // their own ear
  if (LOUD.test(g)) v += style === 'playful' || style === 'bold' ? 0.35 : style === 'shy' || style === 'lazy' ? -0.3 : 0;
  if (SOFT.test(g)) v += style === 'lazy' || style === 'calm' || style === 'shy' ? 0.35 : style === 'playful' ? -0.15 : 0;
  if (LOUD.test(g) && /electric|fire|fight|steel|dragon/.test(tw)) v += 0.15;
  if (SOFT.test(g) && /water|fairy|grass|psychic|ghost/.test(tw)) v += 0.15;
  v += Math.min(0.5, (c?.prefs?.[`music:${g}`] ?? 0) * 0.08); // (it grows on them)
  return Math.max(-1, Math.min(1, +v.toFixed(2)));
}
