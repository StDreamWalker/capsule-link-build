// The words they understand: things to do (and every way of saying them: "battle", "battling", "a fight"),
// places in the yard ("the hammock", "the toy box", "the big tree"), prizes ("a walk with me", "an extra
// berry"), and kinds of music. Used by understand.js to work out what you mean.
//
//   activityIn(text)      → the thing to do it mentions: { id, inv, label, ing, act?, pref? } or null
//   activitiesIn(text)    → all of them, in the order they come
//   placesIn(text)        → [{ id, words, at }] places named, in order
//   prizeIn(text)         → { kind, label, item? } what's on offer, or null
//   genreIn(text)         → a kind of music ('rock', 'lofi'…) or null
//   GENRES, ACTS, YARD_PLACES

// Things to do. The first that matches wins, so the particular ones come before the general ones ("play
// fetch" is fetch, not just play). inv: the "who wants to…?" it is (invite.js); act: the activity, when it is
// one; pref: the preference key their experiences of it build up (memory.js).
export const ACTS = [
  { id: 'hideseek', inv: 'hideseek', label: 'play hide-and-seek', ing: 'playing hide-and-seek', re: /\bhid(?:e|ing) ?(?:and|&|n|'n') ?(?:go )?seek|\bhide-and-seek\b|\bpeek ?-?a ?-?boo\b/ },
  { id: 'berries', inv: 'berries', act: 'gardening', label: 'pick berries', ing: 'picking berries', re: /\bpick(?:ing|ed)? (?:some |the )?(?:berr|fruit)|\bberry[- ]picking\b|\bharvest\w*/ },
  { id: 'obstacle', inv: 'obstacle', act: 'obstacle', label: 'run the obstacle course', ing: 'running the obstacle course', re: /\bobstacle\w*|\bagility\b|\bhurdl\w*/ },
  { id: 'scavenging', inv: 'scavenging', act: 'scavenging', label: 'go scavenging', ing: 'scavenging', re: /\bscaveng\w*|\btreasure\b|\bdig(?:ging|s)?\b(?! (?:in|into) (?:the |some )?(?:food|snack))|\bforag\w*|\bmetal detect\w*/ },
  { id: 'fishing', inv: 'fishing', act: 'fishing', label: 'go fishing', ing: 'fishing', re: /\bfish(?:ing|ed|es)?\b/ },
  { id: 'cooking', inv: 'cooking', act: 'cooking', label: 'cook', ing: 'cooking', re: /\bcook\w*|\bbak(?:e|es|ed|ing)\b|\bkitchen\b|\bpoffins?\b|\bcurry\b/ },
  { id: 'gardening', inv: 'gardening', act: 'gardening', label: 'do some gardening', ing: 'gardening', re: /\bgarden\w*|\bplant(?:ing|s)?\b|\bweed(?:ing|s)?\b|\bfarm(?:ing)?\b|\bwater(?:ing)? the (?:plants|flowers)/ },
  { id: 'puzzle', inv: 'puzzle', act: 'puzzle', label: 'do puzzles', ing: 'doing puzzles', re: /\bpuzzl\w*|\briddl\w*|\bbrain ?teasers?\b|\bjigsaw\w*/ },
  { id: 'photography', inv: 'photography', act: 'photography', label: 'pose for photos', ing: 'posing for photos', re: /\bphoto\w*|\bpictures?\b|\bcamera\b|\bselfies?\b|\bpos(?:e|ing) for\b/ },
  { id: 'training', inv: 'training', act: 'training', label: 'train', ing: 'training', pref: 'activity:run', re: /\btrain(?:ing|s|ed)?\b(?! station)|\bpractis\w*|\bpractic\w*|\bwork(?:ing)? ?out\b|\bexercis\w*|\bworkouts?\b/ },
  { id: 'battle', inv: 'battle', label: 'battle', ing: 'battling', pref: 'activity:battle', re: /\bbattl\w*|\bfight\w*|\bduel\w*|\bspar(?:ring|s)?\b|\btake (?:me|someone|them|each other) on\b/ },
  { id: 'race', inv: 'race', label: 'race', ing: 'racing', pref: 'activity:run', re: /\brac(?:e|es|ed|ing)\b|\bsprint\w*|\bfirst (?:one )?to (?:the|reach|get)|\bbeat (?:me|everyone|each other|them) to\b|\bfastest to\b/ },
  { id: 'tug', inv: 'tug', label: 'play tug-of-war', ing: 'playing tug-of-war', re: /\btug(?:-| )?(?:of(?:-| )?)?war\b|\bwrestl\w*|\bplay ?fight\w*/ },
  { id: 'fetch', inv: 'fetch', label: 'play fetch', ing: 'playing fetch', pref: 'activity:fetch', re: /\bfetch\w*|\bfrisbee\b|\bthrow (?:the |a )?(?:ball|stick|disc)\b/ },
  { id: 'tag', inv: 'tag', label: 'play tag', ing: 'playing tag', re: /\b(?:play(?:ing)? )?tag\b|\bchas(?:e|ing) (?:each other|me)\b|\byou'?re it\b|\bcatch me\b|\bzoomies\b/ },
  { id: 'swim', inv: 'swim', label: 'go for a swim', ing: 'swimming', re: /\bswim\w*|\bsplash\w*|\bpaddl\w*|\bdiv(?:e|es|ing)\b|\bsurf(?:ing)?\b/ },
  { id: 'nap', inv: 'nap', label: 'take a nap', ing: 'napping', pref: 'activity:nap', re: /\bnap\w*|\bsleep\w*|\bsnooz\w*|\bsiesta\b|\b(?:get some |have a )rest\b|\bresting\b/ },
  { id: 'walk', inv: 'walk', label: 'go on a walk', ing: 'going on walks', pref: 'activity:walk', re: /\bwalk(?:s|ies|ing)?\b|\bstroll\w*|\bhik(?:e|es|ing)\b|\badventur\w*|\bon my phone\b|\boutside\b/ },
  { id: 'groom', inv: 'groom', label: 'have a bath and a brush', ing: 'bath time', pref: 'activity:bath', re: /\bbath\w*|\bbrush(?:ing|ed)?\b(?! up)|\bgroom\w*|\bwash\w*|\bshampoo\w*|\bpamper\w*/ },
  { id: 'pets', inv: 'pets', label: 'get some pets', ing: 'being petted', pref: 'activity:pet', re: /\bpet(?:s|ted|ting|tings)?\b(?! (?:shop|store))|\bscratch(?:es|ing)?\b|\bbelly rubs?\b|\bhead ?pats?\b|\bchin (?:rubs?|scratch\w*)/ },
  { id: 'hug', inv: 'hug', label: 'have a cuddle', ing: 'cuddling', re: /\bhug\w*|\bcuddl\w*|\bsnuggl\w*/ },
  { id: 'stargaze', inv: 'stargaze', label: 'look at the stars', ing: 'stargazing', re: /\bstar ?gaz\w*|\b(?:the )?stars\b|\bnight sky\b|\bshooting stars?\b|\bthe moon\b/ },
  { id: 'sunbathe', inv: 'sunbathe', label: 'sunbathe', ing: 'sunbathing', re: /\bsun ?bath\w*|\bbask\w*|\bin the sun\b|\bsunny spot\b/ },
  { id: 'campfire', inv: 'campfire', label: 'sit round a campfire', ing: 'sitting round a campfire', re: /\bcamp ?fires?\b|\bbonfires?\b|\bmarshmallows?\b|\bs'?mores?\b/ },
  { id: 'story', inv: 'story', label: 'hear a story', ing: 'stories', re: /\bstor(?:y|ies)\b|\bbooks?\b|\bread(?:ing)? (?:a |some |together|to)|\bfairy ?tales?\b/ },
  { id: 'paint', inv: 'paint', label: 'draw and paint', ing: 'painting', re: /\bpaint\w*|\bdraw(?:ing|s)?\b|\bdoodl\w*|\bcolou?ring\b|\bart\b|\bcrafts?\b/ },
  { id: 'build', inv: 'build', label: 'build something', ing: 'building things', re: /\bsand ?castles?\b|\bbuild(?:ing)? (?:something|a |things)|\bblocks\b|\bforts?\b/ },
  { id: 'climb', inv: 'climb', label: 'climb trees', ing: 'climbing', re: /\bclimb\w*/ },
  { id: 'fly', inv: 'fly', label: 'fly about', ing: 'flying', re: /\bfly(?:ing)?\b|\bsoar\w*|\bglid(?:e|ing)\b/ },
  { id: 'explore', inv: 'explore', label: 'explore the ranch', ing: 'exploring', re: /\bexplor\w*|\blook(?:ing)? around\b|\bsniff(?:ing)? around\b/ },
  { id: 'movie', inv: 'movie', label: 'watch a movie', ing: 'watching movies', re: /\bmovies?\b|\bfilms?\b|\bcinema\b|\bwatch(?:ing)? (?:tv|telly|cartoons|anime|a show)/ },
  { id: 'desktop', inv: 'desktop', label: 'sit on the desktop with you', ing: 'sitting on your desktop', re: /\bdesk ?top\b|\bon my (?:desk|screen)\b|\bkeep me company\b/ },
  { id: 'contest', inv: 'contest', label: 'put on a contest show', ing: 'showing off', re: /\bcontests?\b|\bshow(?:ing)? off\b|\bperform\w*|\btricks\b|\btalent show\b/ },
  { id: 'snow', inv: 'snow', label: 'play in the snow', ing: 'playing in the snow', re: /\bsnow ?balls?\b|\bsled\w*|\bplay(?:ing)? in the snow\b|\bsnowmen\b|\bsnowman\b/ },
  { id: 'puddles', inv: 'puddles', label: 'jump in puddles and leaves', ing: 'jumping in puddles', re: /\bpuddles?\b|\bleaf piles?\b|\bmud\b/ },
  { id: 'bubbles', inv: 'bubbles', label: 'chase bubbles', ing: 'chasing bubbles', re: /\bbubbles?\b/ },
  { id: 'relax', inv: 'relax', label: 'relax together', ing: 'relaxing', re: /\brelax\w*|\bchill(?:ing)?(?: out)?\b|\bunwind\w*|\blazy day\b|\blounging\b/ },
  { id: 'dance', inv: 'dance', label: 'dance', ing: 'dancing', re: /\bdanc\w*|\bboogie\w*|\bgroov(?:e|ing)\b|\bdisco\b/ },
  { id: 'sing', inv: 'sing', label: 'sing together', ing: 'singing', re: /\bsing(?:ing|s)?\b|\bkaraoke\b|\bhumming\b|\bduets?\b/ },
  { id: 'music', inv: 'music', label: 'listen to some music', ing: 'music', re: /\bmusic\b|\bsongs?\b|\btunes?\b|\bconcerts?\b/ },
  { id: 'friends', inv: 'friends', label: 'make friends', ing: 'making friends', re: /\bmak(?:e|ing) friends\b|\bhang(?:ing)? ?out\b|\bplay ?dates?\b/ },
  { id: 'snack', inv: 'snack', label: 'have a snack', ing: 'eating', re: /\bsnack\w*|\beat(?:ing|s)?\b|\bfood\b|\btreats?\b|\bberr(?:y|ies)\b|\blunch\b|\bdinner\b|\bbreakfast\b|\bpicnics?\b/ },
  { id: 'ball', inv: 'ball', label: 'play ball', ing: 'playing ball', re: /\bball\b|\bcatch\b|\bkick ?about\b|\bsoccer\b|\bfootball\b|\bvolleyball\b/ },
  { id: 'play', inv: 'play', label: 'play', ing: 'playing', pref: 'activity:play', re: /\bplay(?:ing|time)?\b|\bgames?\b|\btoys?\b/ },
];
const ACT_BY_ID = Object.fromEntries(ACTS.map((a) => [a.id, a]));
export const actById = (id) => ACT_BY_ID[id] ?? null;

/** The thing to do a phrase is about (the first, most particular match), or null. */
export function activityIn(text) {
  const s = String(text ?? '').toLowerCase();
  for (const a of ACTS) if (a.re.test(s)) return a;
  return null;
}
/** Every thing to do a phrase names, in the order they come in it. */
export function activitiesIn(text) {
  const s = String(text ?? '').toLowerCase(), out = [];
  for (const a of ACTS) { const m = a.re.exec(s); if (m && !out.some((o) => o.a.inv === a.inv)) out.push({ a, at: m.index }); }
  return out.sort((x, y) => x.at - y.at).map((x) => x.a);
}

// Places in (and round) the yard: what you might call them. id: a blueprint id where it's something you build,
// else a kind of scenery or a spot. The yard works out where each one really is.
export const YARD_PLACES = [
  { id: 'toy-chest', re: /\btoy ?(?:box|chest|bin|basket)\b/ },
  { id: 'hammock', re: /\bhammocks?\b/ },
  { id: 'tire-swing', re: /\btyre ?swing\b|\btire ?swing\b/ },
  { id: 'swing', re: /\bswings?\b/ },
  { id: 'slide', re: /\bslides?\b/ },
  { id: 'climber', re: /\bclimbing frame\b|\bjungle gym\b|\bclimber\b/ },
  { id: 'tunnel', re: /\btunnel\b/ },
  { id: 'ball-pit', re: /\bball ?pit\b/ },
  { id: 'trampoline', re: /\btrampolines?\b/ },
  { id: 'seesaw', re: /\bsee-?saws?\b|\bteeter-?totter\b/ },
  { id: 'carousel', re: /\bmerry-?go-?round\b|\bcarousel\b|\broundabout\b/ },
  { id: 'rocking-horse', re: /\brocking (?:horse|ponyta)\b/ },
  { id: 'scratch-post', re: /\bscratching post\b|\bscratch(?:ing)? post\b/ },
  { id: 'perch', re: /\bperch\b/ },
  { id: 'sand-pit', re: /\bsand ?(?:pit|box)\b/ },
  { id: 'sandcastle', re: /\bsand ?castle\b/ },
  { id: 'flower-bed', re: /\bflower ?beds?\b|\bflowers\b/ },
  { id: 'rock-garden', re: /\brock garden\b/ },
  { id: 'hot-spring', re: /\bhot ?springs?\b/ },
  { id: 'mud-wallow', re: /\bmud ?(?:wallow|bath|pit)\b/ },
  { id: 'tall-grass', re: /\btall grass\b|\blong grass\b/ },
  { id: 'cozy-den', re: /\bden\b/ },
  { id: 'bird-nest', re: /\bnest\b/ },
  { id: 'moon-grove', re: /\bgrove\b/ },
  { id: 'mushroom-ring', re: /\bmushroom(?:s| ring)\b|\bfairy ring\b/ },
  { id: 'sun-patch', re: /\bsun ?patch\b|\bsunny spot\b/ },
  { id: 'wishing-well', re: /\bwell\b(?! done)/ },
  { id: 'windmill', re: /\bwindmill\b/ },
  { id: 'sundial', re: /\bsundial\b/ },
  { id: 'picnic-table', re: /\bpicnic table\b|\btable\b/ },
  { id: 'birdhouse', re: /\bbird ?house\b/ },
  { id: 'birdbath', re: /\bbird ?bath\b/ },
  { id: 'fountain', re: /\bfountain\b/ },
  { id: 'topiary', re: /\btopiary\b/ },
  { id: 'signpost', re: /\bsign ?post\b|\bthe sign\b/ },
  { id: 'statue', re: /\bstatue\b/ },
  { id: 'flag', re: /\bflag ?(?:pole)?\b/ },
  { id: 'lanterns', re: /\blanterns?\b|\blamp ?posts?\b/ },
  { id: 'bench', re: /\bbench(?:es)?\b/ },
  { id: 'campfire', re: /\bcamp ?fire\b|\bfire ?pit\b/ },
  { id: 'gazebo', re: /\bgazebo\b|\bshelter\b|\bthe hut\b/ },
  { id: 'pond', re: /\bpond\b|\bthe water\b|\blake\b|\bpool\b/ },
  { id: 'tree', re: /\b(?:big |tall |old |that |the )?trees?\b/ },
  { id: 'rock', re: /\b(?:big )?(?:rock|boulder|stone)s?\b/ },
  { id: 'bush', re: /\bbush(?:es)?\b|\bhedge\b/ },
  { id: 'fence', re: /\bfence\b|\bthe wall\b|\bthe edge\b/ },
  { id: 'farm', re: /\bberry farm\b|\bplanters?\b/ },
  { id: 'back', re: /\b(?:the )?(?:back|far side|other side|far end)\b/ },
  { id: 'middle', re: /\b(?:the )?(?:middle|centre|center)\b/ },
  { id: 'me', re: /\b(?:to |from )?(?:me|here|over here)\b/ },
];
/** Places a phrase names, in the order they come: [{ id, words, at }]. */
export function placesIn(text) {
  const s = String(text ?? '').toLowerCase(), out = [];
  for (const p of YARD_PLACES) {
    const re = new RegExp(p.re.source, 'g');
    let m; while ((m = re.exec(s))) { if (!out.some((o) => m.index >= o.at && m.index < o.at + o.words.length)) out.push({ id: p.id, words: m[0].trim(), at: m.index }); }
  }
  return out.sort((a, b) => a.at - b.at);
}

// What can be offered as a prize ("whoever wins gets …")
const PRIZES = [
  { kind: 'walk', label: 'a walk with you', icon: '🚶', re: /\b(?:go(?:es)? (?:with (?:me|you) )?(?:on|for) (?:a |the )?walk|come (?:with me )?(?:on|for) (?:a |the )?walk|walk(?:ies)? with (?:me|you)|(?:a |the )walk\b|come (?:out )?with me\b|on my phone|go outside with me)/ },
  { kind: 'desktop', label: 'a spot on your desktop', icon: '🖥️', re: /\b(?:sit|go|come|hang out) (?:on|onto) (?:my|the) (?:desk ?top|screen)|\bdesk ?top\b/ },
  { kind: 'pets', label: 'extra pets', icon: '💗', re: /\b(?:extra |lots of |some )?(?:pets|belly rubs?|head ?pats?|scratches|cuddles|hugs?)\b/ },
  { kind: 'choose', label: 'first pick', icon: '👑', re: /\b(?:first pick|to (?:choose|pick|decide) (?:the |what|where|which|dinner|lunch)|picks? (?:the |what |dinner|lunch|where)|choose (?:the |what |dinner|lunch|where))/ },
  { kind: 'food', label: 'a treat', icon: '🍓', re: /\b(?:an? )?(?:extra |special |big )?(?:berr(?:y|ies)|treats?|snacks?|dessert|cake|poffins?|pok[eé] ?puffs?|candy|sweets|food)\b/ },
  { kind: 'toy', label: 'a new toy', icon: '🧸', re: /\b(?:a |the )?(?:new )?toys?\b/ },
  { kind: 'battle', label: 'a place on your battle team', icon: '⚔️', re: /\b(?:on|in|join) my (?:battle )?team\b|\bbattle (?:with|alongside) me\b|\bmy party\b/ },
  { kind: 'nap', label: 'the comfiest napping spot', icon: '🛏️', re: /\b(?:nap|sleep)(?:ping)? (?:spot|next to me|in my bed|by me)\b|\bthe (?:comfy|best) (?:spot|bed)\b/ },
  { kind: 'glory', label: 'bragging rights', icon: '🏆', re: /\bbragging rights\b|\bthe (?:crown|title|trophy|glory)\b|\bto be (?:the )?champion\b/ },
];
/** What's on offer in a phrase: { kind, label, icon, words } or null. */
export function prizeIn(text) {
  const s = String(text ?? '').toLowerCase();
  let best = null;
  for (const p of PRIZES) { const m = p.re.exec(s); if (m && (!best || m.index < best.at)) best = { kind: p.kind, label: p.label, icon: p.icon, words: m[0].trim(), at: m.index }; }
  return best;
}

// Kinds of music, and the words for them
export const GENRES = [
  ['vgm', 'video game music', /\bvideo ?game (?:music|soundtrack|ost)\b|\bvgm\b|\bchiptunes?\b|\b8-?bit\b|\bgame (?:music|soundtrack)s?\b|\bpok[eé]mon (?:music|soundtrack|theme|songs?)\b/],
  ['lofi', 'lo-fi', /\blo-?fi\b|\bchill ?hop\b|\bbeats to (?:study|relax)/],
  ['classical', 'classical music', /\bclassical\b|\borchestra\w*|\bsymphon\w*|\bbeethoven\b|\bmozart\b|\bbach\b|\bchopin\b|\bvivaldi\b|\bopera\b|\bconcertos?\b/],
  ['metal', 'metal', /\b(?:heavy )?metal\b|\bmetalcore\b|\bthrash\b|\bdeath ?core\b/],
  ['punk', 'punk', /\bpunk\b|\bpop[- ]punk\b|\bemo\b/],
  ['rock', 'rock', /\brock(?: music|'n'roll| and roll| n roll)?\b(?! garden| climbing)|\bgrunge\b|\bguitar music\b/],
  ['jazz', 'jazz', /\bjazz\w*|\bswing music\b|\bbig band\b|\bbebop\b/],
  ['blues', 'blues', /\bblues\b/],
  ['edm', 'electronic music', /\bedm\b|\belectronic\b|\btechno\b|\bhouse music\b|\btrance\b|\bdubstep\b|\bdrum (?:and|&|n) bass\b|\bdnb\b|\brave\b/],
  ['synthwave', 'synthwave', /\bsynth ?wave\b|\bretrowave\b|\bvaporwave\b|\b80s synth/],
  ['hiphop', 'hip-hop', /\bhip-? ?hop\b|\brap(?:per|ping)?\b|\btrap music\b/],
  ['rnb', 'R&B', /\br ?(?:&|and|n) ?b\b|\bsoul music\b|\bsoul\b|\bmotown\b/],
  ['kpop', 'K-pop', /\bk-? ?pop\b|\bbts\b|\bblackpink\b/],
  ['jpop', 'J-pop', /\bj-? ?pop\b|\banime (?:music|songs?|openings?|ops?)\b/],
  ['pop', 'pop', /\bpop(?: music| songs?)?\b/],
  ['country', 'country', /\bcountry(?: music)?\b|\bbluegrass\b|\bwestern\b/],
  ['folk', 'folk', /\bfolk\b|\bacoustic\b|\bsea shant(?:y|ies)\b|\bshant(?:y|ies)\b/],
  ['reggae', 'reggae', /\breggae\b|\bska\b|\bdancehall\b/],
  ['latin', 'Latin music', /\blatin\b|\bsalsa\b|\breggaeton\b|\bbossa ?nova\b|\bflamenco\b|\btango\b/],
  ['disco', 'disco and funk', /\bdisco\b|\bfunk\w*/],
  ['ambient', 'ambient music', /\bambient\b|\bnature sounds\b|\brain sounds\b|\bwhite noise\b|\bmeditation music\b/],
  ['piano', 'piano music', /\bpiano\b/],
  ['lullaby', 'lullabies', /\blullab(?:y|ies)\b|\bnursery rhymes?\b/],
  ['indie', 'indie', /\bindie\b|\balt(?:ernative)?(?: rock)?\b|\bshoegaze\b/],
  ['choir', 'choir music', /\bchoir\b|\bchoral\b|\bgospel\b|\bhymns?\b/],
];
export const GENRE_LABEL = Object.fromEntries(GENRES.map(([id, label]) => [id, label]));
/** The kind of music a phrase names, or null. */
export function genreIn(text) {
  const s = String(text ?? '').toLowerCase();
  for (const [id, , re] of GENRES) if (re.test(s)) return id;
  return null;
}

// who plays what (so a song "by Debussy" is known to be classical without being told)
const ARTISTS = [
  ['classical', /\b(?:debussy|beethoven|mozart|bach|chopin|vivaldi|tchaikovsky|brahms|handel|haydn|liszt|schubert|satie|rachmaninoff|strauss|wagner|holst|dvorak|ravel|grieg|elgar|einaudi|yo-yo ma|hans zimmer|john williams)\b/],
  ['vgm', /\b(?:koji kondo|nobuo uematsu|junichi masuda|go ichinose|toby fox|yoko shimomura|c418|lena raine|grant kirkhope|david wise|mick gordon|hitoshi sakimoto)\b/],
  ['rock', /\b(?:queen|the beatles|beatles|led zeppelin|ac\/?dc|pink floyd|the rolling stones|rolling stones|nirvana|foo fighters|guns n'? roses|arctic monkeys|the who|u2|coldplay|oasis|radiohead|the killers|red hot chili peppers|green day|imagine dragons|muse|kiss|aerosmith|bon jovi|the white stripes|fleetwood mac|david bowie|elvis(?: presley)?)\b/],
  ['metal', /\b(?:metallica|iron maiden|black sabbath|slipknot|megadeth|slayer|pantera|tool|system of a down|avenged sevenfold|gojira|dragonforce|sabaton|babymetal|rammstein)\b/],
  ['punk', /\b(?:the clash|ramones|sex pistols|blink[- ]?182|my chemical romance|paramore|fall out boy|sum 41|the offspring)\b/],
  ['pop', /\b(?:taylor swift|ariana grande|dua lipa|katy perry|lady gaga|ed sheeran|billie eilish|harry styles|olivia rodrigo|beyonc[eé]|rihanna|justin bieber|bruno mars|the weeknd|madonna|michael jackson|abba|sabrina carpenter|chappell roan|adele|sia|shakira|miley cyrus|selena gomez|britney spears|one direction|charli xcx|lorde)\b/],
  ['kpop', /\b(?:bts|blackpink|twice|stray kids|newjeans|seventeen|exo|red velvet|aespa|itzy|le sserafim|ive)\b/],
  ['jpop', /\b(?:yoasobi|ado|kenshi yonezu|lisa|utada hikaru|perfume|kyary pamyu pamyu|aimer|radwimps|official hige dandism)\b/],
  ['hiphop', /\b(?:kendrick lamar|drake|eminem|kanye(?: west)?|jay-?z|travis scott|tupac|2pac|biggie|nicki minaj|doja cat|tyler,? the creator|j\.? cole|snoop dogg|outkast|run dmc|missy elliott|lil nas x|post malone)\b/],
  ['edm', /\b(?:daft punk|deadmau5|skrillex|avicii|calvin harris|marshmello|zedd|porter robinson|madeon|martin garrix|the chemical brothers|aphex twin|fred again|kygo|tiesto|david guetta|disclosure|odesza|flume)\b/],
  ['jazz', /\b(?:miles davis|john coltrane|louis armstrong|ella fitzgerald|duke ellington|billie holiday|nina simone|dave brubeck|herbie hancock|thelonious monk|chet baker|frank sinatra|norah jones|michael bubl[eé])\b/],
  ['country', /\b(?:dolly parton|johnny cash|willie nelson|shania twain|garth brooks|luke combs|kacey musgraves|morgan wallen|zach bryan|chris stapleton)\b/],
  ['folk', /\b(?:bob dylan|joni mitchell|simon (?:and|&) garfunkel|mumford (?:and|&) sons|fleet foxes|bon iver|the lumineers|hozier|joan baez|nick drake|iron (?:and|&) wine|sufjan stevens)\b/],
  ['rnb', /\b(?:stevie wonder|marvin gaye|aretha franklin|sza|frank ocean|alicia keys|usher|whitney houston|prince|h\.e\.r\.|daniel caesar)\b/],
  ['reggae', /\b(?:bob marley|peter tosh|jimmy cliff|toots and the maytals|ub40|sean paul)\b/],
  ['disco', /\b(?:bee gees|donna summer|earth,? wind (?:and|&) fire|chic|kool (?:and|&) the gang|gloria gaynor|parliament|funkadelic|james brown)\b/],
  ['synthwave', /\b(?:the midnight|kavinsky|gunship|perturbator|carpenter brut|com truise|fm-84|timecop1983)\b/],
  ['lofi', /\b(?:nujabes|lofi girl|j dilla|tomppabeats|idealism|jinsang)\b/],
  ['indie', /\b(?:tame impala|mitski|phoebe bridgers|vampire weekend|mac demarco|the strokes|beach house|boygenius|clairo|alvvays|the smiths)\b/],
  ['latin', /\b(?:bad bunny|j balvin|rosal[ií]a|karol g|daddy yankee|santana|gloria estefan|buena vista social club|celia cruz)\b/],
];
/** The kind of music an artist plays, when it's one it would know. */
export function artistGenre(artist) {
  const s = String(artist ?? '').toLowerCase();
  if (!s) return null;
  return ARTISTS.find(([, re]) => re.test(s))?.[0] ?? genreIn(s);
}
