// Paste importer for the Data Lab. Accepts:
//  - JSON, or relaxed JavaScript object literals (unquoted keys, single quotes, trailing commas,
//    comments, an "export const X = " prefix)
//  - tables copied from a spreadsheet or web page (tab, comma, semicolon, pipe separated)
//  - plain learnset lines like "Lv. 12  Vine Lash" or "Vine Lash - 12"
// Columns are matched to fields automatically and can be remapped in the UI.
import { slug, STAT_KEYS } from './dataset.js';

// ---------- relaxed object-literal parser ----------
// Reads JSON or JavaScript/TypeScript data files (Showdown's pokedex.ts, moves.ts, learnsets.ts,
// natures.ts paste straight in). Functions inside the data are skipped. Scans in place, so a
// multi-megabyte file takes well under a second.
const SKIP = Symbol('skip');
const RE_IDENT = /[A-Za-z_$][\w$]*/y;
const RE_NUM = /[-+]?(?:0x[0-9a-f]+|\d[\d_]*\.?\d*(?:e[-+]?\d+)?|\.\d+(?:e[-+]?\d+)?|Infinity)/iy;
const RE_WORD = /[A-Za-z_$][\w$.]*/y;
const RE_INT = /\d+(?:\.\d+)?/y;

export function lenientParse(text) {
  let src = String(text).trim();
  // strip a prefix such as "export const Pokedex: import('../sim/dex-species').SpeciesDataTable = "
  // (leading comments and import lines are skipped too)
  if (!/^[[{"']/.test(src)) {
    const prefix = /(?:^|\n)[ \t]*(?:(?:export\s+)?(?:const|let|var)\s+[\w$]+\s*(?::[^=]+)?=|module\.exports\s*=|export\s+default)\s*/.exec(src.slice(0, 20000));
    if (prefix) src = src.slice(prefix.index + prefix[0].length);
  }
  src = src.replace(/;\s*$/, '');
  let i = 0;
  let depth = 0;
  let partial = null; // set when a paste stops part-way through (a copy that got cut off)
  const err = (msg) => {
    const line = src.slice(0, i).split('\n').length;
    throw new Error(`${msg} (line ${line})`);
  };
  const match = (re) => { re.lastIndex = i; const m = re.exec(src); if (m) i += m[0].length; return m ? m[0] : null; };
  const ws = () => {
    for (;;) {
      while (i < src.length && (src[i] === ' ' || src[i] === '\n' || src[i] === '\t' || src[i] === '\r')) i++;
      if (src[i] === '/' && src[i + 1] === '/') { const e = src.indexOf('\n', i); i = e < 0 ? src.length : e; continue; }
      if (src[i] === '/' && src[i + 1] === '*') { const e = src.indexOf('*/', i + 2); i = e < 0 ? src.length : e + 2; continue; }
      break;
    }
  };
  const str = () => {
    const q = src[i++];
    let out = '';
    let start = i;
    while (i < src.length && src[i] !== q) {
      if (src[i] === '\\') {
        out += src.slice(start, i);
        const n = src[i + 1];
        const map = { n: '\n', t: '\t', r: '\r', b: '\b', f: '\f', v: '\v', 0: '\0' };
        if (n === 'u') { out += String.fromCharCode(parseInt(src.substr(i + 2, 4), 16)); i += 6; }
        else { out += map[n] ?? n; i += 2; }
        start = i;
        continue;
      }
      i++;
    }
    if (src[i] !== q) err('Unclosed text in quotes');
    out += src.slice(start, i);
    i++;
    return out;
  };
  /** A "/" starts a regular expression (not a division) after these, or at the start. */
  const regexAllowed = () => {
    let j = i - 1;
    while (j >= 0 && /\s/.test(src[j])) j--;
    if (j < 0) return true;
    if ('(,=:[!&|?{};+-*%<>~^'.includes(src[j])) return true;
    return /\b(return|typeof|case|in|of|delete|void|throw|new)$/.test(src.slice(Math.max(0, j - 7), j + 1));
  };
  const skipRegex = () => {
    i++;
    let cls = false;
    while (i < src.length && src[i] !== '\n') {
      const c = src[i];
      if (c === '\\') { i += 2; continue; }
      if (c === '[') cls = true;
      else if (c === ']') cls = false;
      else if (c === '/' && !cls) { i++; break; }
      i++;
    }
    while (/[a-z]/i.test(src[i] ?? '')) i++;
  };
  /** Skip a (...), {...} or [...] group, minding strings, comments and regular expressions. */
  const skipGroup = () => {
    const open = src[i];
    const close = { '(': ')', '{': '}', '[': ']' }[open];
    if (!close) err('Expected a block');
    let depth = 0;
    while (i < src.length) {
      const ch = src[i];
      if (ch === '"' || ch === "'" || ch === '`') { str(); continue; }
      if (ch === '/' && (src[i + 1] === '/' || src[i + 1] === '*')) { ws(); continue; }
      if (ch === '/' && regexAllowed()) { skipRegex(); continue; }
      if (ch === '(' || ch === '{' || ch === '[') depth++;
      else if (ch === ')' || ch === '}' || ch === ']') { depth--; if (depth === 0) { i++; return; } }
      i++;
    }
    err('Unclosed block');
  };
  /** Skip a function: optional name, (params), optional return type, then { body } or an arrow expression. */
  const skipFunction = () => {
    ws();
    if (src[i] !== '(') match(RE_IDENT);
    ws();
    if (src[i] === '(') skipGroup();
    ws();
    if (src[i] === ':') { // TypeScript return type
      while (i < src.length && src[i] !== '{' && !src.startsWith('=>', i)) i++;
    }
    ws();
    if (src.startsWith('=>', i)) { i += 2; ws(); }
    if (src[i] === '{') { skipGroup(); return SKIP; }
    // expression body: run to the next , } or ] at this depth
    while (i < src.length && src[i] !== ',' && src[i] !== '}' && src[i] !== ']') {
      if ('({['.includes(src[i]) || src[i] === '"' || src[i] === "'" || src[i] === '`') { if ('"\'`'.includes(src[i])) str(); else skipGroup(); } else i++;
    }
    return SKIP;
  };
  const value = () => {
    ws();
    const ch = src[i];
    if (ch === '{') {
      i++;
      const obj = {};
      const top = depth === 0;
      depth++;
      for (;;) {
        const mark = i;
        try {
        ws();
        if (src[i] === '}') { i++; depth--; return obj; }
        let key;
        if (src[i] === '"' || src[i] === "'" || src[i] === '`') key = str();
        else if (/[0-9]/.test(src[i])) key = match(RE_INT);
        else if (src[i] === '[') { i++; ws(); key = String(value()); ws(); if (src[i] !== ']') err('Expected ]'); i++; }
        else if (src.startsWith('...', i)) { i += 3; const spread = value(); if (spread && typeof spread === 'object') Object.assign(obj, spread); ws(); if (src[i] === ',') i++; continue; }
        else {
          key = match(RE_IDENT);
          if (!key) err(`Unexpected "${src[i] ?? 'end of text'}"`);
          ws();
          // "async name()", "get name()", "set name(v)"
          if ((key === 'async' || key === 'get' || key === 'set') && /[A-Za-z_$]/.test(src[i] ?? '')) { key = match(RE_IDENT); ws(); }
        }
        ws();
        if (src[i] === '?') { i++; ws(); } // optional-property marker in TS
        if (src[i] === '(') { skipFunction(); ws(); if (src[i] === ',') i++; continue; } // method: skipped
        if (src[i] !== ':') {
          obj[key] = key; ws(); if (src[i] === ',') i++; continue; // shorthand {foo}
        }
        i++;
        const v = value();
        if (v !== SKIP) obj[key] = v;
        ws();
        if (src.startsWith('as ', i)) { i += 3; match(RE_WORD); ws(); } // "as const"
        if (src[i] === ',') i++;
        else if (src[i] !== '}') err('Expected , or }');
        } catch (e) {
          // in the outermost list, keep every entry read before the problem
          if (!top || !Object.keys(obj).length) throw e;
          partial = { message: e.message, at: mark, kept: Object.keys(obj).length };
          depth = 0;
          return obj;
        }
      }
    }
    if (ch === '[') {
      i++;
      const arr = [];
      for (;;) {
        ws();
        if (src[i] === ']') { i++; return arr; }
        const v = value();
        if (v !== SKIP) arr.push(v);
        ws();
        if (src[i] === ',') i++;
        else if (src[i] !== ']') err('Expected , or ]');
      }
    }
    if (ch === '"' || ch === "'" || ch === '`') return str();
    if (ch === '(') return skipFunction(); // arrow function
    const num = match(RE_NUM);
    if (num) return Number(num.replace(/_/g, ''));
    const word = match(RE_WORD);
    if (word) {
      if (word === 'true') return true;
      if (word === 'false') return false;
      if (word === 'null' || word === 'undefined') return null;
      if (word === 'function' || word === 'async') return skipFunction();
      ws();
      if (src.startsWith('=>', i)) return skipFunction(); // x => …
      return word; // bare identifiers become text
    }
    err(`Unexpected "${ch ?? 'end of text'}"`);
  };
  const out = value();
  if (partial) {
    Object.defineProperty(out, '__partial', { value: partial, enumerable: false });
    return out;
  }
  ws();
  if (i < src.length) err('Extra text after the data');
  return out;
}

// ---------- flatten objects to columns ----------
function flatten(obj, prefix = '', out = {}) {
  for (const [k, v] of Object.entries(obj ?? {})) {
    const key = prefix ? `${prefix}.${k}` : k;
    if (Array.isArray(v)) {
      if (v.every((x) => x == null || typeof x !== 'object')) {
        out[key] = v;
        v.forEach((x, j) => { out[`${key}.${j}`] = x; });
      } else out[key] = v; // arrays of objects stay intact (e.g. learnsets)
    } else if (v && typeof v === 'object') flatten(v, key, out);
    else out[key] = v;
  }
  return out;
}

// ---------- tables ----------
function splitCsvLine(line, delim) {
  const out = [];
  let cur = '', q = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (q) {
      if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; }
      else if (ch === '"') q = false;
      else cur += ch;
    } else if (ch === '"' && cur.trim() === '') { q = true; cur = ''; }
    else if (ch === delim) { out.push(cur); cur = ''; }
    else cur += ch;
  }
  out.push(cur);
  return out.map((s) => s.trim());
}

export function parseTable(text) {
  let lines = String(text).replace(/\r/g, '').split('\n').filter((l) => l.trim() !== '');
  if (!lines.length) return { columns: [], rows: [] };
  let cells;
  const pipes = lines.filter((l) => l.includes('|')).length > lines.length / 2;
  if (lines.some((l) => l.includes('\t'))) cells = lines.map((l) => l.split('\t').map((s) => s.trim()));
  else if (pipes) {
    lines = lines.filter((l) => !/^\s*\|?\s*:?-{2,}/.test(l));
    cells = lines.map((l) => l.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map((s) => s.trim()));
  } else {
    const counts = (d) => lines.slice(0, 10).map((l) => splitCsvLine(l, d).length);
    const steady = (d) => { const c = counts(d); return c[0] > 1 && c.every((x) => x === c[0]); };
    if (steady(',')) cells = lines.map((l) => splitCsvLine(l, ','));
    else if (steady(';')) cells = lines.map((l) => splitCsvLine(l, ';'));
    else cells = lines.map((l) => l.trim().split(/\s{2,}/));
  }
  const width = Math.max(...cells.map((r) => r.length));
  const first = cells[0];
  const numericish = first.filter((c) => /^[-+]?\d+(\.\d+)?%?$/.test(c)).length;
  const hasHeader = numericish < Math.max(1, first.length / 2);
  let columns = hasHeader ? first.map((h, i) => h || `Column ${i + 1}`) : Array.from({ length: width }, (_, i) => `Column ${i + 1}`);
  // de-duplicate repeated headers (e.g. two "Type" columns)
  const seen = {};
  columns = columns.map((c) => { seen[c] = (seen[c] ?? 0) + 1; return seen[c] > 1 ? `${c} ${seen[c]}` : c; });
  const body = hasHeader ? cells.slice(1) : cells;
  // tables pasted from web pages often repeat the header row
  const rows = body.filter((r) => r.join('|') !== first.join('|')).map((r) => Object.fromEntries(columns.map((c, i) => [c, r[i] ?? ''])));
  return { columns, rows };
}

// ---------- detection ----------
export function parsePaste(text) {
  const t = String(text ?? '').trim();
  if (!t) return { format: 'empty', rows: [], columns: [] };
  // skip leading comments and import lines when deciding whether this is code
  const head = t.replace(/^(?:\s*(?:\/\/[^\n]*|\/\*[\s\S]*?\*\/|import\b[^\n]*))+\s*/, '');
  if (/^[[{]/.test(head) || /^(export|const|let|var|module\.exports)\b/.test(head)) {
    let data;
    try { data = JSON.parse(t); } catch { data = lenientParse(t); }
    const out = fromData(data);
    if (data?.__partial) out.partial = data.__partial;
    return out;
  }
  const table = parseTable(t);
  if (table.columns.length >= 2) return { format: 'table', ...table };
  return { format: 'lines', rows: t.split('\n').map((line) => ({ line: line.trim() })).filter((r) => r.line), columns: ['line'] };
}

/** Showdown learnset codes: "9L12" = generation 9, level-up at 12. */
const LEARN_CODE = /^(\d+)L(\d+)$/;

/** Showdown's learnsets.ts: { bulbasaur: { learnset: { tackle: ["9L1", "8L1"], ... } } } */
function showdownLearnsets(data) {
  const rows = [];
  for (const [species, entry] of Object.entries(data)) {
    const ls = entry?.learnset;
    if (!ls || typeof ls !== 'object') continue;
    // use the newest generation in which this species learns anything by level
    let gen = 0;
    for (const codes of Object.values(ls)) for (const c of codes ?? []) { const m = LEARN_CODE.exec(c); if (m) gen = Math.max(gen, Number(m[1])); }
    if (!gen) continue;
    for (const [move, codes] of Object.entries(ls)) {
      const levels = new Set();
      for (const c of codes ?? []) { const m = LEARN_CODE.exec(c); if (m && Number(m[1]) === gen) levels.add(Number(m[2])); }
      for (const level of levels) rows.push({ species, level, move });
    }
  }
  return rows;
}

function fromData(data) {
  if (data && !Array.isArray(data) && Array.isArray(data.species) && Array.isArray(data.moves)) {
    return { format: 'dataset', data, rows: [], columns: [] };
  }
  if (data && typeof data === 'object' && !Array.isArray(data)) {
    const sample = Object.values(data).slice(0, 20);
    if (sample.some((v) => v?.learnset && typeof v.learnset === 'object' && Object.values(v.learnset).some((x) => Array.isArray(x)))) {
      const rows = showdownLearnsets(data);
      return { format: 'learnsets', target: 'learnset', rows, columns: ['species', 'level', 'move'] };
    }
    if (sample.length && sample.every((v) => v && typeof v === 'object' && ('plus' in v || 'minus' in v || (Object.keys(v).length === 1 && v.name)))) {
      const rows = Object.entries(data).map(([k, v]) => ({ key: k, name: v.name ?? k, plus: v.plus ?? '', minus: v.minus ?? '' }));
      return { format: 'json', target: 'temperaments', rows, columns: ['key', 'name', 'plus', 'minus'] };
    }
  }
  let list;
  if (Array.isArray(data)) list = data.map((x) => (x && typeof x === 'object' ? x : { value: x }));
  else if (data && typeof data === 'object') {
    const vals = Object.values(data);
    if (vals.length && vals.every((v) => v && typeof v === 'object' && !Array.isArray(v))) {
      list = Object.entries(data).map(([k, v]) => ({ key: k, ...v }));
    } else {
      // a single wrapper key holding the list, e.g. { "moves": [...] }
      const arr = vals.find((v) => Array.isArray(v) && v.length && typeof v[0] === 'object');
      list = arr ?? [data];
    }
  } else list = [];
  const rows = list.map((x) => flatten(x));
  const columns = [];
  for (const r of rows.slice(0, 200)) for (const k of Object.keys(r)) if (!columns.includes(k)) columns.push(k);
  return { format: 'json', rows, columns, raw: list };
}

// ---------- field matching ----------
const norm = (s) => String(s).toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');

export const TARGETS = {
  species: {
    label: 'Species',
    fields: {
      name: ['name', 'species', 'creature', 'monster', 'mon', 'key'],
      no: ['no', 'num', 'number', 'dex', 'dexno', 'ndex', 'nationaldex', 'index'],
      type1: ['type1', 'primarytype', 'types0', 'type', 'types', 'typing'],
      type2: ['type2', 'secondarytype', 'types1'],
      hp: ['hp', 'basehp', 'basestatshp', 'statshp', 'hitpoints'],
      atk: ['atk', 'attack', 'att', 'basestatsatk', 'statsatk', 'basestatsattack'],
      def: ['def', 'defense', 'defence', 'basestatsdef', 'statsdef', 'basestatsdefense'],
      spa: ['spa', 'spatk', 'spattack', 'specialattack', 'satk', 'spatt', 'basestatsspa', 'statsspa', 'spcatk'],
      spd: ['spd', 'spdef', 'spdefense', 'specialdefense', 'sdef', 'basestatsspd', 'statsspd', 'spcdef'],
      spe: ['spe', 'speed', 'spd2', 'basestatsspe', 'statsspe', 'basestatsspeed', 'agility'],
      growthRate: ['growthrate', 'growth', 'expgroup', 'experiencegroup', 'levelingrate', 'levellingrate', 'expcurve'],
      baseExp: ['baseexp', 'expyield', 'baseexperience', 'exp', 'baseexpyield'],
      baseFriendship: ['basefriendship', 'friendship', 'basehappiness', 'happiness'],
      flavor: ['flavor', 'flavortext', 'description', 'desc', 'entry', 'dexentry', 'notes'],
      habitat: ['habitat', 'biome', 'home'],
      cry: ['cry', 'call', 'sound'],
      height: ['height', 'heightm'],
      weight: ['weight', 'weightkg'],
      ability1: ['ability1', 'abilities0', 'ability', 'primaryability', 'abilities', 'ab1'],
      ability2: ['ability2', 'abilities1', 'secondaryability', 'ab2'],
      abilityH: ['hiddenability', 'abilitiesh', 'abilityh', 'ha', 'abilityhidden'],
      showdownName: ['showdownname', 'showdown', 'psname'],
      evolvesTo: ['evolvesto', 'evolvesinto', 'evolution', 'evo', 'evos', 'evos0', 'nextstage'],
      evolveLevel: ['evolvelevel', 'evolevel', 'evolutionlevel', 'evolvesat', 'evolevelup'],
      prevo: ['prevo', 'evolvesfrom', 'preevolution', 'prevolution'],
      evoType: ['evotype', 'evolutiontype', 'evomethod', 'evolutionmethod'],
      effortHp: ['evhp', 'effortvalueshp', 'evyieldhp', 'hpev', 'efforthp'],
      effortAtk: ['evatk', 'evattack', 'evyieldatk', 'atkev', 'effortatk'],
      effortDef: ['evdef', 'evdefense', 'evyielddef', 'defev', 'effortdef'],
      effortSpa: ['evspa', 'evspatk', 'evyieldspa', 'spaev', 'effortspa'],
      effortSpd: ['evspd', 'evspdef', 'evyieldspd', 'spdev', 'effortspd'],
      effortSpe: ['evspe', 'evspeed', 'evyieldspe', 'speev', 'effortspe'],
    },
  },
  moves: {
    label: 'Moves',
    fields: {
      name: ['name', 'move', 'movename', 'attack', 'technique', 'skill', 'key'],
      no: ['no', 'num', 'number', 'index', 'id'],
      type: ['type', 'element', 'movetype'],
      category: ['category', 'cat', 'class', 'damageclass', 'kind', 'split', 'movecategory'],
      power: ['power', 'pow', 'bp', 'basepower', 'pwr', 'damage', 'dmg', 'strength'],
      accuracy: ['accuracy', 'acc', 'hitchance', 'accuracy%'],
      pp: ['pp', 'uses', 'powerpoints', 'maxpp'],
      priority: ['priority', 'prio', 'speedpriority'],
      effectChance: ['effectchance', 'probability', 'prob', 'chance', 'secondarychance', 'effect%'],
      desc: ['description', 'desc', 'effect', 'shortdesc', 'flavor', 'notes'],
      showdownName: ['showdownname', 'showdown', 'psname'],
    },
  },
  items: {
    label: 'Items',
    fields: {
      name: ['name', 'item', 'itemname', 'key'],
      desc: ['shortdesc', 'desc', 'description', 'effect'],
    },
  },
  temperaments: {
    label: 'Natures (temperaments)',
    fields: {
      name: ['name', 'nature', 'temperament', 'key'],
      up: ['plus', 'up', 'raises', 'increased', 'increases', 'boost', 'raisedstat'],
      down: ['minus', 'down', 'lowers', 'decreased', 'decreases', 'hinder', 'loweredstat'],
      showdownName: ['showdownname', 'showdown', 'psname'],
    },
  },
  learnset: {
    label: 'Learnset',
    fields: {
      species: ['species', 'creature', 'monster', 'mon', 'learner'],
      level: ['level', 'lv', 'lvl', 'learnlevel', 'at', 'learnedat', 'lvlearned'],
      move: ['move', 'movename', 'name', 'attack', 'technique', 'skill'],
    },
  },
};

/** Guess which column feeds which field. Returns { field: column }. */
export function guessMapping(columns, target) {
  const def = TARGETS[target];
  const mapping = {};
  const used = new Set();
  const normCols = columns.map((c) => ({ c, n: norm(c), last: norm(String(c).split('.').pop()) }));
  // special case: "Spd" next to a "Speed" column means special defense; next to "SpDef" it means speed
  const hasSpeed = normCols.some((x) => x.n === 'speed' || x.last === 'speed' || x.last === 'spe');
  const hasSpDef = normCols.some((x) => ['spdef', 'spdefense', 'specialdefense', 'sdef'].includes(x.last));
  for (const [field, aliases] of Object.entries(def.fields)) {
    // whole column names first ("desc"), then the last part of nested ones ("secondary.chance"),
    // so a nested "zMove.effect" never wins over a real description column
    let found = null;
    for (const test of [(x, a) => x.n === a, (x, a) => x.last === a && !x.c.includes('.'), (x, a) => x.last === a, (x, a) => a.length > 3 && x.n.endsWith(a)]) {
      for (const a of aliases) { found = normCols.find((x) => !used.has(x.c) && test(x, a)); if (found) break; }
      if (found) break;
    }
    if (found && field === 'desc' && /^(zmove|maxmove|self|secondary|condition)\./i.test(found.c)) found = null;
    if (field === 'spd' && found && found.last === 'spd' && hasSpDef && !hasSpeed) found = null;
    if (field === 'spe' && !found && hasSpDef) found = normCols.find((x) => !used.has(x.c) && x.last === 'spd');
    if (found) { mapping[field] = found.c; used.add(found.c); }
  }
  if (!mapping.name) {
    // fall back to the first column that holds words
    const cand = normCols.find((x) => !used.has(x.c) && !/^(no|num|number|id|#)$/.test(x.n));
    if (cand) mapping.name = cand.c;
  }
  // a single "types" column holding arrays or "A/B" fills both type slots
  if (mapping.type1 && !mapping.type2 && /types?$/.test(norm(mapping.type1))) mapping.type2 = `${mapping.type1}#2`;
  return mapping;
}

function cell(row, col) {
  if (!col) return undefined;
  if (col.endsWith('#2')) {
    const v = row[col.slice(0, -2)];
    const parts = Array.isArray(v) ? v : String(v ?? '').split(/\s*[/,|&]\s*|\s+(?=[A-Z])/).filter(Boolean);
    return parts[1];
  }
  const v = row[col];
  if (Array.isArray(v)) return v[0];
  return v;
}

const toNum = (v) => {
  if (v == null || v === '' || v === '—' || v === '-' || v === '–' || v === '∞') return null;
  if (v === true) return null;
  const n = parseFloat(String(v).replace(/[,%×x]/g, ''));
  return Number.isFinite(n) ? n : null;
};

function splitTypes(v) {
  if (Array.isArray(v)) return v;
  return String(v ?? '').split(/\s*[/,|&]\s*/).filter(Boolean);
}

function resolveType(ds, value, report) {
  if (value == null || value === '') return null;
  const raw = String(value).trim();
  const key = slug(raw);
  let t = ds.types.find((x) => x.id === key || slug(x.name) === key);
  if (!t) {
    t = { id: key, name: raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase(), color: typeColorFor(key) };
    ds.types.push(t);
    report.warnings.push(`Added new type "${t.name}" (pick its colour on the Types tab).`);
  }
  return t.id;
}

function typeColorFor(key) {
  let h = 0;
  for (const ch of key) h = (h * 31 + ch.charCodeAt(0)) % 360;
  return hsl(h, 55, 58);
}
function hsl(h, s, l) {
  s /= 100; l /= 100;
  const k = (n) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return '#' + [f(0), f(8), f(4)].map((x) => Math.round(x * 255).toString(16).padStart(2, '0')).join('');
}

function normCategory(v, power) {
  const s = norm(v ?? '');
  if (/^(stat|other|support|non|buff)/.test(s)) return 'status';
  if (/^(phys|melee)/.test(s) || s === 'p' || s === 'atk') return 'physical';
  if (/^(spec|magic|ranged)/.test(s) || s === 's' || s === 'sp') return 'special';
  return power > 0 ? 'physical' : 'status';
}

/** Common names for the standard curves, so pasted "Medium Fast" or "medium-slow" just work. */
const GROWTH_ALIASES = {
  quick: ['fast'], steady: ['mediumfast', 'medium'], slow: ['slow'], wavy: ['mediumslow', 'parabolic'],
  erratic: ['erratic'], fluctuating: ['fluctuating'],
};
function normGrowth(ds, v, report) {
  if (v == null || v === '') return undefined;
  const key = slug(v);
  const compact = compactId(v);
  const g = ds.growthRates.find((x) => x.id === key || slug(x.name) === key || compactId(x.name) === compact);
  if (g) return g.id;
  for (const [id, names] of Object.entries(GROWTH_ALIASES)) {
    if (names.includes(compact) && ds.growthRates.some((x) => x.id === id)) return id;
  }
  const nice = String(v).trim();
  ds.growthRates.push({ id: key, name: nice, formula: 'n^3' });
  report.warnings.push(`Added growth rate "${nice}" with a placeholder curve (n^3). Paste its real formula on the Growth tab.`);
  return key;
}

/** Ids compared without spaces, dashes or punctuation ("Mr. Mime", "mr-mime" and "mrmime" match). */
const compactId = (s) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '');

function lookup(list) {
  const map = new Map();
  for (const x of list) for (const k of [x.id, compactId(x.id), compactId(x.name), x.showdownName && compactId(x.showdownName)]) if (k && !map.has(k)) map.set(k, x);
  return {
    get: (name) => map.get(String(name)) ?? map.get(compactId(name)),
    add: (x) => { for (const k of [x.id, compactId(x.id), compactId(x.name)]) if (k && !map.has(k)) map.set(k, x); },
  };
}
function findMove(ds, name) { return lookup(ds.moves).get(name); }
function findSpecies(ds, name) {
  const n = Number(name);
  return lookup(ds.species).get(name) ?? (Number.isFinite(n) ? ds.species.find((s) => s.no === n) : undefined);
}

/**
 * Apply rows to a dataset (the dataset object is changed in place).
 * opts: { mode: 'merge'|'replace', speciesId (learnset target), clearLearnset, mainOnly (skip alternate forms) }
 */
export function applyImport(ds, target, rows, mapping, opts = {}) {
  const report = { added: 0, updated: 0, skipped: 0, warnings: [] };
  if (target === 'species') importSpecies(ds, rows, mapping, opts, report);
  else if (target === 'moves') importMoves(ds, rows, mapping, opts, report);
  else if (target === 'learnset') importLearnset(ds, rows, mapping, opts, report);
  else if (target === 'temperaments') importTemperaments(ds, rows, mapping, opts, report);
  else if (target === 'typeChart') importTypeChart(ds, rows, mapping, opts, report);
  else if (target === 'items') importItems(ds, rows, mapping, opts, report);
  if (report.warnings.length > 60) {
    const extra = report.warnings.length - 60;
    report.warnings = [...report.warnings.slice(0, 60), `…and ${extra} more.`];
  }
  return report;
}

/** Alternate forms (Mega, Gmax, regional…) and unofficial entries in Showdown-style data. */
function isAlternate(row) {
  const num = Number(row.num ?? row.no ?? 1);
  if (Number.isFinite(num) && num <= 0) return true;
  // real forms (Deoxys-Speed, Castform-Sunny) and regional variants (Corsola-Galar) are kept;
  // only Mega, Gigantamax, Primal and Totem versions are left out
  const forme = `${row.forme ?? ''} ${row.name ?? ''}`;
  if ((row.baseSpecies || row.forme) && /\b(mega|gmax|gigantamax|primal|totem|eternamax)\b/i.test(forme)) return true;
  const ns = String(row.isNonstandard ?? '');
  return /^(CAP|Custom|LGPE|Future)$/i.test(ns);
}

/** Hands out numbers: keeps a row's own number unless another species in this import took it. */
function numberer(list, report, label) {
  let next = list.reduce((m, x) => Math.max(m, x.no || 0), 0);
  const taken = new Map(list.map((x) => [x.no, x]));
  const seen = new Set();
  let moved = 0;
  return {
    assign(item, wanted) {
      if (wanted && wanted > 0) {
        const owner = taken.get(wanted);
        if (owner && owner !== item && seen.has(owner)) {
          // a form sharing its base species' number: give it a free one
          item.no = Math.max(10001, next + 1);
          moved++;
        } else {
          if (owner && owner !== item) { owner.no = Math.max(10001, next + 1); next = owner.no; taken.set(owner.no, owner); }
          item.no = wanted;
        }
      } else if (!item.no) item.no = next + 1;
      next = Math.max(next, item.no);
      taken.set(item.no, item);
      seen.add(item);
    },
    done() { if (moved) report.warnings.push(`${moved} ${label} shared a number with another entry and were given numbers from 10001 up.`); },
  };
}

function importSpecies(ds, rows, map, opts, report) {
  if (opts.mode === 'replace') ds.species = [];
  const evoLinks = [];
  const find = lookup(ds.species);
  const nums = numberer(ds.species, report, 'species');
  let forms = 0;
  const canCreateSpecies = !!(map.type1 || map.type2 || STAT_KEYS.some((k) => map[k]));
  const notInList = [];
  const effortCols = { hp: map.effortHp, atk: map.effortAtk, def: map.effortDef, spa: map.effortSpa, spd: map.effortSpd, spe: map.effortSpe };
  for (const row of rows) {
    const name = cell(row, map.name);
    if (!name || !String(name).trim()) { report.skipped++; continue; }
    if (opts.mainOnly && isAlternate(row)) { forms++; report.skipped++; continue; }
    const id = slug(name);
    let sp = find.get(id) ?? find.get(name);
    if (sp && sp.id !== id && compactId(sp.name) !== compactId(name)) sp = null;
    const isNew = !sp;
    // a table without types or stats (e.g. base exp and growth only) updates species, never adds them
    if (isNew && !canCreateSpecies) { notInList.push(String(name).trim()); report.skipped++; continue; }
    if (isNew) {
      sp = { id, name: String(name).trim(), no: 0, types: [], baseStats: { hp: 50, atk: 50, def: 50, spa: 50, spd: 50, spe: 50 },
        growthRate: ds.growthRates.find((g) => g.id === 'steady')?.id ?? ds.growthRates[0]?.id, baseExp: 64, baseFriendship: 70, effortYield: {}, habitat: 'meadow', cry: '', flavor: '', learnset: [], evolutions: [] };
      ds.species.push(sp);
      find.add(sp);
    }
    sp.name = String(name).trim();
    nums.assign(sp, toNum(cell(row, map.no)));
    // types
    let types = [];
    const t1 = cell(row, map.type1);
    if (map.type1 && Array.isArray(row[map.type1])) types = row[map.type1];
    else if (t1 != null) types = splitTypes(t1);
    const t2 = cell(row, map.type2);
    if (t2 && types.length < 2) types.push(t2);
    const resolved = types.map((t) => resolveType(ds, t, report)).filter(Boolean);
    if (resolved.length) sp.types = [...new Set(resolved)].slice(0, 2);
    if (!sp.types.length) sp.types = [ds.types[0]?.id];
    for (const k of STAT_KEYS) {
      const v = toNum(cell(row, map[k]));
      if (v != null) sp.baseStats[k] = v;
      const ev = toNum(cell(row, effortCols[k]));
      if (ev != null) { if (ev) sp.effortYield[k] = ev; else delete sp.effortYield[k]; }
    }
    const g = normGrowth(ds, cell(row, map.growthRate), report);
    if (g) sp.growthRate = g;
    for (const f of ['baseExp', 'baseFriendship', 'height', 'weight']) {
      const v = toNum(cell(row, map[f]));
      if (v != null) sp[f] = v;
    }
    const abil = [];
    for (const f of ['ability1', 'ability2', 'abilityH']) {
      const v = cell(row, map[f]);
      if (v != null && v !== '') abil.push(...(f === 'ability1' && /[,/]/.test(String(v)) ? String(v).split(/\s*[,/]\s*/) : [String(v)]));
    }
    if (map.ability1 && Array.isArray(row[map.ability1])) abil.splice(0, abil.length, ...row[map.ability1]);
    if (abil.length) sp.abilities = [...new Set(abil.map((a) => String(a).trim()).filter(Boolean))];
    for (const f of ['flavor', 'habitat', 'cry', 'showdownName']) {
      const v = cell(row, map[f]);
      if (v != null && v !== '') sp[f] = String(v);
    }
    // forms: which species they belong to, and whether they only exist mid-battle
    if (row.baseSpecies && String(row.baseSpecies).trim()) sp.baseSpecies = slug(row.baseSpecies);
    if (row.forme && String(row.forme).trim()) sp.forme = String(row.forme).trim();
    if (row.battleOnly) sp.battleOnly = true;
    if (row.requiredItem) sp.requiredItem = String(row.requiredItem);
    // a pasted object may carry its own learnset array
    const rawLearn = row.learnset ?? row.learnSet;
    if (Array.isArray(rawLearn) && rawLearn.length && typeof rawLearn[0] === 'object') {
      sp.learnset = rawLearn.map((l) => ({ level: toNum(l.level ?? l.lv ?? l.lvl) ?? 1, move: findMove(ds, l.move ?? l.name)?.id ?? slug(l.move ?? l.name) }));
    }
    // evolutions: either "evolves into X at L" on this row, or "evolves from X at L" (Showdown's prevo + evoLevel)
    const evoLevel = toNum(cell(row, map.evolveLevel));
    const evoType = String(cell(row, map.evoType) ?? '');
    const prevo = cell(row, map.prevo);
    if (prevo) evoLinks.push({ from: prevo, to: sp, level: evoLevel, type: evoType });
    else {
      const evo = cell(row, map.evolvesTo);
      if (evo) evoLinks.push({ from: sp, to: evo, level: evoLevel, type: evoType });
    }
    if (isNew) report.added++; else report.updated++;
  }
  nums.done();
  if (forms) report.warnings.push(`Skipped ${forms} alternate forms and unofficial entries (untick "Skip alternate forms" to keep them).`);
  if (notInList.length) report.warnings.push(`${notInList.length} rows name species that are not in your list, and this table has no types or stats to create them from (skipped): ${notInList.slice(0, 10).join(', ')}${notInList.length > 10 ? '…' : ''}`);
  const special = [];
  for (const link of evoLinks) {
    const from = typeof link.from === 'string' ? find.get(link.from) : link.from;
    const to = typeof link.to === 'string' ? find.get(link.to) : link.to;
    if (!from || !to) continue; // the other stage was skipped or is not in the list
    let evo;
    if (/friend|happiness/i.test(link.type)) evo = { to: to.id, method: 'friendship', value: 220 };
    else if (link.level) evo = { to: to.id, method: 'level', value: link.level };
    else { special.push(`${from.name} → ${to.name}`); evo = { to: to.id, method: 'friendship', value: 220 }; }
    from.evolutions = [...(from.evolutions ?? []).filter((e) => e.to !== to.id), evo];
  }
  if (special.length) report.warnings.push(`${special.length} evolutions use an item, a trade or something else; they were set to "at friendship 220" for now: ${special.slice(0, 8).join(', ')}${special.length > 8 ? '…' : ''}`);
}

function importMoves(ds, rows, map, opts, report) {
  if (opts.mode === 'replace') ds.moves = [];
  const find = lookup(ds.moves);
  const nums = numberer(ds.moves, report, 'moves');
  const canCreate = !!(map.type || map.power || map.category);
  let notInList = 0;
  for (const row of rows) {
    const name = cell(row, map.name);
    if (!name || !String(name).trim()) { report.skipped++; continue; }
    if (opts.mainOnly && /^(CAP|Custom|LGPE|Future)$/i.test(String(row.isNonstandard ?? ''))) { report.skipped++; continue; }
    const id = slug(name);
    let mv = find.get(id) ?? find.get(name);
    const isNew = !mv;
    if (isNew && !canCreate) { notInList++; report.skipped++; continue; }
    if (isNew) { mv = { id, name: String(name).trim(), no: 0, type: ds.types[0]?.id, category: 'physical', power: 0, accuracy: 100, pp: 20, priority: 0 }; ds.moves.push(mv); find.add(mv); }
    mv.name = String(name).trim();
    nums.assign(mv, toNum(cell(row, map.no)));
    const type = cell(row, map.type);
    if (type) mv.type = resolveType(ds, type, report);
    const power = toNum(cell(row, map.power));
    if (map.power) mv.power = power ?? 0;
    if (map.category) mv.category = normCategory(cell(row, map.category), mv.power);
    else if (isNew) mv.category = mv.power > 0 ? 'physical' : 'status';
    if (map.accuracy) {
      const raw = row[map.accuracy];
      mv.accuracy = raw === true ? null : toNum(raw);
      if (mv.accuracy != null && mv.accuracy <= 1 && mv.accuracy > 0 && String(raw).includes('.')) mv.accuracy *= 100;
    }
    const pp = toNum(cell(row, map.pp));
    if (pp != null) mv.pp = pp;
    const pr = toNum(cell(row, map.priority));
    if (pr != null) mv.priority = pr;
    const desc = cell(row, map.desc);
    if (desc) mv.desc = String(desc);
    const sdn = cell(row, map.showdownName);
    if (sdn) mv.showdownName = String(sdn).trim();
    if (isNew) report.added++; else report.updated++;
  }
  nums.done();
  if (notInList) report.warnings.push(`${notInList} rows name moves that are not in your list, and this table has no type, power or category to create them from (skipped).`);
}

export function parseLearnsetLines(text) {
  const out = [];
  for (let line of String(text).split('\n')) {
    line = line.trim();
    if (!line) continue;
    let m = /^(?:lv\.?|lvl\.?|level|l)?\s*(\d+|start|evo(?:lve|lution)?|—|-)\s*[-–:|,.\t ]+\s*(.+?)\s*$/i.exec(line);
    if (m && !/^\d+$/.test(m[2])) { out.push({ level: levelWord(m[1]), move: m[2] }); continue; }
    m = /^(.+?)\s*[-–:|,\t ]+\s*(?:lv\.?|lvl\.?|level|l)?\s*(\d+|start|evo(?:lve|lution)?)\s*$/i.exec(line);
    if (m) { out.push({ level: levelWord(m[2]), move: m[1] }); continue; }
  }
  return out;
}
const levelWord = (w) => (/^\d+$/.test(w) ? Number(w) : /^evo/i.test(w) ? 0 : 1);

function importLearnset(ds, rows, map, opts, report) {
  let entries = [];
  if (rows.length && rows[0].line != null) entries = parseLearnsetLines(rows.map((r) => r.line).join('\n'));
  else entries = rows.map((r) => ({ species: cell(r, map.species), level: toNum(cell(r, map.level)) ?? levelWord(String(cell(r, map.level) ?? '1')), move: cell(r, map.move) }));
  const species = lookup(ds.species);
  const moves = lookup(ds.moves);
  const bySpecies = new Map();
  const missingSpecies = new Set();
  const placeholders = [];
  let nextNo = ds.moves.reduce((m, x) => Math.max(m, x.no || 0), 0);
  for (const e of entries) {
    if (!e.move) { report.skipped++; continue; }
    const sp = e.species ? (species.get(e.species) ?? findSpecies(ds, e.species)) : ds.species.find((s) => s.id === opts.speciesId);
    if (!sp) { report.skipped++; if (e.species) missingSpecies.add(String(e.species)); continue; }
    if (!bySpecies.has(sp)) bySpecies.set(sp, []);
    let mv = moves.get(e.move);
    if (!mv) {
      mv = { id: slug(e.move), name: String(e.move).trim(), no: ++nextNo,
        type: ds.types[0]?.id, category: 'status', power: 0, accuracy: 100, pp: 20, priority: 0, desc: 'Placeholder: fill in on the Moves tab.' };
      ds.moves.push(mv);
      moves.add(mv);
      placeholders.push(mv.name);
    }
    bySpecies.get(sp).push({ level: e.level, move: mv.id });
  }
  for (const [sp, list] of bySpecies) {
    if (opts.mode === 'replace' || opts.clearLearnset !== false) sp.learnset = [];
    const have = new Set(sp.learnset.map((x) => `${x.level}|${x.move}`));
    for (const l of list) {
      const k = `${l.level}|${l.move}`;
      if (!have.has(k)) { have.add(k); sp.learnset.push(l); report.added++; }
    }
    sp.learnset.sort((a, b) => a.level - b.level);
  }
  if (missingSpecies.size) report.warnings.push(`${missingSpecies.size} species in the learnsets are not in your list (skipped): ${[...missingSpecies].slice(0, 10).join(', ')}${missingSpecies.size > 10 ? '…' : ''}`);
  if (placeholders.length) report.warnings.push(`${placeholders.length} moves were not in the list, so placeholders were added (import your moves first to avoid this): ${placeholders.slice(0, 10).join(', ')}${placeholders.length > 10 ? '…' : ''}`);
}

const STAT_NAMES = { hp: 'hp', atk: 'atk', attack: 'atk', def: 'def', defense: 'def', defence: 'def', spa: 'spa', spatk: 'spa', specialattack: 'spa', spattack: 'spa', spd: 'spd', spdef: 'spd', specialdefense: 'spd', spdefense: 'spd', spe: 'spe', speed: 'spe' };
const statKey = (v) => STAT_NAMES[compactId(v)] ?? null;

function importTemperaments(ds, rows, map, opts, report) {
  if (opts.mode === 'replace') ds.temperaments = [];
  for (const row of rows) {
    const name = cell(row, map.name);
    if (!name) { report.skipped++; continue; }
    const id = slug(name);
    let t = ds.temperaments.find((x) => x.id === id);
    const isNew = !t;
    if (isNew) { t = { id, name: String(name).trim(), up: null, down: null }; ds.temperaments.push(t); }
    t.name = String(name).trim();
    t.up = statKey(cell(row, map.up));
    t.down = statKey(cell(row, map.down));
    if (t.up && t.up === t.down) { t.up = null; t.down = null; }
    const sdn = cell(row, map.showdownName);
    if (sdn) t.showdownName = String(sdn).trim();
    if (isNew) report.added++; else report.updated++;
  }
}

/**
 * Items (Showdown's items.ts, or any table with a name column). Berries become food that grows on
 * the berry farm; everything else is a held item (kept in the bag, given to creatures for battles).
 * Items you already have keep their effects; only the name and description are refreshed.
 * With opts.mode 'update' (Showdown's text/items.ts) only descriptions are added.
 */
const BERRY_COLORS = ['#c0306a', '#e5484d', '#f2a33a', '#5aa83a', '#3a7bd5', '#8a4fc0', '#e07ab0'];
function importItems(ds, rows, map, opts, report) {
  ds.items = ds.items ?? [];
  const byKey = lookup(ds.items);
  for (const row of rows) {
    const name = String(row.name ?? cell(row, map.name) ?? row.key ?? '').trim();
    if (!name) { report.skipped++; continue; }
    const ns = String(row.isNonstandard ?? '');
    if (opts.mainOnly && /^(CAP|Custom|LGPE|Future|Unobtainable)$/i.test(ns)) { report.skipped++; continue; }
    const desc = row.shortDesc ?? row.desc ?? cell(row, map.desc);
    let it = byKey.get(name) ?? byKey.get(row.key ?? '');
    if (opts.mode === 'update') {
      if (it && desc) { it.desc = String(desc); report.updated++; } else report.skipped++;
      continue;
    }
    if (it) {
      it.name = name; it.showdownName = name;
      if (desc) it.desc = String(desc);
      report.updated++;
      continue;
    }
    const berry = row.isBerry === true || /berry$/i.test(name);
    it = berry
      ? { id: slug(name), name, kind: 'food', fullness: 12, joy: 10, friendship: 1, grow: { hours: 3, yield: 2 }, color: BERRY_COLORS[(Number(row.num) || name.length) % BERRY_COLORS.length], desc: desc ? String(desc) : 'A berry. Grows on the berry farm.' }
      : { id: slug(name), name, kind: 'held', desc: desc ? String(desc) : '' };
    it.showdownName = name;
    if (Number(row.num) > 0) it.no = Number(row.num);
    if (Number(row.spritenum) >= 0 && row.spritenum != null) it.spritenum = Number(row.spritenum);
    if (ds.items.some((x) => x.id === it.id)) it.id = `${it.id}-${it.no ?? ds.items.length}`;
    ds.items.push(it);
    byKey.add(it);
    report.added++;
  }
}

/**
 * Type chart paste: first column = attacking type, header row = defending types,
 * cells = multipliers (2, ½, 0.5, 0, ×2, blank = 1).
 */
function importTypeChart(ds, rows, map, opts, report) {
  if (!rows.length) return;
  const cols = Object.keys(rows[0]);
  const atkCol = cols[0];
  const defCols = cols.slice(1).filter((c) => String(c).trim());
  if (opts.mode === 'replace') ds.typeChart = {};
  for (const row of rows) {
    const atk = resolveType(ds, row[atkCol], report);
    if (!atk) continue;
    ds.typeChart[atk] = ds.typeChart[atk] || {};
    for (const c of defCols) {
      const def = resolveType(ds, c, report);
      const v = parseMultiplier(row[c]);
      if (v === 1) delete ds.typeChart[atk][def];
      else ds.typeChart[atk][def] = v;
      report.updated++;
    }
  }
}

export function parseMultiplier(v) {
  const s = String(v ?? '').trim().replace(/[×x*]/g, '');
  if (s === '' || s === '1' || s === '-') return 1;
  if (s === '½' || s === '1/2') return 0.5;
  if (s === '¼' || s === '1/4') return 0.25;
  if (s === '0') return 0;
  const n = parseFloat(s);
  return Number.isFinite(n) ? n : 1;
}
