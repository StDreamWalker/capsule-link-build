// Pokéblocks, made in a Berry Blender as in Ruby, Sapphire and Emerald.
//   Everyone puts in one berry; the blender's top speed (RPM) multiplies the mixed flavours.
//   blenderRpm(rpm, hit, players)    the speed change for a Perfect / Good / Miss
//   blendPokeblock(berries, maxRpm)  the Pokéblock: { flavors, level, feel, color }
//   feedPokeblock(idx, c, block)     raises Cool / Beauty / Cute / Smart / Tough, and the sheen (up to 255)
import { flavorsOf } from './foods.js';

export const FLAVORS = ['spicy', 'dry', 'sweet', 'bitter', 'sour'];
export const CONDITIONS = { spicy: 'cool', dry: 'beauty', sweet: 'cute', bitter: 'smart', sour: 'tough' };
export const CONDITION_NAMES = { cool: 'Cool', beauty: 'Beauty', cute: 'Cute', smart: 'Smart', tough: 'Tough' };
// each flavour is weakened by the next one round the ring: spicy by dry, dry by sweet, sweet by bitter, bitter by sour, sour by spicy
const WEAKENED_BY = { spicy: 'dry', dry: 'sweet', sweet: 'bitter', bitter: 'sour', sour: 'spicy' };
// natures: the stat a nature raises picks the flavour it likes; the one it lowers, the one it doesn't
const STAT_FLAVOR = { atk: 'spicy', spa: 'dry', spe: 'sweet', spd: 'bitter', def: 'sour' };
export const MAX_CONDITION = 255, MAX_SHEEN = 255;

// RPM rules (Gen III): a Perfect adds more below 82.39 RPM; above it a Good no longer speeds it up
export const RPM_MIN = 7.03, RPM_DECAY = 0.66;
export function blenderRpm(rpm, hit, players = 2) {
  const fast = rpm >= 82.39;
  const d = hit === 'perfect' ? (fast ? 7.03 : 21.09) : hit === 'good' ? (fast ? 0 : 14.06) : -14.06;
  return Math.max(RPM_MIN, rpm + d / Math.max(1, players));
}

// berry strengths: the games' berries in their tiers (common ones 10, the later ones stronger and smoother)
const TIER = {
  cheri: 0, chesto: 0, pecha: 0, rawst: 0, aspear: 0, leppa: 0, oran: 0, persim: 0, lum: 1, sitrus: 1,
  figy: 1, wiki: 1, mago: 1, aguav: 1, iapapa: 1, razz: 0, bluk: 0, nanab: 0, wepear: 0, pinap: 0,
  pomeg: 0, kelpsy: 0, qualot: 0, hondew: 0, grepa: 0, tamato: 1, cornn: 1, magost: 1, rabuta: 1, nomel: 1,
  spelon: 2, pamtre: 2, watmel: 2, durin: 2, belue: 2, liechi: 3, ganlon: 3, salac: 3, petaya: 3, apicot: 3, lansat: 3, starf: 3, enigma: 3,
};
const keyOf = (it) => String(it?.name ?? it?.id ?? '').toLowerCase().replace(/\s*berry$/, '').replace(/[^a-z]/g, '');
const hash = (s) => { let h = 0; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h; };
/** A berry's flavour strengths and smoothness for the blender. */
export function berryBlend(it) {
  const k = keyOf(it);
  let fl = flavorsOf(it);
  // berries from other data sets: a flavour from their name, so the same berry always tastes the same
  if (!(k in TIER) && (!fl.length || (fl.length === 1 && fl[0] === 'sweet' && !/^sweet/.test(k)))) fl = [FLAVORS[hash(it?.id ?? k) % 5], ...(hash(k) % 3 === 0 ? [FLAVORS[(hash(k) >> 3) % 5]] : [])];
  fl = [...new Set(fl)];
  const tier = TIER[k] ?? Math.min(3, Math.floor(((it?.grow?.hours ?? 4) - 1) / 4));
  const main = [10, 15, 30, 40][tier];
  const flavors = Object.fromEntries(FLAVORS.map((f) => [f, 0]));
  fl.forEach((f, i) => { flavors[f] = i === 0 ? main : Math.max(10, Math.round(main * (fl.length > 3 ? 0.25 : 0.5))); });
  return { flavors, smooth: [25, 25, 35, 40][tier] - (fl.length > 3 ? 5 : 0) };
}

/** Mix berries at a top speed: the Pokéblock that comes out. */
export function blendPokeblock(berries, maxRpm, { rng = Math.random } = {}) {
  const parts = berries.map((b) => (b?.flavors ? b : berryBlend(b)));
  const ids = berries.map((b) => b?.id ?? keyOf(b));
  const sameTwice = new Set(ids).size < ids.length;
  const feel = Math.max(0, Math.floor(parts.reduce((n, p) => n + p.smooth, 0) / Math.max(1, parts.length)) - parts.length);
  let f = Object.fromEntries(FLAVORS.map((k) => [k, parts.reduce((n, p) => n + (p.flavors[k] ?? 0), 0)]));
  // the weaker flavour eats into each one, then every flavour that went below zero takes one more off them all
  f = Object.fromEntries(FLAVORS.map((k) => [k, f[k] - f[WEAKENED_BY[k]]]));
  const neg = FLAVORS.filter((k) => f[k] < 0).length;
  f = Object.fromEntries(FLAVORS.map((k) => [k, Math.max(0, f[k] - neg)]));
  const mult = Math.floor((1 + maxRpm / 333) * 100) / 100;
  f = Object.fromEntries(FLAVORS.map((k) => [k, Math.round(f[k] * mult)]));
  let n = FLAVORS.filter((k) => f[k] > 0).length;
  if (sameTwice || n === 0 || feel < 4) {
    // a Black Pokéblock: three random flavours, weak
    f = Object.fromEntries(FLAVORS.map((k) => [k, 0]));
    const pool = [...FLAVORS]; for (let i = 0; i < 3; i++) f[pool.splice(Math.floor(rng() * pool.length), 1)[0]] = 2;
    return finish(f, feel, 'black');
  }
  return finish(f, feel, colorOf(f));
}
function colorOf(f) {
  const on = FLAVORS.filter((k) => f[k] > 0);
  const top = FLAVORS.reduce((a, k) => (f[k] > f[a] ? k : a), FLAVORS[0]); // ties go spicy, dry, sweet, bitter, sour
  if (on.length >= 4) return 'white';
  if (on.length === 3) return 'gray';
  if (f[top] > 50) return 'gold';
  if (on.length === 1) return { spicy: 'red', dry: 'blue', sweet: 'pink', bitter: 'green', sour: 'yellow' }[top];
  return { spicy: 'purple', dry: 'indigo', sweet: 'brown', bitter: 'liteblue', sour: 'olive' }[top];
}
export const BLOCK_COLORS = {
  red: ['Red', '#e8424a'], blue: ['Blue', '#3a6ae8'], pink: ['Pink', '#f48ac0'], green: ['Green', '#3cb85a'], yellow: ['Yellow', '#f2d23a'],
  purple: ['Purple', '#9a4ad0'], indigo: ['Indigo', '#4a3ab0'], brown: ['Brown', '#9a6a3a'], liteblue: ['LiteBlue', '#7ac8f0'], olive: ['Olive', '#8a9a3a'],
  gray: ['Gray', '#9a9aa0'], white: ['White', '#f4f4f8'], gold: ['Gold', '#e8b830'], black: ['Black', '#2a2a30'],
};
function finish(flavors, feel, color) {
  const level = Math.max(...FLAVORS.map((k) => flavors[k]));
  return { flavors, level, feel, color, name: `${BLOCK_COLORS[color][0]} Pokéblock` };
}

// ---------- the bag: Pokéblocks are kept as a list (each one is different) ----------
export function addPokeblock(save, block, t = Date.now()) {
  const b = { id: `pb-${t.toString(36)}-${Math.floor(Math.random() * 1e6).toString(36)}`, ...block, at: t };
  (save.pokeblocks = save.pokeblocks || []).push(b);
  if (save.pokeblocks.length > 40) save.pokeblocks.shift(); // the Pokéblock Case holds 40
  return b;
}
export const POKEBLOCK_CASE = 40;

/** How a creature feels about a block (from its nature): 'happily' | 'disdain' | '' */
export function blockTaste(idx, c, block) {
  const t = idx.ds?.temperaments?.find?.((x) => x.id === c?.temper);
  const like = STAT_FLAVOR[t?.up], hate = STAT_FLAVOR[t?.down];
  if (!like || !hate || like === hate) return '';
  const L = block.flavors[like] ?? 0, H = block.flavors[hate] ?? 0;
  if (L > H) return 'happily';
  if (H > L) return 'disdain';
  return '';
}
/** Feed a Pokéblock: conditions up by its flavours (±10% for the flavour they like or don't), sheen up by its feel. */
export function feedPokeblock(idx, save, uid, blockId, t = Date.now()) {
  const c = save.creatures?.[uid];
  const i = (save.pokeblocks ?? []).findIndex((b) => b.id === blockId);
  if (!c || i < 0) return { ok: false, reason: 'That Pokéblock is gone.' };
  if (c.egg) return { ok: false, reason: 'Eggs can’t eat.' };
  const cond = (c.condition = c.condition || { cool: 0, beauty: 0, cute: 0, smart: 0, tough: 0, sheen: 0 });
  if (cond.sheen >= MAX_SHEEN) return { ok: false, reason: 'They’re too full of Pokéblocks to eat another (their sheen is at its best).' };
  const block = save.pokeblocks[i];
  const taste = blockTaste(idx, c, block);
  const t2 = idx.ds?.temperaments?.find?.((x) => x.id === c.temper);
  const like = STAT_FLAVOR[t2?.up], hate = STAT_FLAVOR[t2?.down];
  const gains = {};
  for (const fl of FLAVORS) {
    let v = block.flavors[fl] ?? 0;
    if (taste === 'happily' && fl === like) v = Math.round(v * 1.1);
    if (taste === 'disdain' && fl === hate) v = Math.round(v * 0.9);
    const k = CONDITIONS[fl];
    const before = cond[k];
    cond[k] = Math.min(MAX_CONDITION, cond[k] + v);
    if (cond[k] > before) gains[k] = cond[k] - before;
  }
  cond.sheen = Math.min(MAX_SHEEN, cond.sheen + block.feel);
  save.pokeblocks.splice(i, 1);
  if (taste === 'happily') c.friendship = Math.min(idx.ds?.rules?.maxFriendship ?? 255, (c.friendship ?? 0) + 2);
  return { ok: true, taste, gains, sheen: cond.sheen, stars: sheenStars(cond.sheen) };
}
/** The sheen ring: 1 star, then one more every 29 points, up to 10. */
export const sheenStars = (s) => Math.min(10, 1 + Math.floor((s ?? 0) / 29));
