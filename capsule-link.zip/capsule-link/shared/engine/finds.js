// Rare finds: blueprints (the ones you have to find before you can buy them) and valuables, turning up now and then
// after battles, scavenging, tasks done and other activities — most of all on walks. And items dug up dirty (a
// grubby TM, a muddy incense…), cleaned up in the Item Restorer.
//
//   rareFinds(idx, save, source, { perfect, rnd, t })  → [{ kind: 'blueprint'|'valuable', id, name }] (already given)
//   dirtyId(id) / cleanOf(id)                           a dirty item's id, and what it is once clean
//   restoreItem(save, dirtyId)                          → { ok, item } (cleaned: the real item in the bag)
import { BLUEPRINTS, bpId, blueprintUnlocked } from './ranchBuild.js';
import { noteLegit } from './legit.js';
import { VALUABLES } from './shop.js';

// how likely each is, by where it happened (a walk most of all)
const CHANCE = { walk: { bp: 0.06, val: 0.05 }, battle: { bp: 0.025, val: 0.04 }, scavenging: { bp: 0.05, val: 0.03 }, task: { bp: 0.07, val: 0.06 }, activity: { bp: 0.02, val: 0.02 } };
/** A rare find or two (or, usually, nothing). Gives them, and remembers them for the app to announce. */
export function rareFinds(idx, save, source, { perfect = false, rnd = Math.random, t = Date.now(), scale = 1 } = {}) {
  const ch = CHANCE[source] ?? CHANCE.activity, out = [];
  const k = (perfect ? 2 : 1) * scale;
  if (rnd() < ch.bp * k) {
    const locked = BLUEPRINTS.filter((b) => b.kind !== 'expand' && !blueprintUnlocked(save, b));
    if (locked.length) {
      const b = locked[Math.floor(rnd() * locked.length)];
      save.bpFound = { ...(save.bpFound ?? {}), [b.id]: t };
      noteLegit(save, 'found', b.id);
      out.push({ kind: 'blueprint', id: bpId(b.id), bp: b.id, name: `${b.name} blueprint` });
    }
  }
  if (rnd() < ch.val * k) {
    const pool = VALUABLES.filter((v) => v.rarity <= (perfect ? 2 : 1.2)); // (only the strictly valuable ones)
    const v = pool[Math.floor(rnd() * pool.length)] ?? VALUABLES[0];
    save.inventory[v.id] = (save.inventory[v.id] ?? 0) + 1;
    noteLegit(save, 'item', v.id);
    out.push({ kind: 'valuable', id: v.id, name: v.name });
  }
  if (out.length) { save.findsNew = [...(save.findsNew ?? []), ...out.map((f) => ({ ...f, source, t }))].slice(-12); }
  return out;
}

// ---------- dirty items, and the Item Restorer ----------
export const dirtyId = (id) => `dirty:${id}`;
export const cleanOf = (id) => (String(id).startsWith('dirty:') ? String(id).slice(6) : null);
/** Brushed off, rinsed and polished: the real thing goes into the bag. */
export function restoreItem(save, id) {
  const real = cleanOf(id);
  if (!real || (save.inventory?.[id] ?? 0) <= 0) return { ok: false, reason: 'Nothing to clean.' };
  save.inventory[id] -= 1;
  save.inventory[real] = (save.inventory[real] ?? 0) + 1;
  return { ok: true, item: real };
}
