// What a creature knows about itself and its world: its type and what it's weak or strong against, the moves it
// knows and its best one, whether (and into what) it can evolve, its ability and nature, its ball, where it's
// from and how you met. Answered from the real data (the type chart, its learnset, its own record).
//
//   typeNames(idx, c) · matchup(idx, atk, defTypes) · weakTo(idx, c) · typeIn(idx, text)
//   bestMove(idx, c) · movesOf(idx, c) · evoInfo(idx, save, c) · originOf(idx, c) · ballName(c) · natureOf(idx, c)
import { speciesOf, displayName } from './creature.js';
import { BALL_NAMES_ENGINE } from './ballNames.js';
import { changeOptions } from './transform.js';
import { gamePlacesFor } from './tasks.js';

const low = (s) => String(s ?? '').toLowerCase();
// the names people use for types (the games' and the default set's), so "fire" finds Ember and "water" finds Tide
const TYPE_ALIAS = { fire: ['ember', 'flame'], water: ['tide', 'aqua'], grass: ['sprout', 'leaf', 'plant'], electric: ['spark', 'volt', 'thunder'], rock: ['stone'], steel: ['metal'], dark: ['shade', 'shadow'], ice: ['frost'], psychic: ['mind'], fighting: ['brawl', 'fight'], normal: ['plain'], ghost: ['spirit', 'phantom'], flying: ['sky', 'wind'], poison: ['toxic', 'venom'], ground: ['earth', 'soil'], bug: ['insect'], dragon: ['wyrm'], fairy: ['fae', 'charm'] };
export function typeNames(idx, c) {
  const sp = speciesOf(idx, c);
  return (sp?.types ?? []).map((t) => idx.types?.get?.(t)?.name ?? t);
}
/** A type named in some words ("fire", "water types", "Tide"), as its id, or null. */
export function typeIn(idx, text) {
  const s = low(text);
  const types = [...(idx.types?.values?.() ?? [])];
  for (const t of types) if (new RegExp(`\\b${low(t.name)}\\b|\\b${low(t.id)}\\b`).test(s)) return t.id;
  for (const [real, alts] of Object.entries(TYPE_ALIAS)) {
    if (!new RegExp(`\\b(?:${[real, ...alts].join('|')})\\b`).test(s)) continue;
    const hit = types.find((t) => [real, ...alts].includes(low(t.id)) || [real, ...alts].includes(low(t.name)));
    if (hit) return hit.id;
  }
  return null;
}
/** How much a move of type `atk` hurts something of types `defTypes`: 0, ¼, ½, 1, 2 or 4. */
export function matchup(idx, atk, defTypes = []) {
  const row = idx.ds?.typeChart?.[atk] ?? {};
  return defTypes.reduce((m, d) => m * (row[d] ?? 1), 1);
}
/** What hurts it: { weak: [{ type, name, x }], resist: [...], immune: [...] }. */
export function weakTo(idx, c) {
  const sp = speciesOf(idx, c), mine = sp?.types ?? [];
  const out = { weak: [], resist: [], immune: [] };
  for (const t of idx.types?.values?.() ?? []) {
    const x = matchup(idx, t.id, mine);
    const e = { type: t.id, name: t.name, x };
    if (x === 0) out.immune.push(e); else if (x > 1) out.weak.push(e); else if (x < 1) out.resist.push(e);
  }
  out.weak.sort((a, b) => b.x - a.x);
  return out;
}
export function movesOf(idx, c) {
  return (c.moves ?? []).map((m) => idx.moves?.get?.(m.id)).filter(Boolean);
}
/** Its strongest move (power, with a bonus for its own type). */
export function bestMove(idx, c) {
  const sp = speciesOf(idx, c), mine = new Set(sp?.types ?? []);
  return movesOf(idx, c).map((mv) => ({ mv, v: (mv.power ?? 0) * (mine.has(mv.type) ? 1.5 : 1) })).sort((a, b) => b.v - a.v)[0]?.mv ?? null;
}
/** Evolution: { next: [{ name, how, ok, why }], can (one is ready), final }. */
export function evoInfo(idx, save, c) {
  let opts = [];
  try { opts = changeOptions(idx, save, c).filter((x) => x.kind === 'evolve'); } catch { /* fine */ }
  const sp = speciesOf(idx, c);
  const evos = sp?.evolutions ?? [];
  const next = evos.map((e) => {
    const to = idx.species?.get?.(e.to);
    const how = e.method === 'level' ? `at level ${e.value}` : e.method === 'item' ? `with ${an(e.value)} ${e.value}` : e.method === 'friendship' ? 'once it trusts you completely' : e.method === 'trade' ? 'when traded' : e.method === 'steps' ? `after walking ${e.value ? `${Number(e.value).toLocaleString()} steps` : 'far enough'} with you` : /time|day|night/.test(e.method ?? '') ? `at the right time of day` : /move/.test(e.method ?? '') ? 'once it learns the right move' : e.method ? `by ${String(e.method).replace(/[-_]/g, ' ')}` : '';
    const o = opts.find((x) => x.to === e.to);
    return { name: to?.name ?? e.to, how, ok: !!o?.ok, why: o?.why ?? '' };
  });
  return { next, can: next.some((n) => n.ok), final: !evos.length };
}
const an = (w) => (/^[aeiou]/i.test(String(w)) ? 'an' : 'a');
/** Where it's from: { game, region, how, when, level, trainer, first } (what it knows of its own past). */
export function originOf(idx, c) {
  let g = null; try { g = gamePlacesFor(c); } catch { /* fine */ }
  const first = (c.memories ?? []).find((m) => m.from === 'game') ?? (c.memories ?? [])[0] ?? null;
  return { game: g?.game ?? c.origin?.game ?? null, region: g?.region ?? null, places: g?.places ?? [], how: c.metHow ?? null, when: c.metAt ?? null, level: c.metLevel ?? null, trainer: c.ot ?? c.origin?.ot ?? null, first };
}
export function ballName(c) {
  const id = Number(c.ballSkin ?? c.pk?.ballChanged ?? c.pk?.ball ?? c.ball ?? 4) || 4;
  return BALL_NAMES_ENGINE[id] ?? 'Poké Ball';
}
/** Its nature: { name, up, down } (the stat it's good at and the one it's not, in words). */
export function natureOf(idx, c) {
  const t = (idx.temperaments?.get?.(c.temper)) ?? (idx.ds?.temperaments ?? []).find((x) => x.id === c.temper) ?? null;
  const W = { atk: 'hitting hard', def: 'taking hits', spa: 'special moves', spd: 'shrugging off special moves', spe: 'speed', hp: 'stamina' };
  return { name: t?.name ?? (c.temper ? String(c.temper) : null), up: t?.up ? W[t.up] ?? t.up : null, down: t?.down ? W[t.down] ?? t.down : null };
}
