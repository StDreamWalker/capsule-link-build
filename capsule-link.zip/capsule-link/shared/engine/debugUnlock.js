// Settings → Debug → "Unlock everything": every item, blueprint, toy and expansion, to try things out. Turning
// it off puts everything back as it was when it went on: what you had before stays, everything the unlock gave
// goes (and whatever was built with it comes down). Things you really bought or found while it was on are kept.
//
//   setUnlockAll(idx, save, on, t)   → { ok, on, added?, restored? }
//   unlockAllOn(save)                → whether it's on
//   noteLegit(save, kind, id, n)     → record something bought or found for real while it's on (kept afterwards)
import { BLUEPRINTS, bpId, MAX_YARD_SIZE } from './ranchBuild.js';
import { MAX_FARM_SIZE, farmState, farmPlots } from './farm.js';
import { TOY_SHOP } from './care.js';
import { allFoods, HELD, POWER_ITEMS, MEDICINE, VALUABLES, incenseItems, allClothes } from './shop.js';
import { evolutionItems } from './transform.js';
import { BALL_ITEMS } from './balls.js';
import { FOSSILS } from './fossils.js';
import { tmId } from './teamEdit.js';

export const UNLOCK_QTY = 99;
const clone = (x) => (x == null ? x : JSON.parse(JSON.stringify(x)));
export const unlockAllOn = (save) => !!save?.unlockAll?.on;

/** Everything that can be in the bag: [[id, how many to give]]. */
export function everything(idx) {
  const out = new Map();
  const add = (id, n = UNLOCK_QTY) => { if (id && !out.has(id)) out.set(id, n); };
  for (const it of idx.ds?.items ?? []) if (!it.unlimited) add(it.id);
  for (const f of allFoods(idx)) if (!f.unlimited) add(f.id);
  for (const list of [HELD, POWER_ITEMS, MEDICINE, VALUABLES, BALL_ITEMS]) for (const it of list ?? []) add(it.id);
  try { for (const it of incenseItems(idx)) add(it.id, 30); } catch { /* fine */ }
  try { for (const it of allClothes(idx)) add(it.id, 6); } catch { /* fine */ }
  try { for (const it of evolutionItems(idx)) add(it.id, 10); } catch { /* fine */ }
  for (const f of FOSSILS) add(f.id, 3);
  for (const mv of idx.ds?.moves ?? []) if (mv.power > 0 || mv.category === 'status') add(tmId(mv.id), 1);
  for (const b of BLUEPRINTS) add(bpId(b.id), b.tool || b.kind === 'link' || b.kind === 'gear' ? 1 : b.kind === 'expand' || b.kind === 'farm' ? 0 : 9);
  return [...out.entries()].filter(([, n]) => n > 0);
}

export { noteLegit } from './legit.js';

/** Turn "unlock everything" on or off. */
export function setUnlockAll(idx, save, on, t = Date.now()) {
  if (!!on === unlockAllOn(save)) return { ok: true, on: !!on, same: true };
  if (on) {
    const yards = [...(save.boxes ?? []).map((b, k) => [k, b]), ['ranch', save.ranch]].filter(([, o]) => o);
    save.unlockAll = {
      on: true, at: t,
      snap: {
        inventory: clone(save.inventory ?? {}),
        bpFound: clone(save.bpFound ?? {}),
        toysOwned: clone(save.toysOwned ?? null),
        yards: Object.fromEntries(yards.map(([k, o]) => [k, { size: o.build?.size ?? 0, features: (o.build?.features ?? []).map((f) => f.id) }])),
        farmSize: save.farm?.size ?? 0,
        // what each one holds and wears (handed out of the bag while it's on, so put back after)
        worn: Object.fromEntries(Object.values(save.creatures ?? {}).map((c) => [c.uid, { heldItemId: c.heldItemId ?? null, heldItem: c.heldItem ?? null, clothes: clone(c.clothes ?? []) }])),
      },
      legit: { items: {}, found: {}, toys: {} },
    };
    save.inventory = save.inventory || {};
    let added = 0;
    for (const [id, n] of everything(idx)) { if ((save.inventory[id] ?? 0) < n) { save.inventory[id] = n; added++; } }
    save.bpFound = { ...(save.bpFound ?? {}), ...Object.fromEntries(BLUEPRINTS.map((b) => [b.id, save.bpFound?.[b.id] ?? t])) };
    save.toysOwned = Object.fromEntries(TOY_SHOP.map((x) => [x.id, true]));
    for (const o of [...(save.boxes ?? []), save.ranch].filter(Boolean)) { o.build = o.build || { size: 0, features: [] }; o.build.size = MAX_YARD_SIZE; }
    try { const farm = farmState(save); farm.size = MAX_FARM_SIZE; farmState(save); } catch { /* no farm yet */ }
    return { ok: true, on: true, added };
  }
  // off: back as it was, plus whatever was bought or found for real in the meantime
  const { snap, legit = {} } = save.unlockAll ?? {};
  if (!snap) { save.unlockAll = null; return { ok: true, on: false }; }
  const inv = clone(snap.inventory ?? {});
  for (const [id, n] of Object.entries(legit.items ?? {})) inv[id] = (inv[id] ?? 0) + n;
  save.inventory = inv;
  save.bpFound = { ...(snap.bpFound ?? {}), ...Object.fromEntries(Object.keys(legit.found ?? {}).map((id) => [id, t])) };
  save.toysOwned = snap.toysOwned ? { ...snap.toysOwned, ...(legit.toys ?? {}) } : (Object.keys(legit.toys ?? {}).length ? { ...Object.fromEntries(['ball', 'feather', 'disc', 'plush'].map((x) => [x, true])), ...legit.toys } : null);
  if (save.toysOwned == null) delete save.toysOwned;
  // yards: their old size, and only what was built before (anything built with the unlock comes down)
  let removed = 0;
  for (const [k, o] of [...(save.boxes ?? []).map((b, i) => [String(i), b]), ['ranch', save.ranch]]) {
    if (!o?.build) continue;
    const was = snap.yards?.[k];
    const keep = new Set(was?.features ?? []);
    const before = o.build.features.length;
    o.build.features = o.build.features.filter((f) => keep.has(f.id));
    removed += before - o.build.features.length;
    o.build.size = was?.size ?? 0;
    if (save.revivals) for (const id of Object.keys(save.revivals)) if (!o.build.features.some((f) => f.id === id) && !Object.values(snap.yards ?? {}).some((y) => y.features?.includes(id))) delete save.revivals[id];
  }
  if (save.farm) { save.farm.size = snap.farmSize ?? 0; save.farm.plots = (save.farm.plots ?? []).slice(0, farmPlots(save)); }
  // held items and clothes: back to what they were (the unlock's copies go with it)
  for (const [uid, w] of Object.entries(snap.worn ?? {})) {
    const c = save.creatures?.[uid];
    if (!c) continue;
    c.heldItemId = w.heldItemId ?? undefined; c.heldItem = w.heldItem ?? undefined;
    if (c.heldItemId === undefined) delete c.heldItemId;
    if (c.heldItem === undefined) delete c.heldItem;
    c.clothes = clone(w.clothes ?? []);
  }
  // (and anyone who arrived meanwhile keeps only what's really in the bag)
  for (const c of Object.values(save.creatures ?? {})) {
    if (snap.worn?.[c.uid]) continue;
    c.clothes = (c.clothes ?? []).filter((w) => (save.inventory[w.id] ?? 0) > 0);
  }
  save.unlockAll = null;
  return { ok: true, on: false, restored: true, removed };
}
