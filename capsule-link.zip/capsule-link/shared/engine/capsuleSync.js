// Reading and writing capsules, shared by the PC dock and the phone's NFC reader.
//
// A "tag" is anything with:
//   uid                          hex string (7-byte NFC UID)
//   readUser()  -> Uint8Array    user memory starting at page 4 (at least 232 bytes)
//   writePages(page, bytes)      write whole 4-byte pages starting at `page`
//
// Creatures that live in a capsule use last-writer-wins: the newest copy (capsule or device)
// is kept, then steps walked since the last sync are added on top.
import {
  CAPSULE, parseTagImage, pendingSteps, encodeMain, encodeWalk, emptyMain, buildTagImage, newSyncId, recordToCreature,
} from './capsule.js';
import { applyWalk } from './care.js';
import { touch, addMemory } from './creature.js';
import { firstFreeBoxSlot } from './save.js';

export async function readCapsule(idx, tag) {
  const mem = await tag.readUser();
  const parsed = parseTagImage(mem);
  const base = { uid: tag.uid, parsed };
  if (!parsed.ok) {
    if (parsed.main?.empty && parsed.main.error == null) return { ...base, state: 'empty' };
    if (parsed.blank) return { ...base, state: 'blank', message: 'Blank tag — ready to become a capsule.' };
    if (parsed.foreign) return { ...base, state: 'foreign', message: parsed.error };
    if (parsed.main?.error && parsed.main.empty) return { ...base, state: 'blank', message: 'Blank tag — ready to become a capsule.' };
    return { ...base, state: 'damaged', message: parsed.error ?? 'Capsule data could not be read.' };
  }
  const walk = parsed.walk?.ok ? parsed.walk.walk : null;
  if (parsed.main.empty) return { ...base, state: 'empty', mode: parsed.main.rec.mode, walk };
  const rec = parsed.main.rec;
  return {
    ...base, state: 'creature', rec, walk,
    pending: pendingSteps(rec, walk),
    datasetMatch: rec.datasetHash === idx.hash,
    known: !!idx.speciesByNo.get(rec.speciesNo),
  };
}

/**
 * Bring a capsule's creature up to date in `save` (add it if new, adopt the capsule copy if it is
 * newer, then apply steps walked since the last sync). Does not write the tag.
 * Returns { creature, isNew, adopted, walk: walkOutcome|null }
 */
export function absorbCapsule(idx, save, info, opts = {}) {
  if (info.state !== 'creature') throw new Error('This capsule has no creature in it.');
  if (!info.known) throw new Error(`Species #${info.rec.speciesNo} is not in this data set. Sync data with the PC first.`);
  const at = opts.at ?? Date.now();
  const rec = info.rec;
  let c = save.creatures[rec.uid];
  let isNew = false, adopted = false;
  if (!c) {
    c = recordToCreature(idx, rec, null, { now: at });
    c.uid = rec.uid;
    save.creatures[c.uid] = c;
    addMemory(c, 'Arrived in a capsule.', at);
    isNew = true;
  } else if ((rec.updatedAt ?? 0) > (c.updatedAt ?? 0) + 1500) {
    recordToCreature(idx, rec, c, { now: at });
    adopted = true;
  }
  c.location = { kind: 'capsule', tag: info.uid };
  let walk = null;
  if (info.pending > 0) {
    walk = applyWalk(idx, c, info.pending, { at, seed: `cap-${info.uid}-${rec.syncId}-${info.walk?.steps}` });
    for (const f of walk.finds) save.inventory[f] = (save.inventory[f] ?? 0) + 1;
    save.stats.totalSteps = (save.stats.totalSteps ?? 0) + walk.steps;
  }
  const cap = save.capsules[info.uid] || (save.capsules[info.uid] = { name: `Capsule ${Object.keys(save.capsules).length + 1}` });
  Object.assign(cap, {
    uid: c.uid, mode: rec.mode, lastSeen: at,
    battery: info.walk?.battery ?? cap.battery ?? null, fw: info.walk?.fw ?? cap.fw,
    bumps: info.walk?.bumpCount ?? cap.bumps ?? 0, lastBumpPeer: info.walk?.lastBumpPeer ?? null,
  });
  touch(c, at);
  return { creature: c, isNew, adopted, walk };
}

/** Write a creature (or an empty capsule when creature is null). Returns the new sync id. */
export async function writeCapsule(idx, tag, info, creature, opts = {}) {
  const mode = opts.mode ?? info?.rec?.mode ?? info?.mode ?? 'desk';
  const syncId = newSyncId(info?.rec?.syncId);
  const counted = info?.walk ? info.walk.steps : 0;
  const main = creature ? encodeMain(idx, creature, { mode, syncId, walkCounted: counted, trainer: opts.trainer }) : emptyMain(mode);
  const prevWalk = info?.walk ?? {};
  const walk = encodeWalk({ ...prevWalk, syncId, steps: 0 });
  const standard = info?.parsed?.standardLayout && (info.state === 'creature' || info.state === 'empty');
  if (standard && !opts.full) {
    // main first, then reset the walk counter (see pendingSteps for why this order is safe)
    await tag.writePages(CAPSULE.MAIN_FIRST_PAGE, main);
    await tag.writePages(CAPSULE.WALK_FIRST_PAGE, walk);
  } else {
    await tag.writePages(CAPSULE.FIRST_PAGE, buildTagImage(main, walk));
  }
  return syncId;
}

/** Sync a docked/tapped capsule: absorb, then write the updated creature back. */
export async function syncCapsule(idx, save, tag, info, opts = {}) {
  const res = absorbCapsule(idx, save, info, opts);
  await writeCapsule(idx, tag, info, res.creature, { mode: opts.mode, trainer: save.trainer?.name });
  return res;
}

/** Put a creature from the save into a capsule. */
export async function sendToCapsule(idx, save, tag, info, uid, opts = {}) {
  const c = save.creatures[uid];
  if (!c) throw new Error('Creature not found.');
  if (info.state === 'creature' && info.rec.uid !== uid) throw new Error('This capsule already holds a creature. Bring it out first.');
  if (info.state === 'foreign' && !opts.overwrite) throw new Error('This tag holds other data. Format it first.');
  await writeCapsule(idx, tag, info, c, { mode: opts.mode ?? 'walk', full: info.state !== 'creature' && info.state !== 'empty', trainer: save.trainer?.name });
  c.location = { kind: 'capsule', tag: tag.uid };
  const cap = save.capsules[tag.uid] || (save.capsules[tag.uid] = { name: `Capsule ${Object.keys(save.capsules).length + 1}` });
  Object.assign(cap, { uid, mode: opts.mode ?? 'walk', lastSeen: Date.now() });
  touch(c);
  return c;
}

/** Take the creature out of a capsule into the save (ranch, party or box) and empty the capsule. */
export async function releaseFromCapsule(idx, save, tag, info, to = { kind: 'ranch' }) {
  let c = null;
  if (info.state === 'creature') c = absorbCapsule(idx, save, info).creature;
  await writeCapsule(idx, tag, info, null, { mode: 'desk' });
  if (c) {
    c.location = to.kind === 'box' ? firstFreeBoxSlot(save) ?? { kind: 'ranch' } : to;
    c.lastCapsule = tag.uid;
    touch(c);
  }
  const cap = save.capsules[tag.uid];
  if (cap) { cap.uid = null; cap.mode = 'desk'; cap.lastSeen = Date.now(); }
  return c;
}

export async function setCapsuleMode(idx, save, tag, info, mode) {
  if (info.state === 'creature') {
    const c = save.creatures[info.rec.uid];
    const res = c ? absorbCapsule(idx, save, info) : null;
    await writeCapsule(idx, tag, info, res?.creature ?? null, { mode });
  } else {
    await writeCapsule(idx, tag, info, null, { mode, full: info.state !== 'empty' });
  }
  const cap = save.capsules[tag.uid];
  if (cap) cap.mode = mode;
}

/** A virtual tag (NTAG215-sized) for testing without hardware. */
export function makeVirtualTag(uid, bytes = null) {
  const mem = new Uint8Array(504);
  if (bytes) mem.set(bytes.slice(0, mem.length));
  return {
    uid, virtual: true, mem,
    async readUser() { return mem.slice(); },
    async writePages(page, data) {
      const off = (page - CAPSULE.FIRST_PAGE) * 4;
      if (off < 0 || off + data.length > mem.length) throw new Error('Write outside tag memory.');
      if (data.length % 4) throw new Error('Writes must be whole 4-byte pages.');
      mem.set(data, off);
    },
    /** Pretend the capsule walked: what the firmware does over I2C. */
    addSteps(n, { bump = false, peer = 0 } = {}) {
      const p = parseTagImage(mem);
      const off = p.walkOffset ?? CAPSULE.USER_WALK_OFFSET;
      const cur = p.walk?.ok ? p.walk.walk : { syncId: p.main?.rec?.syncId ?? 0, steps: 0 };
      const next = { ...cur, steps: cur.steps + n, cries: (cur.cries ?? 0) + (n > 500 ? 1 : 0), fw: 1, battery: Math.max(5, (cur.battery ?? 100) - 1) };
      if (bump) { next.bumpCount = (cur.bumpCount ?? 0) + 1; next.lastBumpPeer = peer; next.lastBumpAt = Math.floor(Date.now() / 1000); }
      mem.set(encodeWalk(next), off);
    },
  };
}
