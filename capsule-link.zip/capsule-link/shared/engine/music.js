// Music they've heard: their own taste in kinds of music, and every song you've shown them, remembered.
// Play them something new and they make up their own mind about it (their taste, their kind, their temper,
// and the song itself); play it again and they know it — a song they liked tends to grow on them, one they
// didn't gets old fast, and even a favourite wears thin played five times in an hour.
//
//   genreTaste(idx, c, genre)            → -1 … 1, how much it likes that kind of music
//   songKey({ title, artist, genre })     → a key for the song (or the kind, when there's no title)
//   hearMusic(idx, c, m, t)               → { first, n, op, before, genre, title, label, grew, tired, newGenre, memory }
//   favouriteGenres(idx, c, n)            → [{ genre, label, score }] its favourite kinds of music, best first
//   heardSongs(c)                         → [{ key, title, artist, genre, n, op, first, last }]
import { GENRES, GENRE_LABEL, artistGenre } from './lexicon.js';
import { speciesOf, addMemory } from './creature.js';
import { temperStyle } from './personality.js';
import { remember } from './dayMemory.js';

const hash = (s) => { let x = 2166136261; for (let i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); } return ((x >>> 0) % 10007) / 10007; };
// what kinds of creature tend to take to what
const TYPE_LEAN = {
  electric: { edm: 0.45, synthwave: 0.4, vgm: 0.25, rock: 0.15, pop: 0.1 },
  fire: { rock: 0.35, metal: 0.4, latin: 0.3, punk: 0.2, disco: 0.15 },
  water: { ambient: 0.35, reggae: 0.3, lofi: 0.25, folk: 0.15, jazz: 0.1 },
  grass: { folk: 0.4, country: 0.3, ambient: 0.25, classical: 0.15, lullaby: 0.15 },
  bug: { folk: 0.25, edm: 0.2, country: 0.2, indie: 0.2 },
  psychic: { classical: 0.45, ambient: 0.35, piano: 0.3, jazz: 0.15, choir: 0.2 },
  fairy: { pop: 0.4, kpop: 0.35, jpop: 0.35, lullaby: 0.25, choir: 0.25, classical: 0.15 },
  ghost: { lofi: 0.35, ambient: 0.3, choir: 0.3, classical: 0.2, metal: 0.15, synthwave: 0.15 },
  dark: { hiphop: 0.4, metal: 0.3, punk: 0.3, lofi: 0.25, blues: 0.2 },
  dragon: { classical: 0.3, metal: 0.4, rock: 0.25, vgm: 0.2 },
  ice: { classical: 0.35, ambient: 0.35, piano: 0.3, lofi: 0.15 },
  normal: { pop: 0.3, disco: 0.2, country: 0.15, vgm: 0.15, rnb: 0.15 },
  flying: { indie: 0.3, pop: 0.25, folk: 0.2, classical: 0.15 },
  poison: { punk: 0.4, metal: 0.25, hiphop: 0.2 },
  fighting: { rock: 0.35, hiphop: 0.35, metal: 0.25, edm: 0.2 },
  rock: { rock: 0.45, metal: 0.3, blues: 0.2, country: 0.15 },
  ground: { blues: 0.3, country: 0.3, rock: 0.25, folk: 0.15 },
  steel: { metal: 0.45, edm: 0.3, synthwave: 0.25, rock: 0.2 },
};
const STYLE_LEAN = {
  playful: { pop: 0.25, edm: 0.2, disco: 0.25, kpop: 0.2, jpop: 0.15, punk: 0.15, classical: -0.15, ambient: -0.2 },
  lazy: { lofi: 0.35, ambient: 0.3, reggae: 0.25, jazz: 0.15, lullaby: 0.2, metal: -0.25, punk: -0.25, edm: -0.15 },
  shy: { lofi: 0.25, piano: 0.3, classical: 0.2, folk: 0.2, lullaby: 0.2, metal: -0.3, edm: -0.2, punk: -0.2 },
  bold: { rock: 0.3, metal: 0.25, hiphop: 0.25, punk: 0.2, edm: 0.15, lullaby: -0.25, ambient: -0.15 },
  calm: { jazz: 0.25, classical: 0.25, ambient: 0.2, folk: 0.15, piano: 0.2, punk: -0.2, metal: -0.15 },
};
const typeNames = (idx, c) => { const sp = speciesOf(idx, c); return (sp?.types ?? []).map((t) => String(idx.types?.get?.(t)?.name ?? t).toLowerCase()); };

/** How much it likes a kind of music: -1 (can't stand it) … 1 (loves it). Born with it, nudged by its kind and
 * temper, and by everything of that kind you've played it since. */
export function genreTaste(idx, c, genre) {
  if (!c || !genre) return 0;
  let v = (hash(`${c.uid}|music|${genre}`) - 0.5) * 1.1;
  for (const t of typeNames(idx, c)) for (const [k, x] of Object.entries(TYPE_LEAN[t] ?? {})) if (k === genre) v += x * 0.7;
  let st = 'calm'; try { st = temperStyle(idx, c); } catch { /* fine */ }
  v += (STYLE_LEAN[st]?.[genre] ?? 0) * 0.8;
  v += (c.prefs?.[`music:${genre}`] ?? 0) / 10;
  return Math.max(-1, Math.min(1, v));
}
/** Its favourite kinds of music, best first. */
export function favouriteGenres(idx, c, n = 3) {
  return GENRES.map(([genre, label]) => ({ genre, label, score: genreTaste(idx, c, genre) })).sort((a, b) => b.score - a.score).slice(0, n);
}
export function songKey({ title, artist, genre } = {}) {
  const t = String(title ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  if (t) return `song:${t}${artist ? `|${String(artist).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim()}` : ''}`;
  return genre ? `genre:${genre}` : 'song:something';
}
export function heardSongs(c) {
  return Object.entries(c?.music ?? {}).map(([key, v]) => ({ key, ...v })).sort((a, b) => (b.last ?? 0) - (a.last ?? 0));
}
// a guess at the kind of music from a song's name alone, when you don't say (the same song always gets the same guess)
const guessGenre = (key) => GENRES[Math.floor(hash(`${key}|g`) * GENRES.length)][0];

/**
 * You played it something. m: { title, artist, genre }. What it makes of it (and remembers):
 *   first     never heard it before          before   how it felt last time (-2 … 2)
 *   op        how it feels now (-2 … 2)      grew     it's grown on it      tired   played too often lately
 *   newGenre  the first music of this kind it's ever heard
 */
export function hearMusic(idx, c, m = {}, t = Date.now()) {
  c.music = c.music || {};
  let key = songKey(m);
  // (played again by name only: the same song as before)
  if (!c.music[key] && m.title && !m.artist) { const t0 = String(m.title).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); const hit = Object.entries(c.music).find(([, x]) => String(x.title ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim() === t0); if (hit) key = hit[0]; }
  const known = c.music[key];
  const told = m.genre ?? known?.genre ?? artistGenre(m.artist) ?? null;
  const genre = told ?? (m.title ? guessGenre(key) : null), guessed = !told;
  const label = m.title ? `“${titleCase(m.title)}”${m.artist ? ` by ${titleCase(m.artist)}` : ''}` : genre ? GENRE_LABEL[genre] : 'that music';
  const newGenre = !!genre && !guessed && !Object.values(c.music).some((x) => x.genre === genre) && !(c.prefs?.[`music:${genre}`]);
  const g = genreTaste(idx, c, genre);
  let op, first = !known, before = known?.op ?? null, grew = false, tired = false;
  if (!known) {
    // its own first impression: its taste for the kind of music, and the song itself
    op = g * 1.5 + (hash(`${c.uid}|${key}|first`) - 0.5) * 1.4;
  } else {
    const recent = (known.plays ?? []).filter((x) => t - x < 3600000).length;
    op = known.op;
    // a song it likes grows on it (up to a point); one it doesn't gets worse with every play
    if (op > -0.3) { const up = Math.max(0, 0.35 - Math.max(0, op - 1) * 0.25); op += up; grew = up > 0.15 && op > 0.6 && known.op <= 1.2; }
    else op -= 0.3;
    if (recent >= 3) { tired = true; op -= 0.15 * (recent - 2); }
  }
  op = Math.max(-2, Math.min(2, op));
  const e = (c.music[key] = { ...(known ?? {}), title: m.title ?? known?.title ?? null, artist: m.artist ?? known?.artist ?? null, genre, guessed: guessed && !known?.genre ? true : known?.guessed ?? false, op: Math.round(op * 100) / 100, n: (known?.n ?? 0) + 1, first: known?.first ?? t, last: t, plays: [...(known?.plays ?? []).filter((x) => t - x < 86400000), t].slice(-8) });
  // its taste for that kind of music moves a little with how it felt
  if (genre) { c.prefs = c.prefs || {}; c.prefs[`music:${genre}`] = Math.max(-10, Math.min(10, (c.prefs[`music:${genre}`] ?? 0) + Math.max(-1, Math.min(1, op)) * 0.5)); }
  // keep the 40 it's heard most recently
  const keys = Object.keys(c.music);
  if (keys.length > 40) { keys.sort((a, b) => (c.music[a].last ?? 0) - (c.music[b].last ?? 0)); for (const k of keys.slice(0, keys.length - 40)) delete c.music[k]; }
  remember(c, 'chat', 'music', 1, t);
  // a song it falls for the first time it hears it, or one that grows into a favourite, sticks
  let memory = null;
  if ((first && op >= 1.5) || (grew && op >= 1.4 && !known?.fav)) {
    e.fav = t;
    memory = first ? `The first time you played it ${label}. Loved it straight away; it's one of its songs now.` : `Didn't think much of ${label} at first, but after hearing it with you a few times it's become a favourite.`;
    addMemory(c, memory, t, { core: true, keys: genre ? [`music:${genre}`] : [] });
  }
  return { first, n: e.n, op, before, genre, title: e.title, artist: e.artist, label, grew, tired, newGenre, memory, key };
}
const titleCase = (s) => String(s).replace(/\b([a-z])/g, (x) => x.toUpperCase());
