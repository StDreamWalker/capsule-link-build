// More of the series' battlers, from gym leaders and the Elite Four to rivals, villains, Frontier Brains and the
// anime's best: each with the team they're best known for. (The same format as famousTrainers.js.)
export const MORE_TRAINERS = [
  // ---------- Johto gym leaders and friends (HeartGold & SoulSilver rematch-ish teams) ----------
  ['Falkner', 'HeartGold & SoulSilver (Violet Gym)', 'falkner', `
    Pidgeotto|13|Gust/Quick Attack/Roost/Mud-Slap
    Hoothoot|11|Peck/Hypnosis/Foresight`],
  ['Bugsy', 'HeartGold & SoulSilver (Azalea Gym)', 'bugsy', `
    Metapod|15|Tackle/Harden
    Kakuna|15|Poison Sting/Harden
    Scyther|17|U-turn/Quick Attack/Focus Energy/Fury Cutter`],
  ['Chuck', 'HeartGold & SoulSilver (Cianwood Gym)', 'chuck', `
    Primeape|29|Karate Chop/Leer/Rage/Focus Energy
    Poliwrath|31|Dynamic Punch/Surf/Hypnosis/Body Slam`],
  ['Jasmine', 'HeartGold & SoulSilver (Olivine Gym)', 'jasmine', `
    Magnemite|30|Thunderbolt/Supersonic/Sonic Boom/Thunder Wave
    Magnemite|30|Thunderbolt/Supersonic/Sonic Boom/Thunder Wave
    Steelix|35|Iron Tail/Screech/Rock Throw/Sandstorm`],
  ['Pryce', 'HeartGold & SoulSilver (Mahogany Gym)', 'pryce', `
    Seel|30|Headbutt/Icy Wind/Aurora Beam/Rest
    Dewgong|32|Headbutt/Icy Wind/Aurora Beam/Rest
    Piloswine|34|Blizzard/Fury Attack/Earthquake/Hail`],
  ['Janine', 'HeartGold & SoulSilver (Fuchsia Gym)', 'janine', `
    Crobat|36|Wing Attack/Toxic/Double Team/Screech
    Weezing|36|Sludge Bomb/Double Team/Explosion/Smokescreen
    Ariados|33|Poison Jab/Spider Web/Psychic/Night Shade
    Venomoth|39|Psychic/Toxic Spikes/Supersonic/Signal Beam`],
  ['Koga', 'HeartGold & SoulSilver (Elite Four)', 'koga', `
    Ariados|40|Double Team/Spider Web/Baton Pass/Poison Jab
    Venomoth|41|Supersonic/Psychic/Toxic/Signal Beam
    Forretress|43|Protect/Swift/Explosion/Spikes
    Muk|42|Minimize/Acid Armor/Sludge Bomb/Toxic
    Crobat|44|Double Team/Quick Attack/Wing Attack/Poison Fang`],
  ['Will', 'HeartGold & SoulSilver (Elite Four)', 'will', `
    Xatu|40|Quick Attack/Future Sight/Confuse Ray/Psychic
    Jynx|41|Double Slap/Lovely Kiss/Ice Punch/Psychic
    Exeggutor|41|Reflect/Leech Seed/Egg Bomb/Psychic
    Slowbro|41|Curse/Amnesia/Body Slam/Psychic
    Xatu|42|Quick Attack/Future Sight/Confuse Ray/Psychic`],
  ['Ethan', 'HeartGold & SoulSilver (the player)', 'ethan', `
    Typhlosion|60|Eruption/Flamethrower/Focus Blast/Thunder Punch
    Ampharos|56|Thunderbolt/Power Gem/Focus Blast/Thunder Wave
    Feraligatr|56|Waterfall/Ice Fang/Crunch/Dragon Dance
    Togekiss|56|Air Slash/Aura Sphere/Thunder Wave/Roost
    Heracross|56|Megahorn/Close Combat/Stone Edge/Night Slash
    Lugia|60|Aeroblast/Psychic/Recover/Calm Mind`, ['gold']],
  ['Lyra', 'HeartGold & SoulSilver (the player)', 'lyra', `
    Meganium|58|Petal Blizzard/Earthquake/Synthesis/Body Slam
    Marill|52|Waterfall/Play Rough/Aqua Jet/Belly Drum
    Togekiss|55|Air Slash/Aura Sphere/Thunder Wave/Roost
    Ho-Oh|60|Sacred Fire/Brave Bird/Earthquake/Recover`, ['kris']],
  ['Eusine', 'Crystal (Suicune chaser)', 'eusine', `
    Drowzee|23|Dream Eater/Hypnosis/Disable/Confusion
    Haunter|23|Lick/Hypnosis/Mean Look/Curse
    Electrode|25|Screech/Sonic Boom/Thunder/Rollout`],
  // ---------- Hoenn ----------
  ['Roxanne', 'Omega Ruby & Alpha Sapphire (Rustboro Gym)', 'roxanne', `
    Geodude|12|Tackle/Defense Curl/Rock Tomb
    Nosepass|14|Rock Tomb/Harden/Block/Thunder Wave`],
  ['Brawly', 'Omega Ruby & Alpha Sapphire (Dewford Gym)', 'brawly', `
    Machop|14|Bulk Up/Karate Chop/Seismic Toss
    Makuhita|16|Bulk Up/Arm Thrust/Sand Attack/Knock Off`],
  ['Wattson', 'Omega Ruby & Alpha Sapphire (Mauville Gym)', 'wattson', `
    Magnemite|19|Volt Switch/Supersonic/Mirror Shot
    Voltorb|19|Volt Switch/Screech/Rollout
    Magneton|21|Volt Switch/Supersonic/Mirror Shot
    Manectric|24|Shock Wave/Quick Attack/Howl/Thunder Wave`],
  ['Flannery', 'Omega Ruby & Alpha Sapphire (Lavaridge Gym)', 'flannery', `
    Slugma|26|Overheat/Rock Slide/Smokescreen
    Numel|26|Overheat/Earth Power/Sunny Day
    Camerupt|28|Overheat/Earth Power/Sunny Day/Rock Slide
    Torkoal|30|Overheat/Body Slam/Sunny Day/Attract`],
  ['Norman', 'Omega Ruby & Alpha Sapphire (Petalburg Gym)', 'norman', `
    Slaking|28|Retaliate/Feint Attack/Yawn
    Vigoroth|30|Retaliate/Slash/Encore/Feint Attack
    Linoone|29|Headbutt/Belly Drum/Slash
    Slaking|31|Retaliate/Feint Attack/Yawn/Chip Away`],
  ['Winona', 'Omega Ruby & Alpha Sapphire (Fortree Gym)', 'winona', `
    Swellow|33|Aerial Ace/Double Team/Quick Attack/Endeavor
    Pelipper|33|Aerial Ace/Water Gun/Supersonic/Protect
    Skarmory|34|Aerial Ace/Sand Attack/Spikes/Steel Wing
    Altaria|35|Aerial Ace/Dragon Pulse/Cotton Guard/Earthquake`],
  ['Tate and Liza', 'Omega Ruby & Alpha Sapphire (Mossdeep Gym)', 'tateandliza-gen3', `
    Lunatone|45|Psychic/Hypnosis/Moonblast/Rock Slide
    Solrock|45|Psychic/Solar Beam/Flare Blitz/Rock Slide
    Claydol|44|Psychic/Earth Power/Light Screen/Reflect
    Xatu|44|Psychic/Night Shade/Confuse Ray/Calm Mind`, ['tate', 'liza']],
  ['Juan', 'Emerald (Sootopolis Gym)', 'juan', `
    Luvdisc|41|Water Pulse/Attract/Sweet Kiss/Flail
    Whiscash|41|Rain Dance/Water Pulse/Amnesia/Earthquake
    Sealeo|43|Encore/Body Slam/Aurora Beam/Water Pulse
    Crawdaunt|43|Water Pulse/Crabhammer/Taunt/Leer
    Kingdra|46|Water Pulse/Double Team/Ice Beam/Rest`],
  ['Sidney', 'Omega Ruby & Alpha Sapphire (Elite Four)', 'sidney', `
    Mightyena|50|Crunch/Swagger/Sand Attack/Rock Smash
    Shiftry|50|Leaf Blade/Feint Attack/Fake Out/Swagger
    Cacturne|50|Sucker Punch/Spiky Shield/Leech Seed/Seed Bomb
    Sharpedo|50|Crunch/Waterfall/Aqua Jet/Swagger
    Absol|52|Night Slash/Psycho Cut/Swords Dance/Aerial Ace`],
  ['Glacia', 'Omega Ruby & Alpha Sapphire (Elite Four)', 'glacia', `
    Glalie|50|Ice Fang/Crunch/Hail/Freeze-Dry
    Froslass|50|Ice Beam/Shadow Ball/Hail/Will-O-Wisp
    Glalie|50|Ice Fang/Crunch/Hail/Freeze-Dry
    Froslass|50|Ice Beam/Shadow Ball/Hail/Will-O-Wisp
    Walrein|52|Blizzard/Surf/Body Slam/Sheer Cold`],
  ['Brendan', 'Omega Ruby & Alpha Sapphire (the player)', 'brendan', `
    Sceptile|60|Leaf Blade/Dragon Claw/Earthquake/X-Scissor
    Swampert|58|Waterfall/Earthquake/Ice Punch/Stealth Rock
    Blaziken|58|Blaze Kick/Sky Uppercut/Brave Bird/Swords Dance
    Gardevoir|56|Psychic/Moonblast/Calm Mind/Thunderbolt
    Groudon|62|Precipice Blades/Fire Punch/Stone Edge/Swords Dance`],
  ['May', 'Omega Ruby & Alpha Sapphire (the player)', 'may', `
    Blaziken|60|Blaze Kick/Sky Uppercut/Brave Bird/Swords Dance
    Swampert|58|Waterfall/Earthquake/Ice Punch/Stealth Rock
    Sceptile|58|Leaf Blade/Dragon Claw/Earthquake/X-Scissor
    Beautifly|54|Bug Buzz/Air Slash/Quiver Dance/Giga Drain
    Kyogre|62|Origin Pulse/Ice Beam/Thunder/Calm Mind`],
  ['Courtney', 'Omega Ruby & Alpha Sapphire (Team Magma)', 'courtney', `
    Numel|46|Ember/Magnitude/Focus Energy
    Mightyena|46|Bite/Sand Attack/Roar/Take Down
    Camerupt|48|Flamethrower/Earth Power/Rock Slide/Lava Plume`],
  ['Tabitha', 'Omega Ruby & Alpha Sapphire (Team Magma)', 'tabitha', `
    Numel|38|Ember/Magnitude/Focus Energy
    Golbat|38|Bite/Wing Attack/Confuse Ray/Poison Fang
    Camerupt|40|Lava Plume/Earth Power/Rock Slide`],
  ['Matt', 'Omega Ruby & Alpha Sapphire (Team Aqua)', 'matt', `
    Carvanha|46|Bite/Aqua Jet/Screech
    Golbat|46|Bite/Wing Attack/Confuse Ray/Poison Fang
    Sharpedo|48|Crunch/Waterfall/Aqua Jet/Ice Fang`],
  ['Shelly', 'Omega Ruby & Alpha Sapphire (Team Aqua)', 'shelly', `
    Carvanha|38|Bite/Aqua Jet/Screech
    Mightyena|38|Bite/Sand Attack/Roar/Take Down
    Sharpedo|40|Crunch/Waterfall/Aqua Jet/Ice Fang`],
  ['Zinnia', 'Omega Ruby & Alpha Sapphire (Delta Episode)', 'zinnia', `
    Tyrantrum|68|Dragon Claw/Head Smash/Earthquake/Crunch
    Altaria|68|Dragon Pulse/Moonblast/Cotton Guard/Hurricane
    Noivern|68|Boomburst/Dragon Pulse/Air Slash/Flamethrower
    Goodra|68|Dragon Pulse/Sludge Bomb/Thunderbolt/Fire Blast
    Salamence|70|Dragon Claw/Fly/Earthquake/Dragon Dance`],
  ['Brandon', 'Emerald (Pyramid King)', 'brandon', `
    Regirock|60|Stone Edge/Earthquake/Hammer Arm/Curse
    Regice|60|Ice Beam/Thunderbolt/Amnesia/Rest
    Registeel|60|Iron Head/Earthquake/Curse/Rest`],
  ['Anabel', 'Emerald (Salon Maiden)', 'anabel', `
    Alakazam|60|Psychic/Shadow Ball/Calm Mind/Recover
    Entei|60|Sacred Fire/Extreme Speed/Stone Edge/Calm Mind
    Snorlax|60|Body Slam/Crunch/Rest/Curse`],
  ['Tucker', 'Emerald (Dome Ace)', 'tucker', `
    Salamence|60|Dragon Claw/Earthquake/Flamethrower/Dragon Dance
    Charizard|60|Flamethrower/Air Slash/Dragon Pulse/Focus Blast
    Swampert|60|Waterfall/Earthquake/Ice Beam/Stealth Rock`],
  // ---------- Sinnoh ----------
  ['Roark', 'Platinum (Oreburgh Gym)', 'roark', `
    Geodude|12|Stealth Rock/Rock Throw/Tackle
    Onix|12|Stealth Rock/Rock Throw/Screech
    Cranidos|14|Headbutt/Pursuit/Leer`],
  ['Gardenia', 'Platinum (Eterna Gym)', 'gardenia', `
    Cherubi|19|Grass Knot/Leech Seed/Safeguard
    Turtwig|19|Razor Leaf/Reflect/Grass Knot
    Roserade|22|Magical Leaf/Grass Knot/Stun Spore/Poison Sting`],
  ['Maylene', 'Platinum (Veilstone Gym)', 'maylene', `
    Meditite|28|Drain Punch/Confusion/Rock Tomb
    Machoke|29|Karate Chop/Strength/Focus Energy/Rock Tomb
    Lucario|32|Drain Punch/Metal Claw/Bone Rush/Force Palm`],
  ['Crasher Wake', 'Platinum (Pastoria Gym)', 'crasherwake', `
    Gyarados|33|Waterfall/Bite/Twister/Dragon Rage
    Quagsire|34|Water Pulse/Mud Shot/Rock Tomb/Yawn
    Floatzel|37|Brine/Crunch/Ice Fang/Aqua Jet`, ['wake']],
  ['Fantina', 'Platinum (Hearthome Gym)', 'fantina', `
    Duskull|24|Will-O-Wisp/Future Sight/Shadow Sneak/Pursuit
    Haunter|24|Shadow Claw/Sucker Punch/Confuse Ray/Hypnosis
    Mismagius|26|Shadow Ball/Psybeam/Magical Leaf/Confuse Ray`],
  ['Byron', 'Platinum (Canalave Gym)', 'byron', `
    Magneton|37|Flash Cannon/Tri Attack/Thunderbolt/Metal Sound
    Steelix|38|Flash Cannon/Ice Fang/Earthquake/Sandstorm
    Bastiodon|41|Metal Burst/Iron Defense/Stone Edge/Taunt`],
  ['Candice', 'Platinum (Snowpoint Gym)', 'candice', `
    Sneasel|40|Avalanche/Slash/Quick Attack/Shadow Claw
    Piloswine|40|Avalanche/Earthquake/Ice Shard/Stone Edge
    Abomasnow|42|Avalanche/Wood Hammer/Water Pulse/Grass Knot
    Froslass|44|Blizzard/Double Team/Psychic/Shadow Ball`],
  ['Aaron', 'Platinum (Elite Four)', 'aaron', `
    Dustox|53|Bug Buzz/Psychic/Toxic/Protect
    Beautifly|53|Bug Buzz/Psychic/Silver Wind/Energy Ball
    Vespiquen|54|Attack Order/Defend Order/Heal Order/Power Gem
    Heracross|54|Megahorn/Close Combat/Stone Edge/Night Slash
    Drapion|57|X-Scissor/Cross Poison/Ice Fang/Aerial Ace`],
  ['Bertha', 'Platinum (Elite Four)', 'bertha', `
    Whiscash|55|Earthquake/Aqua Tail/Zen Headbutt/Sandstorm
    Gliscor|55|Earthquake/Fire Fang/Ice Fang/Thunder Fang
    Hippowdon|56|Earthquake/Stone Edge/Crunch/Yawn
    Golem|56|Earthquake/Stone Edge/Fire Punch/Thunder Punch
    Rhyperior|59|Earthquake/Rock Wrecker/Megahorn/Avalanche`],
  ['Barry', 'Platinum (rival)', 'barry', `
    Staraptor|48|Brave Bird/Close Combat/Quick Attack/U-turn
    Heracross|47|Megahorn/Close Combat/Night Slash/Stone Edge
    Floatzel|47|Waterfall/Crunch/Ice Fang/Aqua Jet
    Roserade|48|Energy Ball/Sludge Bomb/Shadow Ball/Extrasensory
    Snorlax|49|Body Slam/Crunch/Rest/Earthquake
    Infernape|51|Flare Blitz/Close Combat/Mach Punch/Thunder Punch`],
  ['Dawn', 'Diamond & Pearl (the player)', 'dawn', `
    Empoleon|58|Surf/Flash Cannon/Ice Beam/Grass Knot
    Togekiss|56|Air Slash/Aura Sphere/Thunder Wave/Roost
    Lopunny|55|Return/High Jump Kick/Ice Punch/Fake Out
    Pachirisu|52|Super Fang/Discharge/Nuzzle/Follow Me
    Mamoswine|56|Earthquake/Icicle Crash/Ice Shard/Stone Edge
    Palkia|60|Spacial Rend/Hydro Pump/Thunder/Fire Blast`],
  ['Lucas', 'Diamond & Pearl (the player)', 'lucas', `
    Torterra|58|Wood Hammer/Earthquake/Stone Edge/Synthesis
    Infernape|56|Flare Blitz/Close Combat/Mach Punch/U-turn
    Luxray|56|Wild Charge/Crunch/Ice Fang/Fire Fang
    Garchomp|57|Earthquake/Dragon Claw/Fire Fang/Swords Dance
    Dialga|60|Roar of Time/Flash Cannon/Earth Power/Thunderbolt`],
  ['Mars', 'Platinum (Team Galactic)', 'mars', `
    Bronzor|38|Confuse Ray/Extrasensory/Gyro Ball
    Golbat|38|Air Cutter/Bite/Confuse Ray
    Purugly|40|Fake Out/Slash/Hypnosis/Shadow Claw`],
  ['Jupiter', 'Platinum (Team Galactic)', 'jupiter', `
    Bronzor|38|Confuse Ray/Extrasensory/Gyro Ball
    Golbat|40|Air Cutter/Bite/Confuse Ray
    Skuntank|42|Night Slash/Poison Jab/Flamethrower/Screech`],
  ['Saturn', 'Platinum (Team Galactic)', 'saturn', `
    Kadabra|42|Psybeam/Recover/Future Sight/Reflect
    Bronzong|42|Gyro Ball/Extrasensory/Confuse Ray/Payback
    Toxicroak|44|Poison Jab/Revenge/Sucker Punch/Swagger`],
  ['Palmer', 'Platinum (Tower Tycoon)', 'palmer', `
    Rhyperior|60|Earthquake/Rock Wrecker/Megahorn/Avalanche
    Milotic|60|Surf/Ice Beam/Mirror Coat/Recover
    Regigigas|60|Crush Grip/Earthquake/Thunder Punch/Drain Punch
    Dragonite|60|Outrage/Extreme Speed/Earthquake/Fire Punch
    Heatran|60|Magma Storm/Earth Power/Flash Cannon/Stone Edge`],
  ['Thorton', 'Platinum (Factory Head)', 'thorton', `
    Bronzong|60|Gyro Ball/Earthquake/Trick Room/Explosion
    Porygon-Z|60|Tri Attack/Thunderbolt/Ice Beam/Nasty Plot
    Magnezone|60|Thunderbolt/Flash Cannon/Hidden Power/Magnet Rise`],
  ['Dahlia', 'Platinum (Arcade Star)', 'dahlia', `
    Ludicolo|60|Surf/Energy Ball/Ice Beam/Rain Dance
    Blaziken|60|Blaze Kick/Sky Uppercut/Thunder Punch/Swords Dance
    Togekiss|60|Air Slash/Aura Sphere/Thunder Wave/Roost
    Dusknoir|60|Shadow Punch/Earthquake/Ice Punch/Trick Room`],
  ['Argenta', 'Platinum (Castle Valet)', 'argenta', `
    Skarmory|60|Steel Wing/Brave Bird/Spikes/Roost
    Blissey|60|Seismic Toss/Soft-Boiled/Toxic/Protect
    Gallade|60|Close Combat/Psycho Cut/Leaf Blade/Swords Dance`],
  ['Darach', 'Platinum (Castle Valet)', 'darach', `
    Houndoom|60|Flamethrower/Dark Pulse/Nasty Plot/Sucker Punch
    Staraptor|60|Brave Bird/Close Combat/U-turn/Quick Attack
    Gallade|60|Close Combat/Psycho Cut/Leaf Blade/Swords Dance`],
  // ---------- Unova ----------
  ['Cilan', 'Black & White (Striaton Gym)', 'cilan', `
    Lillipup|12|Bite/Work Up/Tackle
    Pansage|14|Vine Whip/Bite/Work Up/Leer`],
  ['Chili', 'Black & White (Striaton Gym)', 'chili', `
    Lillipup|12|Bite/Work Up/Tackle
    Pansear|14|Incinerate/Bite/Work Up/Leer`],
  ['Cress', 'Black & White (Striaton Gym)', 'cress', `
    Lillipup|12|Bite/Work Up/Tackle
    Panpour|14|Water Gun/Bite/Work Up/Leer`],
  ['Lenora', 'Black & White (Nacrene Gym)', 'lenora', `
    Herdier|18|Take Down/Leer/Retaliate/Bite
    Watchog|20|Retaliate/Leer/Crunch/Hypnosis`],
  ['Burgh', 'Black & White (Castelia Gym)', 'burgh', `
    Whirlipede|21|Struggle Bug/Poison Tail/Screech/Pursuit
    Dwebble|21|Struggle Bug/Smack Down/Sand Attack/Feint Attack
    Leavanny|23|Struggle Bug/Razor Leaf/String Shot/Protect`],
  ['Clay', 'Black & White (Driftveil Gym)', 'clay', `
    Krokorok|29|Bulldoze/Crunch/Sand Tomb/Torment
    Palpitoad|29|Bulldoze/Bubble Beam/Aqua Ring/Uproar
    Excadrill|31|Bulldoze/Rock Slide/Hone Claws/Metal Claw`],
  ['Skyla', 'Black & White (Mistralton Gym)', 'skyla', `
    Swoobat|33|Acrobatics/Heart Stamp/Amnesia/Attract
    Unfezant|33|Air Slash/Leer/Quick Attack/Razor Wind
    Swanna|35|Air Slash/Bubble Beam/Aqua Ring/Roost`],
  ['Brycen', 'Black & White (Icirrus Gym)', 'brycen', `
    Vanillish|37|Frost Breath/Mirror Shot/Ice Beam/Acid Armor
    Cryogonal|37|Frost Breath/Rapid Spin/Ice Beam/Reflect
    Beartic|39|Frost Breath/Icicle Crash/Brine/Slash`],
  ['Drayden', 'Black 2 & White 2 (Opelucid Gym)', 'drayden', `
    Druddigon|46|Dragon Tail/Revenge/Night Slash/Retaliate
    Flygon|46|Dragon Tail/Earthquake/Fire Punch/U-turn
    Haxorus|48|Dragon Tail/Dragon Dance/Earthquake/Assurance`],
  ['Cheren', 'Black 2 & White 2 (Aspertia Gym)', 'cheren', `
    Patrat|11|Bite/Work Up/Detect
    Lillipup|13|Work Up/Bite/Take Down`],
  ['Roxie', 'Black 2 & White 2 (Virbank Gym)', 'roxie', `
    Koffing|16|Assurance/Venoshock/Smog/Tackle
    Whirlipede|18|Venoshock/Pursuit/Screech/Poison Tail`],
  ['Marlon', 'Black 2 & White 2 (Humilau Gym)', 'marlon', `
    Carracosta|49|Scald/Crunch/Aqua Jet/Shell Smash
    Wailord|49|Scald/Water Spout/Hydro Pump/Rest
    Jellicent|51|Scald/Shadow Ball/Recover/Will-O-Wisp`],
  ['Shauntal', 'Black & White (Elite Four)', 'shauntal', `
    Cofagrigus|48|Shadow Ball/Psychic/Will-O-Wisp/Grass Knot
    Jellicent|48|Shadow Ball/Psychic/Brine/Ice Beam
    Golurk|48|Shadow Punch/Earthquake/Brick Break/Heavy Slam
    Chandelure|50|Shadow Ball/Fire Blast/Payback/Energy Ball`],
  ['Marshal', 'Black & White (Elite Four)', 'marshal', `
    Throh|48|Storm Throw/Rock Tomb/Bulk Up/Payback
    Sawk|48|Close Combat/Rock Slide/Bulk Up/Retaliate
    Mienshao|48|High Jump Kick/Bounce/U-turn/Retaliate
    Conkeldurr|50|Hammer Arm/Stone Edge/Bulk Up/Retaliate`],
  ['Caitlin', 'Black & White (Elite Four)', 'caitlin', `
    Reuniclus|48|Psychic/Focus Blast/Shadow Ball/Reflect
    Musharna|48|Psychic/Shadow Ball/Charge Beam/Reflect
    Sigilyph|48|Psychic/Air Slash/Ice Beam/Shadow Ball
    Gothitelle|50|Psychic/Thunderbolt/Flash/Calm Mind`],
  ['Bianca', 'Black & White (rival)', 'bianca', `
    Musharna|47|Psybeam/Moonlight/Yawn/Hypnosis
    Stoutland|48|Take Down/Crunch/Retaliate/Work Up
    Chandelure|48|Flamethrower/Shadow Ball/Payback/Will-O-Wisp
    Emboar|51|Flare Blitz/Hammer Arm/Head Smash/Arm Thrust`],
  ['Hilbert', 'Black & White (the player)', 'hilbert', `
    Samurott|60|Razor Shell/Megahorn/Aqua Jet/Swords Dance
    Zoroark|56|Night Daze/Flamethrower/Focus Blast/Nasty Plot
    Haxorus|57|Outrage/Earthquake/Dragon Dance/Poison Jab
    Galvantula|55|Thunder/Bug Buzz/Energy Ball/Sticky Web
    Zekrom|60|Bolt Strike/Outrage/Dragon Claw/Hone Claws`],
  ['Hilda', 'Black & White (the player)', 'hilda', `
    Emboar|60|Flare Blitz/Hammer Arm/Head Smash/Wild Charge
    Serperior|57|Leaf Storm/Dragon Pulse/Glare/Leech Seed
    Excadrill|57|Earthquake/Iron Head/Rock Slide/Swords Dance
    Scolipede|55|Megahorn/Poison Jab/Earthquake/Swords Dance
    Reshiram|60|Blue Flare/Dragon Pulse/Fusion Flare/Earth Power`],
  ['Colress', 'Black 2 & White 2 (Team Plasma)', 'colress', `
    Magneton|50|Discharge/Flash Cannon/Tri Attack/Magnet Rise
    Metang|50|Psychic/Iron Defense/Meteor Mash/Zen Headbutt
    Beheeyem|50|Psychic/Signal Beam/Recover/Charge Beam
    Rotom|50|Discharge/Shadow Ball/Hex/Electro Ball
    Klinklang|52|Gear Grind/Discharge/Shift Gear/Flash Cannon`],
  ['Zinzolin', 'Black 2 & White 2 (Team Plasma)', 'zinzolin', `
    Cryogonal|48|Ice Beam/Rapid Spin/Recover/Reflect
    Weavile|50|Night Slash/Ice Shard/Fake Out/Metal Claw`],
  ['Hugh', 'Black 2 & White 2 (rival)', 'hugh', `
    Unfezant|57|Air Slash/Quick Attack/Night Slash/Detect
    Simisage|57|Seed Bomb/Crunch/Acrobatics/Work Up
    Bouffalant|57|Head Charge/Megahorn/Wild Charge/Swords Dance
    Eelektross|57|Wild Charge/Crunch/Flamethrower/Coil
    Samurott|59|Razor Shell/Megahorn/Aqua Jet/Swords Dance`],
  // ---------- Kalos ----------
  ['Viola', 'X & Y (Santalune Gym)', 'viola', `
    Surskit|10|Quick Attack/Water Sport/Bubble
    Vivillon|12|Infestation/Tackle/Harden`],
  ['Grant', 'X & Y (Cyllage Gym)', 'grant', `
    Amaura|25|Rock Tomb/Thunder Wave/Take Down/Aurora Beam
    Tyrunt|25|Rock Tomb/Bite/Stomp/Charm`],
  ['Korrina', 'X & Y (Shalour Gym)', 'korrina', `
    Mienfoo|29|Power-Up Punch/Fake Out/Detect
    Machoke|28|Power-Up Punch/Leer/Bulk Up
    Hawlucha|32|Power-Up Punch/Flying Press/Hone Claws/Swords Dance
    Lucario|35|Power-Up Punch/Bone Rush/Bulk Up/Metal Claw`],
  ['Ramos', 'X & Y (Coumarine Gym)', 'ramos', `
    Jumpluff|30|Acrobatics/Leech Seed/Grass Knot/Stun Spore
    Weepinbell|31|Grass Knot/Acid/Sleep Powder/Poison Powder
    Gogoat|34|Grass Knot/Bulldoze/Take Down/Leech Seed`],
  ['Clemont', 'X & Y (Lumiose Gym)', 'clemont', `
    Emolga|35|Volt Switch/Aerial Ace/Quick Attack
    Magneton|35|Electric Terrain/Mirror Shot/Thunderbolt
    Heliolisk|37|Thunderbolt/Quick Attack/Razor Wind/Grass Knot`],
  ['Valerie', 'X & Y (Laverre Gym)', 'valerie', `
    Mawile|38|Iron Head/Crunch/Fairy Wind/Fake Tears
    Mr. Mime|39|Psychic/Reflect/Light Screen/Dazzling Gleam
    Sylveon|42|Dazzling Gleam/Swift/Charm/Quick Attack`],
  ['Olympia', 'X & Y (Anistar Gym)', 'olympia', `
    Sigilyph|44|Psychic/Air Slash/Reflect/Light Screen
    Slowking|45|Psychic/Yawn/Power Gem/Calm Mind
    Meowstic|48|Psychic/Fake Out/Light Screen/Reflect`],
  ['Wulfric', 'X & Y (Snowbelle Gym)', 'wulfric', `
    Abomasnow|56|Ice Shard/Ice Beam/Wood Hammer/Ingrain
    Cryogonal|55|Ice Beam/Confuse Ray/Reflect/Flash Cannon
    Avalugg|59|Avalanche/Crunch/Gyro Ball/Curse`],
  ['Malva', 'X & Y (Elite Four)', 'malva', `
    Pyroar|63|Flamethrower/Hyper Voice/Wild Charge/Noble Roar
    Torkoal|63|Flamethrower/Earth Power/Stealth Rock/Body Slam
    Chandelure|63|Flamethrower/Shadow Ball/Confuse Ray/Flash Cannon
    Talonflame|65|Flare Blitz/Brave Bird/Quick Attack/Steel Wing`],
  ['Siebold', 'X & Y (Elite Four)', 'siebold', `
    Clawitzer|63|Water Pulse/Dark Pulse/Dragon Pulse/Aura Sphere
    Starmie|63|Surf/Psychic/Thunderbolt/Ice Beam
    Gyarados|63|Waterfall/Earthquake/Ice Fang/Dragon Dance
    Barbaracle|65|Razor Shell/Stone Edge/Cross Chop/Shell Smash`],
  ['Wikstrom', 'X & Y (Elite Four)', 'wikstrom', `
    Klefki|63|Flash Cannon/Dazzling Gleam/Spikes/Swagger
    Probopass|63|Flash Cannon/Power Gem/Earth Power/Discharge
    Scizor|63|Bullet Punch/X-Scissor/Iron Head/Night Slash
    Aegislash|65|Iron Head/Sacred Sword/Shadow Claw/King's Shield`],
  ['Drasna', 'X & Y (Elite Four)', 'drasna', `
    Dragalge|63|Dragon Pulse/Sludge Bomb/Thunderbolt/Focus Blast
    Druddigon|63|Dragon Tail/Crunch/Superpower/Fire Punch
    Altaria|63|Dragon Pulse/Moonblast/Cotton Guard/Roost
    Noivern|65|Dragon Pulse/Air Slash/Boomburst/Flamethrower`],
  ['Calem', 'X & Y (the player)', 'calem', `
    Chesnaught|60|Wood Hammer/Drain Punch/Spiky Shield/Leech Seed
    Delphox|58|Fire Blast/Psychic/Dazzling Gleam/Calm Mind
    Greninja|58|Hydro Pump/Dark Pulse/Ice Beam/Water Shuriken
    Charizard|58|Flare Blitz/Dragon Claw/Earthquake/Dragon Dance
    Xerneas|60|Moonblast/Focus Blast/Geomancy/Thunder`],
  ['Serena', 'X & Y (the player)', 'serena', `
    Delphox|60|Fire Blast/Psychic/Dazzling Gleam/Calm Mind
    Sylveon|58|Moonblast/Hyper Voice/Calm Mind/Wish
    Pancham|52|Crunch/Close Combat/Parting Shot/Stone Edge
    Meowstic|56|Psychic/Shadow Ball/Light Screen/Reflect
    Yveltal|60|Oblivion Wing/Dark Pulse/Focus Blast/Sucker Punch`],
  ['Shauna', 'X & Y (friend)', 'shauna', `
    Delcatty|50|Play Rough/Sucker Punch/Wild Charge/Heal Bell
    Goodra|52|Dragon Pulse/Sludge Bomb/Thunderbolt/Fire Blast
    Chesnaught|54|Wood Hammer/Drain Punch/Spiky Shield/Leech Seed`],
  ['Tierno', 'X & Y (friend)', 'tierno', `
    Crawdaunt|50|Crabhammer/Crunch/Swords Dance/Aqua Jet
    Talonflame|50|Flare Blitz/Brave Bird/Quick Attack/Steel Wing
    Roserade|50|Energy Ball/Sludge Bomb/Shadow Ball/Extrasensory`],
  ['AZ', 'X & Y (the king)', 'az', `
    Torkoal|60|Flamethrower/Earth Power/Stealth Rock/Body Slam
    Golurk|60|Earthquake/Shadow Punch/Ice Punch/Rollout
    Sigilyph|60|Psychic/Air Slash/Ice Beam/Shadow Ball`],
  // ---------- Alola ----------
  ['Hala', 'Sun & Moon (Kahuna)', 'hala', `
    Mankey|14|Leer/Fury Swipes/Arm Thrust/Covet
    Makuhita|14|Arm Thrust/Fake Out/Sand Attack
    Crabrawler|15|Brutal Swing/Leer/Pursuit/Power-Up Punch`],
  ['Olivia', 'Sun & Moon (Kahuna)', 'olivia', `
    Nosepass|26|Rock Slide/Thunder Wave/Block/Sandstorm
    Boldore|26|Rock Slide/Headbutt/Smack Down/Sand Attack
    Lycanroc-Midnight|27|Rock Slide/Bite/Counter/Stone Edge`],
  ['Hapu', 'Sun & Moon (Kahuna)', 'hapu', `
    Dugtrio|47|Earthquake/Sucker Punch/Rock Slide/Sandstorm
    Gastrodon|47|Muddy Water/Earth Power/Recover/Ice Beam
    Flygon|47|Dragon Claw/Earthquake/Fire Punch/U-turn
    Mudsdale|48|High Horsepower/Heavy Slam/Rock Smash/Iron Defense`],
  ['Acerola', 'Sun & Moon (Elite Four)', 'acerola', `
    Sableye|54|Shadow Claw/Fake Out/Will-O-Wisp/Recover
    Drifblim|54|Shadow Ball/Psychic/Will-O-Wisp/Stockpile
    Dhelmise|54|Anchor Shot/Shadow Ball/Power Whip/Energy Ball
    Froslass|54|Ice Beam/Shadow Ball/Will-O-Wisp/Destiny Bond
    Palossand|55|Shadow Ball/Earth Power/Shore Up/Giga Drain`],
  ['Kahili', 'Sun & Moon (Elite Four)', 'kahili', `
    Skarmory|54|Steel Wing/Spikes/Roost/Brave Bird
    Crobat|54|Cross Poison/Brave Bird/U-turn/Confuse Ray
    Oricorio|54|Revelation Dance/Hurricane/Teeter Dance/Roost
    Mandibuzz|54|Foul Play/Brave Bird/Roost/Toxic
    Toucannon|55|Beak Blast/Bullet Seed/Rock Blast/Knock Off`],
  ['Molayne', 'Sun & Moon (Elite Four)', 'molayne', `
    Klefki|56|Flash Cannon/Dazzling Gleam/Spikes/Foul Play
    Bisharp|56|Iron Head/Night Slash/Sucker Punch/Swords Dance
    Magnezone|56|Thunderbolt/Flash Cannon/Tri Attack/Mirror Coat
    Metagross|56|Meteor Mash/Zen Headbutt/Earthquake/Bullet Punch
    Dugtrio-Alola|57|Iron Head/Earthquake/Sucker Punch/Sandstorm`],
  ['Hau', 'Sun & Moon (rival)', 'hau', `
    Raichu-Alola|58|Psychic/Thunderbolt/Focus Blast/Nasty Plot
    Tauros|57|Double-Edge/Earthquake/Stone Edge/Zen Headbutt
    Noivern|57|Boomburst/Dragon Pulse/Air Slash/Flamethrower
    Crabominable|57|Ice Hammer/Close Combat/Earthquake/Stone Edge
    Vaporeon|57|Scald/Ice Beam/Wish/Protect
    Primarina|60|Sparkling Aria/Moonblast/Ice Beam/Psychic`],
  ['Lillie', 'Ultra Sun & Ultra Moon (friend)', 'lillie', `
    Clefable|58|Moonblast/Flamethrower/Calm Mind/Moonlight
    Lilligant|58|Petal Dance/Quiver Dance/Sleep Powder/Energy Ball
    Ninetales-Alola|58|Blizzard/Moonblast/Aurora Veil/Freeze-Dry
    Ribombee|58|Pollen Puff/Moonblast/Quiver Dance/Bug Buzz
    Comfey|58|Draining Kiss/Floral Healing/Sweet Kiss/Petal Blizzard
    Magearna|60|Fleur Cannon/Flash Cannon/Aura Sphere/Calm Mind`],
  ['Plumeria', 'Sun & Moon (Team Skull)', 'plumeria', `
    Golbat|37|Air Cutter/Bite/Confuse Ray/Poison Fang
    Salazzle|38|Flame Burst/Venoshock/Toxic/Torment`],
  ['Faba', 'Ultra Sun & Ultra Moon (Aether Foundation)', 'faba', `
    Claydol|56|Earth Power/Psychic/Ancient Power/Light Screen
    Bruxish|56|Psychic Fangs/Aqua Jet/Ice Fang/Crunch
    Hypno|58|Psychic/Hypnosis/Nasty Plot/Dazzling Gleam`],
  ['Ryuki', 'Ultra Sun & Ultra Moon (Champion challenger)', 'ryuki', `
    Turtonator|60|Dragon Pulse/Flamethrower/Shell Trap/Shell Smash
    Garchomp|60|Earthquake/Dragon Claw/Fire Fang/Swords Dance
    Salamence|60|Dragon Claw/Fly/Earthquake/Dragon Dance
    Druddigon|60|Dragon Tail/Crunch/Superpower/Fire Punch
    Kommo-o|62|Clanging Scales/Close Combat/Poison Jab/Dragon Dance`],
  // ---------- Galar ----------
  ['Milo', 'Sword & Shield (Turffield Gym)', 'milo', `
    Gossifleur|19|Magical Leaf/Rapid Spin/Sweet Scent
    Eldegoss|20|Magical Leaf/Round/Leafage/Cotton Spore`],
  ['Nessa', 'Sword & Shield (Hulbury Gym)', 'nessa', `
    Goldeen|22|Horn Attack/Water Pulse/Agility
    Arrokuda|23|Bite/Water Pulse/Aqua Jet
    Drednaw|24|Water Pulse/Bite/Razor Shell/Headbutt`],
  ['Kabu', 'Sword & Shield (Motostoke Gym)', 'kabu', `
    Ninetales|25|Will-O-Wisp/Quick Attack/Fire Spin/Ember
    Arcanine|25|Bite/Flame Wheel/Agility/Fire Spin
    Centiskorch|27|Flame Wheel/Bite/Bug Bite/Smokescreen`],
  ['Bea', 'Sword (Stow-on-Side Gym)', 'bea', `
    Hitmontop|34|Revenge/Quick Attack/Triple Kick/Rapid Spin
    Pangoro|34|Circle Throw/Karate Chop/Bullet Punch/Night Slash
    Sirfetch'd|35|Revenge/Brutal Swing/Leaf Blade/Detect
    Machamp|36|Revenge/Strength/Knock Off/Scary Face`],
  ['Allister', 'Shield (Stow-on-Side Gym)', 'allister', `
    Yamask-Galar|34|Brutal Swing/Hex/Disable/Rock Tomb
    Mimikyu|34|Shadow Sneak/Baby-Doll Eyes/Slash/Play Rough
    Cursola|35|Hex/Ancient Power/Curse/Strength Sap
    Gengar|36|Shadow Ball/Venoshock/Hypnosis/Payback`],
  ['Opal', 'Sword (Ballonlea Gym)', 'opal', `
    Weezing-Galar|36|Fairy Wind/Tackle/Strange Steam/Smog
    Mawile|36|Iron Head/Draining Kiss/Fake Tears/Astonish
    Togekiss|37|Draining Kiss/Air Slash/Ancient Power/Dazzling Gleam
    Alcremie|38|Draining Kiss/Acid Armor/Dazzling Gleam/Sweet Kiss`],
  ['Gordie', 'Sword (Circhester Gym)', 'gordie', `
    Barbaracle|40|Shell Smash/Stone Edge/Razor Shell/Cross Chop
    Shuckle|40|Rock Tomb/Power Trick/Gyro Ball/Bide
    Stonjourner|41|Stone Edge/Body Press/Wonder Room/Stealth Rock
    Coalossal|42|Heat Crash/Stone Edge/Tar Shot/Rapid Spin`],
  ['Melony', 'Shield (Circhester Gym)', 'melony', `
    Frosmoth|40|Icy Wind/Bug Buzz/Quiver Dance/Aurora Veil
    Darmanitan-Galar|40|Icicle Crash/Fire Fang/Headbutt/Belly Drum
    Eiscue|41|Freeze-Dry/Avalanche/Hail/Headbutt
    Lapras|42|Ice Beam/Surf/Sing/Body Slam`],
  ['Piers', 'Sword & Shield (Spikemuth Gym)', 'piers', `
    Scrafty|44|Fake Out/Brick Break/Payback/Swagger
    Malamar|45|Night Slash/Psycho Cut/Foul Play/Topsy-Turvy
    Skuntank|45|Sucker Punch/Toxic/Screech/Flamethrower
    Obstagoon|46|Throat Chop/Obstruct/Shadow Claw/Scary Face`],
  ['Bede', 'Sword & Shield (rival)', 'bede', `
    Mawile|52|Iron Head/Play Rough/Sucker Punch/Swords Dance
    Gardevoir|53|Psychic/Moonblast/Mystical Fire/Calm Mind
    Rapidash-Galar|53|Psycho Cut/Play Rough/Megahorn/High Horsepower
    Hatterene|55|Psychic/Dazzling Gleam/Mystical Fire/Calm Mind`],
  ['Rose', 'Sword & Shield (Chairman)', 'rose', `
    Escavalier|62|Iron Head/Megahorn/Drill Run/Swords Dance
    Ferrothorn|62|Power Whip/Iron Head/Leech Seed/Spikes
    Perrserker|62|Iron Head/Crunch/Close Combat/Swords Dance
    Klinklang|63|Gear Grind/Wild Charge/Shift Gear/Rock Smash
    Copperajah|64|Heavy Slam/High Horsepower/Play Rough/Rock Slide`, ['chairman rose']],
  ['Oleana', 'Sword & Shield (Macro Cosmos)', 'oleana', `
    Froslass|50|Ice Beam/Shadow Ball/Will-O-Wisp/Hail
    Salazzle|50|Flamethrower/Sludge Bomb/Fake Out/Nasty Plot
    Tsareena|51|Trop Kick/High Jump Kick/Stomp/Swagger
    Garbodor|52|Gunk Shot/Body Slam/Drain Punch/Spikes`],
  ['Mustard', 'Isle of Armor (Master Dojo)', 'mustard', `
    Mienshao|65|Close Combat/U-turn/Stone Edge/Fake Out
    Luxray|65|Wild Charge/Crunch/Ice Fang/Fire Fang
    Corviknight|65|Brave Bird/Body Press/Iron Defense/Roost
    Urshifu|70|Wicked Blow/Close Combat/Sucker Punch/U-turn`],
  ['Peony', 'Crown Tundra (expedition leader)', 'peony', `
    Copperajah|70|Heavy Slam/High Horsepower/Play Rough/Rock Slide
    Aggron|70|Heavy Slam/Earthquake/Stone Edge/Ice Punch`],
  ['Klara', 'Isle of Armor (rival)', 'klara', `
    Slowbro-Galar|65|Shell Side Arm/Psychic/Flamethrower/Trick Room
    Weezing-Galar|65|Strange Steam/Sludge Bomb/Will-O-Wisp/Defog
    Crobat|65|Cross Poison/Brave Bird/U-turn/Confuse Ray`],
  ['Avery', 'Isle of Armor (rival)', 'avery', `
    Slowking-Galar|65|Eerie Spell/Sludge Bomb/Flamethrower/Trick Room
    Alakazam|65|Psychic/Shadow Ball/Focus Blast/Calm Mind
    Mr. Rime|65|Freeze-Dry/Psychic/Rapid Spin/Calm Mind`],
  // ---------- Paldea ----------
  ['Katy', 'Scarlet & Violet (Cortondo Gym)', 'katy', `
    Nymble|14|Struggle Bug/Double Kick/Leer
    Tarountula|14|Struggle Bug/Bug Bite/String Shot
    Teddiursa|15|Fury Cutter/Fury Swipes/Lick/Baby-Doll Eyes`],
  ['Brassius', 'Scarlet & Violet (Artazon Gym)', 'brassius', `
    Petilil|16|Mega Drain/Sleep Powder/Absorb
    Smoliv|16|Razor Leaf/Absorb/Sweet Scent
    Sudowoodo|17|Trailblaze/Rock Throw/Flail/Low Kick`],
  ['Iono', 'Scarlet & Violet (Levincia Gym)', 'iono', `
    Wattrel|23|Spark/Quick Attack/Pluck
    Bellibolt|23|Spark/Water Gun/Slam/Muddy Water
    Luxio|23|Spark/Bite/Quick Attack/Leer
    Mismagius|24|Charge Beam/Hex/Confuse Ray/Psybeam`],
  ['Kofu', 'Scarlet & Violet (Cascarrafa Gym)', 'kofu', `
    Veluza|29|Aqua Cutter/Pluck/Slash/Psycho Cut
    Wugtrio|29|Mud-Slap/Water Pulse/Headbutt/Sucker Punch
    Crabominable|30|Crabhammer/Rock Smash/Slam/Bubble Beam`],
  ['Larry', 'Scarlet & Violet (Medali Gym, Elite Four)', 'larry', `
    Tropius|59|Air Slash/Dragon Pulse/Solar Beam/Sunny Day
    Oricorio-Pom-Pom|59|Revelation Dance/Air Slash/Teeter Dance/Feather Dance
    Altaria|59|Dragon Pulse/Moonblast/Cotton Guard/Hurricane
    Staraptor|60|Brave Bird/Close Combat/Quick Attack/Double-Edge
    Flamigo|61|Brave Bird/Close Combat/Liquidation/Throat Chop`],
  ['Ryme', 'Scarlet & Violet (Montenevera Gym)', 'ryme', `
    Banette|41|Shadow Sneak/Icy Wind/Sucker Punch/Hex
    Mimikyu|41|Shadow Claw/Shadow Sneak/Play Rough/Light Screen
    Houndstone|41|Play Rough/Bulldoze/Phantom Force/Roar
    Toxtricity|42|Hex/Discharge/Hyper Voice/Boomburst`],
  ['Tulip', 'Scarlet & Violet (Alfornada Gym)', 'tulip', `
    Farigiraf|44|Psychic/Zen Headbutt/Crunch/Reflect
    Gardevoir|44|Psychic/Dazzling Gleam/Energy Ball/Mystical Fire
    Espathra|44|Psychic/Lumina Crash/Quick Attack/Reflect
    Florges|45|Psychic/Moonblast/Petal Blizzard/Psychic Noise`],
  ['Grusha', 'Scarlet & Violet (Glaseado Gym)', 'grusha', `
    Frosmoth|47|Ice Beam/Bug Buzz/Tailwind/Blizzard
    Beartic|47|Icicle Crash/Aqua Jet/Rock Slide/Snowscape
    Cetitan|47|Ice Spinner/Liquidation/Entrainment/Ice Shard
    Altaria|48|Ice Beam/Dragon Pulse/Moonblast/Hurricane`],
  ['Rika', 'Scarlet & Violet (Elite Four)', 'rika', `
    Whiscash|57|Earth Power/Muddy Water/Blizzard/Future Sight
    Camerupt|57|Earth Power/Fire Blast/Yawn/Flash Cannon
    Donphan|57|Earthquake/Knock Off/Rapid Spin/Ice Shard
    Dugtrio|57|Earthquake/Sucker Punch/Rock Slide/Sandstorm
    Clodsire|58|Earthquake/Liquidation/Toxic/Protect`],
  ['Poppy', 'Scarlet & Violet (Elite Four)', 'poppy', `
    Copperajah|58|Heavy Slam/High Horsepower/Play Rough/Stealth Rock
    Magnezone|58|Flash Cannon/Thunderbolt/Tri Attack/Light Screen
    Bronzong|58|Flash Cannon/Zen Headbutt/Rock Blast/Reflect
    Corviknight|58|Brave Bird/Body Press/Iron Defense/Roost
    Tinkaton|59|Gigaton Hammer/Play Rough/Knock Off/Stone Edge`],
  ['Hassel', 'Scarlet & Violet (Elite Four)', 'hassel', `
    Noivern|60|Dragon Pulse/Air Slash/Boomburst/Flamethrower
    Haxorus|60|Dragon Claw/Earthquake/Crunch/Dragon Dance
    Dragalge|60|Dragon Pulse/Sludge Bomb/Hydro Pump/Thunderbolt
    Flapple|60|Grav Apple/Dragon Rush/Trailblaze/Dragon Dance
    Baxcalibur|61|Glaive Rush/Icicle Crash/Earthquake/Dragon Dance`],
  ['Arven', 'Scarlet & Violet (friend)', 'arven', `
    Greedent|63|Body Slam/Psychic Fangs/Bullet Seed/Earthquake
    Cloyster|63|Icicle Spear/Rock Blast/Hydro Pump/Shell Smash
    Scovillain|63|Flamethrower/Energy Ball/Crunch/Zen Headbutt
    Toedscruel|63|Earth Power/Giga Drain/Spore/Rapid Spin
    Garganacl|63|Salt Cure/Earthquake/Recover/Stone Edge
    Mabosstiff|65|Crunch/Play Rough/Psychic Fangs/Wild Charge`],
  ['Penny', 'Scarlet & Violet (Team Star)', 'penny', `
    Umbreon|62|Dark Pulse/Moonlight/Foul Play/Toxic
    Vaporeon|62|Scald/Ice Beam/Wish/Protect
    Jolteon|62|Thunderbolt/Shadow Ball/Volt Switch/Thunder Wave
    Flareon|62|Flare Blitz/Superpower/Quick Attack/Will-O-Wisp
    Leafeon|62|Leaf Blade/X-Scissor/Swords Dance/Synthesis
    Sylveon|63|Moonblast/Hyper Voice/Wish/Calm Mind`, ['cassiopeia']],
  ['Clavell', 'Scarlet & Violet (Director)', 'clavell', `
    Abomasnow|65|Blizzard/Wood Hammer/Ice Shard/Earthquake
    Polteageist|65|Shadow Ball/Giga Drain/Shell Smash/Stored Power
    Gyarados|65|Waterfall/Earthquake/Ice Fang/Dragon Dance
    Amoonguss|65|Spore/Giga Drain/Sludge Bomb/Clear Smog
    Meowscarada|66|Flower Trick/Knock Off/U-turn/Play Rough`],
  ['Kieran', 'Indigo Disk (Champion)', 'kieran', `
    Hydrapple|78|Fickle Beam/Draco Meteor/Earth Power/Giga Drain
    Incineroar|78|Flare Blitz/Darkest Lariat/Fake Out/Parting Shot
    Porygon-Z|78|Tri Attack/Thunderbolt/Ice Beam/Nasty Plot
    Kingambit|78|Kowtow Cleave/Iron Head/Sucker Punch/Swords Dance
    Dragapult|78|Dragon Darts/Phantom Force/U-turn/Will-O-Wisp
    Terapagos|80|Tera Starstorm/Earth Power/Dark Pulse/Calm Mind`],
  ['Carmine', 'Teal Mask (rival)', 'carmine', `
    Ludicolo|70|Hydro Pump/Energy Ball/Ice Beam/Rain Dance
    Sinistcha|70|Matcha Gotcha/Shadow Ball/Calm Mind/Strength Sap
    Alakazam|70|Psychic/Shadow Ball/Focus Blast/Calm Mind
    Kingambit|72|Kowtow Cleave/Iron Head/Sucker Punch/Swords Dance`],
  ['Drayton', 'Indigo Disk (Elite Four)', 'drayton', `
    Dragonite|76|Extreme Speed/Outrage/Earthquake/Dragon Dance
    Archaludon|76|Electro Shot/Flash Cannon/Draco Meteor/Body Press
    Flygon|76|Earthquake/Dragon Claw/Fire Punch/U-turn
    Kingdra|76|Draco Meteor/Surf/Ice Beam/Rain Dance
    Haxorus|77|Outrage/Earthquake/Close Combat/Dragon Dance`],
  ['Lacey', 'Indigo Disk (Elite Four)', 'lacey', `
    Granbull|76|Play Rough/Close Combat/Earthquake/Thunder Wave
    Whimsicott|76|Moonblast/Energy Ball/Tailwind/Encore
    Excadrill|76|Earthquake/Iron Head/Rock Slide/Swords Dance
    Primarina|76|Moonblast/Sparkling Aria/Ice Beam/Psychic
    Blissey|77|Seismic Toss/Soft-Boiled/Thunder Wave/Dazzling Gleam`],
  ['Crispin', 'Indigo Disk (Elite Four)', 'crispin', `
    Rotom-Heat|76|Overheat/Thunderbolt/Volt Switch/Will-O-Wisp
    Blaziken|76|Blaze Kick/Close Combat/Brave Bird/Swords Dance
    Houndoom|76|Flamethrower/Dark Pulse/Nasty Plot/Sucker Punch
    Magmortar|76|Fire Blast/Thunderbolt/Focus Blast/Psychic
    Talonflame|77|Flare Blitz/Brave Bird/U-turn/Swords Dance`],
  ['Amarys', 'Indigo Disk (Elite Four)', 'amarys', `
    Skarmory|76|Brave Bird/Body Press/Spikes/Roost
    Corviknight|76|Brave Bird/Body Press/Iron Defense/Roost
    Empoleon|76|Surf/Flash Cannon/Ice Beam/Grass Knot
    Metagross|76|Meteor Mash/Zen Headbutt/Earthquake/Bullet Punch
    Archaludon|77|Electro Shot/Flash Cannon/Draco Meteor/Body Press`],
  ['Briar', 'Indigo Disk (teacher)', 'briar', `
    Kingdra|72|Draco Meteor/Surf/Ice Beam/Rain Dance
    Dragapult|72|Dragon Darts/Phantom Force/U-turn/Will-O-Wisp
    Kommo-o|72|Clanging Scales/Close Combat/Poison Jab/Dragon Dance`],
  ['Sada', 'Scarlet (Professor)', 'sada', `
    Slither Wing|66|First Impression/Close Combat/Flare Blitz/Leech Life
    Scream Tail|66|Play Rough/Psychic Fangs/Stealth Rock/Wish
    Brute Bonnet|66|Spore/Seed Bomb/Crunch/Sucker Punch
    Flutter Mane|66|Moonblast/Shadow Ball/Mystical Fire/Calm Mind
    Sandy Shocks|66|Thunderbolt/Earth Power/Spikes/Volt Switch
    Roaring Moon|67|Crunch/Acrobatics/Earthquake/Dragon Dance`],
  ['Turo', 'Violet (Professor)', 'turo', `
    Iron Moth|66|Fiery Dance/Sludge Wave/Energy Ball/Morning Sun
    Iron Treads|66|Earthquake/Iron Head/Rapid Spin/Ice Spinner
    Iron Bundle|66|Freeze-Dry/Hydro Pump/Flip Turn/Encore
    Iron Hands|66|Drain Punch/Wild Charge/Ice Punch/Swords Dance
    Iron Thorns|66|Wild Charge/Stone Edge/Earthquake/Dragon Dance
    Iron Valiant|67|Moonblast/Close Combat/Spirit Break/Swords Dance`],
  // ---------- Kanto extras ----------
  ['Oak', 'Let’s Go (Professor)', 'oak', `
    Tauros|80|Double-Edge/Earthquake/Stone Edge/Zen Headbutt
    Kangaskhan|80|Mega Punch/Earthquake/Crunch/Fake Out
    Exeggutor|80|Psychic/Wood Hammer/Leech Seed/Sleep Powder
    Arcanine|80|Flare Blitz/Extreme Speed/Wild Charge/Crunch
    Gyarados|80|Waterfall/Earthquake/Ice Fang/Dragon Dance
    Mew|82|Psychic/Aura Sphere/Flamethrower/Thunderbolt`, ['professor oak', 'samuel oak']],
  ['Archer', 'HeartGold & SoulSilver (Team Rocket)', 'archer', `
    Houndour|35|Flamethrower/Bite/Roar/Smog
    Koffing|35|Sludge Bomb/Smokescreen/Self-Destruct
    Houndoom|38|Flamethrower/Crunch/Roar/Feint Attack`],
  ['Ariana', 'HeartGold & SoulSilver (Team Rocket)', 'ariana', `
    Arbok|32|Poison Fang/Glare/Bite/Screech
    Vileplume|32|Petal Dance/Sleep Powder/Acid/Moonlight
    Murkrow|32|Night Shade/Pursuit/Haze/Wing Attack`],
  ['Proton', 'HeartGold & SoulSilver (Team Rocket)', 'proton', `
    Zubat|21|Bite/Supersonic/Leech Life
    Koffing|23|Smog/Sludge/Smokescreen`],
  ['Jessie and James', 'the anime (Team Rocket)', 'jessiejames-gen1', `
    Arbok|30|Poison Fang/Glare/Bite/Wrap
    Weezing|30|Sludge Bomb/Smokescreen/Self-Destruct/Haze
    Meowth|28|Pay Day/Fury Swipes/Bite/Slash
    Wobbuffet|30|Counter/Mirror Coat/Safeguard/Destiny Bond`, ['jessie', 'james', 'team rocket']],
  // ---------- the anime ----------
  ['Paul', 'the anime (Sinnoh rival)', 'paul', `
    Electivire|62|Thunder Punch/Brick Break/Protect/Giga Impact
    Torterra|60|Leaf Storm/Earthquake/Stone Edge/Frenzy Plant
    Honchkrow|60|Night Slash/Sky Attack/Dark Pulse/Haze
    Ursaring|60|Hammer Arm/Hyper Beam/Focus Blast/Protect
    Magmortar|60|Flamethrower/Thunderbolt/Smokescreen/Giga Impact
    Gastrodon|60|Mud Bomb/Water Pulse/Ice Beam/Earthquake`],
  ['Tobias', 'the anime (Sinnoh League)', 'tobias', `
    Darkrai|80|Dark Void/Dark Pulse/Ice Beam/Double Team
    Latios|80|Luster Purge/Dragon Pulse/Psychic/Recover
    Garchomp|78|Earthquake/Dragon Claw/Stone Edge/Swords Dance`],
  ['Alain', 'the anime (Kalos League)', 'alain', `
    Charizard|70|Blast Burn/Dragon Claw/Flamethrower/Steel Wing
    Metagross|68|Meteor Mash/Psychic/Hammer Arm/Bullet Punch
    Weavile|68|Ice Punch/Night Slash/Metal Claw/Double Team
    Tyranitar|68|Stone Edge/Crunch/Earthquake/Dragon Dance
    Bisharp|68|Iron Head/Night Slash/Sucker Punch/Swords Dance
    Unfezant|68|Air Slash/Quick Attack/Steel Wing/Detect`],
  ['Ritchie', 'the anime (Indigo League)', 'ritchie', `
    Pikachu|40|Thunderbolt/Quick Attack/Thunder Wave/Agility
    Butterfree|40|Psybeam/Sleep Powder/Gust/Stun Spore
    Charmeleon|40|Flamethrower/Slash/Dragon Rage/Smokescreen
    Pidgeot|40|Wing Attack/Quick Attack/Whirlwind/Gust`],
  ['Trevor', 'the anime (Kalos)', 'trevor', `
    Charizard|55|Flamethrower/Dragon Claw/Air Slash/Steel Wing
    Florges|55|Moonblast/Petal Blizzard/Calm Mind/Wish
    Aerodactyl|55|Rock Slide/Crunch/Wing Attack/Ancient Power`],
  ['Goh', 'the anime (Journeys)', 'goh', `
    Cinderace|65|Pyro Ball/High Jump Kick/U-turn/Court Change
    Inteleon|65|Snipe Shot/Air Slash/U-turn/Ice Beam
    Lucario|65|Aura Sphere/Flash Cannon/Extreme Speed/Swords Dance
    Mew|70|Psychic/Aura Sphere/Flamethrower/Thunderbolt`],
  ['Liko', 'Horizons (the anime)', 'liko', `
    Floragato|35|Magical Leaf/Quick Attack/Bite/Leafage
    Terapagos|40|Tackle/Withdraw/Rapid Spin/Tera Starstorm`],
  // ---------- spin-offs and Battle Frontier ----------
  ['Noland', 'Emerald (Factory Head)', 'noland', `
    Articuno|60|Ice Beam/Hurricane/Roost/Freeze-Dry
    Zapdos|60|Thunderbolt/Heat Wave/Roost/Volt Switch
    Moltres|60|Flamethrower/Air Slash/Roost/Will-O-Wisp`],
  ['Greta', 'Emerald (Arena Tycoon)', 'greta', `
    Heracross|60|Megahorn/Close Combat/Stone Edge/Night Slash
    Umbreon|60|Foul Play/Moonlight/Toxic/Wish
    Gengar|60|Shadow Ball/Sludge Bomb/Focus Blast/Hypnosis`],
  ['Lucy', 'Emerald (Pike Queen)', 'lucy', `
    Seviper|60|Poison Jab/Crunch/Earthquake/Glare
    Milotic|60|Surf/Ice Beam/Recover/Mirror Coat
    Shuckle|60|Toxic/Rest/Encore/Wrap`],
  ['Spenser', 'Emerald (Palace Maven)', 'spenser', `
    Slaking|60|Return/Earthquake/Shadow Claw/Slack Off
    Lapras|60|Surf/Ice Beam/Body Slam/Confuse Ray
    Crobat|60|Cross Poison/Brave Bird/U-turn/Confuse Ray`],
  ['Wes', 'Colosseum (the hero)', 'wes', `
    Espeon|50|Psychic/Shadow Ball/Morning Sun/Reflect
    Umbreon|50|Foul Play/Moonlight/Confuse Ray/Feint Attack
    Tyranitar|52|Crunch/Earthquake/Rock Slide/Dragon Dance`],
  ['Michael', 'XD: Gale of Darkness (the hero)', 'michael', `
    Salamence|55|Dragon Claw/Fly/Earthquake/Dragon Dance
    Metagross|55|Meteor Mash/Psychic/Earthquake/Bullet Punch
    Lugia|58|Aeroblast/Psychic/Recover/Calm Mind`],
  ['Rei', 'Legends: Arceus (the hero)', 'rei', `
    Decidueye-Hisui|65|Triple Arrows/Brave Bird/Leaf Blade/Shadow Sneak
    Typhlosion-Hisui|65|Infernal Parade/Eruption/Focus Blast/Calm Mind
    Samurott-Hisui|65|Ceaseless Edge/Razor Shell/Aqua Jet/Swords Dance
    Arceus|70|Judgment/Extreme Speed/Recover/Calm Mind`, ['akari']],
  ['Adaman', 'Legends: Arceus (Diamond Clan)', 'adaman', `
    Vaporeon|62|Scald/Ice Beam/Wish/Protect
    Crobat|62|Cross Poison/Brave Bird/U-turn/Confuse Ray
    Leafeon|62|Leaf Blade/X-Scissor/Swords Dance/Synthesis
    Umbreon|62|Dark Pulse/Moonlight/Foul Play/Toxic
    Dialga-Origin|65|Roar of Time/Flash Cannon/Earth Power/Thunderbolt`],
  ['Irida', 'Legends: Arceus (Pearl Clan)', 'irida', `
    Flareon|62|Flare Blitz/Superpower/Quick Attack/Will-O-Wisp
    Glaceon|62|Ice Beam/Shadow Ball/Calm Mind/Wish
    Espeon|62|Psychic/Shadow Ball/Morning Sun/Calm Mind
    Delibird|60|Ice Shard/Drill Peck/Present/Spikes
    Palkia-Origin|65|Spacial Rend/Hydro Pump/Thunder/Fire Blast`],
];
