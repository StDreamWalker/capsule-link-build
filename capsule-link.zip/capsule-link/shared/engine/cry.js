// Chiptune cries. Notation: "E5:2 G5:2 r:1 C6:4" — note name + octave, then length in ticks.
// One tick is 40 ms on every device (PC, phone, capsule buzzer). "r" or "-" is a rest.
import { hashString } from './rng.js';

export const CRY_TICK_MS = 40;
export const CRY_MAX_NOTES = 12;

const NOTE_INDEX = { C: 0, 'C#': 1, DB: 1, D: 2, 'D#': 3, EB: 3, E: 4, F: 5, 'F#': 6, GB: 6, G: 7, 'G#': 8, AB: 8, A: 9, 'A#': 10, BB: 10, B: 11 };
const NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

/** -> [{ midi (0 = rest), ticks }] */
export function parseCry(src) {
  const out = [];
  for (const tok of String(src ?? '').trim().split(/[\s,]+/).filter(Boolean)) {
    const m = /^([A-Ga-g][#b]?|r|-)(-?\d)?(?::(\d+))?$/i.exec(tok);
    if (!m) throw new Error(`Cannot read note "${tok}". Use a form like C5:2 or r:1.`);
    const ticks = Math.max(1, Math.min(255, Number(m[3] ?? 2)));
    if (m[1] === 'r' || m[1] === 'R' || m[1] === '-') { out.push({ midi: 0, ticks }); continue; }
    const name = m[1].length === 2 ? m[1][0].toUpperCase() + m[1][1].toUpperCase() : m[1].toUpperCase();
    const pc = NOTE_INDEX[name];
    if (pc == null) throw new Error(`Unknown note "${tok}".`);
    const octave = Number(m[2] ?? 5);
    const midi = (octave + 1) * 12 + pc;
    out.push({ midi: Math.max(1, Math.min(127, midi)), ticks });
  }
  return out.slice(0, CRY_MAX_NOTES);
}

export function formatCry(notes) {
  return notes.map((n) => (n.midi ? `${NAMES[n.midi % 12]}${Math.floor(n.midi / 12) - 1}` : 'r') + `:${n.ticks}`).join(' ');
}

export const midiToHz = (m) => 440 * Math.pow(2, (m - 69) / 12);

/** A cry generated from the species id, used when the Data Lab has none. */
export function defaultCry(speciesId, baseStats) {
  let h = hashString(speciesId || 'x');
  const next = () => { h = Math.imul(h ^ (h >>> 13), 0x5bd1e995) >>> 0; return h; };
  const scale = [0, 2, 4, 7, 9, 12, 14];
  // heavier creatures get lower voices
  const bulk = baseStats ? (baseStats.hp + baseStats.def) / 2 : 60;
  const root = 60 + (bulk > 85 ? -12 : bulk < 50 ? 12 : 0) + (next() % 5);
  const count = 3 + (next() % 3);
  const notes = [];
  for (let i = 0; i < count; i++) {
    const deg = scale[next() % scale.length];
    notes.push({ midi: root + deg, ticks: i === count - 1 ? 4 + (next() % 3) : 1 + (next() % 3) });
  }
  return notes;
}

export function cryFor(species) {
  if (species?.cry) {
    try { const n = parseCry(species.cry); if (n.length) return n; } catch { /* fall through */ }
  }
  return defaultCry(species?.id, species?.baseStats);
}
