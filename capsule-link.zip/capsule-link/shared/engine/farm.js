// The berry farm next to the R.A.N.C.H. yard: plant one of a food, harvest several later.
// Growth uses real time, so plants keep growing while the app is closed.
export const FARM_PLOTS = 6;

export function farmState(save) {
  if (!save.farm || !Array.isArray(save.farm.plots)) save.farm = { plots: [] };
  while (save.farm.plots.length < FARM_PLOTS) save.farm.plots.push(null);
  return save.farm;
}

/** Foods that can be planted: those with a `grow` entry, or any limited food if none has one. */
export function plantable(idx) {
  const items = idx.ds.items ?? [];
  const growing = items.filter((i) => i.grow);
  return growing.length ? growing : items.filter((i) => i.kind === 'food' && !i.unlimited);
}

export function growInfo(item) {
  return { hours: Math.max(0.01, Number(item?.grow?.hours) || 3), yield: Math.max(1, Math.round(Number(item?.grow?.yield) || 3)) };
}

/** { empty } or { item, stage: 0..3, ready, left (ms), frac } */
export function plotStatus(idx, plot, now = Date.now()) {
  if (!plot) return { empty: true };
  const item = idx.items.get(plot.item);
  const ms = growInfo(item).hours * 3600000;
  const frac = Math.max(0, Math.min(1, (now - plot.plantedAt) / ms));
  return { item, itemId: plot.item, frac, stage: frac >= 1 ? 3 : Math.min(2, Math.floor(frac * 3)), ready: frac >= 1, left: Math.max(0, plot.plantedAt + ms - now) };
}

export function plant(idx, save, i, itemId, now = Date.now()) {
  const farm = farmState(save);
  if (i < 0 || i >= FARM_PLOTS) return { ok: false, reason: 'There is no such plot.' };
  if (farm.plots[i]) return { ok: false, reason: 'Something is already growing there.' };
  const item = idx.items.get(itemId);
  if (!item || !plantable(idx).includes(item)) return { ok: false, reason: 'That cannot be planted.' };
  if (!item.unlimited && (save.inventory[itemId] ?? 0) < 1) return { ok: false, reason: `You have no ${item.name} to plant.` };
  if (!item.unlimited) save.inventory[itemId] -= 1;
  farm.plots[i] = { item: itemId, plantedAt: now };
  return { ok: true };
}

export function harvest(idx, save, i, now = Date.now()) {
  const farm = farmState(save);
  const st = plotStatus(idx, farm.plots[i], now);
  if (st.empty) return { ok: false, reason: 'Nothing is planted there.' };
  if (!st.ready) return { ok: false, reason: 'Not ripe yet.' };
  const n = growInfo(st.item).yield;
  save.inventory[st.itemId] = (save.inventory[st.itemId] ?? 0) + n;
  farm.plots[i] = null;
  return { ok: true, item: st.item, count: n };
}
