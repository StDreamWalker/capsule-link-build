// Working out what you mean: not just the topic of what you say, but what kind of thing it is. "Who wants to
// battle right now?" asks who'd like to, now (how they feel, how tired they are); "Who likes battling in
// general?" asks about their long-standing tastes; "Whoever wins the next race gets to come on a walk" is a deal
// they'll hold you to; "Musharna, I never took you for someone who'd like jazz" is a remark about Musharna's
// taste that it can answer, and agree with or not; "I'd like to show you some lo-fi" is something to listen to.
//
//   understand(text, { names: [{ uid, names: [..] }] }) → {
//     raw, s,                       the words as said, and tidied up
//     named: [uid],                 everyone it names
//     addressees: [uid],            who it's said to ("Cogsy, …", or the named ones it isn't about)
//     about: [uid],                 creatures it's about ("do you like Mindle?" → Mindle)
//     kind,                         'deal' | 'remark' | 'share' | 'why' | 'followup' | 'remember' | 'opinionOf' |
//                                   'groupQ' | 'ynQ' | 'tasteQ' | 'propose' | null
//     stance,                       'want' | 'like' | 'dislike' | 'skill' | 'done' | 'stat' | 'state' | 'compare'
//     time,                         'now' | 'general' | 'later' | null
//     act, acts,                    the thing to do (lexicon.js), and all of them
//     route: { from, to } | null,   places named ("from the hammock to the toy box")
//     obj,                          the thing it's about, in your words ("jazz", "the rain", "Oran Berries")
//     genre, neg, …                 and whatever else that kind needs (cond and prize for deals, title and
//                                   artist for music, sign and surprise for remarks, stat for "who's fastest")
//   }
import { activityIn, activitiesIn, placesIn, prizeIn, genreIn } from './lexicon.js';

const CONTRACT = [
  [/\bwho'?s\b/g, 'who is'], [/\bwhat'?s\b/g, 'what is'], [/\bthat'?s\b/g, 'that is'], [/\bit'?s\b/g, 'it is'], [/\bhow'?s\b/g, 'how is'], [/\bwhere'?s\b/g, 'where is'], [/\bhere'?s\b/g, 'here is'], [/\bthere'?s\b/g, 'there is'],
  [/\bi'?m\b/g, 'i am'], [/\byou'?re\b/g, 'you are'], [/\bwe'?re\b/g, 'we are'], [/\bthey'?re\b/g, 'they are'],
  [/\bi'd\b/g, 'i would'], [/\byou'd\b/g, 'you would'], [/\bwho'd\b/g, 'who would'], [/\bwe'd\b/g, 'we would'],
  [/\bi'll\b/g, 'i will'], [/\byou'll\b/g, 'you will'], [/\bwho'll\b/g, 'who will'], [/\bwe'll\b/g, 'we will'],
  [/\bi'?ve\b/g, 'i have'], [/\byou'?ve\b/g, 'you have'], [/\bwe'?ve\b/g, 'we have'],
  [/\bdon'?t\b/g, 'do not'], [/\bdoesn'?t\b/g, 'does not'], [/\bdidn'?t\b/g, 'did not'], [/\bisn'?t\b/g, 'is not'], [/\baren'?t\b/g, 'are not'], [/\bwasn'?t\b/g, 'was not'],
  [/\bcan'?t\b/g, 'can not'], [/\bcannot\b/g, 'can not'], [/\bwon'?t\b/g, 'will not'], [/\bwouldn'?t\b/g, 'would not'], [/\bhaven'?t\b/g, 'have not'], [/\bhasn'?t\b/g, 'has not'], [/\bshouldn'?t\b/g, 'should not'],
  [/\bwanna\b/g, 'want to'], [/\bgonna\b/g, 'going to'], [/\bgotta\b/g, 'got to'], [/\blemme\b/g, 'let me'], [/\bgimme\b/g, 'give me'], [/\bkinda\b/g, 'kind of'], [/\bsorta\b/g, 'sort of'],
  [/\by'?all\b/g, 'you all'], [/\bya\b/g, 'you'], [/\bu\b/g, 'you'], [/\bur\b/g, 'your'], [/\br\b/g, 'are'], [/\brn\b/g, 'right now'], [/\btmrw\b/g, 'tomorrow'], [/\bpl[sz]\b/g, 'please'], [/\b(?:cuz|coz|bc)\b/g, 'because'], [/\bidk\b/g, 'i do not know'],
  [/\bpok[eé]mon\b/g, 'pokemon'], [/\bfave?\b/g, 'favourite'], [/\bfavorite\b/g, 'favourite'], [/\blets\b/g, "let's"],
];
/** Tidy what was said into plain lower-case words (contractions and texting spelled out). */
export function tidy(text) {
  let s = String(text ?? '').toLowerCase().replace(/[’‘`´]/g, "'").replace(/[“”]/g, '"').replace(/é/g, 'e').replace(/\s+/g, ' ').trim();
  for (const [re, to] of CONTRACT) s = s.replace(re, to);
  return s;
}
const esc = (x) => String(x).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// ---------- time ----------
const NOW = /\b(?:right now|now|at the moment|today|this (?:morning|afternoon|evening)|tonight|currently|immediately|this instant|right away|straight away|soon|this minute|at once)\b/;
const GENERAL = /\b(?:in general|generally|usually|normally|ever|always|typically|overall|at all|on the whole|most of all|the most|as a rule|really|deep down)\b/;
const LATER = /\b(?:tomorrow|later|next time|this weekend|some ?time|one day|tonight later)\b/;
const timeOf = (s) => (NOW.test(s) ? 'now' : LATER.test(s) ? 'later' : GENERAL.test(s) ? 'general' : null);
const stripTime = (s) => s.replace(new RegExp(`${NOW.source}|${GENERAL.source}|${LATER.source}`, 'g'), ' ').replace(/\s+/g, ' ').trim();

// ---------- the pieces ----------
const GROUP = String.raw`(?:who(?: else| here| of you(?: all| guys| lot)?| among you| all)?|which (?:one|ones)(?: of you(?: all| guys)?)?|which of you(?: all| guys)?|any ?one(?: here| of you)?|any ?body(?: here)?|does any ?one|does any ?body|is any ?one|is any ?body|are any of you|do any of you|would any of you|is there any ?one(?: (?:here|who))?|everyone who)`;
const STANCES = [
  // [stance, regex on what follows "who"]
  ['want', /^(?:(?:really |still |also )?(?:wants?|would (?:like|love)|feels? like|fancies|fancy|is (?:up for|keen(?: on| to)?|in the mood for|ready (?:for|to)|down (?:for|to)|game for|coming|joining|free (?:for|to))|will (?:come|join)|is going to)|would want)\b(?: to)?\s*/],
  ['like', /^(?:(?:really |also |actually |secretly )?(?:likes?|loves?|enjoys?|adores?|prefers?|is (?:into|a (?:big |huge )?fan of|fond of|crazy about|obsessed with|keen on|good with)|would rather))\b(?: to)?\s*/],
  ['dislike', /^(?:(?:really |secretly )?(?:hates?|dislikes?|detests?|can not stand|is not (?:a fan of|into|keen on|fond of)|is (?:scared|afraid|frightened) of|fears|would hate))\b(?: to)?\s*/],
  ['skill', /^(?:is (?:the )?(?:best|good|great|bad|terrible|worst|amazing|brilliant|strongest|fastest|quickest|cleverest|smartest|skilled|talented|ace|pro|better|worse) at|can|could|knows? how to|is able to|is (?:the )?(?:best|top|champion) (?:at|in))\b\s*/],
  ['done', /^(?:has (?:ever |never |already |not |been |gone |done )*(?:been|done|gone|tried|had|played|won|seen|battled|raced|fished|cooked|swum|eaten|met|heard|visited)|did|went|ever)\b\s*/],
  ['state', /^is (?:still |feeling |getting )?(?:hungry|starving|peckish|tired|sleepy|exhausted|awake|up|asleep|sleeping|bored|happy|sad|upset|grumpy|cross|angry|dirty|grubby|smelly|clean|full|stuffed|ok|okay|alright|ready|excited|scared|lonely)\b/],
  ['stat', /^is (?:the )?(?:fastest|quickest|slowest|strongest|toughest|weakest|biggest|tallest|largest|heaviest|smallest|tiniest|shortest|lightest|oldest|youngest|newest|cutest|smartest|cleverest|friendliest|hungriest|sleepiest|tiredest|happiest|laziest|most \w+|least \w+|highest(?: level)?|lowest(?: level)?|best (?:fighter|battler|swimmer|runner|flyer|climber|digger|cook|singer|dancer)|loudest|quietest|bravest|shyest|clumsiest)\b|^(?:is |are )?(?:faster|stronger|bigger|taller|heavier|smaller|older|younger|cuter|smarter|friendlier|hungrier|sleepier|happier|lazier)\b/],
];
const STAT_WORDS = [
  ['speed', /fast|quick|slow|runner/], ['strength', /strong|tough|weak|fighter|battler|power|highest|lowest/], ['size', /big|tall|large|small|tiny|short/], ['weight', /heav|light/],
  ['age', /old|young|new/], ['friendship', /friend|cute|sweet/], ['hunger', /hungr/], ['tired', /sleep|tired|lazy|laz/], ['joy', /happ/], ['level', /level/],
  ['swim', /swimmer/], ['fly', /flyer|flier/], ['clever', /smart|clever/], ['brave', /brave|shy/], ['loud', /loud|quiet/], ['clumsy', /clums/],
];
const statOf = (s) => STAT_WORDS.find(([, re]) => re.test(s))?.[0] ?? 'strength';
const lowStat = (s) => /slow|weak|small|tiny|short|light|young|new|lowest|least|quiet|shy/.test(s);

// remarks about someone's taste ("I never took you for someone who'd like jazz", "since when do you like rain?")
const LIKEV = String.raw`(?:like|liked|likes|love|loved|loves|enjoy|enjoyed|enjoys|be into|was into|were into|are into|is into|be a fan of|go for|hate|hated|hates|dislike|disliked|dislikes)`;
const REMARKS = [
  { surprise: true, re: new RegExp(String.raw`\b(?:i )?(?:never|would never have|would not have|did not|had no idea|never would have|really did not)\s+(?:took|take|taken|pegged|peg|had|have|figured|figure|thought|think|guessed|guess|imagined|imagine|known|knew|know|realised|realized|expected|seen)(?: that)?(?: you)?(?: (?:for|as|to be))?\s*(?:someone|somebody|the (?:type|kind|sort)(?: of (?:pokemon|mon|guy|girl|one))?|a pokemon|one|the pokemon|a)?\s*(?:who(?: would| does| was| is)?|that(?: would)?|to)?\s*(?:you )?(?:would |could |might |actually |really )?(?:${LIKEV})\s+(.+)`) },
  { surprise: true, re: new RegExp(String.raw`\bsince when (?:do|did) you (?:${LIKEV})\s+(.+)`) },
  { surprise: true, re: new RegExp(String.raw`\bwho knew you (?:${LIKEV})\s+(.+)`) },
  { surprise: true, re: new RegExp(String.raw`\bi (?:did not|never) (?:know|realise|realize|think) you (?:${LIKEV})\s+(.+)`) },
  { surprise: true, re: new RegExp(String.raw`\b(?:you|you of all pokemon),? (?:really |actually )?(?:${LIKEV})\s+(.+?)\?\s*(?:really|seriously|who knew)`) },
  { surprise: false, re: new RegExp(String.raw`\bi (?:bet|think|guess|reckon|suspect|feel like|knew|just knew|always knew|could tell|can tell) (?:that )?you (?:would |might |will |probably |definitely |secretly |really )?(${LIKEV})\s+(.+)`), verbAt: 1 },
  { surprise: false, re: new RegExp(String.raw`\byou (?:seem|look) like (?:you would |you might |you |the type to |someone who would )(${LIKEV})\s+(.+)`), verbAt: 1 },
  { surprise: false, re: new RegExp(String.raw`^(?:(?:so|wow|oh|huh|ha|haha|aw+|o+h|hey|well|look at you|gosh)[, !]+)*you (?:really |actually |seriously |must |sure |do |totally |clearly )*(${LIKEV})\s+(.+?)(?:,? (?:do not you|do you not|do you|right|huh|eh|then|too|i see|i guess|i bet|yeah))?\s*[?!.]*$`), verbAt: 1 },
  { surprise: false, re: /\byou are (?:a (?:big |huge |real )?|such a )([a-z -]+?) (?:fan|lover|nut|buff|addict)\b/, objAt: 1, sign: 1 },
];

// showing / playing them something
const SHARES = [
  /\b(?:i (?:would|really would) (?:like|love) to|i want to|let me|can i|could i|may i|i am going to|i will|allow me to|i have to|i must|i got to|i need to)\s+(?:show|play|sing|share|introduce)(?: you| for you| something(?: with you)?| to you)?\s+(.+)/,
  /^(?:here,? )?(?:listen to|listen|check out|have a listen to|have a listen|hear|look at|watch|feast your eyes on)\b\s*(?:this|that)?\s*(.*)/,
  /\bi want you to (?:hear|listen to|see|watch|meet)\s+(.+)/,
  /\b(?:here is|this is|that is) (?:a |my |some |the |a really good |my favourite )?(?:song|track|tune|album|band|music|playlist|record|single|melody|piece)\b\s*(.*)/,
  /\b(?:i am|we are) (?:going to |about to )?(?:play(?:ing)?|put(?:ting)? on|listen(?:ing)? to)\s+(?:some |a |the |my )?(.+?(?:music|song|songs|album|playlist|track|tunes|band|soundtrack|ost).*)/,
  /\b(?:put|putting) on (?:some |a |the |my )?(.+?(?:music|song|songs|album|playlist|track|tunes|soundtrack|ost).*)/,
  /^(?:(?:ok|okay|alright|right|now|here|so)[, ]+)?(?:play|put on|let me play|i will play)\s+((?:it|that|this|that song|this song|the song|it|that one|this one)(?: (?:again|one more time|once more))?)\s*[!.]*$/,
  /^(?:(?:ok|okay|alright|right|now|here|so)[, ]+)?(?:play|put on|let me play|i will play|i am putting on|time for)\s+(?:some |a bit of |a little |a |the )?(.+?(?:music|songs?|tunes|album|playlist|soundtrack|ost|jazz|rock|metal|pop|lo-?fi|classical|techno|edm|rap|hip-? ?hop|folk|country|reggae|disco|funk|blues|punk|ambient|synthwave|k-?pop|j-?pop|opera|piano)\b.*)$/,
];
const HEARD_Q = /\b(?:have|did) you (?:ever )?(?:heard|hear|listened to|heard of|seen|watched)\s+(.+?)\s*\??$|\bdo you know (?:the )?(?:song|tune|band|track)\s+(.+?)\s*\??$/;
const MUSICY = /\b(?:songs?|tracks?|tunes?|albums?|bands?|music|playlists?|singles?|records?|ost|soundtracks?|melod(?:y|ies)|pieces?|symphon\w*|lullab\w*|jams?|beats)\b|\bby [a-z]/;

/** What was said, worked out. ctx.names: the creatures who might be named. */
export function understand(text, { names = [] } = {}) {
  const raw = String(text ?? '').trim();
  let s = tidy(raw);
  const out = { raw, s, named: [], addressees: [], about: [], kind: null, stance: null, time: timeOf(s), act: null, acts: [], route: null, obj: '', genre: null, neg: false };
  if (!s) return out;
  // names: who is talked to, and who is talked about
  const hits = [];
  for (const n of names) {
    for (const w of [...new Set((n.names ?? []).filter(Boolean).map((x) => String(x).toLowerCase()))].sort((a, b) => b.length - a.length)) {
      const re = new RegExp(`\\b${esc(w)}\\b`, 'g');
      let m; while ((m = re.exec(s))) { if (!hits.some((h) => m.index < h.at + h.len && h.at < m.index + w.length)) hits.push({ uid: n.uid, at: m.index, len: w.length, w }); }
    }
  }
  hits.sort((a, b) => a.at - b.at);
  out.named = [...new Set(hits.map((h) => h.uid))];
  // "Cogsy, …", "hey Cogsy and Mindle, …", "…, Cogsy?" are said to them
  const voc = new Set();
  for (const h of hits) {
    const before = s.slice(0, h.at), after = s.slice(h.at + h.len);
    if (/^(?:(?:hey|hi|ok|okay|so|oi|yo|and|hello|right|well|oh|um|alright)\s+)*(?:(?:@n|[a-z]+)\s*(?:,|and|&)\s*)*$/.test(before.replace(/\b[a-z]+\b/g, (w) => (hits.some((x) => x.w === w) ? '@n' : w))) && /^\s*(?:,|and\b|&|:|!|\?|$)/.test(after)) voc.add(h.uid);
    else if (/,\s*$/.test(before) && /^\s*[?!.]*\s*$/.test(after)) voc.add(h.uid);
  }
  // swap the names out, so they don't get read as words ("Rocky" isn't a rock)
  let body = s;
  for (const h of [...hits].reverse()) body = `${body.slice(0, h.at)}@n${body.slice(h.at + h.len)}`;
  body = body.replace(/^(?:(?:hey|hi|ok|okay|so|oi|yo|hello|right|well|oh|um|alright)\s+)*(?:@n\s*(?:,|and|&)\s*)*@n\s*[,:!]\s*/, '').replace(/,\s*@n\s*([?!.]*)$/, '$1').trim() || body;
  // (a hello in front — "hi! do you like jazz?" — is answered as well, but doesn't change what's asked)
  const gm = /^(?:hi+|hello+|hey+|heya|hiya|howdy|yo|oi|good (?:morning|afternoon|evening)|morning)(?:\s+(?:there|everyone|everybody|all|guys|gang|buddy|pal|friend|@n))?\s*[!,.]+\s*/.exec(body);
  if (gm && body.length > gm[0].length + 2) { out.greeted = true; body = body.slice(gm[0].length); }
  out.body = body;
  const q = /\?\s*$/.test(raw) || /^(?:who|which|what|why|how|where|when|do|does|did|are|is|was|were|can|could|would|will|have|has|any ?one|any ?body|shall)\b/.test(body);
  out.question = q;
  out.acts = activitiesIn(body);
  out.act = out.acts[0] ?? null;
  out.genre = genreIn(body);
  out.route = routeOf(body);

  // ---------- a deal: "whoever wins the next race gets to come on a walk with me" ----------
  const deal = dealOf(body);
  if (deal) {
    Object.assign(out, { kind: 'deal', ...deal });
    // (and if it's also asking for the race — "let's race to the tree, winner gets a berry" — say so)
    const pre = body.slice(0, Math.max(0, body.search(/\b(?:whoever|the winner|first (?:one )?to|if (?:you|anyone))/))).trim();
    if (pre && /\b(?:let's|let us|shall we|how about|time (?:for|to)|who wants|ready|on your marks|race|battle)\b/.test(pre)) out.alsoStart = true;
    if (/^(?:race|first (?:one )?to)\b/.test(body) || /\blet's (?:race|have a race)\b/.test(body)) out.alsoStart = true;
    finish(out, hits, voc);
    return out;
  }

  // ---------- a promise straight to them: "I'll take you on a walk later", "I promise we'll go fishing tomorrow" ----------
  let pm;
  if ((pm = /\b(?:i (?:will|promise(?: to| that i will| i will| you)?|am going to|shall|swear i will)|we (?:will|are going to|shall)|you will get to|you are getting|you get to|you can have)\s+(?!not\b|never\b)(.+)$/.exec(body)) && !q && !/\b(?:can not|will not|cannot|not going to|sorry)\b/.test(body)) {
    const rest = pm[1];
    const prize = prizeIn(rest) ?? prizeIn(`a ${rest}`);
    const act = activityIn(rest);
    if ((prize || act) && (/^(?:you|i promise)/.test(pm[0]) || /\b(?:take you|bring you|give you|get you|buy you|let you|go|play|have|come|do|walk|you)\b/.test(rest) || /\bpromise\b/.test(body))) {
      Object.assign(out, { kind: 'promise', prize: prize ?? { kind: `act:${act.id}`, label: `to ${act.label}`, icon: '✨', words: act.label }, act: act ?? out.act, when: LATER.test(body) ? 'later' : NOW.test(body) ? 'now' : 'soon' });
      finish(out, hits, voc);
      return out;
    }
  }

  // ---------- follow-ups to what they just said ----------
  if (/^(?:why|how come|why not|why is that|how so|what for)\s*[?!.]*$/.test(body)) { out.kind = 'followup'; out.what = 'why'; finish(out, hits, voc); return out; }
  if (/^(?:really|seriously|are you sure|no way|for real|honestly|is that so|you sure|truly|wait,? really)\s*[?!.]*$/.test(body)) { out.kind = 'followup'; out.what = 'really'; finish(out, hits, voc); return out; }
  if (/^(?:since when|for how long|how long for)\s*[?!.]*$/.test(body)) { out.kind = 'followup'; out.what = 'since'; finish(out, hits, voc); return out; }
  if (/^(?:and |what about |how about )?(?:you|yours|@n)\s*[?!.]*$/.test(body) && /^(?:and|what about|how about)\b/.test(body)) { out.kind = 'followup'; out.what = 'you'; finish(out, hits, voc); return out; }

  // ---------- a remark about their taste ----------
  for (const r of REMARKS) {
    const m = r.re.exec(body);
    if (!m) continue;
    const verb = r.verbAt ? m[r.verbAt] : (m[0].match(new RegExp(LIKEV))?.[0] ?? 'like');
    const obj = cleanObj(m[r.objAt ?? (r.verbAt ? r.verbAt + 1 : 1)] ?? '');
    if (!obj || /^(?:me|it|that|this|them|him|her)$/.test(obj)) continue;
    // ("you like that, don't you?" said while they're doing something is about now; it still counts)
    Object.assign(out, { kind: 'remark', obj, sign: r.sign ?? (/hat|dislik/.test(verb) ? -1 : 1), surprise: r.surprise, act: activityIn(obj), acts: activitiesIn(obj), genre: genreIn(obj) });
    out.aboutCreature = hits.find((h) => h.at > s.indexOf(obj.split(' ')[0] ?? '') - 1 && !voc.has(h.uid) && obj.includes('@n'))?.uid ?? null;
    finish(out, hits, voc);
    return out;
  }

  // ---------- showing or playing them something ----------
  let shown = null;
  for (const re of SHARES) { const m = re.exec(body); if (m && (m[1] ?? '').trim() !== '') { shown = m[1]; break; } if (m && (re === SHARES[1] || re === SHARES[3]) && MUSICY.test(body)) { shown = re === SHARES[3] ? (/\b(song|track|tune|album|band|music|playlist|record|single|melody|piece)\b/.exec(body)?.[1] ?? 'song') : body; break; } }
  const heard = HEARD_Q.exec(body);
  const titleCase = (x) => (String(x ?? '').match(/\b[A-Z][a-z']*/g) ?? []).length >= 2;
  if (!shown && heard && (MUSICY.test(body) || genreIn(body) || /"/.test(raw) || titleCase(raw.replace(/^\s*\S+/, '').replace(new RegExp(`\\b(?:${names.flatMap((n) => n.names ?? []).filter(Boolean).map(esc).join('|') || '\\b\\B'})\\b`, 'g'), '')))) shown = heard[1] ?? heard[2];
  if (shown != null) {
    const m = musicBits(raw, String(shown));
    // (a title asked about by name — "have you heard Never Gonna Give You Up?" — kept as it was written)
    if (heard && !m.title) { const rt = /(?:heard(?: of)?|listened to|know(?: the song| the tune| the band)?)\s+(.+?)\s*[?!.]*$/i.exec(raw)?.[1]; if (rt) { m.title = rt.replace(/\s+by\s+.+$/i, '').trim(); m.music = true; } }
    else if (heard && m.title) { const rt = /(?:heard(?: of)?|listened to|know(?: the song| the tune| the band)?)\s+(.+?)\s*[?!.]*$/i.exec(raw)?.[1]; if (rt && rt.toLowerCase().replace(/gonna/g, 'going to').replace(/wanna/g, 'want to').includes(m.title.slice(0, 6))) m.title = rt.replace(/\s+by\s+.+$/i, '').replace(/^["“']|["”']$/g, '').trim(); }
    const pron = /^(?:it|that|this|that song|this song|the song|that one|this one)(?: (?:again|one more time|once more))?$/.test(String(shown).trim());
    if (m.music || MUSICY.test(body) || genreIn(body) || heard || pron) {
      if (pron) { m.title = null; m.obj = 'it'; m.again = true; }
      Object.assign(out, { kind: 'share', medium: 'music', ...m, asked: !!heard });
      finish(out, hits, voc);
      return out;
    }
  }

  // ---------- talking to them like a friend or a pet ----------
  const PET = [
    ['trick', /^(?:(?:ok|okay|now|come on|alright|hey)[, ]+)?(?:(?:can|could|will|would) you |let's see you |show me (?:a |your )?|do (?:a |your )?|give me (?:a |your )?)?(high[- ]?five|shake(?: paws?| hands)?|paw|roll ?over|play dead|speak|bow|beg|wave(?: hello)?|sit pretty|back ?flip|flip|stand up(?: tall)?|stand on (?:your )?(?:hind|back) legs)\b/],
    ['compliment', /^(?:(?:aw+|oh+|wow|look at you|hey|omg|gosh)[, !]+)*(?:you(?: are|'re)?|you look|you are looking|what a|such a|look how|how|i love how)\s+(?:so |really |very |super |such a |an? |the |just |looking |extra )*(cute|adorable|fluffy|soft|pretty|beautiful|handsome|gorgeous|cool|awesome|strong|smart|clever|brave|funny|sweet|lovely|shiny|sparkly|big|tall|tiny|small|precious|majestic|fierce|tough|amazing|wonderful|elegant|graceful|squishy|round|chunky|cuddly)\b(?! at)/],
    ['tease', /(?:you(?: are|'re)|what a|such a|you little|you big)\s+(?:so |a |an |such a |little |big |total |real |silly )*(lazy|lazybones|silly|goofy|chubby|fat|chonky|slowpoke|weirdo|weird|dork|nerd|dummy|goof|goofball|stinky|smelly|messy|greedy|grumpy|grump|drama queen|baby|scaredy[- ]?cat|show-?off|couch potato|glutton|troublemaker|rascal)\b/],
    ['comfort', /\b(?:it (?:is|will be) (?:ok|okay|alright|all right|fine)|it is going to be (?:ok|okay|fine|alright)|do not (?:worry|be (?:scared|afraid|sad|nervous|upset))|you are safe|i am (?:here|right here)|there,? there|shh+|i have got you|i got you|everything (?:is|will be) (?:ok|okay|fine|alright)|nothing to (?:be scared|worry) (?:of|about))\b/],
    ['encourage', /\b(?:you can do (?:it|this)|good luck|go get (?:them|em|'em)|i believe in you|do your best|you will do (?:great|fine|amazing)|knock (?:them|em) dead|you have got this|you got this|break a leg|give it your all|show them what you(?: have)? got|go for it|let us win this)\b/],
    ['miss', /\b(?:i (?:really )?missed you|did you miss me|missed you|i was thinking about you|i thought about you)\b/],
    ['joke', /\b(?:tell me a joke|make me laugh|do something funny|say something funny|be silly|do a funny|cheer me up)\b/],
    ['thinking', /\bwhat (?:are|is) (?:you|@n) thinking(?: about| of)?\b|\bwhat is on your mind\b|\bpenny for your thoughts\b|\bwhat are you (?:daydreaming|dreaming) about\b|\bwhat is going on in (?:that|your) (?:little |silly |big )?head\b|\bwhat are you (?:looking|staring) at\b/],
    ['dream', /\bwhat did you dream (?:about|of)\b|\bdid you (?:have (?:a |any )?(?:good |nice |bad |sweet )?dreams?|dream)\b|\bhow did you sleep\b|\bdid you sleep (?:well|ok|okay)\b|\bhave a (?:good|nice) nap\b\?/],
    ['bless', /^bless you\b|^gesundheit\b/],
  ];
  for (const [sub, re] of PET) {
    const m = re.exec(body);
    if (!m) continue;
    if (sub === 'dream' && !q) continue;
    if (sub === 'compliment' && /^how \w+ (?:are|is) (?:you|@n)\b/.test(body)) continue;
    out.kind = 'pet'; out.sub = sub; out.word = (m[1] ?? '').trim();
    finish(out, hits, voc); return out;
  }

  // ---------- what it knows about itself: type, weaknesses, moves, evolving, ability, nature, ball, where it's from ----------
  const LORE = [
    ['weak', /\b(?:what|which)(?: types?)? (?:are|is) (?:you|@n) (?:weak|vulnerable) (?:to|against)\b|\bwhat is your weakness\b|\b(?:are|is) (?:you|@n) (?:weak|vulnerable|scared|afraid|frightened) (?:to|of|against) (.+?)\s*\??$|\bdo (?:you|@n) (?:fear|hate) (.+?) types?\b/],
    ['strong', /\bwhat (?:are|is) (?:you|@n) (?:strong|good|effective|great) against\b|\b(?:are|is) (?:you|@n) (?:strong|good|effective|resistant) against (.+?)\s*\??$|\bcould you beat (?:a |an )?(.+?)(?: types?| pokemon)?\s*\??$/],
    ['type', /\bwhat (?:type|types|kind of pokemon|element|sort of pokemon) (?:are|is) (?:you|@n)\b|\b(?:are|is) (?:you|@n) (?:a |an )?(\w+)[- ]type\b|\bwhat is your type\b/],
    ['bestMove', /\b(?:what is|which is) your (?:best|strongest|favourite|most powerful|coolest|signature) (?:move|attack)\b|\bshow me your (?:best|strongest|coolest|favourite) (?:move|attack)\b/],
    ['moves', /\bwhat moves (?:do|can) (?:you|@n) (?:know|use|do)\b|\bwhat (?:are|is) your moves?\b|\bwhat (?:attacks|moves) (?:have you got|do you have)\b/],
    ['evolve', /\b(?:will|can|do|are|could) (?:you|@n) (?:ever )?(?:evolve|going to evolve)\b|\bwhat (?:will|do|does|would) (?:you|@n) evolve into\b|\bwhen (?:will|do) (?:you|@n) evolve\b|\bdo you want to evolve\b|\bwhat do you turn into\b|\bare you (?:fully|done) evolved\b/],
    ['ability', /\bwhat is (?:your|@n'?s?) ability\b|\bwhat ability (?:do|does) (?:you|@n) have\b/],
    ['nature', /\bwhat is your (?:nature|personality|temperament)\b|\bwhat are you like\b|\bdescribe yourself\b/],
    ['origin', /\bwhere (?:are|did|do) (?:you|@n) (?:from|come from|grow up)\b|\bwhere did we (?:first )?meet\b|\bhow did we (?:first )?meet\b|\bremember (?:where|when|how) we (?:first )?met\b|\bremember meeting me\b|\bwho (?:was|is) your (?:old |first |original |real )?trainer\b|\bwhat game (?:are|did) you (?:from|come from)\b|\bremember your (?:home|region|old trainer|old home|game)\b/],
    ['ball', /\b(?:do you like|what is|what kind of|which) (?:your )?(?:poke ?)?ball\b|\bwhat ball are you (?:in|from)\b|\bhow do you like your (?:poke ?)?ball\b/],
    ['health', /\b(?:are|is) (?:you|@n) (?:hurt|injured|poisoned|burned|burnt|paralyzed|paralysed|frozen|okay after|ok after|feeling poorly|sick)\b|\bhow (?:are|is) your (?:hp|wounds|health)\b|\bdo (?:you|@n) (?:need|want) (?:to go to )?(?:the |a )?(?:pokemon center|potion|healing|heal)\b|\bhow much hp\b/],
    ['species', /\b(?:do|did) you (?:know|remember) (?:a |an |any )?([a-z][a-z.'-]+|@n)\s*\??$|\bhave you (?:ever )?(?:seen|met) (?:a |an |any )?([a-z][a-z.'-]+|@n)\s*\??$|\bwhat do you think of ([a-z][a-z.'-]+)s?\s*\??$/],
    ['level', /\bwhat level are you\b|\bhow strong are you\b|\bhow old are you\b|\bhow big are you\b|\bhow tall are you\b|\bhow heavy are you\b|\bhow fast are you\b|\bhow much do you weigh\b/],
  ];
  for (const [topic, re] of LORE) {
    const m = re.exec(body);
    if (!m) continue;
    out.kind = 'loreQ'; out.topic = topic; out.obj = cleanObj(m[1] ?? m[2] ?? '').replace(/\s*(?:types?|moves?|attacks?|pokemon)$/, '');
    out.want = /\bwant\b/.test(body); out.which = (/\b(old|big|tall|heavy|weigh|fast|strong|level)\b/.exec(body) ?? [])[1] ?? null;
    finish(out, hits, voc); return out;
  }

  // ---------- why ----------
  let w;
  if ((w = /^(?:so |but |and |ok |okay )?(?:why|how come)\b\s*(.*)$/.exec(body)) || (w = /\bwhat (?:has|is|did) (?:got(?:ten)?|made|put) you (?:so |in (?:such )?a )?(\w+(?: mood)?)/.exec(body)) || (w = /\bwhat is (?:with|up with) (?:the|that|your|all the) (\w+(?: face| mood)?)/.exec(body))) {
    out.kind = 'why'; out.whyAbout = cleanObj(w[1] ?? '').replace(/^(?:are|is|do|did|were|was) (?:you|@n)\s*/, '').replace(/^(?:so|being|feeling|looking)\s+/, '');
    finish(out, hits, voc);
    return out;
  }

  // ---------- remembering ----------
  if ((w = /\b(?:do|did|can|could) (?:you|@n) (?:still |even )?(?:remember|recall|recollect)\b\s*(.*)$/.exec(body)) || (w = /^(?:remember|you remember|recall)\b\s*(.*)$/.exec(body)) || (w = /\bdo you (?:know|recall) what (?:we|i|you) did\b\s*(.*)$/.exec(body))) {
    out.kind = 'remember'; out.obj = cleanObj(w[1] ?? '').replace(/^(?:when|the time|that time|that|how)\s+/, '');
    finish(out, hits, voc);
    return out;
  }

  // ---------- what happened: "who won the last race?", "who won?" ----------
  if ((w = /^(?:so |and |ok )?who (?:won|is winning|came first|lost|came last)\b\s*(.*)$/.exec(body))) {
    out.kind = 'eventQ'; out.what = /\blost\b|came last/.test(body) ? 'lost' : 'won'; out.obj = cleanObj(w[1]); out.acts = activitiesIn(w[1]); out.act = out.acts[0] ?? null;
    finish(out, hits, voc); return out;
  }
  // ---------- its day: "what did you do today?", "how was your day?" ----------
  if (/\bwhat (?:did|have) (?:you|@n) (?:do|done|been (?:up to|doing))\b|\bhow (?:was|is|has been) (?:your|@n'?s?) day\b|\bwhat (?:happened|have you been up to) today\b|\bhow did (?:today|your day) go\b|\btell me about your day\b/.test(body)) {
    out.kind = 'dayQ'; finish(out, hits, voc); return out;
  }
  // ---------- about you: "do you love me?", "do you trust me?", "are you mad at me?", "what do you think of me?" ----------
  if ((w = /\b(?:do|does|did) (?:you|@n) (?:really |still )?(love|like|trust|miss|hate|believe|need|forgive)\s+me\b|\bwhat do you (?:think|reckon) (?:of|about) me\b|\bam i (?:your (?:best friend|favourite|friend)|a good trainer)\b|\b(?:are|is) (?:you|@n) (?:mad|cross|angry|upset|annoyed) (?:at|with) me\b|\bwho is your favourite (?:person|human|trainer)\b/.exec(body))) {
    out.kind = 'aboutMe'; out.what = w[1] ?? (/mad|cross|angry|upset|annoyed/.test(body) ? 'mad' : /trainer/.test(body) ? 'trainer' : 'think');
    finish(out, hits, voc); return out;
  }
  // ---------- what someone else likes: "does Cogsy like battling?", "is Mindle good at fishing?" ----------
  if ((w = /^(?:so )?(?:does|is|did|has|would|can) @n (?:really |actually |still |even )?(like|love|enjoy|hate|dislike|want(?: to)?|feel like|good at|any good at|bad at|ever|know how to|been)\b\s*(.*)$/.exec(body)) && out.named.length) {
    const subj = hits.find((h) => !voc.has(h.uid))?.uid ?? hits[0]?.uid;
    const v = w[1];
    out.kind = 'thirdQ'; out.subject = subj;
    out.stance = /hate|dislike/.test(v) ? 'dislike' : /good|bad|know how|^can$/.test(v) ? 'skill' : /ever|been/.test(v) ? 'done' : /want|feel like/.test(v) ? 'want' : 'like';
    out.obj = cleanObj(stripTime(w[2])); out.acts = activitiesIn(w[2]); out.act = out.acts[0] ?? null; out.genre = genreIn(w[2]);
    out.addressees = [...voc]; out.about = [subj];
    return out;
  }
  // ---------- favourites: "what's your favourite thing to do?", "what is your favourite berry?" ----------
  if ((w = /\b(?:what|which|who) (?:is|are) (?:your|@n'?s?) (?:most )?favourite\s+([a-z ]+?)\s*\??$|\byour favourite\s+([a-z ]+?)\s*\??$/.exec(body)) && !/\b(?:song|band|music|genre|tune|album|artist|singer)\b/.test(body)) {
    const what = (w[1] ?? w[2] ?? '').trim();
    out.kind = 'favQ'; out.domain = /food|berr|snack|treat|meal|dish|thing to eat/.test(what) ? 'food' : /toy/.test(what) ? 'toy' : /place|spot/.test(what) ? 'place' : /weather|season/.test(what) ? 'weather' : /time/.test(what) ? 'time' : /friend|pal|buddy|pokemon|mon/.test(what) ? 'friend' : /thing to do|game|activity|hobby|sport|pastime|thing|way to/.test(what) ? 'act' : 'any';
    out.obj = what; finish(out, hits, voc); return out;
  }

  // ---------- "who do you like more, Cogsy or Mindle?" ----------
  if (/\bwho do you (?:like|love|prefer)(?: more| better| most)?\b|\bwhich do you (?:like|prefer)\b|\bwho is your favourite\b.*\bor\b/.test(body) && (body.match(/@n/g) ?? []).length >= 2) {
    out.kind = 'preferQ';
    const optHits = hits.filter((h) => !voc.has(h.uid));
    out.about = [...new Set(optHits.map((h) => h.uid))];
    out.addressees = [...voc];
    return out;
  }
  // ---------- "what are you good at?" ----------
  if (/\bwhat (?:are|is) (?:you|@n) (?:good|best|great|really good) at\b|\bwhat can (?:you|@n) do\b|\bwhat are your (?:talents|skills|strengths)\b/.test(body)) {
    out.kind = 'goodAtQ'; finish(out, hits, voc); return out;
  }

  // ---------- what they think of someone else here ----------
  const opin = /\b(?:what do you (?:think|reckon) (?:of|about)|how do you feel about|how do you get (?:on|along) with|do you (?:like|love|hate|get (?:on|along) with|trust|miss)|are you (?:friends|mates|pals|close) with|is @n your (?:friend|best friend|buddy|pal)|what is @n like|who is @n to you)\b/.exec(body);
  if (opin && body.includes('@n')) {
    out.kind = 'opinionOf';
    finish(out, hits, voc);
    out.kind = null;
    const objs = out.about.length ? out.about : out.named.filter((u) => !out.addressees.includes(u));
    if (objs.length) { out.kind = 'opinionOf'; out.about = objs; return out; }
  }

  // ---------- what it thinks of something: "what do you think about cats?", "how do you feel about the rain?" ----------
  const oq = /\b(?:what do you (?:think|reckon) (?:of|about)|how do you feel about|thoughts on|your opinion (?:of|on)|what is your (?:take|view) on|how do you like)\s+(.+)$/.exec(body);
  if (oq && !oq[1].includes('@n')) {
    Object.assign(out, { kind: 'ynQ', stance: 'like', opinion: true, obj: cleanObj(stripTime(oq[1])) });
    out.acts = activitiesIn(out.obj); out.act = out.acts[0] ?? null; out.genre = genreIn(out.obj);
    finish(out, hits, voc); return out;
  }

  // ---------- "what kind of music do you like?", "what is your favourite song?" ----------
  if (/\b(?:what|which) (?:kind|sort|type|genre)s? of (?:music|songs?)\b|\bfavourite (?:song|band|music|genre|kind of music|tune|album|artist|singer)\b|\bwhat (?:music|songs?) do you (?:like|love|listen to|enjoy)\b/.test(body)) {
    out.kind = 'tasteQ'; out.domain = 'music'; finish(out, hits, voc); return out;
  }

  // ---------- a question for the group: "who wants to…", "who likes…", "who is the fastest?" ----------
  const g = new RegExp(`^(?:(?:so|ok|okay|alright|hey|and|right|well|now|guys|everyone|everybody|folks|gang|team)[, ]+)*${GROUP}\\s+(.*)$`).exec(body);
  if (g) {
    let rest = g[1].trim();
    if (/^(?:does not|do not|is not|would not|never|has not|did not|will not|can not)\b/.test(rest)) { out.neg = true; rest = rest.replace(/^(?:does not|do not|is not|would not|never|has not|did not|will not|can not)\s+(?:want to |like |)/, (x) => (/want|like/.test(x) ? x.replace(/^(?:does not|do not|is not|would not|never|has not|did not|will not|can not)\s+/, '') : '')); }
    let stance = null, after = rest;
    // type and move questions: "who is weak to fire?", "who knows a water move?", "who can evolve?", "who is a grass type?"
    let tm;
    if ((tm = /^(?:is |are )?(?:weak|vulnerable|scared|afraid) (?:to|of|against) (.+)$/.exec(rest))) { stance = 'weak'; after = tm[1]; }
    else if ((tm = /^(?:is |are )?(?:strong|good|effective|resistant|tough) against (.+)$/.exec(rest))) { stance = 'strong'; after = tm[1]; }
    else if ((tm = /^(?:knows?|has|can use|learned|have) (?:a |an |any |the )?(.+?)(?:[- ]type)? (?:moves?|attacks?)\b/.exec(rest))) { stance = 'knows'; after = tm[1]; }
    else if (/^(?:can|could|is (?:ready|about|going) to|will|is able to|is close to) evolve\b|^(?:is |are )?ready to evolve\b/.test(rest)) { stance = 'evolve'; after = ''; }
    else if ((tm = /^(?:is|are) (?:a |an )?(.+?)[- ]types?\b/.exec(rest))) { stance = 'isType'; after = tm[1]; }
    if (stance) {
      out.kind = 'groupQ'; out.stance = stance; out.obj = cleanObj(after);
      finish(out, hits, voc); return out;
    }
    for (const [st, re] of STANCES) { const m = re.exec(rest); if (m) { stance = st; after = rest.slice(st === 'state' || st === 'stat' ? 0 : m[0].length); break; } }
    // "who is coming on a walk", "who is up for…" (no verb we know: when it names a thing to do, it's a want)
    if (!stance && /^(?:is |are )?(?:coming|in|game|keen|up for|ready)\b/.test(rest)) stance = 'want';
    if (!stance && /^(?:is your|are your|is the|is a) (?:friend|best friend|buddy)/.test(rest)) stance = 'friends';
    if (stance) {
      // "who likes battling right now?" is a want; "who wants to battle in general?" is a like
      if (stance === 'like' && out.time === 'now') stance = 'want';
      if (stance === 'want' && out.time === 'general' && !/\bwants?\b|\bwould\b|\bfeel/.test(rest)) stance = 'like';
      if (stance === 'stat' && out.named.length >= 2) out.compare = out.named;
      if ((stance === 'like' || stance === 'skill') && /\bmore\b|\bbetter\b|\bmost\b/.test(rest) && out.named.length >= 2) out.compare = out.named;
      out.kind = 'groupQ'; out.stance = stance;
      out.obj = cleanObj(stripTime(after.replace(/,?\s*@n(?:\s*(?:,|or|and)\s*@n)*\s*\??$/, '').replace(/\bmore\b|\bbetter\b|\bthe most\b/g, '')));
      out.acts = activitiesIn(after); out.act = out.acts[0] ?? null; out.genre = genreIn(after);
      if (stance === 'stat') { out.stat = statOf(rest); out.low = lowStat(rest); }
      if (stance === 'state') out.state = (/^is (?:still |feeling |getting )?(\w+)/.exec(rest) ?? [])[1] ?? null;
      finish(out, hits, voc);
      return out;
    }
  }

  // ---------- a yes/no question to them: "do you like…", "do you want to…", "are you good at…", "have you ever…" ----------
  let yn;
  if ((yn = /^(?:do|would|did|will) (?:you|@n|you (?:all|guys|two|both))(?: all| guys| two| both)? (?:want|wanna|like|love|fancy|feel like|care) (?:to (?:go |come |have |do |play )?)?(.+)$/.exec(body)) && /\bwant\b|\bwould\b|\bfancy\b|\bfeel like\b/.test(body.slice(0, yn.index + 40)) && !/^(?:do|did) (?:you|@n) (?:like|love)\b/.test(body)) out.kind = 'ynQ', out.stance = 'want', out.obj = cleanObj(stripTime(yn[1]));
  else if ((yn = /^(?:are|is) (?:you|@n)(?: all| guys| two| both)? (?:up for|keen (?:on|to)|in the mood for|ready (?:for|to)|down for|game for|coming|free to)\s+(.+)$/.exec(body))) out.kind = 'ynQ', out.stance = 'want', out.obj = cleanObj(stripTime(yn[1]));
  else if ((yn = /^(?:fancy|wanna|want to|up for)\s+(?:a |some |going )?(.+?)\s*\?\s*$/.exec(body + (q && !/\?$/.test(body) ? '?' : '')))) out.kind = 'ynQ', out.stance = 'want', out.obj = cleanObj(stripTime(yn[1]));
  else if ((yn = /^(?:do|did) (?:you|@n)(?: all| guys| two| both)? (?:really |actually |still |even )?(like|love|enjoy|hate|dislike|mind|prefer)\s+(.+)$/.exec(body))) out.kind = 'ynQ', out.stance = /hate|dislike|mind/.test(yn[1]) ? 'dislike' : 'like', out.obj = cleanObj(stripTime(yn[2]));
  else if ((yn = /^(?:are|is) (?:you|@n) (?:any |very |really )?(?:good|great|bad|any good|fast|quick|strong) at\s+(.+)$/.exec(body)) || (yn = /^(?:can|could) (?:you|@n)\s+(.+?)\s*\??$/.exec(body))) out.kind = 'ynQ', out.stance = 'skill', out.obj = cleanObj(yn[1]);
  else if ((yn = /^(?:have|did) (?:you|@n) (?:ever |already |never )?(?:been|done|gone|tried|had|played|won|seen|battled|raced|fished|cooked|swum|eaten|met)\s*(.*)$/.exec(body))) out.kind = 'ynQ', out.stance = 'done', out.obj = cleanObj(yn[0].replace(/^(?:have|did) (?:you|@n) (?:ever |already |never )?/, ''));
  if (out.kind === 'ynQ') {
    out.acts = activitiesIn(out.obj); out.act = out.acts[0] ?? null; out.genre = genreIn(out.obj);
    // a yes/no "can you…" that isn't about a thing to do is a request, not a question about skill
    if (out.stance === 'skill' && /^(?:can|could)\b/.test(body) && !out.act) { out.kind = null; out.stance = null; }
    else { finish(out, hits, voc); return out; }
  }

  // ---------- a suggestion: "let's race from the hammock to the toy box", "race to the tree!" ----------
  if ((w = /^(?:(?:ok|okay|alright|right|so|now|come on|c'?mon)[, ]+)?(?:let's|let us|shall we|how about(?: we| a| some| going)?|what about(?: a| some)?|why do not we|we should|time (?:for (?:a |some )?|to )|go and|go|everyone|everybody|all of you|you (?:two|all|guys|both))\s+(.+)$/.exec(body)) && activityIn(w[1])) {
    out.kind = 'propose'; out.obj = cleanObj(w[1]); out.acts = activitiesIn(w[1]); out.act = out.acts[0];
    finish(out, hits, voc); return out;
  }
  if (/^(?:race|have a race|battle|play (?:fetch|tag|hide)|go (?:swimming|fishing))\b/.test(body) && out.act) { out.kind = 'propose'; out.obj = cleanObj(body); finish(out, hits, voc); return out; }

  finish(out, hits, voc);
  return out;
}

// who it's said to and who it's about
function finish(out, hits, voc) {
  const vocs = [...voc];
  if (vocs.length) { out.addressees = vocs; out.about = [...new Set(out.named.filter((u) => !voc.has(u)))]; return; }
  // no one addressed by name: named creatures after "about / of / with / like / beat / than / to" are being talked about
  const s = out.s;
  const aboutHit = hits.filter((h) => /\b(?:about|of|with|like|likes|love|loves|beat|beats|than|to|at|and|or|hate|trust|miss|is|from|for|remember|recall|prefer|know|seen|met)\s*$/.test(s.slice(0, h.at)) || /^\s*(?:your|is your)\b/.test(s.slice(h.at + h.len)));
  if (out.kind === 'opinionOf' || (out.kind === 'groupQ' && (out.stance === 'stat' || out.compare)) || out.kind === 'remember' || out.kind === 'loreQ') {
    out.about = [...new Set(aboutHit.map((h) => h.uid))];
    out.addressees = out.kind === 'groupQ' && out.compare ? [...out.compare] : out.named.filter((u) => !out.about.includes(u));
    return;
  }
  if (out.kind === 'remark' || out.kind === 'ynQ' || out.kind === 'groupQ') {
    const objHits = hits.filter((h) => out.obj && out.obj.includes('@n') && aboutHit.includes(h));
    out.about = [...new Set(objHits.map((h) => h.uid))];
    out.addressees = out.named.filter((u) => !out.about.includes(u));
    return;
  }
  out.addressees = [...out.named];
}

/** "from the hammock to the toy box", "to the tree", "around the pond": { from, to } (place ids, words). */
export function routeOf(text) {
  const s = String(text ?? '');
  const places = placesIn(s);
  if (!places.length) return null;
  const fromM = /\bfrom\s+(?:the\s+|that\s+|your\s+|my\s+)?/g, toM = /\b(?:to|towards|till|until|over to|up to|as far as|round|around)\s+(?:the\s+|that\s+|your\s+|my\s+)?/g;
  let from = null, to = null;
  for (const p of places) {
    const before = s.slice(Math.max(0, p.at - 14), p.at);
    if (/\bfrom\s+(?:the\s+|that\s+|your\s+|my\s+)?$/.test(before)) from = from ?? p;
    else if (/\b(?:to|towards|till|until|over to|up to|as far as|round|around|reach|reaches|touch|touches)\s+(?:the\s+|that\s+|your\s+|my\s+)?$/.test(before) || /\bfirst (?:one )?to\s+(?:the\s+)?$/.test(before)) to = p;
  }
  void fromM; void toM;
  if (!from && !to) {
    // "between the slide and the pond": the first to the second
    if (/\bbetween\b/.test(s) && places.length >= 2) return { from: { id: places[0].id, words: places[0].words }, to: { id: places[1].id, words: places[1].words } };
    return null;
  }
  return { from: from ? { id: from.id, words: from.words } : null, to: to ? { id: to.id, words: to.words } : null, back: /\band back\b|\bthere and back\b/.test(s) };
}

/** A deal from what was said, or null: { cond: { kind, next, words, route }, prize: { kind, label, icon, words } }. */
export function dealOf(body) {
  const s = String(body ?? '');
  const m = /\b(?:whoever|who ?ever|whichever (?:one|of you)|the (?:first )?(?:one|pokemon|mon|person)s? (?:who|that)|first (?:one )?(?:to|who|that)|(?:the )?winners?|the champion|the fastest(?: one)?|if (?:you|anyone|any ?body|someone|any of you|one of you|either of you)(?: can)? (?:win|wins|beat|beats|get|gets|make it|makes it|reach|reaches|finish|finishes|find|finds|catch|catches))\b(.*?)\b(?:gets?|will get|shall get|can (?:have|get|go|come|pick|choose|sit|sleep)|earns?|is getting|receives?|gets to have)\b\s*(?:to\s+)?(.+)$/.exec(s);
  if (!m) return null;
  const prizeText = m[2], condText = m[0].slice(0, m[0].length - prizeText.length).replace(/\b(?:gets?|will get|shall get|can (?:have|get|go|come|pick|choose|sit|sleep)|earns?|is getting|receives?|gets to have)\b\s*(?:to\s+)?$/, '').trim();
  const prize = prizeIn(prizeText);
  if (!prize) return null;
  const whole = s;
  let kind = 'any';
  const condAct = activityIn(condText) ?? activityIn(whole.slice(0, m.index));
  if (/\bfirst (?:one )?to\b|\bfastest\b/.test(condText) || condAct?.id === 'race') kind = 'race';
  else if (condAct?.id === 'battle') kind = 'battle';
  else if (condAct) kind = condAct.id;
  else if (/\bwin|winner|beat|champion\b/.test(condText)) kind = /\bbattle|fight/.test(whole) ? 'battle' : /\brace\b/.test(whole) ? 'race' : 'any';
  const route = routeOf(condText) ?? routeOf(whole.slice(0, m.index));
  return { cond: { kind, next: !/\bthis\b/.test(condText) || /\bnext\b/.test(condText), words: condText, route }, prize, prizeWords: cleanObj(prizeText), route };
}

/** A song, an artist, a kind of music, from how it was described. */
export function musicBits(raw, phrase) {
  const p = String(phrase ?? '').trim();
  const quoted = /["“]([^"”]{1,80})["”]/.exec(raw)?.[1] ?? /'([^']{2,60})'/.exec(raw)?.[1] ?? null;
  const called = /\b(?:called|named|titled)\s+(.+?)(?:\s+by\s+.+)?$/.exec(p)?.[1] ?? null;
  let artist = /\bby\s+([a-z0-9 .&'!-]{2,40}?)(?:\s*[?!.]|$)/.exec(p)?.[1]?.trim() ?? null;
  const genre = genreIn(p);
  let title = quoted ?? called ?? null;
  if (!title) {
    // "my favourite song, Bohemian Rhapsody" / "this song: X" / "X by Y" / "the X soundtrack"
    const t = p.replace(/\s+by\s+.+$/, '').replace(/\s*\b(?:again|one more time|once more)$/, '').replace(/^(?:to |you |for you )/, '').replace(/^(?:some|a|an|the|this|that|my|our|a really good|a new|this new|my favourite|an old)\s+/, '').replace(/^(?:song|track|tune|album|record|single|piece)\s*[:,-]?\s*/, '').replace(/\s+(?:song|track|tune|album)$/, '').trim();
    if (t && !/^(?:music|songs?|tunes?|something|some music|a song|stuff|this|that|it|again|this song|that song|the song)$/.test(t) && !(genre && new RegExp(`^(?:${t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})$`).test(t) && /^(?:[a-z-]+ )?(?:music|songs?|tunes?)$/.test(t))) title = t;
  }
  if (title && genre && /^(?:[a-z& -]+ )?(?:music|songs?|tunes?|beats|stuff)$/.test(title)) title = null; // ("some jazz music" is a kind, not a song)
  if (title && genre && title.replace(/\s*music$/, '') === p.replace(/^(?:some|a|the)\s+/, '').replace(/\s*music$/, '')) title = null;
  if (artist && /^(?:me|you|myself)$/.test(artist)) artist = null;
  const music = !!(genre || MUSICY.test(p) || artist || quoted);
  const clean = (x) => (x ? x.replace(/[?!.]+$/, '').trim() : null);
  return { title: clean(title), artist: clean(artist), genre, music, obj: cleanObj(p) };
}

/** The object of a phrase, tidied: leading articles off, trailing filler and punctuation off. */
export function cleanObj(x) {
  return String(x ?? '').toLowerCase().replace(/[?!.]+\s*$/, '').replace(/,?\s*(?:do not you|do you not|right|huh|eh|i guess|i bet|then|too|either|at all|of all things|so much|that much|a lot|lol|haha)\s*$/g, '')
    .replace(/^(?:the|a|an|some|any|doing|going|to go|to)\s+/, '').replace(/\s+/g, ' ').trim();
}
