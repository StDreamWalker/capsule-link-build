// Messages between the phone app, the PC app and the battle relay (JSON over WebSocket).
export const PROTOCOL_VERSION = 1;
export const HUB_PORT = 47820;
export const DISCOVERY_PORT = 47821;
export const BUMP_WINDOW_MS = 1500;

export const MSG = Object.freeze({
  // client -> hub
  HELLO: 'hello',
  PULL: 'sync.pull',
  PUSH: 'sync.push',
  TAKE: 'pocket.take',
  RETURN: 'pocket.return',
  FIND: 'battle.find',
  BUMP: 'battle.bump',
  CANCEL: 'battle.cancel',
  PING: 'ping',
  // simulated capsule on a phone, placed on the PC dock (phone <-> hub <-> PC dock screen)
  CAP_ATTACH: 'capsule.attach',
  CAP_DETACH: 'capsule.detach',
  CAP_READ: 'capsule.read',
  CAP_WRITE: 'capsule.write',
  CAP_REPLY: 'capsule.reply',
  // phone backups kept on the PC
  BACKUP_PUT: 'backup.put',
  BACKUP_LIST: 'backup.list',
  BACKUP_GET: 'backup.get',
  // the PC's virtual capsules, tapped by a phone over the link (debug: stands in for NFC)
  VTAG_LIST: 'vtag.list',
  VTAG_READ: 'vtag.read',
  VTAG_WRITE: 'vtag.write',
  // debug ball hardware: a PC virtual ball handed to the phone (TAKE) or back to the PC (GIVE)
  VTAG_TAKE: 'vtag.take',
  VTAG_GIVE: 'vtag.give',
  DOCK_GET: 'dock.get',
  // hub -> client
  WELCOME: 'welcome',
  ERROR: 'error',
  STATE: 'sync.state',
  WAITING: 'battle.waiting',
  NO_MATCH: 'battle.nomatch',
  MATCHED: 'battle.matched',
  NOTIFY: 'notify',
  PONG: 'pong',
  CHANGED: 'hub.changed',
  CAP_ATTACHED: 'capsule.attached',
  CAP_DETACHED: 'capsule.detached',
  BACKUP: 'backup.reply',
  VTAG: 'vtag.reply',
  DOCK: 'dock.reply',
});
