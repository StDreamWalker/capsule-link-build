// Forms: alternate looks of a species (weather forms, seasonal forms, appliance forms…). Each form is a
// species entry of its own in the data set (imported with "Skip alternate forms" unticked), linked to its
// base by `baseSpecies` (or, for older data, by a name like "Base-Form").
//   c.formId   the form a creature is in right now (null: its own species)
// Battle-only forms (sp.battleOnly) can be shown at home but go into battles as their base form.

const lc = (s) => String(s ?? '').toLowerCase();

/** The base species of a species (itself if it isn't a form). */
/** Regional variants (Alolan, Galarian, Hisuian, Paldean…) are species of their own, not switchable forms. */
export const isRegional = (sp) => /\b(alola|alolan|galar|galarian|hisui|hisuian|paldea|paldean)\b/i.test(`${sp?.forme ?? ''} ${String(sp?.name ?? '').replace(/-/g, ' ')}`);
export function baseSpeciesOf(idx, sp) {
  if (!sp) return null;
  if (isRegional(sp)) return sp;
  if (sp.baseSpecies) { const b = idx.species.get(sp.baseSpecies) ?? [...idx.species.values()].find((x) => lc(x.name) === lc(sp.baseSpecies)); if (b && b !== sp) return b; }
  const cut = String(sp.name ?? '').indexOf('-');
  if (cut > 0) {
    const name = lc(sp.name.slice(0, cut));
    const b = idx._byLcName?.get(name) ?? [...idx.species.values()].find((x) => lc(x.name) === name);
    if (b && b !== sp && (b.no === sp.no || sp.no > 10000 || sp.baseSpecies)) return b;
  }
  return sp;
}

/** Every form of a species, its base first: [{ id, name, forme, sp, battleOnly }]. */
export function formsOf(idx, speciesId) {
  const sp0 = idx.species.get(speciesId);
  if (!sp0) return [];
  const base = baseSpeciesOf(idx, sp0);
  if (!idx._forms) {
    idx._forms = new Map();
    idx._byLcName = new Map([...idx.species.values()].map((x) => [lc(x.name), x]));
    for (const sp of idx.species.values()) {
      const b = baseSpeciesOf(idx, sp);
      if (b === sp) continue;
      if (!idx._forms.has(b.id)) idx._forms.set(b.id, []);
      idx._forms.get(b.id).push(sp);
    }
  }
  const list = [base, ...(idx._forms.get(base.id) ?? [])];
  return list.map((sp) => ({ id: sp.id, name: sp.name, forme: sp === base ? 'Usual' : (sp.forme || sp.name.slice(base.name.length + 1) || sp.name), sp, battleOnly: !!sp.battleOnly }));
}

/** The species id to show for a creature right now (its form, or its own species). */
export function currentFormId(idx, c) {
  if (c?.formId && idx.species.has(c.formId) && formsOf(idx, c.speciesId).some((f) => f.id === c.formId)) return c.formId;
  return c?.speciesId;
}

/** Change form. Returns { ok, reason }. */
export function setForm(idx, c, formId) {
  const forms = formsOf(idx, c.speciesId);
  if (!formId || formId === c.speciesId) { c.formId = null; return { ok: true }; }
  if (!forms.some((f) => f.id === formId)) return { ok: false, reason: 'That isn’t one of its forms.' };
  c.formId = formId;
  return { ok: true };
}

// weather words a form's name can carry
const WEATHER_FORMS = [
  ['sun', /sun|sunny|solar|summer|heat|blaze/i],
  ['rain', /rain|rainy|storm|drizzle|water/i],
  ['snow', /snow|snowy|hail|ice|icy|frost|winter|cold/i],
  ['wind', /wind|gust|breeze/i],
  ['fog', /fog|mist|haze/i],
];
/**
 * The form the weather calls for (for weather-shaped species), or null if this species has none.
 * weather: 'sun'|'clouds'|'rain'|'storm'|'snow'|'fog'|'wind'; temp in °C. Hot (28 °C+) counts as sun,
 * freezing (2 °C or less) as snow.
 */
export function weatherForm(idx, c, { weather, temp } = {}) {
  const forms = formsOf(idx, c.speciesId);
  if (forms.length < 2) return null;
  const tagged = forms.slice(1).map((f) => ({ ...f, w: WEATHER_FORMS.find(([, re]) => re.test(f.forme))?.[0] })).filter((f) => f.w);
  if (!tagged.length) return null;
  let want = weather === 'storm' ? 'rain' : weather;
  if (Number.isFinite(temp) && temp >= 28) want = 'sun';
  if (Number.isFinite(temp) && temp <= 2) want = 'snow';
  const hit = tagged.find((f) => f.w === want);
  return hit ? hit.id : forms[0].id;
}

/** The species a creature battles as: its form, unless that form only exists mid-battle. */
export function battleSpeciesOf(idx, c) {
  const id = currentFormId(idx, c);
  const sp = idx.species.get(id);
  if (sp && !sp.battleOnly) return sp;
  return idx.species.get(c.speciesId);
}

// ---------- how a species gets about (the R.A.N.C.H. and the desktop) ----------
// ds.movement = { float: [ids], noFloat: [ids], swim: [ids], noSwim: [ids] } — set in the Data Lab (Rules).
// Anything not listed is worked out from its types and abilities.
export function movementOf(idx, sp, c = null) {
  const m = idx.ds?.movement ?? {};
  const id = sp?.id;
  const types = (sp?.types ?? []).flatMap((t) => [t, idx.types?.get(t)?.name ?? t]).join(' ');
  const levit = /levitat/i.test(`${c?.ability ?? ''} ${(sp?.abilities ?? []).join?.(' ') ?? ''}`);
  const has = (k) => (m[k] ?? []).includes(id);
  const float = has('float') ? true : has('noFloat') ? false : /flying|gale/i.test(types) || levit || !!sp?.floats;
  const swim = has('swim') ? true : has('noSwim') ? false : /water|tide/i.test(types);
  return { float, swim };
}
