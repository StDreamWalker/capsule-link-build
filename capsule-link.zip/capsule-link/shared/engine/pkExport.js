// Sending creatures back to PKHeX: a .pk9 / .pk8 file PKHeX opens (PKHeX keeps its own files decrypted,
// so these are written decrypted with a correct checksum, the same as PKHeX saves them).
//  - came in from a Gen 8/9 file: that file, with what changed here written over it (level, effort,
//    genes, nickname, moves, friendship…). Everything else the game kept stays as it was.
//  - came in from an older file (.pk3 to .pk7): that original file, unchanged (older layouts can't be written yet).
//  - remembered (Import from memory) or born here: a fresh Scarlet/Violet file built from what's known.
// What lives only in Capsule Link (memories, mood, the journal, friends) has no place in a PKHeX file.
// Bring the same file back in and it's matched to the creature by its PID and encryption constant, so
// none of that is lost.
import { NATURE_NAMES, readPkm } from './pkhex.js';
import { expForLevel } from './dataset.js';
import { STAT_KEYS } from './defaults.js';

const SIZE_STORED = 0x148;
const u16 = (d, o) => d[o] | (d[o + 1] << 8);
const u32 = (d, o) => (d[o] | (d[o + 1] << 8) | (d[o + 2] << 16) | (d[o + 3] << 24)) >>> 0;
const w16 = (d, o, v) => { d[o] = v & 255; d[o + 1] = (v >> 8) & 255; };
const w32 = (d, o, v) => { w16(d, o, v & 0xffff); w16(d, o + 2, (v >>> 16) & 0xffff); };
function wstr(d, o, s, max = 12) {
  for (let i = 0; i <= max; i++) w16(d, o + i * 2, 0);
  const t = String(s ?? '').slice(0, max);
  for (let i = 0; i < t.length; i++) w16(d, o + i * 2, t.charCodeAt(i));
}
function fromB64(s) {
  const bin = typeof atob === 'function' ? atob(s) : Buffer.from(s, 'base64').toString('binary');
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function sum(d) { let s = 0; for (let i = 8; i < SIZE_STORED; i += 2) s = (s + u16(d, i)) & 0xffff; return s; }
const clampEv = (effort) => {
  const ev = Object.fromEntries(STAT_KEYS.map((k) => [k, Math.max(0, Math.min(252, Math.round(effort?.[k] ?? 0)))]));
  let total = STAT_KEYS.reduce((a, k) => a + ev[k], 0);
  for (const k of [...STAT_KEYS].reverse()) { if (total <= 510) break; const cut = Math.min(ev[k], total - 510); ev[k] -= cut; total -= cut; }
  return ev;
};
const EV_AT = { hp: 0x26, atk: 0x27, def: 0x28, spe: 0x29, spa: 0x2a, spd: 0x2b };
const IV_SHIFT = { hp: 0, atk: 5, def: 10, spe: 15, spa: 20, spd: 25 };
const NATURE_INDEX = (name) => { const i = NATURE_NAMES.findIndex((n) => n.toLowerCase() === String(name ?? '').toLowerCase()); return i < 0 ? null : i; };
const MARK_BITS = { circle: 0, triangle: 1, square: 2, heart: 3, star: 4, diamond: 5 };

/** Can this creature go to PKHeX, and how? { ok, how: 'patch' | 'original' | 'fresh', reason } */
export function exportPlan(idx, c) {
  if (!c) return { ok: false, reason: 'Nobody picked.' };
  if (c.egg) return { ok: false, reason: 'Eggs can’t be sent to PKHeX yet. Hatch it first.' };
  if (c.pk?.raw && (c.pk.gen === 8 || c.pk.gen === 9)) return { ok: true, how: 'patch' };
  if (c.pk?.raw) return { ok: true, how: 'original' };
  const sp = idx.species.get(c.speciesId);
  const no = Number(sp?.no);
  if (!no) return { ok: false, reason: `${sp?.name ?? 'This species'} has no national number in your data set (set one in the Data Lab), so the games wouldn’t know it.` };
  if (no > 905) return { ok: false, reason: `${sp.name} is from Scarlet/Violet, which numbers species its own way inside files; only creatures that came in from a .pk9 file can go back for now.` };
  return { ok: true, how: 'fresh' };
}

/**
 * The file for a creature: { ok, bytes, name, how, notes, error }.
 * notes: what couldn't be carried over (moves without a number in your data set, and so on).
 */
export function exportPkm(idx, c, { now = Date.now() } = {}) {
  const plan = exportPlan(idx, c);
  if (!plan.ok) return { ok: false, error: plan.reason };
  const notes = [];
  const sp = idx.species.get(c.speciesId);
  const R = idx.ds.rules;
  const pk = c.pk ?? {};
  let d, ext;
  if (plan.how === 'original') {
    d = fromB64(pk.raw); ext = pk.format || `pk${pk.gen || 7}`;
    notes.push(`This one came from an older game (${ext.toUpperCase()}), so it goes back exactly as it came in; what changed here stays in Capsule Link.`);
    return { ok: true, bytes: d, how: plan.how, notes, name: fileName(idx, c, sp, ext) };
  }
  if (plan.how === 'patch') { d = fromB64(pk.raw); ext = pk.format && /^[pe][kb][89]$/.test(pk.format) ? pk.format.replace(/^e/, 'p') : `pk${pk.gen}`; }
  else { d = new Uint8Array(SIZE_STORED); ext = 'pk9'; fresh(idx, d, c, sp, pk, now, notes); }
  const gen = plan.how === 'patch' ? pk.gen : 9;
  // ----- what can change in Capsule Link, written over the file -----
  // level (as experience on the species' curve) — only if it changed here, so the game's exact number stays otherwise
  const lvAt = (exp) => { let lv = 1; while (lv < (R.maxLevel ?? 100) && expForLevel(idx, sp.growthRate, lv + 1) <= exp) lv++; return lv; };
  const fileExp = u32(d, 0x10);
  if (plan.how === 'fresh' || lvAt(fileExp) !== c.level) w32(d, 0x10, expForLevel(idx, sp.growthRate, c.level));
  if (d.length > SIZE_STORED) d[0x148] = c.level;
  const ev = clampEv(c.effort);
  for (const k of STAT_KEYS) d[EV_AT[k]] = ev[k];
  const maxG = R.maxGenes ?? 31;
  let iv32 = u32(d, 0x8c) & 0xc0000000;
  for (const k of STAT_KEYS) iv32 |= (Math.max(0, Math.min(31, Math.round(((c.genes?.[k] ?? 0) * 31) / maxG))) & 31) << IV_SHIFT[k];
  if (c.nickname) { wstr(d, 0x58, c.nickname, 12); iv32 |= 0x80000000; }
  else if (plan.how === 'fresh') wstr(d, 0x58, sp.name, 12);
  w32(d, 0x8c, iv32 >>> 0);
  // moves: by their number in the games
  const nums = (c.moves ?? []).map((m) => ({ no: Number(idx.moves.get(m.id)?.no) || 0, mv: idx.moves.get(m.id), m }));
  if (nums.length && nums.every((x) => x.no)) {
    for (let i = 0; i < 4; i++) { const x = nums[i]; w16(d, 0x72 + i * 2, x?.no ?? 0); d[0x7a + i] = x ? Math.max(0, Math.min(99, x.m.pp ?? x.mv?.pp ?? 10)) : 0; }
  } else if (nums.length) notes.push(`Moves kept as they were in the file: ${nums.filter((x) => !x.no).map((x) => x.mv?.name ?? x.m.id).join(', ')} ${nums.filter((x) => !x.no).length === 1 ? 'has' : 'have'} no game number in your data set.`);
  // friendship goes to whoever looks after them now
  const fr = Math.max(0, Math.min(255, Math.round(c.friendship ?? 70)));
  if (d[0xc4] === 1) d[0xc8] = fr; else d[0x112] = fr;
  // markings and the ball, if they were told or changed
  if (pk.markList) { let mk = 0; for (const m of pk.markList) if (MARK_BITS[m] != null) mk |= 1 << (MARK_BITS[m] * 2); w16(d, 0x18, mk); }
  if (Number(pk.ball)) d[0x124] = Number(pk.ball);
  if (c.shiny && plan.how === 'fresh' && !pk.pidGiven) makeShiny(d);
  w16(d, 0x06, sum(d));
  // a quick check: the file reads back as the same creature
  const back = readPkm(d, `x.${ext}`);
  if (!back.ok) return { ok: false, error: `Couldn’t make a file PKHeX would open (${back.error}).` };
  if (gen === 9 && plan.how === 'fresh') notes.push('Built fresh as a Scarlet/Violet file. PKHeX opens it; its legality checker may flag details the games would have filled in themselves.');
  // the file's identity: keep it on the creature, so bringing this file back in finds them again
  return { ok: true, bytes: d, how: plan.how, notes, name: fileName(idx, c, sp, ext), ident: { pid: u32(d, 0x1c), ec: u32(d, 0) } };
}

function fileName(idx, c, sp, ext) {
  const no = String(Number(sp?.no) || 0).padStart(4, '0');
  const nm = (c.nickname || sp?.name || 'creature').replace(/[\\/:*?"<>|]+/g, '');
  const ec = (Number(c.pk?.ec ?? c.ec ?? 0) >>> 0).toString(16).toUpperCase().padStart(8, '0');
  return `${no}${c.shiny ? ' ★' : ''} - ${nm} - ${ec}.${ext}`;
}

// a fresh Scarlet/Violet file from what's known
function fresh(idx, d, c, sp, pk, now, notes) {
  const rnd = () => (Math.random() * 4294967296) >>> 0;
  const ec = (Number(pk.ec) >>> 0) || rnd(), pid = (Number(pk.pid) >>> 0) || (Number(c.pid) >>> 0) || rnd();
  w32(d, 0x00, ec);
  w16(d, 0x08, Number(sp.no));
  // the trainer ID on screen (6 digits since Sun/Moon) is the 32-bit id mod 1,000,000: keep those digits
  if (pk.tid != null || pk.sid != null) { w16(d, 0x0c, Number(pk.tid) || 0); w16(d, 0x0e, Number(pk.sid) || 0); }
  else if (Number(pk.trainerId)) w32(d, 0x0c, (Number(pk.trainerId) % 1000000) >>> 0);
  w16(d, 0x14, Number(pk.abilityId) || 0);
  d[0x16] = [1, 2, 4][Number(pk.abilitySlot ?? 0)] ?? 1;
  w32(d, 0x1c, pid);
  const temp = idx.temperaments?.get?.(c.temper);
  const nat = NATURE_INDEX(pk.nature) ?? NATURE_INDEX(temp?.showdownName ?? temp?.name) ?? 0;
  d[0x20] = nat; d[0x21] = NATURE_INDEX(pk.statNature) ?? nat;
  d[0x22] = (pk.fateful ? 1 : 0) | ((c.gender === 'female' ? 1 : c.gender === 'none' ? 2 : 0) << 1);
  w16(d, 0x24, Number(pk.form) || 0);
  if (pk.pokerus) d[0x32] = 0x11;
  // size: 0-255, middle by default
  const size = Number.isFinite(c.sizeScalar) ? c.sizeScalar : 128;
  d[0x48] = size; d[0x49] = 128; d[0x4a] = size;
  if (pk.teraType != null) { d[0x94] = Number(pk.teraType) || 0; d[0x95] = 19; }
  d[0xce] = Number(pk.version) || 50;
  d[0xd5] = Number(pk.language) || 2;
  wstr(d, 0xf8, pk.otName || c.trainer || 'Trainer', 12);
  d[0x112] = Math.max(0, Math.min(255, Math.round(c.friendship ?? 70)));
  const met = new Date(c.metAt ?? now);
  if (pk.metDate) { d[0x11c] = pk.metDate.y - 2000; d[0x11d] = pk.metDate.m; d[0x11e] = pk.metDate.d; }
  else if (met.getFullYear() >= 2000) { d[0x11c] = met.getFullYear() - 2000; d[0x11d] = met.getMonth() + 1; d[0x11e] = met.getDate(); }
  if (pk.hatched) { d[0x119] = d[0x11c]; d[0x11a] = d[0x11d]; d[0x11b] = d[0x11e]; w16(d, 0x120, 30023); }
  w16(d, 0x122, Number(pk.metLocation) || 0);
  d[0x124] = Number(pk.ball) || 4;
  d[0x125] = (Math.max(1, Math.min(100, Number(pk.metLevel) || c.metLevel || c.level)) & 0x7f) | ((pk.otGender === 1 || pk.otGender === 'female' ? 1 : 0) << 7);
  w16(d, 0x8a, 0);
  if (pk.metPlace) notes.push(`Where you met (${pk.metPlace}) stays in Capsule Link: the file needs the game’s own place number, so PKHeX will show it as unknown.`);
  if (pk.ribbons?.length) notes.push(`Ribbons you remembered (${pk.ribbons.length}) are kept in Capsule Link; add them in PKHeX’s ribbon editor if you want them on the file.`);
}

/** Shiny the way the games check it: the PID's halves XOR the trainer's id to under 16. */
function makeShiny(d) {
  const tid = u16(d, 0x0c), sid = u16(d, 0x0e);
  const pid = u32(d, 0x1c), low = pid & 0xffff;
  const high = (tid ^ sid ^ low) & 0xffff; // xor 0: square
  w32(d, 0x1c, ((high << 16) | low) >>> 0);
}
