// Long-term memory and preferences.
//
// Two kinds of memories:
//   core memories (c.memories)  — rare and lasting: where you met, hatching, evolving, first battles,
//                                 the first time somewhere truly new, finding a favourite, making a
//                                 friend, and now and then an ordinary moment that simply stuck.
//   the journal (c.journal)     — the last few everyday things (first kibble, a brush…); it rolls over.
//
// Preferences (c.prefs) grow quietly out of experiences: every walk, wash, toy or berry nudges how
// a creature feels about the things involved (the place, the weather, the time of day, a car ride…).
// Rarely an experience becomes a core memory, which fixes a strong liking for those things. Liked
// things then make the same activities more joyful (prefBonus) and show up in thoughts.
import { createRng } from './rng.js';

export const MAX_CORE = 40;
export const MAX_JOURNAL = 20;

// how preference keys read in sentences ("loves {label}")
const LABELS = {
  'env:urban': 'the city', 'env:forest': 'the woods', 'env:water': 'being by the water', 'env:plains': 'open fields',
  'env:mountain': 'the hills', 'env:desert': 'the desert', 'env:snow': 'the snow', 'env:cave': 'going underground',
  'place:beach': 'the beach', 'place:park': 'parks', 'place:river': 'riversides', 'place:cemetery': 'quiet old graveyards',
  'place:city-centre': 'busy streets', 'place:countryside': 'the countryside', 'place:industrial': 'industrial yards',
  'place:hospital': 'hospital grounds', 'place:temple': 'shrines and churches', 'place:sports': 'sports grounds',
  'place:farm': 'farmland', 'place:wetland': 'marshes', 'place:rocky': 'rocky ground', 'place:peak': 'high places',
  'weather:sun': 'sunny days', 'weather:clouds': 'cloudy days', 'weather:rain': 'rainy days', 'weather:storm': 'thunderstorms',
  'weather:snow': 'snowy days', 'weather:fog': 'foggy days', 'weather:wind': 'windy days', 'weather:hot': 'hot weather', 'weather:cold': 'cold weather',
  'time:dawn': 'early mornings', 'time:day': 'the daytime', 'time:dusk': 'sunsets', 'time:night': 'night walks',
  'activity:walk': 'walks', 'activity:long-walk': 'long walks', 'activity:car': 'car rides', 'activity:run': 'running',
  'activity:bath': 'bath time', 'activity:brush': 'being brushed', 'activity:pet': 'being petted', 'activity:battle': 'battling',
  'activity:play': 'playtime', 'activity:fetch': 'playing fetch', 'activity:nap': 'naps',
};
const CLOTHES_NAMES = { bow: 'ribbon bow', tophat: 'top hat', cap: 'sports cap', scarf: 'knit scarf', specs: 'round specs', shades: 'sunglasses', flower: 'hair flower', crown: 'tiny crown', bandana: 'bandana', starpin: 'star pin', bellcollar: 'bell collar', witchhat: 'pointy hat', beanie: 'beanie', headphones: 'headphones', monocle: 'monocle', heartclip: 'heart clip' };
export function prefLabel(key, idx = null) {
  if (LABELS[key]) return LABELS[key];
  const [kind, id] = String(key).split(':');
  if (kind === 'clothes' && !idx?.items?.get(id)) return `their ${CLOTHES_NAMES[id.replace(/^clothes-/, '')] ?? id.replace(/^clothes-/, '').replace(/-/g, ' ')}`;
  if (kind === 'food' || kind === 'toy' || kind === 'clothes') return idx?.items?.get(id)?.name ?? id.replace(/-/g, ' ');
  if (kind === 'friend') return 'a friend';
  return id ?? key;
}

/** A line for the journal (everyday things that roll over). */
export function journal(c, text, t = Date.now()) {
  c.journal = c.journal || [];
  c.journal.push({ t, text });
  if (c.journal.length > MAX_JOURNAL) c.journal.splice(0, c.journal.length - MAX_JOURNAL);
}

/**
 * Something that happened, felt with `joy` (-10 … +10). keys: what it involved, e.g.
 * ['env:water', 'weather:rain', 'time:dawn', 'activity:walk']. Nudges preferences; rarely (and
 * more often when it felt strong) it becomes a core memory that fixes a strong liking.
 * opts: { t, seed, label: 'that rainy morning by the water', coreChance }
 * Returns { core: text | null }.
 */
export function experience(c, keys, joy, opts = {}) {
  if (!c || !keys?.length) return { core: null };
  const t = opts.t ?? Date.now();
  const p = (c.prefs = c.prefs || {});
  const step = Math.max(-1, Math.min(1, joy / 10)) * 0.35;
  for (const k of keys) p[k] = Math.max(-10, Math.min(10, (p[k] ?? 0) + step));
  const rng = createRng(opts.seed ?? `${c.uid}:${t}:${keys.join()}`);
  // only things they don't already love can become a new core memory, and each one makes the
  // next rarer (a long life has a handful of these, not dozens)
  const fresh = keys.filter((k) => (p[k] ?? 0) < 6 && !k.startsWith('activity:walk'));
  const made = (c.memories ?? []).filter((m) => m.keys).length;
  const recent = (c.memories ?? []).some((m) => m.keys && t - m.t < 3 * 86400000);
  const chance = ((opts.coreChance ?? 0.02) * (1 + Math.abs(joy) / 4)) / (1 + made);
  if (joy >= 6 && opts.label && fresh.length && !recent && rng() < chance) {
    for (const k of keys) p[k] = Math.min(10, (p[k] ?? 0) + 4);
    const text = `${cap(opts.label)} stuck with them. Ever since, they love ${listOf(fresh.slice(0, 2).map((k) => prefLabel(k)))}.`;
    addCore(c, text, t, { keys: fresh });
    return { core: text };
  }
  return { core: null };
}

/** Add a core memory (kept for good, oldest everyday-ish ones go first when full). */
export function addCore(c, text, t = Date.now(), extra = {}) {
  c.memories = c.memories || [];
  c.memories.push({ t, text, core: true, ...extra });
  if (c.memories.length > MAX_CORE) {
    // keep where they came from (game history, meeting) and drop the oldest of the rest
    const i = c.memories.findIndex((m) => m.from !== 'game' && !/^Met /.test(m.text));
    c.memories.splice(i >= 0 ? i : 0, 1);
  }
}

/** Joy multiplier for an activity involving these keys: 0.7 (dislikes) … 1.6 (loves). */
export function prefBonus(c, keys) {
  if (!c?.prefs || !keys?.length) return 1;
  const s = keys.reduce((a, k) => a + (c.prefs[k] ?? 0), 0) / keys.length;
  return Math.max(0.7, Math.min(1.6, 1 + s / 12));
}

/** Their strongest likes (and dislikes): [{ key, score, label }] */
export function topPrefs(c, idx = null, n = 4) {
  return Object.entries(c?.prefs ?? {}).filter(([k, v]) => v >= 2 && !k.startsWith('friend:')).sort((a, b) => b[1] - a[1]).slice(0, n).map(([key, score]) => ({ key, score, label: prefLabel(key, idx) }));
}
export function dislikes(c, idx = null, n = 2) {
  return Object.entries(c?.prefs ?? {}).filter(([, v]) => v <= -2).sort((a, b) => a[1] - b[1]).slice(0, n).map(([key, score]) => ({ key, score, label: prefLabel(key, idx) }));
}

// memories older versions saved as lasting that are really everyday things
const EVERYDAY = [/^Tasted /, /^Got brushed/, /^Played catch/, /^Had a bath/, /^Friendship reached (100|150|200)\b/, /^Reached level (?!50\b|100\b)\d+/,
  /^Walked (1,000|5,000|10,000|25,000|50,000) steps/, /^Arrived in a capsule/, /^Felt a gentle tap/, /^Leaned into a pat/, /^Streamed into .* again/];
/** Older saves: move everyday memories into the journal (runs once per creature). */
export function tidyMemories(c) {
  if (!c || c.memV >= 2) return;
  const keep = [], moved = [];
  for (const m of c.memories ?? []) (EVERYDAY.some((r) => r.test(m.text)) && m.from !== 'game' ? moved : keep).push(m);
  c.memories = keep.map((m) => ({ ...m, core: true }));
  for (const m of moved.slice(-MAX_JOURNAL)) journal(c, m.text, m.t);
  c.memV = 2;
}

const cap = (s) => String(s).charAt(0).toUpperCase() + String(s).slice(1);
const listOf = (a) => (a.length < 2 ? a.join('') : `${a.slice(0, -1).join(', ')} and ${a.at(-1)}`);
