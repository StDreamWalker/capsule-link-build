// Import from memory: bring in a creature you remember (from a cartridge you no longer have, a save
// that's gone, or just a friend you miss) by answering what PKHeX would show you. Every answer is
// optional; as you go, the species list narrows down (by name, type, region) and the rest fills in.
// The result can be sent to PKHeX afterwards (see pkExport.js).
import { createCreature, addMemory, speciesAbilities } from './creature.js';
import { NATURE_NAMES, GAME_NAMES } from './pkhex.js';
import { STAT_KEYS } from './defaults.js';

export const BALLS = [
  [4, 'Poké Ball'], [3, 'Great Ball'], [2, 'Ultra Ball'], [1, 'Master Ball'], [12, 'Premier Ball'], [5, 'Safari Ball'], [6, 'Net Ball'], [7, 'Dive Ball'],
  [8, 'Nest Ball'], [9, 'Repeat Ball'], [10, 'Timer Ball'], [11, 'Luxury Ball'], [13, 'Dusk Ball'], [14, 'Heal Ball'], [15, 'Quick Ball'], [16, 'Cherish Ball'],
  [17, 'Fast Ball'], [18, 'Level Ball'], [19, 'Lure Ball'], [20, 'Heavy Ball'], [21, 'Love Ball'], [22, 'Friend Ball'], [23, 'Moon Ball'], [24, 'Sport Ball'],
  [25, 'Dream Ball'], [26, 'Beast Ball'],
];
export const MARKINGS = [['circle', '●'], ['triangle', '▲'], ['square', '■'], ['heart', '♥'], ['star', '★'], ['diamond', '◆']];
export const RIBBONS = [
  'Champion Ribbon', 'Hoenn Champion', 'Sinnoh Champion', 'Kalos Champion', 'Alola Champion', 'Galar Champion', 'Paldea Champion', 'Master Rank Ribbon',
  'Effort Ribbon', 'Best Friends Ribbon', 'Classic Ribbon', 'Premier Ribbon', 'Event Ribbon', 'Birthday Ribbon', 'Wishing Ribbon', 'Battle Tower Ribbon',
  'Battle Tree Ribbon', 'Training Ribbon', 'Footprint Ribbon', 'Artist Ribbon', 'Contest Star Ribbon', 'Once-in-a-Lifetime Ribbon', 'Partner Ribbon', 'Souvenir Ribbon',
  'Lunchtime Mark', 'Rainy Mark', 'Uncommon Mark', 'Rare Mark', 'Jumbo Mark', 'Mini Mark', 'Titan Mark', 'Alpha Mark', 'Mightiest Mark',
];
export const MET_HOW = [
  ['caught', 'Caught them in the wild'], ['hatched', 'Hatched from an egg'], ['starter', 'My first partner (a starter)'], ['gift', 'Someone gave them to me in the game'],
  ['traded', 'A trade (with a friend, or online)'], ['event', 'A special event or download'], ['raid', 'A raid or Max Raid den'], ['other', 'Something else'],
];
export const TERA_TYPES = ['Normal', 'Fighting', 'Flying', 'Poison', 'Ground', 'Rock', 'Bug', 'Ghost', 'Steel', 'Fire', 'Water', 'Grass', 'Electric', 'Psychic', 'Ice', 'Dragon', 'Dark', 'Fairy', 'Stellar'];
export const JUDGE = [['31', 'Best (31)'], ['30', 'Fantastic (30)'], ['26', 'Very good (26–29)'], ['21', 'Pretty good (16–25)'], ['10', 'Decent (1–15)'], ['0', 'No good (0)']];

// places to meet, by the games' regions (the well-known ones; anything can be typed in)
const REGION_PLACES = {
  Kanto: ['Pallet Town', 'Viridian Forest', 'Route 1', 'Mt. Moon', 'Cerulean Cave', 'Rock Tunnel', 'Pokémon Tower', 'Safari Zone', 'Seafoam Islands', 'Power Plant', 'Victory Road', 'Diglett’s Cave', 'Celadon City', 'Route 24', 'Cinnabar Island'],
  Johto: ['New Bark Town', 'Route 29', 'Sprout Tower', 'Union Cave', 'Slowpoke Well', 'Ilex Forest', 'National Park', 'Burned Tower', 'Lake of Rage', 'Whirl Islands', 'Ice Path', 'Dark Cave', 'Mt. Silver', 'Ruins of Alph'],
  Hoenn: ['Littleroot Town', 'Route 101', 'Petalburg Woods', 'Granite Cave', 'Fiery Path', 'Mt. Chimney', 'Meteor Falls', 'Route 119', 'Safari Zone', 'Seafloor Cavern', 'Sky Pillar', 'Shoal Cave', 'Abandoned Ship', 'Victory Road'],
  Sinnoh: ['Twinleaf Town', 'Lake Verity', 'Route 201', 'Eterna Forest', 'Mt. Coronet', 'Great Marsh', 'Iron Island', 'Old Chateau', 'Snowpoint City', 'Lake Valor', 'Lake Acuity', 'Spear Pillar', 'Grand Underground', 'Stark Mountain'],
  Unova: ['Nuvema Town', 'Route 1', 'Pinwheel Forest', 'Desert Resort', 'Relic Castle', 'Chargestone Cave', 'Twist Mountain', 'Dragonspiral Tower', 'Giant Chasm', 'Victory Road', 'Abundant Shrine', 'Castelia City'],
  Kalos: ['Vaniville Town', 'Santalune Forest', 'Route 2', 'Glittering Cave', 'Reflection Cave', 'Frost Cavern', 'Terminus Cave', 'Lost Hotel', 'Friend Safari', 'Victory Road', 'Pokémon Village'],
  Alola: ['Iki Town', 'Route 1', 'Verdant Cavern', 'Brooklet Hill', 'Wela Volcano Park', 'Lush Jungle', 'Haina Desert', 'Poni Island', 'Vast Poni Canyon', 'Mount Lanakila', 'Ultra Space', 'Ten Carat Hill'],
  Galar: ['Postwick', 'Slumbering Weald', 'Route 1', 'Wild Area: Rolling Fields', 'Wild Area: Lake of Outrage', 'Giant’s Cap', 'Bridge Field', 'Motostoke Riverbank', 'Isle of Armor', 'Crown Tundra', 'Max Lair', 'Dynamax Adventure'],
  Hisui: ['Jubilife Village', 'Obsidian Fieldlands', 'Crimson Mirelands', 'Cobalt Coastlands', 'Coronet Highlands', 'Alabaster Icelands', 'Mass outbreak', 'Space-time distortion'],
  Paldea: ['Cabo Poco', 'South Province (Area One)', 'Los Platos', 'Asado Desert', 'Tagtree Thicket', 'Glaseado Mountain', 'Casseroya Lake', 'Area Zero', 'Kitakami: Mossui Town', 'Blueberry Academy: Terarium', 'Tera Raid Battle'],
  Other: ['Pokémon GO', 'Pokémon HOME', 'Pokémon Bank', 'Poké Transfer', 'Link trade', 'Mystery Gift', 'Day-Care / Nursery', 'Picnic basket'],
};
const GAME_REGION = { 1: 'Hoenn', 2: 'Hoenn', 3: 'Hoenn', 4: 'Kanto', 5: 'Kanto', 7: 'Johto', 8: 'Johto', 10: 'Sinnoh', 11: 'Sinnoh', 12: 'Sinnoh', 20: 'Unova', 21: 'Unova', 22: 'Unova', 23: 'Unova',
  24: 'Kalos', 25: 'Kalos', 26: 'Hoenn', 27: 'Hoenn', 30: 'Alola', 31: 'Alola', 32: 'Alola', 33: 'Alola', 34: 'Other', 35: 'Kanto', 36: 'Kanto', 37: 'Kanto', 38: 'Kanto',
  39: 'Johto', 40: 'Johto', 41: 'Johto', 42: 'Kanto', 43: 'Kanto', 44: 'Galar', 45: 'Galar', 47: 'Hisui', 48: 'Sinnoh', 49: 'Sinnoh', 50: 'Paldea', 51: 'Paldea' };
/** Places to suggest for a game (its region's, then the rest). */
export function placesFor(version) {
  const r = GAME_REGION[Number(version)];
  return [...(r ? REGION_PLACES[r] : []), ...REGION_PLACES.Other, ...Object.entries(REGION_PLACES).filter(([k]) => k !== r && k !== 'Other').flatMap(([, v]) => v)];
}
export const GAMES = Object.entries(GAME_NAMES).map(([v, n]) => [Number(v), n]);
// rough national-number ranges per region, for "which game were they from?" narrowing
const REGION_NO = { Kanto: [1, 151], Johto: [152, 251], Hoenn: [252, 386], Sinnoh: [387, 493], Unova: [494, 649], Kalos: [650, 721], Alola: [722, 809], Galar: [810, 898], Hisui: [899, 905], Paldea: [906, 1025] };

const sq = (s) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
const typeName = (idx, t) => String(idx.types?.get?.(t)?.name ?? t ?? '').toLowerCase();

/**
 * Who it could be, from what's been answered so far: { list (best first), total, exact }.
 * a: { species (a typed name), types: [names], region, shiny… }
 */
export function narrow(idx, a = {}) {
  let list = idx.ds.species.filter((s) => !s.battleOnly);
  const total = list.length;
  if (a.speciesId && idx.species.has(a.speciesId)) return { list: [idx.species.get(a.speciesId)], total, exact: true };
  const q = sq(a.species);
  if (q) {
    const starts = list.filter((s) => sq(s.name).startsWith(q)), has = list.filter((s) => !sq(s.name).startsWith(q) && sq(s.name).includes(q));
    list = [...starts, ...has];
  }
  for (const t of (a.types ?? []).filter(Boolean)) list = list.filter((s) => (s.types ?? []).some((x) => typeName(idx, x) === String(t).toLowerCase()));
  const reg = REGION_NO[a.region];
  if (reg) { const inReg = list.filter((s) => Number(s.no) >= reg[0] && Number(s.no) <= reg[1]); if (inReg.length) list = inReg; }
  return { list, total, exact: list.length === 1 };
}

/** The questions, in order: { id, group, ask, hint, kind, options… }. Every one has "No idea" / skip. */
export function memoryQuestions(idx) {
  const types = [...(idx.types?.values?.() ?? [])].map((t) => t.name);
  return [
    { id: 'pid', group: 'Who', ask: 'Do you happen to know their PID?', hint: 'The 8-character code PKHeX shows (like 1A2B3C4D). No sweat if not, almost nobody does: we’ll make one up.', kind: 'hex' },
    { id: 'species', group: 'Who', ask: 'What kind are they?', hint: 'Type a name, or narrow it down by type and region below.', kind: 'species', types, regions: Object.keys(REGION_NO) },
    { id: 'nickname', group: 'Who', ask: 'Did they have a nickname?', kind: 'text', placeholder: 'Leave empty if not' },
    { id: 'looks', group: 'Who', ask: 'Anything special about them?', kind: 'looks' }, // shiny, gender, form
    { id: 'met', group: 'How you met', ask: 'Do you remember how you met them?', kind: 'choice', options: MET_HOW },
    { id: 'game', group: 'How you met', ask: 'Which game was it?', kind: 'game', options: GAMES },
    { id: 'place', group: 'How you met', ask: 'Where was it?', hint: 'Pick a place from that game, or type your own.', kind: 'place' },
    { id: 'when', group: 'How you met', ask: 'When, roughly? And what level were they?', kind: 'when' },
    { id: 'ball', group: 'How you met', ask: 'Which ball did they come in?', kind: 'ball', options: BALLS },
    { id: 'ot', group: 'Their trainer', ask: 'Who was their original trainer?', hint: 'On the summary: OT name, ID No. (the 5 or 6 digits), and boy or girl. If they were yours from the start, that’s you.', kind: 'ot' },
    { id: 'nature', group: 'What they’re like', ask: 'Their nature and ability?', kind: 'nature', natures: NATURE_NAMES },
    { id: 'level', group: 'What they’re like', ask: 'What level are they now?', kind: 'number', min: 1, max: 100 },
    { id: 'moves', group: 'What they’re like', ask: 'Which moves do they know?', hint: 'Up to four. Start typing and pick.', kind: 'moves' },
    { id: 'stats', group: 'Stats', ask: 'How about their stats?', hint: 'The judge’s verdict per stat (IVs), and effort points (EVs) if you trained them. Skip any you don’t know.', kind: 'stats', judge: JUDGE },
    { id: 'item', group: 'Stats', ask: 'Were they holding anything?', kind: 'text', placeholder: 'e.g. Leftovers' },
    { id: 'extras', group: 'Little things', ask: 'Markings, Pokérus, Tera Type?', kind: 'extras', markings: MARKINGS, tera: TERA_TYPES },
    { id: 'ribbons', group: 'Little things', ask: 'Any ribbons or marks?', kind: 'ribbons', options: RIBBONS },
    { id: 'friendship', group: 'You two', ask: 'How close were you?', kind: 'choice', options: [['255', 'Inseparable'], ['200', 'Very close'], ['150', 'Good friends'], ['100', 'Getting there'], ['50', 'Not really']] },
    { id: 'memory', group: 'You two', ask: 'A memory with them you want to keep?', hint: 'Up to three. These become core memories here.', kind: 'memories' },
  ];
}

/**
 * The creature, from the answers: { creature, notes }.
 * a: { pid, speciesId, nickname, shiny, gender, met, game, place, when (text), metLevel, ball, otName, otId, otGender,
 *      nature, ability (slot 0/1/2), level, moves: [ids], ivs: {stat: n}, evs: {stat: n}, item, markings: [], pokerus, tera,
 *      ribbons: [], friendship, memories: [] }
 */
export function creatureFromMemory(idx, a = {}, { trainer = '', location, now = Date.now() } = {}) {
  const notes = [];
  const sp = idx.species.get(a.speciesId) ?? narrow(idx, a).list[0];
  if (!sp) throw new Error('Pick what kind they are first.');
  const R = idx.ds.rules;
  const level = Math.max(1, Math.min(R.maxLevel ?? 100, Math.round(Number(a.level) || Number(a.metLevel) || 5)));
  const scale = (v) => Math.round(((Number(v) || 0) * (R.maxGenes ?? 31)) / 31);
  const genes = Object.fromEntries(STAT_KEYS.filter((k) => a.ivs?.[k] != null && a.ivs[k] !== '').map((k) => [k, scale(a.ivs[k])]));
  const effort = Object.fromEntries(STAT_KEYS.map((k) => [k, Math.max(0, Math.min(R.maxEffortPerStat ?? 252, Math.round(Number(a.evs?.[k]) || 0)))]));
  const temps = idx.ds.temperaments ?? [];
  const temper = a.nature ? temps.find((t) => sq(t.name) === sq(a.nature) || sq(t.showdownName) === sq(a.nature)) : null;
  const abil = speciesAbilities(sp);
  const pidNum = /^[0-9a-f]{1,8}$/i.test(String(a.pid ?? '').trim()) ? parseInt(String(a.pid).trim(), 16) >>> 0 : null;
  const gameName = GAME_NAMES[Number(a.game)] ?? (a.gameText || '');
  const metHow = MET_HOW.find(([k]) => k === a.met)?.[1];
  const c = createCreature(idx, sp.id, {
    level, genes, effort, temper: temper?.id, ability: abil[Number(a.ability) || 0] ?? abil[0] ?? '',
    nickname: String(a.nickname ?? '').trim().slice(0, 12), trainer: a.otName || trainer, location, now,
    friendship: Number(a.friendship) || undefined,
    metHow: gameName ? `Remembered from ${gameName}` : 'Remembered', seed: pidNum ?? undefined,
  });
  // moves (the ones in your data set)
  const moves = (a.moves ?? []).map((id) => idx.moves.get(id)).filter(Boolean).slice(0, 4);
  if (moves.length) c.moves = moves.map((m) => ({ id: m.id, pp: m.pp ?? 10 }));
  c.shiny = !!a.shiny;
  if (a.gender) c.gender = a.gender;
  const yr = /\b(19|20)\d{2}\b/.exec(String(a.when ?? ''))?.[0];
  if (yr) c.metAt = new Date(Number(yr), 5, 1).getTime();
  c.metLevel = Math.max(1, Math.min(100, Number(a.metLevel) || level));
  if (a.ball) c.ball = String(a.ball);
  if (a.item) c.toldItem = String(a.item).trim();
  const ec = (Math.random() * 4294967296) >>> 0;
  c.pid = pidNum ?? ((Math.random() * 4294967296) >>> 0); c.ec = ec;
  const otId = Number(String(a.otId ?? '').replace(/\D/g, '')) || null;
  c.origin = { from: 'memory', game: gameName || 'a game', version: Number(a.game) || null, ot: a.otName || trainer, otId, ball: Number(a.ball) || null, ec, pid: c.pid, place: a.place || null };
  c.pk = {
    fromMemory: true, gen: null, pid: c.pid, ec, pidGiven: pidNum != null, trainerId: otId, otName: a.otName || trainer, otGender: a.otGender === 'female' ? 1 : 0,
    nature: a.nature || null, abilitySlot: Number(a.ability) || 0, ball: Number(a.ball) || 4, version: [44, 45, 47, 48, 49, 50, 51].includes(Number(a.game)) ? Number(a.game) : 50,
    metLevel: c.metLevel, metPlace: a.place || null, hatched: a.met === 'hatched', fateful: a.met === 'event',
    markList: (a.markings ?? []).filter(Boolean), pokerus: !!a.pokerus, teraType: a.tera != null && a.tera !== '' ? TERA_TYPES.indexOf(a.tera) : null,
    ribbons: (a.ribbons ?? []).filter(Boolean), ivs: { ...(a.ivs ?? {}) }, evs: { ...(a.evs ?? {}) }, heldItemName: a.item || null,
  };
  if (c.pk.teraType === -1) c.pk.teraType = null;
  if (a.ribbons?.length) c.ribbons = [...a.ribbons];
  // the story so far, as memories (oldest first)
  c.memories = [];
  const mem = (t, text, core = true) => { addMemory(c, text, t, { core }); const m = c.memories.at(-1); m.from = 'game'; m.told = true; };
  const who = a.otName || 'their trainer';
  const placeTxt = a.place ? ` at ${a.place}` : '';
  const gameTxt = gameName ? ` in ${gameName}` : '';
  const when = String(a.when ?? '').trim();
  const story = {
    caught: `Caught by ${who}${placeTxt}${gameTxt}${c.metLevel ? ` at level ${c.metLevel}` : ''}`,
    hatched: `Hatched from an egg${placeTxt}${gameTxt}`, starter: `Chose ${who} as their very first partner${gameTxt}`,
    gift: `Given to ${who}${placeTxt}${gameTxt}`, traded: `Came to ${who} in a trade${gameTxt}`, event: `Arrived through a special event${gameTxt}`,
    raid: `Joined ${who} after a raid${placeTxt}${gameTxt}`, other: `Met ${who}${placeTxt}${gameTxt}`,
  }[a.met] ?? (a.place || gameName ? `Met ${who}${placeTxt}${gameTxt}` : null);
  if (story) mem(c.metAt, `${story}${when ? `, ${when}` : ''}.`);
  const ball = BALLS.find(([n]) => n === Number(a.ball))?.[1];
  if (ball && a.met !== 'hatched') mem(c.metAt + 1, `Has always lived in a ${ball}.`, false);
  if (a.ribbons?.length) mem(c.metAt + 2, `Earned ${a.ribbons.length === 1 ? 'the ' + a.ribbons[0] : `${a.ribbons.length} ribbons, including the ${a.ribbons[0]}`}.`);
  if (c.shiny) mem(c.metAt + 3, 'Has always had an unusual colouring.', false);
  const told = (a.memories ?? []).map((x) => String(x ?? '').trim()).filter(Boolean).slice(0, 3);
  told.forEach((m, i) => mem(c.metAt + 10 + i, m.replace(/^./, (y) => y.toUpperCase()).replace(/([^.!?])$/, '$1.')));
  addMemory(c, `Remembered into Capsule Link${trainer ? ` by ${trainer}` : ''}.`, now);
  if (!moves.length) notes.push('No moves picked: they know their usual moves for their level.');
  if (a.item) notes.push(`Holding “${a.item}”: noted on their page (give them the real item from the bag if you have it).`);
  return { creature: c, notes };
}
