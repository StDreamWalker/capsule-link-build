// Save file model plus the event log that keeps the PC and phone in agreement.
// Both sides apply the same events with the same rules; the PC is the final authority.
import { applyCare, applyWalk, tickNeeds } from './care.js';
import { addMemory, evolve, replaceMove, touch, gainExp, restore } from './creature.js';
import { STAT_KEYS } from './dataset.js';
import { randomId } from './rng.js';

export const BIOMES = [
  { id: 'meadow', name: 'Meadow' },
  { id: 'forest', name: 'Forest' },
  { id: 'shoreline', name: 'Shoreline' },
  { id: 'volcano', name: 'Volcano' },
  { id: 'cavern', name: 'Cavern' },
  { id: 'tundra', name: 'Tundra' },
  { id: 'desert', name: 'Desert' },
  { id: 'skyline', name: 'Skyline' },
  { id: 'seafloor', name: 'Seafloor' },
  { id: 'marsh', name: 'Marsh' },
  { id: 'starfield', name: 'Starfield' },
  { id: 'crystal', name: 'Crystal cave' },
];

export function createSave(trainerName = 'Trainer', boxCount = 12) {
  return {
    version: 1,
    trainer: { name: trainerName, id: randomId(4) },
    creatures: {},
    boxes: Array.from({ length: boxCount }, (_, i) => ({ name: `Box ${i + 1}`, biome: BIOMES[i % BIOMES.length].id })),
    ranch: { biome: 'meadow', name: 'Ranch' },
    inventory: { sweetroot: 3, 'honey-drop': 1, 'bramble-berry': 2 },
    farm: { plots: [null, null, null, null, null, null] },
    capsules: {},
    devices: {},
    appliedEvents: [],
    stats: { battlesWon: 0, battlesLost: 0, totalSteps: 0 },
    settings: { petUid: null, petEnabled: false, sound: true, volume: 0.6 },
    createdAt: Date.now(),
  };
}

export const list = (save) => Object.values(save.creatures);
export const atKind = (save, kind) => list(save).filter((c) => c.location?.kind === kind);

export function party(save) {
  return atKind(save, 'party').sort((a, b) => (a.location.slot ?? 0) - (b.location.slot ?? 0));
}

export function boxContents(save, box, slots = 30) {
  const out = new Array(slots).fill(null);
  for (const c of atKind(save, 'box')) if (c.location.box === box && c.location.slot < slots) out[c.location.slot] = c;
  return out;
}

export function firstFreeBoxSlot(save, slots = 30, startBox = 0) {
  const n = save.boxes.length;
  for (let k = 0; k < n; k++) {
    const b = (startBox + k) % n;
    const used = new Set(atKind(save, 'box').filter((c) => c.location.box === b).map((c) => c.location.slot));
    for (let s = 0; s < slots; s++) if (!used.has(s)) return { kind: 'box', box: b, slot: s };
  }
  return null;
}

export function addCreature(save, c, location) {
  save.creatures[c.uid] = c;
  c.location = location ?? firstFreeBoxSlot(save) ?? { kind: 'ranch' };
  if (save.trainer?.name && !c.trainer) c.trainer = save.trainer.name;
  return c;
}

/** Move a creature; swaps with whoever sits in a target box/party slot. */
export function moveCreature(save, uid, to, partySize = 6) {
  const c = save.creatures[uid];
  if (!c) return { ok: false, error: 'Creature not found' };
  const from = c.location;
  if (to.kind === 'party') {
    const p = party(save).filter((x) => x.uid !== uid);
    if (to.slot == null) to = { kind: 'party', slot: p.length };
    if (from.kind !== 'party' && p.length >= partySize && !p.some((x) => x.location.slot === to.slot)) {
      return { ok: false, error: `Your party is full (${partySize}).` };
    }
  }
  const occupant = list(save).find((x) => x.uid !== uid && sameSlot(x.location, to));
  if (occupant) occupant.location = { ...from };
  c.location = { ...to };
  if (to.kind === 'party' || from.kind === 'party') compactParty(save);
  touch(c);
  return { ok: true, swapped: occupant?.uid ?? null };
}

function sameSlot(a, b) {
  if (!a || !b || a.kind !== b.kind) return false;
  if (a.kind === 'box') return a.box === b.box && a.slot === b.slot;
  if (a.kind === 'party') return a.slot === b.slot;
  return false;
}

export function compactParty(save) {
  party(save).forEach((c, i) => { c.location.slot = i; });
}

export function releaseCreature(save, uid) {
  delete save.creatures[uid];
  if (save.settings.petUid === uid) save.settings.petUid = null;
}

/** Mark an event applied; returns false if it was seen before. */
function claimEvent(save, id) {
  if (!id) return true;
  save.appliedEvents = save.appliedEvents || [];
  if (save.appliedEvents.includes(id)) return false;
  save.appliedEvents.push(id);
  if (save.appliedEvents.length > 3000) save.appliedEvents.splice(0, save.appliedEvents.length - 3000);
  return true;
}

export function makeEvent(type, data) {
  return { id: `${type}-${Date.now().toString(36)}-${randomId(4)}`, type, at: Date.now(), ...data };
}

/**
 * Apply one event. Events:
 *  walk   { uid, steps, source }
 *  care   { uid, action, item }
 *  battle { results: [{uid, exp, effort, friendship, won}], won, opponent, linked }
 *  evolve { uid, to }       learn { uid, slot, move }      rename { uid, nickname }
 *  locate { uid, location } capsule { tag, uid|null, mode, name }
 */
export function applyEvent(idx, save, ev) {
  if (!claimEvent(save, ev.id)) return { ok: true, duplicate: true };
  const t = ev.at ?? Date.now();
  const c = ev.uid ? save.creatures[ev.uid] : null;
  if (ev.uid && !c && ev.type !== 'locate' && ev.type !== 'snapshot') return { ok: false, error: `Creature ${ev.uid} is not in this save.` };
  switch (ev.type) {
    case 'walk': {
      const out = applyWalk(idx, c, ev.steps, { at: t, seed: ev.id });
      save.stats.totalSteps = (save.stats.totalSteps ?? 0) + out.steps;
      for (const f of out.finds) save.inventory[f] = (save.inventory[f] ?? 0) + 1;
      return { ok: true, outcome: out };
    }
    case 'memory': {
      // something worth remembering that happened away from the PC (a first walk by the sea…)
      if (ev.text) addMemory(c, String(ev.text).slice(0, 160), t);
      if (ev.seen) c.seen = { ...(c.seen || {}), ...ev.seen };
      touch(c, t);
      return { ok: true };
    }
    case 'care': {
      const out = applyCare(idx, c, ev.action, { item: ev.item, inventory: save.inventory, at: t });
      return { ok: out.ok !== false, outcome: out };
    }
    case 'battle': {
      const outcomes = [];
      for (const r of ev.results || []) {
        const x = save.creatures[r.uid];
        if (!x) continue;
        const events = gainExp(idx, x, r.exp || 0, t);
        for (const k of STAT_KEYS) {
          const add = r.effort?.[k] ?? 0;
          if (!add) continue;
          const total = STAT_KEYS.reduce((s, kk) => s + (x.effort[kk] ?? 0), 0);
          const room = Math.max(0, Math.min(idx.ds.rules.maxEffortPerStat - (x.effort[k] ?? 0), idx.ds.rules.maxEffortTotal - total));
          x.effort[k] = (x.effort[k] ?? 0) + Math.min(add, room);
        }
        x.friendship = Math.max(0, Math.min(idx.ds.rules.maxFriendship, x.friendship + (r.friendship ?? 0)));
        if (r.won && ev.linked) addMemory(x, `Won a link battle against ${ev.opponent ?? 'a friend'}.`, t);
        else if (r.won && !x.memories.some((m) => m.text.startsWith('Won a first battle'))) addMemory(x, 'Won a first battle.', t);
        restore(idx, x);
        touch(x, t);
        outcomes.push({ uid: x.uid, events });
      }
      if (ev.won) save.stats.battlesWon++; else save.stats.battlesLost++;
      return { ok: true, outcome: outcomes };
    }
    case 'evolve': {
      const out = evolve(idx, c, ev.to, t);
      return { ok: !!out, outcome: out };
    }
    case 'learn': {
      replaceMove(idx, c, ev.slot, ev.move);
      touch(c, t);
      return { ok: true };
    }
    case 'rename': {
      c.nickname = String(ev.nickname ?? '').slice(0, 12);
      touch(c, t);
      return { ok: true };
    }
    case 'locate': {
      if (!c) {
        if (ev.creature) { save.creatures[ev.uid] = ev.creature; ev.creature.location = ev.location; return { ok: true }; }
        return { ok: false, error: 'Unknown creature' };
      }
      c.location = ev.location;
      touch(c, t);
      return { ok: true };
    }
    case 'snapshot': {
      // a creature that lives in a capsule: newest copy wins
      const incoming = ev.creature;
      if (!incoming?.uid || !idx.species.has(incoming.speciesId)) return { ok: false, error: 'Bad snapshot' };
      const cur = save.creatures[incoming.uid];
      if (!cur || (incoming.updatedAt ?? 0) > (cur.updatedAt ?? 0)) {
        save.creatures[incoming.uid] = { ...cur, ...incoming, memories: incoming.memories ?? cur?.memories ?? [] };
        return { ok: true, adopted: true };
      }
      return { ok: true, adopted: false };
    }
    case 'items': {
      for (const [k, v] of Object.entries(ev.delta ?? {})) save.inventory[k] = Math.max(0, (save.inventory[k] ?? 0) + v);
      if (ev.steps) save.stats.totalSteps = (save.stats.totalSteps ?? 0) + ev.steps;
      return { ok: true };
    }
    case 'capsule': {
      const cap = save.capsules[ev.tag] || (save.capsules[ev.tag] = { name: ev.name ?? `Capsule ${Object.keys(save.capsules).length + 1}` });
      if (ev.name) cap.name = ev.name;
      if ('uid' in ev) cap.uid = ev.uid;
      if (ev.mode) cap.mode = ev.mode;
      if ('skin' in ev) cap.skin = ev.skin || '';
      cap.lastSeen = t;
      if (ev.uid && save.creatures[ev.uid]) save.creatures[ev.uid].location = { kind: 'capsule', tag: ev.tag };
      return { ok: true };
    }
    default:
      return { ok: false, error: `Unknown event type ${ev.type}` };
  }
}

/** Bring every creature's needs up to date (call on load and every few minutes). */
export function tickAll(idx, save, t = Date.now()) {
  for (const c of list(save)) tickNeeds(idx, c, t);
}

export function capsuleName(save, tag) {
  return save.capsules?.[tag]?.name ?? `Capsule ${String(tag).slice(-4)}`;
}

/**
 * Turn the difference between two copies of a save into a replayable change.
 * Used when slow work (writing an NFC tag) was done on a copy: the returned function copies the
 * changed creatures and capsules over and applies inventory/step deltas, so it can be re-run safely
 * on a newer save.
 */
export function diffMutator(before, after) {
  const changed = [], removed = [], caps = [];
  for (const [uid, c] of Object.entries(after.creatures)) {
    if (JSON.stringify(c) !== JSON.stringify(before.creatures[uid])) changed.push(uid);
  }
  for (const uid of Object.keys(before.creatures)) if (!after.creatures[uid]) removed.push(uid);
  for (const [tag, cap] of Object.entries(after.capsules ?? {})) {
    if (JSON.stringify(cap) !== JSON.stringify(before.capsules?.[tag])) caps.push(tag);
  }
  const inv = {};
  for (const k of new Set([...Object.keys(after.inventory ?? {}), ...Object.keys(before.inventory ?? {})])) {
    const d = (after.inventory?.[k] ?? 0) - (before.inventory?.[k] ?? 0);
    if (d) inv[k] = d;
  }
  const steps = (after.stats?.totalSteps ?? 0) - (before.stats?.totalSteps ?? 0);
  const clone = (x) => JSON.parse(JSON.stringify(x));
  return (save) => {
    for (const uid of changed) save.creatures[uid] = clone(after.creatures[uid]);
    for (const uid of removed) delete save.creatures[uid];
    save.capsules = save.capsules || {};
    for (const tag of caps) save.capsules[tag] = clone(after.capsules[tag]);
    for (const [k, d] of Object.entries(inv)) save.inventory[k] = Math.max(0, (save.inventory[k] ?? 0) + d);
    if (steps) save.stats.totalSteps = (save.stats.totalSteps ?? 0) + steps;
  };
}
