/*
  Capsule Link — capsule firmware
  ===============================
  Runs inside the ball. The creature's data lives in an NTAG I2C plus tag (NT3H2111/NT3H2211):
  phones and the dock read/write it over NFC, and this microcontroller reads/writes the same
  memory over I2C. The capsule itself never changes the creature (MAIN record); it only keeps
  the WALK record up to date: steps, bumps, cries, wiggles, battery.

  Modes (byte 4 of MAIN, set from the PC or phone):
    desk   — plays its cry and wiggles every few minutes, says hello when picked up
    walk   — counts steps, celebrates every 1,000
    battle — a sharp tap against another capsule records a bump and sends a Bluetooth beacon
             so both phones can start a battle
    sleep  — quiet

  Hardware (see docs/hardware.md):
    - ESP32-C3 board (Seeed XIAO ESP32-C3 or C3 SuperMini) — Bluetooth LE + I2C
    - NTAG I2C plus breakout: SDA/SCL shared with the IMU, FD pin to FD_PIN (pull-up)
    - IMU: MPU-6050 (0x68) or LSM6DS3/LSM6DSO (0x6A/0x6B), detected automatically
    - Passive piezo buzzer on BUZZER_PIN, small vibration motor via a transistor on MOTOR_PIN
    - LiPo with charger; battery voltage through a 1:1 divider on BATT_PIN
    - Optional: WS2812 LED on LED_PIN for the light ring

  Libraries: ESP32 Arduino core (BLE is built in). Adafruit NeoPixel if USE_LED is 1.
*/
#include <Wire.h>
#include <BLEDevice.h>
#include <BLEAdvertising.h>

// ---------------- pins & tuning ----------------
#define FW_VERSION    1
#define SDA_PIN       6
#define SCL_PIN       7
#define FD_PIN        3      // NTAG field detect: LOW while a phone/dock is reading
#define BUZZER_PIN    4
#define MOTOR_PIN     5
#define BATT_PIN      2      // ADC, battery through a 100k/100k divider
#define USE_LED       1
#define LED_PIN       10

#define NTAG_ADDR     0x55
#define MAIN_BLOCK    3      // I2C block of the MAIN record (user byte 32)
#define WALK_BLOCK    11     // I2C block of the WALK record (user byte 160)
#define FLUSH_STEPS   100    // write walk data at least every N steps…
#define FLUSH_MS      600000 // …or every 10 minutes
#define SAMPLE_MS     20     // 50 Hz motion sampling

#if USE_LED
#include <Adafruit_NeoPixel.h>
Adafruit_NeoPixel led(1, LED_PIN, NEO_GRB + NEO_KHZ800);
#endif

enum Mode : uint8_t { DESK = 0, WALK = 1, BATTLE = 2, SLEEP = 3 };

// ---------------- records (layout in docs/protocol.md) ----------------
struct Main {
  bool valid = false, occupied = false;
  Mode mode = DESK;
  uint8_t cryCount = 0;
  uint8_t cry[24];
  uint8_t r = 52, g = 209, b = 191;
} mainRec;

struct Walk {
  uint16_t syncId = 0;
  uint32_t steps = 0;
  uint16_t bumpCount = 0;
  uint32_t lastBumpPeer = 0;
  uint32_t lastBumpAt = 0;
  uint16_t cries = 0, wiggles = 0, pickups = 0;
  uint8_t battery = 255;
} walk;

uint8_t tagUid[7];
uint32_t unflushed = 0;

void onTap(float strength);
void onStep();
void cry();
void wiggle();
void advertiseBump(uint32_t ms);
void setLed(uint8_t r, uint8_t g, uint8_t b);     // steps counted since the last write
uint32_t lastFlush = 0;
bool fieldWasOn = false;

// ---------------- CRC-16/CCITT-FALSE (same as the apps) ----------------
uint16_t crc16(const uint8_t* d, size_t n) {
  uint16_t crc = 0xFFFF;
  for (size_t i = 0; i < n; i++) {
    crc ^= (uint16_t)d[i] << 8;
    for (int b = 0; b < 8; b++) crc = (crc & 0x8000) ? (crc << 1) ^ 0x1021 : crc << 1;
  }
  return crc;
}

// ---------------- NTAG I2C plus ----------------
bool fieldOn() { return digitalRead(FD_PIN) == LOW; }

bool ntagRead(uint8_t block, uint8_t* out16) {
  for (int attempt = 0; attempt < 3; attempt++) {
    Wire.beginTransmission(NTAG_ADDR);
    Wire.write(block);
    if (Wire.endTransmission() == 0 && Wire.requestFrom((uint8_t)NTAG_ADDR, (uint8_t)16) == 16) {
      for (int i = 0; i < 16; i++) out16[i] = Wire.read();
      return true;
    }
    delay(5);
  }
  return false;
}

bool ntagWrite(uint8_t block, const uint8_t* in16) {
  if (block == 0) return false;          // block 0 holds the I2C address: never write it
  if (fieldOn()) return false;           // a phone or the dock owns the memory right now
  Wire.beginTransmission(NTAG_ADDR);
  Wire.write(block);
  Wire.write(in16, 16);
  bool ok = Wire.endTransmission() == 0;
  delay(6);                              // EEPROM write time
  return ok;
}

void loadMain() {
  uint8_t buf[128];
  for (int i = 0; i < 8; i++) if (!ntagRead(MAIN_BLOCK + i, buf + i * 16)) { mainRec.valid = false; return; }
  uint16_t crc = (buf[126] << 8) | buf[127];
  mainRec.valid = buf[0] == 'C' && buf[1] == 'L' && crc == crc16(buf, 126);
  if (!mainRec.valid) return;
  mainRec.occupied = buf[3] & 1;
  mainRec.mode = (Mode)(buf[4] & 3);
  mainRec.cryCount = buf[88] < 12 ? buf[88] : 12;
  memcpy(mainRec.cry, buf + 89, 24);
  mainRec.r = buf[113]; mainRec.g = buf[114]; mainRec.b = buf[115];
}

void loadWalk() {
  uint8_t buf[32];
  if (!ntagRead(WALK_BLOCK, buf) || !ntagRead(WALK_BLOCK + 1, buf + 16)) return;
  if (buf[0] != 'W' || buf[1] != 'K') return;
  if (((buf[30] << 8) | buf[31]) != crc16(buf, 30)) return;
  walk.syncId = (buf[2] << 8) | buf[3];
  walk.steps = ((uint32_t)buf[4] << 24) | ((uint32_t)buf[5] << 16) | (buf[6] << 8) | buf[7];
  walk.bumpCount = (buf[8] << 8) | buf[9];
  walk.lastBumpPeer = ((uint32_t)buf[10] << 24) | ((uint32_t)buf[11] << 16) | (buf[12] << 8) | buf[13];
  walk.lastBumpAt = ((uint32_t)buf[14] << 24) | ((uint32_t)buf[15] << 16) | (buf[16] << 8) | buf[17];
  walk.cries = (buf[18] << 8) | buf[19];
  walk.wiggles = (buf[20] << 8) | buf[21];
  walk.pickups = (buf[22] << 8) | buf[23];
}

void put16(uint8_t* p, uint16_t v) { p[0] = v >> 8; p[1] = v; }
void put32(uint8_t* p, uint32_t v) { p[0] = v >> 24; p[1] = v >> 16; p[2] = v >> 8; p[3] = v; }

bool flushWalk() {
  uint8_t buf[32] = {0};
  buf[0] = 'W'; buf[1] = 'K';
  put16(buf + 2, walk.syncId);
  put32(buf + 4, walk.steps + unflushed);
  put16(buf + 8, walk.bumpCount);
  put32(buf + 10, walk.lastBumpPeer);
  put32(buf + 14, walk.lastBumpAt);
  put16(buf + 18, walk.cries);
  put16(buf + 20, walk.wiggles);
  put16(buf + 22, walk.pickups);
  buf[24] = walk.battery;
  buf[25] = FW_VERSION;
  put16(buf + 30, crc16(buf, 30));
  if (!ntagWrite(WALK_BLOCK, buf) || !ntagWrite(WALK_BLOCK + 1, buf + 16)) return false;
  walk.steps += unflushed;
  unflushed = 0;
  lastFlush = millis();
  return true;
}

// After a phone/dock session the PC or phone may have reset the walk counter or changed the mode.
void afterField() {
  loadMain();
  uint32_t keep = unflushed;
  loadWalk();
  unflushed = keep;
}

// ---------------- motion ----------------
uint8_t imuAddr = 0;
bool isLsm = false;

void imuWrite(uint8_t reg, uint8_t v) { Wire.beginTransmission(imuAddr); Wire.write(reg); Wire.write(v); Wire.endTransmission(); }
uint8_t imuRead8(uint8_t reg) { Wire.beginTransmission(imuAddr); Wire.write(reg); Wire.endTransmission(false); Wire.requestFrom(imuAddr, (uint8_t)1); return Wire.available() ? Wire.read() : 0; }

bool imuBegin() {
  for (uint8_t a : { (uint8_t)0x6A, (uint8_t)0x6B }) {
    imuAddr = a;
    uint8_t who = imuRead8(0x0F);
    if (who == 0x69 || who == 0x6A || who == 0x6C) { isLsm = true; imuWrite(0x10, 0x4C); return true; } // 104 Hz, ±8 g
  }
  imuAddr = 0x68;
  uint8_t who = imuRead8(0x75);
  if (who == 0x68 || who == 0x70 || who == 0x98) { isLsm = false; imuWrite(0x6B, 0x00); imuWrite(0x1C, 0x10); return true; } // wake, ±8 g
  return false;
}

/** Acceleration magnitude in g. */
float imuMagnitude() {
  uint8_t reg = isLsm ? 0x28 : 0x3B;
  Wire.beginTransmission(imuAddr); Wire.write(reg); Wire.endTransmission(false);
  Wire.requestFrom(imuAddr, (uint8_t)6);
  int16_t v[3];
  for (int i = 0; i < 3; i++) {
    uint8_t a = Wire.read(), b = Wire.read();
    v[i] = isLsm ? (int16_t)(a | (b << 8)) : (int16_t)((a << 8) | b);
  }
  const float scale = isLsm ? 0.000244f : 1.0f / 4096.0f; // ±8 g
  float x = v[0] * scale, y = v[1] * scale, z = v[2] * scale;
  return sqrtf(x * x + y * y + z * z);
}

// step detector: smoothed magnitude crossing a moving threshold, 0.25–2 s apart
float lp = 1.0f, avg = 1.0f;
bool above = false;
uint32_t lastStep = 0, lastTap = 0, stillSince = 0, lastActive = 0;

void processMotion() {
  float m = imuMagnitude();
  lp += (m - lp) * 0.25f;
  avg += (m - avg) * 0.02f;
  uint32_t now = millis();
  // tap: a sharp spike well above the smoothed signal
  if (m - lp > 1.6f && now - lastTap > 700) { lastTap = now; onTap(m); }
  // steps
  if (!above && lp > avg + 0.12f) {
    above = true;
    uint32_t dt = now - lastStep;
    if (dt > 250 && dt < 2000 && mainRec.mode == WALK) onStep();
    lastStep = now;
  } else if (above && lp < avg) above = false;
  // picked up after resting (desk mode greeting)
  bool moving = fabsf(m - 1.0f) > 0.08f;
  if (moving) {
    if (now - lastActive > 120000 && mainRec.mode == DESK && mainRec.occupied) { walk.pickups++; cry(); }
    lastActive = now;
  }
}

// ---------------- reactions ----------------
void setLed(uint8_t r, uint8_t g, uint8_t b) {
#if USE_LED
  led.setPixelColor(0, led.Color(r, g, b));
  led.show();
#endif
}

void cry() {
  if (!mainRec.occupied || mainRec.mode == SLEEP) return;
  setLed(mainRec.r, mainRec.g, mainRec.b);
  for (int i = 0; i < mainRec.cryCount; i++) {
    uint8_t midi = mainRec.cry[i * 2], ticks = mainRec.cry[i * 2 + 1];
    uint32_t ms = ticks * 40;
    if (midi) tone(BUZZER_PIN, (unsigned int)(440.0f * powf(2.0f, (midi - 69) / 12.0f)), ms);
    delay(ms);
  }
  noTone(BUZZER_PIN);
  setLed(0, 0, 0);
  walk.cries++;
}

void wiggle() {
  if (!mainRec.occupied || mainRec.mode == SLEEP) return;
  const uint16_t pattern[] = { 90, 70, 90, 140, 60 };
  for (int i = 0; i < 5; i++) { digitalWrite(MOTOR_PIN, i % 2 == 0); delay(pattern[i]); }
  digitalWrite(MOTOR_PIN, LOW);
  walk.wiggles++;
}

void onStep() {
  unflushed++;
  uint32_t total = walk.steps + unflushed;
  if (total % 1000 == 0) { wiggle(); cry(); }
  if (unflushed >= FLUSH_STEPS) flushWalk();
}

void onTap(float strength) {
  if (mainRec.mode != BATTLE || !mainRec.occupied) return;
  walk.bumpCount++;
  walk.lastBumpAt = millis() / 1000;
  setLed(255, 201, 60);
  tone(BUZZER_PIN, 1319, 80); delay(90); tone(BUZZER_PIN, 1760, 120); delay(130); noTone(BUZZER_PIN);
  advertiseBump(8000);
  flushWalk();
  setLed(0, 0, 0);
}

// ---------------- Bluetooth beacon ----------------
// Manufacturer data: FF FF 'C' 'L' version uid4[4] bumps(u16 LE) mode battery
void advertiseBump(uint32_t ms) {
  uint8_t d[13] = { 0xFF, 0xFF, 'C', 'L', 1, tagUid[3], tagUid[4], tagUid[5], tagUid[6],
                    (uint8_t)(walk.bumpCount & 0xFF), (uint8_t)(walk.bumpCount >> 8), (uint8_t)mainRec.mode, walk.battery };
  BLEAdvertisementData data;
  data.setFlags(0x06);
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  String payload;
  for (uint8_t b : d) payload += (char)b;
#else
  std::string payload((const char*)d, sizeof d);
#endif
  data.setManufacturerData(payload);
  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->setAdvertisementData(data);
  adv->setMinInterval(0x20);
  adv->setMaxInterval(0x40);
  adv->start();
  uint32_t until = millis() + ms;
  while (millis() < until) { delay(SAMPLE_MS); }
  adv->stop();
}

// ---------------- battery ----------------
void readBattery() {
  uint32_t mv = analogReadMilliVolts(BATT_PIN) * 2;
  int pct = (int)((mv - 3300) * 100 / (4200 - 3300));
  walk.battery = (uint8_t)constrain(pct, 0, 100);
}

// ---------------- main ----------------
uint32_t nextIdle = 0;

void setup() {
  pinMode(FD_PIN, INPUT_PULLUP);
  pinMode(MOTOR_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  Wire.begin(SDA_PIN, SCL_PIN);
  Wire.setClock(400000);
#if USE_LED
  led.begin();
  led.setBrightness(80);
#endif
  uint8_t b0[16];
  if (ntagRead(0, b0)) memcpy(tagUid, b0, 7);   // block 0 bytes 0–6 = the tag's NFC UID
  loadMain();
  loadWalk();
  imuBegin();
  readBattery();
  BLEDevice::init("Capsule");
  randomSeed(esp_random());
  nextIdle = millis() + random(180000, 720000);
  if (mainRec.occupied) cry();
}

void loop() {
  static uint32_t lastSample = 0;
  bool field = fieldOn();
  if (field && !fieldWasOn) { setLed(52, 209, 191); }
  if (!field && fieldWasOn) { delay(50); afterField(); setLed(0, 0, 0); }
  fieldWasOn = field;

  if (millis() - lastSample >= SAMPLE_MS) {
    lastSample = millis();
    if (imuAddr) processMotion();
  }
  // desk mode: every few minutes, cry or wiggle
  if (mainRec.mode == DESK && millis() > nextIdle) {
    if (random(2)) cry(); else wiggle();
    nextIdle = millis() + random(180000, 720000);
  }
  if (unflushed && millis() - lastFlush > FLUSH_MS) { readBattery(); flushWalk(); }
}
