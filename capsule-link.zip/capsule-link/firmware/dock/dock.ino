/*
  Capsule Link — dock firmware
  ============================
  The receptacle a capsule sits in. A PN532 NFC reader under the cradle reads/writes the
  capsule's tag; the PC app does all the thinking over USB serial.

  Hardware (see docs/hardware.md):
    - Any board with native USB serial: ESP32-S3, ESP32-C3, RP2040 (Pico), Arduino Leonardo...
    - PN532 module in I2C mode (DIP switches I0=1, I1=0), SDA/SCL to the board's I2C pins
    - Optional: WS2812 ring (LED_PIN), passive buzzer (BUZZER_PIN)

  Libraries (Arduino Library Manager):
    - Adafruit PN532
    - ArduinoJson (v7)
    - Adafruit NeoPixel (only if USE_LEDS is 1)

  Protocol: one JSON object per line at 115200 baud.
    PC -> dock  {"id":1,"cmd":"info"}
                {"id":2,"cmd":"read","page":4,"count":16}        -> {"id":2,"ok":true,"hex":"..."}
                {"id":3,"cmd":"write","page":12,"hex":"..."}      -> {"id":3,"ok":true}
                {"id":4,"cmd":"led","mode":"solid|pulse|off","rgb":"55ccff"}
                {"id":5,"cmd":"tone","notes":[[76,2],[79,2]]}     (MIDI note, ticks of 40 ms)
    dock -> PC  {"ev":"hello","fw":"dock-1.0","reader":"PN532 1.6"}
                {"ev":"tag","uid":"04A1B2C3D4E5F6","size":496}
                {"ev":"removed","uid":"04A1B2C3D4E5F6"}
*/
#include <Wire.h>
#include <Adafruit_PN532.h>
#include <ArduinoJson.h>

// ---------------- configuration ----------------
#define FW_VERSION   "dock-1.0"
#define PN532_IRQ    -1     // -1 = not wired (polling)
#define PN532_RESET  -1     // -1 = not wired
#define USE_LEDS     1
#define LED_PIN      8
#define LED_COUNT    12
#define BUZZER_PIN   9      // -1 to disable
#define POLL_MS      200    // how often to look for a capsule
#define MISSES_TO_REMOVE 3  // polls without the tag before "removed"

#if USE_LEDS
#include <Adafruit_NeoPixel.h>
Adafruit_NeoPixel ring(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);
#endif

Adafruit_PN532 nfc(PN532_IRQ, PN532_RESET, &Wire);

uint8_t  tagUid[7];
uint8_t  tagUidLen = 0;
bool     tagPresent = false;
uint8_t  misses = 0;
uint32_t lastPoll = 0;
String   lineBuf;

// LED state
uint8_t  ledR = 52, ledG = 209, ledB = 191;
char     ledMode = 'p'; // s solid, p pulse, o off

// ---------------- helpers ----------------
static const char HEXCH[] = "0123456789ABCDEF";

String toHex(const uint8_t* b, size_t n) {
  String s;
  s.reserve(n * 2);
  for (size_t i = 0; i < n; i++) { s += HEXCH[b[i] >> 4]; s += HEXCH[b[i] & 15]; }
  return s;
}

int hexVal(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

size_t fromHex(const char* s, uint8_t* out, size_t max) {
  size_t n = 0;
  while (s[0] && s[1] && n < max) {
    int a = hexVal(s[0]), b = hexVal(s[1]);
    if (a < 0 || b < 0) break;
    out[n++] = (a << 4) | b;
    s += 2;
  }
  return n;
}

void sendEvent(JsonDocument& doc) {
  serializeJson(doc, Serial);
  Serial.print('\n');
}

void reply(long id, bool ok, const char* error = nullptr) {
  JsonDocument doc;
  doc["id"] = id;
  doc["ok"] = ok;
  if (error) doc["error"] = error;
  sendEvent(doc);
}

// ---------------- LEDs and sound ----------------
void showLeds() {
#if USE_LEDS
  float k = 1.0;
  if (ledMode == 'o') k = 0;
  else if (ledMode == 'p') k = 0.25 + 0.75 * (0.5 + 0.5 * sin(millis() / 400.0));
  for (int i = 0; i < LED_COUNT; i++) ring.setPixelColor(i, ring.Color(ledR * k, ledG * k, ledB * k));
  ring.show();
#endif
}

void playNotes(JsonArray notes) {
#if BUZZER_PIN >= 0
  for (JsonVariant v : notes) {
    JsonArray n = v.as<JsonArray>();
    int midi = n[0] | 0, ticks = n[1] | 2;
    uint32_t ms = ticks * 40;
    if (midi > 0) tone(BUZZER_PIN, (unsigned int)(440.0 * pow(2.0, (midi - 69) / 12.0)), ms);
    delay(ms);
  }
  noTone(BUZZER_PIN);
#endif
}

// ---------------- NFC ----------------
bool selectTag(uint8_t* uid, uint8_t* len) {
  return nfc.readPassiveTargetID(PN532_MIFARE_ISO14443A, uid, len, 60);
}

/** Read `count` 4-byte pages starting at `page` into out. */
bool readPages(uint8_t page, uint8_t count, uint8_t* out) {
  uint8_t buf[16];
  for (uint8_t i = 0; i < count; i++) {
    if (!nfc.ntag2xx_ReadPage(page + i, buf)) {
      // the tag may have been deselected by polling; select and retry once
      uint8_t u[7], l;
      if (!selectTag(u, &l) || !nfc.ntag2xx_ReadPage(page + i, buf)) return false;
    }
    memcpy(out + i * 4, buf, 4);
  }
  return true;
}

bool writePages(uint8_t page, const uint8_t* data, size_t len) {
  uint8_t buf[4];
  for (size_t i = 0; i < len / 4; i++) {
    memcpy(buf, data + i * 4, 4);
    if (!nfc.ntag2xx_WritePage(page + i, buf)) {
      uint8_t u[7], l;
      if (!selectTag(u, &l) || !nfc.ntag2xx_WritePage(page + i, buf)) return false;
    }
  }
  return true;
}

void pollTag() {
  uint8_t uid[7], len = 0;
  bool found = selectTag(uid, &len);
  if (found) {
    misses = 0;
    bool same = tagPresent && len == tagUidLen && memcmp(uid, tagUid, len) == 0;
    if (!same) {
      memcpy(tagUid, uid, len);
      tagUidLen = len;
      tagPresent = true;
      uint8_t cc[4] = {0};
      readPages(3, 1, cc);
      JsonDocument doc;
      doc["ev"] = "tag";
      doc["uid"] = toHex(tagUid, tagUidLen);
      doc["size"] = cc[2] * 8;
      sendEvent(doc);
      ledMode = 's';
    }
  } else if (tagPresent && ++misses >= MISSES_TO_REMOVE) {
    JsonDocument doc;
    doc["ev"] = "removed";
    doc["uid"] = toHex(tagUid, tagUidLen);
    sendEvent(doc);
    tagPresent = false;
    tagUidLen = 0;
    ledMode = 'p'; ledR = 52; ledG = 209; ledB = 191;
  }
}

// ---------------- commands ----------------
void handleLine(const String& line) {
  JsonDocument doc;
  if (deserializeJson(doc, line)) return;
  long id = doc["id"] | 0;
  const char* cmd = doc["cmd"] | "";

  if (!strcmp(cmd, "info")) {
    uint32_t ver = nfc.getFirmwareVersion();
    JsonDocument out;
    out["id"] = id;
    out["ok"] = true;
    out["fw"] = FW_VERSION;
    char reader[24];
    snprintf(reader, sizeof reader, "PN5%02X %d.%d", (unsigned)((ver >> 24) & 0xFF), (int)((ver >> 16) & 0xFF), (int)((ver >> 8) & 0xFF));
    out["reader"] = ver ? reader : "none";
    if (tagPresent) out["tag"] = toHex(tagUid, tagUidLen);
    sendEvent(out);
    return;
  }
  if (!strcmp(cmd, "read")) {
    if (!tagPresent) return reply(id, false, "No capsule on the dock");
    uint8_t page = doc["page"] | 4, count = doc["count"] | 4;
    if (count > 32) count = 32;
    uint8_t buf[128];
    if (!readPages(page, count, buf)) return reply(id, false, "Read failed");
    JsonDocument out;
    out["id"] = id;
    out["ok"] = true;
    out["hex"] = toHex(buf, count * 4);
    sendEvent(out);
    return;
  }
  if (!strcmp(cmd, "write")) {
    if (!tagPresent) return reply(id, false, "No capsule on the dock");
    uint8_t page = doc["page"] | 0;
    if (page < 4) return reply(id, false, "Pages below 4 are protected");
    const char* hex = doc["hex"] | "";
    uint8_t buf[128];
    size_t n = fromHex(hex, buf, sizeof buf);
    if (n == 0 || n % 4) return reply(id, false, "Data must be whole pages");
    if (!writePages(page, buf, n)) return reply(id, false, "Write failed");
    return reply(id, true);
  }
  if (!strcmp(cmd, "led")) {
    const char* mode = doc["mode"] | "solid";
    const char* rgb = doc["rgb"] | "";
    ledMode = mode[0] == 'o' ? 'o' : mode[0] == 'p' ? 'p' : 's';
    if (strlen(rgb) == 6) {
      uint8_t c[3];
      fromHex(rgb, c, 3);
      ledR = c[0]; ledG = c[1]; ledB = c[2];
    }
    return reply(id, true);
  }
  if (!strcmp(cmd, "tone")) {
    reply(id, true);
    playNotes(doc["notes"].as<JsonArray>());
    return;
  }
  reply(id, false, "Unknown command");
}

// ---------------- main ----------------
void setup() {
  Serial.begin(115200);
  Wire.begin();
#if USE_LEDS
  ring.begin();
  ring.setBrightness(60);
#endif
  nfc.begin();
  uint32_t ver = nfc.getFirmwareVersion();
  if (ver) nfc.SAMConfig();
  JsonDocument doc;
  doc["ev"] = "hello";
  doc["fw"] = FW_VERSION;
  doc["reader"] = ver ? "PN532" : "missing";
  sendEvent(doc);
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') { if (lineBuf.length()) handleLine(lineBuf); lineBuf = ""; }
    else if (c != '\r' && lineBuf.length() < 1024) lineBuf += c;
  }
  if (millis() - lastPoll >= POLL_MS) {
    lastPoll = millis();
    pollTag();
  }
  showLeds();
}
