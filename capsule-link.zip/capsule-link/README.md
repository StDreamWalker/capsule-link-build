# Capsule Link

A personal walking-buddy system in three parts:

**The idea.** Creatures can't step into our world, so the closest thing is carrying their data
with you. They live on your PC. Away from it they ride in a capsule you carry, and your phone is
how you check on them — they never come out of the capsule until they are home.

- **PC app** — boots to a black screen and one old-school text box asking *whose PC are you using?*, then connects to "the network" that keeps your creatures. Each
  trainer has their own profile and a **trainer ID card** (eight card designs, a pixel portrait you
  build yourself). Once logged on: the **Creature Storage System** (party and boxes), the
  **R.A.N.C.H.** (Remote Access Nurture & Care Hub: step into any box's walled yard, pet,
  pick up and play with whoever lives there, with a berry farm next door), a desktop buddy that walks
  along your taskbar, the capsule dock, a Showdown window for battles, and the **Data Lab** where
  you paste in every species, move, ability, growth curve and formula you want to use.
- **Android app** — a monitor for the creatures in your capsules: vitals, happiness and the odd
  thought while you walk ("Sproutle is enjoying the smells of the area"), a gentle tap on the
  capsule, steps that turn into friendship, wild creatures that an empty capsule can pick up, NFC
  capsule sync, and Showdown battles when you bump phones (or capsules) with a friend.
- **Battles happen on Showdown.** The apps send your creatures there as a team, Showdown
  runs the battle, and when it ends the apps read the battle log and work out experience, effort,
  friendship, new moves and evolutions in-house with your Data Lab formulas.
- **Hardware** — a USB dock with an NFC reader, and capsules that hold an NFC tag (optionally
  with a microcontroller, motion sensor, buzzer and vibration motor so they count steps, cry,
  wiggle and detect bumps on their own).

The project ships with 15 original placeholder creatures, generated pixel art and neutral names
(Capsule Link, capsules, creatures) so everything works out of the box. The **first-run setup**
lets you rename all of it — the app, what creatures travel in, what you call them, the network
you "connect" to — and walks you through bringing in your own species, moves, learnsets, natures,
sprites and trainer pictures, with links to copy from and a check after every paste. See
[making it yours](docs/making-it-yours.md).

```
             USB serial (JSON)        Wi-Fi or USB-C cable WebSocket (port 47820)
  [Dock] ───────────────────────── [PC app] ───────────────────────────── [Phone app]
    │  NFC                            │  hub: sync + battles                 │  NFC, steps,
    ▼                                 │  UDP beacon (47821)                  │  Bluetooth
 [Capsule] ◄──────────────────────────┼──────────────────────────────────── ┘
  NTAG I2C plus + ESP32-C3            └── optional relay server for friends elsewhere
```

## Getting the apps

**No developer tools needed.** Open `Preview.html` to try both apps in a browser. For the PC,
unzip *Capsule Link for Windows* and run `Capsule Link.exe`. For the phone, follow
[getting-the-apps.md](docs/getting-the-apps.md) (a free GitHub build makes the APK, or Claude
can do it for you once GitHub is connected). After that, updates come as one small
`.clupdate` file: drop it on the PC app's window and phones pick it up on their next sync.

**Making an update file** (for whoever changes the code): bump `version` in `version.json`, then
`node tools/make-update.mjs --notes "What changed"`. It builds both apps and writes
`capsule-link-update-<version>.clupdate`. Only the apps' own code goes in. If the PC's engine
and boot loader (`desktop/boot.cjs`, the Electron version) or the phone's native code
(`mobile/native`) changed, that side needs a full build instead; `tools/buildinfo.mjs` holds the
fingerprints that decide this.

## Folders

| Folder | What is in it |
|---|---|
| `shared/engine` | The rules: formula language, data sets, creatures, care and walking, capsule tag format, paste importer, save events, and `showdown.js` (team export, battle-log reader, in-house rewards, the Showdown bridge script). No dependencies, used by everything. |
| `shared/ui` | Pixel font, generated creatures and biomes, sprite bank (your PNGs win), ranch/buddy scene, Showdown panels, chiptune cries |
| `shared/net` | Dependency-free WebSocket server, the hub (PC sync + battle pairing), the client |
| `desktop` | Electron PC app |
| `mobile` | Capacitor Android app; `mobile/native` holds the Java plugin and the Android patch script |
| `relay` | Stand-alone pairing server for bump/code battles away from home |
| `firmware/dock`, `firmware/capsule` | Arduino sketches |
| `docs` | [adding-your-data.md](docs/adding-your-data.md) (start here for your species and sprites), [data-lab.md](docs/data-lab.md), [textures.md](docs/textures.md), [protocol.md](docs/protocol.md), [hardware.md](docs/hardware.md), and spreadsheet templates in `docs/templates` |
| `tests` | Engine and network tests (`node --test tests/*.test.mjs`) |
| `tools` | Generators for the pixel font and the app icons |

## PC app

Needs [Node.js](https://nodejs.org) 20 or newer.

```
cd desktop
npm install
npm start
```

To make an installer: `npm run dist` (Windows: produces an NSIS installer in `desktop/release`).
Your profiles (`profiles/<id>.json`, one per trainer), data set, textures and daily backups live
in the app data folder (**Settings → Open data folder**). A save from before profiles existed
becomes the first profile automatically.

**Look and feel.** Both apps use a clean, current design (system fonts, rounded cards, soft
shadows) and follow the computer's or phone's light or dark mode. Creatures stay pixel art.

**First run.** A full-screen introduction to the Nexus Ball (fading slides, Next only), then a few slides on how it works (capsules, the dock, linking a phone), then **Make it
yours** (every name the apps use, plus a logo and capsule picture), then an optional, recommended
data setup. Come back to any part from **Settings → Names and setup**.

**Sign-in and profiles.** After the logo, a black screen asks "Whose PC are you using?" (any key or
click). Then pick your card, or **Add trainer** to make an ID and a PC of your own with a few
starter creatures. Signing in "connects" to the network that keeps your creatures — longer the
first time, quick after that. The sign-out button (top right) returns to the question. Phones are paired per trainer:
when someone else logs on, linked phones disconnect and need that trainer's pairing code.

**Trainer ID.** Edit the card under **Trainer ID** on the PC menu. **Look** lists trainer pictures
you add (any PNG in `textures/trainers`) first and *Make your own* last; **Portrait** has face,
hair, clothes and up to four extras at once, each in any colour; **Card** has twelve designs, a
base colour, two card colours, sixteen patterns, eight finishes, any title you like, your region and
a motto. Drag a card sideways to spin it round: the back has a magnetic stripe (optional), your
signature (draw it in the editor), your party or your trainer class, earlier card numbers (**Get a
new number** keeps the old one there) and ink stamps you place anywhere. It is stored in the profile
and reaches the phone with every sync (Link screen; tap it to see it large). A phone with no PC
linked can edit its own card.

**R.A.N.C.H.** (Remote Access Nurture & Care Hub) puts you inside a box's yard at creature height.
The land carries on past the fence into layered scenery, so the world feels endless. Sixteen
environments, among them city outskirts, a mountaintop above the treetops, a spooky forest and two
abstract ones. Rub a creature to pet it, drag it to pick it up and carry it, fling it to toss it.
**Toys** and **Berries** open menus from your bag: toys bounce, roll and get kicked about (drag one
to fling it yourself); berries go to whoever gets there first. Fliers and levitators float and sit
down now and then; in a seafloor yard where everyone swims they swim about in a blue-tinted world.
Creatures show their back walking away, have little mood bubbles with sparks of their type, and
friends hang out together. Click someone for the care panel: feed, groom, nap, **Quality time**
(a close-up corner of their environment: wash, dry, brush, feed by hand, play fetch), **Dress up**
(clothes from the shop, placed anywhere on them; they grow fond of what you give them), a held item,
their form, and **Desktop buddy**. The **berry farm** and the **shop** are their own areas (tabs
under the title, or keys 1–3). The shop's stock changes every day: berries and treats, battle items,
clothes and incense, paid with coins from walking and battles. Drag empty ground (or Q / E) to
turn, scroll or + / − to zoom, R to reset. Your own ground, sky, scenery and prop textures can
replace the generated ones (see [textures.md](docs/textures.md)).

**Desktop buddies.** Up to six creatures out on your desktop at once (Settings, or **Desktop
buddy** in the R.A.N.C.H. and Storage): walkers along the bottom of the screen, fliers anywhere.
Pick them up and fling them, rub to pet, double-click to call, right-click for more (feed, play,
nap, change form). Friends play together, and now and then someone finds a little present.

**Debug → Edit a creature** changes anything about a creature like a save editor: species and form,
level and experience, PID and encryption constant, shininess, gender, ability, held item,
temperament, genes, effort, moves and PP, size, cry pitch, needs, memories and likes.

**Storage.** Boxes start with a clean, system-style background; **Wallpaper** picks another per
box (soft gradients, any habitat scene, or your own pictures from `textures/boxes`). Moving a
creature turns it into light and data that flies to its new spot; sending one to free range fires
it up as a beacon. Each move gets a line from the creature about it.

**Bringing creatures over.** **Storage → Import from PKHeX…** takes `.pk8`, `.pb8` and `.pk9`
files (and their encrypted `.ek*` forms): species, nickname, level, nature, ability, moves, IVs and
EVs, friendship, original trainer, when and where it was met, and the memories the games record
come across, and show up as its first memories. Teams exported from Showdown never import —
creatures go to Showdown, not back.

The first time a phone connects, Windows asks whether Capsule Link may use the network — allow
it on private networks.

## Android app

Needs Node.js, [Android Studio](https://developer.android.com/studio) (with JDK 21) and a phone
with NFC.

```
cd mobile
npm install
npm run android:init     # first time: creates mobile/android and adds the native code
npm run android:open     # opens Android Studio — press Run with your phone plugged in
```

After changing the web code: `npm run android:sync`, then Run again. `android:init` and
`android:sync` run `native/patch-android.mjs`, which copies the Java plugin and walking
service into the project, sets the icons and adds the permissions, the NFC launch filter
(tapping a capsule opens the app) and the foreground service to `AndroidManifest.xml`.

On first launch: the same introduction, two short slides on how it works, then **Link to my PC** → Find my PC (or type
the address from the PC's **Phone link** screen) → enter the six-digit code. Or **Start without
a PC** and pick a buddy.

**Monitor** shows the creature in your capsule: HP, energy, fullness, happiness and grooming,
what they seem to be thinking (every minute or two on a walk), and **tap the capsule** to let
them know you are there. There is no feeding or petting on the phone: inside the capsule hunger
and grooming barely change, and care happens at the PC. **Use my location** lets the app look up
what is nearby (OpenStreetMap, through the public Overpass service) and the weather (Open-Meteo):
rivers and beaches, parks, graveyards, power stations, hospitals, landmarks and more, how far the
town centre is, rain or sun and the temperature. Only that summary is kept; the position stays on
the phone. Without it, pick up to two environments by hand. With an empty capsule along, wild
creatures turn up by what is around you (water types by water, ghosts by graveyards, electric
types by power stations…), the weather, the time of day and how long you have walked; light an
**incense** from the shop and its type turns up far more for an hour. Weather-shaped creatures
change form inside the ball. Time the throw ring to catch one; it is sealed in the capsule and
reaches the PC on the next sync. First visits to real places become core memories, and favourite
places grow from the walks they enjoy.

## Trying it without hardware

**The phone as a capsule.** The phone app has a hidden **Debug** screen (**Link → Debug tools**)
with a simulated capsule: the same tag memory as a real ball and the same behaviour as the capsule
firmware. Tap it to the phone, put a creature in, switch modes (desk mode cries and wiggles, walk
mode counts steps, battle mode records bumps), add steps by hand or walk for real, and watch the
raw tag memory change.

It can also sit on the **PC's dock over a USB-C cable**, so you can try PC ↔ capsule transfers
before the dock is built:

1. On the phone, turn on USB debugging (Settings → About phone → tap Build number 7 times, then
   Developer options → USB debugging).
2. Plug the phone into the PC and allow the PC when the phone asks.
3. On the PC: **Phone link → Phone over a USB-C cable → Set up USB link**. This needs Android's
   `adb` tool: install Android Studio, or put Google's SDK Platform-Tools in the data folder.
   Tick **Keep linking phones I plug in** to have it redo this whenever you plug in.
4. On the phone: **Debug → Put on the PC dock**, then open **Capsule dock** on the PC. The PC
   sends creatures in, syncs steps and lets them out exactly as with a real capsule.

The same cable works for the normal phone link with no Wi-Fi: **Link → Use USB cable**. It uses
`adb reverse`, so the phone reaches the PC at `ws://127.0.0.1:47820`.

- PC: **Capsule dock → New virtual capsule**. Dock it, send a creature, lift it off, press
  **+1,000 steps** or **Bump**, dock it again — everything the real capsule does.
- Battles: paste any finished Showdown battle log on the Battle screen to see the in-house
  rewards without opening Showdown.
- Phone in a browser: `cd mobile && npm run preview`, then open `mobile/dist-web/index.html`.
  NFC and steps are simulated (virtual capsules and step buttons).
- The PC interface also runs in a browser: `cd desktop && npm run preview` → `desktop/dist-web/index.html`
  (no USB or phone link there).

## Battles on Pokémon Showdown

1. Set your Showdown name on the **Battle** screen (or open Showdown in the app and log in once;
   the name fills in by itself).
2. **Open Showdown** opens the real Showdown site inside the app (its own window on the PC). A
   small **Capsule team** panel sits in the corner of the page. Use it to challenge someone or to
   accept a challenge, so the creatures you carry are the team that battles. Showdown's own
   challenge buttons would use a Teambuilder team instead.
3. When the battle ends, the app reads the log, works out experience, effort and friendship with
   your Data Lab formulas, and asks about new moves and evolutions. Each battle counts once.

**Bump battles.** Both players press **Bump to battle** and knock phones together, or knock two
capsules in battle mode together. The PC (or a pairing server) matches the two bumps, swaps
Showdown names, and each app opens Showdown: one sends the challenge with your team, the other
accepts with theirs. Both players are saved as friends, with their capsule ids, so next time two
friends' capsules can find each other through Bluetooth with no PC or server at all.

**Battles played elsewhere** (Showdown in a normal browser) still count: upload the replay in
Showdown and paste the link on the Battle screen, or load the downloaded replay file, or paste the
log. Copy your team first with **Copy team** and import it in Showdown's Teambuilder.

**Format.** The default is `gen9customgame` (Custom Game), which accepts any level and moveset.
Your species, moves, abilities and natures need Showdown's names for the official server
(each species and move has a "Name on Showdown" field in the Data Lab if yours differ).

**Your own made-up creatures** only exist on a Showdown server you run yourself: the server is
open source ([smogon/pokemon-showdown](https://github.com/smogon/pokemon-showdown)), and custom
species go in a mod under `data/mods`. Point **Battle → Server and format** at it, for example
`http://192.168.1.20:8000`, and use the format your mod defines.

**Pairing away from home.** Phones on your Wi-Fi pair through the PC. Elsewhere, run the pairing
server on any machine both phones can reach and set **Link → Pairing server** to it:

```
node relay/relay.mjs --port 47820
```

## Hardware

See [docs/hardware.md](docs/hardware.md) for parts, wiring and assembly. Short version: a plain
NTAG215 sticker inside a ball already works as a capsule; add an NTAG I2C plus module, an
ESP32-C3, a motion sensor, a buzzer and a coin motor for the full walking/crying/wiggling capsule.
For how much room a creature's whole life takes (everything, with 20 core memories: about 1.4 KB
deflated, so an NTAG I2C plus 2k), see [docs/example-monster.md](docs/example-monster.md).

## Your data and art

- **[Adding your data](docs/adding-your-data.md)**: start here. It covers the fastest way to load
  every species, move, learnset and nature (Showdown's own data files paste straight in), the
  spreadsheet templates, and how to name and size sprites so a whole folder imports in one go.
- [Data Lab guide](docs/data-lab.md): every field, the formula language, how battles become rewards.
- [Making it yours](docs/making-it-yours.md): names, logo and capsule art, trainer pictures,
  wallpapers, and importing from PKHeX.
- [Textures](docs/textures.md): file names and sizes for creature, ranch and box art.

## What was tested, and what was not

Tested while building: PKHeX file reading (a synthetic Scarlet/Violet file through PKHeX's
encryption and block shuffle and back, field by field), walk encounters, thoughts and catching,
the name layer, the first-run setup, storage transfers and the turning R.A.N.C.H. camera in
Chromium (60 fps), the engine (formulas, levelling, evolution, walking, care, capsule
encoding, half-finished syncs, the paste importer with Showdown's pokedex/moves/learnsets/natures
files and every template in `docs/templates`, sprite file matching, Showdown team export in both
formats, battle-log reading and rewards, idempotent sync events), the WebSocket hub and relay with
real sockets (pairing, sync, bump and code matching, a phone acting as a capsule on the PC dock),
the phone's simulated capsule docked on the PC hub (send in, walk 2,000 steps, tap, back home), the PC main process under a stand-in for Electron, both interfaces in Chromium,
a full phone-to-PC session (pair, take a creature, walk, sync), and the Showdown bridge in
Chromium against a stand-in Showdown server (challenge panel, `/utm` + `/accept`, battle log
captured and scored). The firmware compiles against stand-in Arduino headers.

Not tested here: real PKHeX files (the layout follows PKHeX's PK8/PK9 source; Sword/Shield and
BDSP keep the game version at a different offset than Scarlet/Violet, which is handled but
untested with a real file), Electron itself, the Android build and Java code on a device, `adb` over a
real cable, the firmware on
real boards, and the bridge against the live Showdown site (no network access to it from here).
The bridge only relies on Showdown's documented protocol (it watches the page's own connection and
sends `/utm`, `/challenge` and `/accept`), so it does not depend on how Showdown's page is built,
but try it once with a friend before relying on it.

Sending creatures to PKHeX (0.9): a creature that came in from a .pk8/.pk9 file goes back as that file with
its changes written over it; older files go back unchanged; remembered or home-grown ones are written as a
fresh Scarlet/Violet file (round-trip tested here against the same reader, not yet opened in a real copy of
PKHeX, whose legality checker may flag details the games would have filled in). Wild battles in Battle Link
run on Pokémon Showdown's own simulator and battle screen, bundled into the PC app (see vendor/showdown);
only species and moves Showdown knows can take part (set their Showdown names in the Data Lab).

Known limits: notifications for bump battles reach the phone while the app is open, a walk is
running, or (for capsules) Bluetooth listening is on. The capsule firmware favours simplicity over
battery life (see hardware.md).
