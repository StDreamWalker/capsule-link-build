#!/usr/bin/env node
// Stand-alone battle relay. Run it on any computer or small server to battle friends who are
// not on your Wi-Fi:   node relay/relay.mjs --port 47820
// Then in the phone app set Battle server to ws://<that machine>:47820
import { createWsServer } from '../shared/net/wsserver.js';
import { Hub } from '../shared/net/hub.js';
import { HUB_PORT } from '../shared/engine/protocol.js';

const arg = (name, def) => {
  const i = process.argv.indexOf(`--${name}`);
  return i > 0 ? process.argv[i + 1] : process.env[name.toUpperCase()] ?? def;
};
const port = Number(arg('port', HUB_PORT));
const hub = new Hub({ mode: 'relay', name: arg('name', 'Capsule Link relay'), log: (...a) => console.log(new Date().toISOString(), ...a) });
const server = createWsServer({
  port,
  onConnection: (conn) => hub.attach(conn),
  onHttp: (req, res) => {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify({ app: 'capsule-link', ...hub.status() }));
  },
});
await server.ready;
console.log(`Capsule Link battle relay listening on port ${port}`);
process.on('SIGINT', async () => { await server.close(); process.exit(0); });
