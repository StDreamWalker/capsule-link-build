/* Capsule Link: water depth and the ocean's zones. At sea, the atlas reads the depth of the sea floor (GEBCO,
   through NOAA's ERDDAP; estimated from how far the land is when it can't) and each sea Pokémon lives where its
   real counterpart does: [shallowest, deepest] metres and how it lives there (p: in open water, b: on the sea
   floor, r: on shallow reefs, kelp and rocks). Deep-water Pokémon can't be met where the sea is too shallow for
   them, reef and seafloor ones need their floor within reach, and the deeper a Pokémon lives the rarer meeting
   it is (the sunlit zone most, then twilight, midnight and the abyss), though never impossible. */
const CL_MARINE = {
  72: [0, 200, 'p'], 73: [0, 200, 'p'],                         // box jellyfish: sunlit surface water
  86: [0, 100, 'p'], 87: [0, 150, 'p'],                         // harp seals
  90: [0, 300, 'b'], 91: [0, 300, 'b'],                         // scallops
  98: [0, 600, 'b'], 99: [0, 600, 'b'],                         // Japanese spider crab: 50–600 m
  116: [0, 30, 'r'], 117: [0, 40, 'r'], 230: [200, 1500, 'p'],  // seahorses; Kingdra sleeps in the deep
  120: [0, 6000, 'b'], 121: [0, 6000, 'b'],                     // starfish: shore to abyss
  131: [0, 200, 'p'],                                           // plesiosaur-like, at the surface
  147: [0, 200, 'p'], 148: [0, 200, 'p'],                       // sea serpents
  170: [200, 1000, 'p'], 171: [200, 4000, 'p'],                 // lanternfish, deep-sea anglerfish
  211: [0, 100, 'r'], 904: [0, 150, 'r'],                       // pufferfish
  222: [0, 50, 'r'], 864: [0, 300, 'b'],                        // coral reef; ancient bleached coral
  223: [0, 200, 'p'], 224: [0, 300, 'b'],                       // remora; octopus
  458: [0, 200, 'p'], 226: [0, 1000, 'p'],                      // manta rays (they dive deep)
  319: [0, 500, 'p'],                                           // sharks
  320: [0, 300, 'p'], 321: [0, 2000, 'p'],                      // whales (the big ones dive)
  363: [0, 200, 'p'], 364: [0, 300, 'p'], 365: [0, 400, 'p'],   // seals and walruses
  366: [0, 200, 'b'], 367: [200, 2000, 'p'], 368: [200, 2000, 'p'], // pearl oysters; the deep-sea pair
  369: [150, 800, 'b'],                                         // coelacanth
  370: [0, 40, 'r'],                                            // kissing fish
  394: [0, 300, 'p'], 395: [0, 500, 'p'],                       // penguins dive
  418: [0, 40, 'r'], 419: [0, 40, 'r'],                         // sea otters in the kelp
  422: [0, 30, 'b'], 423: [0, 40, 'b'],                         // sea slugs
  456: [0, 100, 'r'], 457: [200, 2000, 'b'],                    // butterflyfish; Lumineon on the deep floor
  592: [0, 1000, 'p'], 593: [200, 4000, 'p'],                   // man o' war; Jellicent sinks to the deep
  594: [0, 600, 'p'],                                           // ocean sunfish
  686: [0, 200, 'p'], 687: [0, 300, 'p'],                       // cuttlefish
  688: [0, 30, 'b'], 689: [0, 30, 'b'],                         // goose barnacles on rocks
  690: [0, 50, 'r'], 691: [0, 200, 'r'],                        // leafy seadragons
  692: [0, 100, 'b'], 693: [0, 100, 'b'],                       // pistol shrimp
  746: [0, 200, 'p'],                                           // schooling sardines
  747: [0, 50, 'r'], 748: [0, 60, 'r'],                         // crown-of-thorns starfish
  767: [0, 100, 'b'], 768: [170, 2200, 'b'],                    // isopods; giant isopods are deep
  771: [0, 30, 'b'],                                            // sea cucumbers in the shallows
  779: [0, 50, 'r'],                                            // triggerfish
  781: [200, 4000, 'b'],                                        // an anchor on a deep wreck
  846: [0, 200, 'p'], 847: [0, 200, 'p'],                       // barracuda
  852: [0, 30, 'b'], 853: [0, 100, 'b'],                        // octopus
  871: [0, 100, 'b'],                                           // sea urchin
  960: [0, 100, 'b'], 961: [0, 100, 'b'],                       // garden eels in sand
  963: [0, 300, 'p'], 964: [0, 300, 'p'],                       // dolphins
  976: [0, 300, 'p'],                                           // a fish
};
const CL_ZONES = [[200, 'sunlight zone', 1], [1000, 'twilight zone', 0.45], [4000, 'midnight zone', 0.22], [6000, 'abyss', 0.12], [Infinity, 'hadal trenches', 0.07]];
function clZone(m) { for (const z of CL_ZONES) if (m < z[0]) return z; return CL_ZONES[CL_ZONES.length - 1]; }
const clM = (m) => `${Math.round(m).toLocaleString('en-US')} m`;
/** env.depth: { m (the floor, metres), min, max (over the scan), zone, est (estimated) }. */
function clDepthEnv(env, raw) {
  if (!env.isOcean) { env.depth = null; return; }
  const d = raw && raw.depth;
  if (d && Number.isFinite(d.m) && d.m > 0) { env.depth = { m: d.m, min: d.min ?? d.m, max: d.max ?? d.m, est: false, src: d.src || 'GEBCO' }; }
  else {
    // no reading: how far from land it is says roughly how deep (shore, shelf, slope, open ocean)
    const f = env.seaFrac || 0;
    const m = f < 0.6 ? 15 : f < 0.9 ? 45 : f < 1 ? 150 : 3000;
    env.depth = { m, min: m, max: m, est: true, src: 'estimated from the distance to land' };
  }
  env.depth.zone = clZone(env.depth.m)[1];
}
/** How likely a sea Pokémon is here, for the depth (1 when the depth doesn't matter to it). */
function clMarine(env, s, why) {
  const z = CL_MARINE[s.dex];
  const D = env.depth && env.depth.m;
  if (!z || !D) return 1;
  const [top, bot, how] = z;
  let f = 1, at = top;
  if (how === 'p') {
    if (D < top * 0.6) { f = 0.08; why.push({ k: 'neg', t: `Lives below ${clM(top)}; the sea here is ${clM(D)} deep` }); }
    at = top;
  } else if (how === 'r') {
    if (D <= bot) { f = 1.25; why.push({ k: 'hab', t: `Shallow reefs and rocks (${clM(D)} deep)` }); }
    else if (D <= bot * 2.5) f = 0.6;
    else { f = 0.06; why.push({ k: 'neg', t: `Needs shallow water; the floor here is ${clM(D)} down` }); }
    at = 0;
  } else {
    const lo = Math.min(env.depth.min ?? D, D), hi = Math.max(env.depth.max ?? D, D);
    if (hi < top * 0.6) { f = 0.08; why.push({ k: 'neg', t: `Lives on the floor below ${clM(top)}` }); at = top; }
    else if (lo > bot * 1.4) { f = 0.1; why.push({ k: 'neg', t: `Lives on the floor down to ${clM(bot)}; it's ${clM(D)} here` }); at = bot; }
    else { at = Math.max(top, Math.min(D, bot)); if (at >= 200) why.push({ k: 'hab', t: `On the sea floor, ${clM(at)} down` }); }
  }
  const zone = clZone(at);
  if (zone[2] < 1) why.push({ k: 'neg', t: `Lives in the ${zone[1]}: rarely met near the surface` });
  else if (how === 'p' && at === 0 && f >= 1) why.push({ k: 'hab', t: 'Sunlit open water' });
  return f * zone[2];
}
/** The depth reading: GEBCO 2020 from NOAA's ERDDAP, a small grid over the scan. */
function clDepthUrl(lat, lon, radiusKm) {
  const d = Math.max(0.005, Math.min(3, radiusKm || 1.5) / 111);
  const cells = Math.ceil((2 * d) / 0.0041667), stride = Math.max(1, Math.ceil(cells / 4));
  const la1 = Math.max(-89.99, lat - d), la2 = Math.min(89.99, lat + d);
  let lo1 = lon - d, lo2 = lon + d; lo1 = Math.max(-179.99, lo1); lo2 = Math.min(179.99, lo2);
  return `https://coastwatch.pfeg.noaa.gov/erddap/griddap/GEBCO_2020.json?elevation%5B(${la1.toFixed(4)}):${stride}:(${la2.toFixed(4)})%5D%5B(${lo1.toFixed(4)}):${stride}:(${lo2.toFixed(4)})%5D`;
}
function clParseDepth(json, lat, lon) {
  const rows = (json && json.table && json.table.rows) || [];
  const pts = rows.map((r) => ({ la: +r[0], lo: +r[1], e: +r[2] })).filter((p) => Number.isFinite(p.e) && p.e !== 32767);
  if (!pts.length) return null;
  let best = pts[0];
  for (const p of pts) if ((p.la - lat) ** 2 + (p.lo - lon) ** 2 < (best.la - lat) ** 2 + (best.lo - lon) ** 2) best = p;
  const wet = pts.filter((p) => p.e < 0).map((p) => -p.e);
  if (best.e >= 0 && !wet.length) return null;
  const m = best.e < 0 ? -best.e : Math.min(...wet);
  return { m, min: wet.length ? Math.min(...wet) : m, max: wet.length ? Math.max(...wet) : m, src: 'GEBCO 2020 (NOAA ERDDAP)' };
}
