/* Capsule Link bridge (added to the atlas page by tools/atlas/extract.mjs): a button to make the scanned spot
   the app's "where you are", and messages to and from the app around it. */
(function () {
  var A = window.__atlas; if (!A || window.parent === window) return;
  var send = function (m) { try { window.parent.postMessage(Object.assign({ from: 'pokeeco' }, m), '*'); } catch (e) { } };
  var css = document.createElement('style');
  css.textContent = '.cl-bar{position:absolute;left:296px;bottom:18px;z-index:900;display:flex;gap:8px;align-items:center;flex-wrap:wrap;max-width:calc(100% - 310px);pointer-events:none}' +
    '.cl-bar>*{pointer-events:auto}.cl-use{background:#e9c46a;color:#1b1b1b;border:0;border-radius:10px;padding:9px 14px;font:600 13px system-ui,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.35);cursor:pointer}' +
    '.cl-use[disabled]{opacity:.55;cursor:default}.cl-now{background:rgba(16,22,26,.88);color:#e8eef0;border-radius:10px;padding:7px 11px;font:12px system-ui,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.3)}' +
    '.cl-now b{color:#e9c46a;font-weight:600}@media (max-width:820px){.cl-bar{left:12px;max-width:calc(100% - 24px);bottom:calc(var(--sheet-h,140px) + 10px)}.cl-now{display:none!important}.cl-use{padding:7px 11px;font-size:12px}}';
  document.head.appendChild(css);
  var bar = document.createElement('div'); bar.className = 'cl-bar';
  var use = document.createElement('button'); use.className = 'cl-use'; use.type = 'button'; use.textContent = '📍 Use this spot in Capsule Link';
  var now = document.createElement('div'); now.className = 'cl-now'; now.style.display = 'none';
  bar.appendChild(use); bar.appendChild(now);
  (document.getElementById('mapwrap') || document.body).appendChild(bar);
  function label() {
    var r = A.state.raw; if (!r) return '';
    var g = r.geo || {};
    if (g.ocean) return 'Open water';
    if (g.estimated) return g.country ? g.country + ' (estimated)' : 'Remote area ' + r.lat.toFixed(2) + '°, ' + r.lon.toFixed(2) + '°';
    var t = [g.place, g.state, g.country].filter(Boolean).slice(0, 2).join(', ');
    return t || (r.lat.toFixed(2) + '°, ' + r.lon.toFixed(2) + '°');
  }
  function sync() { use.disabled = !A.state.raw; }
  setInterval(sync, 700); sync();
  use.onclick = function () {
    var r = A.state.raw; if (!r) return;
    send({ type: 'atlas-spot', lat: r.lat, lon: r.lon, radiusKm: r.radiusKm, label: label() });
    use.textContent = '✓ Capsule Link is using this spot'; setTimeout(function () { use.textContent = '📍 Use this spot in Capsule Link'; }, 2600);
  };
  // ---------- anchored to where you are (the phone with location on) ----------
  var anchor = null, lastScan = null;
  css.textContent += 'body.cl-locked .search,body.cl-locked #preset{display:none!important}body.cl-locked .cl-use{display:none}' +
    '.cl-anchor{display:none;background:rgba(16,22,26,.9);color:#e8eef0;border-radius:10px;padding:7px 11px;font:600 12px system-ui,sans-serif;box-shadow:0 3px 12px rgba(0,0,0,.3)}body.cl-locked .cl-anchor{display:block}' +
    '.cl-you{width:22px;height:22px;border-radius:50%;background:#3b82f6;border:3px solid #fff;box-shadow:0 0 0 6px rgba(59,130,246,.25),0 2px 8px rgba(0,0,0,.4)}';
  var anchorEl = document.createElement('div'); anchorEl.className = 'cl-anchor'; bar.insertBefore(anchorEl, use);
  var you = null;
  function km(a, b) { var R = 6371, dLat = (b.lat - a.lat) * Math.PI / 180, dLon = (b.lon - a.lon) * Math.PI / 180; var x = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2); return 2 * R * Math.asin(Math.sqrt(x)); }
  function setZoomCentered(on) {
    ['touchZoom', 'scrollWheelZoom', 'doubleClickZoom'].forEach(function (k) { var hnd = A.map[k]; if (!hnd) return; try { hnd.disable(); A.map.options[k] = on ? 'center' : true; hnd.enable(); } catch (e) { } });
  }
  function lock(m) {
    var first = !anchor;
    anchor = { lat: m.lat, lon: m.lon, label: m.label || '' };
    window.__clLock = true; document.body.classList.add('cl-locked');
    try { A.map.dragging.disable(); A.map.boxZoom && A.map.boxZoom.disable(); A.map.keyboard && A.map.keyboard.disable(); } catch (e) { }
    if (first) setZoomCentered(true);
    anchorEl.textContent = '📍 Where you are' + (anchor.label ? ' · ' + anchor.label : '');
    try {
      if (!you && window.L && L.marker) you = L.marker([anchor.lat, anchor.lon], { icon: L.divIcon({ className: '', html: '<div class="cl-you"></div>', iconSize: [22, 22], iconAnchor: [11, 11] }), interactive: false, zIndexOffset: 1000 }).addTo(A.map);
      else if (you) you.setLatLng([anchor.lat, anchor.lon]);
      A.map.setView([anchor.lat, anchor.lon], first ? Math.max(A.map.getZoom ? A.map.getZoom() : 14, 14) : (A.map.getZoom ? A.map.getZoom() : 14), { animate: !first });
    } catch (e) { }
    // scan again when you've moved a little (or the first time)
    if (!lastScan || km(lastScan, anchor) > 0.15 || Date.now() - lastScan.at > 20 * 60000) { lastScan = { lat: anchor.lat, lon: anchor.lon, at: Date.now() }; A.analyze(anchor.lat, anchor.lon); }
  }
  function unlock() {
    if (!anchor) return;
    anchor = null; window.__clLock = false; document.body.classList.remove('cl-locked');
    try { A.map.dragging.enable(); A.map.boxZoom && A.map.boxZoom.enable(); A.map.keyboard && A.map.keyboard.enable(); } catch (e) { }
    setZoomCentered(false);
    if (you) { try { A.map.removeLayer(you); } catch (e) { } you = null; }
  }
  window.__clLocked = function () {
    var t = document.createElement('div'); t.className = 'toast'; t.textContent = 'The atlas follows where you are. Turn location off in Monitor → Where to look around anywhere.'; document.body.appendChild(t); setTimeout(function () { t.remove(); }, 3400);
    if (anchor) try { A.map.setView([anchor.lat, anchor.lon]); } catch (e) { }
  };
  // Locate me, anchored: back to you (and read it again)
  var loc = document.getElementById('locate');
  if (loc) loc.addEventListener('click', function (e) { if (!anchor) return; e.stopImmediatePropagation(); e.preventDefault(); send({ type: 'locate' }); try { A.map.setView([anchor.lat, anchor.lon], 15); } catch (er) { } }, true);
  window.addEventListener('message', function (e) {
    var m = e.data || {}; if (m.to !== 'pokeeco') return;
    if (m.type === 'current') {
      now.style.display = m.label ? '' : 'none';
      now.innerHTML = m.label ? 'In the app: <b></b>' : '';
      if (m.label) now.querySelector('b').textContent = m.label;
    }
    if (m.type === 'go' && !anchor && isFinite(m.lat) && isFinite(m.lon)) { A.map.setView([m.lat, m.lon], m.zoom || 12); A.analyze(m.lat, m.lon); }
    if (m.type === 'anchor' && isFinite(m.lat) && isFinite(m.lon)) lock(m);
    if (m.type === 'free') unlock();
  });
  send({ type: 'ready' });
})();
