  /* Capsule Link: the sea floor's depth for a scan at sea (see marine.js), kept for a while once read. */
  function clDepthFetch(lat, lon, r) {
    const key = 'cl-depth:' + lat.toFixed(3) + ',' + lon.toFixed(3) + ',' + r;
    try { const c = JSON.parse(localStorage.getItem(key) || 'null'); if (c) return Promise.resolve(c); } catch (e) { }
    const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 20000);
    return fetch(clDepthUrl(lat, lon, r), { signal: ctl.signal })
      .then(res => (res.ok ? res.json() : Promise.reject(new Error('HTTP ' + res.status))))
      .then(j => { const d = clParseDepth(j, lat, lon); try { if (d) localStorage.setItem(key, JSON.stringify(d)); } catch (e) { } return d; })
      .finally(() => clearTimeout(t));
  }
