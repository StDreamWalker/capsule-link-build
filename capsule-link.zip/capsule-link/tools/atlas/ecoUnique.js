  /* Capsule Link: "What's special here" for the Local Ecology tab. Almost everywhere has more birds than anything
     else, then insects, then rodents, so those only count when this place has a lot more of them than usual.
     Groups: the local share of each animal group against its share in the atlas's world-wide baseline (GUILDS).
     Species: localSpecialties (the regional ecology and culture boost, against the same land without it), on the
     population model; filler birds, insects and rodents only when far above the usual or their group stands out. */
  const CL_FILLER = new Set(['songbird', 'insect', 'rodent']);
  let clUniqCache = null;
  function ecoUnique(env, pop) {
    if (clUniqCache && clUniqCache.pop === pop) return clUniqCache.html;
    let html = '';
    try {
      const share = {}; let tot = 0;
      for (const r of pop.list) if (r.w > 0 && !r.locked) { const g = DEX2GUILD[r.s.fam] || 'misc'; share[g] = (share[g] || 0) + r.p; tot += r.p; }
      let baseTot = 0; for (const [, v] of Object.entries(GUILDS)) baseTot += v[1];
      const groups = Object.entries(share).filter(([g]) => GUILDS[g]).map(([g, v]) => ({ g, local: v / (tot || 1), ratio: (v / (tot || 1)) / (GUILDS[g][1] / baseTot) }))
        .filter((x) => x.local >= 0.02 && x.ratio >= (CL_FILLER.has(x.g) ? 2 : 1.7)).sort((a, b) => b.ratio * Math.sqrt(b.local) - a.ratio * Math.sqrt(a.local));
      const standout = new Set(groups.map((x) => x.g));
      let sp = [];
      try { sp = localSpecialties(env, SPECIES, { includeLegendary: false, weather: 'none', time: 'any', useConditions: false }, pop, 30); } catch (e) { sp = []; }
      // (a place known for a particular creature, like New York's pigeons and rats, names it in its regional rules)
      const fa = env.fauna || {};
      const known = (s) => ((fa.spMult || {})[s.fam] >= 1.5 || (fa.spMult || {})[s.dex] >= 1.5) ? ((fa.spSrc || {})[s.fam] || (fa.spSrc || {})[s.dex] || 'this place') : null;
      sp = sp.filter((x) => { const g = DEX2GUILD[x.r.s.fam] || 'misc'; return !CL_FILLER.has(g) || standout.has(g) || x.ratio >= 3 || known(x.r.s); });
      // what the place is known for comes first (even when it's only a little above the usual), then the rest
      const fams = new Set(sp.map((x) => x.r.s.fam));
      const knownHere = pop.list.filter((r) => r.w > 0 && !r.locked && r.p >= 0.002 && !r.s.legendary && known(r.s) && r.s.dex === r.s.fam && !fams.has(r.s.fam)).sort((a, b) => b.p - a.p).map((r) => ({ r, ratio: null, knownOnly: true }));
      sp = [...sp.filter((x) => known(x.r.s)), ...knownHere, ...sp.filter((x) => !known(x.r.s))].slice(0, 6);
      // non-filler groups that stand out also bring their most common member, when the regional list is short
      const seen = new Set(sp.map((x) => x.r.s.fam));
      for (const x of groups) {
        if (sp.length >= 6) break;
        if (CL_FILLER.has(x.g) && x.ratio < 2.5) continue;
        const top = pop.list.filter((r) => r.w > 0 && !r.locked && (DEX2GUILD[r.s.fam] || 'misc') === x.g && !seen.has(r.s.fam)).sort((a, b) => b.p - a.p)[0];
        if (top) { sp.push({ r: top, ratio: null, g: x.g }); seen.add(top.s.fam); }
      }
      const low = (t) => t.replace(/^[A-Z][a-z]/, (m) => m.toLowerCase());
      const name = (g) => esc(low(GUILDS[g][0]));
      const times = (v) => (v >= 10 ? Math.round(v) : v.toFixed(1)).toString().replace(/\.0$/, '');
      const shownGroups = groups.slice(0, 3);
      const gLine = shownGroups.length
        ? `Compared with the usual mix almost everywhere (songbirds, then insects, then rodents), this area has ${shownGroups.map((x, i) => `${i === 0 ? '' : i === shownGroups.length - 1 ? ' and ' : ', '}<b>${x.ratio >= 3 ? 'far ' : ''}more ${name(x.g)}</b> (${times(x.ratio)}× the usual share)`).join('')}.`
        : 'Its animal groups follow the usual mix found almost everywhere: songbirds first, then insects, then rodents.';
      const sLine = sp.length
        ? ` Relatively special here: ${sp.map((x) => `<b>${esc(x.r.s.name)}</b>${x.knownOnly ? ` <span class="tyn">(${esc(known(x.r.s))} is known for them)</span>` : x.ratio && known(x.r.s) ? ` <span class="tyn">(${times(x.ratio)}× usual, ${esc(known(x.r.s))} is known for them)</span>` : x.ratio ? ` <span class="tyn">(${times(x.ratio)}× usual for this land)</span>` : ` <span class="tyn">(${esc(GUILDS[x.g] ? low(GUILDS[x.g][0]) : '')})</span>`}`).join(', ')}.`
        : ' No Pokémon here is much more common than it would be on the same kind of land elsewhere.';
      html = `<div class="ecoBlk clUniq"><b>What’s special here</b><div style="margin-top:4px;line-height:1.5">${gLine}${sLine}</div></div>`;
    } catch (e) { console.warn(e); html = ''; }
    clUniqCache = { pop, html };
    return html;
  }
