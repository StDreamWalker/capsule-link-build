// Move lab: a Mew on the battle stage, every move one click (or one key) away, to check how each one looks.
// No battle behind it: just the effect, with controls for the things that change how a move plays out.
import { createBattleStage } from '../../shared/ui/battleStage.js';
import { SpriteBank } from '../../shared/ui/art.js';
import { indexDataset, createDefaultDataset, createCreature } from '../../shared/engine/index.js';
import { h } from '../../shared/ui/dom.js';

const SD = globalThis.CapsuleShowdown;
const idx = indexDataset(createDefaultDataset());
const bank = new SpriteBank({ idx, resolveTexture: () => null });
const anySp = idx.ds.species[0]?.id;
const mk = (seed) => createCreature(idx, anySp, { level: 50, seed, location: { kind: 'wild' } });
const mons = [mk(1), mk(2)];
const ALL = SD.allMoves();
const NOTES_KEY = 'clMoveLabNotes';
let notes = {}; try { notes = JSON.parse(localStorage.getItem(NOTES_KEY) || '{}'); } catch { notes = {}; }
const saveNotes = () => { try { localStorage.setItem(NOTES_KEY, JSON.stringify(notes)); } catch { /* fine */ } };

const S = { i: 0, q: '', type: '', place: 'stadium', hits: 'auto', weather: '', mag: 7, miss: false, crit: false, quality: 'high', me: 'Mew', foe: 'Mew', status: '' };
try { Object.assign(S, JSON.parse(localStorage.getItem('clMoveLabState') || '{}')); } catch { /* fine */ }
const keep = () => { try { localStorage.setItem('clMoveLabState', JSON.stringify(S)); } catch { /* fine */ } };

const PLACES = ['stadium', 'colosseum', 'meadow', 'forest', 'beach', 'skyline', 'spooky', 'volcano', 'cavern', 'seafloor', 'ruins', 'shrine', 'park', 'snowfield', 'desert', 'synth', 'crystal', 'prism', 'starfield'];
const WEATHERS = [['', 'None'], ['raindance', 'Rain'], ['sunnyday', 'Harsh sun'], ['sandstorm', 'Sandstorm'], ['snowscape', 'Snow'], ['hail', 'Hail'], ['primordialsea', 'Heavy rain'], ['desolateland', 'Extreme sun']];
const MAG = { 4: 10, 5: 30, 6: 50, 7: 70, 8: 90, 9: 110, 10: 150 };

const stageBox = h('div', { class: 'lab-stage' });
const listEl = h('div', { class: 'lab-list' });
const info = h('div', { class: 'lab-info' });
let stage = null;
function build() {
  try { stage?.destroy(); } catch { /* fine */ }
  stage = createBattleStage({ idx, bank, place: S.place, creatureFor: (mon) => mons[mon.side] ?? mons[0], speciesFor: () => null, quality: S.quality, ambient: null });
  stageBox.replaceChildren(stage.el);
  setTimeout(() => stage.labStart(S.me, S.foe), 60);
}
const list = () => ALL.filter((m) => (!S.q || m.name.toLowerCase().includes(S.q)) && (!S.type || m.type === S.type));
function cur() { const L = list(); if (!L.length) return null; S.i = Math.max(0, Math.min(L.length - 1, S.i)); return L[S.i]; }
function play() {
  const m = cur(); if (!m || !stage) return;
  let mv = SD.stageMove(m.id);
  if (m.id === 'magnitude') mv = { ...mv, bp: MAG[S.mag] ?? 70 };
  const multi = Array.isArray(m.multihit) ? m.multihit : m.multihit ? [m.multihit, m.multihit] : null;
  const hits = multi ? (S.hits === 'auto' ? Math.round((multi[0] + multi[1]) / 2) : Number(S.hits)) : 1;
  stage.labMove(mv, { hits, weather: S.weather || null, miss: S.miss, crit: S.crit });
  drawInfo();
}
function go(d) { S.i += d; keep(); drawList(); play(); }
function drawInfo() {
  const m = cur(); if (!m) { info.replaceChildren('No move matches.'); return; }
  const mv = SD.stageMove(m.id), n = notes[m.id] ?? {};
  const ok = h('button', { class: `lab-mark ${n.mark === 'ok' ? 'on ok' : ''}`, onclick: () => { notes[m.id] = { ...n, mark: n.mark === 'ok' ? null : 'ok' }; saveNotes(); drawInfo(); drawList(); } }, '✓ Looks right');
  const bad = h('button', { class: `lab-mark ${n.mark === 'bad' ? 'on bad' : ''}`, onclick: () => { notes[m.id] = { ...n, mark: n.mark === 'bad' ? null : 'bad' }; saveNotes(); drawInfo(); drawList(); } }, '✗ Needs work');
  const ta = h('textarea', { placeholder: 'What should change? (saved as you type)', value: n.text ?? '', oninput: (e) => { notes[m.id] = { ...(notes[m.id] ?? {}), text: e.target.value }; saveNotes(); } });
  ta.value = n.text ?? '';
  info.replaceChildren(
    h('div', { class: 'lab-title' }, h('b', null, m.name), h('span', { class: `lab-type t-${m.type}` }, m.type), h('span', { class: 'dim' }, `${mv.cat}${mv.bp ? ` · ${mv.bp} power` : ''}${m.multihit ? ` · hits ${Array.isArray(m.multihit) ? m.multihit.join('–') : m.multihit}×` : ''}${m.weather ? ` · sets ${m.weather}` : ''}`)),
    h('div', { class: 'lab-row' }, ok, bad), ta);
}
function drawList() {
  const L = list(), c = cur();
  const done = Object.values(notes).filter((n) => n.mark).length;
  listEl.replaceChildren(h('div', { class: 'dim lab-count' }, `${L.length} moves · ${done} checked`), ...L.slice(Math.max(0, S.i - 60), S.i + 140).map((m) => {
    const i = L.indexOf(m), n = notes[m.id];
    const b = h('button', { class: `lab-item ${m === c ? 'cur' : ''} ${n?.mark ?? ''}`, onclick: () => { S.i = i; keep(); drawList(); play(); } }, h('span', { class: `lab-dot t-${m.type}` }), m.name, n?.mark === 'ok' ? ' ✓' : n?.mark === 'bad' ? ' ✗' : '');
    return b;
  }));
  listEl.querySelector('.cur')?.scrollIntoView({ block: 'nearest' });
}
const sel = (label, opts, key, after) => h('label', null, h('span', null, label), h('select', { onchange: (e) => { S[key] = e.target.value; keep(); after?.(); } }, opts.map(([v, l]) => h('option', { value: v, selected: String(S[key]) === String(v) }, l))));
const chk = (label, key) => h('label', { class: 'lab-chk' }, h('input', { type: 'checkbox', checked: !!S[key], onchange: (e) => { S[key] = e.target.checked; keep(); } }), label);
const types = [...new Set(ALL.map((m) => m.type))].sort();
const exportBtn = h('button', { onclick: () => {
  const lines = ALL.filter((m) => notes[m.id]?.mark === 'bad' || notes[m.id]?.text).map((m) => `- ${m.name}${notes[m.id].mark === 'bad' ? ' (needs work)' : notes[m.id].mark === 'ok' ? ' (ok)' : ''}: ${notes[m.id].text ?? ''}`);
  const txt = lines.length ? `Move lab notes:\n${lines.join('\n')}` : 'No notes yet.';
  navigator.clipboard?.writeText(txt).then(() => { exportBtn.textContent = 'Copied!'; setTimeout(() => { exportBtn.textContent = 'Copy my notes'; }, 1500); }, () => prompt('Your notes:', txt));
} }, 'Copy my notes');
const controls = h('div', { class: 'lab-controls' },
  h('input', { type: 'search', placeholder: 'Find a move…', value: S.q, oninput: (e) => { S.q = e.target.value.trim().toLowerCase(); S.i = 0; keep(); drawList(); drawInfo(); } }),
  sel('Type', [['', 'All'], ...types.map((t) => [t, t])], 'type', () => { S.i = 0; drawList(); drawInfo(); }),
  sel('Place', PLACES.map((p) => [p, p]), 'place', build),
  sel('Weather', WEATHERS, 'weather', play),
  sel('Hits (multi-hit moves)', [['auto', 'Average'], ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => [n, `${n}`])], 'hits'),
  sel('Magnitude', [4, 5, 6, 7, 8, 9, 10].map((n) => [n, `${n} (${MAG[n]} power)`]), 'mag'),
  sel('Graphics', [['potato', 'Potato'], ['low', 'Low'], ['medium', 'Medium'], ['high', 'High'], ['ultra', 'Ultra']], 'quality', build),
  sel('Target', ['Mew', 'Snorlax', 'Pikachu', 'Gyarados', 'Charizard', 'Onix', 'Wailord', 'Joltik'].map((n) => [n, n]), 'foe', build),
  h('div', { class: 'lab-row' }, chk('Miss', 'miss'), chk('Critical hit', 'crit')),
  h('div', { class: 'lab-row' }, h('button', { onclick: () => go(-1) }, '◀ Prev'), h('button', { class: 'primary', onclick: play }, '▶ Play again'), h('button', { onclick: () => go(1) }, 'Next ▶')),
  h('p', { class: 'dim' }, 'Keys: ← / → previous / next move (plays it), Space or Enter plays it again, 1 marks it right, 2 needs work.'),
  exportBtn);
document.body.append(h('div', { class: 'lab' }, h('div', { class: 'lab-side' }, h('h1', null, 'Move lab'), controls, listEl), h('div', { class: 'lab-main' }, stageBox, info)));
addEventListener('keydown', (e) => {
  if (/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName ?? '')) return;
  if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { e.preventDefault(); go(1); }
  else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { e.preventDefault(); go(-1); }
  else if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); play(); }
  else if (e.key === '1' || e.key === '2') { const m = cur(); if (!m) return; notes[m.id] = { ...(notes[m.id] ?? {}), mark: e.key === '1' ? 'ok' : 'bad' }; saveNotes(); drawInfo(); drawList(); }
});
build(); drawList(); drawInfo();
setTimeout(play, 1400);
