// What a build is: its version (version.json) and fingerprints of the parts an update file can't
// replace — the PC's runtime and boot loader, and the phone's native Android code. An update file
// only applies when those fingerprints match what is installed; otherwise a full build is needed.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');

function hashFiles(paths) {
  const h = crypto.createHash('sha256');
  const walk = (p) => {
    if (!fs.existsSync(p)) return;
    if (fs.statSync(p).isDirectory()) { for (const f of fs.readdirSync(p).sort()) walk(path.join(p, f)); return; }
    const rel = path.relative(root, p).replace(/\\/g, '/');
    h.update(rel);
    let data = fs.readFileSync(p);
    // the app's display name is set per person at build time; it doesn't change the code
    if (rel === 'mobile/capacitor.config.json') { const j = JSON.parse(data); delete j.appName; data = Buffer.from(JSON.stringify(j)); }
    h.update(data);
  };
  for (const p of paths) walk(path.join(root, p));
  return h.digest('hex').slice(0, 12);
}

export function buildInfo() {
  const v = JSON.parse(fs.readFileSync(path.join(root, 'version.json'), 'utf8'));
  const desktopPkg = JSON.parse(fs.readFileSync(path.join(root, 'desktop', 'package.json'), 'utf8'));
  const mobilePkg = JSON.parse(fs.readFileSync(path.join(root, 'mobile', 'package.json'), 'utf8'));
  return {
    version: v.version,
    built: new Date().toISOString(),
    // the PC: Electron's version and the boot loader
    pcNative: `${(desktopPkg.devDependencies?.electron ?? '').replace(/[^\d.]/g, '')}-${hashFiles(['desktop/boot.cjs'])}`,
    // the phone: Java code, resources, Android settings and Capacitor's version
    phoneNative: `${(mobilePkg.dependencies?.['@capacitor/android'] ?? '').replace(/[^\d.]/g, '')}-${hashFiles(['mobile/native', 'mobile/capacitor.config.json'])}`,
  };
}
