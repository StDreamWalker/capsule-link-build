// Builds an example creature with every attribute filled in (moves and PP, genes and effort,
// nickname, shiny, its own cry pitch, size, favourite places, toys, food and times of day, friends,
// clothes, a held item, 20 core memories and a full journal, plus the original game file it came
// from) and reports how many bytes it takes on a ball. For planning the ball's hardware.
//   node tools/example-monster.mjs            prints the report
//   node tools/example-monster.mjs --write    also writes docs/example-monster.json and .md
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';
import { createDefaultDataset, indexDataset, createCreature, makeEgg } from '../shared/engine/index.js';
import { encodeFullRecord, decodeFullRecord } from '../shared/engine/fullRecord.js';
import { toBase64 } from '../shared/engine/ndef.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const idx = indexDataset(createDefaultDataset());
const sp = idx.ds.species.find((s) => s.id === 'gloomoth') ?? idx.ds.species[0];
const day = 86400000, t0 = Date.UTC(2025, 3, 2, 7, 15);

const c = createCreature(idx, sp.id, { level: 58, seed: 4242, trainer: 'Ziggy', nickname: 'Moonbeam', metHow: 'Caught on a walk near the river at dusk', now: t0 });
c.shiny = true; c.shinyType = 'square';
c.pid = 0x8c3f12a7; c.ec = 0x5e19d0c4;
c.gender = 'female';
c.cryPitch = 1.5;
c.sizeScalar = 231; // XL
c.ball = '4';
c.ability = 'Shield Dust';
c.genes = { hp: 31, atk: 4, def: 30, spa: 31, spd: 29, spe: 31 };
c.effort = { hp: 4, atk: 0, def: 0, spa: 252, spd: 0, spe: 252 };
c.friendship = 255;
c.moves = c.moves.map((m, i) => ({ ...m, pp: Math.max(0, (idx.moves.get(m.id)?.pp ?? 10) - i * 3) }));
c.heldItemId = 'held-scarf'; c.heldItem = 'Choice Scarf';
c.walk.totalSteps = 1284330;
c.metLevel = 7; c.metAt = t0;
c.prefs = {
  'place:river': 9, 'place:park': 7, 'place:beach': 6, 'place:cemetery': 4, 'place:city-centre': -5,
  'toy:feather': 8, 'toy:ball': 5, 'toy:disc': -2, 'food:glow-berry': 10, 'food:honey-drop': 6, 'food:sun-biscuit': -3,
  'time:dusk': 8, 'time:night': 6, 'time:dawn': -4, 'weather:rain': 5, 'weather:fog': 7, 'activity:fetch': 6, 'activity:bath': -6,
  'clothes:clothes-bow': 7, 'env:water': 6,
};
c.bonds = { a1b2c3d4e5f60718: 96, '0f1e2d3c4b5a6978': 74, '1122334455667788': 61, '99aabbccddeeff00': 40, '0123456789abcdef': 18 };
c.clothes = [{ id: 'clothes-bow', fx: 0.62, fy: 0.12, s: 1 }, { id: 'clothes-specs', fx: 0.5, fy: 0.38, s: 0.75 }, { id: 'clothes-scarf', fx: 0.5, fy: 0.7, s: 1.25 }];
const CORE = [
  'Met Ziggy on a walk near the river at dusk.', 'Hatched a plan to sleep in the sock drawer. It worked.', 'Saw the sea for the first time.',
  'Won a first battle.', 'Found out how much they love Glow Berries.', 'Went past the old graveyard for the first time, unafraid.',
  'Rode in a car for the first time and watched the lights rush by.', 'Became friends with Pebbleton.', 'Changed with the weather for the first time, out on a walk.',
  'Got dressed up for the first time.', 'Climbed into the hills for the first time.', 'Won a link battle against Aiko.',
  'Walked 100,000 steps together.', 'Spent a whole stormy night curled up with Ziggy.', 'Found out how much they love the Feather wand.',
  'Became inseparable from their trainer.', 'Went underground for the first time.', 'Reached level 50.', 'Watched the sun come up from the summit.',
  'Walked 1,000,000 steps together.',
];
c.memories = CORE.map((text, i) => ({ t: t0 + i * 17 * day, text, core: true }));
c.journal = Array.from({ length: 20 }, (_, i) => ({ t: t0 + (300 + i) * day, text: ['Had a nap in a sunbeam.', 'Played with the bouncy ball.', 'Ate a Bramble Berry.', 'Got brushed.', 'Watched the rain.'][i % 5] }));
// it came over from a save editor: keep the original 344-byte file (the largest current format)
// (game files are encrypted, so they look random and don't compress)
const raw = new Uint8Array(344); let sd = 12345; for (let i = 0; i < raw.length; i++) { sd = (Math.imul(sd, 1103515245) + 12345) >>> 0; raw[i] = sd >>> 24; }
c.pk = { format: 'pk9', gen: 9, pid: c.pid, ec: c.ec, raw: toBase64(raw) };
void makeEgg;

const full = encodeFullRecord(idx, c);
const noGame = encodeFullRecord(idx, c, { gameData: false });
const withJournal = encodeFullRecord(idx, c, { journal: true });
const back = decodeFullRecord(full);
if (!back.ok || back.memories.length !== CORE.length || back.identity.pid !== c.pid) throw new Error('round trip failed');
const deflate = (b) => zlib.deflateRawSync(b, { level: 9 }).length;
const json = Buffer.from(JSON.stringify(c));
// NDEF overhead around a record: TLV (4) + long record header (6) + type (27) + app record (~37) + end (1)
const NDEF = 75;
const tags = [['NTAG213', 144], ['NTAG215', 504], ['NTAG216 / NTAG I2C plus 1k', 888], ['NTAG I2C plus 2k', 1912]];
const rows = [
  ['Today\'s tag record (summary: MAIN 128 + WALK 32)', 160, null],
  ['Full record without the original game file', noGame.length, deflate(noGame)],
  ['Full record with the original game file (344 B)', full.length, deflate(full)],
  ['Full record + game file + 20-entry journal', withJournal.length, deflate(withJournal)],
  ['Everything as JSON (what the PC keeps)', json.length, deflate(json)],
];
const fits = (n) => tags.filter(([, cap]) => n + NDEF <= cap).map(([name]) => name)[0] ?? 'none (needs the ball’s own memory)';
let report = `Example creature: ${c.nickname} (${sp.name}), Lv. ${c.level}, shiny (${c.shinyType}), ${c.memories.length} core memories, ${Object.keys(c.prefs).length} likes, ${Object.keys(c.bonds).length} friends, ${c.clothes.length} clothes\n\n`;
report += `| What | Bytes | Deflated | Smallest NFC tag that holds it (deflated, plus ~${NDEF} B of NDEF wrapping) |\n|---|---:|---:|---|\n`;
for (const [what, n, z] of rows) report += `| ${what} | ${n} | ${z ?? '—'} | ${fits(z ?? n)} |\n`;
console.log(report);
if (process.argv.includes('--write')) {
  const docs = path.join(here, '..', 'docs');
  fs.mkdirSync(docs, { recursive: true });
  fs.writeFileSync(path.join(docs, 'example-monster.json'), JSON.stringify(c, null, 1));
  fs.writeFileSync(path.join(docs, 'example-monster.md'), `# Example creature: how much space it takes on a ball\n\nMade by \`node tools/example-monster.mjs --write\`. The full record format is described in shared/engine/fullRecord.js.\n\n${report}\nTag user memory: ${tags.map(([n, b]) => `${n} ${b} B`).join(', ')}.\n`);
  console.log('Wrote docs/example-monster.json and docs/example-monster.md');
}
