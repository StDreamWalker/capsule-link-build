// Bakes a name and icon into the installable apps before they are built (used by the cloud build).
// Put branding/app-name.txt and/or branding/app-icon.png (square, 512×512 or larger) next to the
// project; anything missing keeps the defaults. At run time the apps also follow the names and
// pictures chosen in setup — this only covers what Windows and Android show before the app opens.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const dir = process.argv[2] ? path.resolve(process.argv[2]) : path.join(root, 'branding');
const nameFile = path.join(dir, 'app-name.txt');
const iconFile = path.join(dir, 'app-icon.png');
const name = fs.existsSync(nameFile) ? fs.readFileSync(nameFile, 'utf8').trim().slice(0, 40) : '';

if (name) {
  const capPath = path.join(root, 'mobile', 'capacitor.config.json');
  const cap = JSON.parse(fs.readFileSync(capPath, 'utf8'));
  cap.appName = name;
  fs.writeFileSync(capPath, `${JSON.stringify(cap, null, 2)}\n`);
  const pkgPath = path.join(root, 'desktop', 'package.json');
  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  pkg.productName = name;
  pkg.build.productName = name;
  fs.writeFileSync(pkgPath, `${JSON.stringify(pkg, null, 2)}\n`);
  console.log(`name: ${name}`);
}
if (fs.existsSync(iconFile)) {
  fs.copyFileSync(iconFile, path.join(root, 'desktop', 'assets', 'icon-512.png'));
  fs.copyFileSync(iconFile, path.join(root, 'desktop', 'assets', 'icon.png'));
  console.log('icon: desktop/assets updated (Android icons are resized by the build)');
}
