// Makes an update file: node tools/make-update.mjs [--notes "What changed"] [--out folder]
// Builds both apps and packs their own code (not the app engine, not anyone's data) into one
// small capsule-link-update-<version>.clupdate. Bump "version" in version.json first.
//
// The PC installs it (Settings → Updates, or drop it on the window) and runs it after a restart;
// linked phones are offered the phone part on their next sync. An update can only replace app
// code: if the PC's engine/boot loader or the phone's Android code changed (the fingerprints in
// buildinfo.mjs), the PC says a full download is needed for that side.
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { buildInfo } from './buildinfo.mjs';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const arg = (name) => { const i = process.argv.indexOf(name); return i > 0 ? process.argv[i + 1] : null; };
const notes = arg('--notes') ?? JSON.parse(fs.readFileSync(path.join(root, 'version.json'), 'utf8')).notes ?? '';
const outDir = path.resolve(arg('--out') ?? root);

for (const d of ['desktop', 'mobile']) execFileSync(process.execPath, ['build.mjs'], { cwd: path.join(root, d), stdio: 'inherit', env: process.env });

function collect(base, parts) {
  const files = {};
  const walk = (abs, rel) => {
    if (fs.statSync(abs).isDirectory()) { for (const f of fs.readdirSync(abs)) walk(path.join(abs, f), `${rel}/${f}`); return; }
    const data = fs.readFileSync(abs);
    files[rel.replace(/^\//, '')] = { sha256: crypto.createHash('sha256').update(data).digest('hex'), data: data.toString('base64') };
  };
  for (const p of parts) walk(path.join(base, p), p);
  return files;
}

const info = buildInfo();
const pkg = {
  format: 'capsule-link-update',
  version: info.version,
  built: info.built,
  notes,
  pcNative: info.pcNative,
  phoneNative: info.phoneNative,
  pc: { files: collect(path.join(root, 'desktop'), ['dist', 'assets']) },
  phone: { files: collect(path.join(root, 'mobile', 'www'), fs.readdirSync(path.join(root, 'mobile', 'www'))) },
};
const out = path.join(outDir, `capsule-link-update-${info.version}.clupdate`);
fs.writeFileSync(out, zlib.gzipSync(Buffer.from(JSON.stringify(pkg)), { level: 9 }));
console.log(`Wrote ${out} (${Math.round(fs.statSync(out).size / 1024)} KB): PC ${Object.keys(pkg.pc.files).length} files, phone ${Object.keys(pkg.phone.files).length} files.`);
