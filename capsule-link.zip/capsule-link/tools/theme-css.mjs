// Make "dark mode" follow a setting as well as the system: every
//   @media (prefers-color-scheme: dark) { A { … } }
// becomes
//   @media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) A { … } }   (system, unless set to light)
//   :root[data-theme="dark"] A { … }                                                 (set to dark)
// Run on a CSS file in place: node tools/theme-css.mjs file.css   (idempotent)
import fs from 'node:fs';
const file = process.argv[2];
let css = fs.readFileSync(file, 'utf8');
if (css.includes('/* themed */')) process.exit(0);
const out = [];
let i = 0;
const re = /@media \(prefers-color-scheme: dark\) \{/g;
let m;
let last = 0;
while ((m = re.exec(css))) {
  // find the matching closing brace
  let depth = 0, j = m.index + m[0].length - 1;
  for (; j < css.length; j++) { if (css[j] === '{') depth++; else if (css[j] === '}') { depth--; if (depth === 0) break; } }
  const inner = css.slice(m.index + m[0].length, j);
  const rules = [...inner.matchAll(/([^{}]+)\{([^{}]*)\}/g)].map(([, sel, body]) => ({ sel: sel.trim(), body }));
  const pre = (p, sel) => sel.split(',').map((s) => { s = s.trim(); return s.startsWith(':root') ? s.replace(':root', `:root${p}`) : `:root${p} ${s}`; }).join(', ');
  out.push(css.slice(last, m.index));
  out.push(`@media (prefers-color-scheme: dark) {\n${rules.map((r) => `  ${pre(':not([data-theme="light"])', r.sel)} {${r.body}}`).join('\n')}\n}\n`);
  out.push(rules.map((r) => `${pre('[data-theme="dark"]', r.sel)} {${r.body}}`).join('\n'));
  last = j + 1;
  i++;
}
out.push(css.slice(last));
fs.writeFileSync(file, `/* themed */\n${out.join('')}`);
console.log(`${file}: ${i} dark blocks themed`);
