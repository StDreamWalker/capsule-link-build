#!/usr/bin/env python3
"""Draws the Capsule Link app icon (pixel capsule on grape plastic) for desktop and Android."""
import os
from PIL import Image

POD = [
    '......########......',
    '....##........##....',
    '...#............#...',
    '..#..............#..',
    '..#..............#..',
    '.#................#.',
    '.#................#.',
    '.#................#.',
    '.#................#.',
    '.#................#.',
    '.#................#.',
    '.##################.',
    '.#RRRRRRRRRRRRRRRR#.',
    '.##################.',
    '.#BBBBBBBBBBBBBBBB#.',
    '.#BBBBBBBBBBBBBBBB#.',
    '.#BBBBBBBBBBBBBBBB#.',
    '..#BBBBBBBBBBBBBB#..',
    '..#BBBBBBBBBBBBBB#..',
    '...#BBBBBBBBBBBB#...',
    '....##BBBBBBBB##....',
    '......########......',
]
INK = (27, 24, 56, 255)
RING = (52, 209, 191, 255)
BODY = (74, 70, 112, 255)
GLASS = (200, 228, 255, 255)
GRAPE = (91, 69, 196, 255)
GRAPE_DARK = (58, 42, 138, 255)
SPROUT = [  # small creature peeking through the glass
    '...##...',
    '..#..#..',
    '.######.',
    '#.#..#.#',
    '########',
    '.######.',
]
SPROUT_C = (92, 191, 76, 255)


def art(with_bg=True, pad=6):
    w, h = 20 + pad * 2, 22 + pad * 2
    side = max(w, h)
    img = Image.new('RGBA', (side, side), GRAPE if with_bg else (0, 0, 0, 0))
    ox, oy = (side - 20) // 2, (side - 22) // 2
    px = img.load()
    if with_bg:
        for y in range(side):
            for x in range(side):
                if y > side * 0.62:
                    px[x, y] = GRAPE_DARK
    for j, row in enumerate(POD):
        a, b = row.find('#'), row.rfind('#')
        if 0 < j < 11:
            for i in range(a + 1, b):
                px[ox + i, oy + j] = GLASS
    for j, row in enumerate(SPROUT):
        for i, ch in enumerate(row):
            if ch == '#':
                px[ox + 6 + i, oy + 4 + j] = SPROUT_C if not (j == 3 and i in (2, 5)) else INK
    for j, row in enumerate(POD):
        for i, ch in enumerate(row):
            if ch == '#':
                px[ox + i, oy + j] = INK
            elif ch == 'R':
                px[ox + i, oy + j] = RING
            elif ch == 'B':
                px[ox + i, oy + j] = BODY
    px[ox + 4, oy + 3] = (255, 255, 255, 220)
    px[ox + 3, oy + 4] = (255, 255, 255, 160)
    return img


def scaled(img, size):
    return img.resize((size, size), Image.NEAREST)


if __name__ == '__main__':
    root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
    desk = os.path.join(root, 'desktop', 'assets')
    os.makedirs(desk, exist_ok=True)
    base = art(True, 6)
    scaled(base, 256).save(os.path.join(desk, 'icon.png'))
    scaled(base, 512).save(os.path.join(desk, 'icon-512.png'))
    # Android launcher icons (legacy + adaptive foreground)
    res = os.path.join(root, 'mobile', 'native', 'res')
    for dens, legacy, fg in [('mdpi', 48, 108), ('hdpi', 72, 162), ('xhdpi', 96, 216), ('xxhdpi', 144, 324), ('xxxhdpi', 192, 432)]:
        d = os.path.join(res, f'mipmap-{dens}')
        os.makedirs(d, exist_ok=True)
        scaled(base, legacy).save(os.path.join(d, 'ic_launcher.png'))
        scaled(base, legacy).save(os.path.join(d, 'ic_launcher_round.png'))
        # adaptive foreground: capsule centred in the 66% safe zone
        fgi = Image.new('RGBA', (fg, fg), (0, 0, 0, 0))
        inner = scaled(art(False, 2), int(fg * 0.62))
        fgi.paste(inner, ((fg - inner.width) // 2, (fg - inner.height) // 2), inner)
        fgi.save(os.path.join(d, 'ic_launcher_foreground.png'))
    # notification icon: white silhouette
    nd = os.path.join(res, 'drawable')
    os.makedirs(nd, exist_ok=True)
    sil = Image.new('RGBA', (24, 24), (0, 0, 0, 0))
    p = sil.load()
    for j, row in enumerate(POD):
        for i, ch in enumerate(row):
            if ch != '.' and 1 + j < 24:
                p[2 + i, 1 + j] = (255, 255, 255, 255)
    scaled(sil, 96).save(os.path.join(nd, 'ic_stat_capsule.png'))
    print('icons written')
