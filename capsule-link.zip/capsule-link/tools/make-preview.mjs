// Packs the two browser builds (desktop/dist-web and mobile/dist-web) into one page with a
// switcher, for sharing a clickable preview. Usage: node tools/make-preview.mjs <out.html>
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = process.argv[2] ?? path.join(root, 'preview.html');
const pc = fs.readFileSync(path.join(root, 'desktop/dist-web/index.html'), 'utf8');
const phone = fs.readFileSync(path.join(root, 'mobile/dist-web/index.html'), 'utf8');
const fontCss = fs.readFileSync(path.join(root, 'shared/ui/font/font.css'), 'utf8');
const attr = (s) => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;');

const page = `<title>Capsule Link</title>
<meta name="claude:viewport-fit-sides" content="cover">
<style>
${fontCss}
/* A neutral frame around each app, in the apps' own clean style. */
:root {
  --bg: #e9ecf4; --text: #16171c; --muted: #565b6b; --surface: #ffffff; --border: rgba(18,22,40,.12); --accent: #3b6cf6;
  --font: "Segoe UI Variable Text", "Segoe UI", system-ui, -apple-system, Roboto, "Inter", sans-serif;
  color-scheme: light dark;
}
@media (prefers-color-scheme: dark) { :root { --bg: #111217; --text: #f1f2f6; --muted: #a4a8b6; --surface: #202128; --border: rgba(255,255,255,.12); --accent: #6d92ff; } }
html, body { height: 100%; }
[hidden] { display: none !important; }
body {
  margin: 0; background: var(--bg); color: var(--text); font: 15px/22px var(--font);
  display: flex; flex-direction: column;
  padding-left: max(16px, env(safe-area-inset-left, 0px)); padding-right: max(16px, env(safe-area-inset-right, 0px));
}
header { display: flex; flex-wrap: wrap; align-items: center; gap: 8px 16px; padding-block: 12px 10px; }
.name { font-size: 18px; font-weight: 650; display: flex; align-items: center; gap: 10px; }
.led { width: 12px; height: 20px; border-radius: 6px; background: linear-gradient(180deg, #5b8cff 0 45%, #fff 45%); box-shadow: 0 0 0 1px var(--border); }
.switch { display: inline-flex; gap: 2px; padding: 3px; border-radius: 10px; background: var(--surface); border: 1px solid var(--border); }
.switch button { font: inherit; font-weight: 600; color: var(--muted); background: none; border: 0; border-radius: 8px; cursor: pointer; min-height: 34px; padding: 2px 14px; }
.switch button[aria-pressed="true"] { background: var(--accent); color: #fff; }
.switch button:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
.note { color: var(--muted); flex: 1 1 280px; min-width: 0; }
.stage { flex: 1; min-height: 0; display: flex; justify-content: center; align-items: flex-start; padding-block: 4px 16px; }
.pc { width: 100%; max-width: 1280px; overflow: hidden; border-radius: 14px; box-shadow: 0 20px 50px rgba(16,24,40,.22), 0 0 0 1px var(--border); background: var(--surface); }
.pc iframe { display: block; width: 1280px; height: 800px; border: 0; transform-origin: 0 0; }
.phone { width: min(390px, 100%); height: min(800px, 100%); border-radius: 44px; padding: 12px; background: #16171c; box-shadow: 0 20px 50px rgba(16,24,40,.3); display: flex; }
.phone iframe { flex: 1; width: 100%; border: 0; border-radius: 34px; background: var(--surface); }
@media (max-width: 520px) {
  .phone { width: 100%; height: 100%; padding: 0; border-radius: 0; box-shadow: none; background: none; }
  .phone iframe { border-radius: 0; }
  .note { display: none; }
}
</style>
<header>
  <div class="name"><span class="led" aria-hidden="true"></span>Capsule Link</div>
  <div class="switch" role="group" aria-label="Which app">
    <button id="show-pc" type="button" aria-pressed="false">PC app</button>
    <button id="show-phone" type="button" aria-pressed="false">Phone app</button>
  </div>
  <p class="note" id="note"></p>
</header>
<main class="stage" id="stage">
  <div class="pc" id="pc" hidden><iframe id="pc-frame" title="Capsule Link PC terminal" data-src="${attr(pc)}"></iframe></div>
  <div class="phone" id="phone" hidden><iframe id="phone-frame" title="Capsule Link phone app" data-src="${attr(phone)}"></iframe></div>
</main>
<script>
(function () {
  var notes = {
    pc: 'The PC app in your browser. The capsule dock runs on virtual capsules; USB and the phone link need the desktop app.',
    phone: 'The Android app with simulated NFC and steps. Use Start without a PC to pick a buddy.'
  };
  var stage = document.getElementById('stage');
  var pc = document.getElementById('pc'), phone = document.getElementById('phone');
  var pcFrame = document.getElementById('pc-frame'), phoneFrame = document.getElementById('phone-frame');
  function load(frame) { if (!frame.srcdoc && frame.dataset.src) { frame.srcdoc = frame.dataset.src; delete frame.dataset.src; } }
  function fitPc() {
    var w = pc.clientWidth || stage.clientWidth;
    var s = Math.min(1, w / 1280);
    pcFrame.style.transform = 'scale(' + s + ')';
    pc.style.height = Math.round(800 * s) + 'px';
  }
  function show(which) {
    var isPc = which === 'pc';
    pc.hidden = !isPc; phone.hidden = isPc;
    document.getElementById('show-pc').setAttribute('aria-pressed', String(isPc));
    document.getElementById('show-phone').setAttribute('aria-pressed', String(!isPc));
    document.getElementById('note').textContent = notes[which];
    load(isPc ? pcFrame : phoneFrame);
    if (isPc) fitPc();
    try { localStorage.setItem('capsule-link-preview:tab', which); } catch (e) { /* storage blocked */ }
  }
  document.getElementById('show-pc').addEventListener('click', function () { show('pc'); });
  document.getElementById('show-phone').addEventListener('click', function () { show('phone'); });
  window.addEventListener('resize', fitPc);
  var start = window.innerWidth < 760 ? 'phone' : 'pc';
  try { start = localStorage.getItem('capsule-link-preview:tab') || start; } catch (e) { /* storage blocked */ }
  show(start);
})();
</script>
`;
fs.writeFileSync(out, page);
console.log(`Wrote ${out} (${Math.round(page.length / 1024)} KB)`);
