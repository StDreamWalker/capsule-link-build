// Capsule Link — PC app main process.
// Owns the save file, runs the phone hub (WebSocket + LAN discovery), the desktop buddy
// window, and grants the dock's USB serial port to the renderer.
import { app, BrowserWindow, ipcMain, shell, dialog, screen, session, Menu, Tray, nativeImage, net } from 'electron';
import path from 'node:path';
import os from 'node:os';
import fs from 'node:fs';
import dgram from 'node:dgram';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { Store } from './storage.js';
import { createWsServer } from '../../../shared/net/wsserver.js';
import { Hub } from '../../../shared/net/hub.js';
import * as E from '../../../shared/engine/index.js';
import { backupFileName, summarize } from '../../../shared/engine/backup.js';
import { createHost } from './host.js';
import { startHostActivity, hostStatus } from './hostActivity.js';

const ROOT = path.join(__dirname, '..'); // desktop/
const PRELOAD = path.join(__dirname, 'preload.cjs');
const SD_PRELOAD = path.join(__dirname, 'showdown-preload.cjs');
const ICON = path.join(ROOT, 'assets', 'icon.png');

let store, hub, wsServer, hubPort = E.HUB_PORT;
let win = null, pet = null, tray = null, quitting = false;
let sdWin = null, sdConfig = {};
let beacon = null;
let textureCache = null;
let host = null; // hosting a home server from this PC (host.js)
const startHidden = process.argv.includes('--hidden');

// ---------- names and icon chosen in setup ----------
// Window titles, the tray, the phone-facing hub name and the app icon follow the names and
// pictures chosen in setup (textures/ui/app-icon.png for the icon, else the logo).
const T = (text) => E.brandRewriter(store?.dataset?.brand)(text);
function appIconPath() {
  // the app's own icon (textures/ui/app-icon.png) if one was made, else the Poké Ball's picture, else the logo
  for (const f of ['ui/app-icon.png', 'items/poke-ball.png', 'ui/logo.png']) {
    const p = store && path.join(store.textures, ...f.split('/'));
    if (p && fs.existsSync(p)) return p;
  }
  return ICON;
}
function appIcon() {
  const p = appIconPath();
  if (!fs.existsSync(p)) return nativeImage.createEmpty();
  const img = nativeImage.createFromPath(p);
  // a small pixel picture (the Poké Ball's item sprite) is blown up with hard edges, not blurred
  const { width: w, height: h } = img.getSize();
  if (!w || Math.max(w, h) >= 128) return img;
  const k = Math.max(1, Math.floor(256 / Math.max(w, h))), src = img.toBitmap(), out = Buffer.alloc(w * k * h * k * 4);
  for (let y = 0; y < h * k; y++) for (let x = 0; x < w * k; x++) src.copy(out, (y * w * k + x) * 4, ((Math.floor(y / k) * w) + Math.floor(x / k)) * 4, ((Math.floor(y / k) * w) + Math.floor(x / k)) * 4 + 4);
  return nativeImage.createFromBitmap(out, { width: w * k, height: h * k });
}

/** A Windows .ico holding PNG pictures (Vista and later read these). */
function pngToIco(img) {
  const sizes = [256, 64, 48, 32, 16];
  const pngs = sizes.map((s) => img.resize({ width: s, height: s, quality: 'best' }).toPNG());
  const head = Buffer.alloc(6 + 16 * sizes.length);
  head.writeUInt16LE(0, 0); head.writeUInt16LE(1, 2); head.writeUInt16LE(sizes.length, 4);
  let offset = head.length;
  sizes.forEach((s, i) => {
    const o = 6 + i * 16;
    head.writeUInt8(s >= 256 ? 0 : s, o); head.writeUInt8(s >= 256 ? 0 : s, o + 1);
    head.writeUInt8(0, o + 2); head.writeUInt8(0, o + 3);
    head.writeUInt16LE(1, o + 4); head.writeUInt16LE(32, o + 6);
    head.writeUInt32LE(pngs[i].length, o + 8); head.writeUInt32LE(offset, o + 12);
    offset += pngs[i].length;
  });
  return Buffer.concat([head, ...pngs]);
}

/** Start menu and desktop shortcuts with the chosen name and icon (Windows, installed or portable). */
function updateShortcuts() {
  if (process.platform !== 'win32' || !app.isPackaged) return;
  try {
    const name = T('Capsule Link').replace(/[<>:"/\\|?*]+/g, '').trim() || 'Capsule Link';
    const ico = path.join(app.getPath('userData'), 'app-icon.ico');
    fs.writeFileSync(ico, pngToIco(appIcon()));
    const marker = path.join(app.getPath('userData'), 'shortcuts.json');
    const prev = (() => { try { return JSON.parse(fs.readFileSync(marker, 'utf8')); } catch { return null; } })();
    const places = [path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs'), app.getPath('desktop')];
    for (const dir of places) {
      if (prev?.name && prev.name !== name) fs.rmSync(path.join(dir, `${prev.name}.lnk`), { force: true });
      // a desktop shortcut is made once; if it was deleted later, leave it deleted
      if (dir === places[1] && prev && !prev.desktop) continue;
      shell.writeShortcutLink(path.join(dir, `${name}.lnk`), 'replace', { target: process.execPath, icon: ico, iconIndex: 0, appUserModelId: 'com.capsulelink.desktop', description: name });
    }
    fs.writeFileSync(marker, JSON.stringify({ name, desktop: prev ? prev.desktop : true }));
  } catch (e) { console.error('shortcuts', e); }
}

function applyBranding() {
  const name = T('Capsule Link');
  const icon = appIcon();
  if (win && !win.isDestroyed()) { win.setTitle(name); if (!icon.isEmpty()) win.setIcon(icon); }
  if (sdWin && !sdWin.isDestroyed()) sdWin.setTitle(T('Showdown (Capsule Link)'));
  if (hub) hub.name = `${os.hostname()} (${name})`;
  if (tray) { tray.destroy(); tray = null; updateTray(); }
  updateShortcuts();
}

// ---------- updates by file ----------
// A .clupdate file is the app's own code (the PC part and the phone part), a few hundred KB.
// The PC part goes in the data folder and boot.cjs runs it on the next start; the phone part is
// handed to linked phones when they sync.
const UPDATES = () => path.join(app.getPath('userData'), 'app-update');
const BUILD = typeof __BUILD__ !== 'undefined' ? __BUILD__ : { version: '0.0.0' };
const readJsonFile = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
const builtInBuild = () => readJsonFile(path.join(global.capsuleBoot?.builtInRoot ?? ROOT, 'dist', 'version.json')) ?? BUILD;
let phoneUpdateCache;
function phoneUpdate() {
  if (phoneUpdateCache === undefined) phoneUpdateCache = readJsonFile(path.join(UPDATES(), 'phone.json'));
  return phoneUpdateCache;
}
function vNewer(a, b) {
  const pa = String(a ?? '0').split(/[.-]/).map(Number), pb = String(b ?? '0').split(/[.-]/).map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0; }
  return false;
}
function updateInfo() {
  return {
    running: BUILD,
    builtIn: builtInBuild(),
    active: global.capsuleBoot?.active ?? null,
    failed: readJsonFile(path.join(UPDATES(), 'failed.json')),
    phone: phoneUpdate() ? { version: phoneUpdate().version, phoneNative: phoneUpdate().phoneNative } : null,
    phones: hub ? [...hub.phoneApps.values()] : [],
  };
}
function installUpdate(bytes) {
  let pkg;
  try { pkg = JSON.parse(zlib.gunzipSync(Buffer.from(bytes)).toString('utf8')); } catch { throw new Error('That isn’t an update file (or it got damaged while downloading).'); }
  if (pkg?.format !== 'capsule-link-update') throw new Error('That isn’t an update file for this app.');
  const check = (part) => {
    for (const [rel, f] of Object.entries(part.files ?? {})) {
      if (rel.includes('..') || path.isAbsolute(rel)) throw new Error('The update file has a bad path in it.');
      if (crypto.createHash('sha256').update(Buffer.from(f.data, 'base64')).digest('hex') !== f.sha256) throw new Error('The update file is damaged (a file inside doesn’t match). Download it again.');
    }
  };
  const out = { version: pkg.version, notes: pkg.notes ?? '', pc: 'none', phone: 'none' };
  // whatever happens next, everyone's saves and the data set are kept as they are now
  try { out.backup = path.basename(store.keepBackup(`before-update-${pkg.version}`, { version: BUILD.version })); } catch (e) { console.error('Could not keep a backup before the update', e); }
  const dir = UPDATES();
  fs.mkdirSync(dir, { recursive: true });
  const here = builtInBuild();
  const running = global.capsuleBoot?.active?.version ?? here.version;
  if (pkg.pc?.files) {
    check(pkg.pc);
    if (pkg.pcNative !== here.pcNative) out.pc = 'full';
    else if (!vNewer(pkg.version, running)) out.pc = 'same';
    else {
      const target = path.join(dir, `pc-${pkg.version}`);
      fs.rmSync(target, { recursive: true, force: true });
      for (const [rel, f] of Object.entries(pkg.pc.files)) {
        if (!/^(dist|assets)\//.test(rel)) continue;
        fs.mkdirSync(path.dirname(path.join(target, rel)), { recursive: true });
        fs.writeFileSync(path.join(target, rel), Buffer.from(f.data, 'base64'));
      }
      fs.writeFileSync(path.join(dir, 'current.json'), JSON.stringify({ version: pkg.version, dir: `pc-${pkg.version}`, pcNative: pkg.pcNative, at: Date.now() }));
      fs.rmSync(path.join(dir, 'failed.json'), { force: true });
      // keep just this one and the one running now
      for (const d of fs.readdirSync(dir)) if (/^pc-/.test(d) && d !== `pc-${pkg.version}` && d !== global.capsuleBoot?.active?.dir) fs.rmSync(path.join(dir, d), { recursive: true, force: true });
      out.pc = 'installed';
    }
  }
  if (pkg.phone?.files) {
    check(pkg.phone);
    const cur = phoneUpdate();
    if (!cur || vNewer(pkg.version, cur.version)) {
      const files = Object.fromEntries(Object.entries(pkg.phone.files).map(([k, f]) => [k, f.data]));
      fs.writeFileSync(path.join(dir, 'phone.json'), JSON.stringify({ version: pkg.version, phoneNative: pkg.phoneNative, notes: pkg.notes ?? '', files }));
      phoneUpdateCache = undefined;
      out.phone = 'ready';
    } else out.phone = 'same';
  }
  return out;
}

if (process.platform === 'win32') app.setAppUserModelId('com.capsulelink.desktop');
if (!app.requestSingleInstanceLock()) app.quit();
app.on('second-instance', () => { if (win) { win.show(); win.focus(); } });

// transparent windows need this on some Linux desktops
if (process.platform === 'linux') app.commandLine.appendSwitch('enable-transparent-visuals');

function lanAddresses() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const a of list ?? []) if (a.family === 'IPv4' && !a.internal) out.push({ name, address: a.address });
  }
  return out;
}

function broadcast(channel, payload) {
  for (const w of BrowserWindow.getAllWindows()) if (!w.isDestroyed()) w.webContents.send(channel, payload);
}

function saveChanged(reason) {
  store.rev++;
  store.persist();
  broadcast('save:changed', { save: store.save, rev: store.rev, reason });
  refreshPet();
}

async function startHub() {
  hub = new Hub({
    mode: 'home',
    name: `${os.hostname()} (${T('Capsule Link')})`,
    getIdx: () => store.idx,
    getSave: () => store.save,
    onSaveChanged: (reason) => saveChanged(reason),
    getPhoneUpdate: () => phoneUpdate(),
    getDock: () => dockState,
    getCries: () => {
      if (!cryCache || Date.now() - cryCache.at > 15000) cryCache = { at: Date.now(), ...store.cryBundle() };
      return cryCache;
    },
    backups: {
      put: (device, backup) => store.keepPhoneBackup(device, backup),
      list: () => store.listBackups().filter((b) => b.kind === 'phone').slice(0, 30),
      get: (file) => { const t = store.readBackupFile(file); if (!/^capsule-link-phone-backup-/.test(path.basename(String(file)))) throw new Error('Only phone backups can be sent to a phone.'); return t; },
    },
    getTextures: () => {
      if (!textureCache || Date.now() - textureCache.at > 5000) textureCache = { at: Date.now(), ...store.textureBundle() };
      return textureCache;
    },
    log: (...a) => console.log('[hub]', ...a),
  });
  const origBroadcast = hub.broadcastChanged.bind(hub);
  hub.broadcastChanged = (reason, except) => { origBroadcast(reason, except); broadcast('hub:changed', hubInfo()); };
  for (let attempt = 0; attempt < 6; attempt++) {
    try {
      wsServer = createWsServer({
        port: hubPort,
        onConnection: (conn) => hub.attach(conn),
        onHttp: (req, res) => {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ app: 'capsule-link', name: hub.name, mode: 'home', v: E.PROTOCOL_VERSION }));
        },
      });
      await wsServer.ready;
      console.log(`[hub] listening on ${hubPort}`);
      break;
    } catch (e) {
      console.warn(`[hub] port ${hubPort} busy (${e.code}); trying ${hubPort + 2}`);
      hubPort += 2;
    }
  }
  startBeacon();
}

function startBeacon() {
  try {
    beacon = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    beacon.bind(() => {
      beacon.setBroadcast(true);
      const tick = () => {
        const msg = Buffer.from(JSON.stringify({ app: 'capsule-link', name: os.hostname(), port: hubPort, v: E.PROTOCOL_VERSION }));
        for (const a of lanAddresses()) {
          const parts = a.address.split('.');
          const bcast = `${parts[0]}.${parts[1]}.${parts[2]}.255`;
          beacon.send(msg, E.DISCOVERY_PORT, bcast, () => {});
        }
        beacon.send(msg, E.DISCOVERY_PORT, '255.255.255.255', () => {});
      };
      tick();
      setInterval(tick, 3000).unref();
    });
    beacon.on('error', (e) => console.warn('[beacon]', e.message));
  } catch (e) { console.warn('[beacon] off:', e.message); }
}

function hubInfo() {
  return { port: hubPort, pairCode: hub?.pairCode, localToken: hub?.localToken, ips: lanAddresses(), status: hub?.status() };
}

function createWindow() {
  win = new BrowserWindow({
    width: 1360, height: 860, minWidth: 1040, minHeight: 700,
    backgroundColor: '#3a2a8a', title: T('Capsule Link'), icon: appIconPath(),
    webPreferences: { preload: PRELOAD, contextIsolation: true, sandbox: false },
  });
  win.removeMenu();
  win.loadFile(path.join(ROOT, 'dist', 'renderer', 'index.html'));
  win.webContents.once('did-finish-load', () => global.capsuleBoot?.started?.());
  // links (data sources in the setup guide, docs) open in the normal browser
  win.webContents.setWindowOpenHandler(({ url: u }) => { if (/^https?:/.test(u)) shell.openExternal(u); return { action: 'deny' }; });
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.control && input.shift && input.key.toLowerCase() === 'i') win.webContents.toggleDevTools();
    if (input.type === 'keyDown' && input.key === 'F11') win.setFullScreen(!win.isFullScreen());
  });
  win.on('close', (e) => {
    // keep running in the tray while the desktop buddy is out, or while hosting the server
    if (!quitting && ((pet && !pet.isDestroyed()) || (host?.running && host.cfg.keepRunning))) { e.preventDefault(); win.hide(); }
  });
  win.on('closed', () => { win = null; });
}

// ---------- desktop buddy ----------
// The buddy's size (Settings, or the tray menu): a 1 m creature is PET_BASE screen pixels tall at
// size 1; others follow their own height. The strip is tall enough for the biggest one plus its menu.
let dockState = null; // what the PC's dock holds, for phones
let cryCache = null;
const PET_BASE = 56;
const PET_SIZES = [['Tiny', 0.4], ['Small', 0.7], ['Normal', 1], ['Big', 1.5], ['Huge', 2.2]];
const petSize = () => Math.max(0.25, Math.min(3, Number(store.save.settings.petSize) || 1));
// the buddies have the whole screen (above the taskbar): walkers keep to the bottom, fliers go anywhere
function petBounds() {
  const { workArea } = screen.getPrimaryDisplay();
  return { x: workArea.x, y: workArea.y, width: workArea.width, height: workArea.height };
}
const buddyUids = () => E.desktopBuddies(store.save);
let stopActivity = null, hostState = null;
function openPet() {
  if (pet && !pet.isDestroyed()) { refreshPet(); return; }
  pet = new BrowserWindow({
    ...petBounds(),
    transparent: true, frame: false, resizable: false, movable: false, alwaysOnTop: true,
    skipTaskbar: true, hasShadow: false, focusable: false, backgroundColor: '#00000000',
    // a tool window on Windows: other apps (browsers, video players) don't count it as covering them, so
    // they keep playing while you play with the buddies
    ...(process.platform === 'win32' ? { type: 'toolbar' } : {}),
    webPreferences: { preload: PRELOAD, contextIsolation: true, sandbox: false },
  });
  pet.setAlwaysOnTop(true, 'screen-saver');
  pet.setVisibleOnAllWorkspaces?.(true);
  pet.setIgnoreMouseEvents(true, { forward: true });
  pet.loadFile(path.join(ROOT, 'dist', 'pet', 'pet.html'));
  pet.on('closed', () => { pet = null; updateTray(); stopActivity?.(); stopActivity = null; });
  // music playing / a fullscreen video or game: the buddies react (notes, or they sit and watch with you)
  if (!stopActivity && store.save.settings.petNoticeActivity !== false) stopActivity = startHostActivity((st) => { hostState = st; if (pet && !pet.isDestroyed()) pet.webContents.send('pet:host', st); });
  pet.webContents.on('did-finish-load', () => { if (hostState) pet?.webContents.send('pet:host', hostState); });
  updateTray();
}
function closePet() { if (pet && !pet.isDestroyed()) pet.close(); pet = null; updateTray(); }
// creatures busy elsewhere for a while (an activity): they step off the desktop until they're done
const petBusy = new Set();
function petPayload() {
  const creatures = buddyUids().filter((uid) => !petBusy.has(uid)).map((uid) => store.save.creatures[uid]).filter(Boolean);
  return { creature: creatures[0] ?? null, creatures, dataset: store.dataset, textures: store.listTextures(), settings: store.save.settings };
}
function refreshPet() {
  if (!pet || pet.isDestroyed()) return;
  const s = store.save.settings;
  if (!s.petEnabled || !buddyUids().length) { closePet(); return; }
  const b = petBounds(), now = pet.getBounds();
  if (now.height !== b.height || now.y !== b.y || now.width !== b.width) pet.setBounds(b);
  pet.webContents.send('pet:data', petPayload());
  if (tray && tray.sizeShown !== petSize()) { tray.destroy(); tray = null; updateTray(); }
}
function syncPetWindow() {
  const s = store.save.settings;
  if (s.petEnabled && buddyUids().length) openPet(); else closePet();
}

function updateTray() {
  const petOut = pet && !pet.isDestroyed(), hosting = !!host?.running;
  if (!petOut && !hosting) { tray?.destroy(); tray = null; return; }
  if (tray && tray.hosting === hosting && tray.petOut === petOut) return;
  tray?.destroy();
  const img = appIcon().resize({ width: 16, height: 16 });
  tray = new Tray(img);
  tray.setToolTip(T(hosting ? `Capsule Link — hosting the server on port ${host.cfg.port}` : 'Capsule Link — your buddy is out'));
  tray.sizeShown = petSize(); tray.hosting = hosting; tray.petOut = petOut;
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: T('Open Capsule Link'), click: () => { if (!win) createWindow(); win.show(); win.focus(); } },
    { label: 'Buddy size', submenu: PET_SIZES.map(([label, v]) => ({ label, type: 'radio', checked: Math.abs(petSize() - v) < 0.01, click: () => { store.save.settings.petSize = v; saveChanged('pet'); } })) },
    { label: 'Put the buddies away', enabled: !!petOut, click: () => { store.save.settings.petEnabled = false; saveChanged('pet'); closePet(); } },
    { type: 'separator' },
    { label: hosting ? `Server running (port ${host.cfg.port}) — stop it` : 'Server stopped', enabled: hosting, click: () => host.stop() },
    { type: 'separator' },
    { label: 'Quit', click: () => { quitting = true; app.quit(); } },
  ]));
  tray.on('click', () => { if (!win) createWindow(); win.show(); });
}

// ---------- phone over a USB-C cable ----------
// `adb reverse` makes the phone's 127.0.0.1:47820 reach this PC's hub through the cable,
// so the phone links (and its simulated capsule docks) with no Wi-Fi at all.
const ADB_EXE = process.platform === 'win32' ? 'adb.exe' : 'adb';
function runCmd(cmd, args) {
  return new Promise((resolve) => execFile(cmd, args, { timeout: 8000, windowsHide: true }, (err, stdout, stderr) => resolve({ err, out: String(stdout || ''), errOut: String(stderr || '') })));
}
let adbPath = null;
async function findAdb() {
  if (adbPath) return adbPath;
  const home = os.homedir();
  const list = [
    ...['ANDROID_HOME', 'ANDROID_SDK_ROOT'].filter((v) => process.env[v]).map((v) => path.join(process.env[v], 'platform-tools', ADB_EXE)),
    path.join(store.dir, 'platform-tools', ADB_EXE),
    process.platform === 'win32' ? path.join(process.env.LOCALAPPDATA || '', 'Android', 'Sdk', 'platform-tools', ADB_EXE) : null,
    process.platform === 'darwin' ? path.join(home, 'Library', 'Android', 'sdk', 'platform-tools', ADB_EXE) : null,
    path.join(home, 'Android', 'Sdk', 'platform-tools', ADB_EXE),
    ADB_EXE, // on the PATH
  ].filter(Boolean);
  for (const c of list) {
    if (c !== ADB_EXE && !fs.existsSync(c)) continue;
    const r = await runCmd(c, ['version']);
    if (!r.err) { adbPath = c; return c; }
  }
  return null;
}
async function usbSetup() {
  const adb = await findAdb();
  if (!adb) return { ok: false, reason: 'adb', dataFolder: store.dir };
  const listed = await runCmd(adb, ['devices']);
  const devices = listed.out.split(/\r?\n/).slice(1).map((l) => l.trim().split(/\s+/)).filter((p) => p[0] && p[1]).map(([serial, state]) => ({ serial, state }));
  for (const d of devices) {
    if (d.state !== 'device') continue;
    const r = await runCmd(adb, ['-s', d.serial, 'reverse', `tcp:${E.HUB_PORT}`, `tcp:${hubPort}`]);
    d.linked = !r.err;
    if (r.err) d.error = (r.errOut || r.err.message).trim().split('\n')[0];
  }
  return { ok: devices.some((d) => d.linked), reason: devices.length ? null : 'nodevice', devices, adb };
}

// ---------- IPC ----------
let serialPick = null;
function registerIpc() {
  ipcMain.handle('app:load', () => ({
    save: store.save, rev: store.rev, dataset: store.dataset, textures: store.listTextures(),
    profiles: store.listProfiles(), activeProfile: store.activeId,
    hub: hubInfo(), paths: { data: store.dir, textures: store.textures }, version: app.getVersion(), platform: process.platform,
  }));
  // profiles: one save per trainer, chosen on the log-on screen
  ipcMain.handle('profiles:list', () => store.listProfiles());
  ipcMain.handle('profiles:create', (_e, { name, card } = {}) => {
    const id = store.createProfile({ name, card });
    return { id, profiles: store.listProfiles() };
  });
  ipcMain.handle('profiles:open', (_e, id) => {
    if (id !== store.activeId) {
      store.openProfile(id);
      hub?.dropPhones();
      for (const w of BrowserWindow.getAllWindows()) if (w !== win && !w.isDestroyed()) w.webContents.send('save:changed', { save: store.save, rev: store.rev, reason: 'profile' });
      syncPetWindow(); refreshPet();
      broadcast('hub:changed', hubInfo());
    } else {
      store.save.settings.lastLogin = Date.now();
      store.persist();
    }
    return { save: store.save, rev: store.rev, id: store.activeId };
  });
  ipcMain.handle('profiles:delete', (_e, id) => {
    store.deleteProfile(id);
    return { profiles: store.listProfiles(), active: store.activeId, save: store.save, rev: store.rev };
  });
  ipcMain.handle('save:commit', (_e, { save, baseRev, reason }) => {
    if (baseRev !== store.rev) return { conflict: true, save: store.save, rev: store.rev };
    store.setSave(save);
    for (const w of BrowserWindow.getAllWindows()) if (w !== win && !w.isDestroyed()) w.webContents.send('save:changed', { save: store.save, rev: store.rev, reason });
    syncPetWindow(); refreshPet();
    return { ok: true, rev: store.rev };
  });
  ipcMain.handle('dataset:save', (_e, ds) => {
    store.setDataset(ds);
    broadcast('dataset:changed', { dataset: store.dataset, hash: store.idx.hash });
    refreshPet();
    applyBranding();
    return { ok: true, hash: store.idx.hash };
  });
  ipcMain.handle('textures:list', () => store.listTextures());
  ipcMain.handle('textures:open', () => shell.openPath(store.textures));
  ipcMain.handle('textures:import', (_e, { path: rel, data }) => {
    const list = store.importTexture(rel, data);
    textureCache = null;
    broadcast('textures:changed', list);
    return list;
  });
  ipcMain.handle('textures:importMany', (_e, files) => {
    const r = store.importTextures(Array.isArray(files) ? files : []);
    textureCache = null;
    broadcast('textures:changed', r.list);
    if ((files ?? []).some((f) => /^ui\/(app-icon|logo)\.png$/i.test(f.path))) applyBranding();
    return r;
  });
  ipcMain.handle('data:open', () => shell.openPath(store.dir));
  ipcMain.handle('update:info', () => updateInfo());
  ipcMain.handle('update:install', (_e, bytes) => installUpdate(bytes));
  ipcMain.handle('update:revert', () => { fs.rmSync(path.join(UPDATES(), 'current.json'), { force: true }); return updateInfo(); });
  ipcMain.handle('app:restart', () => { app.relaunch(); app.exit(0); });
  // downloads for the setup guide (data files, sprites): done here so no browser rules get in the way
  ipcMain.handle('net:fetch', async (_e, { url: u, as = 'text' } = {}) => {
    if (!/^https?:\/\//i.test(String(u))) throw new Error('Only web addresses can be downloaded.');
    // Chromium's own networking: same proxy and certificate settings as the computer's browser
    let r;
    try { r = await net.fetch(u, { redirect: 'follow', headers: { 'user-agent': 'CapsuleLink/1.0 (personal app)' } }); }
    catch { throw new Error(`couldn’t reach ${new URL(u).host} — check the internet connection`); }
    const out = { ok: r.ok, status: r.status, type: r.headers.get('content-type') ?? '', url: r.url };
    if (!r.ok) return out;
    if (as === 'bytes') out.bytes = new Uint8Array(await r.arrayBuffer());
    else out.text = await r.text();
    return out;
  });
  ipcMain.handle('hub:info', () => hubInfo());
  // hosting the home server from this PC
  ipcMain.handle('host:status', () => host.status());
  ipcMain.handle('host:start', () => host.start());
  ipcMain.handle('host:stop', () => host.stop());
  ipcMain.handle('host:configure', async (_e, patch) => { try { return await host.configure(patch); } catch (e) { return { ...host.status(), error: e.message }; } });
  ipcMain.handle('host:forward', () => host.retryForward());
  ipcMain.handle('host:check', () => host.checkReach());
  ipcMain.handle('host:firewall', () => host.allowFirewall());
  ipcMain.handle('usb:setup', () => usbSetup());
  ipcMain.handle('hub:newCode', () => { hub.pairCode = String(Math.floor(100000 + Math.random() * 900000)); return hubInfo(); });
  ipcMain.handle('hub:forget', (_e, deviceId) => { delete store.save.devices[deviceId]; saveChanged('devices'); return hubInfo(); });
  // full backups (Settings → Backups)
  ipcMain.handle('backup:export', async (_e, { textures = true } = {}) => {
    const b = store.fullBackup({ textures, version: BUILD.version });
    const r = await dialog.showSaveDialog(win, { defaultPath: path.join(app.getPath('documents'), backupFileName('pc')), filters: [{ name: 'Backup', extensions: ['json'] }] });
    if (r.canceled || !r.filePath) return { ok: false };
    fs.writeFileSync(r.filePath, JSON.stringify(b));
    return { ok: true, path: r.filePath, summary: summarize(b) };
  });
  ipcMain.on('dock:state', (_e, d) => { dockState = d ?? null; hub?.broadcastChanged?.('dock'); });
  ipcMain.handle('backup:list', () => store.listBackups());
  ipcMain.handle('backup:copy', async (_e, file) => {
    const text = store.readBackupFile(file);
    const r = await dialog.showSaveDialog(win, { defaultPath: path.join(app.getPath('documents'), path.basename(file)), filters: [{ name: 'Backup', extensions: ['json'] }] });
    if (r.canceled || !r.filePath) return { ok: false };
    fs.writeFileSync(r.filePath, text);
    return { ok: true, path: r.filePath };
  });
  ipcMain.handle('backup:read', (_e, file) => store.readBackupFile(file));
  ipcMain.handle('backup:restore', (_e, text) => {
    const r = store.restoreBackup(text, { version: BUILD.version });
    applyBranding();
    syncPetWindow(); refreshPet();
    hub?.broadcastChanged?.('restore');
    // the window starts over on the restored data
    setTimeout(() => win?.webContents.reload(), 50);
    return r;
  });
  ipcMain.handle('file:export', async (_e, { name, text }) => {
    const r = await dialog.showSaveDialog(win, { defaultPath: name });
    if (r.canceled || !r.filePath) return { ok: false };
    fs.writeFileSync(r.filePath, text);
    return { ok: true, path: r.filePath };
  });
  ipcMain.handle('file:import', async (_e, { filters } = {}) => {
    const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters });
    if (r.canceled || !r.filePaths[0]) return null;
    return { name: path.basename(r.filePaths[0]), text: fs.readFileSync(r.filePaths[0], 'utf8') };
  });
  // desktop buddy
  ipcMain.handle('pet:data', () => petPayload());
  ipcMain.on('pet:mouse', (_e, over) => { if (pet && !pet.isDestroyed()) pet.setIgnoreMouseEvents(!over, { forward: true }); });
  ipcMain.handle('pet:care', (_e, { action, item, uid }) => {
    const c = store.save.creatures[uid ?? store.save.settings.petUid];
    if (!c) return null;
    const out = E.applyCare(store.idx, c, action, { item, inventory: store.save.inventory });
    saveChanged('pet-care');
    return out;
  });
  // something a buddy found lying around on the desktop
  ipcMain.handle('pet:gift', (_e, { uid, found } = {}) => {
    // brought back from a trip off-screen: like a find on a walk (coins, berries, something shiny)
    if (found) {
      const f = E.walkFind(store.idx, Math.random);
      const c = uid && store.save.creatures[uid];
      let name;
      if (f.coins) { E.earn(store.save, f.coins); name = `${f.coins} coins`; }
      else { store.save.inventory[f.item] = (store.save.inventory[f.item] ?? 0) + 1; name = E.itemInfo(store.idx, f.item)?.name ?? 'something'; }
      if (c && !c.firsts?.deskTrip) { c.firsts = { ...(c.firsts || {}), deskTrip: Date.now() }; E.addMemory(c, `Went exploring off the edge of the desktop and came back with ${name}.`, Date.now(), { core: false }); }
      saveChanged('pet-gift');
      return { name, color: null };
    }
    const foods = (store.dataset.items ?? []).filter((i) => i.kind === 'food' && !i.unlimited);
    const pool = [...foods, ...foods.filter((i) => i.grow)];
    const it = pool[Math.floor(Math.random() * pool.length)];
    if (!it) return null;
    store.save.inventory[it.id] = (store.save.inventory[it.id] ?? 0) + 1;
    E.earn(store.save, 5);
    const c = uid && store.save.creatures[uid];
    if (c && !c.firsts?.deskFind) { c.firsts = { ...(c.firsts || {}), deskFind: Date.now() }; E.addMemory(c, `Found a ${it.name} lying around on the desktop.`, Date.now(), { core: false }); }
    saveChanged('pet-gift');
    return { item: it.id, name: it.name, color: it.color ?? null };
  });
  ipcMain.handle('pet:form', (_e, { uid, form }) => {
    const c = store.save.creatures[uid];
    if (!c) return { ok: false };
    const r = E.setForm(store.idx, c, form);
    saveChanged('pet-form');
    return r;
  });
  // evolve / Mega Evolve / change form from the desktop pet's menu (only what they can do; the rest greyed)
  ipcMain.handle('host:activity', () => ({ ...hostStatus, running: !!stopActivity, platform: process.platform }));
  ipcMain.handle('pet:changes', (_e, { uid }) => { const c = store.save.creatures[uid]; return c ? E.changeOptions(store.idx, store.save, c) : []; });
  ipcMain.handle('pet:change', (_e, { uid, key }) => {
    const r = E.applyChange(store.idx, store.save, uid, key);
    if (r.ok) saveChanged('pet-change');
    return { ok: r.ok, reason: r.reason, text: r.text, kind: r.kind };
  });
  ipcMain.on('pet:open-app', () => { if (!win) createWindow(); win.show(); win.focus(); });
  ipcMain.on('pet:size', (_e, v) => { store.save.settings.petSize = Math.max(0.25, Math.min(3, Number(v) || 1)); saveChanged('pet'); });
  // friends' Data Labs kept as presets (one file each), so visiting them again needs no download
  const PRESETS = () => path.join(app.getPath('userData'), 'capsule-link', 'datalab-presets');
  const presetFile = (name) => path.join(PRESETS(), `${String(name).toLowerCase().replace(/[^a-z0-9._-]+/g, '-').slice(0, 60)}.json`);
  ipcMain.handle('presets:list', () => {
    try { return fs.readdirSync(PRESETS()).filter((f) => f.endsWith('.json')).map((f) => { try { const j = JSON.parse(fs.readFileSync(path.join(PRESETS(), f), 'utf8')); return { name: j.name, label: j.label, hash: j.hash, at: j.at, species: j.dataset?.species?.length ?? 0 }; } catch { return null; } }).filter(Boolean); } catch { return []; }
  });
  ipcMain.handle('presets:save', (_e, p) => { fs.mkdirSync(PRESETS(), { recursive: true }); fs.writeFileSync(presetFile(p.name), JSON.stringify({ ...p, at: Date.now() })); return { ok: true }; });
  ipcMain.handle('presets:load', (_e, name) => { try { return JSON.parse(fs.readFileSync(presetFile(name), 'utf8')); } catch { return null; } });
  ipcMain.handle('presets:delete', (_e, name) => { try { fs.unlinkSync(presetFile(name)); } catch { /* gone */ } return { ok: true }; });
  ipcMain.on('pet:busy', (_e, { uid, on } = {}) => { if (!uid) return; if (on) petBusy.add(uid); else petBusy.delete(uid); refreshPet(); });
  ipcMain.on('pet:away', (_e, uid) => {
    if (uid) E.toggleBuddy(store.save, uid, false); else store.save.settings.petEnabled = false;
    saveChanged('pet');
    if (!store.save.settings.petEnabled) closePet(); else refreshPet();
  });
  // Showdown window: the real Showdown site, with the bridge script watching its connection
  ipcMain.handle('showdown:open', (_e, { url, config }) => {
    sdConfig = config || {};
    const target = /^https?:\/\//i.test(url || '') ? url : E.SHOWDOWN_DEFAULTS.server;
    if (sdWin && !sdWin.isDestroyed()) {
      const sameSite = (() => { try { return new URL(sdWin.webContents.getURL()).host === new URL(target).host; } catch { return false; } })();
      if (sameSite) sdWin.webContents.executeJavaScript(E.bridgeScript(sdConfig)).catch(() => {});
      else sdWin.loadURL(target);
      sdWin.show(); sdWin.focus();
      return true;
    }
    sdWin = new BrowserWindow({
      width: 1280, height: 860, title: T('Showdown (Capsule Link)'), backgroundColor: '#3a2a8a', icon: appIconPath(),
      webPreferences: { preload: SD_PRELOAD, contextIsolation: true, sandbox: true, partition: 'persist:showdown' },
    });
    sdWin.removeMenu();
    sdWin.webContents.setWindowOpenHandler(({ url: u }) => {
      // replays and other Showdown pages open in the same window; anything else in the browser
      if (/pokemonshowdown\.com|psim\.us/.test(u)) { sdWin.loadURL(u); } else shell.openExternal(u);
      return { action: 'deny' };
    });
    sdWin.on('closed', () => { sdWin = null; });
    sdWin.loadURL(target);
    return true;
  });
  ipcMain.on('showdown:script', (e) => { e.returnValue = E.bridgeScript(sdConfig); });
  ipcMain.on('showdown:post', (e, json) => {
    if (!sdWin || sdWin.isDestroyed() || e.sender !== sdWin.webContents) return;
    let msg;
    try { msg = JSON.parse(json); } catch { return; }
    if (!msg || typeof msg.type !== 'string') return;
    if (msg.type === 'battle' && (!win || win.isDestroyed())) { createWindow(); }
    const deliver = () => win?.webContents.send('showdown:event', msg);
    if (win?.webContents.isLoading()) win.webContents.once('did-finish-load', () => setTimeout(deliver, 1500)); else deliver();
  });
  ipcMain.handle('showdown:fetch', async (_e, url) => {
    if (!/^https?:\/\//i.test(String(url))) throw new Error('Only web links can be loaded.');
    const r = await fetch(url, { headers: { 'User-Agent': 'CapsuleLink/0.1' } });
    if (!r.ok) throw new Error(`The replay server answered ${r.status}.`);
    return r.text();
  });
  // dock serial port choice
  ipcMain.on('serial:chosen', (_e, portId) => { serialPick?.(portId || ''); serialPick = null; });
}

function serialPermissions() {
  const ses = session.defaultSession;
  ses.on('select-serial-port', (event, portList, webContents, callback) => {
    event.preventDefault();
    if (!portList.length) { callback(''); return; }
    serialPick = callback;
    webContents.send('serial:choose', portList.map((p) => ({ portId: p.portId, name: p.displayName || p.portName, vendorId: p.vendorId, productId: p.productId })));
  });
  ses.setPermissionCheckHandler((_wc, permission) => permission === 'serial' || permission === 'notifications' || permission === 'media');
  ses.setDevicePermissionHandler((details) => details.deviceType === 'serial');
}

app.whenReady().then(async () => {
  store = new Store(path.join(app.getPath('userData'), 'capsule-link')).load();
  host = createHost({ dir: store.dir, onChange: (st) => { updateTray(); if (win && !win.isDestroyed()) win.webContents.send('host:status', st); } });
  registerIpc();
  serialPermissions();
  await startHub();
  createWindow();
  if (host.cfg.autoStart) host.start().catch(() => {});
  // started with the computer to host the server: stay in the tray
  if (startHidden && host.cfg.autoStart) win.once('ready-to-show', () => win.hide());
  applyBranding();
  syncPetWindow();
  // needs keep moving while the app is open
  setInterval(() => { E.tickAll(store.idx, store.save); }, 5 * 60 * 1000).unref();
});

app.on('before-quit', () => { quitting = true; store?.writeNow(); host?.stop().catch(() => {}); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (!win) createWindow(); });
