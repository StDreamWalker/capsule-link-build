// Save/dataset files in the app's data folder, written atomically with rolling backups.
import fs from 'node:fs';
import path from 'node:path';
import * as E from '../../../shared/engine/index.js';
import { starterSave } from './storage-starter.js';
import { makeBackup, backupFileName, readBackup, summarize } from '../../../shared/engine/backup.js';

export { starterSave };

export const TEXTURE_DIRS = ['creatures', 'ranch', 'boxes', 'battle', 'ui', 'trainers', 'cries'];
// cries/ holds sounds; everything else is pictures
const fileOk = (dir, f) => (dir === 'cries' ? /\.(mp3|ogg|wav)$/i : /\.png$/i).test(f);

export class Store {
  constructor(dir) {
    this.dir = dir;
    this.files = {
      legacySave: path.join(dir, 'save.json'),
      dataset: path.join(dir, 'dataset.json'),
      profiles: path.join(dir, 'profiles.json'),
    };
    this.profileDir = path.join(dir, 'profiles');
    this.textures = path.join(dir, 'textures');
    this.backups = path.join(dir, 'backups');
    this.rev = 1;
    this.timer = null;
    this.profiles = { active: null, order: [] };
  }

  load() {
    fs.mkdirSync(this.dir, { recursive: true });
    fs.mkdirSync(this.backups, { recursive: true });
    fs.mkdirSync(this.profileDir, { recursive: true });
    for (const d of TEXTURE_DIRS) fs.mkdirSync(path.join(this.textures, d), { recursive: true });
    const readme = path.join(this.textures, 'README.txt');
    if (!fs.existsSync(readme) || fs.readFileSync(readme, 'utf8') !== TEXTURE_README) fs.writeFileSync(readme, TEXTURE_README);
    this.dataset = readJson(this.files.dataset) ?? E.createDefaultDataset();
    if (!fs.existsSync(this.files.dataset)) writeAtomic(this.files.dataset, JSON.stringify(this.dataset, null, 1));
    this.idx = E.indexDataset(this.dataset);
    this.dataset = this.idx.ds;
    this.profiles = readJson(this.files.profiles) ?? { active: null, order: [] };
    this.profiles.order = (this.profiles.order ?? []).filter((id) => fs.existsSync(this.profileFile(id)));
    // a save from before profiles becomes the first profile
    if (fs.existsSync(this.files.legacySave)) {
      const old = readJson(this.files.legacySave);
      if (old) {
        const id = E.randomId(8);
        writeAtomic(this.profileFile(id), JSON.stringify(old));
        this.profiles.order.unshift(id);
        this.profiles.active = id;
      }
      fs.renameSync(this.files.legacySave, path.join(this.backups, 'save-before-profiles.json'));
    }
    if (!this.profiles.order.length) this.createProfile({ name: 'Trainer' }, { open: true });
    if (!this.profiles.order.includes(this.profiles.active)) this.profiles.active = this.profiles.order[0];
    this.writeIndex();
    this.openProfile(this.profiles.active);
    return this;
  }

  profileFile(id) { return path.join(this.profileDir, `${String(id).replace(/[^\w-]/g, '')}.json`); }
  get activeId() { return this.profiles.active; }
  writeIndex() { writeAtomic(this.files.profiles, JSON.stringify(this.profiles, null, 1)); }

  /** Who can log on: name, ID card and a few numbers, read from each profile's save. */
  listProfiles() {
    return this.profiles.order.map((id) => {
      const sv = id === this.profiles.active && this.save ? this.save : readJson(this.profileFile(id));
      if (!sv) return null;
      const creatures = Object.values(sv.creatures ?? {});
      return {
        id, trainer: sv.trainer, creatures: creatures.length,
        steps: sv.stats?.totalSteps ?? 0, lastUsed: sv.settings?.lastLogin ?? null, active: id === this.profiles.active,
        party: creatures.filter((c) => c.location?.kind === 'party').sort((a, b) => a.location.slot - b.location.slot).slice(0, 6).map((c) => c.speciesId),
      };
    }).filter(Boolean);
  }

  createProfile({ name = 'Trainer', card = null } = {}, { open = false } = {}) {
    const id = E.randomId(8);
    const save = starterSave(this.idx, String(name).slice(0, 12) || 'Trainer');
    if (card) save.trainer.card = card;
    writeAtomic(this.profileFile(id), JSON.stringify(save));
    this.profiles.order.push(id);
    if (open) this.profiles.active = id;
    this.writeIndex();
    return id;
  }

  openProfile(id) {
    if (this.save && this.profiles.active && this.profiles.active !== id) this.writeNow();
    const save = readJson(this.profileFile(id));
    if (!save) throw new Error('That profile could not be read.');
    this.profiles.active = id;
    this.save = save;
    migrate(this.save);
    E.tickAll(this.idx, this.save);
    this.save.settings.lastLogin = Date.now();
    this.rev++;
    this.writeIndex();
    this.writeNow();
    this.dailyBackup();
    return this.save;
  }

  deleteProfile(id) {
    if (this.profiles.order.length <= 1) throw new Error('The last profile cannot be deleted.');
    const file = this.profileFile(id);
    if (fs.existsSync(file)) fs.renameSync(file, path.join(this.backups, `deleted-${id}-${Date.now()}.json`));
    this.profiles.order = this.profiles.order.filter((x) => x !== id);
    if (this.profiles.active === id) { this.save = null; this.openProfile(this.profiles.order[0]); }
    this.writeIndex();
  }

  setDataset(ds) {
    this.idx = E.indexDataset(ds);
    this.dataset = this.idx.ds;
    writeAtomic(this.files.dataset, JSON.stringify(this.dataset, null, 1));
  }

  setSave(save) {
    this.save = save;
    this.rev++;
    this.persist();
  }

  persist() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.writeNow(), 250);
  }

  writeNow() {
    clearTimeout(this.timer);
    if (this.save && this.profiles.active) writeAtomic(this.profileFile(this.profiles.active), JSON.stringify(this.save));
  }

  dailyBackup() {
    const day = new Date().toISOString().slice(0, 10);
    const id = this.profiles.active;
    const target = path.join(this.backups, `save-${id}-${day}.json`);
    if (!fs.existsSync(target) && fs.existsSync(this.profileFile(id))) fs.copyFileSync(this.profileFile(id), target);
    const old = fs.readdirSync(this.backups).filter((f) => f.startsWith(`save-${id}-`)).sort();
    for (const f of old.slice(0, Math.max(0, old.length - 14))) fs.rmSync(path.join(this.backups, f), { force: true });
  }

  // ---------- full backups ----------
  /** Everything in one object: every trainer profile, the data set and (optionally) textures. */
  fullBackup({ textures = true, version, reason } = {}) {
    this.writeNow();
    const saves = {};
    for (const id of this.profiles.order) {
      const sv = id === this.profiles.active ? this.save : readJson(this.profileFile(id));
      if (sv) saves[id] = sv;
    }
    const parts = { profiles: { active: this.profiles.active, order: [...this.profiles.order], saves }, dataset: this.dataset };
    if (textures) {
      parts.textures = {};
      for (const d of TEXTURE_DIRS) {
        const dir = path.join(this.textures, d);
        if (!fs.existsSync(dir)) continue;
        for (const f of fs.readdirSync(dir)) if (/\.png$/i.test(f)) parts.textures[`${d}/${f.toLowerCase()}`] = fs.readFileSync(path.join(dir, f)).toString('base64');
      }
    }
    return makeBackup('pc', version, parts, { reason });
  }

  /** Keep a full backup in the backups folder (before an update or a restore). Keeps the last 12. */
  keepBackup(label, opts = {}) {
    const file = path.join(this.backups, backupFileName('pc', label));
    writeAtomic(file, JSON.stringify(this.fullBackup({ textures: false, ...opts, reason: label })));
    const kept = fs.readdirSync(this.backups).filter((f) => f.startsWith('capsule-link-pc-backup-')).sort((a, b) => fs.statSync(path.join(this.backups, a)).mtimeMs - fs.statSync(path.join(this.backups, b)).mtimeMs);
    for (const f of kept.slice(0, Math.max(0, kept.length - 12))) fs.rmSync(path.join(this.backups, f), { force: true });
    return file;
  }

  /** Keep a phone's backup (sent over the link). The last 10 per phone are kept. */
  keepPhoneBackup(device, backup) {
    const r = readBackup(backup);
    if (!r.ok || r.kind !== 'phone') throw new Error(r.error ?? 'That is not a phone backup.');
    const who = String(device || 'phone').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24) || 'phone';
    const name = backupFileName('phone', who);
    writeAtomic(path.join(this.backups, name), JSON.stringify(backup));
    const mine = fs.readdirSync(this.backups).filter((f) => f.startsWith(`capsule-link-phone-backup-${who}-`)).sort();
    for (const f of mine.slice(0, Math.max(0, mine.length - 10))) fs.rmSync(path.join(this.backups, f), { force: true });
    return name;
  }

  /** Backups in the backups folder, newest first: { file, kind, size, at, summary }. */
  listBackups() {
    const out = [];
    for (const f of fs.readdirSync(this.backups)) {
      if (!/\.json$/i.test(f)) continue;
      const full = path.join(this.backups, f);
      const st = fs.statSync(full);
      let kind = 'save', summary = '';
      if (f.startsWith('capsule-link-pc-backup-')) kind = 'pc';
      else if (f.startsWith('capsule-link-phone-backup-')) kind = 'phone';
      if (kind !== 'save' || st.size < 4e6) {
        const r = readBackup(readJson(full));
        if (!r.ok) continue;
        kind = r.kind; summary = r.summary;
        if (kind === 'pc' && r.backup.reason && r.backup.reason !== 'by hand') summary += ` — kept automatically (${r.backup.reason.replace(/-/g, ' ')})`;
      }
      out.push({ file: f, kind, size: st.size, at: st.mtimeMs, summary: summary || 'One trainer\'s daily save' });
    }
    return out.sort((a, b) => b.at - a.at);
  }

  readBackupFile(file) {
    const full = path.join(this.backups, path.basename(String(file)));
    if (!fs.existsSync(full)) throw new Error('That backup is not there any more.');
    return fs.readFileSync(full, 'utf8');
  }

  /**
   * Put a PC backup back: every profile, the data set and any textures in it. What is here now is
   * kept first as a backup of its own, so a restore can always be undone.
   */
  restoreBackup(input, { version } = {}) {
    const r = readBackup(input);
    if (!r.ok) throw new Error(r.error);
    if (r.kind !== 'pc') throw new Error(r.kind === 'phone' ? 'That is a phone backup: restore it on the phone (Link → Backups).' : 'That is a single save: use Import save instead.');
    const b = r.backup;
    const safety = this.keepBackup('before-restore', { version });
    clearTimeout(this.timer);
    const ids = Object.keys(b.profiles.saves).map((id) => String(id).replace(/[^\w-]/g, '')).filter(Boolean);
    for (const f of fs.readdirSync(this.profileDir)) if (/\.json$/.test(f)) fs.rmSync(path.join(this.profileDir, f), { force: true });
    for (const [id, sv] of Object.entries(b.profiles.saves)) writeAtomic(this.profileFile(id), JSON.stringify(sv));
    const order = [...(b.profiles.order ?? []).filter((id) => ids.includes(id)), ...ids.filter((id) => !(b.profiles.order ?? []).includes(id))];
    this.profiles = { active: ids.includes(b.profiles.active) ? b.profiles.active : order[0], order };
    this.writeIndex();
    if (b.dataset?.species) writeAtomic(this.files.dataset, JSON.stringify(b.dataset, null, 1));
    let textures = 0;
    for (const [rel, data] of Object.entries(b.textures ?? {})) {
      try { this.importTexture(rel, Buffer.from(data, 'base64'), { list: false }); textures++; } catch { /* skip odd paths */ }
    }
    this.save = null;
    this.load();
    return { safety: path.basename(safety), profiles: ids.length, textures, summary: summarize(b) };
  }

  /** { "creatures/sproutle.png": "file:///…?v=mtime" } */
  listTextures() {
    const out = {};
    for (const d of TEXTURE_DIRS) {
      const dir = path.join(this.textures, d);
      if (!fs.existsSync(dir)) continue;
      for (const f of fs.readdirSync(dir)) {
        if (!fileOk(d, f)) continue;
        const full = path.join(dir, f);
        const v = Math.floor(fs.statSync(full).mtimeMs);
        out[`${d}/${f.toLowerCase()}`] = `${pathToFileUrl(full)}?v=${v}`;
      }
    }
    return out;
  }

  /** Textures as data URLs plus a fingerprint, so phones can mirror the PC's art. */
  textureBundle() {
    const files = {};
    let sig = '';
    for (const d of TEXTURE_DIRS.filter((x) => x !== 'cries')) { // cries stay on the PC for now (size)
      const dir = path.join(this.textures, d);
      if (!fs.existsSync(dir)) continue;
      for (const f of fs.readdirSync(dir).sort()) {
        if (!/\.png$/i.test(f)) continue;
        const full = path.join(dir, f);
        const st = fs.statSync(full);
        if (st.size > 512 * 1024) continue; // keep phone storage sane
        sig += `${d}/${f}:${st.size}:${Math.floor(st.mtimeMs)};`;
        files[`${d}/${f.toLowerCase()}`] = `data:image/png;base64,${fs.readFileSync(full).toString('base64')}`;
      }
    }
    let hash = 0;
    for (let i = 0; i < sig.length; i++) hash = (Math.imul(hash, 31) + sig.charCodeAt(i)) >>> 0;
    return { hash: String(hash), files };
  }

  /** Cries as data URLs plus a fingerprint, so phones play the same sounds. */
  cryBundle() {
    const dir = path.join(this.textures, 'cries');
    const files = {};
    let sig = '';
    if (fs.existsSync(dir)) {
      for (const f of fs.readdirSync(dir).sort()) {
        if (!fileOk('cries', f)) continue;
        const full = path.join(dir, f);
        const st = fs.statSync(full);
        if (st.size > 400 * 1024) continue;
        sig += `${f}:${st.size}:${Math.floor(st.mtimeMs)};`;
        const type = /\.ogg$/i.test(f) ? 'audio/ogg' : /\.wav$/i.test(f) ? 'audio/wav' : 'audio/mpeg';
        files[`cries/${f.toLowerCase()}`] = `data:${type};base64,${fs.readFileSync(full).toString('base64')}`;
      }
    }
    let hash = 0;
    for (let i = 0; i < sig.length; i++) hash = (Math.imul(hash, 31) + sig.charCodeAt(i)) >>> 0;
    return { hash: String(hash), files };
  }

  importTexture(rel, bytes, { list = true } = {}) {
    const clean = rel.replace(/\\/g, '/').split('/').filter((p) => p && p !== '..');
    if (clean.length !== 2 || !TEXTURE_DIRS.includes(clean[0]) || !fileOk(clean[0], clean[1])) throw new Error(`Textures go in ${TEXTURE_DIRS.map((d) => `${d}/`).join(', ')} as .png files.`);
    fs.mkdirSync(path.join(this.textures, clean[0]), { recursive: true });
    fs.writeFileSync(path.join(this.textures, clean[0], clean[1].toLowerCase()), Buffer.from(bytes));
    return list ? this.listTextures() : null;
  }

  /** Many files at once (a whole sprite folder): writes them all, then lists once. */
  importTextures(files) {
    const failed = [];
    for (const f of files) {
      try { this.importTexture(f.path, f.data, { list: false }); } catch (e) { failed.push({ path: f.path, error: e.message }); }
    }
    return { list: this.listTextures(), failed };
  }
}

function pathToFileUrl(p) {
  let s = p.replace(/\\/g, '/');
  if (!s.startsWith('/')) s = `/${s}`;
  return `file://${encodeURI(s).replace(/#/g, '%23').replace(/\?/g, '%3F')}`;
}

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
}

export function writeAtomic(file, text) {
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, text);
  fs.renameSync(tmp, file);
}

function migrate(save) {
  save.devices = save.devices || {};
  save.capsules = save.capsules || {};
  save.settings = Object.assign({ petUid: null, petEnabled: false, sound: true, volume: 0.6, autoSync: true, askLetOut: true }, save.settings);
  save.stats = Object.assign({ battlesWon: 0, battlesLost: 0, totalSteps: 0 }, save.stats);
  save.virtualTags = save.virtualTags || {};
  E.ensureTrainerCard(save);
}

const TEXTURE_README = `Capsule Link textures
=====================

Drop PNG files in these folders. They replace the built-in placeholder art.
Easiest: Settings > Add creature sprites... and select a whole folder of PNGs at once.

creatures/<name>.png         idle animation: square frames side by side, or one picture
creatures/<name>-walk.png    walking frames (optional)
creatures/<name>-sleep.png   sleeping frames (optional)
creatures/<name>-happy.png   happy frames (optional)
creatures/<name>-back.png    seen from behind (optional)
ranch/<biome>.png            buddy scene background, 320x180 is the native size
ranch/<biome>-ground.png     R.A.N.C.H. yard ground, 432x264, back fence at the top
ranch/<biome>-sky.png        R.A.N.C.H. sky, repeats sideways
ranch/<biome>-far.png        R.A.N.C.H. scenery beyond the fence (also -mid.png, -near.png)
ranch/<biome>-prop1.png      R.A.N.C.H. props in the yard, up to -prop8.png
boxes/<biome>.png            box wallpaper, 216x180 is the native size
boxes/<anything>.png         extra storage wallpapers (listed under "Yours"), 216x180 or larger
cries/<name>.mp3             the creature's cry (also .ogg or .wav); Settings > Data and art downloads them
ui/app-icon.png              the app's icon (window, taskbar, shortcuts, phone home screen), square 512x512
ui/logo.png                  the app's logo (square, 256x256 recommended)
ui/ball.png                  the capsule: one picture, or 7 square frames side by side:
                             closed, empty, open, shake1, shake2, shake3, icon
ui/ball-<kind>.png           another kind of capsule (a name, or the ball number from PKHeX files)
ui/ball-<kind>-<pose>.png    one pose on its own, e.g. ui/ball-open.png or ui/ball-4-shake2.png
ui/toy-ball.png              the ball thrown in the R.A.N.C.H.
trainers/<anything>.png      trainer pictures to pick on your ID card (any size, full body)

<name> can be the species id (sproutle), the name squashed (mrbristle), the name with its
form (bristle-mega) or the number (7, 007 or 0007).
Frames: 32x32 is the built-in size; 64x64 is the largest shown 1:1, bigger is shrunk to fit.
How big a creature is drawn comes from its height in the data set (Data Lab → Height), not the
picture size: empty space around the creature is ignored, so any sprite size works.
Biome ids: meadow forest shoreline volcano cavern tundra desert skyline seafloor marsh starfield crystal
Full guide: docs/adding-your-data.md in the project folder.
`;
