// Hosting a Capsule Link home server from this PC (Settings → Debug → Host a server from this PC).
// The same server as server/core.mjs, run inside the app: accounts, friends, messages, gifts, trades,
// yard visits, shared creature data, and the battle relay. Optional extras so friends can reach it from
// anywhere: automatic port forwarding (UPnP), a free DuckDNS name that follows your home's changing
// address, a Windows Firewall rule, and starting with the computer.
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { app, net } from 'electron';
import { makeServer } from '../../../server/core.mjs';
import { lanAddresses, mapPort, unmapPort, isPrivate } from './upnp.js';

const DEFAULTS = { autoStart: false, port: 47830, name: '', upnp: true, duckDomain: '', duckToken: '', openAtLogin: false, keepRunning: true };

export function createHost({ dir, onChange = () => {} }) {
  const file = path.join(dir, 'host.json');
  let cfg = { ...DEFAULTS };
  try { cfg = { ...DEFAULTS, ...JSON.parse(fs.readFileSync(file, 'utf8')) }; } catch { /* first time */ }
  let srv = null;
  let st = { running: false, error: '', upnp: null, publicIp: null, duck: null, startedAt: null, log: [] };
  let duckTimer = null;
  const saveCfg = () => { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(file, JSON.stringify(cfg, null, 2)); };
  const log = (...a) => { st.log.push(`${new Date().toLocaleTimeString()} ${a.join(' ')}`); if (st.log.length > 60) st.log.shift(); };
  const changed = () => onChange(status());

  function status() {
    const lan = lanAddresses();
    const port = cfg.port;
    const pub = st.upnp?.externalIp && !isPrivate(st.upnp.externalIp) ? st.upnp.externalIp : st.publicIp;
    return {
      ...st, cfg: { ...cfg, duckToken: cfg.duckToken ? '••••' : '' }, port, lan,
      localUrl: lan[0] ? `http://${lan[0]}:${port}` : `http://localhost:${port}`,
      publicUrl: cfg.duckDomain ? `http://${cfg.duckDomain.replace(/\.duckdns\.org$/i, '')}.duckdns.org:${port}` : pub ? `http://${pub}:${port}` : null,
      cgnat: !!(st.upnp?.externalIp && isPrivate(st.upnp.externalIp)),
      dataDir: path.join(dir, 'server-data'),
      platform: process.platform,
      trainers: srv ? Object.keys(srv.store.col('users')).length : 0,
    };
  }

  async function findPublicIp() {
    try { const r = await net.fetch('https://api.ipify.org?format=json'); st.publicIp = (await r.json()).ip; } catch { st.publicIp = null; }
    return st.publicIp;
  }
  async function updateDuck() {
    if (!cfg.duckDomain || !cfg.duckToken) { st.duck = null; return; }
    const domain = cfg.duckDomain.replace(/\.duckdns\.org$/i, '');
    try {
      const r = await net.fetch(`https://www.duckdns.org/update?domains=${encodeURIComponent(domain)}&token=${encodeURIComponent(cfg.duckToken)}`);
      const t = (await r.text()).trim();
      st.duck = t === 'OK' ? { ok: true, at: Date.now() } : { ok: false, error: 'DuckDNS said no: check the domain and token.' };
    } catch (e) { st.duck = { ok: false, error: `Couldn’t reach DuckDNS (${e.message}).` }; }
    log('DuckDNS', st.duck.ok ? 'updated' : st.duck.error);
  }

  async function start() {
    if (srv) return status();
    st.error = '';
    try {
      srv = makeServer({ port: cfg.port, dataDir: path.join(dir, 'server-data'), name: cfg.name || `${app.getName()} server`, log });
      await srv.server.ready;
      st.running = true; st.startedAt = Date.now();
      log('Server started on port', cfg.port);
    } catch (e) {
      srv = null; st.running = false;
      st.error = e.code === 'EADDRINUSE' ? `Port ${cfg.port} is already in use on this PC. Pick another port.` : e.message;
      changed();
      return status();
    }
    changed();
    // the extras, in the background
    (async () => {
      if (cfg.upnp) { st.upnp = await mapPort(cfg.port).catch((e) => ({ ok: false, error: e.message })); log('Port forwarding:', st.upnp.ok ? `done on ${st.upnp.router}` : st.upnp.error); }
      await findPublicIp();
      await updateDuck();
      clearInterval(duckTimer);
      duckTimer = setInterval(() => { updateDuck().then(changed); }, 10 * 60 * 1000);
      changed();
    })();
    return status();
  }
  async function stop() {
    clearInterval(duckTimer);
    if (srv) { await srv.close(); srv = null; log('Server stopped'); }
    st.running = false;
    if (st.upnp?.ok) { unmapPort(cfg.port).catch(() => {}); st.upnp = null; }
    changed();
    return status();
  }
  async function configure(patch = {}) {
    const wasRunning = !!srv;
    const restart = wasRunning && (patch.port != null && Number(patch.port) !== cfg.port);
    if (patch.port != null) { const p = Number(patch.port); if (!(p >= 1024 && p <= 65535)) throw new Error('Pick a port between 1024 and 65535.'); patch.port = p; }
    if (patch.duckToken === '••••') delete patch.duckToken;
    cfg = { ...cfg, ...patch };
    saveCfg();
    if ('openAtLogin' in patch) { try { app.setLoginItemSettings({ openAtLogin: !!cfg.openAtLogin, args: ['--hidden'] }); } catch { /* not supported here */ } }
    if (restart) { await stop(); await start(); }
    if ('duckDomain' in patch || 'duckToken' in patch) await updateDuck();
    if ('upnp' in patch && srv) { st.upnp = cfg.upnp ? await mapPort(cfg.port).catch((e) => ({ ok: false, error: e.message })) : (await unmapPort(cfg.port), null); }
    changed();
    return status();
  }
  async function retryForward() { st.upnp = await mapPort(cfg.port).catch((e) => ({ ok: false, error: e.message })); await findPublicIp(); changed(); return status(); }

  /** Can this PC reach its own public address? (Many routers allow it; if not, test from a phone on mobile data.) */
  async function checkReach() {
    const s = status();
    const url = s.publicUrl;
    if (!url) return { ok: false, reason: 'No public address yet.' };
    try {
      const ctl = new AbortController(); setTimeout(() => ctl.abort(), 6000);
      const r = await net.fetch(`${url}/api/info`, { signal: ctl.signal });
      const j = await r.json();
      return { ok: j?.kind === 'home-server', url };
    } catch { return { ok: false, url, reason: 'This PC couldn’t reach its own public address. That’s normal on many routers even when it works from outside: test on a phone using mobile data (Wi-Fi off).' }; }
  }

  /** Windows only: add a firewall rule (Windows asks for permission). */
  function allowFirewall() {
    return new Promise((resolve) => {
      if (process.platform !== 'win32') { resolve({ ok: true, skipped: true }); return; }
      const rule = `netsh advfirewall firewall add rule name=\\"Capsule Link server\\" dir=in action=allow protocol=TCP localport=${cfg.port}`;
      execFile('powershell.exe', ['-NoProfile', '-Command', `Start-Process cmd -Verb RunAs -WindowStyle Hidden -ArgumentList '/c ${rule}'`], (err) => resolve(err ? { ok: false, error: 'Windows didn’t allow it (or the permission box was closed).' } : { ok: true }));
    });
  }

  return { status, start, stop, configure, retryForward, checkReach, allowFirewall, get running() { return !!srv; }, get cfg() { return cfg; } };
}
