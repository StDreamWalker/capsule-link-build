// First-run save with a few placeholder creatures so the terminal is not empty.
import * as E from '../../../shared/engine/index.js';

/** A first save with a few placeholder creatures so the terminal is not empty. */
export function starterSave(idx, name = 'Trainer') {
  const save = E.createSave(name);
  save.trainer.card = E.defaultTrainerCard(name, save.trainer.id);
  const add = (id, level, loc) => {
    if (!idx.species.has(id)) return;
    E.addCreature(save, E.createCreature(idx, id, { level, trainer: name }), loc);
  };
  add('sproutle', 6, { kind: 'party', slot: 0 });
  add('cindrop', 6, { kind: 'party', slot: 1 });
  add('puddlop', 6, { kind: 'party', slot: 2 });
  let slot = 0;
  for (const id of ['mossling', 'zapkit', 'frostuft', 'gloomoth', 'cogsy', 'mindle', 'pugnacub']) add(id, 5 + (slot % 4), { kind: 'box', box: 0, slot: slot++ });
  if (!Object.keys(save.creatures).length && idx.ds.species[0]) add(idx.ds.species[0].id, 5, { kind: 'party', slot: 0 });
  save.settings.petUid = Object.values(save.creatures).find((c) => c.location.kind === 'box')?.uid ?? null;
  return save;
}
