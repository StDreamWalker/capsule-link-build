// UPnP port forwarding: ask the home router to forward a port to this PC, so friends can reach the
// server from anywhere. Most home routers support this (it's often called UPnP or "automatic port
// forwarding"); if yours doesn't, or it's switched off, forward the port by hand (the guide says how).
import dgram from 'node:dgram';
import http from 'node:http';
import os from 'node:os';

const SSDP = { host: '239.255.255.250', port: 1900 };
const SERVICES = ['urn:schemas-upnp-org:service:WANIPConnection:2', 'urn:schemas-upnp-org:service:WANIPConnection:1', 'urn:schemas-upnp-org:service:WANPPPConnection:1'];

/** This PC's addresses on the home network (IPv4, not loopback). */
export function lanAddresses() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const a of list ?? []) if (a.family === 'IPv4' && !a.internal && !/^169\.254\./.test(a.address) && !/vEthernet|VirtualBox|VMware|docker|WSL/i.test(name)) out.push(a.address);
  }
  // the usual home ranges first
  return out.sort((a, b) => (/^192\.168\./.test(b) ? 1 : 0) - (/^192\.168\./.test(a) ? 1 : 0));
}

function get(url, timeout = 5000) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, { timeout }, (res) => { let d = ''; res.setEncoding('utf8'); res.on('data', (c) => { d += c; }); res.on('end', () => resolve(d)); });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
  });
}

/** Find the router: { location, controlUrl, service } or null. */
export function discover(timeout = 3000) {
  return new Promise((resolve) => {
    const sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    const seen = new Set();
    let done = false;
    const finish = (v) => { if (done) return; done = true; try { sock.close(); } catch { /* ignore */ } resolve(v); };
    sock.on('message', async (msg) => {
      const m = /^location:\s*(.+)$/im.exec(msg.toString());
      if (!m || seen.has(m[1].trim())) return;
      const location = m[1].trim();
      seen.add(location);
      try {
        const xml = await get(location);
        for (const service of SERVICES) {
          const i = xml.indexOf(service);
          if (i < 0) continue;
          const tail = xml.slice(i);
          const ctl = /<controlURL>\s*([^<]+?)\s*<\/controlURL>/i.exec(tail);
          if (!ctl) continue;
          finish({ location, controlUrl: new URL(ctl[1], location).href, service });
          return;
        }
      } catch { /* not a gateway */ }
    });
    sock.on('error', () => finish(null));
    sock.bind(() => {
      const search = (st) => Buffer.from(`M-SEARCH * HTTP/1.1\r\nHOST: ${SSDP.host}:${SSDP.port}\r\nMAN: "ssdp:discover"\r\nMX: 2\r\nST: ${st}\r\n\r\n`);
      for (const st of ['urn:schemas-upnp-org:device:InternetGatewayDevice:1', 'urn:schemas-upnp-org:device:InternetGatewayDevice:2', 'urn:schemas-upnp-org:service:WANIPConnection:1']) {
        sock.send(search(st), SSDP.port, SSDP.host);
      }
    });
    setTimeout(() => finish(null), timeout);
  });
}

function soap(gw, action, args = {}) {
  const body = `<?xml version="1.0"?>\r\n<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:${action} xmlns:u="${gw.service}">${Object.entries(args).map(([k, v]) => `<${k}>${v}</${k}>`).join('')}</u:${action}></s:Body></s:Envelope>`;
  const u = new URL(gw.controlUrl);
  return new Promise((resolve, reject) => {
    const req = http.request({ host: u.hostname, port: u.port || 80, path: u.pathname + u.search, method: 'POST', timeout: 6000,
      headers: { 'Content-Type': 'text/xml; charset="utf-8"', 'Content-Length': Buffer.byteLength(body), SOAPAction: `"${gw.service}#${action}"` } }, (res) => {
      let d = ''; res.setEncoding('utf8'); res.on('data', (c) => { d += c; });
      res.on('end', () => (res.statusCode >= 200 && res.statusCode < 300 ? resolve(d) : reject(new Error((/<errorDescription>([^<]+)/.exec(d)?.[1]) ?? `The router said ${res.statusCode}`))));
    });
    req.on('timeout', () => req.destroy(new Error('The router didn’t answer.')));
    req.on('error', reject);
    req.end(body);
  });
}

/** The internet address the router has (may be a carrier-grade NAT address: see isPrivate). */
export async function externalIp(gw) {
  const r = await soap(gw, 'GetExternalIPAddress');
  return /<NewExternalIPAddress>([^<]*)</i.exec(r)?.[1] || null;
}
export const isPrivate = (ip) => /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.|127\.)/.test(ip ?? '');

/**
 * Forward TCP `port` on the router to this PC. Returns { ok, router, externalIp, internal, error }.
 */
export async function mapPort(port, description = 'Capsule Link server') {
  const gw = await discover();
  if (!gw) return { ok: false, error: 'Couldn’t find a router that allows automatic port forwarding (UPnP). It may be switched off in the router’s settings.' };
  const internal = lanAddresses()[0];
  try {
    await soap(gw, 'AddPortMapping', { NewRemoteHost: '', NewExternalPort: port, NewProtocol: 'TCP', NewInternalPort: port, NewInternalClient: internal, NewEnabled: 1, NewPortMappingDescription: description, NewLeaseDuration: 0 });
  } catch (e) {
    // some routers only accept leases that expire: try a week
    try { await soap(gw, 'AddPortMapping', { NewRemoteHost: '', NewExternalPort: port, NewProtocol: 'TCP', NewInternalPort: port, NewInternalClient: internal, NewEnabled: 1, NewPortMappingDescription: description, NewLeaseDuration: 604800 }); }
    catch { return { ok: false, router: new URL(gw.location).hostname, internal, error: `The router refused: ${e.message}` }; }
  }
  let ip = null; try { ip = await externalIp(gw); } catch { /* fine */ }
  return { ok: true, router: new URL(gw.location).hostname, externalIp: ip, internal };
}
export async function unmapPort(port) {
  const gw = await discover();
  if (!gw) return { ok: false };
  try { await soap(gw, 'DeletePortMapping', { NewRemoteHost: '', NewExternalPort: port, NewProtocol: 'TCP' }); return { ok: true }; } catch (e) { return { ok: false, error: e.message }; }
}
