// Desktop buddy: a transparent strip along the bottom of the screen with one creature in it.
import { indexDataset, displayName, mood, cryFor, speciesOf, tickNeeds } from '../../../shared/engine/index.js';
import { SpriteBank, spriteIdOf, EGG_ID } from '../../../shared/ui/art.js';
import { setBrand, brandText } from '../../../shared/ui/dom.js';
import { Stage } from '../../../shared/ui/stage.js';
import { petFactor, sizeVariant } from '../../../shared/ui/creatureSize.js';
import { playCry, sfx, setSound, creatureCry, setCryResolver } from '../../../shared/ui/audio.js';

const api = window.capsule;
// one canvas pixel is SCALE screen pixels; a 1 m creature is BASE screen pixels tall at size 1
// (Settings → Desktop buddy → Size, or the tray menu), others follow their own height
const SCALE = 2, BASE = 56;
let stage, bank, idx, creature, settings;
let overCreature = false;
let menu = null;
let lastPet = 0;

async function boot() {
  await document.fonts?.load?.('10px "Capsule Pixel"').catch(() => {});
  const data = await api.petData();
  apply(data);
  api.onPetData(apply);
  scheduleCry();
}

function apply(data) {
  if (!data?.creature) return;
  settings = data.settings;
  setSound(settings.sound !== false, settings.volume ?? 0.6);
  if (!idx || data.dataset !== idx.ds) { idx = indexDataset(data.dataset); setBrand(idx.ds.brand); }
  const textures = data.textures ?? {};
  setCryResolver((p) => textures[p.toLowerCase()] ?? null);
  if (!bank) bank = new SpriteBank({ idx, resolveTexture: (p) => textures[p.toLowerCase()] ?? null });
  else { bank.setDataset(idx); bank.setResolver((p) => textures[p.toLowerCase()] ?? null); }
  creature = data.creature;
  tickNeeds(idx, creature);
  if (!stage) {
    const canvas = document.getElementById('stage');
    const W = Math.ceil(window.innerWidth / SCALE), H = Math.ceil(window.innerHeight / SCALE);
    stage = new Stage(canvas, {
      bank, width: W, height: H, transparent: true, spriteScale: 1, showNames: false,
      iconMode: true, beam: true,
      visibleHeight: (a) => (BASE * petSize() * (a.sizeMul ?? 1) * (a.speciesId === EGG_ID ? 0.5 : petFactor(idx.species.get(a.speciesId)))) / SCALE,
      onSelect: () => {},
      onPet: () => pet(),
      onHover: (uid) => setOver(!!uid),
    });
    canvas.addEventListener('dblclick', () => { stage.react(creature.uid, 'happy', 4); creatureCry(speciesOf(idx, creature), creature); });
    canvas.addEventListener('contextmenu', (e) => { e.preventDefault(); if (overCreature) openMenu(e.clientX, e.clientY); });
    canvas.addEventListener('pointerdown', () => closeMenu());
    stage.start();
  }
  // the window grows and shrinks with the size setting: keep the canvas matched to it
  const W = Math.ceil(window.innerWidth / SCALE), H = Math.ceil(window.innerHeight / SCALE);
  if (W !== stage.W || H !== stage.H) resizeStage(W, H);
  stage.setCreatures([{ uid: creature.uid, speciesId: spriteIdOf(creature), sizeMul: sizeVariant(creature).mult, name: displayName(idx, creature), mood: mood(creature).id, speed: 10 + 12 * petSize() }]);
}

function petSize() { return Math.max(0.25, Math.min(3, Number(settings?.petSize) || 1)); }

function resizeStage(W, H) {
  stage.W = W; stage.H = H;
  stage.canvas.width = W; stage.canvas.height = H;
  for (const a of stage.actors.values()) { a.y = H - 2; a.x = Math.min(a.x, W - 8); }
}
window.addEventListener('resize', () => {
  if (!stage) return;
  resizeStage(Math.ceil(window.innerWidth / SCALE), Math.ceil(window.innerHeight / SCALE));
});

function setOver(v) {
  if (v === overCreature || menu) return;
  overCreature = v;
  api.petMouse(v);
}

async function pet() {
  const now = Date.now();
  if (now - lastPet < 900) return;
  lastPet = now;
  sfx('heart');
  await api.petCare('pet');
}

function openMenu(x, y) {
  closeMenu();
  api.petMouse(true);
  const items = [
    ['Feed', async () => { const r = await api.petCare('feed'); stage.react(creature.uid, r?.reaction === 'full' ? 'sad' : 'munch', 4); sfx('munch'); }],
    ['Play', async () => { stage.throwBall(); await api.petCare('play'); }],
    ['Call', () => { creatureCry(speciesOf(idx, creature), creature); stage.react(creature.uid, 'note', 2); }],
    ['Smaller', () => api.petSize(Math.max(0.25, +(petSize() / 1.25).toFixed(2)))],
    ['Bigger', () => api.petSize(Math.min(3, +(petSize() * 1.25).toFixed(2)))],
    ['Open Capsule Link', () => api.petOpenApp()],
    ['Put away', () => api.petAway()],
  ];
  menu = document.createElement('div');
  menu.className = 'pet-menu';
  for (const [label, fn] of items) {
    const b = document.createElement('button');
    b.textContent = brandText(label);
    b.onclick = () => { closeMenu(); fn(); };
    menu.append(b);
  }
  document.body.append(menu);
  const r = menu.getBoundingClientRect();
  menu.style.left = `${Math.min(window.innerWidth - r.width - 8, x)}px`;
  menu.style.top = `${Math.max(4, y - r.height - 8)}px`;
  menu.addEventListener('pointerleave', () => setTimeout(closeMenu, 400));
}

function closeMenu() {
  if (!menu) return;
  menu.remove();
  menu = null;
  overCreature = false;
  api.petMouse(false);
}

function scheduleCry() {
  // every so often the buddy calls out or wiggles, like a capsule in desk mode
  const wait = (6 + Math.random() * 14) * 60 * 1000;
  setTimeout(() => {
    if (creature && stage) {
      const m = mood(creature).id;
      if (m === 'hungry') stage.react(creature.uid, 'sad', 2);
      else stage.react(creature.uid, 'note', 2);
      if (Math.random() < 0.6) creatureCry(speciesOf(idx, creature), creature);
    }
    scheduleCry();
  }, wait);
}

boot();
