// Preload for the Showdown window. Runs before Showdown's own scripts: gives the page a
// CapsuleBridge.post() mailbox and installs the bridge script (see shared/engine/showdown.js).
const { contextBridge, ipcRenderer, webFrame } = require('electron');

contextBridge.exposeInMainWorld('CapsuleBridge', {
  post: (json) => ipcRenderer.send('showdown:post', String(json).slice(0, 2_000_000)),
});
webFrame.executeJavaScript(ipcRenderer.sendSync('showdown:script'));
