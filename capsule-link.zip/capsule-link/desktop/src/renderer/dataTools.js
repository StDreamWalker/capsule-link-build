// Ready-made tools for the setup guide and Settings: the extras tables, creature sprites (download
// from a source, your own files, or a sprite sheet) and trainer pictures. Each manages itself.
import { h, mount, toast } from '../../../shared/ui/dom.js';
import { sfx } from '../../../shared/ui/audio.js';
import { POKEAPI_CSV, EXTRA_FILES, addCsvExtrasText, applyCsvExtras, normalizeDataset } from '../../../shared/engine/index.js';
import { importSprites, pickTrainerPictures, spriteCoverage } from './spriteImport.js';
import { SPRITE_SOURCES, TRAINER_SOURCE, downloadIcons, downloadSprites, pngLinksOn, downloadPictures, inspectSheet, sliceSheet } from './downloads.js';

const clone = (x) => JSON.parse(JSON.stringify(x));

function section(title, what, { optional = false, ok = false } = {}, ...body) {
  return h('section', { class: `data-step ${ok ? 'done' : ''}` },
    h('div', { class: 'row' },
      h('span', { class: 'step-check' }, ok ? '✓' : ''),
      h('div', { class: 'grow' }, h('h3', null, title, optional ? h('span', { class: 'chip micro' }, 'optional') : null), h('p', { class: 'micro dim' }, what))),
    body);
}
function progress() {
  const bar = h('i');
  const text = h('span', { class: 'micro dim' });
  const el = h('div', { class: 'dl-progress', hidden: true }, h('div', { class: 'connect-bar' }, bar), text);
  return {
    el,
    set(done, total, label = '') { el.hidden = false; bar.style.width = `${total ? (done / total) * 100 : 0}%`; text.textContent = `${label}${done} of ${total}`; },
    hide() { el.hidden = true; },
  };
}

// ---------- experience, growth, effort (and friendship, catch rate, habitat) ----------
export function extrasTool(app) {
  const st = { ok: false, status: '', tables: {} };
  const el = h('div');
  async function apply() {
    const ds = clone(app.dataset);
    const r = applyCsvExtras(ds, st.tables);
    if (!r.updated) { st.status = 'Nothing matched your species. These tables match by national number, so species need numbers (Showdown’s species file has them).'; st.ok = false; return; }
    await app.saveDataset(normalizeDataset(ds));
    st.ok = true;
    st.status = `✓ ${r.updated} species updated${r.report.length ? ` · ${r.report[0]}` : ''}`;
    sfx('heal');
  }
  function render() {
    const ta = h('textarea', { class: 'code paste small', spellcheck: false, placeholder: 'Or paste any of the three files here, one at a time…' });
    const status = h('div', { class: `data-status ${st.ok ? 'ok' : st.status ? 'err' : ''}` }, st.status);
    mount(el, section('Experience, growth and effort', 'Base experience, growth rate and effort yield — plus base friendship, catch rate and habitat. Showdown’s files leave these out, so they come from PokéAPI’s open data tables.', { optional: true, ok: st.ok },
      h('p', { class: 'micro' }, 'Press Download and the PC fetches the three tables and matches them to your species by number. To do it by hand, open each file, select all, copy and paste it below.'),
      h('div', { class: 'row wrap' }, EXTRA_FILES.map((f) => h('a', { class: 'btn small', href: `${POKEAPI_CSV}/${f}`, target: '_blank', rel: 'noopener' }, f))),
      ta,
      h('div', { class: 'row' }, status, h('span', { class: 'spacer' }),
        h('button', { class: 'btn small', onclick: async () => {
          const kind = addCsvExtrasText(st.tables, ta.value);
          if (!kind) { st.status = 'That is not one of the three tables (check the first line: it should be the column names).'; st.ok = false; render(); return; }
          await apply(); render();
        } }, 'Check and add'),
        h('button', { class: 'btn small primary', onclick: async (e) => {
          e.target.disabled = true; e.target.textContent = 'Downloading…';
          try {
            for (const f of EXTRA_FILES) {
              const r = await app.platform.fetchUrl(`${POKEAPI_CSV}/${f}`, 'text');
              if (!r.ok) throw new Error(`${f} answered ${r.status}`);
              addCsvExtrasText(st.tables, r.text);
            }
            await apply();
          } catch (err) { st.status = `Download failed: ${err.message}. Use the links and paste instead.`; st.ok = false; }
          render();
        } }, 'Download for me'))));
  }
  render();
  return el;
}

// ---------- creature sprites ----------
export function spriteTool(app) {
  const st = { source: SPRITE_SOURCES[0].id, custom: '', back: true, trim: true, onlyMissing: true, running: false, stop: false, status: '', ok: false, sheet: null };
  const el = h('div');
  const prog = progress();
  function src() { return SPRITE_SOURCES.find((s) => s.id === st.source) ?? { front: st.custom, back: '' }; }
  async function run() {
    const s = src();
    if (!s.front || !/\{(num|num3|num4|sd|id|name)\}/.test(s.front)) { st.status = 'The address needs {num}, {sd}, {id} or {name} where the species goes.'; render(); return; }
    st.running = true; st.stop = false; st.status = ''; render();
    const r = await downloadSprites(app, { template: s.front, back: st.back ? s.back : '', trim: st.trim, onlyMissing: st.onlyMissing, onProgress: (d, t) => prog.set(d, t, 'Downloading '), shouldStop: () => st.stop });
    st.running = false;
    const cov = spriteCoverage(app);
    st.ok = r.saved > 0;
    if (!r.saved) { st.status = `Couldn’t download any: ${r.failed[0] ?? (r.missing.length ? 'the source has no pictures under those names' : 'nothing to do')}.${app.platform.kind !== 'desktop' ? ' (The browser preview can’t reach most sites; the PC app can.)' : ''}`; sfx('error'); prog.hide(); render(); return; }
    st.status = `✓ ${r.saved} pictures saved · ${cov.have} of ${cov.total} species have a sprite${r.missing.length ? ` · not found: ${r.missing.slice(0, 6).join(', ')}${r.missing.length > 6 ? ` and ${r.missing.length - 6} more` : ''}` : ''}${r.failed.length ? ` · ${r.failed.length} failed` : ''}`;
    sfx('heal'); prog.hide(); render();
  }
  function sheetPanel() {
    const s = st.sheet;
    if (!s) return null;
    const num = (k, label, v) => h('label', { class: 'field small' }, h('span', null, label), h('input', { type: 'number', min: 0, value: v, onchange: (e) => { s[k] = Number(e.target.value) || 0; render(); } }));
    const cols = Math.floor((s.width - s.offsetX + s.gap) / (s.cell + s.gap)), rows = Math.floor((s.height - s.offsetY + s.gap) / (s.cell + s.gap));
    return h('div', { class: 'sheet-cut' },
      h('p', { class: 'micro' }, `${s.name}: ${s.width}×${s.height}. Cells are read left to right, top to bottom; the first cell is species number ${s.startNo}. That gives ${cols} × ${rows} = ${cols * rows} cells.`),
      h('div', { class: 'form-grid six' }, num('cell', 'Cell size (px)', s.cell), num('gap', 'Gap between', s.gap), num('offsetX', 'Margin left', s.offsetX), num('offsetY', 'Margin top', s.offsetY), num('startNo', 'First number', s.startNo)),
      h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.countEmpty, onchange: (e) => { s.countEmpty = e.target.checked; } }), 'Empty cells still use up a number'),
      h('div', { class: 'row' }, h('span', { class: 'spacer' }),
        h('button', { class: 'btn small', onclick: () => { st.sheet = null; render(); } }, 'Cancel'),
        h('button', { class: 'btn small primary', onclick: async () => {
          const r = await sliceSheet(app, s, { cellW: s.cell, gap: s.gap, offsetX: s.offsetX, offsetY: s.offsetY, startNo: s.startNo, countEmpty: s.countEmpty, trim: st.trim });
          const cov = spriteCoverage(app);
          st.ok = true; st.status = `✓ Cut ${r.saved} sprites from the sheet${r.skipped ? ` (${r.skipped} numbers not in your species list)` : ''} · ${cov.have} of ${cov.total} species have a sprite`;
          st.sheet = null; sfx('heal'); render();
        } }, 'Cut it up')));
  }
  function render() {
    const s = src();
    mount(el, section('Creature sprites', 'One picture per species. Download them from a sprite source, choose your own files, or cut up one big sprite sheet.', { ok: st.ok },
      h('div', { class: 'col' },
        h('label', { class: 'field' }, h('span', null, 'Download from'),
          h('select', { disabled: st.running, onchange: (e) => { st.source = e.target.value; render(); } },
            SPRITE_SOURCES.map((x) => h('option', { value: x.id, selected: x.id === st.source }, x.label)),
            h('option', { value: 'custom', selected: st.source === 'custom' }, 'Another address…'))),
        st.source === 'custom'
          ? h('label', { class: 'field' }, h('span', null, 'Address pattern — {num} is the number (or {num3} for 001), {sd} the Showdown id, {id} your species id'),
            h('input', { type: 'url', value: st.custom, placeholder: 'https://example.com/sprites/{num}.png', oninput: (e) => { st.custom = e.target.value.trim(); } }))
          : h('p', { class: 'micro dim mono-num' }, s.front),
        h('div', { class: 'row wrap' },
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: st.back, disabled: !s.back, onchange: (e) => { st.back = e.target.checked; } }), 'Back views too'),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: st.trim, onchange: (e) => { st.trim = e.target.checked; } }), 'Trim empty space'),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: st.onlyMissing, onchange: (e) => { st.onlyMissing = e.target.checked; } }), 'Only species without a sprite'))),
      prog.el,
      sheetPanel(),
      h('div', { class: 'row wrap' },
        h('div', { class: `data-status ${st.ok ? 'ok' : st.status ? 'err' : ''}` }, st.status), h('span', { class: 'spacer' }),
        h('label', { class: 'btn small' }, 'Choose files…', h('input', { type: 'file', class: 'hidden', accept: 'image/png', multiple: true, onchange: async (e) => {
          const files = [...(e.target.files ?? [])];
          if (!files.length) return;
          const r = await importSprites(app, files);
          app.applyTextures?.();
          st.ok = r.saved > 0; st.status = `✓ ${r.saved} saved · ${r.matched} matched a species${r.unmatched.length ? ` · ${r.unmatched.length} did not` : ''}`;
          sfx('heal'); render();
        } })),
        h('label', { class: 'btn small' }, 'Cut up a sprite sheet…', h('input', { type: 'file', class: 'hidden', accept: 'image/png', onchange: async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          const info = await inspectSheet(f);
          st.sheet = { ...info, name: f.name, gap: 0, offsetX: 0, offsetY: 0, startNo: 1, countEmpty: true };
          render();
        } })),
        st.running
          ? h('button', { class: 'btn small danger', onclick: () => { st.stop = true; } }, 'Stop')
          : h('button', { class: 'btn small primary', onclick: run }, 'Download sprites'),
        st.running ? null : h('button', { class: 'btn small', title: 'The small pictures used in storage boxes and menus', onclick: async () => {
          st.running = true; st.status = 'Downloading menu icons…'; render();
          try { const r = await downloadIcons(app); st.ok = r.saved > 0; st.status = r.saved ? `✓ ${r.saved} menu icons saved` : 'No icons matched your species numbers.'; sfx(r.saved ? 'heal' : 'error'); }
          catch (e) { st.ok = false; st.status = `Icon download failed: ${e.message}`; }
          st.running = false; render();
        } }, 'Download menu icons'))));
  }
  render();
  return el;
}

// ---------- trainer pictures ----------
export function trainerTool(app) {
  const st = { url: TRAINER_SOURCE, running: false, stop: false, status: '', ok: false };
  const el = h('div');
  const prog = progress();
  function render() {
    mount(el, section('Trainer pictures', 'Full-body pictures to choose on ID cards. Download a whole folder of them, or choose your own files.', { optional: true, ok: st.ok },
      h('label', { class: 'field' }, h('span', null, 'Folder address (a page that lists PNG files)'),
        h('input', { type: 'url', value: st.url, oninput: (e) => { st.url = e.target.value.trim(); } })),
      prog.el,
      h('div', { class: 'row wrap' },
        h('div', { class: `data-status ${st.ok ? 'ok' : st.status ? 'err' : ''}` }, st.status), h('span', { class: 'spacer' }),
        h('button', { class: 'btn small', onclick: async () => { const n = await pickTrainerPictures(app); if (n) { st.ok = true; st.status = `✓ ${n} added`; render(); } } }, 'Choose files…'),
        st.running ? h('button', { class: 'btn small danger', onclick: () => { st.stop = true; } }, 'Stop')
          : h('button', { class: 'btn small primary', onclick: async () => {
            st.running = true; st.stop = false; st.status = 'Reading the folder…'; render();
            try {
              const links = await pngLinksOn(app, st.url);
              if (!links.length) throw new Error('no PNG files are listed on that page');
              const r = await downloadPictures(app, links, 'trainers', { onProgress: (d, t) => prog.set(d, t, 'Downloading '), shouldStop: () => st.stop });
              st.ok = r.saved > 0; st.status = `✓ ${r.saved} trainer pictures${r.failed.length ? ` · ${r.failed.length} failed` : ''}`;
              sfx('heal');
            } catch (err) { st.ok = false; st.status = `Couldn’t download: ${err.message}.`; }
            st.running = false; prog.hide(); render();
          } }, 'Download all'))));
  }
  render();
  return el;
}

void toast;
