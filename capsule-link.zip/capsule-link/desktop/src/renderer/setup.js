// First-run setup on the PC (and again any time from Settings):
//   1-3  how it works: storage on the PC, capsules you carry, the phone that watches over them
//   4    make it yours: every name the apps use (app, capsule, creature, network, PC) + logo and capsule art
//   5    optional, recommended: bring in your own species, moves, learnsets, natures, sprites and trainer
//        pictures — each with where to copy it from, what it should look like, and a check
import { h, mount, toast } from '../../../shared/ui/dom.js';
import { capsuleCanvas } from '../../../shared/ui/capsuleArt.js';
import { spriteCanvas } from '../../../shared/ui/art.js';
import { logoMark, svgIcon } from '../../../shared/ui/icons.js';
import { sfx } from '../../../shared/ui/audio.js';
import { setBrand } from '../../../shared/ui/dom.js';
import {
  DEFAULT_BRAND, normalizeBrand, brandRewriter, parsePaste, looksLikeShowdownSet, normalizeDataset,
} from '../../../shared/engine/index.js';
import { spriteTool } from './dataTools.js';
import { presetTool, oneThingTool } from './presets.js';
import { playIntro, DEFAULT_INTRO } from '../../../shared/ui/introShow.js';

const clone = (x) => JSON.parse(JSON.stringify(x));

function slide(art, title, body) {
  return h('div', { class: 'setup-slide' }, h('div', { class: 'setup-art' }, art), h('h1', null, title), body.map((p) => h('p', { class: 'dim' }, p)));
}

/**
 * Run the setup in `host` (an element that fills the window). Resolves when finished or skipped.
 * opts.start: 'intro' | 'names' | 'data'
 */
export function runSetup(app, host, { start = 'intro' } = {}) {
  return new Promise((resolve) => {
    const steps = ['intro1', 'intro2', 'intro3', 'names', 'data'];
    let i = Math.max(0, steps.indexOf(start === 'intro' ? 'intro1' : start));
    let brand = normalizeBrand(app.dataset.brand);
    let introText = app.dataset.introText || DEFAULT_INTRO;
    const done = {};
    const tools = {};
    let dataOpen = start === 'data';
    const el = h('div', { class: 'setup' });
    mount(host, el);

    const finish = async () => {
      const ds = clone(app.dataset);
      ds.brand = brand;
      ds.setup = { done: true, at: Date.now() };
      await app.saveDataset(normalizeDataset(ds));
      sfx('heal');
      resolve();
    };

    function dots() {
      return h('div', { class: 'setup-dots' }, steps.map((s, k) => h('i', { class: k === i ? 'on' : k < i ? 'past' : '' })));
    }
    function nav({ nextLabel = 'Next', onNext = () => { i++; render(); }, back = i > 0, skip = true } = {}) {
      return h('div', { class: 'setup-nav' },
        back ? h('button', { class: 'btn', onclick: () => { i--; render(); } }, 'Back') : h('span'),
        dots(),
        h('div', { class: 'row' },
          skip && i < 3 ? h('button', { class: 'btn ghost', onclick: () => { i = 3; render(); } }, 'Skip intro') : null,
          h('button', { class: 'btn primary', id: 'setup-next', onclick: onNext }, nextLabel)));
    }

    // ---------- 1-3: how it works ----------
    function intro(n) {
      const sp = app.idx.ds.species;
      const pick = (k) => sp[k % Math.max(1, sp.length)]?.id;
      if (n === 1) {
        return slide(h('div', { class: 'art-row' }, logoMark(72), h('div', { class: 'art-sprites' }, [0, 2, 4].map((k) => spriteCanvas(app.bank, pick(k), { scale: 2, animate: true })))),
          'Welcome to Capsule Link',
          ['Creatures can’t step out into our world — but their data can travel with you. This PC is their home: storage boxes, the R.A.N.C.H. to spend time with them, and everything they remember.',
            'Away from the PC they ride in a capsule you carry, and your phone keeps an eye on them.']);
      }
      if (n === 2) {
        return slide(h('div', { class: 'art-row' }, capsuleCanvas({ ring: '#34d1bf', creature: pick(1), bank: app.bank }, 7), svgIcon('dock', { size: 48 })),
          'Carry them in a capsule',
          ['A capsule is a small NFC ball. Set it on the dock plugged into this PC (USB) to send someone in or bring them home — open Capsule Dock from the home screen.',
            'On a walk the capsule counts steps on its own. Nobody leaves their capsule away from the PC: you check on them, they tell you how they are doing, and an empty capsule might even pick up someone new.']);
      }
      return slide(h('div', { class: 'art-row' }, svgIcon('phone', { size: 64 }), capsuleCanvas({ ring: '#ffc93c' }, 5)),
        'Link your phone',
        ['On the phone, open Link and enter the address and six-digit code shown under Phone Link on this PC. Same Wi-Fi works, or a USB-C cable.',
          'Hold a capsule against the back of the phone to read it. Walks, thoughts and anything found along the way sync back here.']);
    }

    // ---------- 4: names ----------
    function names() {
      const preview = h('div', { class: 'brand-preview' });
      const paint = () => {
        const f = brandRewriter(brand);
        mount(preview,
          h('div', { class: 'bp-head' }, logoMark(28), h('b', null, f('Capsule Link'))),
          ['Put a creature in the capsule.', 'Your capsules hold 3 creatures.', 'Contacting Capsule Link Network servers…', 'Creature Storage on your PC'].map((t) => h('p', null, f(t))));
      };
      const field = (key, label, hint) => h('label', { class: 'field' }, h('span', null, label),
        h('input', { type: 'text', maxLength: 40, value: brand[key], placeholder: DEFAULT_BRAND[key], 'data-key': key, oninput: (e) => {
          const raw = { ...brand, [key]: e.target.value };
          // keep plurals following the singular unless they were typed by hand
          if (key === 'ball' && !el.querySelector('[data-key=balls]').dataset.touched) raw.balls = '';
          if (key === 'creature' && !el.querySelector('[data-key=creatures]').dataset.touched) raw.creatures = '';
          if (key === 'balls' || key === 'creatures') e.target.dataset.touched = '1';
          brand = normalizeBrand(raw);
          for (const k of ['balls', 'creatures']) { const inp = el.querySelector(`[data-key=${k}]`); if (inp && inp !== e.target && !inp.dataset.touched) inp.value = brand[k]; }
          paint();
        } }), hint ? h('span', { class: 'micro dim' }, hint) : null);
      const art = (path, label, hint) => h('div', { class: 'art-pick' },
        h('span', null, label), h('span', { class: 'micro dim' }, hint),
        h('label', { class: 'btn small' }, 'Choose PNG…', h('input', { type: 'file', class: 'hidden', accept: 'image/png', onchange: async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          const r = await app.platform.importTextures([{ path, data: new Uint8Array(await f.arrayBuffer()) }]);
          app.textures = r.list; app.applyTextures();
          toast(`${label} updated.`, 'ok'); paint(); render();
        } })));
      paint();
      return h('div', { class: 'setup-names' },
        h('div', { class: 'col' },
          h('h1', null, 'Make it yours'),
          h('p', { class: 'dim' }, 'Every name the apps use comes from here — on this PC, on your phone after it syncs, on ID cards and in messages. Type exactly what you want to see.'),
          h('div', { class: 'form-grid' },
            field('app', 'App name'),
            field('company', 'Network / company', 'Shown while connecting to your creatures.'),
            field('ball', 'What creatures travel in'),
            field('balls', '…more than one'),
            field('creature', 'What you call them'),
            field('creatures', '…more than one'),
            field('pc', 'The computer', 'Usually “PC”.'),
            field('product', 'The device’s product name', 'Used in the introduction.')),
          h('details', { class: 'intro-edit' },
            h('summary', null, 'Introduction text'),
            h('p', { class: 'micro dim' }, 'Shown full screen the very first time the apps start. Slides are separated by a line with ---. “## ” starts a headline, “> ” a small line above it, “- Label: text” a feature card. The names above are filled in automatically.'),
            h('textarea', { class: 'code paste small', spellcheck: false, oninput: (e) => { introText = e.target.value; } }, introText),
            h('div', { class: 'row' },
              h('button', { class: 'btn small', onclick: async () => { const host = h('div', { class: 'setup-overlay bare' }); document.body.append(host); setBrand(brand); try { await playIntro(host, { text: introText }); } finally { host.remove(); } } }, 'Preview'),
              h('button', { class: 'btn small', onclick: (e) => { introText = DEFAULT_INTRO; e.target.closest('details').querySelector('textarea').value = DEFAULT_INTRO; } }, 'Restore the original'))),
          h('h2', null, 'Pictures'),
          art('ui/logo.png', 'Logo', 'Square, transparent, 256×256 or larger.'),
          art('ui/app-icon.png', 'App icon', 'Square PNG, 512×512. Window, taskbar, shortcuts and the phone’s home screen.'),
          art('ui/ball.png', 'Capsule picture', 'One picture, or a strip of 7 poses (see docs/templates/capsule-sheet-guide.png).'),
          h('p', { class: 'micro dim' }, 'Creature sprites, trainer pictures and backgrounds come in the next step.')),
        h('div', { class: 'col' }, h('h2', null, 'Preview'), preview));
    }

    // ---------- 5: data ----------
    function data() {
      const spCount = app.idx.ds.species.length, mvCount = app.idx.ds.moves.length;
      tools.all = tools.all ?? presetTool(app, { big: true, onDone: () => render() });
      tools.one = tools.one ?? oneThingTool(app, { extra: { sprites: () => (tools.sprites = tools.sprites ?? spriteTool(app)) } });
      return h('div', { class: 'setup-data' },
        h('h1', null, 'Your creatures, moves and pictures'),
        h('p', { class: 'dim' }, `Right now there are ${spCount} species and ${mvCount} moves. Pick a preset and get everything in one go: the built-in one brings in everything that works today, or make your own for your own creatures. You can come back any time from Settings → Data and art.`),
        tools.all,
        !dataOpen ? h('section', { class: 'recommend' },
          h('div', { class: 'grow' }, h('h2', null, 'Or one thing at a time'), h('p', { class: 'dim' }, 'Any single table, picture set or sound set, from an address (a GitHub file works) or from your own files.')),
          h('button', { class: 'btn', onclick: () => { dataOpen = true; render(); } }, 'Show it'),
          h('button', { class: 'btn', onclick: finish }, 'Later'))
          : [
            tools.one,
            h('p', { class: 'micro dim' }, 'Box wallpapers and R.A.N.C.H. scenery: drop PNGs in the textures folder (Settings → Open textures folder). The README there lists every name and size.'),
          ]);
    }

    function render() {
      const s = steps[i];
      if (s.startsWith('intro')) mount(el, h('div', { class: 'setup-card' }, intro(Number(s.slice(5))), nav()));
      else if (s === 'names') {
        mount(el, h('div', { class: 'setup-card wide' }, names(), nav({ nextLabel: 'Next', onNext: async () => {
          const ds = clone(app.dataset); ds.brand = brand; ds.introText = introText.trim() === DEFAULT_INTRO.trim() ? '' : introText; await app.saveDataset(normalizeDataset(ds)); setBrand(brand);
          i++; render();
        } })));
      } else {
        mount(el, h('div', { class: 'setup-card wide scroll' }, data(), nav({ nextLabel: 'Finish', onNext: finish })));
      }
      el.querySelector('.setup-card')?.scrollTo?.(0, 0);
    }
    render();
  });
}
