// First-run setup on the PC (and again any time from Settings):
//   1-3  how it works: storage on the PC, capsules you carry, the phone that watches over them
//   4    make it yours: every name the apps use (app, capsule, creature, network, PC) + logo and capsule art
//   5    optional, recommended: bring in your own species, moves, learnsets, natures, sprites and trainer
//        pictures — each with where to copy it from, what it should look like, and a check
import { h, mount, toast } from '../../../shared/ui/dom.js';
import { capsuleCanvas } from '../../../shared/ui/capsuleArt.js';
import { spriteCanvas } from '../../../shared/ui/art.js';
import { logoMark, svgIcon } from '../../../shared/ui/icons.js';
import { sfx } from '../../../shared/ui/audio.js';
import { setBrand } from '../../../shared/ui/dom.js';
import {
  DEFAULT_BRAND, normalizeBrand, brandRewriter, parsePaste, looksLikeShowdownSet, normalizeDataset,
} from '../../../shared/engine/index.js';
import { everythingTool, extrasTool, spriteTool, trainerTool } from './dataTools.js';
import { DATA_STEPS, detectTarget, importStep } from './dataSteps.js';
import { playIntro, DEFAULT_INTRO } from '../../../shared/ui/introShow.js';

const clone = (x) => JSON.parse(JSON.stringify(x));

function slide(art, title, body) {
  return h('div', { class: 'setup-slide' }, h('div', { class: 'setup-art' }, art), h('h1', null, title), body.map((p) => h('p', { class: 'dim' }, p)));
}

/**
 * Run the setup in `host` (an element that fills the window). Resolves when finished or skipped.
 * opts.start: 'intro' | 'names' | 'data'
 */
export function runSetup(app, host, { start = 'intro' } = {}) {
  return new Promise((resolve) => {
    const steps = ['intro1', 'intro2', 'intro3', 'names', 'data'];
    let i = Math.max(0, steps.indexOf(start === 'intro' ? 'intro1' : start));
    let brand = normalizeBrand(app.dataset.brand);
    let introText = app.dataset.introText || DEFAULT_INTRO;
    const done = {};
    const tools = {};
    let dataOpen = start === 'data';
    let replaceStarters = (app.dataset.species?.length ?? 0) <= 15;
    const el = h('div', { class: 'setup' });
    mount(host, el);

    const finish = async () => {
      const ds = clone(app.dataset);
      ds.brand = brand;
      ds.setup = { done: true, at: Date.now() };
      await app.saveDataset(normalizeDataset(ds));
      sfx('heal');
      resolve();
    };

    function dots() {
      return h('div', { class: 'setup-dots' }, steps.map((s, k) => h('i', { class: k === i ? 'on' : k < i ? 'past' : '' })));
    }
    function nav({ nextLabel = 'Next', onNext = () => { i++; render(); }, back = i > 0, skip = true } = {}) {
      return h('div', { class: 'setup-nav' },
        back ? h('button', { class: 'btn', onclick: () => { i--; render(); } }, 'Back') : h('span'),
        dots(),
        h('div', { class: 'row' },
          skip && i < 3 ? h('button', { class: 'btn ghost', onclick: () => { i = 3; render(); } }, 'Skip intro') : null,
          h('button', { class: 'btn primary', id: 'setup-next', onclick: onNext }, nextLabel)));
    }

    // ---------- 1-3: how it works ----------
    function intro(n) {
      const sp = app.idx.ds.species;
      const pick = (k) => sp[k % Math.max(1, sp.length)]?.id;
      if (n === 1) {
        return slide(h('div', { class: 'art-row' }, logoMark(72), h('div', { class: 'art-sprites' }, [0, 2, 4].map((k) => spriteCanvas(app.bank, pick(k), { scale: 2, animate: true })))),
          'Welcome to Capsule Link',
          ['Creatures can’t step out into our world — but their data can travel with you. This PC is their home: storage boxes, the R.A.N.C.H. to spend time with them, and everything they remember.',
            'Away from the PC they ride in a capsule you carry, and your phone keeps an eye on them.']);
      }
      if (n === 2) {
        return slide(h('div', { class: 'art-row' }, capsuleCanvas({ ring: '#34d1bf', creature: pick(1), bank: app.bank }, 7), svgIcon('dock', { size: 48 })),
          'Carry them in a capsule',
          ['A capsule is a small NFC ball. Set it on the dock plugged into this PC (USB) to send someone in or bring them home — open Capsule Dock from the home screen.',
            'On a walk the capsule counts steps on its own. Nobody leaves their capsule away from the PC: you check on them, they tell you how they are doing, and an empty capsule might even pick up someone new.']);
      }
      return slide(h('div', { class: 'art-row' }, svgIcon('phone', { size: 64 }), capsuleCanvas({ ring: '#ffc93c' }, 5)),
        'Link your phone',
        ['On the phone, open Link and enter the address and six-digit code shown under Phone Link on this PC. Same Wi-Fi works, or a USB-C cable.',
          'Hold a capsule against the back of the phone to read it. Walks, thoughts and anything found along the way sync back here.']);
    }

    // ---------- 4: names ----------
    function names() {
      const preview = h('div', { class: 'brand-preview' });
      const paint = () => {
        const f = brandRewriter(brand);
        mount(preview,
          h('div', { class: 'bp-head' }, logoMark(28), h('b', null, f('Capsule Link'))),
          ['Put a creature in the capsule.', 'Your capsules hold 3 creatures.', 'Contacting Capsule Link Network servers…', 'Creature Storage on your PC'].map((t) => h('p', null, f(t))));
      };
      const field = (key, label, hint) => h('label', { class: 'field' }, h('span', null, label),
        h('input', { type: 'text', maxLength: 40, value: brand[key], placeholder: DEFAULT_BRAND[key], 'data-key': key, oninput: (e) => {
          const raw = { ...brand, [key]: e.target.value };
          // keep plurals following the singular unless they were typed by hand
          if (key === 'ball' && !el.querySelector('[data-key=balls]').dataset.touched) raw.balls = '';
          if (key === 'creature' && !el.querySelector('[data-key=creatures]').dataset.touched) raw.creatures = '';
          if (key === 'balls' || key === 'creatures') e.target.dataset.touched = '1';
          brand = normalizeBrand(raw);
          for (const k of ['balls', 'creatures']) { const inp = el.querySelector(`[data-key=${k}]`); if (inp && inp !== e.target && !inp.dataset.touched) inp.value = brand[k]; }
          paint();
        } }), hint ? h('span', { class: 'micro dim' }, hint) : null);
      const art = (path, label, hint) => h('div', { class: 'art-pick' },
        h('span', null, label), h('span', { class: 'micro dim' }, hint),
        h('label', { class: 'btn small' }, 'Choose PNG…', h('input', { type: 'file', class: 'hidden', accept: 'image/png', onchange: async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          const r = await app.platform.importTextures([{ path, data: new Uint8Array(await f.arrayBuffer()) }]);
          app.textures = r.list; app.applyTextures();
          toast(`${label} updated.`, 'ok'); paint(); render();
        } })));
      paint();
      return h('div', { class: 'setup-names' },
        h('div', { class: 'col' },
          h('h1', null, 'Make it yours'),
          h('p', { class: 'dim' }, 'Every name the apps use comes from here — on this PC, on your phone after it syncs, on ID cards and in messages. Type exactly what you want to see.'),
          h('div', { class: 'form-grid' },
            field('app', 'App name'),
            field('company', 'Network / company', 'Shown while connecting to your creatures.'),
            field('ball', 'What creatures travel in'),
            field('balls', '…more than one'),
            field('creature', 'What you call them'),
            field('creatures', '…more than one'),
            field('pc', 'The computer', 'Usually “PC”.'),
            field('product', 'The device’s product name', 'Used in the introduction.')),
          h('details', { class: 'intro-edit' },
            h('summary', null, 'Introduction text'),
            h('p', { class: 'micro dim' }, 'Shown full screen the very first time the apps start. Slides are separated by a line with ---. “## ” starts a headline, “> ” a small line above it, “- Label: text” a feature card. The names above are filled in automatically.'),
            h('textarea', { class: 'code paste small', spellcheck: false, oninput: (e) => { introText = e.target.value; } }, introText),
            h('div', { class: 'row' },
              h('button', { class: 'btn small', onclick: async () => { const host = h('div', { class: 'setup-overlay bare' }); document.body.append(host); setBrand(brand); try { await playIntro(host, { text: introText }); } finally { host.remove(); } } }, 'Preview'),
              h('button', { class: 'btn small', onclick: (e) => { introText = DEFAULT_INTRO; e.target.closest('details').querySelector('textarea').value = DEFAULT_INTRO; } }, 'Restore the original'))),
          h('h2', null, 'Pictures'),
          art('ui/logo.png', 'Logo', 'Square, transparent, 256×256 or larger.'),
          art('ui/app-icon.png', 'App icon', 'Square PNG, 512×512. Window, taskbar, shortcuts and the phone’s home screen.'),
          art('ui/ball.png', 'Capsule picture', 'One picture, or a strip of 7 poses (see docs/templates/capsule-sheet-guide.png).'),
          h('p', { class: 'micro dim' }, 'Creature sprites, trainer pictures and backgrounds come in the next step.')),
        h('div', { class: 'col' }, h('h2', null, 'Preview'), preview));
    }

    // ---------- 5: data ----------
    function dataStep(step) {
      const st = done[step.id] ?? (done[step.id] = { status: '', text: '' });
      const ta = h('textarea', { class: 'code paste small', spellcheck: false, placeholder: 'Paste here…', oninput: (e) => { st.text = e.target.value; st.status = ''; } }, st.text.length > 200000 ? '' : st.text);
      const statusEl = h('div', { class: `data-status ${st.ok ? 'ok' : st.status ? 'err' : ''}` }, st.status);
      async function check(text) {
        st.text = text ?? st.text;
        if (!st.text.trim()) { st.status = 'Paste something first.'; st.ok = false; render(); return; }
        if (looksLikeShowdownSet(st.text)) { st.status = 'That is a Showdown team, which never imports. This step needs the data file named above.'; st.ok = false; render(); return; }
        let parsed;
        try { parsed = parsePaste(st.text); } catch (e) { st.status = `That could not be read: ${e.message}`; st.ok = false; render(); return; }
        // is this what this step expects?
        const target = detectTarget(parsed, step.target);
        const expect = step.target;
        if (parsed.format === 'dataset') { st.status = 'That is a whole Capsule Link data set — load it in Data Lab → Rules instead.'; st.ok = false; render(); return; }
        if (target !== expect && !(step.mode === 'update')) {
          st.status = `This looks like ${target === 'temperaments' ? 'natures' : target === 'learnset' ? 'learnsets' : target} data, not ${step.title.toLowerCase()}. Check you copied ${step.file ?? 'the right table'}.`;
          st.ok = false; render(); return;
        }
        let rep;
        try { rep = await importStep(app, step, st.text, { replace: replaceStarters }); } catch (e) { st.status = `Import failed: ${e.message}`; st.ok = false; render(); return; }
        const n = rep.added + rep.updated;
        if (!n) { st.status = `Nothing matched. ${rep.warnings[0] ?? 'Check the headers or the file.'}`; st.ok = false; render(); return; }
        st.ok = true;
        const cut = parsed.partial ? ` · ⚠ the paste stopped part-way (${parsed.partial.kept} entries came through) — use Download for me to get the rest` : '';
        st.status = `✓ ${rep.added ? `${rep.added} added` : ''}${rep.added && rep.updated ? ', ' : ''}${rep.updated ? `${rep.updated} updated` : ''}${rep.skipped ? ` · ${rep.skipped} skipped` : ''}${rep.warnings.length ? ` · ${rep.warnings.length} note${rep.warnings.length > 1 ? 's' : ''}` : ''}${cut}`;
        if (st.text.length > 200000) st.text = '';
        sfx('heal');
        render();
      }
      return h('section', { class: `data-step ${st.ok ? 'done' : ''}` },
        h('div', { class: 'row' },
          h('span', { class: 'step-check' }, st.ok ? '✓' : ''),
          h('div', { class: 'grow' }, h('h3', null, step.title, step.optional ? h('span', { class: 'chip micro' }, 'optional') : null), h('p', { class: 'micro dim' }, step.what)),
          step.links.map(([l, u]) => h('a', { class: 'btn small', href: u, target: '_blank', rel: 'noopener' }, l))),
        h('p', { class: 'micro' }, step.how),
        h('details', null, h('summary', { class: 'micro dim' }, 'What it should look like'), h('pre', { class: 'code micro' }, step.looks)),
        ta,
        h('div', { class: 'row' },
          statusEl,
          h('span', { class: 'spacer' }),
          h('button', { class: 'btn small', onclick: async () => {
            const f = await app.platform.importFile([{ name: 'Data file', extensions: ['ts', 'js', 'json', 'csv', 'tsv', 'txt'] }]);
            if (f) check(f.text);
          } }, 'Load a file'),
          h('button', { class: 'btn small', onclick: () => check() }, 'Check and add'),
          step.raw ? h('button', { class: 'btn small primary', onclick: async (e) => {
            e.target.disabled = true; e.target.textContent = 'Downloading…';
            try {
              const r = await app.platform.fetchUrl(step.raw, 'text');
              if (!r.ok) throw new Error(`the server answered ${r.status}`);
              await check(r.text);
            } catch (err) { st.status = `Download failed: ${err.message}. Use “Raw text to copy” and paste instead.`; st.ok = false; render(); }
          } }, 'Download for me') : null));
    }

    function data() {
      const spCount = app.idx.ds.species.length, mvCount = app.idx.ds.moves.length;
      tools.all = tools.all ?? everythingTool(app, { big: true, onDone: () => render() });
      tools.extras = tools.extras ?? extrasTool(app);
      tools.sprites = tools.sprites ?? spriteTool(app);
      tools.trainers = tools.trainers ?? trainerTool(app);
      return h('div', { class: 'setup-data' },
        h('h1', null, 'Your creatures, moves and pictures'),
        h('p', { class: 'dim' }, `Right now there are ${spCount} species and ${mvCount} moves. Bring in the real lists so battles on Showdown line up. You can come back any time from Settings → Run setup again.`),
        tools.all,
        !dataOpen ? h('section', { class: 'recommend' },
          h('div', { class: 'grow' }, h('h2', null, 'Or do it step by step'), h('p', { class: 'dim' }, 'Each file on its own, with a link to copy from, an example of what to paste, and a check that tells you if it worked. Handy for your own data.')),
          h('button', { class: 'btn', onclick: () => { dataOpen = true; render(); } }, 'Show the steps'),
          h('button', { class: 'btn', onclick: finish }, 'Later'))
          : [
            h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: replaceStarters, onchange: (e) => { replaceStarters = e.target.checked; } }), 'Replace the placeholder creatures and moves (your own creatures keep their species numbers and come back once that number exists)'),
            DATA_STEPS.map(dataStep), tools.extras, tools.sprites, tools.trainers,
            h('p', { class: 'micro dim' }, 'Box wallpapers and R.A.N.C.H. scenery: drop PNGs in the textures folder (Settings → Open textures folder). The README there lists every name and size.'),
          ]);
    }

    function render() {
      const s = steps[i];
      if (s.startsWith('intro')) mount(el, h('div', { class: 'setup-card' }, intro(Number(s.slice(5))), nav()));
      else if (s === 'names') {
        mount(el, h('div', { class: 'setup-card wide' }, names(), nav({ nextLabel: 'Next', onNext: async () => {
          const ds = clone(app.dataset); ds.brand = brand; ds.introText = introText.trim() === DEFAULT_INTRO.trim() ? '' : introText; await app.saveDataset(normalizeDataset(ds)); setBrand(brand);
          i++; render();
        } })));
      } else {
        mount(el, h('div', { class: 'setup-card wide scroll' }, data(), nav({ nextLabel: 'Finish', onNext: finish })));
      }
      el.querySelector('.setup-card')?.scrollTo?.(0, 0);
    }
    render();
  });
}
