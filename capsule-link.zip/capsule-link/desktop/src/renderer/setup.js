// First-run setup on the PC (and again any time from Settings):
//   1-3  how it works: storage on the PC, capsules you carry, the phone that watches over them
//   4    make it yours: every name the apps use (app, capsule, creature, network, PC) + logo and capsule art
//   5    optional, recommended: bring in your own species, moves, learnsets, natures, sprites and trainer
//        pictures — each with where to copy it from, what it should look like, and a check
import { h, mount, toast } from '../../../shared/ui/dom.js';
import { capsuleCanvas } from '../../../shared/ui/capsuleArt.js';
import { spriteCanvas } from '../../../shared/ui/art.js';
import { logoMark, svgIcon } from '../../../shared/ui/icons.js';
import { sfx } from '../../../shared/ui/audio.js';
import { setBrand } from '../../../shared/ui/dom.js';
import {
  DEFAULT_BRAND, normalizeBrand, brandRewriter, parsePaste, guessMapping, applyImport, normalizeDataset, looksLikeShowdownSet,
} from '../../../shared/engine/index.js';
import { extrasTool, spriteTool, trainerTool } from './dataTools.js';
import { playIntro, DEFAULT_INTRO } from '../../../shared/ui/introShow.js';

const SD = 'https://github.com/smogon/pokemon-showdown/blob/master/data';
const RAW = 'https://raw.githubusercontent.com/smogon/pokemon-showdown/master/data';
const clone = (x) => JSON.parse(JSON.stringify(x));

/** The data steps, in the order that works (learnsets need species and moves first). */
const DATA_STEPS = [
  {
    id: 'species', target: 'species', title: 'Species', file: 'pokedex.ts',
    what: 'Names, numbers, types, base stats, abilities and evolutions.',
    how: 'Press Download for me. (By hand: open the raw text, select all, copy and paste below — exactly as it is.)',
    looks: 'export const Pokedex: import(\'../sim/dex-species\').SpeciesDataTable = {\n\tbulbasaur: {\n\t\tnum: 1,\n\t\tname: "Bulbasaur",\n\t\ttypes: ["Grass", "Poison"], …',
    raw: `${RAW}/pokedex.ts`,
    links: [['View on GitHub', `${SD}/pokedex.ts`], ['Raw text to copy', `${RAW}/pokedex.ts`]],
  },
  {
    id: 'moves', target: 'moves', title: 'Moves', file: 'moves.ts',
    what: 'Every move: type, category, power, accuracy, PP and priority.',
    how: 'Press Download for me. This file is too big for GitHub’s normal page to copy in one go, so if you paste by hand use the raw text, or save it and use Load a file.',
    looks: 'export const Moves: import(\'../sim/dex-moves\').MoveDataTable = {\n\tabsorb: {\n\t\tnum: 71,\n\t\taccuracy: 100,\n\t\tbasePower: 20, …',
    raw: `${RAW}/moves.ts`,
    links: [['View on GitHub', `${SD}/moves.ts`], ['Raw text to copy', `${RAW}/moves.ts`]],
  },
  {
    id: 'learnset', target: 'learnset', title: 'Learnsets', file: 'learnsets.ts', big: true,
    what: 'Which moves each species learns by level (the newest generation each appears in).',
    how: 'Press Download for me (several megabytes; takes a few seconds). By hand: save the raw page and use Load a file.',
    looks: 'export const Learnsets: import(\'../sim/dex-species\').LearnsetDataTable = {\n\tbulbasaur: {\n\t\tlearnset: {\n\t\t\tabsorb: ["9L1", "8L1"], …',
    raw: `${RAW}/learnsets.ts`,
    links: [['View on GitHub', `${SD}/learnsets.ts`], ['Raw text to copy', `${RAW}/learnsets.ts`]],
  },
  {
    id: 'natures', target: 'temperaments', title: 'Natures', file: 'natures.ts',
    what: 'Nature names with the stat each one raises and lowers.',
    how: 'Press Download for me, or copy the raw text and paste it.',
    looks: 'export const Natures: import(\'../sim/dex-data\').NatureDataTable = {\n\tadamant: {\n\t\tname: "Adamant",\n\t\tplus: \'atk\',\n\t\tminus: \'spa\',\n\t}, …',
    raw: `${RAW}/natures.ts`,
    links: [['View on GitHub', `${SD}/natures.ts`], ['Raw text to copy', `${RAW}/natures.ts`]],
  },
  {
    id: 'items', target: 'items', title: 'Items', file: 'items.ts', optional: true,
    what: 'Every item. Berries become food that grows on the berry farm; the rest are held items for battles.',
    how: 'Optional. Press Download for me. Items you already have keep what they do; new ones are added.',
    looks: 'export const Items: import(\'../sim/dex-items\').ItemDataTable = {\n\tabilityshield: {\n\t\tname: "Ability Shield",\n\t\tspritenum: 746, …',
    raw: `${RAW}/items.ts`,
    links: [['View on GitHub', `${SD}/items.ts`], ['Raw text to copy', `${RAW}/items.ts`]],
  },
  {
    id: 'itemtext', target: 'items', title: 'Item descriptions', file: 'text/items.ts', optional: true, mode: 'update',
    what: 'The one-line description shown for each item.',
    how: 'Optional. Press Download for me after Items. It only adds descriptions.',
    looks: 'export const ItemsText: {[k: string]: ItemText} = {\n\tabilityshield: {\n\t\tname: "Ability Shield",\n\t\tdesc: …',
    raw: `${RAW}/text/items.ts`,
    links: [['View on GitHub', `${SD}/text/items.ts`], ['Raw text to copy', `${RAW}/text/items.ts`]],
  },
  {
    id: 'movetext', target: 'moves', title: 'Move descriptions', file: 'text/moves.ts', optional: true, mode: 'update',
    what: 'The one-line description shown for each move.',
    how: 'Optional. Press Download for me. It only adds descriptions to moves you already have.',
    looks: 'export const MovesText: {[k: string]: MoveText} = {\n\tabsorb: {\n\t\tname: "Absorb",\n\t\tdesc: "The user recovers 1/2 …',
    raw: `${RAW}/text/moves.ts`,
    links: [['View on GitHub', `${SD}/text/moves.ts`], ['Raw text to copy', `${RAW}/text/moves.ts`]],
  },
];

function slide(art, title, body) {
  return h('div', { class: 'setup-slide' }, h('div', { class: 'setup-art' }, art), h('h1', null, title), body.map((p) => h('p', { class: 'dim' }, p)));
}

/**
 * Run the setup in `host` (an element that fills the window). Resolves when finished or skipped.
 * opts.start: 'intro' | 'names' | 'data'
 */
export function runSetup(app, host, { start = 'intro' } = {}) {
  return new Promise((resolve) => {
    const steps = ['intro1', 'intro2', 'intro3', 'names', 'data'];
    let i = Math.max(0, steps.indexOf(start === 'intro' ? 'intro1' : start));
    let brand = normalizeBrand(app.dataset.brand);
    let introText = app.dataset.introText || DEFAULT_INTRO;
    const done = {};
    const tools = {};
    let dataOpen = start === 'data';
    let replaceStarters = (app.dataset.species?.length ?? 0) <= 15;
    const el = h('div', { class: 'setup' });
    mount(host, el);

    const finish = async () => {
      const ds = clone(app.dataset);
      ds.brand = brand;
      ds.setup = { done: true, at: Date.now() };
      await app.saveDataset(normalizeDataset(ds));
      sfx('heal');
      resolve();
    };

    function dots() {
      return h('div', { class: 'setup-dots' }, steps.map((s, k) => h('i', { class: k === i ? 'on' : k < i ? 'past' : '' })));
    }
    function nav({ nextLabel = 'Next', onNext = () => { i++; render(); }, back = i > 0, skip = true } = {}) {
      return h('div', { class: 'setup-nav' },
        back ? h('button', { class: 'btn', onclick: () => { i--; render(); } }, 'Back') : h('span'),
        dots(),
        h('div', { class: 'row' },
          skip && i < 3 ? h('button', { class: 'btn ghost', onclick: () => { i = 3; render(); } }, 'Skip intro') : null,
          h('button', { class: 'btn primary', id: 'setup-next', onclick: onNext }, nextLabel)));
    }

    // ---------- 1-3: how it works ----------
    function intro(n) {
      const sp = app.idx.ds.species;
      const pick = (k) => sp[k % Math.max(1, sp.length)]?.id;
      if (n === 1) {
        return slide(h('div', { class: 'art-row' }, logoMark(72), h('div', { class: 'art-sprites' }, [0, 2, 4].map((k) => spriteCanvas(app.bank, pick(k), { scale: 2, animate: true })))),
          'Welcome to Capsule Link',
          ['Creatures can’t step out into our world — but their data can travel with you. This PC is their home: storage boxes, the R.A.N.C.H. to spend time with them, and everything they remember.',
            'Away from the PC they ride in a capsule you carry, and your phone keeps an eye on them.']);
      }
      if (n === 2) {
        return slide(h('div', { class: 'art-row' }, capsuleCanvas({ ring: '#34d1bf', creature: pick(1), bank: app.bank }, 7), svgIcon('dock', { size: 48 })),
          'Carry them in a capsule',
          ['A capsule is a small NFC ball. Set it on the dock plugged into this PC (USB) to send someone in or bring them home — open Capsule Dock from the home screen.',
            'On a walk the capsule counts steps on its own. Nobody leaves their capsule away from the PC: you check on them, they tell you how they are doing, and an empty capsule might even pick up someone new.']);
      }
      return slide(h('div', { class: 'art-row' }, svgIcon('phone', { size: 64 }), capsuleCanvas({ ring: '#ffc93c' }, 5)),
        'Link your phone',
        ['On the phone, open Link and enter the address and six-digit code shown under Phone Link on this PC. Same Wi-Fi works, or a USB-C cable.',
          'Hold a capsule against the back of the phone to read it. Walks, thoughts and anything found along the way sync back here.']);
    }

    // ---------- 4: names ----------
    function names() {
      const preview = h('div', { class: 'brand-preview' });
      const paint = () => {
        const f = brandRewriter(brand);
        mount(preview,
          h('div', { class: 'bp-head' }, logoMark(28), h('b', null, f('Capsule Link'))),
          ['Put a creature in the capsule.', 'Your capsules hold 3 creatures.', 'Contacting Capsule Link Network servers…', 'Creature Storage on your PC'].map((t) => h('p', null, f(t))));
      };
      const field = (key, label, hint) => h('label', { class: 'field' }, h('span', null, label),
        h('input', { type: 'text', maxLength: 40, value: brand[key], placeholder: DEFAULT_BRAND[key], 'data-key': key, oninput: (e) => {
          const raw = { ...brand, [key]: e.target.value };
          // keep plurals following the singular unless they were typed by hand
          if (key === 'ball' && !el.querySelector('[data-key=balls]').dataset.touched) raw.balls = '';
          if (key === 'creature' && !el.querySelector('[data-key=creatures]').dataset.touched) raw.creatures = '';
          if (key === 'balls' || key === 'creatures') e.target.dataset.touched = '1';
          brand = normalizeBrand(raw);
          for (const k of ['balls', 'creatures']) { const inp = el.querySelector(`[data-key=${k}]`); if (inp && inp !== e.target && !inp.dataset.touched) inp.value = brand[k]; }
          paint();
        } }), hint ? h('span', { class: 'micro dim' }, hint) : null);
      const art = (path, label, hint) => h('div', { class: 'art-pick' },
        h('span', null, label), h('span', { class: 'micro dim' }, hint),
        h('label', { class: 'btn small' }, 'Choose PNG…', h('input', { type: 'file', class: 'hidden', accept: 'image/png', onchange: async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          const r = await app.platform.importTextures([{ path, data: new Uint8Array(await f.arrayBuffer()) }]);
          app.textures = r.list; app.applyTextures();
          toast(`${label} updated.`, 'ok'); paint(); render();
        } })));
      paint();
      return h('div', { class: 'setup-names' },
        h('div', { class: 'col' },
          h('h1', null, 'Make it yours'),
          h('p', { class: 'dim' }, 'Every name the apps use comes from here — on this PC, on your phone after it syncs, on ID cards and in messages. Type exactly what you want to see.'),
          h('div', { class: 'form-grid' },
            field('app', 'App name'),
            field('company', 'Network / company', 'Shown while connecting to your creatures.'),
            field('ball', 'What creatures travel in'),
            field('balls', '…more than one'),
            field('creature', 'What you call them'),
            field('creatures', '…more than one'),
            field('pc', 'The computer', 'Usually “PC”.'),
            field('product', 'The device’s product name', 'Used in the introduction.')),
          h('details', { class: 'intro-edit' },
            h('summary', null, 'Introduction text'),
            h('p', { class: 'micro dim' }, 'Shown full screen the very first time the apps start. Slides are separated by a line with ---. “## ” starts a headline, “> ” a small line above it, “- Label: text” a feature card. The names above are filled in automatically.'),
            h('textarea', { class: 'code paste small', spellcheck: false, oninput: (e) => { introText = e.target.value; } }, introText),
            h('div', { class: 'row' },
              h('button', { class: 'btn small', onclick: async () => { const host = h('div', { class: 'setup-overlay bare' }); document.body.append(host); setBrand(brand); try { await playIntro(host, { text: introText }); } finally { host.remove(); } } }, 'Preview'),
              h('button', { class: 'btn small', onclick: (e) => { introText = DEFAULT_INTRO; e.target.closest('details').querySelector('textarea').value = DEFAULT_INTRO; } }, 'Restore the original'))),
          h('h2', null, 'Pictures'),
          art('ui/logo.png', 'Logo', 'Square, transparent, 256×256 or larger.'),
          art('ui/app-icon.png', 'App icon', 'Square PNG, 512×512. Window, taskbar, shortcuts and the phone’s home screen.'),
          art('ui/ball.png', 'Capsule picture', 'One picture, or a strip of 7 poses (see docs/templates/capsule-sheet-guide.png).'),
          h('p', { class: 'micro dim' }, 'Creature sprites, trainer pictures and backgrounds come in the next step.')),
        h('div', { class: 'col' }, h('h2', null, 'Preview'), preview));
    }

    // ---------- 5: data ----------
    function dataStep(step) {
      const st = done[step.id] ?? (done[step.id] = { status: '', text: '' });
      const ta = h('textarea', { class: 'code paste small', spellcheck: false, placeholder: 'Paste here…', oninput: (e) => { st.text = e.target.value; st.status = ''; } }, st.text.length > 200000 ? '' : st.text);
      const statusEl = h('div', { class: `data-status ${st.ok ? 'ok' : st.status ? 'err' : ''}` }, st.status);
      async function check(text) {
        st.text = text ?? st.text;
        if (!st.text.trim()) { st.status = 'Paste something first.'; st.ok = false; render(); return; }
        if (looksLikeShowdownSet(st.text)) { st.status = 'That is a Showdown team, which never imports. This step needs the data file named above.'; st.ok = false; render(); return; }
        let parsed;
        try { parsed = parsePaste(st.text); } catch (e) { st.status = `That could not be read: ${e.message}`; st.ok = false; render(); return; }
        // is this what this step expects?
        const target = parsed.target ?? (parsed.format === 'lines' ? 'learnset'
          // moves have a "type" too, so look for move columns first
          : parsed.columns.some((c) => /^spritenum$|^isberry$|^megastone$/i.test(c)) ? 'items'
          : parsed.columns.some((c) => /basepower|^accuracy$|^pp$|^category$/i.test(c)) ? 'moves'
            : parsed.columns.some((c) => /basestats|^types$|abilities|heightm/i.test(c)) ? 'species' : step.target);
        const expect = step.target;
        if (parsed.format === 'dataset') { st.status = 'That is a whole Capsule Link data set — load it in Data Lab → Rules instead.'; st.ok = false; render(); return; }
        if (target !== expect && !(step.mode === 'update')) {
          st.status = `This looks like ${target === 'temperaments' ? 'natures' : target === 'learnset' ? 'learnsets' : target} data, not ${step.title.toLowerCase()}. Check you copied ${step.file ?? 'the right table'}.`;
          st.ok = false; render(); return;
        }
        const ds = clone(app.dataset);
        if (step.id === 'species' && replaceStarters) { ds.species = []; ds.types = []; ds.typeChart = ds.typeChart ?? {}; }
        if (step.id === 'moves' && replaceStarters) ds.moves = [];
        const mapping = guessMapping(parsed.columns, expect);
        let rep;
        try { rep = applyImport(ds, expect, parsed.rows, mapping, { mode: step.mode === 'update' && expect === 'items' ? 'update' : 'merge', mainOnly: expect === 'species' || expect === 'moves' || expect === 'items' }); } catch (e) { st.status = `Import failed: ${e.message}`; st.ok = false; render(); return; }
        const n = rep.added + rep.updated;
        if (!n) { st.status = `Nothing matched. ${rep.warnings[0] ?? 'Check the headers or the file.'}`; st.ok = false; render(); return; }
        await app.saveDataset(normalizeDataset(ds));
        st.ok = true;
        const cut = parsed.partial ? ` · ⚠ the paste stopped part-way (${parsed.partial.kept} entries came through) — use Download for me to get the rest` : '';
        st.status = `✓ ${rep.added ? `${rep.added} added` : ''}${rep.added && rep.updated ? ', ' : ''}${rep.updated ? `${rep.updated} updated` : ''}${rep.skipped ? ` · ${rep.skipped} skipped` : ''}${rep.warnings.length ? ` · ${rep.warnings.length} note${rep.warnings.length > 1 ? 's' : ''}` : ''}${cut}`;
        if (st.text.length > 200000) st.text = '';
        sfx('heal');
        render();
      }
      return h('section', { class: `data-step ${st.ok ? 'done' : ''}` },
        h('div', { class: 'row' },
          h('span', { class: 'step-check' }, st.ok ? '✓' : ''),
          h('div', { class: 'grow' }, h('h3', null, step.title, step.optional ? h('span', { class: 'chip micro' }, 'optional') : null), h('p', { class: 'micro dim' }, step.what)),
          step.links.map(([l, u]) => h('a', { class: 'btn small', href: u, target: '_blank', rel: 'noopener' }, l))),
        h('p', { class: 'micro' }, step.how),
        h('details', null, h('summary', { class: 'micro dim' }, 'What it should look like'), h('pre', { class: 'code micro' }, step.looks)),
        ta,
        h('div', { class: 'row' },
          statusEl,
          h('span', { class: 'spacer' }),
          h('button', { class: 'btn small', onclick: async () => {
            const f = await app.platform.importFile([{ name: 'Data file', extensions: ['ts', 'js', 'json', 'csv', 'tsv', 'txt'] }]);
            if (f) check(f.text);
          } }, 'Load a file'),
          h('button', { class: 'btn small', onclick: () => check() }, 'Check and add'),
          step.raw ? h('button', { class: 'btn small primary', onclick: async (e) => {
            e.target.disabled = true; e.target.textContent = 'Downloading…';
            try {
              const r = await app.platform.fetchUrl(step.raw, 'text');
              if (!r.ok) throw new Error(`the server answered ${r.status}`);
              await check(r.text);
            } catch (err) { st.status = `Download failed: ${err.message}. Use “Raw text to copy” and paste instead.`; st.ok = false; render(); }
          } }, 'Download for me') : null));
    }

    function data() {
      const spCount = app.idx.ds.species.length, mvCount = app.idx.ds.moves.length;
      tools.extras = tools.extras ?? extrasTool(app);
      tools.sprites = tools.sprites ?? spriteTool(app);
      tools.trainers = tools.trainers ?? trainerTool(app);
      return h('div', { class: 'setup-data' },
        h('h1', null, 'Your creatures, moves and pictures'),
        h('p', { class: 'dim' }, `Right now there are ${spCount} placeholder species and ${mvCount} moves. Bring in the real lists so battles on Showdown line up — do these in order. You can come back any time from Settings → Run setup again.`),
        !dataOpen ? h('section', { class: 'recommend' },
          h('div', { class: 'grow' }, h('h2', null, 'Recommended: set up your data now'), h('p', { class: 'dim' }, 'About fifteen minutes. Each step has a link to copy from, an example of what to paste, and a check that tells you if it worked.')),
          h('button', { class: 'btn primary', onclick: () => { dataOpen = true; render(); } }, 'Set it up now'),
          h('button', { class: 'btn', onclick: finish }, 'Later'))
          : [
            h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: replaceStarters, onchange: (e) => { replaceStarters = e.target.checked; } }), 'Replace the placeholder creatures and moves (your own creatures keep their species numbers and come back once that number exists)'),
            DATA_STEPS.map(dataStep), tools.extras, tools.sprites, tools.trainers,
            h('p', { class: 'micro dim' }, 'Box wallpapers and R.A.N.C.H. scenery: drop PNGs in the textures folder (Settings → Open textures folder). The README there lists every name and size.'),
          ]);
    }

    function render() {
      const s = steps[i];
      if (s.startsWith('intro')) mount(el, h('div', { class: 'setup-card' }, intro(Number(s.slice(5))), nav()));
      else if (s === 'names') {
        mount(el, h('div', { class: 'setup-card wide' }, names(), nav({ nextLabel: 'Next', onNext: async () => {
          const ds = clone(app.dataset); ds.brand = brand; ds.introText = introText.trim() === DEFAULT_INTRO.trim() ? '' : introText; await app.saveDataset(normalizeDataset(ds)); setBrand(brand);
          i++; render();
        } })));
      } else {
        mount(el, h('div', { class: 'setup-card wide scroll' }, data(), nav({ nextLabel: 'Finish', onNext: finish })));
      }
      el.querySelector('.setup-card')?.scrollTo?.(0, 0);
    }
    render();
  });
}
