// Capsule Link — PC storage terminal (renderer).
import { indexDataset, tickAll, MSG } from '../../../shared/engine/index.js';
import { SpriteBank } from '../../../shared/ui/art.js';
import { h, mount, toast, chooseDialog, setBrand, brandText } from '../../../shared/ui/dom.js';
import { sfx, setSound } from '../../../shared/ui/audio.js';
import { HubClient } from '../../../shared/net/client.js';
import { getPlatform } from './platform.js';
import { SerialDock, VirtualDock } from './dock.js';
import { DockController } from './dockController.js';
import { ingestBattle } from '../../../shared/ui/showdownUi.js';
import { party, toHex, fromHex } from '../../../shared/engine/index.js';
import { boxesView } from './views/boxes.js';
import { ranchView } from './views/ranch.js';
import { dockView } from './views/dock.js';
import { battleView, watchFriendBattles } from './views/battle.js';
import { dataLabView } from './views/datalab.js';
import { phoneView } from './views/phone.js';
import { settingsView } from './views/settings.js';
import { homeView } from './views/home.js';
import { trainerView } from './views/trainer.js';
import { marketView } from './views/market.js';
import { activitiesView } from './views/activities.js';
import { friendsView } from './views/friends.js';
import { logOn } from './login.js';
import { avatarEl } from '../../../shared/ui/idcard.js';
import { svgIcon, logoMark } from '../../../shared/ui/icons.js';
import { setUiArt } from '../../../shared/ui/brandArt.js';
import { setCryResolver } from '../../../shared/ui/audio.js';
import { watchUpdateDrops } from './updates.js';
import { ensureTrainerCard } from '../../../shared/engine/index.js';
import { applyTheme } from './theme.js';
applyTheme();

const VIEWS = [
  { id: 'home', label: 'Home', make: homeView },
  { id: 'storage', label: 'Creature Storage', make: boxesView, aliases: ['boxes'] },
  { id: 'ranch', label: 'R.A.N.C.H.', make: ranchView, immersive: true },
  { id: 'market', label: 'Market', make: marketView, aliases: ['shop', 'bag'] },
  { id: 'activities', label: 'Activities', make: activitiesView },
  { id: 'friends', label: 'Friends', make: friendsView },
  { id: 'dock', label: 'Capsule Dock', make: dockView },
  { id: 'battle', label: 'Battle Link', make: battleView },
  { id: 'trainer', label: 'Trainer ID', make: trainerView },
  { id: 'phone', label: 'Phone Link', make: phoneView },
  { id: 'data', label: 'Data Lab', make: dataLabView },
  { id: 'settings', label: 'Settings', make: settingsView },
];

class App {
  constructor() {
    this.platform = getPlatform();
    this.view = null;
    this.viewId = 'home';
    this.pending = [];
    this.queue = Promise.resolve();
    this.listeners = new Set();
    this.status = '';
  }

  async boot() {
    
    const data = await this.platform.load();
    this.save = data.save;
    this.rev = data.rev;
    this.hubInfo = data.hub;
    this.profiles = data.profiles ?? [];
    this.paths = data.paths;
    this.setDataset(data.dataset, false);
    this.textures = data.textures ?? {};
    setUiArt((p) => this.textures[p.toLowerCase()] ?? null, () => Object.keys(this.textures ?? {}));
    setCryResolver((p) => this.textures[p.toLowerCase()] ?? null);
    this.bank = new SpriteBank({ idx: this.idx, resolveTexture: (p) => this.textures[p.toLowerCase()] ?? null });
    this.bank.onChange(() => this.view?.art?.());
    this.applySettings();
    tickAll(this.idx, this.save);

    this.platform.onSaveChanged(({ save, rev, reason }) => {
      this.save = save;
      this.rev = rev;
      for (const m of this.pending) m.fn(this.save); // keep local changes that are still on their way
      if (reason === 'sync') this.say('Your phone synced.');
      if (reason === 'vtag' && this.virtualDock) {
        // a phone tapped one of the virtual capsules: pick up what it wrote
        this.virtualDock.load();
        if (this.dockCtl?.current?.tag?.virtual) this.dockCtl.refresh().then(() => this.dockCtl.emit()).catch(() => {});
        this.say('Your phone tapped a virtual capsule.');
      }
      this.refresh();
    });
    this.platform.onDatasetChanged(({ dataset }) => { if (this.tempData) { this.homeDataset = dataset; return; } this.setDataset(dataset); this.refresh(); });
    this.platform.onTexturesChanged((list) => { this.textures = list; this.applyTextures(); });
    // friends: battle invites and replies reach you wherever you are in the app
    try { watchFriendBattles(this); } catch (e) { console.error(e); }
    this.platform.onHubChanged((info) => { this.hubInfo = { ...this.hubInfo, ...info }; this.emit('hub'); this.renderTop(); });
    this.platform.onSerialChoose(async (ports) => {
      const pick = await chooseDialog('Choose the dock', ports.map((p) => ({ value: p.portId, label: p.name, detail: p.vendorId ? `USB ${p.vendorId}:${p.productId}` : '' })), { empty: 'No serial devices found. Plug in the dock and try again.' });
      this.platform.chooseSerial(pick ?? '');
    });

    this.virtualDock = new VirtualDock(() => this.save, (fn) => this.commit(fn, 'virtual-tag', { quiet: true }));
    this.dock = this.virtualDock;
    this.serialDock = SerialDock.supported() ? new SerialDock() : null;
    this.dockCtl = new DockController(this);
    this.dockCtl.attach(this.virtualDock);
    this.serialDock?.on('status', (st) => {
      if (st === 'disconnected' && this.dock === this.serialDock) { this.dockCtl.attach(this.virtualDock); this.say('The USB dock was unplugged. Using the virtual dock.'); }
    });
    // reconnect a dock that was allowed before
    if (this.serialDock && this.platform.kind === 'desktop') {
      navigator.serial.getPorts().then((ports) => {
        if (!ports.length) return;
        return this.serialDock.connect({ ask: false }).then(() => { this.dockCtl.attach(this.serialDock); this.say('Dock reconnected.'); });
      }).catch(() => {});
    }

    // the renderer joins its own hub, to see phones' simulated capsules placed on the dock
    if (this.platform.hasHub) this.connectHub();
    if (this.save.settings.usbAuto) this.keepUsb(true);

    // battles finished in the Showdown window come back here
    this.platform.onShowdown((msg) => this.onShowdown(msg));

    watchUpdateDrops(this);
    window.addEventListener('hashchange', () => { try { if (this.viewEl) this.go(location.hash.slice(1)); } catch { /* ignore */ } });
    setInterval(() => { if (!this.viewEl) return; tickAll(this.idx, this.save); this.view?.tick?.(); }, 60000);
    let start = 'home';
    try { start = location.hash.slice(1) || 'home'; } catch { /* preview frame */ }
    await this.logOnFlow({ boot: true, start });
  }

  /** The log-on screen; then the PC menu (or the screen named in the address). */
  async logOnFlow({ boot = false, start = 'home' } = {}) {
    this.view?.dispose?.();
    this.view = null;
    this.viewEl = null;
    const r = await logOn(this, { boot });
    this.save = r.save;
    this.rev = r.rev;
    this.pending = [];
    ensureTrainerCard(this.save);
    this.applySettings();
    tickAll(this.idx, this.save);
    if (this.client) { try { this.client.close(); } catch { /* closed */ } this.client = null; }
    if (this.platform.hasHub) this.connectHub();
    this.buildShell();
    this.go(start);
    this.say(`Signed in as ${this.save.trainer?.name ?? 'Trainer'}.`);
  }

  async logOff() {
    sfx('logoff');
    this.profiles = await this.platform.listProfiles();
    await this.logOnFlow({ boot: false });
  }

  /** After textures change: creature sprites, the logo, the ball and trainer pictures follow. */
  applyTextures() {
    this.bank?.setResolver((p) => this.textures[p.toLowerCase()] ?? null);
    setUiArt((p) => this.textures[p.toLowerCase()] ?? null, () => Object.keys(this.textures ?? {}));
    setCryResolver((p) => this.textures[p.toLowerCase()] ?? null);
    this.renderTop?.();
  }

  setDataset(ds, rebuildArt = true) {
    this.idx = indexDataset(ds);
    this.dataset = this.idx.ds;
    setBrand(this.dataset.brand);
    try { document.title = brandText('Capsule Link'); } catch { /* no document */ }
    if (rebuildArt) this.bank?.setDataset(this.idx);
  }

  applySettings() {
    const s = this.save.settings;
    setSound(s.sound !== false, s.volume ?? 0.6);
  }

  on(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  emit(what) { for (const fn of this.listeners) fn(what); }

  /**
   * Change the save. `fn` mutates it; it is re-run if the main process changed the save meanwhile
   * (for example when a phone synced at the same moment).
   */
  commit(fn, reason = 'edit', { quiet = false } = {}) {
    const entry = { fn, reason };
    try { fn(this.save); } catch (e) { toast(e.message, 'err'); return Promise.resolve(false); }
    this.pending.push(entry);
    if (!quiet) this.refresh();
    this.queue = this.queue.then(async () => {
      let r = await this.platform.commit(this.save, this.rev, reason);
      if (r.conflict) {
        this.save = r.save; this.rev = r.rev;
        for (const m of this.pending) m.fn(this.save);
        r = await this.platform.commit(this.save, this.rev, reason);
      }
      if (r.ok) this.rev = r.rev;
      this.pending = this.pending.filter((m) => m !== entry);
      return true;
    }).catch((e) => { toast(`Could not save: ${e.message}`, 'err'); return false; });
    return this.queue;
  }

  /** Use a friend's Data Lab for a while (not saved: your own comes back with restoreDataset). */
  useDataset(ds, label) {
    if (!this.tempData) this.homeDataset = this.dataset;
    this.tempData = { label };
    this.setDataset(ds);
    this.refresh(); this.renderTop();
  }
  restoreDataset() {
    if (!this.tempData) return;
    this.tempData = null;
    this.setDataset(this.homeDataset);
    this.homeDataset = null;
    this.refresh(); this.renderTop();
  }
  async saveDataset(ds) {
    if (this.tempData) { toast(`You’re using ${this.tempData.label}. Go back to your own data first (top bar).`, 'err'); return { ok: false }; }
    const r = await this.platform.saveDataset(ds);
    this.setDataset(ds);
    this.refresh();
    return r;
  }

  say(text, kind = '') {
    this.status = text;
    if (this.statusEl) this.statusEl.textContent = brandText(text);
    if (kind) toast(text, kind);
  }

  // ---------- shell ----------
  buildShell() {
    this.viewEl = h('main', { class: 'view' });
    this.topEl = h('header', { class: 'topbar' });
    this.statusEl = h('div', { class: 'statusline', role: 'status' }, 'Storage terminal ready.');
    this.shellEl = h('div', { class: 'shell' }, h('div', { class: 'monitor' }, this.topEl, h('div', { class: 'screen' }, this.viewEl), this.statusEl));
    mount(document.body, this.shellEl);
    this.renderTop();
  }

  renderTop() {
    if (!this.topEl) return;
    const dockOn = this.dock?.kind === 'serial' && this.dock.status === 'connected';
    const phones = this.hubInfo?.status?.clients?.filter((c) => c.kind === 'phone').length ?? 0;
    const v = VIEWS.find((x) => x.id === this.viewId);
    const home = this.viewId === 'home';
    mount(this.topEl,
      home ? h('div', { class: 'brand' }, logoMark(22), h('span', null, 'Capsule Link'))
        : h('button', { class: 'back-btn', id: 'pc-menu', 'aria-label': 'Back to home', title: 'Home', onclick: () => { sfx('back'); this.go('home'); } }, svgIcon('back')),
      h('span', { class: 'view-title' }, home ? '' : v?.label ?? ''),
      this.tempData ? h('button', { class: 'pill temp-data', title: 'You’re visiting with a friend’s Data Lab. Click to go back to your own.', onclick: () => { this.restoreDataset(); toast('Back to your own data.', 'ok'); } }, `Using ${this.tempData.label} · back to mine`) : null,
      h('span', { class: 'spacer' }),
      h('span', { class: 'pill', title: 'Dock' }, h('span', { class: `dot ${dockOn ? 'on' : this.dock?.kind === 'virtual' ? 'sim' : ''}` }), dockOn ? 'Dock connected' : 'Virtual dock'),
      this.platform.hasHub ? h('span', { class: 'pill', title: 'Phones' }, h('span', { class: `dot ${phones ? 'on' : ''}` }), phones ? `${phones} phone${phones > 1 ? 's' : ''}` : 'No phone') : null,
      h('button', { class: 'pill trainer-pill', title: 'Trainer ID', onclick: () => this.go('trainer') }, avatarEl(this.save.trainer, 24), this.save.trainer?.name ?? 'Trainer'),
      h('button', { class: 'icon-btn', title: 'Sign out', 'aria-label': 'Sign out', onclick: () => this.logOff() }, svgIcon('logoff')));
  }

  go(id) {
    if (!this.viewEl) return;
    const v = VIEWS.find((x) => x.id === id || x.aliases?.includes(id)) ?? VIEWS[0];
    if (this.view && this.viewId === v.id) return;
    this.view?.dispose?.();
    this.viewId = v.id;
    this.viewEl.className = `view view-${v.id}${v.immersive ? ' immersive' : ''}`;
    this.renderTop();
    this.view = v.make(this);
    mount(this.viewEl, this.view.el);
    this.view.mounted?.();
  }

  refresh() {
    this.renderTop();
    this.view?.update?.();
  }

  // ---------- Showdown ----------
  sdCtx() {
    return {
      idx: this.idx, bank: this.bank, getSave: () => this.save,
      commit: (fn) => this.commit(fn, 'battle'),
      update: (fn) => this.commit(fn, 'showdown', { quiet: true }),
      team: () => party(this.save),
      fetchText: this.platform.fetchText,
    };
  }

  async onShowdown(msg) {
    if (msg.type === 'user' && msg.named && msg.name) {
      const cur = this.save.settings.showdown?.name;
      if (cur !== msg.name) this.commit((s) => { s.settings.showdown = { ...(s.settings.showdown || {}), name: msg.name }; }, 'settings');
    } else if (msg.type === 'popup' || msg.type === 'status') {
      this.say(msg.text, msg.type === 'popup' ? 'err' : '');
    } else if (msg.type === 'battle') {
      try {
        const el = await ingestBattle(this.sdCtx(), msg.log, { id: msg.room, user: msg.user });
        if (!el) return;
        this.lastResult = el;
        if (this.viewEl && this.viewId !== 'battle') this.go('battle');
        this.emit('battle-result');
        this.say('Showdown battle counted. Experience added.', 'ok');
      } catch (e) {
        this.say(`That Showdown battle was not counted: ${e.message}`, 'err');
      }
    }
  }

  // ---------- simulated capsules from phones ----------
  async connectHub() {
    try {
      const c = await this.hubClient();
      if (c.capHandlers) return;
      c.capHandlers = true;
      this.capWait = new Map();
      this.capRid = 0;
      c.on(MSG.CAP_ATTACHED, (m) => {
        this.say(`${m.name}'s simulated capsule is on the dock.`);
        this.dockCtl.externalTag(this.remoteTag(m.uid, m.name));
      });
      c.on(MSG.CAP_DETACHED, (m) => this.dockCtl.externalRemoved(m.uid));
      c.on(MSG.CAP_REPLY, (m) => {
        const w = this.capWait.get(m.rid);
        if (!w) return;
        this.capWait.delete(m.rid);
        clearTimeout(w.t);
        if (m.ok === false) w.reject(new Error(m.error || 'The phone could not do that.'));
        else w.resolve(m);
      });
    } catch (e) {
      console.warn('hub connection', e);
      setTimeout(() => this.connectHub(), 5000);
    }
  }

  capCall(type, data) {
    const rid = ++this.capRid;
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => { this.capWait.delete(rid); reject(new Error('The phone did not answer. Is it still connected?')); }, 8000);
      this.capWait.set(rid, { resolve, reject, t });
      try { this.client.send(type, { ...data, rid }); } catch (e) { clearTimeout(t); this.capWait.delete(rid); reject(e); }
    });
  }

  remoteTag(uid, phoneName) {
    return {
      uid, simulated: true, phoneName,
      readUser: async () => fromHex((await this.capCall(MSG.CAP_READ, { uid })).hex),
      writePages: async (page, bytes) => { await this.capCall(MSG.CAP_WRITE, { uid, page, hex: toHex(bytes) }); },
    };
  }

  /** Re-run the USB setup every few seconds so a phone plugged in later is linked too. */
  keepUsb(on) {
    clearInterval(this.usbTimer);
    if (!on) return;
    this.usbTimer = setInterval(async () => {
      const r = await this.platform.usbSetup().catch(() => null);
      const linked = r?.devices?.filter((d) => d.linked).map((d) => d.serial).join(',') ?? '';
      if (linked && linked !== this.usbLinked) this.say('Phone linked over USB.');
      this.usbLinked = linked;
    }, 6000);
  }

  // ---------- link battles (the renderer joins its own hub like any phone) ----------
  async hubClient() {
    if (!this.platform.hasHub) throw new Error('Link battles need the desktop app.');
    if (this.client?.status === 'open') return this.client;
    const info = this.hubInfo ?? await this.platform.hubInfo();
    this.client = new HubClient({ url: `ws://127.0.0.1:${info.port}`, deviceId: 'pc', name: this.save.trainer?.name ?? 'PC', kind: 'pc', localToken: info.localToken, reconnect: true });
    await this.client.connect();
    return this.client;
  }
}

export const app = new App();
if (typeof window !== 'undefined') window.__app = app; // handy in the dev tools
window.addEventListener('DOMContentLoaded', () => app.boot().catch((e) => {
  console.error(e);
  document.body.textContent = `Capsule Link could not start: ${e.message}`;
}));
export { MSG };
