// One connection to your friends server for the whole PC app: the Friends app, Battle Link (battle a
// friend) and the home screen (who's online) all share it, so there's one live socket and one list.
import { FriendsClient } from '../../../shared/net/friends.js';

const KEY = 'capsule-link:online';
export const loadAcct = () => { try { return JSON.parse(localStorage.getItem(KEY) ?? 'null') ?? {}; } catch { return {}; } };
export const saveAcct = (a) => { try { localStorage.setItem(KEY, JSON.stringify(a)); } catch { /* private mode */ } };
export const ago = (t) => { if (!t) return 'a while ago'; const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : m < 1440 ? `${Math.round(m / 60)} h ago` : `${Math.round(m / 1440)} d ago`; };

/** The app's friends session (made on first use). */
export function friendsSession(app) {
  if (app.friendsSession) return app.friendsSession;
  const S = {
    acct: loadAcct(),
    client: null,
    friends: null,     // { friends, incoming, outgoing } from the server (with online / seenAt)
    battles: null,     // { incoming, outgoing }
    error: '',
    listeners: new Set(),
    /** fn(notification) for every push (message, gift, request, friend, trade, battle, battle-reply, online, offline…) */
    on(fn) { S.listeners.add(fn); return () => S.listeners.delete(fn); },
    signedIn() { return !!S.client?.token; },
    setAccount(acct) {
      S.acct = acct; saveAcct(acct);
      try { S.client?.ws?.close(); } catch { /* ignore */ }
      S.client = new FriendsClient(acct.server ?? '', acct.token ?? null);
      S.friends = null; S.battles = null;
      S.start();
      return S.client;
    },
    start() {
      if (!S.client) S.client = new FriendsClient(S.acct.server ?? '', S.acct.token ?? null);
      if (!S.client.token) return;
      S.client.listen((n) => {
        if (['online', 'offline', 'friend'].includes(n.what)) S.refresh().catch(() => {});
        if (/^battle/.test(n.what)) S.refreshBattles().catch(() => {});
        for (const fn of S.listeners) { try { fn(n); } catch (e) { console.error(e); } }
      });
      S.refresh().catch(() => {});
    },
    async refresh() {
      if (!S.signedIn()) return null;
      try { S.friends = await S.client.friends(); S.error = ''; }
      catch (e) { if (e.status === 401) { S.client.token = null; S.acct.token = null; saveAcct(S.acct); } S.error = e.message; }
      for (const fn of S.listeners) { try { fn({ what: 'refresh' }); } catch { /* ignore */ } }
      return S.friends;
    },
    async refreshBattles() {
      if (!S.signedIn()) return null;
      try { S.battles = await S.client.battles(); } catch { /* older server: no battles */ S.battles = { incoming: [], outgoing: [] }; }
      for (const fn of S.listeners) { try { fn({ what: 'battles' }); } catch { /* ignore */ } }
      return S.battles;
    },
  };
  app.friendsSession = S;
  S.start();
  // keep "last seen" fresh now and then
  setInterval(() => { if (S.signedIn()) S.refresh().catch(() => {}); }, 120000);
  return S;
}
