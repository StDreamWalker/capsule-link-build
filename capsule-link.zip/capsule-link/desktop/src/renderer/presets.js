// Presets: a named list of things to bring in (data tables, sprites, icons, cries, trainer pictures, item
// pictures, move effects), each with the address it comes from. "Get everything" runs one preset; the
// built-in one is everything that works today (Showdown, PokéAPI, PokéSprite). Players add their own
// presets (or copy the built-in one and change the addresses) and can share them as a .json file.
// "One thing at a time" brings in any single kind on its own, from an address or from your own files.
import { h, mount, toast, confirmDialog } from '../../../shared/ui/dom.js';
import { sfx } from '../../../shared/ui/audio.js';
import { POKEAPI_CSV, EXTRA_FILES, addCsvExtrasText, applyCsvExtras, applyDexEntries, DEX_FILE, normalizeDataset, parsePaste, looksLikeShowdownSet } from '../../../shared/engine/index.js';
import { importSprites, spriteIndex, matchSpriteFile, spriteCoverage } from './spriteImport.js';
import { DATA_STEPS, detectTarget, importStep } from './dataSteps.js';
import { SPRITE_SOURCES, ANI_SOURCE, ICON_SOURCE, CRY_SOURCE, TRAINER_SOURCE, ITEM_SOURCE, ITEM_SHEET, BG_SOURCE, downloadSprites, pngLinksOn, downloadPictures, downloadItemSprites, downloadMoveFx, saveBatch } from './downloads.js';

const clone = (x) => JSON.parse(JSON.stringify(x));
const FX_SOURCE = 'https://play.pokemonshowdown.com/fx/';
const F = (k, label, ph = '') => ({ k, label, ph });

/** Every kind of thing a preset step (or "One thing at a time") can bring in. */
export const STEP_KINDS = {
  data: { title: 'Data table', about: 'Species, moves, learnsets, natures, items or their descriptions: a Showdown data file (.ts), CSV, TSV or JSON. Learnsets need species and moves first.', accept: 'text',
    fields: [{ k: 'table', label: 'Which table', select: DATA_STEPS.map((s) => [s.id, s.title]) }, F('url', 'Address of the file (the raw text)', 'https://raw.githubusercontent.com/you/your-game/main/species.csv')] },
  tables: { title: 'Experience, growth, effort and catch rates', about: 'CSV tables matched to your species by national number, in PokéAPI’s layout (pokemon.csv, pokemon_species.csv, pokemon_stats.csv).', accept: 'text',
    fields: [{ k: 'urls', label: 'Addresses, one per line', multi: true }] },
  dex: { title: 'Dex entries', about: 'A CSV of species descriptions, in PokéAPI’s flavour-text layout. The newest entry for each species is used.', accept: 'text',
    fields: [F('url', 'Address of the CSV')] },
  sprites: { title: 'Creature sprites', about: 'One picture per species. In an address, {num} is the national number ({num3} gives 001), {sd} the Showdown id, {ps} the dashed name, {id} your species id and {name} its name. Your own files are matched by name or number (sproutle.png, 0001.png, sproutle-back.png).', accept: 'png',
    fields: [F('front', 'Front', 'https://example.com/sprites/{num}.png'), F('back', 'Back (optional)'), F('shiny', 'Shiny (optional)'), F('shinyBack', 'Shiny back (optional)'), F('aniFront', 'Animated front, GIF (optional)'), F('aniBack', 'Animated back (optional)'), F('aniShiny', 'Animated shiny (optional)')] },
  icons: { title: 'Box icons', about: 'The small pictures in boxes and menus. Same address codes as sprites. Your own files are matched by name or number and saved as icons.', accept: 'png',
    fields: [F('regular', 'Icons', 'https://example.com/icons/{ps}.png'), F('shiny', 'Shiny icons (optional)')] },
  cries: { title: 'Cries', about: 'One sound per species, played when you call them. Same address codes as sprites. Your own files (MP3, OGG or WAV) are matched by name or number.', accept: 'audio',
    fields: [F('template', 'Address', 'https://example.com/cries/{num}.mp3')] },
  pictures: { title: 'Trainer pictures', about: 'Full-body pictures to choose on ID cards: a web page that lists PNG files (a folder), or your own files.', accept: 'png',
    fields: [F('url', 'Folder address', 'https://example.com/trainers/')] },
  items: { title: 'Item pictures', about: '{ps} is the item’s dashed name (oran-berry). An optional sprite sheet is cut by each item’s sprite number (24×24, 16 across). Your own files are saved under their name (oran-berry.png).', accept: 'png',
    fields: [F('template', 'Address', 'https://example.com/items/{ps}.png'), F('sheet', 'Sprite sheet (optional)')] },
  fx: { title: 'Move effects and battle backgrounds', about: 'The effect pictures move animations use (fireball.png, waterwisp.png…) and the battle backgrounds. Your own files replace the one with the same name.', accept: 'png',
    fields: [F('fxBase', 'Effects folder'), F('bgBase', 'Backgrounds folder (optional)')] },
};
export const KIND_ORDER = ['data', 'tables', 'dex', 'sprites', 'icons', 'cries', 'pictures', 'items', 'fx'];

const SD5 = SPRITE_SOURCES[0];
/** The built-in preset: everything that works today. */
export const BUILTIN_PRESET = Object.freeze({
  id: 'builtin-pokemon', builtIn: true, name: 'Pokémon (everything that works)',
  about: 'Species, moves (power, accuracy, PP) and their descriptions, learnsets, natures, items and their descriptions from Showdown; experience, growth, effort and dex entries from PokéAPI; then the animated Black/White sprites with backs and shinies, box icons, cries, trainer pictures, item pictures and move effects.',
  steps: [
    ...DATA_STEPS.map((s) => ({ kind: 'data', table: s.id, url: s.raw })),
    { kind: 'tables', urls: EXTRA_FILES.map((f) => `${POKEAPI_CSV}/${f}`).join('\n') },
    { kind: 'dex', url: `${POKEAPI_CSV}/${DEX_FILE}` },
    { kind: 'sprites', front: SD5.front, back: SD5.back, shiny: SD5.shiny, shinyBack: SD5.shinyBack, aniFront: ANI_SOURCE.front, aniBack: ANI_SOURCE.back, aniShiny: ANI_SOURCE.shiny, fallback: true },
    { kind: 'icons', regular: ICON_SOURCE.regular, shiny: ICON_SOURCE.shiny },
    { kind: 'cries', template: CRY_SOURCE },
    { kind: 'pictures', url: TRAINER_SOURCE },
    { kind: 'items', template: ITEM_SOURCE, sheet: ITEM_SHEET },
    { kind: 'fx', fxBase: FX_SOURCE, bgBase: BG_SOURCE },
  ],
});

/** The built-in step for a kind (or a data table), used to fill in a new step. */
export function defaultStep(kind, table) {
  const s = BUILTIN_PRESET.steps.find((x) => x.kind === kind && (!table || x.table === table));
  return s ? clone(s) : { kind };
}
export function stepLabel(step) {
  if (step.kind === 'data') return DATA_STEPS.find((d) => d.id === step.table)?.title ?? 'Data table';
  return STEP_KINDS[step.kind]?.title ?? step.kind;
}
export function userPresets(app) { return Array.isArray(app.save?.settings?.dataPresets) ? app.save.settings.dataPresets : []; }
export function allPresets(app) { return [BUILTIN_PRESET, ...userPresets(app)]; }

/** A preset read from a shared file: only known kinds and text fields survive. */
export function cleanPreset(p) {
  if (!p || typeof p !== 'object' || !Array.isArray(p.steps)) throw new Error('that file is not a preset');
  const txt = (v, n = 2000) => (typeof v === 'string' ? v.slice(0, n) : '');
  const steps = p.steps.filter((s) => s && STEP_KINDS[s.kind]).slice(0, 60).map((s) => {
    const out = { kind: s.kind };
    for (const f of STEP_KINDS[s.kind].fields) out[f.k] = txt(s[f.k], f.multi ? 6000 : 600);
    if (s.kind === 'data' && !DATA_STEPS.some((d) => d.id === out.table)) out.table = DATA_STEPS[0].id;
    return out;
  });
  if (!steps.length) throw new Error('that preset has no steps this app knows');
  return { id: `p${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`, name: txt(p.name, 60) || 'My preset', about: txt(p.about, 400), steps };
}

const okUrl = (u) => /^https?:\/\/\S+$/i.test(String(u ?? '').trim());
const needUrl = (u, what) => { if (!okUrl(u)) throw new Error(`${what} needs an address starting with http`); return String(u).trim(); };
async function fetchText(app, url) {
  const r = await app.platform.fetchUrl(url, 'text');
  if (!r.ok) throw new Error(`the site answered ${r.status}`);
  return r.text;
}
const counted = (rep) => `${rep.added ? `${rep.added} added` : ''}${rep.added && rep.updated ? ', ' : ''}${rep.updated ? `${rep.updated} updated` : ''}`;

/** Bring in one data table from text (a download, a file or a paste). */
export async function importDataText(app, tableId, text, { replace = null } = {}) {
  const step = DATA_STEPS.find((d) => d.id === tableId) ?? DATA_STEPS[0];
  if (!String(text ?? '').trim()) throw new Error('there is nothing in it');
  if (looksLikeShowdownSet(text)) throw new Error('that is a Showdown team, which never imports: this needs the data file');
  let parsed;
  try { parsed = parsePaste(text); } catch (e) { throw new Error(`that could not be read: ${e.message}`); }
  if (parsed.format === 'dataset') throw new Error('that is a whole Capsule Link data set: load it in Data Lab → Rules instead');
  const target = detectTarget(parsed, step.target);
  if (target !== step.target && step.mode !== 'update') throw new Error(`this looks like ${target === 'temperaments' ? 'natures' : target === 'learnset' ? 'learnsets' : target} data, not ${step.title.toLowerCase()}`);
  const rep = await importStep(app, step, text, { replace: replace ?? ((app.dataset.species?.length ?? 0) <= 15 && (step.id === 'species' || step.id === 'moves')) });
  if (!(rep.added + rep.updated)) throw new Error(rep.warnings[0] ?? 'nothing matched');
  return `${counted(rep)}${parsed.partial ? ` (the text stopped part-way: ${parsed.partial.kept} came through)` : ''}`;
}
async function applyTables(app, texts) {
  const tables = {};
  for (const t of texts) if (!addCsvExtrasText(tables, t)) throw new Error('one of those is not a table this step reads (check its first line: the column names)');
  const ds = clone(app.dataset);
  const out = applyCsvExtras(ds, tables);
  if (!out.updated) throw new Error('nothing matched your species (these tables match by national number)');
  await app.saveDataset(normalizeDataset(ds));
  return `${out.updated} species updated`;
}
async function applyDex(app, text) {
  const ds = clone(app.dataset);
  const out = applyDexEntries(ds, text);
  if (!out.updated) throw new Error('no entries matched your species numbers');
  await app.saveDataset(normalizeDataset(ds));
  return `${out.updated} dex entries`;
}

/** Run one step from its addresses. ctx: { prog(done, total, label), stop() } */
export async function runStep(app, step, { prog = () => {}, stop = () => false, onlyMissing = false } = {}) {
  const p = (label) => (a, b) => prog(a, b, label);
  switch (step.kind) {
    case 'data': return importDataText(app, step.table, await fetchText(app, needUrl(step.url, stepLabel(step))));
    case 'tables': {
      const urls = String(step.urls ?? '').split(/\s+/).filter(Boolean);
      if (!urls.length) throw new Error('add at least one address');
      const texts = [];
      for (const u of urls) texts.push(await fetchText(app, needUrl(u, 'Each table')));
      const r = await applyTables(app, texts);
      return r;
    }
    case 'dex': return applyDex(app, await fetchText(app, needUrl(step.url, 'Dex entries')));
    case 'sprites': {
      const ani = { front: step.aniFront || '', back: step.aniBack || '', shiny: step.aniShiny || '' };
      const r = await downloadSprites(app, { template: needUrl(step.front, 'The front sprite'), back: step.back || '', shiny: step.shiny || '', shinyBack: step.shinyBack || '', animated: !!ani.front, ani, fallback: !!step.fallback, onlyMissing: onlyMissing && !ani.front, onProgress: p('Sprites '), shouldStop: stop });
      if (!r.saved) throw new Error(r.failed[0] ?? 'the address had no pictures under those names');
      return `${r.saved} pictures${r.missing.length ? `, ${r.missing.length} species not found` : ''}`;
    }
    case 'icons': {
      const r = await downloadSprites(app, { template: needUrl(step.regular, 'Box icons'), shiny: step.shiny || '', trim: false, icons: true, onlyMissing, onProgress: p('Box icons '), shouldStop: stop });
      if (!r.saved) throw new Error(r.failed[0] ?? 'no icons found under those names');
      return `${r.saved} icons`;
    }
    case 'cries': {
      const r = await downloadSprites(app, { template: needUrl(step.template, 'Cries'), trim: false, cries: true, onlyMissing: true, onProgress: p('Cries '), shouldStop: stop });
      return `${r.saved} cries${r.missing.length ? ` (${r.missing.length} not found)` : ''}`;
    }
    case 'pictures': {
      const links = await pngLinksOn(app, needUrl(step.url, 'Trainer pictures'));
      if (!links.length) throw new Error('the folder listed no pictures');
      const r = await downloadPictures(app, links, 'trainers', { onProgress: p('Trainers '), shouldStop: stop });
      return `${r.saved} pictures`;
    }
    case 'items': {
      const r = await downloadItemSprites(app, { template: needUrl(step.template, 'Item pictures'), sheet: okUrl(step.sheet) ? step.sheet.trim() : '', onlyMissing, onProgress: p('Items '), shouldStop: stop });
      return `${r.saved} items${r.missing.length ? ` (${r.missing.length} have no picture)` : ''}`;
    }
    case 'fx': {
      const r = await downloadMoveFx(app, { fxBase: needUrl(step.fxBase, 'Move effects'), bgBase: okUrl(step.bgBase) ? step.bgBase.trim() : '', onProgress: p('Move effects '), shouldStop: stop });
      return `${r.saved} pictures${r.failed.length ? ` (${r.failed.length} missing: those moves use their type’s look)` : ''}`;
    }
    default: throw new Error('this app does not know that kind of step');
  }
}

const stemOf = (name) => String(name).replace(/\.[a-z0-9]+$/i, '').toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'file';
/** Bring in one kind from your own files (File objects). Returns a line saying what happened. */
export async function importFilesFor(app, kind, files) {
  files = [...files];
  if (!files.length) return '';
  if (kind === 'sprites') {
    const r = await importSprites(app, files);
    app.applyTextures?.();
    return `${r.saved} saved · ${r.matched} matched a species${r.unmatched.length ? ` · ${r.unmatched.length} did not` : ''}`;
  }
  if (kind === 'icons') {
    const r = await importSprites(app, files, { pose: 'icon' });
    app.applyTextures?.();
    return `${r.saved} icons saved · ${r.matched} matched a species`;
  }
  if (kind === 'cries') {
    const index = spriteIndex(app.idx.ds.species);
    const batch = [], unmatched = [];
    for (const f of files) {
      if (!/\.(mp3|ogg|wav|m4a)$/i.test(f.name)) continue;
      const m = matchSpriteFile(f.name.replace(/\.[a-z0-9]+$/i, '.png'), index);
      if (!m.species) { unmatched.push(f.name); continue; }
      batch.push({ path: `cries/${m.species.id}.mp3`, data: new Uint8Array(await f.arrayBuffer()) });
    }
    const failed = await saveBatch(app, batch);
    return `${batch.length - failed.length} cries saved${unmatched.length ? ` · ${unmatched.length} matched no species` : ''}`;
  }
  const folder = { pictures: 'trainers', items: 'items', fx: 'fx' }[kind];
  if (!folder) throw new Error('that kind is read from text: use Load a file');
  const batch = [];
  for (const f of files) if (/\.png$/i.test(f.name)) batch.push({ path: `${folder}/${stemOf(f.name)}.png`, data: new Uint8Array(await f.arrayBuffer()) });
  const failed = await saveBatch(app, batch);
  return `${batch.length - failed.length} pictures saved`;
}
/** Bring in one text kind from a file or a paste. */
export async function importTextFor(app, step, texts) {
  if (step.kind === 'data') return importDataText(app, step.table, texts[0]);
  if (step.kind === 'tables') return applyTables(app, texts);
  if (step.kind === 'dex') return applyDex(app, texts[0]);
  throw new Error('that kind is pictures or sounds: use Choose files');
}

function progress() {
  const bar = h('i');
  const text = h('span', { class: 'micro dim' });
  const el = h('div', { class: 'dl-progress', hidden: true }, h('div', { class: 'connect-bar' }, bar), text);
  return { el, set(done, total, label = '') { el.hidden = false; bar.style.width = `${total ? (done / total) * 100 : 0}%`; text.textContent = `${label}${done} of ${total}`; }, hide() { el.hidden = true; } };
}

function fieldInputs(step, onChange) {
  const def = STEP_KINDS[step.kind];
  return h('div', { class: 'preset-fields' }, def.fields.map((f) => {
    if (f.select) return h('label', { class: 'field small' }, h('span', null, f.label), h('select', { onchange: (e) => { step[f.k] = e.target.value; onChange(f.k); } }, f.select.map(([v, l]) => h('option', { value: v, selected: v === step[f.k] }, l))));
    if (f.multi) return h('label', { class: 'field small' }, h('span', null, f.label), h('textarea', { class: 'code paste small', rows: 3, spellcheck: false, oninput: (e) => { step[f.k] = e.target.value; } }, step[f.k] ?? ''));
    return h('label', { class: 'field small' }, h('span', null, f.label), h('input', { type: 'url', value: step[f.k] ?? '', placeholder: f.ph, spellcheck: false, oninput: (e) => { step[f.k] = e.target.value.trim(); } }));
  }));
}

/** "Get everything": pick a preset and run it; make, copy, edit, share and delete your own. */
export function presetTool(app, { onDone = () => {}, big = false } = {}) {
  const st = { running: false, stop: false, steps: [], pick: presetTool.pick ?? BUILTIN_PRESET.id, edit: null, showSteps: false };
  const el = h('div', { class: big ? 'dl-everything big' : 'dl-everything' });
  const prog = progress();
  const ICON = { wait: '·', run: '…', ok: '✓', err: '✕', skip: '–' };
  const current = () => allPresets(app).find((p) => p.id === st.pick) ?? BUILTIN_PRESET;
  const savePresets = (fn) => app.commit((s) => { s.settings.dataPresets = fn(clone(userPresets(app))); }, 'settings');

  async function run() {
    const preset = current();
    st.running = true; st.stop = false; st.steps = preset.steps.map((s) => ({ label: stepLabel(s), state: 'wait', text: '' })); render();
    for (const [i, step] of preset.steps.entries()) {
      if (st.stop) { st.steps[i].state = 'skip'; st.steps[i].text = 'stopped'; continue; }
      st.steps[i].state = 'run'; render();
      try { st.steps[i].text = await runStep(app, step, { prog: prog.set, stop: () => st.stop }); st.steps[i].state = 'ok'; }
      catch (e) { st.steps[i].state = 'err'; st.steps[i].text = e.message; }
      prog.hide(); render();
    }
    st.running = false;
    const ok = st.steps.some((s) => s.state === 'ok');
    app.applyTextures?.();
    sfx(ok ? 'heal' : 'error'); render(); onDone();
  }

  function editor() {
    const p = st.edit;
    const move = (i, d) => { const j = i + d; if (j < 0 || j >= p.steps.length) return; [p.steps[i], p.steps[j]] = [p.steps[j], p.steps[i]]; render(); };
    return h('div', { class: 'preset-editor col' },
      h('div', { class: 'form-grid' },
        h('label', { class: 'field' }, h('span', null, 'Preset name'), h('input', { type: 'text', value: p.name, maxLength: 60, oninput: (e) => { p.name = e.target.value; } })),
        h('label', { class: 'field' }, h('span', null, 'What it brings in (optional)'), h('input', { type: 'text', value: p.about ?? '', maxLength: 400, oninput: (e) => { p.about = e.target.value; } }))),
      h('p', { class: 'micro dim' }, 'Steps run from top to bottom. Any address works: a GitHub file (use its Raw link), your own website, anything that serves the file.'),
      p.steps.map((step, i) => h('div', { class: 'preset-step' },
        h('div', { class: 'row' },
          h('b', { class: 'grow' }, `${i + 1}. ${stepLabel(step)}`),
          h('button', { class: 'btn small ghost', title: 'Move up', disabled: i === 0, onclick: () => move(i, -1) }, '↑'),
          h('button', { class: 'btn small ghost', title: 'Move down', disabled: i === p.steps.length - 1, onclick: () => move(i, 1) }, '↓'),
          h('button', { class: 'btn small ghost', title: 'Remove this step', onclick: () => { p.steps.splice(i, 1); render(); } }, '✕')),
        fieldInputs(step, (k) => { if (k === 'table') render(); }))),
      h('div', { class: 'row wrap' },
        h('select', { onchange: (e) => { const [kind, table] = e.target.value.split(':'); if (kind) { p.steps.push(defaultStep(kind, table)); render(); } } },
          h('option', { value: '' }, '+ Add a step…'),
          DATA_STEPS.map((d) => h('option', { value: `data:${d.id}` }, `Data table: ${d.title}`)),
          KIND_ORDER.filter((k) => k !== 'data').map((k) => h('option', { value: k }, STEP_KINDS[k].title))),
        h('span', { class: 'spacer' }),
        h('button', { class: 'btn small', onclick: () => { st.edit = null; render(); } }, 'Cancel'),
        h('button', { class: 'btn small primary', onclick: () => {
          if (!p.steps.length) { toast('Add at least one step.', 'err'); return; }
          const clean = { ...cleanPreset(p), id: p.id };
          savePresets((list) => { const i = list.findIndex((x) => x.id === clean.id); if (i >= 0) list[i] = clean; else list.push(clean); return list; });
          st.pick = presetTool.pick = clean.id; st.edit = null; sfx('heal'); render();
        } }, 'Save preset')));
  }

  function render() {
    if (st.edit) { mount(el, h('section', { class: 'data-step' }, h('h3', null, st.edit.isNew ? 'New preset' : `Edit “${st.edit.name}”`), editor())); return; }
    const preset = current();
    const mine = !preset.builtIn;
    mount(el, h('section', { class: 'data-step' },
      h('div', { class: 'row' }, h('div', { class: 'grow' },
        h('h3', null, 'Get everything'),
        h('p', { class: 'micro dim' }, 'One button brings in a whole creature system from a preset: its data, pictures and sounds. The built-in preset is everything that works today; make your own for your own creatures, or copy it and change the addresses.'))),
      h('div', { class: 'row wrap' },
        h('label', { class: 'field grow' }, h('span', null, 'Preset'),
          h('select', { disabled: st.running, onchange: (e) => { st.pick = presetTool.pick = e.target.value; st.steps = []; render(); } },
            allPresets(app).map((p) => h('option', { value: p.id, selected: p.id === preset.id }, `${p.name}${p.builtIn ? ' · built in' : ''}`))))),
      preset.about ? h('p', { class: 'micro' }, preset.about) : null,
      h('details', { open: st.showSteps, ontoggle: (e) => { st.showSteps = e.target.open; } }, h('summary', { class: 'micro dim' }, `${preset.steps.length} steps`),
        h('ol', { class: 'micro preset-list' }, preset.steps.map((s) => h('li', null, stepLabel(s), h('span', { class: 'dim mono-num' }, ` ${s.url ?? s.front ?? s.regular ?? s.template ?? s.fxBase ?? String(s.urls ?? '').split(/\s+/)[0] ?? ''}`))))),
      app.platform.kind === 'web' ? h('p', { class: 'micro dim' }, 'The browser preview can’t reach most sites; use the PC app for this.') : null,
      st.steps.length ? h('ul', { class: 'dl-steps' }, st.steps.map((s) => h('li', { class: `dl-${s.state}` }, h('span', { class: 'dl-ic' }, ICON[s.state]), h('span', { class: 'grow' }, s.label), h('span', { class: 'micro dim' }, s.text)))) : null,
      prog.el,
      h('div', { class: 'row wrap' },
        st.running ? null : h('button', { class: 'btn small', onclick: () => { st.edit = { isNew: true, id: '', name: 'My creatures', about: '', steps: [defaultStep('data', 'species')] }; render(); } }, 'New preset'),
        st.running ? null : h('button', { class: 'btn small', onclick: () => { st.edit = { ...clone(preset), isNew: true, id: '', builtIn: undefined, name: `${preset.name} (copy)` }; render(); } }, 'Copy and change'),
        st.running || !mine ? null : h('button', { class: 'btn small', onclick: () => { st.edit = clone(preset); render(); } }, 'Edit'),
        st.running ? null : h('button', { class: 'btn small', title: 'Save this preset as a file to share', onclick: async () => {
          const { id, builtIn, ...rest } = clone(preset); void id; void builtIn;
          await app.platform.exportFile(`${preset.name.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.preset.json`, JSON.stringify({ capsulePreset: 1, ...rest }, null, 1));
        } }, 'Share as a file'),
        st.running ? null : h('button', { class: 'btn small', onclick: async () => {
          const f = await app.platform.importFile([{ name: 'Preset', extensions: ['json'] }]);
          if (!f) return;
          try { const p = cleanPreset(JSON.parse(f.text)); savePresets((list) => [...list, p]); st.pick = presetTool.pick = p.id; toast(`Added the preset “${p.name}”.`, 'ok'); }
          catch (e) { toast(`Couldn’t add that preset: ${e.message}.`, 'err'); }
          render();
        } }, 'Add a preset file…'),
        st.running || !mine ? null : h('button', { class: 'btn small danger', onclick: async () => {
          if (!(await confirmDialog('Delete this preset?', `“${preset.name}” goes away. What it already brought in stays.`, { ok: 'Delete', danger: true }))) return;
          savePresets((list) => list.filter((x) => x.id !== preset.id)); st.pick = presetTool.pick = BUILTIN_PRESET.id; render();
        } }, 'Delete'),
        h('span', { class: 'spacer' }),
        st.running ? h('button', { class: 'btn small danger', onclick: () => { st.stop = true; } }, 'Stop')
          : h('button', { class: 'btn primary', onclick: run }, st.steps.length ? 'Run it again' : 'Get everything'))));
  }
  render();
  return el;
}

/** "One thing at a time": any single kind, from an address (prefilled from the built-in preset) or your own files. */
export function oneThingTool(app, { extra = {} } = {}) {
  const st = { kind: 'data', step: defaultStep('data', 'species'), running: false, stop: false, status: '', ok: false, onlyMissing: false, paste: '' };
  const el = h('div');
  const prog = progress();
  const done = (ok, text) => { st.ok = ok; st.status = ok ? `✓ ${text}` : text; sfx(ok ? 'heal' : 'error'); st.running = false; prog.hide(); render(); };
  const choose = (kind, table) => { st.kind = kind; st.step = defaultStep(kind, table); st.status = ''; st.ok = false; render(); };
  function render() {
    const def = STEP_KINDS[st.kind];
    const isText = def.accept === 'text';
    const sel = st.kind === 'data' ? `data:${st.step.table}` : st.kind;
    mount(el, h('section', { class: `data-step ${st.ok ? 'done' : ''}` },
      h('div', { class: 'row wrap' },
        h('label', { class: 'field grow' }, h('span', null, 'What to bring in'),
          h('select', { disabled: st.running, onchange: (e) => { const [k, t] = e.target.value.split(':'); choose(k, t); } },
            DATA_STEPS.map((d) => h('option', { value: `data:${d.id}`, selected: sel === `data:${d.id}` }, `Data table: ${d.title}`)),
            KIND_ORDER.filter((k) => k !== 'data').map((k) => h('option', { value: k, selected: sel === k }, STEP_KINDS[k].title))))),
      h('p', { class: 'micro dim' }, st.kind === 'data' ? `${DATA_STEPS.find((d) => d.id === st.step.table)?.what ?? ''} ${def.about}` : def.about),
      fieldInputs(st.step, (k) => { if (k === 'table') { st.step = defaultStep('data', st.step.table); render(); } }),
      h('p', { class: 'micro faint' }, 'The addresses start as the built-in preset’s. Put in your own (a GitHub file’s Raw link works), or use your own files.'),
      isText ? h('textarea', { class: 'code paste small', spellcheck: false, placeholder: 'Or paste the file here…', oninput: (e) => { st.paste = e.target.value; } }, st.paste.length > 200000 ? '' : st.paste) : null,
      ['sprites', 'icons', 'items'].includes(st.kind) ? h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: st.onlyMissing, onchange: (e) => { st.onlyMissing = e.target.checked; } }), 'Only ones that don’t have a picture yet') : null,
      prog.el,
      h('div', { class: 'row wrap' },
        h('div', { class: `data-status ${st.ok ? 'ok' : st.status ? 'err' : ''}` }, st.status), h('span', { class: 'spacer' }),
        isText ? h('button', { class: 'btn small', disabled: st.running, onclick: async () => {
          const f = await app.platform.importFile([{ name: 'Data file', extensions: ['ts', 'js', 'json', 'csv', 'tsv', 'txt'] }]);
          if (!f) return;
          try { done(true, await importTextFor(app, st.step, [f.text])); } catch (e) { done(false, `That file: ${e.message}.`); }
        } }, 'Load a file') : null,
        isText ? h('button', { class: 'btn small', disabled: st.running, onclick: async () => {
          try { done(true, await importTextFor(app, st.step, [st.paste])); st.paste = st.paste.length > 200000 ? '' : st.paste; } catch (e) { done(false, `The paste: ${e.message}.`); }
        } }, 'Check and add') : null,
        !isText ? h('label', { class: 'btn small' }, 'Choose files…', h('input', { type: 'file', class: 'hidden', multiple: true, accept: def.accept === 'audio' ? 'audio/*' : 'image/png', onchange: async (e) => {
          const files = [...(e.target.files ?? [])]; e.target.value = '';
          if (!files.length) return;
          try { done(true, await importFilesFor(app, st.kind, files)); } catch (err) { done(false, `Couldn’t add those: ${err.message}.`); }
        } })) : null,
        st.running ? h('button', { class: 'btn small danger', onclick: () => { st.stop = true; } }, 'Stop')
          : h('button', { class: 'btn small primary', onclick: async () => {
            st.running = true; st.stop = false; st.status = 'Downloading…'; st.ok = false; render();
            try { done(true, await runStep(app, st.step, { prog: prog.set, stop: () => st.stop, onlyMissing: st.onlyMissing })); }
            catch (e) { done(false, `Couldn’t download: ${e.message}.${app.platform.kind === 'web' ? ' (The browser preview can’t reach most sites; the PC app can.)' : ''}`); }
          } }, 'Download')),
      st.kind === 'sprites' && extra.sprites ? h('details', null, h('summary', { class: 'micro dim' }, 'More sprite tools: ready-made sources, cutting up a sprite sheet'), extra.sprites()) : null,
      st.kind === 'sprites' ? h('p', { class: 'micro faint' }, (() => { const c = spriteCoverage(app); return `${c.have} of ${c.total} species have a sprite.`; })()) : null));
  }
  render();
  return el;
}
