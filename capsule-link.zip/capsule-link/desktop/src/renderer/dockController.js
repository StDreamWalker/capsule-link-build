import { transferLine } from '../../../shared/ui/transfer.js';
// Reacts to capsules arriving on the dock (real or virtual), whatever screen is open.
import {
  readCapsule, syncCapsule, sendToCapsule, releaseFromCapsule, setCapsuleMode, writeCapsule, diffMutator,
  displayName, speciesOf, cryFor, capsuleName,
} from '../../../shared/engine/index.js';
import { dialog, h, toast, fmtNum } from '../../../shared/ui/dom.js';
import { sfx, playCry } from '../../../shared/ui/audio.js';
import { capsuleCanvas } from '../../../shared/ui/capsuleArt.js';

const clone = (x) => JSON.parse(JSON.stringify(x));

export function describeFinds(idx, finds) {
  const counts = {};
  for (const f of finds) counts[f] = (counts[f] ?? 0) + 1;
  return Object.entries(counts).map(([id, n]) => `${idx.items.get(id)?.name ?? id}${n > 1 ? ` ×${n}` : ''}`).join(', ');
}

export class DockController {
  constructor(app) {
    this.app = app;
    this.current = null; // { tag, info, error }
    this.busy = false;
    this.subs = new Set();
    this.offs = [];
    this.lastResult = null;
  }

  on(fn) { this.subs.add(fn); return () => this.subs.delete(fn); }
  emit() { for (const fn of this.subs) fn(); this.app.renderTop(); }

  attach(dock) {
    for (const off of this.offs) off();
    this.dock = dock;
    this.app.dock = dock;
    this.current = null;
    this.offs = [
      dock.on('tag', (tag) => this.onTag(tag)),
      dock.on('removed', () => { if (this.current) sfx('undock'); this.current = null; this.emit(); }),
      dock.on('status', () => this.emit()),
      dock.on('hello', () => this.emit()),
    ];
    const t = dock.currentTag?.();
    if (t) this.onTag(t);
    this.emit();
  }

  async onTag(tag) {
    this.current = { tag, info: null };
    this.emit();
    sfx('dock');
    try {
      await this.refresh();
    } catch (e) {
      this.current.error = e.message;
      this.emit();
      return;
    }
    const info = this.current?.info;
    if (!info) return;
    const app = this.app;
    if (info.state === 'creature' && info.known) {
      const sp = app.idx.speciesByNo.get(info.rec.speciesNo);
      this.dock.tone?.(cryFor(sp));
      playCry(cryFor(sp));
      this.dock.led?.('solid', app.idx.types.get(sp.types[0])?.color?.slice(1));
      if (!info.datasetMatch) toast('This capsule was written with a different Data Lab set. Numbers may point at different species.', 'err');
      if (app.save.settings.autoSync !== false) await this.sync({ auto: true });
      if (app.save.settings.askLetOut !== false) this.offerLetOut();
    } else {
      this.dock.led?.('pulse', '34d1bf');
    }
  }

  /** A capsule that is not on the USB/virtual dock, e.g. a phone's simulated capsule. */
  externalTag(tag) {
    this.onTag(tag);
  }

  externalRemoved(uid) {
    if (this.current?.tag?.uid !== uid) return;
    this.current = null;
    sfx('undock');
    this.emit();
  }

  async refresh() {
    if (!this.current) return null;
    const info = await readCapsule(this.app.idx, this.current.tag);
    if (!this.current) return null;
    this.current.info = info;
    this.current.error = null;
    if (!this.app.save.capsules[info.uid] && info.state !== 'foreign') {
      this.app.commit((s) => { s.capsules[info.uid] = s.capsules[info.uid] || { name: `Capsule ${Object.keys(s.capsules).length + 1}`, uid: info.rec?.uid ?? null, mode: info.rec?.mode ?? 'desk', lastSeen: Date.now() }; }, 'capsule', { quiet: true });
    }
    this.emit();
    return info;
  }

  /** Run slow tag work on a copy of the save, then commit the difference. */
  async run(label, work) {
    if (!this.current?.info) { toast('Place a capsule on the dock first.', 'err'); return null; }
    if (this.busy) return null;
    this.busy = true;
    this.emit();
    const before = clone(this.app.save);
    const copy = clone(this.app.save);
    try {
      const result = await work(copy, this.current.tag, this.current.info);
      this.app.commit(diffMutator(before, copy), 'capsule');
      await this.refresh();
      return result;
    } catch (e) {
      console.error(e);
      toast(`${label} failed: ${e.message}`, 'err');
      try { await this.refresh(); } catch { /* tag gone */ }
      return null;
    } finally {
      this.busy = false;
      this.emit();
    }
  }

  async sync({ auto = false } = {}) {
    const app = this.app;
    const res = await this.run('Sync', (save, tag, info) => syncCapsule(app.idx, save, tag, info));
    if (!res) return null;
    const c = app.save.creatures[res.creature.uid];
    const name = displayName(app.idx, c);
    if (res.isNew) app.say(`${transferLine('home', name)} (Now in your storage.)`, 'ok');
    if (res.walk?.steps) {
      app.say(`${name} walked ${fmtNum(res.walk.steps)} steps with you. Friendship +${res.walk.friendship}.${res.walk.finds.length ? ` Found ${describeFinds(app.idx, res.walk.finds)}.` : ''}`, 'ok');
      if (res.walk.events.some((e) => e.type === 'level')) sfx('level');
    } else if (!auto) app.say(`${name} is up to date.`);
    this.lastResult = res;
    return res;
  }

  async offerLetOut() {
    const app = this.app;
    const info = this.current?.info;
    if (!info || info.state !== 'creature') return;
    const c = app.save.creatures[info.rec.uid];
    if (!c) return;
    const name = displayName(app.idx, c);
    const choice = await dialog(`${name} is home`, (close) => h('div', { class: 'col' },
      h('div', { class: 'row' }, capsuleCanvas({ skin: c.ball, ring: app.idx.types.get(speciesOf(app.idx, c)?.types[0])?.color, creature: c.speciesId, bank: app.bank }, 4),
        h('p', null, `${name} is resting in ${capsuleName(app.save, info.uid)}. Let it out into the ranch, or keep it in the capsule for your next walk?`)),
      h('div', { class: 'actions' },
        h('button', { class: 'btn', onclick: () => close('keep') }, 'Keep in capsule'),
        h('button', { class: 'btn', onclick: () => close('party') }, 'Out to the party'),
        h('button', { class: 'btn primary', onclick: () => close('ranch') }, 'Let it out'))));
    if (choice === 'ranch' || choice === 'party') await this.letOut(choice);
  }

  async letOut(where = 'ranch') {
    const app = this.app;
    const party = Object.values(app.save.creatures).filter((x) => x.location.kind === 'party').length;
    const to = where === 'party' && party < app.idx.ds.rules.partySize ? { kind: 'party', slot: party } : where === 'box' ? { kind: 'box' } : { kind: 'ranch' };
    const c = await this.run('Let out', (save, tag, info) => releaseFromCapsule(app.idx, save, tag, info, to));
    if (c) { app.say(transferLine('home', displayName(app.idx, c)), 'ok'); sfx('materialize'); }
  }

  async send(uid, mode = 'walk') {
    const app = this.app;
    const c = await this.run('Send', (save, tag, info) => sendToCapsule(app.idx, save, tag, info, uid, { mode }));
    if (c) { app.say(transferLine('capsule', displayName(app.idx, c)), 'ok'); sfx('transfer'); playCry(cryFor(speciesOf(app.idx, c))); }
  }

  async setMode(mode) {
    const app = this.app;
    await this.run('Mode change', (save, tag, info) => setCapsuleMode(app.idx, save, tag, info, mode));
    app.say(`Capsule set to ${mode} mode.`);
  }

  async format() {
    const app = this.app;
    await this.run('Format', async (save, tag, info) => {
      if (info.state === 'creature' && save.creatures[info.rec.uid]) throw new Error('Let the creature out before formatting.');
      await writeCapsule(app.idx, tag, null, null, { mode: 'desk', full: true });
      save.capsules[tag.uid] = { ...(save.capsules[tag.uid] || { name: `Capsule ${Object.keys(save.capsules).length + 1}` }), uid: null, mode: 'desk', lastSeen: Date.now() };
    });
    app.say('Capsule formatted and ready.');
  }
}
