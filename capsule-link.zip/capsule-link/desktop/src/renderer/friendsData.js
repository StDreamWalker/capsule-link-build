// Visiting a friend with their Data Lab: their species, moves, learnsets, items, natures and everything else
// "Download everything" would bring in, made to match theirs for the visit, plus the pictures you don't have.
// Keep it as a preset and next time it switches straight over (it only downloads again when they change it).
import { h, toast, chooseDialog } from '../../../shared/ui/dom.js';
import { sha256Hex } from '../../../shared/net/friends.js';

const presetName = (username) => `friend-${username}`;

/** Share your Data Lab (and the pictures that go with it) on the friends server. */
export async function shareMyDatalab(app, client, { onProgress = () => {} } = {}) {
  const paths = Object.keys(app.textures ?? {}).filter((p) => /\.png$/i.test(p));
  const map = {}, bytesOf = {};
  let i = 0;
  for (const p of paths) {
    try { const buf = new Uint8Array(await (await fetch(app.textures[p])).arrayBuffer()); if (buf.length < 4 * 1024 * 1024) { const hsh = await sha256Hex(buf); map[p] = hsh; bytesOf[hsh] = buf; } } catch { /* unreadable: skip */ }
    onProgress(++i, paths.length * 2, 'Reading pictures');
  }
  const all = [...new Set(Object.values(map))];
  const have = new Set();
  for (let k = 0; k < all.length; k += 4000) for (const x of (await client.blobsHave(all.slice(k, k + 4000))).have) have.add(x);
  const need = all.filter((x) => !have.has(x));
  let j = 0;
  for (const hsh of need) { await client.putBlob(hsh, bytesOf[hsh]).catch(() => {}); onProgress(paths.length + Math.round((++j / Math.max(1, need.length)) * paths.length), paths.length * 2, 'Uploading pictures'); }
  const r = await client.shareDatalab(app.homeDataset ?? app.dataset, map);
  return { hash: r.hash, pictures: paths.length, uploaded: need.length };
}

/** Bring in the pictures their Data Lab uses that you don't have (yours are never replaced). */
async function bringPictures(app, client, textures, onProgress) {
  const missing = Object.entries(textures ?? {}).filter(([p]) => !app.textures?.[p.toLowerCase()]);
  let batch = [], n = 0;
  for (const [p, hsh] of missing) {
    try { const bytes = await client.getBlob(hsh); if (bytes?.length) batch.push({ path: p, data: bytes }); } catch { /* skip */ }
    onProgress(++n, missing.length, 'Pictures');
    if (batch.length >= 60) { const r = await app.platform.importTextures(batch); app.textures = r.list; batch = []; }
  }
  if (batch.length) { const r = await app.platform.importTextures(batch); app.textures = r.list; }
  app.applyTextures?.();
  return missing.length;
}

/**
 * Before visiting a friend: if their Data Lab differs from yours, offer to use theirs for the visit.
 * Returns true to carry on with the visit, false to cancel.
 */
export async function offerFriendData(app, client, friend, { onProgress = () => {} } = {}) {
  let info;
  try { info = await client.datalabInfo(friend.username); } catch { return true; } // nothing shared: visit as you are
  const preset = (await app.platform.presets?.list?.() ?? []).find((p) => p.name === presetName(friend.username));
  const fresh = preset && preset.hash === info.hash;
  const choice = await chooseDialog(`${friend.trainerName} has their own Data Lab`, [
    { value: 'theirs', label: fresh ? 'Use their data (saved preset)' : 'Use their data for this visit', detail: `${info.counts?.species ?? '?'} species, ${info.counts?.moves ?? '?'} moves${fresh ? ' · already saved, nothing to download' : preset ? ' · they’ve changed it since your preset: it updates' : ' · downloads it (and any pictures you don’t have)'}` },
    { value: 'keep', label: fresh ? 'Use it, and keep the preset up to date' : 'Use it, and save it as a preset', detail: 'Next visit switches straight over; it only downloads again when they change their Data Lab.' },
    { value: 'mine', label: 'Keep my own data', detail: 'Their creatures show with your species list (anything you don’t have looks generic).' },
  ]);
  if (!choice) return false;
  if (choice === 'mine') { app.restoreDataset?.(); return true; }
  let ds;
  if (fresh) ds = (await app.platform.presets.load(preset.name))?.dataset;
  if (!ds) {
    const full = await client.datalabFull(friend.username);
    ds = full.dataset;
    const n = await bringPictures(app, client, full.textures, onProgress);
    if (n) toast(`Brought in ${n} picture${n === 1 ? '' : 's'} their data uses.`, 'ok');
    if (choice === 'keep') await app.platform.presets.save({ name: presetName(friend.username), label: `${friend.trainerName}’s data`, hash: full.hash, dataset: ds });
  }
  app.useDataset(ds, `${friend.trainerName}’s data`);
  return true;
}

/** Saved friends' presets: [{ name, label, species, at }] and a way to switch to one. */
export async function presetMenu(app) {
  const list = await app.platform.presets?.list?.() ?? [];
  if (!list.length) { toast('No saved presets yet. Visit a friend and choose “save it as a preset”.', 'err'); return; }
  const pick = await chooseDialog('Friends’ Data Lab presets', list.map((p) => ({ value: p.name, label: p.label, detail: `${p.species} species · saved ${new Date(p.at).toLocaleDateString()}` })));
  if (!pick) return;
  const p = await app.platform.presets.load(pick);
  if (p?.dataset) { app.useDataset(p.dataset, p.label); toast(`Using ${p.label}. The top bar takes you back to yours.`, 'ok'); }
}
void h;
