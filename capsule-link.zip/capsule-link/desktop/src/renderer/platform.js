// Where the PC app keeps its data. In Electron this talks to the main process; opened in a plain
// browser (the web preview) it falls back to localStorage so the interface can be tried anywhere.
import { createDefaultDataset, indexDataset, randomId, ensureTrainerCard } from '../../../shared/engine/index.js';
import { starterSave } from '../main/storage-starter.js';
import { makeBackup, backupFileName, readBackup, summarize } from '../../../shared/engine/backup.js';

const clean = (e) => { throw new Error(String(e.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, '')); };

export function getPlatform() {
  if (typeof window !== 'undefined' && window.capsule) return electronPlatform(window.capsule);
  return webPlatform();
}

function electronPlatform(api) {
  return {
    kind: 'desktop',
    petBusy: (uid, on) => api.petBusy?.(uid, on),
    presets: { list: () => api.presetsList(), save: (p) => api.presetsSave(p), load: (n) => api.presetsLoad(n), remove: (n) => api.presetsDelete(n) },
    load: () => api.load(),
    commit: (save, rev, reason) => api.commit(save, rev, reason),
    saveDataset: (ds) => api.saveDataset(ds),
    textures: () => api.listTextures(),
    openTextures: () => api.openTextures(),
    openData: () => api.openData(),
    importTexture: (p, bytes) => api.importTexture(p, bytes),
    importTextures: (files) => api.importTextures(files),
    listProfiles: () => api.listProfiles(),
    createProfile: (p) => api.createProfile(p),
    openProfile: (id) => api.openProfile(id),
    deleteProfile: (id) => api.deleteProfile(id),
    hubInfo: () => api.hubInfo(),
    host: api.hostStatus ? {
      status: () => api.hostStatus(), start: () => api.hostStart(), stop: () => api.hostStop(), configure: (p) => api.hostConfigure(p),
      forward: () => api.hostForward(), check: () => api.hostCheck(), firewall: () => api.hostFirewall(), onStatus: (fn) => api.onHostStatus(fn),
    } : null,
    usbSetup: () => api.usbSetup(),
    newPairCode: () => api.newPairCode(),
    forgetDevice: (id) => api.forgetDevice(id),
    exportFile: (name, text) => api.exportFile(name, text),
    importFile: (filters) => api.importFile(filters),
    reportDock: (d) => api.reportDock?.(d),
    backupExport: (opts) => api.backupExport(opts).catch(clean),
    backupList: () => api.backupList(),
    backupCopy: (file) => api.backupCopy(file).catch(clean),
    backupRead: (file) => api.backupRead(file).catch(clean),
    backupRestore: (text) => api.backupRestore(text).catch(clean),
    updateInfo: () => api.updateInfo(),
    installUpdate: (bytes) => api.installUpdate(bytes).catch((e) => { throw new Error(String(e.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, '')); }),
    revertUpdate: () => api.revertUpdate(),
    restart: () => api.restart(),
    fetchUrl: (url, as) => api.fetchUrl(url, as).catch((e) => { throw new Error(String(e.message).replace(/^Error invoking remote method '[^']+': (Error: )?/, '')); }),
    openShowdown: (url, config) => api.openShowdown(url, config),
    fetchText: (url) => api.fetchText(url),
    onShowdown: api.onShowdown,
    canEmbedShowdown: true,
    onSaveChanged: api.onSaveChanged,
    onDatasetChanged: api.onDatasetChanged,
    onTexturesChanged: api.onTexturesChanged,
    onHubChanged: api.onHubChanged,
    onSerialChoose: api.onSerialChoose,
    chooseSerial: api.chooseSerial,
    hasHub: true,
  };
}

const LS = { save: 'capsule-link:save', dataset: 'capsule-link:dataset', textures: 'capsule-link:textures', profiles: 'capsule-link:profiles' };
const read = (k) => { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } };
const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage full or blocked */ } };

function webPlatform() {
  let rev = 1;
  const noop = () => () => {};
  return {
    kind: 'web',
    async load() {
      let dataset = read(LS.dataset);
      const idx = indexDataset(dataset ?? createDefaultDataset());
      dataset = idx.ds;
      this.idx = idx;
      let index = read(LS.profiles);
      if (!index?.order?.length) {
        index = { active: null, order: [] };
        const old = read(LS.save); // a preview save from before profiles
        const id = randomId(6);
        write(`${LS.save}:${id}`, old ?? starterSave(idx, 'Trainer'));
        index.order.push(id); index.active = id;
        write(LS.profiles, index);
      }
      const save = this.readProfile(index.active);
      return { save, rev, dataset, textures: read(LS.textures) ?? {}, hub: null, paths: {}, version: 'preview', platform: 'web', profiles: await this.listProfiles(), activeProfile: index.active };
    },
    readProfile(id) {
      const sv = read(`${LS.save}:${id}`);
      if (sv) { ensureTrainerCard(sv); sv.settings = sv.settings || {}; }
      return sv;
    },
    async listProfiles() {
      const index = read(LS.profiles) ?? { order: [] };
      return index.order.map((id) => {
        const sv = this.readProfile(id);
        if (!sv) return null;
        const cs = Object.values(sv.creatures ?? {});
        return { id, trainer: sv.trainer, creatures: cs.length, steps: sv.stats?.totalSteps ?? 0, lastUsed: sv.settings?.lastLogin ?? null, active: id === index.active,
          party: cs.filter((c) => c.location?.kind === 'party').sort((a, b) => a.location.slot - b.location.slot).slice(0, 6).map((c) => c.speciesId) };
      }).filter(Boolean);
    },
    async createProfile({ name = 'Trainer', card = null } = {}) {
      const index = read(LS.profiles) ?? { active: null, order: [] };
      const id = randomId(6);
      const sv = starterSave(this.idx, String(name).slice(0, 12) || 'Trainer');
      if (card) sv.trainer.card = card;
      write(`${LS.save}:${id}`, sv);
      index.order.push(id);
      write(LS.profiles, index);
      return { id, profiles: await this.listProfiles() };
    },
    async openProfile(id) {
      const index = read(LS.profiles);
      index.active = id;
      write(LS.profiles, index);
      const save = this.readProfile(id);
      save.settings.lastLogin = Date.now();
      write(`${LS.save}:${id}`, save);
      rev++;
      return { save, rev, id };
    },
    async deleteProfile(id) {
      const index = read(LS.profiles);
      if (index.order.length <= 1) throw new Error('The last profile cannot be deleted.');
      index.order = index.order.filter((x) => x !== id);
      if (index.active === id) index.active = index.order[0];
      write(LS.profiles, index);
      try { localStorage.removeItem(`${LS.save}:${id}`); } catch { /* blocked */ }
      const save = this.readProfile(index.active);
      return { profiles: await this.listProfiles(), active: index.active, save, rev };
    },
    async commit(save) {
      const index = read(LS.profiles);
      write(`${LS.save}:${index?.active}`, save); rev++; return { ok: true, rev };
    },
    async saveDataset(ds) { write(LS.dataset, ds); return { ok: true }; },
    async textures() { return read(LS.textures) ?? {}; },
    async openTextures() {},
    async openData() {},
    async importTexture(p, bytes) {
      const map = read(LS.textures) ?? {};
      const blob = new Blob([bytes], { type: 'image/png' });
      map[p.toLowerCase()] = await new Promise((r) => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(blob); });
      write(LS.textures, map);
      return map;
    },
    async importTextures(files) {
      let list = null;
      const failed = [];
      for (const f of files) {
        try { list = await this.importTexture(f.path, f.data); } catch (e) { failed.push({ path: f.path, error: e.message }); }
      }
      return { list: list ?? read(LS.textures) ?? {}, failed };
    },
    async hubInfo() { return null; },
    host: null,
    petBusy: () => {},
    // the preview keeps presets in memory only
    presets: (() => { const m = new Map(); return { list: async () => [...m.values()].map((p) => ({ name: p.name, label: p.label, hash: p.hash, at: p.at, species: p.dataset?.species?.length ?? 0 })), save: async (p) => { m.set(p.name, { ...p, at: Date.now() }); return { ok: true }; }, load: async (n) => m.get(n) ?? null, remove: async (n) => { m.delete(n); return { ok: true }; } }; })(),
    async usbSetup() { return { ok: false, reason: 'web' }; },
    async newPairCode() { return null; },
    async forgetDevice() { return null; },
    async exportFile(name, text) {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
      a.download = name; document.body.append(a); a.click(); a.remove();
      return { ok: true };
    },
    importFile() {
      return new Promise((resolve) => {
        const input = document.createElement('input');
        input.type = 'file';
        input.onchange = async () => { const f = input.files[0]; resolve(f ? { name: f.name, text: await f.text() } : null); };
        input.click();
      });
    },
    // backups in the preview: everything kept in this browser
    async backupExport({ textures = true } = {}) {
      const index = read(LS.profiles) ?? { active: null, order: [] };
      const saves = {};
      for (const id of index.order) { const sv = read(`${LS.save}:${id}`); if (sv) saves[id] = sv; }
      const parts = { profiles: { active: index.active, order: index.order, saves }, dataset: read(LS.dataset) ?? this.idx?.ds };
      if (textures) {
        parts.textures = {};
        for (const [k, url] of Object.entries(read(LS.textures) ?? {})) if (/^data:image\/png;base64,/.test(url)) parts.textures[k] = url.slice(url.indexOf(',') + 1);
      }
      const b = makeBackup('pc', typeof __BUILD__ !== 'undefined' ? __BUILD__.version : 'preview', parts);
      await this.exportFile(backupFileName('pc'), JSON.stringify(b));
      return { ok: true, summary: summarize(b) };
    },
    async backupList() { return []; },
    async backupRestore(text) {
      const r = readBackup(text);
      if (!r.ok) throw new Error(r.error);
      if (r.kind !== 'pc') throw new Error(r.kind === 'phone' ? 'That is a phone backup: restore it on the phone.' : 'That is a single save: use Import save instead.');
      const b = r.backup;
      const index = read(LS.profiles) ?? { order: [] };
      for (const id of index.order) { try { localStorage.removeItem(`${LS.save}:${id}`); } catch { /* blocked */ } }
      const ids = Object.keys(b.profiles.saves);
      for (const id of ids) write(`${LS.save}:${id}`, b.profiles.saves[id]);
      write(LS.profiles, { active: ids.includes(b.profiles.active) ? b.profiles.active : ids[0], order: ids });
      if (b.dataset) write(LS.dataset, b.dataset);
      if (b.textures) {
        const map = read(LS.textures) ?? {};
        for (const [k, data] of Object.entries(b.textures)) map[k] = `data:image/png;base64,${data}`;
        write(LS.textures, map);
      }
      setTimeout(() => location.reload(), 50);
      return { profiles: ids.length, textures: Object.keys(b.textures ?? {}).length, summary: r.summary };
    },
    async updateInfo() { return { running: typeof __BUILD__ !== 'undefined' ? __BUILD__ : null, builtIn: null, active: null, preview: true }; },
    async installUpdate() { throw new Error('Updates install in the PC app, not the browser preview.'); },
    /** In a browser only sites that allow it can be read (raw GitHub does); the PC app can read any. */
    async fetchUrl(url, as = 'text') {
      let r;
      try { r = await fetch(url, { redirect: 'follow' }); } catch { throw new Error('This preview can’t download from that site (the browser blocks it). The PC app can.'); }
      const out = { ok: r.ok, status: r.status, type: r.headers.get('content-type') ?? '', url: r.url };
      if (!r.ok) return out;
      if (as === 'bytes') out.bytes = new Uint8Array(await r.arrayBuffer()); else out.text = await r.text();
      return out;
    },
    openShowdown: null,
    fetchText: null,
    onShowdown: noop,
    canEmbedShowdown: false,
    onSaveChanged: noop, onDatasetChanged: noop, onTexturesChanged: noop, onHubChanged: noop, onSerialChoose: noop,
    chooseSerial() {},
    hasHub: false,
  };
}
