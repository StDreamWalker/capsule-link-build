// Starting the PC: a short splash, a black screen asking "Whose PC are you using?", the trainer
// picker, then a connection to the network that keeps your creatures.
// Each trainer has their own profile (save) and ID card; a new one can be made here.
import { h, mount, toast, confirmDialog, timeAgo, brandText } from '../../../shared/ui/dom.js';
import { avatarEl } from '../../../shared/ui/idcard.js';
import { pickTrainerPictures } from './spriteImport.js';
import { runSetup } from './setup.js';
import { playIntro } from '../../../shared/ui/introShow.js';
import { cardEditor } from '../../../shared/ui/idcardEditor.js';
import { spriteCanvas } from '../../../shared/ui/art.js';
import { svgIcon, logoMark } from '../../../shared/ui/icons.js';
import { sfx } from '../../../shared/ui/audio.js';
import { defaultTrainerCard, cardNumber } from '../../../shared/engine/index.js';

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const reduced = () => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; } };

/** Black screen, one old-school text box: "Whose PC are you using?" Any key or click goes on. */
function retroPrompt(stage, text) {
  return new Promise((resolve) => {
    const out = h('span', { class: 'retro-text' });
    const arrow = h('span', { class: 'retro-arrow', 'aria-hidden': 'true' }, '\u25BC');
    const box = h('div', { class: 'retro-box', role: 'dialog', 'aria-label': text }, out, arrow);
    const scr = h('div', { class: 'retro-screen' }, box);
    mount(stage, scr);
    let i = 0, done = false, timer = 0;
    const full = brandText(text);
    const finish = () => { clearInterval(timer); out.textContent = full; done = true; scr.classList.add('ready'); };
    const go = (e) => {
      if (e?.type === 'keydown' && ['Shift', 'Control', 'Alt', 'Meta', 'Tab'].includes(e.key)) return;
      if (!done) { finish(); return; }
      window.removeEventListener('keydown', go);
      sfx('blip');
      scr.classList.add('out');
      setTimeout(resolve, reduced() ? 0 : 220);
    };
    window.addEventListener('keydown', go);
    scr.addEventListener('pointerdown', go);
    if (reduced()) finish();
    else timer = setInterval(() => {
      out.textContent = full.slice(0, ++i);
      if (full[i - 1] && full[i - 1] !== ' ') sfx('key');
      if (i >= full.length) finish();
    }, 45);
  });
}

/**
 * The PC reaching out to the network that keeps your creatures. Longer the first time a trainer
 * signs in on this PC. Resolves when `work` (opening the profile) and the steps are done.
 */
async function connecting(stage, app, p, work) {
  const first = !p.lastUsed || (() => { try { return !localStorage.getItem(`capsule-link:linked:${p.id}`); } catch { return false; } })();
  const n = app.idx?.ds?.species?.length ?? 0;
  const steps = [
    'Contacting Capsule Link Network servers…',
    ...(first ? ['Registering trainer ID with Capsule Link Network…'] : []),
    `Verifying trainer ID ${cardNumber(p.trainer?.id ?? p.id, p.trainer?.card)}…`,
    ...(first ? [`Allocating storage boxes on this PC…`, `Downloading creature data (${n} species)…`] : []),
    `Syncing boxes${p.creatures ? ` (${p.creatures} creatures)` : ''}…`,
    ...(first ? ['Calibrating capsule link…'] : []),
    'Establishing link…',
  ];
  const each = reduced() ? 60 : first ? 620 : 300;
  const rows = steps.map((t) => h('li', null, h('span', { class: 'conn-dot' }), h('span', null, t)));
  const bar = h('i');
  mount(stage, h('div', { class: 'connect' },
    h('div', { class: 'connect-card' },
      h('div', { class: 'connect-head' }, logoMark(36), h('div', null, h('div', { class: 'connect-title' }, first ? 'Setting up your link' : 'Connecting'), h('div', { class: 'dim' }, 'Capsule Link Network · Storage system'))),
      h('div', { class: 'connect-who' }, avatarEl(p.trainer, 56), h('div', null, h('div', { class: 'who-name' }, p.trainer?.name ?? 'Trainer'), h('div', { class: 'dim mono-num' }, `ID No. ${cardNumber(p.trainer?.id ?? p.id, p.trainer?.card)}`))),
      h('ol', { class: 'connect-steps' }, rows),
      h('div', { class: 'connect-bar' }, bar),
      h('div', { class: 'micro faint' }, 'Your creatures stay safe in storage while you are away.'))));
  let result, error;
  const job = work().then((r) => { result = r; }, (e) => { error = e; });
  for (let i = 0; i < rows.length; i++) {
    rows[i].classList.add('active');
    if (i === rows.length - 2 || i === rows.length - 1) await job; // the real work finishes before the link is up
    if (error) throw error;
    await wait(each * (0.7 + Math.random() * 0.6));
    rows[i].classList.remove('active'); rows[i].classList.add('done');
    bar.style.width = `${((i + 1) / rows.length) * 100}%`;
    sfx('move');
  }
  await job;
  if (error) throw error;
  try { localStorage.setItem(`capsule-link:linked:${p.id}`, '1'); } catch { /* storage blocked */ }
  return result;
}

/** Shows the splash (unless skipped) and the sign-in screen; resolves once a trainer is signed in. */
export function logOn(app, { boot = true } = {}) {
  return new Promise((resolve) => {
    const stage = h('div', { class: 'lock-stage' });
    const root = h('div', { class: 'lock' }, h('div', { class: 'lock-wall', 'aria-hidden': 'true' }, h('i'), h('i'), h('i')), stage);
    mount(document.body, root);

    async function splash() {
      mount(stage, h('div', { class: 'splash' }, logoMark(64), h('div', { class: 'splash-name' }, 'Capsule Link'), h('div', { class: 'splash-bar' }, h('i'))));
      let skip = false;
      const onSkip = () => { skip = true; };
      window.addEventListener('keydown', onSkip, { once: true });
      root.addEventListener('pointerdown', onSkip, { once: true });
      for (let t = 0; t < 12 && !skip && !reduced(); t++) await wait(100);
      window.removeEventListener('keydown', onSkip);
    }

    function profileTile(p) {
      const tile = h('button', { class: 'who-tile', onclick: () => enter(p) },
        h('span', { class: 'who-avatar' }, avatarEl(p.trainer, 96)),
        h('span', { class: 'who-name' }, p.trainer?.name ?? 'Trainer'),
        h('span', { class: 'who-meta' }, `${p.creatures} creature${p.creatures === 1 ? '' : 's'}${p.lastUsed ? ` · ${timeAgo(p.lastUsed)}` : ''}`),
        h('span', { class: 'who-party' }, (p.party ?? []).slice(0, 6).map((sp) => spriteCanvas(app.bank, sp, { scale: 1 }))));
      const remove = app.profiles.length > 1 ? h('button', { class: 'who-del', title: `Remove ${p.trainer?.name}`, 'aria-label': `Remove ${p.trainer?.name}`, onclick: async (e) => {
        e.stopPropagation();
        if (!(await confirmDialog(`Remove ${p.trainer?.name}?`, 'Their creatures and boxes go with them. A copy is kept in the backups folder.', { ok: 'Remove', danger: true }))) return;
        try { const r = await app.platform.deleteProfile(p.id); app.profiles = r.profiles; showWho(); } catch (err) { toast(err.message, 'err'); }
      } }, '×') : null;
      return h('div', { class: 'who-cell' }, tile, remove);
    }

    function showWho() {
      const tiles = h('div', { class: 'who-grid' },
        app.profiles.map(profileTile),
        h('div', { class: 'who-cell' }, h('button', { class: 'who-tile who-new', onclick: newTrainer },
          h('span', { class: 'who-avatar add' }, svgIcon('plus', { size: 40 })), h('span', { class: 'who-name' }, 'Add trainer'), h('span', { class: 'who-meta' }, 'Your own ID and PC'))));
      tiles.addEventListener('keydown', (e) => {
        const all = [...tiles.querySelectorAll('.who-tile')];
        const i = all.indexOf(document.activeElement);
        const step = { ArrowRight: 1, ArrowLeft: -1 }[e.key];
        if (i >= 0 && step) { e.preventDefault(); all[Math.max(0, Math.min(all.length - 1, i + step))].focus(); }
      });
      mount(stage,
        h('div', { class: 'who' }, h('h1', { class: 'who-title' }, 'Who’s using Capsule Link?'), tiles),
        h('div', { class: 'lock-foot' }, logoMark(20), h('span', null, 'Capsule Link'), h('span', { class: 'spacer' }), h('span', null, app.platform.kind === 'web' ? 'Preview: profiles stay in this browser' : '')));
      const active = Math.max(0, app.profiles.findIndex((p) => p.active));
      setTimeout(() => tiles.querySelectorAll('.who-tile')[active]?.focus({ preventScroll: true }), 30);
    }

    function newTrainer() {
      const draftId = Math.floor(Math.random() * 0xffffffff).toString(16);
      const ed = cardEditor({ trainer: { name: 'Trainer', id: draftId, card: defaultTrainerCard('Trainer', draftId) }, editName: true, scale: 1.5, onAddSprites: () => pickTrainerPictures(app) });
      mount(stage, h('div', { class: 'sheet' },
        h('div', { class: 'sheet-head' },
          h('button', { class: 'btn icon', 'aria-label': 'Back', onclick: showWho }, svgIcon('back')),
          h('div', null, h('h1', null, 'Create your trainer ID'), h('p', { class: 'dim' }, 'It appears on this PC and on your phone after it syncs.'))),
        ed.el,
        h('div', { class: 'actions' },
          h('button', { class: 'btn', onclick: showWho }, 'Cancel'),
          h('button', { class: 'btn primary', id: 'create-trainer', onclick: async (e) => {
            e.target.disabled = true;
            const { name, card } = ed.value();
            try {
              const r = await app.platform.createProfile({ name, card });
              app.profiles = r.profiles;
              enter(app.profiles.find((x) => x.id === r.id));
            } catch (err) { e.target.disabled = false; toast(err.message, 'err'); }
          } }, 'Create and sign in'))));
      stage.querySelector('#card-name')?.focus();
    }

    async function enter(p) {
      sfx('logon');
      let r;
      try { r = await connecting(stage, app, p, () => app.platform.openProfile(p.id)); }
      catch (err) { toast(`Could not sign in: ${err.message}`, 'err'); showWho(); return; }
      sfx('access');
      root.classList.add('leaving');
      await wait(reduced() ? 0 : 260);
      resolve(r);
    }

    (async () => {
      if (boot) await splash();
      if (!app.dataset?.setup?.done) {
        await playIntro(stage, { text: app.dataset?.introText });
        await runSetup(app, stage);
      }
      root.classList.add('dark-stage');
      await retroPrompt(stage, 'Whose PC are you using?');
      root.classList.remove('dark-stage');
      showWho();
    })();
  });
}
