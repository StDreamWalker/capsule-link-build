// Installing update files (.clupdate) on the PC: from Settings, or by dropping the file anywhere
// on the window. The PC part runs after a restart; the phone part goes to phones on their next sync.
import { h, mount, dialog, toast } from '../../../shared/ui/dom.js';
import { sfx } from '../../../shared/ui/audio.js';

export async function installUpdateFile(app, file) {
  if (!/\.clupdate$/i.test(file.name)) { toast('Update files end in .clupdate.', 'err'); return; }
  let r;
  try { r = await app.platform.installUpdate(new Uint8Array(await file.arrayBuffer())); }
  catch (e) { toast(e.message, 'err'); return; }
  sfx(r.pc === 'installed' || r.phone === 'ready' ? 'level' : 'blip');
  const pcLine = {
    installed: 'PC app: installed. It starts the next time the app opens.',
    same: 'PC app: already up to date.',
    full: 'PC app: this update needs a fresh full download of the PC app (the app engine changed).',
    none: null,
  }[r.pc];
  const phoneLine = {
    ready: 'Phone app: ready. Linked phones offer it the next time they sync.',
    same: 'Phone app: phones already have this one or newer.',
    none: null,
  }[r.phone];
  await dialog(`Update ${r.version}`, (close) => h('div', { class: 'col' },
    r.notes ? h('p', null, r.notes) : null,
    pcLine ? h('p', { class: r.pc === 'full' ? 'err-text' : '' }, pcLine) : null,
    phoneLine ? h('p', null, phoneLine) : null,
    r.backup ? h('p', { class: 'micro dim' }, 'Everyone’s saves and the data set were backed up first (Settings → Backups).') : null,
    h('div', { class: 'actions' },
      h('button', { class: 'btn', onclick: () => close() }, r.pc === 'installed' ? 'Later' : 'Done'),
      r.pc === 'installed' ? h('button', { class: 'btn primary', onclick: () => app.platform.restart() }, 'Restart now') : null)));
}

/** Drop a .clupdate anywhere on the window to install it. */
export function watchUpdateDrops(app) {
  window.addEventListener('dragover', (e) => { if ([...(e.dataTransfer?.items ?? [])].some((i) => i.kind === 'file')) e.preventDefault(); });
  window.addEventListener('drop', (e) => {
    const f = [...(e.dataTransfer?.files ?? [])].find((x) => /\.clupdate$/i.test(x.name));
    if (!f) return;
    e.preventDefault();
    installUpdateFile(app, f);
  });
}

/** The Updates panel in Settings. */
export function updatesPanel(app, rerender) {
  const el = h('section', { class: 'panel col' }, h('h2', null, 'Updates'), h('p', { class: 'dim' }, 'Checking…'));
  app.platform.updateInfo?.().then((u) => {
    const v = (b) => (b?.version ? `v${b.version}` : 'unknown');
    mount(el,
      h('h2', null, 'Updates'),
      h('p', { class: 'dim' }, u.preview ? `This preview is ${v(u.running)}. Update files install in the PC app.`
        : u.active ? `Running ${v(u.running)} from an update file (this download came with ${v(u.builtIn)}).` : `Running ${v(u.running)}.`),
      u.failed ? h('p', { class: 'err-text micro' }, `Update v${u.failed.version} didn’t start properly, so the app went back to its built-in version.`) : null,
      u.phone ? h('p', { class: 'micro dim' }, `Phone app v${u.phone.version} is waiting here; phones pick it up when they sync.`) : null,
      h('p', { class: 'micro dim' }, 'An update file (.clupdate) carries new code for both apps. Drop it anywhere on this window, or choose it here. Your creatures, save and textures are never touched.'),
      h('div', { class: 'row wrap' },
        h('label', { class: 'btn primary' }, 'Install update file…', h('input', { type: 'file', class: 'hidden', accept: '.clupdate', onchange: async (e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) { await installUpdateFile(app, f); rerender(); } } })),
        u.active ? h('button', { class: 'btn', onclick: async () => { await app.platform.revertUpdate(); toast('The built-in version starts next time.', 'ok'); rerender(); } }, `Go back to ${v(u.builtIn)}`) : null));
  }).catch(() => {});
  return el;
}
