// Settings → Backups: download everything as one JSON file, put a backup back, and the copies the
// PC keeps by itself (before every update and restore, daily saves, and backups sent by phones).
import { h, mount, toast, confirmDialog } from '../../../shared/ui/dom.js';
import { sfx } from '../../../shared/ui/audio.js';
import { readBackup } from '../../../shared/engine/backup.js';

const when = (ms) => new Date(ms).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
const kb = (n) => (n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

/** Put a backup (its text) back, after saying exactly what it holds. */
export async function restoreFromText(app, text, rerender) {
  const r = readBackup(text);
  if (!r.ok) { toast(r.error, 'err'); return; }
  if (r.kind === 'phone') { toast('That is a phone backup. On the phone: Link → Backups → Restore.', 'err'); return; }
  if (r.kind === 'save') {
    if (!(await confirmDialog('Replace this trainer’s save?', `${r.summary}. It replaces the save of the trainer logged on now. Other trainers, the data set and textures stay as they are.`, { ok: 'Replace', danger: true }))) return;
    app.commit((sv) => { for (const k of Object.keys(sv)) delete sv[k]; Object.assign(sv, JSON.parse(JSON.stringify(r.backup))); }, 'import');
    toast('Save loaded.', 'ok');
    rerender?.();
    return;
  }
  if (!(await confirmDialog('Restore this backup?', `${r.summary}. Every trainer, the data set and your names come back as they were in the backup. What is here now is kept as a backup first, so you can undo this.`, { ok: 'Restore', danger: true }))) return;
  try {
    const out = await app.platform.backupRestore(text);
    sfx('heal');
    toast(`Restored ${out.profiles} trainer${out.profiles === 1 ? '' : 's'}${out.textures ? ` and ${out.textures} textures` : ''}. Starting over…`, 'ok');
  } catch (e) { toast(`Could not restore: ${e.message}`, 'err'); }
}

export function backupsPanel(app, rerender) {
  let textures = true;
  let showAll = false;
  const listEl = h('div', { class: 'col backup-list' });
  const el = h('section', { class: 'panel col' },
    h('h2', null, 'Backups'),
    h('p', { class: 'dim' }, 'One file with every trainer, their creatures and items, the data set and your names. Keep it somewhere safe: if an update or anything else goes wrong, Restore puts it all back.'),
    h('div', { class: 'row wrap' },
      h('button', { class: 'btn primary', onclick: async () => {
        try {
          const r = await app.platform.backupExport({ textures });
          if (r?.ok) { sfx('level'); toast(r.path ? `Backup saved: ${r.path}` : 'Backup downloaded.', 'ok'); }
        } catch (e) { toast(`Could not make the backup: ${e.message}`, 'err'); }
      } }, 'Download backup'),
      h('button', { class: 'btn', onclick: async () => {
        const f = await app.platform.importFile([{ name: 'Backup', extensions: ['json'] }]);
        if (f) await restoreFromText(app, f.text, rerender);
      } }, 'Restore a backup…'),
      h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: textures, onchange: (e) => { textures = e.target.checked; } }), 'Include textures')),
    app.platform.kind === 'desktop' ? listEl : h('p', { class: 'micro faint' }, 'The PC app also keeps backups by itself: before every update, before a restore, a daily copy of each trainer, and backups sent by phones.'));

  const paint = (list) => {
    const shown = showAll ? list : list.slice(0, 6);
    mount(listEl,
      h('p', { class: 'micro dim' }, 'Kept by this PC: before every update and restore, a daily copy of each trainer (two weeks), and backups sent by phones.'),
      list.length ? shown.map((b) => h('div', { class: 'backup-row' },
        h('div', { class: 'col tight' },
          h('strong', null, `${{ pc: 'Everything', phone: 'Phone', save: 'One trainer' }[b.kind]} · ${when(b.at)}`),
          h('span', { class: 'micro dim' }, `${b.summary} · ${kb(b.size)}`)),
        h('div', { class: 'row' },
          h('button', { class: 'btn small', title: 'Save a copy somewhere else', onclick: async () => { try { const r = await app.platform.backupCopy(b.file); if (r?.ok) toast('Copy saved.', 'ok'); } catch (e) { toast(e.message, 'err'); } } }, 'Save a copy'),
          b.kind !== 'phone' ? h('button', { class: 'btn small', onclick: async () => { try { await restoreFromText(app, await app.platform.backupRead(b.file), rerender); } catch (e) { toast(e.message, 'err'); } } }, 'Restore') : null)))
        : h('p', { class: 'micro faint' }, 'None yet.'),
      list.length > 6 ? h('button', { class: 'btn small ghost', onclick: () => { showAll = !showAll; paint(list); } }, showAll ? 'Show fewer' : `Show all ${list.length}`) : null,
      h('div', { class: 'row' }, h('button', { class: 'btn small', onclick: () => app.platform.openData() }, 'Open data folder')));
  };
  if (app.platform.kind === 'desktop') app.platform.backupList().then(paint).catch(() => paint([]));
  return el;
}
