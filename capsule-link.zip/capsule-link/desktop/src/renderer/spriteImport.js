// Adding a whole folder of creature sprites at once.
// Each file is matched to a species by its name (id, name, Showdown name or number) and saved
// under the species id, so renaming species later does not lose the art.
import { spriteNames } from '../../../shared/ui/art.js';

const POSES = ['walk', 'sleep', 'happy', 'blink', 'back', 'icon'];
const POSE_END = new RegExp(`[-_](${POSES.join('|')})$`);
const compact = (s) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '');
const PHONE_LIMIT = 512 * 1024;

/** name -> species, for every name a sprite file could have. */
export function spriteIndex(species) {
  const index = new Map();
  for (const sp of species) {
    for (const n of spriteNames(sp)) {
      if (!index.has(n)) index.set(n, sp);
      if (!index.has(compact(n))) index.set(compact(n), sp);
    }
  }
  return index;
}

/** "Mr. Bristle-walk.png" -> { species, pose: 'walk', base: 'mr. bristle' } */
export function matchSpriteFile(fileName, index, { pose: forcePose = '' } = {}) {
  let base = String(fileName).replace(/\.png$/i, '').toLowerCase().trim();
  let pose = '';
  const m = POSE_END.exec(base);
  if (m) { pose = m[1]; base = base.slice(0, -m[0].length); }
  if (forcePose && !pose) pose = forcePose;
  const num = /^0*(\d+)$/.exec(base);
  const species = index.get(base) ?? index.get(compact(base)) ?? (num ? index.get(num[1]) : null) ?? null;
  return { species, pose, base };
}

/**
 * Import PNG files (File objects). Returns { saved, matched, unmatched: [names], skipped: [names], big: [names], failed }.
 * `back: true` treats files without a pose in their name as back views.
 */
export async function importSprites(app, files, { back = false } = {}) {
  const index = spriteIndex(app.idx.ds.species);
  const batch = [];
  const out = { saved: 0, matched: 0, unmatched: [], skipped: [], big: [], failed: [] };
  for (const f of files) {
    if (!/\.png$/i.test(f.name)) { out.skipped.push(f.name); continue; }
    const m = matchSpriteFile(f.name, index, { pose: back ? 'back' : '' });
    const stem = m.species ? m.species.id : m.base.replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'sprite';
    if (m.species) out.matched++; else out.unmatched.push(f.name);
    if (f.size > PHONE_LIMIT) out.big.push(f.name);
    batch.push({ path: `creatures/${stem}${m.pose ? `-${m.pose}` : ''}.png`, data: new Uint8Array(await f.arrayBuffer()) });
  }
  // send in chunks so one huge folder does not make one huge message
  for (let i = 0; i < batch.length; i += 200) {
    const r = await app.platform.importTextures(batch.slice(i, i + 200));
    out.failed.push(...(r.failed ?? []));
    app.textures = r.list;
  }
  out.saved = batch.length - out.failed.length;
  app.bank.setResolver((p) => app.textures[p.toLowerCase()] ?? null);
  return out;
}

/** How many species have a front sprite: { have, total, missing: [names] } */
export function spriteCoverage(app) {
  const list = app.idx.ds.species;
  const missing = [];
  for (const sp of list) if (!app.bank.find(sp)) missing.push(sp.name);
  return { have: list.length - missing.length, total: list.length, missing };
}

/** Ask for PNG files and save them as trainer pictures (textures/trainers). Returns how many were added. */
export function pickTrainerPictures(app) {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file'; input.accept = 'image/png'; input.multiple = true;
    input.onchange = async () => {
      const files = [...(input.files ?? [])].filter((f) => /\.png$/i.test(f.name));
      const batch = [];
      for (const f of files) {
        const stem = f.name.replace(/\.png$/i, '').toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'trainer';
        batch.push({ path: `trainers/${stem}.png`, data: new Uint8Array(await f.arrayBuffer()) });
      }
      for (let i = 0; i < batch.length; i += 200) {
        const r = await app.platform.importTextures(batch.slice(i, i + 200));
        app.textures = r.list;
      }
      app.applyTextures?.();
      resolve(batch.length);
    };
    input.addEventListener('cancel', () => resolve(0));
    input.click();
  });
}
