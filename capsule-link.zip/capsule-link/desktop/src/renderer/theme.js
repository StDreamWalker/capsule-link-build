// Light or dark (or whatever the computer uses): stored on this PC, applied before anyone signs in.
const KEY = 'capsule-link:theme';
export function currentTheme() { try { return localStorage.getItem(KEY) || 'system'; } catch { return 'system'; } }
export function applyTheme(t = currentTheme()) {
  try { localStorage.setItem(KEY, t); } catch { /* private mode */ }
  if (t === 'system') delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = t;
}
