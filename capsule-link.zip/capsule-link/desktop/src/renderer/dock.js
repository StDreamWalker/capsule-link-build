// The dock: a USB-serial NFC reader (see firmware/dock) or a virtual dock for testing.
// Serial protocol: one JSON object per line, 115200 baud.
//   PC -> dock  {"id":1,"cmd":"read","page":4,"count":16}   {"id":2,"cmd":"write","page":12,"hex":"..."}
//               {"id":3,"cmd":"led","mode":"pulse","rgb":"55ccff"}   {"id":4,"cmd":"tone","notes":[[76,2],[79,2]]}
//   dock -> PC  {"ev":"hello","fw":"dock-1.0"}  {"ev":"tag","uid":"04A1..","size":496}  {"ev":"removed","uid":"04A1.."}
//               {"id":1,"ok":true,"hex":"..."}  {"id":2,"ok":false,"error":"..."}
import { toHex, fromHex, makeVirtualTag, CAPSULE } from '../../../shared/engine/index.js';

const USER_BYTES = 232; // enough for the whole capsule NDEF message

class Emitter {
  constructor() { this.subs = new Map(); }
  on(ev, fn) { if (!this.subs.has(ev)) this.subs.set(ev, new Set()); this.subs.get(ev).add(fn); return () => this.subs.get(ev)?.delete(fn); }
  emit(ev, data) { for (const fn of this.subs.get(ev) ?? []) { try { fn(data); } catch (e) { console.error(e); } } }
}

export class SerialDock extends Emitter {
  constructor() {
    super();
    this.kind = 'serial';
    this.port = null;
    this.nextId = 1;
    this.pending = new Map();
    this.tagUid = null;
    this.info = {};
    this.status = 'disconnected';
  }
  static supported() {
    if (typeof navigator === 'undefined' || !('serial' in navigator)) return false;
    // embedded previews block USB access through the permissions policy
    try { if (document.featurePolicy && !document.featurePolicy.allowsFeature('serial')) return false; } catch { /* old browsers */ }
    return true;
  }

  async connect({ ask = true } = {}) {
    if (!SerialDock.supported()) throw new Error('This app build has no USB serial support.');
    let port = (await navigator.serial.getPorts())[0];
    if (!port || ask) port = await navigator.serial.requestPort();
    this.port = port;
    await port.open({ baudRate: 115200 });
    this.setStatus('connected');
    this.writer = port.writable.getWriter();
    this.readLoop();
    port.addEventListener?.('disconnect', () => this.lost());
    // ESP32 boards reset when the port opens; give it a moment, then ask who it is
    setTimeout(() => this.cmd('info', {}, 3000).then((r) => { this.info = r; this.emit('hello', r); }).catch(() => {}), 1200);
  }

  setStatus(s) { this.status = s; this.emit('status', s); }

  async readLoop() {
    const decoder = new TextDecoder();
    let buf = '';
    try {
      this.reader = this.port.readable.getReader();
      for (;;) {
        const { value, done } = await this.reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        let nl;
        while ((nl = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, nl).trim();
          buf = buf.slice(nl + 1);
          if (line.startsWith('{')) this.onLine(line);
        }
      }
    } catch (e) {
      console.warn('dock read stopped', e);
    }
    this.lost();
  }

  onLine(line) {
    let msg;
    try { msg = JSON.parse(line); } catch { return; }
    if (msg.id != null && this.pending.has(msg.id)) {
      const p = this.pending.get(msg.id);
      this.pending.delete(msg.id);
      clearTimeout(p.timer);
      if (msg.ok === false) p.reject(new Error(msg.error || 'Dock error')); else p.resolve(msg);
      return;
    }
    if (msg.ev === 'hello') { this.info = msg; this.emit('hello', msg); }
    if (msg.ev === 'tag') { this.tagUid = String(msg.uid).toUpperCase(); this.emit('tag', this.currentTag()); }
    if (msg.ev === 'removed') { const uid = this.tagUid; this.tagUid = null; this.emit('removed', uid); }
    if (msg.ev === 'log') this.emit('log', msg.msg);
  }

  cmd(cmd, args = {}, timeout = 4000) {
    const id = this.nextId++;
    const line = JSON.stringify({ id, cmd, ...args }) + '\n';
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(id); reject(new Error(`The dock did not answer "${cmd}".`)); }, timeout);
      this.pending.set(id, { resolve, reject, timer });
      this.writer.write(new TextEncoder().encode(line)).catch((e) => { clearTimeout(timer); this.pending.delete(id); reject(e); });
    });
  }

  currentTag() {
    if (!this.tagUid) return null;
    const uid = this.tagUid;
    const dock = this;
    return {
      uid,
      async readUser() {
        const out = new Uint8Array(Math.ceil(USER_BYTES / 4) * 4);
        for (let off = 0; off < out.length; off += 64) {
          const count = Math.min(16, (out.length - off) / 4);
          const r = await dock.cmd('read', { page: CAPSULE.FIRST_PAGE + off / 4, count });
          out.set(fromHex(r.hex).slice(0, count * 4), off);
        }
        return out;
      },
      async writePages(page, bytes) {
        for (let off = 0; off < bytes.length; off += 64) {
          const chunk = bytes.slice(off, off + 64);
          await dock.cmd('write', { page: page + off / 4, hex: toHex(chunk) }, 6000);
        }
      },
    };
  }

  led(mode, rgb) { return this.cmd('led', { mode, rgb }).catch(() => {}); }
  tone(notes) { return this.cmd('tone', { notes: notes.map((n) => [n.midi, n.ticks]) }).catch(() => {}); }

  lost() {
    if (this.status === 'disconnected') return;
    for (const p of this.pending.values()) { clearTimeout(p.timer); p.reject(new Error('Dock disconnected')); }
    this.pending.clear();
    this.tagUid = null;
    this.setStatus('disconnected');
    this.emit('removed', null);
  }

  async disconnect() {
    try { await this.reader?.cancel(); } catch { /* ignore */ }
    try { this.writer?.releaseLock(); } catch { /* ignore */ }
    try { await this.port?.close(); } catch { /* ignore */ }
    this.lost();
  }
}

/** Virtual dock + virtual capsules, stored in the save so they survive restarts. */
export class VirtualDock extends Emitter {
  constructor(getSave, persist) {
    super();
    this.kind = 'virtual';
    this.status = 'connected';
    this.getSave = getSave;
    this.persist = persist;
    this.tags = new Map();
    this.docked = null;
    this.load();
  }
  load() {
    const stored = this.getSave().virtualTags ?? {};
    for (const [uid, hex] of Object.entries(stored)) {
      const had = this.tags.get(uid);
      if (had) { had.mem.fill(0); had.mem.set(fromHex(hex).slice(0, had.mem.length)); } // in place: a docked copy sees it too
      else this.tags.set(uid, makeVirtualTag(uid, fromHex(hex)));
    }
  }
  store(uid) {
    const t = this.tags.get(uid);
    if (!t) return;
    this.persist((save) => { save.virtualTags = save.virtualTags || {}; save.virtualTags[uid] = toHex(t.mem); });
  }
  wrap(t) {
    return {
      uid: t.uid, virtual: true,
      readUser: () => t.readUser(),
      writePages: async (page, bytes) => { await t.writePages(page, bytes); this.store(t.uid); },
    };
  }
  create() {
    const uid = '04' + Array.from({ length: 6 }, () => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join('').toUpperCase();
    const t = makeVirtualTag(uid);
    t.mem.set([0x03, 0x00, 0xfe], 0);
    this.tags.set(uid, t);
    this.store(uid);
    return uid;
  }
  remove(uid) {
    if (this.docked === uid) this.undock();
    this.tags.delete(uid);
    this.persist((save) => { delete save.virtualTags?.[uid]; });
  }
  dock(uid) {
    if (this.docked) this.undock();
    this.docked = uid;
    this.emit('tag', this.wrap(this.tags.get(uid)));
  }
  undock() {
    const uid = this.docked;
    this.docked = null;
    this.emit('removed', uid);
  }
  currentTag() { return this.docked ? this.wrap(this.tags.get(this.docked)) : null; }
  walk(uid, steps, opts) { const t = this.tags.get(uid); if (!t) return; t.addSteps(steps, opts); this.store(uid); }
  led() {}
  tone() {}
  disconnect() { this.undock(); }
}
