// Getting art and data in without copy and paste:
//  - downloadSprites: one picture per species from an address pattern ({num}, {sd}, {id}, {name})
//  - pngLinksOn: every .png a web folder lists (for trainer pictures and the like)
//  - sliceSheet: cut one big sprite sheet into one picture per species
//  - trimPng: crop empty space around a sprite so it fills its frame
// Pictures are saved through the normal texture import, so phones pick them up on their next sync.
import { toId } from '../../../shared/engine/index.js';

export const SPRITE_SOURCES = [
  { id: 'sd-gen5', label: 'Showdown sprites (Black/White style, 96 px)', front: 'https://play.pokemonshowdown.com/sprites/gen5/{sd}.png', back: 'https://play.pokemonshowdown.com/sprites/gen5-back/{sd}.png',
    shiny: 'https://play.pokemonshowdown.com/sprites/gen5-shiny/{sd}.png', shinyBack: 'https://play.pokemonshowdown.com/sprites/gen5-back-shiny/{sd}.png' },
  { id: 'pokeapi', label: 'PokéAPI sprites (by number, 96 px)', front: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/{num}.png', back: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/back/{num}.png',
    shiny: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/shiny/{num}.png', shinyBack: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/back/shiny/{num}.png' },
];
/** Box icons (the small menu pictures): PokéSprite's Gen 8 set, 68×56, regular and shiny. */
export const ICON_SOURCE = { regular: 'https://raw.githubusercontent.com/msikma/pokesprite/master/pokemon-gen8/regular/{ps}.png', shiny: 'https://raw.githubusercontent.com/msikma/pokesprite/master/pokemon-gen8/shiny/{ps}.png' };
export const TRAINER_SOURCE = 'https://play.pokemonshowdown.com/sprites/trainers/';
/** Showdown's menu icons: one sheet, 40×30 cells, 12 across, cell N is national number N. */
export const ICON_SHEET = 'https://play.pokemonshowdown.com/sprites/pokemonicons-sheet.png';

/** Box icons for every species (and their shiny versions), kept at their true size. */
export function downloadBoxIcons(app, opts = {}) { return downloadSprites(app, { template: ICON_SOURCE.regular, shiny: ICON_SOURCE.shiny, trim: false, ...opts, icons: true }); }

/** Download the icon sheet and save creatures/<id>-icon.png for every species you have. */
export async function downloadIcons(app, url = ICON_SHEET) {
  const r = await app.platform.fetchUrl(url, 'bytes');
  if (!r.ok || !r.bytes) throw new Error(`the site answered ${r.status ?? 'nothing'}`);
  const img = await createImageBitmap(new Blob([r.bytes], { type: 'image/png' }));
  return sliceSheet(app, { img }, { cellW: 40, cellH: 30, startNo: 0, countEmpty: true, trim: false, pose: 'icon' });
}

/** An animated GIF as a strip of square frames side by side (how the app stores animations). */
async function gifToStrip(bytes) {
  if (typeof ImageDecoder === 'undefined') return null;
  const dec = new ImageDecoder({ data: bytes, type: 'image/gif' });
  await dec.tracks.ready;
  const n = dec.tracks.selectedTrack?.frameCount ?? 1;
  const step = Math.max(1, Math.ceil(n / 16)); // at most 16 frames
  const frames = [];
  for (let i = 0; i < n; i += step) frames.push((await dec.decode({ frameIndex: i })).image);
  const W = frames[0].displayWidth, H = frames[0].displayHeight;
  const tmp = document.createElement('canvas'); tmp.width = W; tmp.height = H;
  const tx = tmp.getContext('2d', { willReadFrequently: true });
  let x0 = W, y0 = H, x1 = 0, y1 = 0;
  for (const f of frames) {
    tx.clearRect(0, 0, W, H); tx.drawImage(f, 0, 0);
    const d = tx.getImageData(0, 0, W, H).data;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (d[(y * W + x) * 4 + 3] > 20) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  }
  if (x1 < x0) return null;
  const side = Math.max(x1 - x0 + 1, y1 - y0 + 1) + 2;
  const out = document.createElement('canvas'); out.width = side * frames.length; out.height = side;
  const ox = out.getContext('2d');
  frames.forEach((f, i) => ox.drawImage(f, x0, y0, x1 - x0 + 1, y1 - y0 + 1, i * side + Math.floor((side - (x1 - x0 + 1)) / 2), side - 1 - (y1 - y0 + 1), x1 - x0 + 1, y1 - y0 + 1));
  for (const f of frames) f.close?.();
  dec.close?.();
  return encode(out);
}
/** Showdown's sprite name: "deoxys-speed", "corsola-galar" for forms (base and form joined by a dash). */
export function sdSprite(sp) {
  const name = String(sp.showdownName || sp.name);
  const cut = name.indexOf('-');
  if (cut > 0 && (sp.baseSpecies || sp.forme || sp.no > 10000)) return `${toId(name.slice(0, cut))}-${toId(name.slice(cut + 1))}`;
  return toId(name);
}
// other places to look when the chosen set has no picture of a species (forms, the newest ones)
const FALLBACK = {
  front: ['https://play.pokemonshowdown.com/sprites/gen5/{sd}.png', 'https://play.pokemonshowdown.com/sprites/dex/{sd}.png', 'https://play.pokemonshowdown.com/sprites/home-centered/{sd}.png'],
  back: ['https://play.pokemonshowdown.com/sprites/gen5-back/{sd}.png'],
  shiny: ['https://play.pokemonshowdown.com/sprites/gen5-shiny/{sd}.png', 'https://play.pokemonshowdown.com/sprites/dex-shiny/{sd}.png', 'https://play.pokemonshowdown.com/sprites/home-centered-shiny/{sd}.png'],
};
/** Fill an address pattern for one species. */
export function spriteUrl(template, sp) {
  const n = Number(sp.no) || 0;
  return template
    .replace(/\{num\}/g, String(n))
    .replace(/\{num3\}/g, String(n).padStart(3, '0'))
    .replace(/\{num4\}/g, String(n).padStart(4, '0'))
    .replace(/\{sd\}/g, sdSprite(sp))
    .replace(/\{ps\}/g, psSlug(sp.showdownName || sp.name))
    .replace(/\{id\}/g, sp.id)
    .replace(/\{name\}/g, encodeURIComponent(sp.name));
}

async function decode(bytes) {
  const blob = new Blob([bytes], { type: 'image/png' });
  return createImageBitmap(blob);
}
async function encode(canvas) {
  const blob = await new Promise((r) => canvas.toBlob(r, 'image/png'));
  return new Uint8Array(await blob.arrayBuffer());
}

/** Crop transparent edges, keep it square, leave a 1 px margin. Returns PNG bytes (or the input if empty). */
export async function trimPng(bytes) {
  const img = await decode(bytes);
  const c = document.createElement('canvas');
  c.width = img.width; c.height = img.height;
  const ctx = c.getContext('2d');
  ctx.drawImage(img, 0, 0);
  const d = ctx.getImageData(0, 0, c.width, c.height).data;
  let x0 = c.width, y0 = c.height, x1 = -1, y1 = -1;
  for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) {
    if (d[(y * c.width + x) * 4 + 3] > 8) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  }
  if (x1 < 0) return bytes;
  const w = x1 - x0 + 1, h = y1 - y0 + 1, side = Math.max(w, h) + 2;
  const o = document.createElement('canvas');
  o.width = side; o.height = side;
  // centred sideways, standing on the bottom
  o.getContext('2d').drawImage(c, x0, y0, w, h, Math.floor((side - w) / 2), side - h - 1, w, h);
  return encode(o);
}

async function saveBatch(app, batch) {
  const failed = [];
  for (let i = 0; i < batch.length; i += 100) {
    const r = await app.platform.importTextures(batch.slice(i, i + 100));
    failed.push(...(r.failed ?? []));
    app.textures = r.list;
  }
  app.applyTextures?.();
  return failed;
}

/**
 * Download a sprite for every species (optionally only the ones without art).
 * opts: { template, back, trim, onlyMissing, onProgress(done, total), shouldStop() }
 * Returns { saved, missing: [names], failed: [] }.
 */
/** Cries from Showdown, one sound per species, saved as cries/<id>.mp3. */
export const CRY_SOURCE = 'https://play.pokemonshowdown.com/audio/cries/{sd}.mp3';
export function downloadCries(app, opts = {}) { return downloadSprites(app, { template: CRY_SOURCE, trim: false, ...opts, cries: true }); }

/** PokéSprite's file names: "mr-mime", "nidoran-f", "farfetchd", "flabebe", "rotom-wash". */
export function psSlug(name) {
  return String(name).normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/♀/g, '-f').replace(/♂/g, '-m')
    .toLowerCase().replace(/['’.:%]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

export async function downloadSprites(app, { template, back = '', shiny = '', shinyBack = '', cries = false, icons = false, trim = true, animated = false, onlyMissing = true, onProgress = () => {}, shouldStop = () => false } = {}) {
  const has = (p) => !!app.textures?.[p];
  const list = app.idx.ds.species.filter((sp) => !onlyMissing || (cries ? !has(`cries/${sp.id}.mp3`) : icons ? !has(`creatures/${sp.id}-icon.png`) : !app.bank.find(sp)));
  const jobs = [];
  for (const sp of list) {
    const main = cries ? `cries/${sp.id}.mp3` : icons ? `creatures/${sp.id}-icon.png` : `creatures/${sp.id}.png`;
    const ANI = { front: 'https://play.pokemonshowdown.com/sprites/gen5ani/{sd}.gif', back: 'https://play.pokemonshowdown.com/sprites/gen5ani-back/{sd}.gif', shiny: 'https://play.pokemonshowdown.com/sprites/gen5ani-shiny/{sd}.gif' };
    const alt = (kind, first) => [...new Set([...(animated && !cries && !icons ? [spriteUrl(ANI[kind], sp)] : []), first, ...(cries || icons ? [] : FALLBACK[kind].map((t) => spriteUrl(t, sp)))])];
    jobs.push({ sp, urls: alt('front', spriteUrl(template, sp)), path: main });
    if (back) jobs.push({ sp, urls: alt('back', spriteUrl(back, sp)), path: `creatures/${sp.id}-back.png`, optional: true });
    if (shiny) jobs.push({ sp, urls: alt('shiny', spriteUrl(shiny, sp)), path: icons ? `creatures/${sp.id}-shiny-icon.png` : `creatures/${sp.id}-shiny.png`, optional: true });
    if (shinyBack) jobs.push({ sp, url: spriteUrl(shinyBack, sp), path: `creatures/${sp.id}-shiny-back.png`, optional: true });
  }
  const out = { saved: 0, missing: [], failed: [] };
  let done = 0, batch = [];
  const worker = async () => {
    while (jobs.length && !shouldStop()) {
      const j = jobs.shift();
      try {
        let r = null;
        for (const url of j.urls ?? [j.url]) { r = await app.platform.fetchUrl(url, 'bytes').catch(() => null); if (r?.ok && r.bytes?.length) break; }
        if (r?.ok && r.bytes?.length) {
          const gif = r.bytes[0] === 0x47 && r.bytes[1] === 0x49 && r.bytes[2] === 0x46;
          const strip = gif ? await gifToStrip(r.bytes).catch(() => null) : null;
          batch.push({ path: j.path, data: strip ?? (trim ? await trimPng(r.bytes) : r.bytes) });
          out.saved++;
        } else if (!j.optional) out.missing.push(j.sp.name);
      } catch (e) { if (!j.optional) out.failed.push(`${j.sp.name}: ${e.message}`); }
      done++;
      onProgress(done, done + jobs.length);
      if (batch.length >= 60) { const b = batch; batch = []; out.failed.push(...(await saveBatch(app, b)).map((f) => f.error)); }
    }
  };
  await Promise.all(Array.from({ length: 6 }, worker));
  if (batch.length) out.failed.push(...(await saveBatch(app, batch)).map((f) => f.error));
  return out;
}

/** Every .png a web folder page links to (a directory listing). */
export async function pngLinksOn(app, pageUrl) {
  const base = pageUrl.endsWith('/') ? pageUrl : `${pageUrl}/`;
  const r = await app.platform.fetchUrl(base, 'text');
  if (!r.ok) throw new Error(`That address answered ${r.status}.`);
  const links = new Set();
  for (const m of r.text.matchAll(/href\s*=\s*["']([^"'#?]+\.png)["']/gi)) {
    try { links.add(new URL(m[1], r.url || base).href); } catch { /* bad link */ }
  }
  return [...links];
}

/** Download a list of picture addresses into a texture folder ('trainers', 'creatures', 'boxes'). */
export async function downloadPictures(app, urls, folder, { trim = false, onProgress = () => {}, shouldStop = () => false } = {}) {
  const jobs = urls.slice();
  const out = { saved: 0, failed: [] };
  let done = 0, batch = [];
  const worker = async () => {
    while (jobs.length && !shouldStop()) {
      const u = jobs.shift();
      const stem = decodeURIComponent(u.split('/').pop()).replace(/\.png$/i, '').toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'picture';
      try {
        const r = await app.platform.fetchUrl(u, 'bytes');
        if (r.ok && r.bytes?.length) { batch.push({ path: `${folder}/${stem}.png`, data: trim ? await trimPng(r.bytes) : r.bytes }); out.saved++; }
        else out.failed.push(`${stem}: ${r.status}`);
      } catch (e) { out.failed.push(`${stem}: ${e.message}`); }
      done++;
      onProgress(done, done + jobs.length);
      if (batch.length >= 60) { const b = batch; batch = []; out.failed.push(...(await saveBatch(app, b)).map((f) => f.error)); }
    }
  };
  await Promise.all(Array.from({ length: 6 }, worker));
  if (batch.length) out.failed.push(...(await saveBatch(app, batch)).map((f) => f.error));
  return out;
}

/** Look at a sprite sheet: its size and a guess at the grid (square cells, by the most common sprite sizes). */
export async function inspectSheet(file) {
  const img = await createImageBitmap(file);
  const guesses = [96, 80, 68, 64, 56, 48, 40, 32].filter((s) => img.width % s === 0 && img.height % s === 0);
  const cell = guesses[0] ?? Math.min(img.width, img.height);
  return { img, width: img.width, height: img.height, cell };
}

/**
 * Cut a sheet into species pictures: cells read left to right, top to bottom, numbered from
 * `startNo`. Empty cells are skipped (and don't use up a number unless `countEmpty`).
 * Saves creatures/<species id>.png for numbers that exist in the data set; returns { saved, skipped }.
 */
export async function sliceSheet(app, sheet, { cellW, cellH = cellW, gap = 0, offsetX = 0, offsetY = 0, startNo = 1, countEmpty = true, trim = true, pose = '' } = {}) {
  const { img } = sheet;
  const cols = Math.floor((img.width - offsetX + gap) / (cellW + gap));
  const rows = Math.floor((img.height - offsetY + gap) / (cellH + gap));
  const byNo = new Map(app.idx.ds.species.map((s) => [Number(s.no), s]));
  const c = document.createElement('canvas');
  c.width = cellW; c.height = cellH;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  const batch = [];
  let no = startNo, skipped = 0;
  for (let r = 0; r < rows; r++) for (let q = 0; q < cols; q++) {
    ctx.clearRect(0, 0, cellW, cellH);
    ctx.drawImage(img, offsetX + q * (cellW + gap), offsetY + r * (cellH + gap), cellW, cellH, 0, 0, cellW, cellH);
    const d = ctx.getImageData(0, 0, cellW, cellH).data;
    let any = false;
    for (let i = 3; i < d.length; i += 4) if (d[i] > 8) { any = true; break; }
    if (!any) { if (countEmpty) no++; continue; }
    const sp = byNo.get(no);
    no++;
    if (!sp) { skipped++; continue; }
    let bytes = await encode(c);
    if (trim) bytes = await trimPng(bytes);
    batch.push({ path: `creatures/${sp.id}${pose ? `-${pose}` : ''}.png`, data: bytes });
  }
  const failed = await saveBatch(app, batch);
  return { saved: batch.length - failed.length, skipped, cols, rows };
}

// ---------- item sprites ----------
/** PokéAPI keeps one small picture per item under its dashed name ("oran-berry"); Showdown has one sheet (24×24, 16 across). */
export const ITEM_SOURCE = 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/{ps}.png';
export const ITEM_SHEET = 'https://play.pokemonshowdown.com/sprites/itemicons-sheet.png';
const NO_ITEM_ART = new Set(['clothes', 'toy', 'blueprint', 'dish']);

/** Save items/<id>.png for every item that has a picture somewhere (PokéAPI first, then Showdown's sheet). */
export async function downloadItemSprites(app, { onlyMissing = true, onProgress = () => {}, shouldStop = () => false } = {}) {
  const items = (app.dataset?.items ?? app.idx.ds.items ?? []).filter((it) => !NO_ITEM_ART.has(it.kind) && !String(it.id).startsWith('dish-') && !(onlyMissing && app.textures?.[`items/${it.id}.png`]));
  const out = { saved: 0, missing: [], failed: [] };
  const left = [];
  let done = 0, batch = [];
  const jobs = items.slice();
  const worker = async () => {
    while (jobs.length && !shouldStop()) {
      const it = jobs.shift();
      try {
        const r = await app.platform.fetchUrl(ITEM_SOURCE.replace('{ps}', psSlug(it.showdownName ?? it.name)), 'bytes').catch(() => null);
        if (r?.ok && r.bytes?.length) { batch.push({ path: `items/${it.id}.png`, data: await trimPng(r.bytes) }); out.saved++; }
        else left.push(it);
      } catch { left.push(it); }
      done++;
      onProgress(done, items.length);
      if (batch.length >= 60) { const b = batch; batch = []; out.failed.push(...(await saveBatch(app, b)).map((f) => f.error)); }
    }
  };
  await Promise.all(Array.from({ length: 6 }, worker));
  // TM discs, one per type (tm-fire…), and the Full Incense that made-up type incenses are recoloured from
  const balls = ['master-ball', 'ultra-ball', 'great-ball', 'poke-ball', 'safari-ball', 'net-ball', 'dive-ball', 'nest-ball', 'repeat-ball', 'timer-ball', 'luxury-ball', 'premier-ball', 'dusk-ball', 'heal-ball', 'quick-ball', 'cherish-ball', 'fast-ball', 'level-ball', 'lure-ball', 'heavy-ball', 'love-ball', 'friend-ball', 'moon-ball', 'sport-ball', 'dream-ball', 'beast-ball', 'strange-ball'].map((b) => [b, b]);
  const extra = [...balls, ['incense-base', 'full-incense'], ...['normal', 'fire', 'water', 'electric', 'grass', 'ice', 'fighting', 'poison', 'ground', 'flying', 'psychic', 'bug', 'rock', 'ghost', 'dragon', 'dark', 'steel', 'fairy'].map((t) => [`tm-type-${t}`, `tm-${t}`])]
    .filter(([id]) => !(onlyMissing && app.textures?.[`items/${id}.png`]));
  for (const [id, ps] of extra) {
    if (shouldStop()) break;
    const r = await app.platform.fetchUrl(ITEM_SOURCE.replace('{ps}', ps), 'bytes').catch(() => null);
    if (r?.ok && r.bytes?.length) { batch.push({ path: `items/${id}.png`, data: await trimPng(r.bytes) }); out.saved++; }
  }
  // what PokéAPI doesn't have: cut from Showdown's sheet by the item's sprite number
  const bySheet = left.filter((it) => it.spritenum != null);
  if (bySheet.length && !shouldStop()) {
    try {
      const r = await app.platform.fetchUrl(ITEM_SHEET, 'bytes');
      if (r.ok && r.bytes) {
        const img = await createImageBitmap(new Blob([r.bytes], { type: 'image/png' }));
        const cv = document.createElement('canvas'); cv.width = 24; cv.height = 24;
        const x = cv.getContext('2d', { willReadFrequently: true });
        for (const it of bySheet) {
          const n = it.spritenum, sx = (n % 16) * 24, sy = Math.floor(n / 16) * 24;
          if (sy + 24 > img.height) { out.missing.push(it.name); continue; }
          x.clearRect(0, 0, 24, 24); x.drawImage(img, sx, sy, 24, 24, 0, 0, 24, 24);
          const d = x.getImageData(0, 0, 24, 24).data;
          let any = false; for (let i = 3; i < d.length; i += 4) if (d[i] > 20) { any = true; break; }
          if (!any) { out.missing.push(it.name); continue; }
          batch.push({ path: `items/${it.id}.png`, data: await encode(cv) }); out.saved++;
        }
      }
    } catch (e) { out.failed.push(`item sheet: ${e.message}`); }
  }
  out.missing.push(...left.filter((it) => it.spritenum == null).map((it) => it.name));
  if (batch.length) out.failed.push(...(await saveBatch(app, batch)).map((f) => f.error));
  return out;
}

// ---------- move effects ----------
/** Showdown's battle effect pictures (fireball, waterwisp, fist…) for the move animations, saved as fx/<file>.png. */
/** Every ball's item picture (items/poke-ball.png…), fetched quietly when they're missing: balls show as the real thing. */
export const BALL_ITEMS = ['master-ball', 'ultra-ball', 'great-ball', 'poke-ball', 'safari-ball', 'net-ball', 'dive-ball', 'nest-ball', 'repeat-ball', 'timer-ball', 'luxury-ball', 'premier-ball', 'dusk-ball', 'heal-ball', 'quick-ball', 'cherish-ball', 'fast-ball', 'level-ball', 'lure-ball', 'heavy-ball', 'love-ball', 'friend-ball', 'moon-ball', 'sport-ball', 'dream-ball', 'beast-ball', 'strange-ball'];
export async function downloadBallSprites(app) {
  const want = BALL_ITEMS.filter((b) => !app.textures?.[`items/${b}.png`]);
  if (!want.length) return 0;
  const batch = [];
  await Promise.all(want.map(async (b) => { const r = await app.platform.fetchUrl(ITEM_SOURCE.replace('{ps}', b), 'bytes').catch(() => null); if (r?.ok && r.bytes?.length) batch.push({ path: `items/${b}.png`, data: await trimPng(r.bytes) }); }));
  if (batch.length) await saveBatch(app, batch);
  return batch.length;
}
export async function downloadMoveFx(app, { onProgress = () => {}, shouldStop = () => false } = {}) {
  const { SD_FX_FILES, SD_FX_SOURCE } = await import('../../../shared/ui/sdanim/player.js');
  const { BACKDROP_FILES } = await import('../../../shared/ui/showdownWild.js');
  // and the battle backgrounds wild battles use (one per kind of place)
  return downloadPictures(app, [...SD_FX_FILES.map((f) => SD_FX_SOURCE + f), ...BACKDROP_FILES.map((f) => `https://play.pokemonshowdown.com/sprites/gen6bgs/${f}`)], 'fx', { onProgress, shouldStop });
}
