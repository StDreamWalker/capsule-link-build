// Getting art and data in without copy and paste:
//  - downloadSprites: one picture per species from an address pattern ({num}, {sd}, {id}, {name})
//  - pngLinksOn: every .png a web folder lists (for trainer pictures and the like)
//  - sliceSheet: cut one big sprite sheet into one picture per species
//  - trimPng: crop empty space around a sprite so it fills its frame
// Pictures are saved through the normal texture import, so phones pick them up on their next sync.
import { toId } from '../../../shared/engine/index.js';

export const SPRITE_SOURCES = [
  { id: 'sd-gen5', label: 'Showdown sprites (Black/White style, 96 px)', front: 'https://play.pokemonshowdown.com/sprites/gen5/{sd}.png', back: 'https://play.pokemonshowdown.com/sprites/gen5-back/{sd}.png' },
  { id: 'pokeapi', label: 'PokéAPI sprites (by number, 96 px)', front: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/{num}.png', back: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/back/{num}.png' },
];
export const TRAINER_SOURCE = 'https://play.pokemonshowdown.com/sprites/trainers/';

/** Fill an address pattern for one species. */
export function spriteUrl(template, sp) {
  const n = Number(sp.no) || 0;
  return template
    .replace(/\{num\}/g, String(n))
    .replace(/\{num3\}/g, String(n).padStart(3, '0'))
    .replace(/\{num4\}/g, String(n).padStart(4, '0'))
    .replace(/\{sd\}/g, toId(sp.showdownName || sp.name))
    .replace(/\{id\}/g, sp.id)
    .replace(/\{name\}/g, encodeURIComponent(sp.name));
}

async function decode(bytes) {
  const blob = new Blob([bytes], { type: 'image/png' });
  return createImageBitmap(blob);
}
async function encode(canvas) {
  const blob = await new Promise((r) => canvas.toBlob(r, 'image/png'));
  return new Uint8Array(await blob.arrayBuffer());
}

/** Crop transparent edges, keep it square, leave a 1 px margin. Returns PNG bytes (or the input if empty). */
export async function trimPng(bytes) {
  const img = await decode(bytes);
  const c = document.createElement('canvas');
  c.width = img.width; c.height = img.height;
  const ctx = c.getContext('2d');
  ctx.drawImage(img, 0, 0);
  const d = ctx.getImageData(0, 0, c.width, c.height).data;
  let x0 = c.width, y0 = c.height, x1 = -1, y1 = -1;
  for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) {
    if (d[(y * c.width + x) * 4 + 3] > 8) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  }
  if (x1 < 0) return bytes;
  const w = x1 - x0 + 1, h = y1 - y0 + 1, side = Math.max(w, h) + 2;
  const o = document.createElement('canvas');
  o.width = side; o.height = side;
  // centred sideways, standing on the bottom
  o.getContext('2d').drawImage(c, x0, y0, w, h, Math.floor((side - w) / 2), side - h - 1, w, h);
  return encode(o);
}

async function saveBatch(app, batch) {
  const failed = [];
  for (let i = 0; i < batch.length; i += 100) {
    const r = await app.platform.importTextures(batch.slice(i, i + 100));
    failed.push(...(r.failed ?? []));
    app.textures = r.list;
  }
  app.applyTextures?.();
  return failed;
}

/**
 * Download a sprite for every species (optionally only the ones without art).
 * opts: { template, back, trim, onlyMissing, onProgress(done, total), shouldStop() }
 * Returns { saved, missing: [names], failed: [] }.
 */
export async function downloadSprites(app, { template, back = '', trim = true, onlyMissing = true, onProgress = () => {}, shouldStop = () => false } = {}) {
  const list = app.idx.ds.species.filter((sp) => !onlyMissing || !app.bank.find(sp));
  const jobs = [];
  for (const sp of list) {
    jobs.push({ sp, url: spriteUrl(template, sp), path: `creatures/${sp.id}.png` });
    if (back) jobs.push({ sp, url: spriteUrl(back, sp), path: `creatures/${sp.id}-back.png`, optional: true });
  }
  const out = { saved: 0, missing: [], failed: [] };
  let done = 0, batch = [];
  const worker = async () => {
    while (jobs.length && !shouldStop()) {
      const j = jobs.shift();
      try {
        const r = await app.platform.fetchUrl(j.url, 'bytes');
        if (r.ok && r.bytes?.length) {
          batch.push({ path: j.path, data: trim ? await trimPng(r.bytes) : r.bytes });
          out.saved++;
        } else if (!j.optional) out.missing.push(j.sp.name);
      } catch (e) { if (!j.optional) out.failed.push(`${j.sp.name}: ${e.message}`); }
      done++;
      onProgress(done, done + jobs.length);
      if (batch.length >= 60) { const b = batch; batch = []; out.failed.push(...(await saveBatch(app, b)).map((f) => f.error)); }
    }
  };
  await Promise.all(Array.from({ length: 6 }, worker));
  if (batch.length) out.failed.push(...(await saveBatch(app, batch)).map((f) => f.error));
  return out;
}

/** Every .png a web folder page links to (a directory listing). */
export async function pngLinksOn(app, pageUrl) {
  const base = pageUrl.endsWith('/') ? pageUrl : `${pageUrl}/`;
  const r = await app.platform.fetchUrl(base, 'text');
  if (!r.ok) throw new Error(`That address answered ${r.status}.`);
  const links = new Set();
  for (const m of r.text.matchAll(/href\s*=\s*["']([^"'#?]+\.png)["']/gi)) {
    try { links.add(new URL(m[1], r.url || base).href); } catch { /* bad link */ }
  }
  return [...links];
}

/** Download a list of picture addresses into a texture folder ('trainers', 'creatures', 'boxes'). */
export async function downloadPictures(app, urls, folder, { trim = false, onProgress = () => {}, shouldStop = () => false } = {}) {
  const jobs = urls.slice();
  const out = { saved: 0, failed: [] };
  let done = 0, batch = [];
  const worker = async () => {
    while (jobs.length && !shouldStop()) {
      const u = jobs.shift();
      const stem = decodeURIComponent(u.split('/').pop()).replace(/\.png$/i, '').toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'picture';
      try {
        const r = await app.platform.fetchUrl(u, 'bytes');
        if (r.ok && r.bytes?.length) { batch.push({ path: `${folder}/${stem}.png`, data: trim ? await trimPng(r.bytes) : r.bytes }); out.saved++; }
        else out.failed.push(`${stem}: ${r.status}`);
      } catch (e) { out.failed.push(`${stem}: ${e.message}`); }
      done++;
      onProgress(done, done + jobs.length);
      if (batch.length >= 60) { const b = batch; batch = []; out.failed.push(...(await saveBatch(app, b)).map((f) => f.error)); }
    }
  };
  await Promise.all(Array.from({ length: 6 }, worker));
  if (batch.length) out.failed.push(...(await saveBatch(app, batch)).map((f) => f.error));
  return out;
}

/** Look at a sprite sheet: its size and a guess at the grid (square cells, by the most common sprite sizes). */
export async function inspectSheet(file) {
  const img = await createImageBitmap(file);
  const guesses = [96, 80, 68, 64, 56, 48, 40, 32].filter((s) => img.width % s === 0 && img.height % s === 0);
  const cell = guesses[0] ?? Math.min(img.width, img.height);
  return { img, width: img.width, height: img.height, cell };
}

/**
 * Cut a sheet into species pictures: cells read left to right, top to bottom, numbered from
 * `startNo`. Empty cells are skipped (and don't use up a number unless `countEmpty`).
 * Saves creatures/<species id>.png for numbers that exist in the data set; returns { saved, skipped }.
 */
export async function sliceSheet(app, sheet, { cellW, cellH = cellW, gap = 0, offsetX = 0, offsetY = 0, startNo = 1, countEmpty = true, trim = true, pose = '' } = {}) {
  const { img } = sheet;
  const cols = Math.floor((img.width - offsetX + gap) / (cellW + gap));
  const rows = Math.floor((img.height - offsetY + gap) / (cellH + gap));
  const byNo = new Map(app.idx.ds.species.map((s) => [Number(s.no), s]));
  const c = document.createElement('canvas');
  c.width = cellW; c.height = cellH;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  const batch = [];
  let no = startNo, skipped = 0;
  for (let r = 0; r < rows; r++) for (let q = 0; q < cols; q++) {
    ctx.clearRect(0, 0, cellW, cellH);
    ctx.drawImage(img, offsetX + q * (cellW + gap), offsetY + r * (cellH + gap), cellW, cellH, 0, 0, cellW, cellH);
    const d = ctx.getImageData(0, 0, cellW, cellH).data;
    let any = false;
    for (let i = 3; i < d.length; i += 4) if (d[i] > 8) { any = true; break; }
    if (!any) { if (countEmpty) no++; continue; }
    const sp = byNo.get(no);
    no++;
    if (!sp) { skipped++; continue; }
    let bytes = await encode(c);
    if (trim) bytes = await trimPng(bytes);
    batch.push({ path: `creatures/${sp.id}${pose ? `-${pose}` : ''}.png`, data: bytes });
  }
  const failed = await saveBatch(app, batch);
  return { saved: batch.length - failed.length, skipped, cols, rows };
}
