// The game-data files the app can bring in from Showdown, in the order that works (learnsets need species
// and moves first), and one function that reads one into the data set. Used by the setup guide's steps
// and by "Download everything".
import { parsePaste, guessMapping, applyImport, normalizeDataset } from '../../../shared/engine/index.js';

const clone = (x) => JSON.parse(JSON.stringify(x));
const SD = 'https://github.com/smogon/pokemon-showdown/blob/master/data';
const RAW = 'https://raw.githubusercontent.com/smogon/pokemon-showdown/master/data';

/** The data steps, in the order that works (learnsets need species and moves first). */
export const DATA_STEPS = [
  {
    id: 'species', target: 'species', title: 'Species', file: 'pokedex.ts',
    what: 'Names, numbers, types, base stats, abilities and evolutions.',
    how: 'Press Download for me. (By hand: open the raw text, select all, copy and paste below — exactly as it is.)',
    looks: 'export const Pokedex: import(\'../sim/dex-species\').SpeciesDataTable = {\n\tbulbasaur: {\n\t\tnum: 1,\n\t\tname: "Bulbasaur",\n\t\ttypes: ["Grass", "Poison"], …',
    raw: `${RAW}/pokedex.ts`,
    links: [['View on GitHub', `${SD}/pokedex.ts`], ['Raw text to copy', `${RAW}/pokedex.ts`]],
  },
  {
    id: 'moves', target: 'moves', title: 'Moves', file: 'moves.ts',
    what: 'Every move: type, category, power, accuracy, PP and priority.',
    how: 'Press Download for me. This file is too big for GitHub’s normal page to copy in one go, so if you paste by hand use the raw text, or save it and use Load a file.',
    looks: 'export const Moves: import(\'../sim/dex-moves\').MoveDataTable = {\n\tabsorb: {\n\t\tnum: 71,\n\t\taccuracy: 100,\n\t\tbasePower: 20, …',
    raw: `${RAW}/moves.ts`,
    links: [['View on GitHub', `${SD}/moves.ts`], ['Raw text to copy', `${RAW}/moves.ts`]],
  },
  {
    id: 'learnset', target: 'learnset', title: 'Learnsets', file: 'learnsets.ts', big: true,
    what: 'Which moves each species learns by level (the newest generation each appears in).',
    how: 'Press Download for me (several megabytes; takes a few seconds). By hand: save the raw page and use Load a file.',
    looks: 'export const Learnsets: import(\'../sim/dex-species\').LearnsetDataTable = {\n\tbulbasaur: {\n\t\tlearnset: {\n\t\t\tabsorb: ["9L1", "8L1"], …',
    raw: `${RAW}/learnsets.ts`,
    links: [['View on GitHub', `${SD}/learnsets.ts`], ['Raw text to copy', `${RAW}/learnsets.ts`]],
  },
  {
    id: 'natures', target: 'temperaments', title: 'Natures', file: 'natures.ts',
    what: 'Nature names with the stat each one raises and lowers.',
    how: 'Press Download for me, or copy the raw text and paste it.',
    looks: 'export const Natures: import(\'../sim/dex-data\').NatureDataTable = {\n\tadamant: {\n\t\tname: "Adamant",\n\t\tplus: \'atk\',\n\t\tminus: \'spa\',\n\t}, …',
    raw: `${RAW}/natures.ts`,
    links: [['View on GitHub', `${SD}/natures.ts`], ['Raw text to copy', `${RAW}/natures.ts`]],
  },
  {
    id: 'items', target: 'items', title: 'Items', file: 'items.ts', optional: true,
    what: 'Every item. Berries become food that grows on the berry farm; the rest are held items for battles.',
    how: 'Optional. Press Download for me. Items you already have keep what they do; new ones are added.',
    looks: 'export const Items: import(\'../sim/dex-items\').ItemDataTable = {\n\tabilityshield: {\n\t\tname: "Ability Shield",\n\t\tspritenum: 746, …',
    raw: `${RAW}/items.ts`,
    links: [['View on GitHub', `${SD}/items.ts`], ['Raw text to copy', `${RAW}/items.ts`]],
  },
  {
    id: 'itemtext', target: 'items', title: 'Item descriptions', file: 'text/items.ts', optional: true, mode: 'update',
    what: 'The one-line description shown for each item.',
    how: 'Optional. Press Download for me after Items. It only adds descriptions.',
    looks: 'export const ItemsText: {[k: string]: ItemText} = {\n\tabilityshield: {\n\t\tname: "Ability Shield",\n\t\tdesc: …',
    raw: `${RAW}/text/items.ts`,
    links: [['View on GitHub', `${SD}/text/items.ts`], ['Raw text to copy', `${RAW}/text/items.ts`]],
  },
  {
    id: 'movetext', target: 'moves', title: 'Move descriptions', file: 'text/moves.ts', optional: true, mode: 'update',
    what: 'The one-line description shown for each move.',
    how: 'Optional. Press Download for me. It only adds descriptions to moves you already have.',
    looks: 'export const MovesText: {[k: string]: MoveText} = {\n\tabsorb: {\n\t\tname: "Absorb",\n\t\tdesc: "The user recovers 1/2 …',
    raw: `${RAW}/text/moves.ts`,
    links: [['View on GitHub', `${SD}/text/moves.ts`], ['Raw text to copy', `${RAW}/text/moves.ts`]],
  },
];


/** What kind of table a parsed paste holds. */
export function detectTarget(parsed, fallback) {
  return parsed.target ?? (parsed.format === 'lines' ? 'learnset'
    // moves have a "type" too, so look for move columns first
    : parsed.columns.some((c) => /^spritenum$|^isberry$|^megastone$/i.test(c)) ? 'items'
    : parsed.columns.some((c) => /basepower|^accuracy$|^pp$|^category$/i.test(c)) ? 'moves'
      : parsed.columns.some((c) => /basestats|^types$|abilities|heightm/i.test(c)) ? 'species' : fallback);
}

/** Read one step's file into a copy of the data set and save it. Returns the import report (+ parsed). */
export async function importStep(app, step, text, { replace = false } = {}) {
  const parsed = parsePaste(text);
  const ds = clone(app.dataset);
  const expect = step.target;
  if (step.id === 'species' && replace) { ds.species = []; ds.types = []; ds.typeChart = ds.typeChart ?? {}; }
  if (step.id === 'moves' && replace) ds.moves = [];
  const mapping = guessMapping(parsed.columns, expect);
  const rep = applyImport(ds, expect, parsed.rows, mapping, { mode: step.mode === 'update' && expect === 'items' ? 'update' : 'merge', mainOnly: expect === 'species' || expect === 'moves' || expect === 'items' });
  if (rep.added + rep.updated) await app.saveDataset(normalizeDataset(ds));
  return { ...rep, parsed };
}
