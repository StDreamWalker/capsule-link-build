// Settings → Debug → Host a server from this PC: a step-by-step guide that turns this computer into a
// Capsule Link home server friends can reach from anywhere. Each step checks itself where it can.
import { h, mount, toast } from '../../../../shared/ui/dom.js';
import { sfx } from '../../../../shared/ui/audio.js';

const ONLINE_KEY = 'capsule-link:online';
const copy = async (text) => { try { await navigator.clipboard.writeText(text); toast('Copied.', 'ok'); } catch { toast(text); } };

export function serverGuide(app) {
  const host = app.platform.host;
  const el = h('section', { class: 'panel col span-all guide' });
  let st = null, step = serverGuide.step ?? 0, reach = null, busy = false;
  const go = (n) => { step = serverGuide.step = Math.max(0, Math.min(STEPS.length - 1, n)); sfx('move'); render(); };
  const act = async (fn, ok) => { busy = true; render(); try { const r = await fn(); if (r?.error) toast(r.error, 'err'); else if (ok) toast(ok, 'ok'); return r; } catch (e) { toast(e.message, 'err'); return null; } finally { busy = false; await refresh(); } };
  async function refresh() { if (host) st = await host.status(); render(); }
  const cfg = () => st?.cfg ?? {};
  const set = (patch, ok) => act(() => host.configure(patch), ok);
  const field = (label, input, hint) => h('label', { class: 'field' }, h('span', null, label), input, hint ? h('span', { class: 'micro faint' }, hint) : null);
  const urlRow = (label, url) => h('div', { class: 'guide-url' }, h('span', { class: 'dim' }, label), h('code', null, url ?? '—'), url ? h('button', { class: 'btn small', onclick: () => copy(url) }, 'Copy') : null);
  const tip = (...t) => h('p', { class: 'guide-tip' }, ...t);
  const list = (items) => h('ol', { class: 'guide-list' }, items.map((x) => h('li', null, x)));

  const STEPS = [
    { title: 'What this does', done: () => true, body: () => [
      h('p', null, 'This turns this PC into a Capsule Link home server. Your friends sign in to it from their own PC app, wherever they are, to add each other, message, send gifts, trade, visit each other’s yards through the Link gate, share creature data, and battle through its relay.'),
      h('p', null, 'An old PC is perfect for this. Install the app on it, sign in (any trainer is fine), and follow these steps once. After that it starts by itself with the computer.'),
      list([
        'The PC needs to be on and connected to the internet while friends use it (it can sit in a corner with the screen off).',
        'Nothing else to install: the server is built into the app.',
        'Everything it keeps (accounts, messages, gifts, shared pictures) stays in a folder on this PC.',
      ]),
      tip('About 10 minutes. The steps that can check themselves get a tick.'),
    ] },
    { title: 'Start the server', done: () => st?.running, body: () => {
      const name = h('input', { type: 'text', value: cfg().name ?? '', placeholder: 'e.g. Kim’s Capsule Server', maxLength: 40 });
      const port = h('input', { type: 'number', value: cfg().port ?? 47830, min: 1024, max: 65535, style: { width: '120px' } });
      return [
        h('p', null, 'Give your server a name and press Start. The port is the "door number" friends connect to; 47830 is fine unless something else on this PC already uses it.'),
        h('div', { class: 'form-grid two' }, field('Server name', name, 'Shown to friends when they connect'), field('Port', port, '1024–65535')),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn', disabled: busy, onclick: () => set({ name: name.value.trim(), port: Number(port.value) }, 'Saved.') }, 'Save'),
          st?.running ? h('button', { class: 'btn danger', disabled: busy, onclick: () => act(() => host.stop(), 'Server stopped.') }, 'Stop the server')
            : h('button', { class: 'btn primary', disabled: busy, onclick: () => act(async () => { await host.configure({ name: name.value.trim(), port: Number(port.value) }); return host.start(); }, 'The server is running!') }, 'Start the server')),
        st?.error ? h('p', { class: 'err-text' }, st.error) : null,
        st?.running ? tip(`Running on port ${st.port}. ${st.trainers} trainer account${st.trainers === 1 ? '' : 's'} so far.`) : null,
      ];
    } },
    { title: 'Let it through the firewall', done: () => st?.platform !== 'win32' || cfg().firewallDone, body: () => [
      h('p', null, 'Windows blocks incoming connections until you allow them. The first time the server starts, Windows may ask on its own: tick both Private and Public networks and press Allow.'),
      st?.platform === 'win32' ? [
        h('p', null, 'If it didn’t ask (or you pressed Cancel), add the rule from here. Windows will ask for permission.'),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn primary', disabled: busy, onclick: () => act(async () => { const r = await host.firewall(); if (r.ok) await host.configure({ firewallDone: true }); return r; }, 'Firewall rule added.') }, 'Allow through Windows Firewall'),
          h('button', { class: 'btn', onclick: () => set({ firewallDone: true }) }, 'Windows already asked and I allowed it')),
      ] : tip('Not on Windows: most Linux and Mac setups don’t block it. If yours has a firewall, allow TCP port ' + (st?.port ?? 47830) + '.'),
    ] },
    { title: 'Check it at home', done: () => st?.running && cfg().lanChecked, body: () => [
      h('p', null, 'First make sure it works on your own Wi-Fi. On a phone or another computer at home, open this address in a web browser:'),
      urlRow('At home', st?.localUrl),
      h('p', null, 'You should see a short line of text starting with {"app":"capsule-link"…. That means the server is reachable at home.'),
      (st?.lan?.length ?? 0) > 1 ? tip(`This PC has more than one network address (${st.lan.join(', ')}). If the first doesn’t work, try the others.`) : null,
      h('button', { class: 'btn', onclick: () => set({ lanChecked: true }, 'Great!') }, 'It worked'),
      tip('Didn’t load? Check the server is running (step 2) and the firewall step. Both devices need to be on the same network (not a guest network).'),
    ] },
    { title: 'Open it to the internet', done: () => st?.upnp?.ok || cfg().manualForward, body: () => [
      h('p', null, 'For friends outside your home, your router has to pass connections on to this PC. This is called port forwarding. The app tries to set it up automatically (UPnP).'),
      h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: cfg().upnp !== false, onchange: (e) => set({ upnp: e.target.checked }) }), 'Set up port forwarding automatically'),
      st?.upnp?.ok ? tip(`Done: your router (${st.upnp.router}) forwards port ${st.port} to this PC (${st.upnp.internal}).`)
        : st?.upnp ? h('p', { class: 'err-text' }, st.upnp.error) : st?.running ? tip('Trying…') : tip('Start the server first (step 2).'),
      st?.cgnat ? h('div', { class: 'guide-warn' }, h('strong', null, 'Your internet provider shares one address between many homes (CGNAT). '), 'Port forwarding can’t work through that. Ask your provider for a "public IPv4 address" (often free), or use a tunnel service such as playit.gg or Tailscale Funnel pointed at port ' + st.port + '.') : null,
      h('div', { class: 'row wrap' }, h('button', { class: 'btn', disabled: busy || !st?.running, onclick: () => act(() => host.forward(), null) }, 'Try again')),
      h('details', { class: 'guide-more' }, h('summary', null, 'If it can’t: forward the port by hand'),
        list([
          `Give this PC a fixed address on your network: in the router’s settings look for "DHCP reservation" or "static lease" and reserve ${st?.lan?.[0] ?? 'this PC’s address'} for it.`,
          'Open your router’s settings page in a browser (usually http://192.168.1.1 or http://192.168.0.1; it’s often printed on the router).',
          'Find "Port forwarding" (sometimes under Advanced, NAT, Firewall, or "Virtual servers").',
          `Add a rule: TCP, external port ${st?.port ?? 47830}, internal port ${st?.port ?? 47830}, to ${st?.lan?.[0] ?? 'this PC'}.`,
          'Save, then come back here.',
        ]),
        h('button', { class: 'btn', onclick: () => set({ manualForward: true }, 'Noted.') }, 'I forwarded it by hand')),
    ] },
    { title: 'An address that doesn’t change', done: () => st?.duck?.ok || cfg().skipDuck, body: () => {
      const dom = h('input', { type: 'text', value: (cfg().duckDomain ?? '').replace(/\.duckdns\.org$/i, ''), placeholder: 'yourname' });
      const tok = h('input', { type: 'password', value: cfg().duckToken ?? '', placeholder: 'token from duckdns.org' });
      return [
        h('p', null, 'Your home’s internet address can change now and then, which would break the address your friends saved. A free DuckDNS name follows it automatically, and gives friends something easy to type.'),
        list([
          h('span', null, 'Go to ', h('a', { href: 'https://www.duckdns.org', target: '_blank' }, 'duckdns.org'), ' and sign in (with Google, GitHub or others).'),
          'Type a name in "sub domain" and press "add domain" (e.g. kims-ranch → kims-ranch.duckdns.org).',
          'Copy the token shown at the top of the page and paste it here with your name.',
        ]),
        h('div', { class: 'form-grid two' }, field('Name', dom, '.duckdns.org'), field('Token', tok)),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn primary', disabled: busy, onclick: () => set({ duckDomain: dom.value.trim(), duckToken: tok.value.trim(), skipDuck: false }, null) }, 'Save and update'),
          h('button', { class: 'btn', onclick: () => set({ skipDuck: true }) }, 'Skip: use the plain address')),
        st?.duck ? (st.duck.ok ? tip(`DuckDNS is pointing ${cfg().duckDomain}.duckdns.org at this home. It keeps it up to date every 10 minutes.`) : h('p', { class: 'err-text' }, st.duck.error)) : null,
      ];
    } },
    { title: 'Keep it running', done: () => cfg().autoStart && cfg().openAtLogin, body: () => [
      h('p', null, 'So the server is there whenever your friends are:'),
      h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!cfg().autoStart, onchange: (e) => set({ autoStart: e.target.checked }) }), 'Start the server whenever the app opens'),
      h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!cfg().openAtLogin, onchange: (e) => set({ openAtLogin: e.target.checked }) }), 'Open the app (in the background) when this computer starts'),
      h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: cfg().keepRunning !== false, onchange: (e) => set({ keepRunning: e.target.checked }) }), 'Closing the window keeps the server running (it waits in the system tray, by the clock)'),
      h('details', { class: 'guide-more', open: true }, h('summary', null, 'Stop the PC from going to sleep'),
        list([
          'Windows 10/11: Settings → System → Power (& battery) → Screen and sleep → "When plugged in, put my device to sleep after": Never. The screen can still turn off.',
          'A laptop: also set "When I close the lid" to Do nothing (Control Panel → Power Options → Choose what closing the lid does).',
          'Optional: Windows Update can restart the PC at night. With the two boxes above ticked, the server comes back by itself after a restart (as long as Windows signs in; set up automatic sign-in if the PC has a password).',
        ])),
    ] },
    { title: 'Invite your friends', done: () => !!reach?.ok, body: () => [
      h('p', null, 'This is the address to send your friends. They put it in Friends → Server, then make an account:'),
      urlRow('From anywhere', st?.publicUrl),
      urlRow('At home', st?.localUrl),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn', disabled: busy || !st?.running, onclick: async () => { busy = true; render(); reach = await host.check(); busy = false; render(); } }, 'Check from the internet'),
        h('button', { class: 'btn primary', disabled: !st?.running, onclick: () => {
          try { const a = JSON.parse(localStorage.getItem(ONLINE_KEY) ?? '{}'); const next = { ...a, server: st.localUrl, token: a.server === st.localUrl ? a.token : null }; localStorage.setItem(ONLINE_KEY, JSON.stringify(next)); app.friendsSession?.setAccount(next); } catch { /* ignore */ }
          app.go('friends');
        } }, 'Make my own account on it')),
      reach ? (reach.ok ? tip('It answered from its internet address. Friends anywhere can connect.') : h('p', { class: 'dim' }, reach.reason)) : null,
      tip('Best real test: on your phone, turn Wi-Fi off (use mobile data) and open the "From anywhere" address in its browser. If you see {"app":"capsule-link"…, you’re done.'),
      tip('You, on this PC, use the "At home" address in Friends; friends outside use the "From anywhere" one.'),
    ] },
    { title: 'Looking after it', done: () => true, body: () => [
      list([
        `Everything lives in ${st?.dataDir ?? 'the app’s data folder'}. Copy that folder somewhere safe now and then: that’s your whole server.`,
        'Passwords are never stored, only scrambled fingerprints of them. Each friend gets a random 12-digit trainer code.',
        'The server only talks plain HTTP. That’s fine among friends; if it grows beyond that, put it behind HTTPS (docs/home-server.md shows a two-line Caddy setup).',
        'To move the server to a new PC: install the app there, copy the data folder over, and run through this guide again.',
        'To stop hosting: Stop the server (step 2) and untick the boxes in step 7.',
      ]),
      st?.log?.length ? h('details', { class: 'guide-more' }, h('summary', null, 'Server log'), h('pre', { class: 'guide-log' }, st.log.slice(-25).join('\n'))) : null,
    ] },
  ];

  function render() {
    if (!host) {
      mount(el, h('h2', null, 'Host a server from this PC'), h('p', { class: 'dim' }, 'This only works in the installed PC app (not the browser preview). The same server can also run from a terminal: node server/home-server.mjs (docs/home-server.md).'));
      return;
    }
    const s = STEPS[step];
    mount(el,
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, 'Host a server from this PC'),
        h('span', { class: `guide-badge ${st?.running ? 'on' : ''}` }, st?.running ? `● Running · port ${st.port}` : '○ Stopped')),
      h('p', { class: 'dim' }, 'Turn this computer into the place your friends connect to, from anywhere. Step by step:'),
      h('div', { class: 'guide-wrap' },
        h('ol', { class: 'guide-steps' }, STEPS.map((x, i) => h('li', null, h('button', { class: `${i === step ? 'on' : ''} ${x.done() ? 'done' : ''}`, onclick: () => go(i) }, h('span', { class: 'guide-num' }, x.done() && i ? '✓' : i + 1), x.title)))),
        h('div', { class: 'guide-body' },
          h('div', { class: 'guide-kicker' }, `Step ${step + 1} of ${STEPS.length}`),
          h('h3', null, s.title),
          s.body(),
          h('div', { class: 'row guide-nav' },
            h('button', { class: 'btn', disabled: step === 0, onclick: () => go(step - 1) }, 'Back'),
            h('span', { class: 'spacer' }),
            step < STEPS.length - 1 ? h('button', { class: 'btn primary', onclick: () => go(step + 1) }, 'Next') : h('button', { class: 'btn primary', onclick: () => go(0) }, 'Back to the start')))));
  }
  host?.onStatus?.((s) => { st = s; if (el.isConnected) render(); });
  refresh();
  return { el, update: () => refresh() };
}
