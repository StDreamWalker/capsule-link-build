import { chooseBall } from '../../../../shared/ui/ballPicker.js';
// Capsule dock: connect the USB dock, manage capsules, and test with virtual capsules.
import { h, mount, toast, promptDialog, chooseDialog, confirmDialog, dialog, fmtNum, timeAgo } from '../../../../shared/ui/dom.js';
import { capsuleCanvas } from '../../../../shared/ui/capsuleArt.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { sfx } from '../../../../shared/ui/audio.js';
import { displayName, speciesOf, list, CAPSULE, parseTagImage } from '../../../../shared/engine/index.js';

const MODE_HELP = {
  desk: 'Sits on your desk. Plays its cry and wiggles now and then.',
  walk: 'Counts steps while you carry it. Friendship grows as you walk.',
  battle: 'Tap it against a friend’s capsule to start a battle on your phones.',
  sleep: 'Quiet. No sounds, no wiggles, lowest power.',
};

export function dockView(app) {
  const ctl = app.dockCtl;
  const el = h('div', { class: 'dockview' });
  const off = ctl.on(() => render());
  const ringFor = (c) => app.idx.types.get(speciesOf(app.idx, c)?.types?.[0])?.color ?? '#34d1bf';

  function connectionPanel() {
    const serial = app.serialDock;
    const usingSerial = app.dock?.kind === 'serial';
    const fw = usingSerial ? serial.info?.fw : null;
    return h('section', { class: 'panel' },
      h('div', { class: 'panel-title' }, h('h2', null, 'Dock connection')),
      usingSerial && serial.status === 'connected'
        ? h('div', { class: 'col' },
          h('p', null, h('span', { class: 'dot on' }), ` USB dock connected${fw ? ` · firmware ${fw}` : ''}${serial.info?.reader ? ` · ${serial.info.reader}` : ''}`),
          h('div', { class: 'row' }, h('button', { class: 'btn', onclick: async () => { await serial.disconnect(); ctl.attach(app.virtualDock); } }, 'Disconnect')))
        : h('div', { class: 'col' },
          h('p', { class: 'dim' }, serial ? 'Plug the dock in by USB, then connect. Until then the virtual dock below works the same way.' : 'USB serial is only available in the desktop app. The virtual dock below works the same way.'),
          serial ? h('div', { class: 'row' }, h('button', { class: 'btn primary', onclick: connectSerial }, 'Connect USB dock')) : null));
  }

  async function connectSerial() {
    try {
      await app.serialDock.connect({ ask: true });
      ctl.attach(app.serialDock);
      app.say('Dock connected. Place a capsule on it.', 'ok');
    } catch (e) {
      if (!/No port selected|cancel/i.test(e.message)) toast(`Could not connect: ${e.message}`, 'err');
    }
  }

  function dockedPanel() {
    const cur = ctl.current;
    if (!cur) {
      return h('section', { class: 'panel docked empty' },
        h('div', { class: 'cradle' }, capsuleCanvas({ lit: false, pose: 'empty', ring: '#2a2848', body: '#7a77a0', glass: 'rgba(255,255,255,0.25)' }, 6)),
        h('div', { class: 'col grow' }, h('h1', null, 'The dock is empty'),
          h('p', { class: 'dim' }, app.dock?.kind === 'virtual' ? 'Pick a virtual capsule below and press Dock to place it.' : 'Place a capsule on the dock. Its creature syncs automatically.')));
    }
    const info = cur.info;
    if (!info) return h('section', { class: 'panel docked' }, h('p', null, cur.error ? `Could not read the capsule: ${cur.error}` : 'Reading capsule…'));
    const cap = app.save.capsules[info.uid] ?? { name: `Tag ${info.uid}` };
    const c = info.state === 'creature' ? app.save.creatures[info.rec.uid] : null;
    const busy = ctl.busy;
    let body;
    if (info.state === 'creature') {
      const name = c ? displayName(app.idx, c) : info.rec.nickname || app.idx.speciesByNo.get(info.rec.speciesNo)?.name || `#${info.rec.speciesNo}`;
      body = h('div', { class: 'col grow' },
        h('div', { class: 'row' }, h('h1', null, name), h('span', { class: 'dim' }, `Lv. ${info.rec.level}`)),
        h('div', { class: 'kv' },
          h('span', null, 'Capsule'), h('span', null, cap.name),
          h('span', null, 'Mode'), h('span', null, info.rec.mode),
          h('span', null, 'Steps since sync'), h('span', null, fmtNum(info.pending)),
          h('span', null, 'Walked together'), h('span', null, `${fmtNum(info.rec.totalSteps)} steps`),
          h('span', null, 'Friendship'), h('span', null, String(info.rec.friendship)),
          info.walk ? [h('span', null, 'Bumps'), h('span', null, String(info.walk.bumpCount)), h('span', null, 'Battery'), h('span', null, info.walk.battery == null ? 'unknown' : `${info.walk.battery}%`)] : null),
        !info.known ? h('p', { class: 'err-text' }, `Species #${info.rec.speciesNo} is not in your Data Lab. Add it to bring this creature in.`) : null,
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn primary', disabled: busy || !info.known, onclick: () => ctl.sync() }, 'Sync steps'),
          h('button', { class: 'btn', disabled: busy || !info.known, onclick: () => ctl.letOut('ranch') }, 'Let out to ranch'),
          h('button', { class: 'btn', disabled: busy || !info.known, onclick: () => ctl.letOut('party') }, 'Let out to party')),
        modeRow(info.rec.mode, busy));
    } else if (info.state === 'empty' || info.state === 'blank') {
      body = h('div', { class: 'col grow' },
        h('h1', null, info.state === 'blank' ? 'A new tag' : `${cap.name} is empty`),
        h('p', { class: 'dim' }, info.state === 'blank' ? 'This tag has never been used. Send a creature to turn it into a capsule.' : 'Choose a creature to carry with you.'),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn primary', disabled: busy, onclick: pickAndSend }, 'Send a creature'),
          info.state === 'empty' ? modeRow(info.mode ?? 'desk', busy) : null));
    } else {
      body = h('div', { class: 'col grow' },
        h('h1', null, info.state === 'foreign' ? 'Not a capsule' : 'Capsule needs repair'),
        h('p', { class: 'dim' }, info.message ?? ''),
        h('div', { class: 'row' }, h('button', { class: 'btn danger', disabled: busy, onclick: async () => {
          if (await confirmDialog('Format this tag?', 'Everything on the tag is replaced with an empty capsule.', { ok: 'Format', danger: true })) ctl.format();
        } }, 'Format as capsule')));
    }
    const simNote = cur.tag.simulated ? h('p', { class: 'note' }, `Simulated capsule on ${cur.tag.phoneName ?? 'a phone'}. Lift it off from the phone’s Debug screen.`) : null;
    if (simNote) body.prepend(simNote);
    return h('section', { class: 'panel docked' },
      h('div', { class: 'cradle' }, capsuleCanvas({ skin: c?.ball, pose: info.state === 'creature' ? 'closed' : 'empty', ring: c ? ringFor(c) : '#34d1bf', creature: c?.speciesId ?? (info.rec ? app.idx.speciesByNo.get(info.rec.speciesNo)?.id : null), bank: app.bank, pulse: busy }, 6),
        h('div', { class: 'micro dim center' }, info.uid)),
      body,
      h('div', { class: 'col', style: { alignSelf: 'flex-start' } },
        h('button', { class: 'btn small', onclick: async () => {
          const name = await promptDialog('Name this capsule', 'Name', cap.name, { maxLength: 16 });
          if (name) app.commit((s) => { s.capsules[info.uid] = { ...(s.capsules[info.uid] || {}), name: name.trim() }; });
        } }, 'Rename'),
        h('button', { class: 'btn small', onclick: () => showRaw() }, 'Raw data')));
  }

  function modeRow(mode, busy) {
    return h('div', { class: 'col' },
      h('div', { class: 'row wrap', role: 'radiogroup', 'aria-label': 'Capsule mode' }, CAPSULE.MODES.map((m) => h('button', {
        class: `btn small ${m === mode ? 'primary' : ''}`, role: 'radio', 'aria-checked': m === mode ? 'true' : 'false', disabled: busy,
        onclick: () => { if (m !== mode) ctl.setMode(m); },
      }, m[0].toUpperCase() + m.slice(1)))),
      h('p', { class: 'dim' }, MODE_HELP[mode] ?? ''));
  }

  async function pickAndSend() {
    const options = list(app.save).filter((c) => ['party', 'box', 'ranch'].includes(c.location.kind));
    const uid = await chooseDialog('Who goes in the capsule?', options.map((c) => ({
      value: c.uid, label: displayName(app.idx, c), detail: `Lv. ${c.level} · ${c.location.kind}`, el: spriteCanvas(app.bank, c.speciesId, { scale: 1 }),
    })), { empty: 'Nobody is free. Return creatures from your phone first.' });
    if (uid) ctl.send(uid, 'walk');
  }

  async function showRaw() {
    const mem = await ctl.current.tag.readUser();
    const lines = [];
    for (let o = 0; o < 232; o += 16) {
      const bytes = Array.from(mem.slice(o, o + 16), (b) => b.toString(16).padStart(2, '0').toUpperCase());
      const tag = o === 32 ? '  MAIN' : o === 160 ? '  WALK' : '';
      lines.push(`${String(o).padStart(3, '0')}  p${String(4 + o / 4).padStart(2, '0')}  ${bytes.join(' ')}${tag}`);
    }
    await dialog('Raw capsule data', (close) => h('div', { class: 'col' },
      h('p', { class: 'dim' }, 'User memory from page 4. MAIN (128 bytes) starts at byte 32, WALK (32 bytes) at byte 160. See docs/protocol.md for every field.'),
      h('pre', { class: 'hexdump' }, lines.join('\n')),
      h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close() }, 'Close'))), { wide: true });
  }

  function capsulesPanel() {
    const caps = Object.entries(app.save.capsules ?? {});
    return h('section', { class: 'panel' },
      h('div', { class: 'panel-title' }, h('h2', null, 'Your capsules'), h('span', { class: 'dim' }, `${caps.length}`)),
      caps.length ? h('div', { class: 'cap-grid' }, caps.map(([tag, cap]) => {
        const c = cap.uid ? app.save.creatures[cap.uid] : null;
        const docked = ctl.current?.info?.uid === tag;
        return h('div', { class: `cap-card ${docked ? 'docked' : ''}` },
          capsuleCanvas({ skin: c?.ball ?? cap?.skin, ring: c ? ringFor(c) : '#2a2848', lit: !!c, creature: c?.speciesId, bank: app.bank }, 3),
          h('div', { class: 'col grow', style: { gap: 0 } },
            h('span', null, cap.name),
            h('span', { class: 'dim' }, c ? `${displayName(app.idx, c)} · ${cap.mode ?? 'desk'}` : 'Empty'),
            h('span', { class: 'micro faint' }, docked ? 'On the dock now' : `Seen ${timeAgo(cap.lastSeen)}`)),
          h('button', { class: 'btn small', title: 'Which capsule picture this one shows when empty', onclick: async () => {
            const t = await chooseBall(cap.skin);
            if (t != null) app.commit((s) => { s.capsules[tag].skin = t; }, 'capsule');
          } }, 'Look'));
      })) : h('p', { class: 'dim' }, 'No capsules yet. Place one on the dock to register it.'));
  }

  function virtualPanel() {
    const vd = app.virtualDock;
    const tags = [...vd.tags.values()];
    const usingVirtual = app.dock === vd;
    return h('section', { class: 'panel' },
      h('div', { class: 'panel-title' }, h('h2', null, 'Virtual capsules'), h('span', { class: 'spacer' }),
        h('button', { class: 'btn small', onclick: () => { const uid = vd.create(); sfx('blip'); app.say(`Made virtual capsule ${uid}.`); render(); } }, 'New virtual capsule')),
      h('p', { class: 'dim' }, usingVirtual ? 'Test every capsule feature without hardware. Walking and bumping here does what the capsule firmware does.' : 'Switch back to the virtual dock to use these (disconnect the USB dock).'),
      tags.length ? h('table', { class: 'grid' },
        h('thead', null, h('tr', null, h('th', null, 'Tag'), h('th', null, 'Holds'), h('th', null, 'Unsynced steps'), h('th', null, ''))),
        h('tbody', null, tags.map((t) => {
          const p = parseTagImage(t.mem);
          const rec = p.main?.ok && !p.main.empty ? p.main.rec : null;
          const pending = rec && p.walk?.ok ? (p.walk.walk.syncId === rec.syncId ? p.walk.walk.steps : Math.max(0, p.walk.walk.steps - rec.walkCounted)) : 0;
          const docked = vd.docked === t.uid;
          return h('tr', { class: docked ? 'sel' : '' },
            h('td', null, app.save.capsules[t.uid]?.name ?? t.uid.slice(-6)),
            h('td', null, rec ? (rec.nickname || app.idx.speciesByNo.get(rec.speciesNo)?.name || `#${rec.speciesNo}`) : h('span', { class: 'faint' }, p.ok || p.blank ? 'Empty' : 'Unreadable')),
            h('td', { class: 'num' }, fmtNum(pending)),
            h('td', null, h('div', { class: 'row' },
              h('button', { class: 'btn small', disabled: !usingVirtual, onclick: () => { if (docked) vd.undock(); else vd.dock(t.uid); } }, docked ? 'Lift off' : 'Dock'),
              h('button', { class: 'btn small', disabled: !rec || docked, title: 'Pretend you walked with it', onclick: () => { vd.walk(t.uid, 1000); render(); } }, '+1,000 steps'),
              h('button', { class: 'btn small', disabled: !rec || docked, onclick: () => { vd.walk(t.uid, 10000); render(); } }, '+10,000'),
              h('button', { class: 'btn small', disabled: !rec || docked, title: 'Pretend it bumped another capsule', onclick: () => { vd.walk(t.uid, 0, { bump: true, peer: 0xbeef }); toast('Bump recorded on the capsule.'); render(); } }, 'Bump'),
              h('button', { class: 'btn small danger', 'aria-label': 'Delete virtual capsule', onclick: async () => {
                if (rec && !(await confirmDialog('Delete virtual capsule?', 'The creature inside stays listed as being in this capsule. Let it out first if you want to keep it.', { ok: 'Delete', danger: true }))) return;
                vd.remove(t.uid); render();
              } }, '×'))));
        }))) : h('p', { class: 'dim' }, 'None yet.'));
  }

  function render() {
    mount(el, h('div', { class: 'dock-top' }, dockedPanel(), connectionPanel()), capsulesPanel(), virtualPanel());
  }
  render();
  return { el, update: render, art: render, dispose: off };
}
