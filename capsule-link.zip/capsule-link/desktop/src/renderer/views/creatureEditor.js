// Debug → edit a creature, field by field, like a save editor: species and form, level and
// experience, identity numbers (PID, encryption constant), shininess, gender, ability, held item,
// temperament, friendship, genes and effort, moves and PP, ball, trainer, size, cry pitch, needs,
// egg steps, memories, likes, and the raw game data kept from an imported file.
import { h, mount, dialog, toast, confirmDialog, promptDialog } from '../../../../shared/ui/dom.js';
import { searchPick } from '../../../../shared/ui/searchPick.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { sfx, creatureCry } from '../../../../shared/ui/audio.js';
import { SIZE_LABELS, sizeVariant } from '../../../../shared/ui/creatureSize.js';
import {
  STAT_KEYS, calcStats, displayName, expForLevel, levelForExp, speciesAbilities, speciesOf, touch, formsOf, setForm,
  HELD, itemInfo, holdable, NEED_KEYS, NEED_LABELS, prefLabel, MAX_CORE, makeEgg,
} from '../../../../shared/engine/index.js';

const STAT_LABEL = { hp: 'HP', atk: 'Atk', def: 'Def', spa: 'SpA', spd: 'SpD', spe: 'Spe' };
const hex8 = (n) => (Number.isFinite(n) ? (n >>> 0).toString(16).toUpperCase().padStart(8, '0') : '');

export function openCreatureEditor(app, uid) {
  const orig = app.save.creatures[uid];
  if (!orig) return Promise.resolve(null);
  // edit a copy; Save puts it back
  const c = JSON.parse(JSON.stringify(orig));
  const box = h('div', { class: 'cre-editor' });
  const idx = app.idx;
  const num = (v, lo, hi) => Math.max(lo, Math.min(hi, Math.round(Number(v) || 0)));
  const field = (label, input, hint) => h('label', { class: 'field' }, h('span', null, label), input, hint ? h('span', { class: 'micro dim' }, hint) : null);

  function render() {
    const sp = speciesOf(idx, c);
    const st = calcStats(idx, c);
    const forms = formsOf(idx, c.speciesId);
    const abilities = speciesAbilities(sp ?? {});
    const maxG = idx.ds.rules.maxGenes ?? 31;
    const maxEPer = idx.ds.rules.maxEffortPerStat ?? 252;
    const moveList = idx.ds.moves.map((m) => ({ value: m.id, label: m.name })).sort((a, b) => a.label.localeCompare(b.label));
    mount(box,
      h('div', { class: 'row', style: { alignItems: 'flex-start', gap: '16px' } },
        h('div', { class: 'col center-items', style: { minWidth: '120px' } }, spriteCanvas(app.bank, c, { scale: 3, animate: true }), h('strong', null, displayName(idx, c)), h('span', { class: 'micro dim mono-num' }, c.uid)),
        h('div', { class: 'grid-form grow' },
          field('Species', searchPick(idx.ds.species.map((s2) => ({ value: s2.id, label: `#${s2.no} ${s2.name}` })), c.speciesId, (v) => { if (!v) return; c.speciesId = v; c.formId = null; const s2 = speciesOf(idx, c); c.exp = Math.max(c.exp ?? 0, expForLevel(idx, s2.growthRate, c.level)); render(); }, { allowNone: false, placeholder: 'Type a name or number…' })),
          forms.length > 1 ? field('Form', h('select', { onchange: (e) => { setForm(idx, c, e.target.value === c.speciesId ? null : e.target.value); render(); } }, forms.map((f) => h('option', { value: f.id, selected: f.id === (c.formId || c.speciesId) }, f.forme)))) : null,
          field('Nickname', h('input', { type: 'text', maxLength: 12, value: c.nickname ?? '', onchange: (e) => { c.nickname = e.target.value.trim(); render(); } })),
          field('Level', h('input', { type: 'number', min: 1, max: idx.ds.rules.maxLevel ?? 100, value: c.level, onchange: (e) => { c.level = num(e.target.value, 1, idx.ds.rules.maxLevel ?? 100); c.exp = expForLevel(idx, sp.growthRate, c.level); render(); } })),
          field('Experience', h('input', { type: 'number', min: 0, value: c.exp ?? 0, onchange: (e) => { c.exp = Math.max(0, Number(e.target.value) || 0); c.level = levelForExp(idx, sp.growthRate, c.exp); render(); } })),
          field('PID', h('input', { type: 'text', class: 'mono-num', maxLength: 8, value: hex8(c.pid), onchange: (e) => { c.pid = parseInt(e.target.value, 16) >>> 0; render(); } }), 'Personality value (hex)'),
          field('Encryption constant', h('input', { type: 'text', class: 'mono-num', maxLength: 8, value: hex8(c.ec), onchange: (e) => { c.ec = parseInt(e.target.value, 16) >>> 0; render(); } })),
          field('Shiny', h('select', { onchange: (e) => { const v = e.target.value; c.shiny = v !== 'no'; c.shinyType = v === 'no' ? undefined : v; render(); } }, [['no', 'No'], ['star', 'Yes (star)'], ['square', 'Yes (square)']].map(([v, l]) => h('option', { value: v, selected: (c.shiny ? (c.shinyType ?? 'star') : 'no') === v }, l)))),
          field('Gender', h('select', { onchange: (e) => { c.gender = e.target.value; } }, [['none', 'None'], ['male', 'Male'], ['female', 'Female']].map(([v, l]) => h('option', { value: v, selected: (c.gender ?? 'none') === v }, l)))),
          field('Ability', h('input', { type: 'text', list: 'ed-abilities', value: c.ability ?? '', onchange: (e) => { c.ability = e.target.value.trim(); } }), abilities.length ? `Usual: ${abilities.join(', ')}` : null),
          h('datalist', { id: 'ed-abilities' }, abilities.map((a) => h('option', { value: a }))),
          field('Held item', searchPick([...HELD, ...idx.ds.items.filter((i) => holdable(i))].map((i) => ({ value: i.id, label: i.name })), c.heldItemId ?? '', (id) => { const it = itemInfo(idx, id); c.heldItemId = id || null; c.heldItem = id ? (it?.showdownName || '') : ''; }, { placeholder: 'Nothing (type to search)' })),
          field('Temperament', searchPick(idx.ds.temperaments.map((t) => ({ value: t.id, label: t.name })), c.temper ?? '', (v) => { c.temper = v || null; render(); }, { placeholder: 'Type a nature…' })),
          field('Friendship', h('input', { type: 'number', min: 0, max: idx.ds.rules.maxFriendship ?? 255, value: c.friendship ?? 0, onchange: (e) => { c.friendship = num(e.target.value, 0, idx.ds.rules.maxFriendship ?? 255); } })),
          field('Ball picture', h('input', { type: 'text', value: c.ball ?? '', onchange: (e) => { c.ball = e.target.value.trim(); } }), 'A number or name from ui/ball-*.png'),
          field('Original trainer', h('input', { type: 'text', maxLength: 12, value: c.trainer ?? '', onchange: (e) => { c.trainer = e.target.value.trim(); } })),
          field('Met at level', h('input', { type: 'number', min: 1, max: 255, value: c.metLevel ?? 1, onchange: (e) => { c.metLevel = num(e.target.value, 1, 255); } })),
          field('How you met', h('input', { type: 'text', maxLength: 80, value: c.metHow ?? '', onchange: (e) => { c.metHow = e.target.value; } })),
          field(`Size (${sizeVariant(c).label})`, h('input', { type: 'range', min: 0, max: 255, value: Number.isFinite(c.sizeScalar) ? c.sizeScalar : 128, onchange: (e) => { c.sizeScalar = num(e.target.value, 0, 255); render(); } }), `${SIZE_LABELS[0]} … ${SIZE_LABELS[SIZE_LABELS.length - 1]}`),
          field(`Cry pitch (${Number.isFinite(c.cryPitch) ? `${c.cryPitch > 0 ? '+' : ''}${c.cryPitch}` : 'own'})`, h('div', { class: 'row' },
            h('input', { type: 'range', min: -6, max: 6, step: 0.5, value: Number.isFinite(c.cryPitch) ? c.cryPitch : 0, onchange: (e) => { c.cryPitch = Number(e.target.value); render(); } }),
            h('button', { class: 'btn small', type: 'button', onclick: () => creatureCry(sp, c) }, 'Hear'),
            h('button', { class: 'btn small ghost', type: 'button', onclick: () => { delete c.cryPitch; render(); } }, 'Own voice')), 'Semitones; every call still varies with mood'))),
      h('div', { class: 'row wrap', style: { gap: '20px', alignItems: 'flex-start' } },
        h('div', { class: 'col' },
          h('h3', null, 'Genes and effort'),
          h('table', { class: 'ed-stats' },
            h('tr', null, h('th'), STAT_KEYS.map((k) => h('th', null, STAT_LABEL[k]))),
            h('tr', null, h('td', { class: 'dim' }, `Genes (0–${maxG})`), STAT_KEYS.map((k) => h('td', null, h('input', { type: 'number', min: 0, max: maxG, value: c.genes?.[k] ?? 0, onchange: (e) => { c.genes[k] = num(e.target.value, 0, maxG); render(); } })))),
            h('tr', null, h('td', { class: 'dim' }, `Effort (0–${maxEPer})`), STAT_KEYS.map((k) => h('td', null, h('input', { type: 'number', min: 0, max: maxEPer, value: c.effort?.[k] ?? 0, onchange: (e) => { c.effort[k] = num(e.target.value, 0, maxEPer); render(); } })))),
            h('tr', null, h('td', { class: 'dim' }, 'Stats'), STAT_KEYS.map((k) => h('td', { class: 'mono-num' }, String(st[k]))))),
          h('div', { class: 'row wrap' },
            h('button', { class: 'btn small', type: 'button', onclick: () => { for (const k of STAT_KEYS) c.genes[k] = maxG; render(); } }, 'Max genes'),
            h('button', { class: 'btn small', type: 'button', onclick: () => { for (const k of STAT_KEYS) c.effort[k] = 0; render(); } }, 'Clear effort'))),
        h('div', { class: 'col' },
          h('h3', null, 'Moves'),
          [0, 1, 2, 3].map((i) => {
            const m = c.moves[i];
            return h('div', { class: 'row' },
              searchPick(moveList, m?.id ?? '', (id) => { if (!id) c.moves.splice(i, 1); else c.moves[i] = { id, pp: idx.moves.get(id)?.pp ?? 10 }; c.moves = c.moves.filter(Boolean); render(); }, { placeholder: 'No move (type to search)' }),
              m ? h('input', { type: 'number', min: 0, max: 64, value: m.pp ?? 0, title: 'PP left', style: { width: '64px' }, onchange: (e) => { m.pp = num(e.target.value, 0, 64); } }) : null,
              m ? h('span', { class: 'micro dim' }, `/ ${idx.moves.get(m.id)?.pp ?? '?'} PP`) : null);
          })),
        h('div', { class: 'col' },
          h('h3', null, 'Needs'),
          NEED_KEYS.map((k) => h('label', { class: 'row' }, h('span', { class: 'dim', style: { minWidth: '80px' } }, NEED_LABELS[k] ?? k), h('input', { type: 'range', min: 0, max: 100, value: c.needs?.[k] ?? 50, onchange: (e) => { c.needs[k] = num(e.target.value, 0, 100); c.needsAt = Date.now(); } }))),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!c.egg, onchange: (e) => { if (e.target.checked) makeEgg(c, 2000); else { delete c.egg; } render(); } }), 'An egg'),
          c.egg ? field('Steps to hatch', h('input', { type: 'number', min: 1, value: c.egg.steps ?? 0, onchange: (e) => { c.egg.steps = Math.max(1, Number(e.target.value) || 1); } })) : null)),
      h('h3', null, `Core memories (${(c.memories ?? []).length} of ${MAX_CORE})`),
      h('div', { class: 'col ed-mem' }, (c.memories ?? []).map((m, i) => h('div', { class: 'row' },
        h('input', { type: 'date', value: new Date(m.t).toISOString().slice(0, 10), onchange: (e) => { const d = new Date(e.target.value); if (!Number.isNaN(d.getTime())) m.t = d.getTime(); } }),
        h('input', { type: 'text', class: 'grow', value: m.text, maxLength: 160, onchange: (e) => { m.text = e.target.value; } }),
        h('button', { class: 'btn small ghost', type: 'button', title: 'Forget', onclick: () => { c.memories.splice(i, 1); render(); } }, '✕'))),
      h('button', { class: 'btn small', type: 'button', onclick: () => { (c.memories = c.memories || []).push({ t: Date.now(), text: 'A new memory.', core: true }); render(); } }, 'Add a memory')),
      h('h3', null, 'Likes and dislikes'),
      h('div', { class: 'row wrap ed-prefs' }, Object.entries(c.prefs ?? {}).sort((a, b) => b[1] - a[1]).map(([k, v]) => h('label', { class: 'pref-chip' }, h('span', null, prefLabel(k, idx)),
        h('input', { type: 'number', min: -10, max: 10, value: Math.round(v), style: { width: '56px' }, onchange: (e) => { c.prefs[k] = num(e.target.value, -10, 10); } }),
        h('button', { class: 'btn small ghost', type: 'button', onclick: () => { delete c.prefs[k]; render(); } }, '✕'))),
        h('button', { class: 'btn small', type: 'button', onclick: async () => { const k = await promptDialog('Add a like', 'What they like, as kind:thing (place:beach, food:bramble-berry, toy:ball, weather:rain, time:night, friend:<uid>)', '', { maxLength: 60, ok: 'Add' }); if (k && k.includes(':')) { c.prefs = { ...(c.prefs || {}), [k.trim()]: 5 }; render(); } } }, 'Add a like')),
      c.pk ? h('details', { class: 'ed-raw' }, h('summary', null, 'Game data kept from the imported file (advanced)'),
        h('textarea', { rows: 10, spellcheck: false, value: JSON.stringify({ ...c.pk, raw: c.pk.raw ? `${String(c.pk.raw).slice(0, 24)}…` : null }, null, 1), onchange: (e) => {
          try { const v = JSON.parse(e.target.value); const raw = c.pk.raw; c.pk = { ...v, raw }; toast('Game data updated (the original file bytes are kept as they were).', 'ok'); } catch (err) { toast(`That isn’t valid JSON: ${err.message}`, 'err'); }
        } })) : null);
  }
  render();
  return dialog(`Edit ${displayName(idx, orig)}`, (close) => h('div', null, box,
    h('div', { class: 'actions' },
      h('button', { class: 'btn', onclick: () => close(null) }, 'Cancel'),
      h('button', { class: 'btn primary', onclick: async () => {
        if (c.speciesId !== orig.speciesId && !(await confirmDialog('Change species?', 'Moves, stats and sprite follow the new species. Memories stay.', { ok: 'Change it' }))) return;
        app.commit((s) => {
          const keepLoc = s.creatures[uid].location;
          c.location = keepLoc;
          c.hp = Math.min(c.hp ?? 9999, calcStats(idx, c).hp);
          touch(c);
          s.creatures[uid] = c;
        }, 'debug-edit');
        sfx('heal');
        close(true);
      } }, 'Save changes'))), { wide: true });
}
