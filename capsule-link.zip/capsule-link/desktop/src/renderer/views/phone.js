// Phone link: pairing code, addresses, and connected phones.
import { h, mount, toast, confirmDialog, timeAgo } from '../../../../shared/ui/dom.js';
import { displayName, list, itemInfo, packSatchel, unpackSatchel, allFoods, isIncense, healingOf } from '../../../../shared/engine/index.js';
import { itemIcon } from '../../../../shared/ui/itemIcon.js';
import { sfx } from '../../../../shared/ui/audio.js';

export function phoneView(app) {
  const el = h('div', { class: 'phoneview' });
  let info = app.hubInfo;
  const off = app.on((what) => { if (what === 'hub') { info = app.hubInfo; render(); } });

  async function refresh() { info = await app.platform.hubInfo(); app.hubInfo = info; render(); }

  function render() {
    if (!app.platform.hasHub) {
      mount(el, h('section', { class: 'panel' }, h('h1', null, 'Phone link'),
        h('p', null, 'The phone app connects to the desktop app over your Wi-Fi. This web preview cannot open a network port, so linking works once you run the desktop app (see the README).')));
      return;
    }
    const ips = info?.ips ?? [];
    const clients = info?.status?.clients ?? [];
    const devices = Object.entries(app.save.devices ?? {});
    const onPhones = list(app.save).filter((c) => c.location.kind === 'phone');
    mount(el,
      h('div', { class: 'phone-top' },
        h('section', { class: 'panel pair' },
          h('h2', null, 'Pair a phone'),
          h('p', { class: 'dim' }, 'In the phone app open Link, tap Find my PC (or type an address below), then enter this code.'),
          h('div', { class: 'pair-code', 'aria-label': `Pairing code ${info?.pairCode}` }, (info?.pairCode ?? '------').split('').map((d) => h('span', null, d))),
          h('div', { class: 'row' }, h('button', { class: 'btn', onclick: async () => { info = await app.platform.newPairCode(); render(); } }, 'New code'))),
        h('section', { class: 'panel' },
          h('h2', null, 'This PC'),
          ips.length ? h('div', { class: 'kv' }, ips.map((a) => [h('span', null, a.name), h('span', { class: 'mono-num' }, `${a.address}:${info.port}`)])) : h('p', { class: 'dim' }, 'No network found. Connect this PC to Wi-Fi or Ethernet.'),
          h('p', { class: 'dim' }, 'The phone must be on the same network. Windows may ask to allow Capsule Link through the firewall; allow it on private networks.'),
          h('button', { class: 'btn small', onclick: refresh }, 'Refresh'))),
      satchelPanel(),
      usbPanel(),
      h('section', { class: 'panel' },
        h('h2', null, 'Connected now'),
        clients.filter((c) => c.kind !== 'pc').length
          ? h('div', { class: 'col' }, clients.filter((c) => c.kind !== 'pc').map((c) => h('div', { class: 'row' }, h('span', { class: 'dot on' }), h('span', { class: 'grow' }, c.name), c.inBattle ? h('span', { class: 'dim' }, 'in a battle') : null)))
          : h('p', { class: 'dim' }, 'No phones connected right now.')),
      h('section', { class: 'panel' },
        h('h2', null, 'Paired phones'),
        devices.length ? h('table', { class: 'grid' }, h('tbody', null, devices.map(([id, d]) => h('tr', null,
          h('td', null, d.name), h('td', { class: 'dim' }, `paired ${new Date(d.pairedAt).toLocaleDateString()}`), h('td', { class: 'dim' }, `seen ${timeAgo(d.lastSeen)}`),
          h('td', null, h('button', { class: 'btn small', onclick: async () => {
            if (!(await confirmDialog('Forget this phone?', `${d.name} will need the pairing code again.`, { ok: 'Forget', danger: true }))) return;
            info = await app.platform.forgetDevice(id); toast('Phone forgotten.'); render();
          } }, 'Forget')))))) : h('p', { class: 'dim' }, 'None yet.')),
      h('section', { class: 'panel' },
        h('h2', null, 'Walking with a phone'),
        onPhones.length ? h('div', { class: 'col' }, onPhones.map((c) => h('div', null, `${displayName(app.idx, c)} — on ${app.save.devices?.[c.location.device]?.name ?? 'a phone'}`)))
          : h('p', { class: 'dim' }, 'Nobody. Take creatures along from the phone app (Party → Take from PC).')),
      h('section', { class: 'panel' },
        h('h2', null, 'Battling friends away from home'),
        h('p', { class: 'dim' }, 'Phones on this network battle through this PC. For friends elsewhere, run the small relay server from the project folder on any machine they can reach (node relay/relay.mjs) and set it as the battle server in the phone app.')));
  }
  // ---------- the satchel: what the phone carries on walks ----------
  function satchelPanel() {
    const sat = Object.entries(app.save.satchel ?? {}).filter(([, n]) => n > 0);
    // what's worth taking: food, medicine and incense (and anything else in the bag, further down)
    const useful = (it) => it && (it.kind === 'food' || isIncense(it) || healingOf(it) || it.kind === 'toy');
    const bag = Object.entries(app.save.inventory ?? {}).filter(([, n]) => n > 0).map(([id, n]) => ({ it: itemInfo(app.idx, id), n })).filter(({ it }) => it && it.kind !== 'blueprint' && !it.unlimited)
      .sort((a, b) => (useful(b.it) ? 1 : 0) - (useful(a.it) ? 1 : 0) || a.it.name.localeCompare(b.it.name));
    const move = (id, n) => { let k = 0; app.commit((sv) => { k = packSatchel(sv, id, n); }, 'satchel', { quiet: true }); if (k) sfx('blip'); render(); };
    const row = (it, n, packed) => h('div', { class: 'sat-row' }, itemIcon(it, 28, { idx: app.idx }), h('span', { class: 'grow' }, it.name), h('span', { class: 'dim' }, `× ${n}`),
      packed ? [h('button', { class: 'btn small', onclick: () => move(it.id, -1) }, 'Take out'), n > 1 ? h('button', { class: 'btn small ghost', onclick: () => move(it.id, -n) }, 'All') : null]
        : [h('button', { class: 'btn small', onclick: () => move(it.id, 1) }, 'Pack 1'), n > 1 ? h('button', { class: 'btn small ghost', onclick: () => move(it.id, Math.min(n, 5)) }, `+${Math.min(n, 5)}`) : null]);
    return h('section', { class: 'panel col sat-panel' },
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, 'Satchel for walks'), sat.length ? h('button', { class: 'btn small', onclick: () => { app.commit((sv) => unpackSatchel(sv), 'satchel', { quiet: true }); render(); } }, 'Unpack everything') : null),
      h('p', { class: 'dim' }, 'Pack what your phone takes along: food to feed them on walks (kibble always comes along), Potions, incense to light. It goes over the next time the phone links up; what they eat or use on the walk comes out of it here too. Things they find on walks come straight home to the bag.'),
      h('div', { class: 'sat-cols' },
        h('div', { class: 'btn-group col' }, h('div', { class: 'btn-group-head' }, `Packed (${sat.reduce((a, [, n]) => a + n, 0)})`),
          sat.length ? sat.map(([id, n]) => row(itemInfo(app.idx, id) ?? { id, name: id }, n, true)) : h('p', { class: 'micro dim' }, 'Nothing yet.')),
        h('div', { class: 'btn-group col' }, h('div', { class: 'btn-group-head' }, 'In the bag'),
          bag.length ? h('div', { class: 'sat-bag' }, bag.map(({ it, n }) => row(it, n, false))) : h('p', { class: 'micro dim' }, 'The bag is empty.'))));
  }
  let usbResult = null;
  function usbPanel() {
    const r = usbResult;
    let status = null;
    if (r?.reason === 'adb') {
      status = h('div', { class: 'col' },
        h('p', { class: 'err-text' }, 'Android’s adb tool was not found on this PC.'),
        h('p', { class: 'dim' }, `Install Android Studio, or download Google’s "SDK Platform-Tools" and put its platform-tools folder in ${r.dataFolder ?? 'the data folder'} (Settings → Open data folder).`));
    } else if (r?.reason === 'nodevice') {
      status = h('p', { class: 'err-text' }, 'No phone found. Check the cable, turn on USB debugging, and allow this PC on the phone.');
    } else if (r?.devices) {
      status = h('div', { class: 'col', style: { gap: '2px' } }, r.devices.map((d) => h('div', { class: 'row' },
        h('span', { class: `dot ${d.linked ? 'on' : ''}` }),
        h('span', { class: 'mono-num' }, d.serial),
        h('span', { class: 'dim' }, d.linked ? 'linked: use ws://127.0.0.1:47820 on the phone' : d.state === 'unauthorized' ? 'tap Allow on the phone, then try again' : d.error || d.state))));
    }
    return h('section', { class: 'panel col' },
      h('h2', null, 'Phone over a USB-C cable'),
      h('p', { class: 'dim' }, 'Works with no Wi-Fi. Turn on USB debugging on the phone (Developer options), plug it in, then set up the link. On the phone use Link → Use USB cable, or Debug → Put on the PC dock for the simulated capsule.'),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn primary', onclick: async (e) => {
          e.target.disabled = true;
          usbResult = await app.platform.usbSetup().catch((err) => ({ ok: false, reason: 'error', message: err.message }));
          if (usbResult?.ok) app.say('Phone linked over USB.', 'ok');
          render();
        } }, 'Set up USB link'),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!app.save.settings.usbAuto, onchange: (e) => {
          const on = e.target.checked;
          app.commit((sv) => { sv.settings.usbAuto = on; }, 'settings', { quiet: true });
          app.keepUsb(on);
        } }), 'Keep linking phones I plug in')),
      status);
  }

  render();
  if (app.platform.hasHub) refresh();
  return { el, update: render, dispose: off };
}
