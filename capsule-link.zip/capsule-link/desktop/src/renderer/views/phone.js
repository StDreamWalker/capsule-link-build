// Phone link: pairing code, addresses, and connected phones.
import { h, mount, toast, confirmDialog, timeAgo } from '../../../../shared/ui/dom.js';
import { displayName, list } from '../../../../shared/engine/index.js';

export function phoneView(app) {
  const el = h('div', { class: 'phoneview' });
  let info = app.hubInfo;
  const off = app.on((what) => { if (what === 'hub') { info = app.hubInfo; render(); } });

  async function refresh() { info = await app.platform.hubInfo(); app.hubInfo = info; render(); }

  function render() {
    if (!app.platform.hasHub) {
      mount(el, h('section', { class: 'panel' }, h('h1', null, 'Phone link'),
        h('p', null, 'The phone app connects to the desktop app over your Wi-Fi. This web preview cannot open a network port, so linking works once you run the desktop app (see the README).')));
      return;
    }
    const ips = info?.ips ?? [];
    const clients = info?.status?.clients ?? [];
    const devices = Object.entries(app.save.devices ?? {});
    const onPhones = list(app.save).filter((c) => c.location.kind === 'phone');
    mount(el,
      h('div', { class: 'phone-top' },
        h('section', { class: 'panel pair' },
          h('h2', null, 'Pair a phone'),
          h('p', { class: 'dim' }, 'In the phone app open Link, tap Find my PC (or type an address below), then enter this code.'),
          h('div', { class: 'pair-code', 'aria-label': `Pairing code ${info?.pairCode}` }, (info?.pairCode ?? '------').split('').map((d) => h('span', null, d))),
          h('div', { class: 'row' }, h('button', { class: 'btn', onclick: async () => { info = await app.platform.newPairCode(); render(); } }, 'New code'))),
        h('section', { class: 'panel' },
          h('h2', null, 'This PC'),
          ips.length ? h('div', { class: 'kv' }, ips.map((a) => [h('span', null, a.name), h('span', { class: 'mono-num' }, `${a.address}:${info.port}`)])) : h('p', { class: 'dim' }, 'No network found. Connect this PC to Wi-Fi or Ethernet.'),
          h('p', { class: 'dim' }, 'The phone must be on the same network. Windows may ask to allow Capsule Link through the firewall; allow it on private networks.'),
          h('button', { class: 'btn small', onclick: refresh }, 'Refresh'))),
      usbPanel(),
      h('section', { class: 'panel' },
        h('h2', null, 'Connected now'),
        clients.filter((c) => c.kind !== 'pc').length
          ? h('div', { class: 'col' }, clients.filter((c) => c.kind !== 'pc').map((c) => h('div', { class: 'row' }, h('span', { class: 'dot on' }), h('span', { class: 'grow' }, c.name), c.inBattle ? h('span', { class: 'dim' }, 'in a battle') : null)))
          : h('p', { class: 'dim' }, 'No phones connected right now.')),
      h('section', { class: 'panel' },
        h('h2', null, 'Paired phones'),
        devices.length ? h('table', { class: 'grid' }, h('tbody', null, devices.map(([id, d]) => h('tr', null,
          h('td', null, d.name), h('td', { class: 'dim' }, `paired ${new Date(d.pairedAt).toLocaleDateString()}`), h('td', { class: 'dim' }, `seen ${timeAgo(d.lastSeen)}`),
          h('td', null, h('button', { class: 'btn small', onclick: async () => {
            if (!(await confirmDialog('Forget this phone?', `${d.name} will need the pairing code again.`, { ok: 'Forget', danger: true }))) return;
            info = await app.platform.forgetDevice(id); toast('Phone forgotten.'); render();
          } }, 'Forget')))))) : h('p', { class: 'dim' }, 'None yet.')),
      h('section', { class: 'panel' },
        h('h2', null, 'Walking with a phone'),
        onPhones.length ? h('div', { class: 'col' }, onPhones.map((c) => h('div', null, `${displayName(app.idx, c)} — on ${app.save.devices?.[c.location.device]?.name ?? 'a phone'}`)))
          : h('p', { class: 'dim' }, 'Nobody. Take creatures along from the phone app (Party → Take from PC).')),
      h('section', { class: 'panel' },
        h('h2', null, 'Battling friends away from home'),
        h('p', { class: 'dim' }, 'Phones on this network battle through this PC. For friends elsewhere, run the small relay server from the project folder on any machine they can reach (node relay/relay.mjs) and set it as the battle server in the phone app.')));
  }
  let usbResult = null;
  function usbPanel() {
    const r = usbResult;
    let status = null;
    if (r?.reason === 'adb') {
      status = h('div', { class: 'col' },
        h('p', { class: 'err-text' }, 'Android’s adb tool was not found on this PC.'),
        h('p', { class: 'dim' }, `Install Android Studio, or download Google’s "SDK Platform-Tools" and put its platform-tools folder in ${r.dataFolder ?? 'the data folder'} (Settings → Open data folder).`));
    } else if (r?.reason === 'nodevice') {
      status = h('p', { class: 'err-text' }, 'No phone found. Check the cable, turn on USB debugging, and allow this PC on the phone.');
    } else if (r?.devices) {
      status = h('div', { class: 'col', style: { gap: '2px' } }, r.devices.map((d) => h('div', { class: 'row' },
        h('span', { class: `dot ${d.linked ? 'on' : ''}` }),
        h('span', { class: 'mono-num' }, d.serial),
        h('span', { class: 'dim' }, d.linked ? 'linked: use ws://127.0.0.1:47820 on the phone' : d.state === 'unauthorized' ? 'tap Allow on the phone, then try again' : d.error || d.state))));
    }
    return h('section', { class: 'panel col' },
      h('h2', null, 'Phone over a USB-C cable'),
      h('p', { class: 'dim' }, 'Works with no Wi-Fi. Turn on USB debugging on the phone (Developer options), plug it in, then set up the link. On the phone use Link → Use USB cable, or Debug → Put on the PC dock for the simulated capsule.'),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn primary', onclick: async (e) => {
          e.target.disabled = true;
          usbResult = await app.platform.usbSetup().catch((err) => ({ ok: false, reason: 'error', message: err.message }));
          if (usbResult?.ok) app.say('Phone linked over USB.', 'ok');
          render();
        } }, 'Set up USB link'),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!app.save.settings.usbAuto, onchange: (e) => {
          const on = e.target.checked;
          app.commit((sv) => { sv.settings.usbAuto = on; }, 'settings', { quiet: true });
          app.keepUsb(on);
        } }), 'Keep linking phones I plug in')),
      status);
  }

  render();
  if (app.platform.hasHub) refresh();
  return { el, update: render, dispose: off };
}
