// Activities: pick something to do and someone to do it with. Each activity is a little game on screen;
// the helper's types, moves, stats and temperament change how it plays (a wider stirring zone for a fire
// creature, fish biting sooner for a water one, sparkles over buried treasure for a digger, pairs shown
// to a psychic one…) and what comes of it (engine: activities.js).
import { h, mount, toast, chooseDialog } from '../../../../shared/ui/dom.js';
import { spriteCanvas, spriteIdOf } from '../../../../shared/ui/art.js';
import { renderBiome } from '../../../../shared/ui/biomes.js';
import { sfx, creatureCry } from '../../../../shared/ui/audio.js';
import {
  ACTIVITIES, activityOf, aptitude, canDo, finishActivity, dishFor, displayName, list, speciesOf, allFoods, itemInfo, mood,
} from '../../../../shared/engine/index.js';

const W = 640, H = 360;
const ACT_TINT = { cooking: '#e0882a', gardening: '#3fb26a', fishing: '#3b8ae0', scavenging: '#a0683a', obstacle: '#e5484d', puzzle: '#8b5cf6', photography: '#ec4899' };
const ACT_SCENE = { cooking: 'outskirts', gardening: 'meadow', fishing: 'shoreline', scavenging: 'desert', obstacle: 'meadow', puzzle: 'crystal', photography: 'forest' };

export function activitiesView(app) {
  const el = h('div', { class: 'activities' });
  let pick = activitiesView.last ?? null; // creature uid
  let running = null;

  const helpers = () => list(app.save).filter((c) => !c.egg && ['party', 'box', 'ranch'].includes(c.location?.kind)).sort((a, b) => (a.location.kind === 'party' ? 0 : 1) - (b.location.kind === 'party' ? 0 : 1) || b.friendship - a.friendship);

  function render() {
    if (running) return;
    const c = pick && app.save.creatures[pick];
    mount(el,
      h('header', { class: 'act-head' },
        h('div', null, h('h1', null, 'Activities'), h('p', { class: 'dim' }, 'Spend time doing things together. Every creature is good at different things.')),
        h('button', { class: 'act-helper', onclick: chooseHelper },
          c ? [spriteCanvas(app.bank, c, { scale: 2, animate: true }), h('span', { class: 'col' }, h('strong', null, displayName(app.idx, c)), h('span', { class: 'micro dim' }, `${mood(c).label} · energy ${Math.round(c.needs?.energy ?? 0)}`))]
            : h('span', null, 'Choose a helper'))),
      h('div', { class: 'act-grid' }, ACTIVITIES.map((a) => {
        const apt = c ? aptitude(app.idx, c, a.id) : null;
        const ok = c ? canDo(app.idx, app.save, c, a.id) : { ok: false };
        return h('button', { class: 'act-card', style: { '--tint': ACT_TINT[a.id] }, disabled: !c, onclick: () => start(a.id) },
          h('div', { class: 'act-card-top' }, h('span', { class: 'act-name' }, a.name), apt ? h('span', { class: 'act-stars', title: 'How good they are at it' }, '★'.repeat(1 + Math.round(apt.score * 4)), h('span', { class: 'dim' }, '★'.repeat(4 - Math.round(apt.score * 4)))) : null),
          h('p', { class: 'micro dim' }, a.desc),
          apt?.perks.length ? h('ul', { class: 'act-perks' }, apt.perks.map((p) => h('li', null, p))) : null,
          c && !ok.ok ? h('p', { class: 'micro err-text' }, ok.reason) : null);
      })),
      !c ? h('p', { class: 'dim' }, 'Choose a helper to see what they’re good at.') : null);
  }

  async function chooseHelper() {
    const uid = await chooseDialog('Who wants to help?', helpers().map((c) => ({ value: c.uid, label: displayName(app.idx, c), detail: `Lv. ${c.level} · ${mood(c).label} · energy ${Math.round(c.needs?.energy ?? 0)}`, el: spriteCanvas(app.bank, c, { scale: 1 }) })), { empty: 'Nobody can help right now.' });
    if (!uid) return;
    pick = activitiesView.last = uid; sfx('move'); render();
  }

  async function start(actId) {
    const c = app.save.creatures[pick];
    const ok = canDo(app.idx, app.save, c, actId);
    if (!ok.ok) { toast(ok.reason, 'err'); return; }
    let extra = {};
    if (actId === 'cooking') {
      const foods = allFoods(app.idx).filter((f) => (app.save.inventory[f.id] ?? 0) > 0 && !f.id.startsWith('dish-'));
      if (foods.length < 1) { toast('You need food in the bag to cook with. Grow berries or buy some at the Market.', 'err'); return; }
      const a = await chooseDialog('First ingredient', foods.map((f) => ({ value: f.id, label: f.name, detail: `× ${app.save.inventory[f.id]}` })));
      if (!a) return;
      const rest = foods.filter((f) => f.id !== a || (app.save.inventory[f.id] ?? 0) > 1);
      const b = rest.length ? await chooseDialog('Second ingredient', rest.map((f) => ({ value: f.id, label: f.name, detail: `× ${app.save.inventory[f.id] - (f.id === a ? 1 : 0)}` }))) : null;
      extra.ingredients = [a, b].filter(Boolean);
      extra.dish = dishFor(app.idx, c, extra.ingredients);
    }
    running = actId;
    activitiesView.lastAct = actId;
    const apt = aptitude(app.idx, c, actId).score;
    const canvas = h('canvas', { class: 'act-canvas', width: W, height: H, tabindex: '0' });
    const hint = h('div', { class: 'act-hint' });
    const stage = h('div', { class: 'act-stage' },
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, `${activityOf(actId).name} with ${displayName(app.idx, c)}`), h('button', { class: 'btn small', onclick: () => stop(null) }, 'Stop')),
      canvas, hint);
    mount(el, stage);
    canvas.focus();
    sfx('access');
    const game = GAMES[actId]({ app, c, apt, canvas, hint, extra, bg: renderBiome(ACT_SCENE[actId], W, H, { seed: 3 }) });
    let raf = 0, last = performance.now();
    const loop = (now) => {
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      try { game.frame(dt); } catch (e) { console.error(e); }
      if (game.done) { stop(game.perf ?? 0); return; }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    function stop(perf) {
      cancelAnimationFrame(raf);
      game.dispose?.();
      running = null;
      if (perf == null) { render(); return; }
      let out;
      app.commit((s) => { out = finishActivity(app.idx, s, c.uid, actId, perf, { ...extra, photo: game.photo ? { scene: ACT_SCENE[actId] } : null }); }, 'activity', { quiet: true });
      if (!out?.ok) { toast(out?.reason ?? 'That didn’t work.', 'err'); render(); return; }
      sfx(out.stars >= 2 ? 'level' : 'heal');
      if (out.stars >= 2) creatureCry(speciesOf(app.idx, c), c, { mood: 'happy' });
      results(out, game);
    }
  }

  function results(out, game) {
    const c = app.save.creatures[pick];
    mount(el, h('div', { class: 'act-results panel' },
      h('div', { class: 'act-res-art' }, spriteCanvas(app.bank, c, { scale: 3, animate: true })),
      h('div', { class: 'col' },
        h('div', { class: 'act-stars big' }, '★'.repeat(out.stars), h('span', { class: 'dim' }, '★'.repeat(3 - out.stars))),
        h('p', null, out.text),
        out.coins ? h('p', null, h('span', { class: 'coin' }), ` +${out.coins} coins`) : null,
        out.items.length ? h('p', null, `Got: ${Object.entries(out.items.reduce((m, id) => ((m[id] = (m[id] ?? 0) + 1), m), {})).map(([id, n]) => `${itemInfo(app.idx, id)?.name ?? id}${n > 1 ? ` ×${n}` : ''}`).join(', ')}`) : null,
        out.firstTime ? h('p', { class: 'micro dim' }, 'A first time together: it went in their journal.') : null,
        game.photo ? h('div', { class: 'col' }, h('img', { class: 'act-photo', src: game.photo, alt: 'Your photo' }), h('a', { class: 'btn small', href: game.photo, download: `${displayName(app.idx, c)}-photo.png` }, 'Save the photo')) : null,
        h('div', { class: 'row' }, h('button', { class: 'btn primary', onclick: () => render() }, 'Done'), h('button', { class: 'btn', onclick: () => start(activitiesView.lastAct) }, 'Again')))));
  }

  render();
  return { el, update: () => { if (!running) render(); } };
}

// ---------- drawing helpers ----------
function drawSprite(ctx, app, c, x, yBottom, size, { frame = 0, anim = 'idle', flip = false } = {}) {
  const e = app.bank.get(spriteIdOf(c));
  const listF = e.frames[anim] ?? e.frames.idle;
  const img = listF[((frame % listF.length) + listF.length) % listF.length];
  ctx.save(); ctx.imageSmoothingEnabled = false;
  if (flip) { ctx.translate(x, 0); ctx.scale(-1, 1); ctx.drawImage(img, -size / 2, yBottom - size, size, size); }
  else ctx.drawImage(img, x - size / 2, yBottom - size, size, size);
  ctx.restore();
}
function text(ctx, s, x, y, { size = 18, color = '#fff', align = 'center' } = {}) {
  ctx.font = `700 ${size}px "Segoe UI", system-ui, sans-serif`; ctx.textAlign = align; ctx.textBaseline = 'middle';
  ctx.fillStyle = 'rgba(10,8,30,.55)'; ctx.fillText(s, x + 1, y + 1); ctx.fillStyle = color; ctx.fillText(s, x, y); ctx.textAlign = 'start';
}
const toLocal = (canvas, e) => { const r = canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) * (W / r.width), y: (e.clientY - r.top) * (H / r.height) }; };

// ---------- the games: each returns { frame(dt), done, perf, dispose } ----------
const GAMES = {
  // stir when the marker is in the zone; the helper's knack widens the zone
  cooking({ app, c, apt, canvas, hint, extra, bg }) {
    const ctx = canvas.getContext('2d');
    const g = { t: 0, round: 0, rounds: 3, hits: 0, pos: 0, dir: 1, speed: 0.9, zone: 0.12 + apt * 0.16, flash: 0, done: false, msg: '' };
    g.center = 0.3 + Math.random() * 0.4;
    const press = () => {
      if (g.done || g.round >= g.rounds) return;
      const off = Math.abs(g.pos - g.center);
      if (off <= g.zone / 2) { g.hits += 1 - off / g.zone; g.msg = off < g.zone / 6 ? 'Perfect!' : 'Nice!'; sfx('heal'); } else { g.msg = 'Oops!'; sfx('miss'); }
      g.flash = 0.6; g.round++; g.speed += 0.35; g.center = 0.2 + Math.random() * 0.6;
      if (g.round >= g.rounds) setTimeout(() => { g.perf = g.hits / g.rounds; g.done = true; }, 700);
    };
    const onDown = () => press();
    const onKey = (e) => { if (e.code === 'Space' || e.key === 'Enter') { e.preventDefault(); press(); } };
    canvas.addEventListener('pointerdown', onDown); canvas.addEventListener('keydown', onKey);
    hint.textContent = `Stir when the marker is in the green (click or press space). Making: ${extra.dish?.name ?? 'something tasty'}.`;
    g.frame = (dt) => {
      g.t += dt; g.flash = Math.max(0, g.flash - dt);
      g.pos += g.dir * g.speed * dt; if (g.pos > 1) { g.pos = 1; g.dir = -1; } if (g.pos < 0) { g.pos = 0; g.dir = 1; }
      ctx.drawImage(bg, 0, 0);
      ctx.fillStyle = 'rgba(20,14,30,.35)'; ctx.fillRect(0, 0, W, H);
      // the pot
      ctx.fillStyle = '#3a3550'; ctx.beginPath(); ctx.ellipse(W / 2, 250, 120, 40, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = extra.dish?.color ?? '#c0306a'; ctx.beginPath(); ctx.ellipse(W / 2, 240, 105, 28, 0, 0, Math.PI * 2); ctx.fill();
      for (let i = 0; i < 6; i++) { const a = g.t * 2 + i; ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.fillRect(W / 2 + Math.cos(a) * 70, 236 + Math.sin(a) * 14, 4, 4); }
      for (let i = 0; i < 4; i++) { ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.fillRect(W / 2 - 40 + i * 26, 190 - ((g.t * 30 + i * 20) % 60), 6, 14); }
      drawSprite(ctx, app, c, 150, 300, 150, { frame: Math.floor(g.t * 6) });
      // the bar
      const bx = 120, bw = 400, by = 40;
      ctx.fillStyle = 'rgba(10,8,30,.7)'; ctx.fillRect(bx - 4, by - 4, bw + 8, 28);
      ctx.fillStyle = '#3fb26a'; ctx.fillRect(bx + (g.center - g.zone / 2) * bw, by, g.zone * bw, 20);
      ctx.fillStyle = '#ffffff'; ctx.fillRect(bx + g.pos * bw - 3, by - 6, 6, 32);
      text(ctx, `Stir ${Math.min(g.round + 1, g.rounds)} of ${g.rounds}`, W / 2, 90, { size: 16 });
      if (g.flash > 0) text(ctx, g.msg, W / 2, 140, { size: 30, color: g.msg === 'Oops!' ? '#ff9a9a' : '#fff6a0' });
    };
    g.dispose = () => { canvas.removeEventListener('pointerdown', onDown); canvas.removeEventListener('keydown', onKey); };
    return g;
  },

  // weeds pop up in the beds; pull them (the helper pulls some too)
  gardening({ app, c, apt, canvas, hint, bg }) {
    const ctx = canvas.getContext('2d');
    const cells = []; for (let r = 0; r < 3; r++) for (let q = 0; q < 5; q++) cells.push({ x: 140 + q * 90, y: 170 + r * 60, weed: 0, pop: 0 });
    const g = { t: 0, len: 14, pulled: 0, spawned: 0, next: 0.4, helperT: 0, done: false };
    const onDown = (e) => {
      const p = toLocal(canvas, e);
      for (const cl of cells) if (cl.weed > 0 && Math.abs(p.x - cl.x) < 36 && Math.abs(p.y - cl.y) < 28) { cl.weed = 0; cl.pop = 0.4; g.pulled++; sfx('blip'); return; }
    };
    canvas.addEventListener('pointerdown', onDown);
    hint.textContent = 'Click the weeds to pull them before they spread. Your helper pulls some too.';
    g.frame = (dt) => {
      g.t += dt; g.next -= dt; g.helperT -= dt;
      if (g.t < g.len && g.next <= 0) { const free = cells.filter((x) => !x.weed); if (free.length) { free[Math.floor(Math.random() * free.length)].weed = 0.01; g.spawned++; } g.next = 0.45 + Math.random() * 0.5; }
      for (const cl of cells) { if (cl.weed > 0) cl.weed = Math.min(1, cl.weed + dt * 0.25); cl.pop = Math.max(0, cl.pop - dt); }
      // the helper wanders over and pulls one now and then (better gardeners, more often)
      if (g.helperT <= 0) { g.helperT = 2.2 - apt * 1.5; const w = cells.filter((x) => x.weed > 0.2); if (w.length) { const cl = w[0]; cl.weed = 0; cl.pop = 0.4; g.pulled++; g.hx = cl.x; } }
      ctx.drawImage(bg, 0, 0);
      for (const cl of cells) {
        ctx.fillStyle = '#6b4423'; ctx.fillRect(cl.x - 38, cl.y - 18, 76, 40); ctx.fillStyle = '#5a3a1c'; ctx.fillRect(cl.x - 38, cl.y + 10, 76, 6);
        ctx.fillStyle = '#3fb26a'; ctx.fillRect(cl.x - 4, cl.y - 6, 8, 10);
        if (cl.weed > 0) { const s = 8 + cl.weed * 26; ctx.fillStyle = '#6a8a2a'; for (let i = -2; i <= 2; i++) ctx.fillRect(cl.x + i * 6 - 2, cl.y + 4 - s * (1 - Math.abs(i) * 0.2), 4, s * (1 - Math.abs(i) * 0.2)); }
        if (cl.pop > 0) text(ctx, '✓', cl.x, cl.y - 30 - (0.4 - cl.pop) * 40, { size: 20, color: '#c8ffb0' });
      }
      drawSprite(ctx, app, c, g.hx ?? 80, 340, 110, { frame: Math.floor(g.t * 6), anim: 'walk' });
      const left = Math.max(0, g.len - g.t);
      text(ctx, `${Math.ceil(left)} s · pulled ${g.pulled}`, W / 2, 30);
      if (g.t >= g.len + 0.8 && !g.done) { const total = g.pulled + cells.filter((x) => x.weed > 0).length; g.perf = total ? g.pulled / total : 1; g.done = true; }
    };
    g.dispose = () => canvas.removeEventListener('pointerdown', onDown);
    return g;
  },

  // wait for the bite, then click in time; water creatures get bites sooner and longer windows
  fishing({ app, c, apt, canvas, hint, bg }) {
    const ctx = canvas.getContext('2d');
    const g = { t: 0, cast: 0, casts: 3, caught: 0, state: 'wait', timer: 1.5 + Math.random() * 3 * (1.2 - apt), window: 0.45 + apt * 0.6, msg: '', msgT: 0, done: false };
    const press = () => {
      if (g.done) return;
      if (g.state === 'bite') { g.caught++; g.msg = 'Got one!'; sfx('level'); next(); }
      else if (g.state === 'wait') { g.msg = 'Too soon…'; sfx('miss'); g.timer += 1; }
      g.msgT = 1;
    };
    const next = () => { g.cast++; if (g.cast >= g.casts) { setTimeout(() => { g.perf = g.caught / g.casts; g.done = true; }, 900); g.state = 'end'; return; } g.state = 'wait'; g.timer = 1.5 + Math.random() * 3 * (1.2 - apt); };
    const onDown = () => press();
    const onKey = (e) => { if (e.code === 'Space' || e.key === 'Enter') { e.preventDefault(); press(); } };
    canvas.addEventListener('pointerdown', onDown); canvas.addEventListener('keydown', onKey);
    hint.textContent = 'Wait for the bobber to dip, then click (or press space) right away!';
    g.frame = (dt) => {
      g.t += dt; g.msgT = Math.max(0, g.msgT - dt);
      if (g.state === 'wait') { g.timer -= dt; if (g.timer <= 0) { g.state = 'bite'; g.timer = g.window; sfx('alert'); } }
      else if (g.state === 'bite') { g.timer -= dt; if (g.timer <= 0) { g.msg = 'It got away!'; g.msgT = 1; sfx('back'); next(); } }
      ctx.drawImage(bg, 0, 0);
      ctx.fillStyle = 'rgba(40,110,200,.35)'; ctx.fillRect(0, 200, W, H - 200);
      const bx = 420, by = 240 + Math.sin(g.t * 2) * 3 + (g.state === 'bite' ? 10 : 0);
      ctx.strokeStyle = 'rgba(255,255,255,.8)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(200, 120); ctx.quadraticCurveTo(320, 140, bx, by - 8); ctx.stroke();
      ctx.fillStyle = '#e5484d'; ctx.fillRect(bx - 6, by - 10, 12, 8); ctx.fillStyle = '#fff'; ctx.fillRect(bx - 6, by - 2, 12, 6);
      if (g.state === 'bite') { ctx.strokeStyle = 'rgba(255,255,255,.7)'; for (let r = 10; r < 40; r += 12) { ctx.beginPath(); ctx.ellipse(bx, by + 4, r + (g.t * 30) % 12, (r + (g.t * 30) % 12) / 3, 0, 0, Math.PI * 2); ctx.stroke(); } text(ctx, '!', bx, by - 40, { size: 40, color: '#ffd23f' }); }
      drawSprite(ctx, app, c, 160, 230, 130, { frame: Math.floor(g.t * 3) });
      text(ctx, `Cast ${Math.min(g.cast + 1, g.casts)} of ${g.casts} · caught ${g.caught}`, W / 2, 30);
      if (g.msgT > 0) text(ctx, g.msg, W / 2, 90, { size: 26, color: '#fff6a0' });
    };
    g.dispose = () => { canvas.removeEventListener('pointerdown', onDown); canvas.removeEventListener('keydown', onKey); };
    return g;
  },

  // three digs on a grid; a good nose makes the treasure spots sparkle
  scavenging({ app, c, apt, canvas, hint, bg }) {
    const ctx = canvas.getContext('2d');
    const tiles = []; for (let r = 0; r < 3; r++) for (let q = 0; q < 4; q++) tiles.push({ x: 170 + q * 100, y: 140 + r * 70, gem: false, dug: false });
    const gems = new Set(); while (gems.size < 4) gems.add(Math.floor(Math.random() * tiles.length));
    for (const i of gems) tiles[i].gem = true;
    const sniffed = tiles.filter((t) => t.gem && Math.random() < 0.25 + apt * 0.7);
    const g = { t: 0, digs: 3, found: 0, done: false };
    const onDown = (e) => {
      if (g.digs <= 0) return;
      const p = toLocal(canvas, e);
      const tl = tiles.find((t) => !t.dug && Math.abs(p.x - t.x) < 44 && Math.abs(p.y - t.y) < 30);
      if (!tl) return;
      tl.dug = true; g.digs--; if (tl.gem) { g.found++; sfx('level'); } else sfx('miss');
      if (g.digs <= 0) setTimeout(() => { g.perf = g.found / 3; g.done = true; }, 900);
    };
    canvas.addEventListener('pointerdown', onDown);
    hint.textContent = 'You get three digs. Watch your helper’s nose: sparkles mean something’s buried there.';
    g.frame = (dt) => {
      g.t += dt;
      ctx.drawImage(bg, 0, 0);
      for (const tl of tiles) {
        ctx.fillStyle = tl.dug ? '#5a3a1c' : '#c9a06a'; ctx.fillRect(tl.x - 44, tl.y - 28, 88, 56);
        ctx.fillStyle = tl.dug ? '#3a2410' : '#b58a54'; ctx.fillRect(tl.x - 44, tl.y + 20, 88, 8);
        if (tl.dug && tl.gem) { ctx.fillStyle = '#ffd23f'; ctx.beginPath(); ctx.arc(tl.x, tl.y, 10, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#fff'; ctx.fillRect(tl.x - 4, tl.y - 5, 3, 3); }
        if (!tl.dug && sniffed.includes(tl) && Math.sin(g.t * 5 + tl.x) > 0.3) { ctx.fillStyle = '#fff6a0'; ctx.fillRect(tl.x - 12, tl.y - 22, 3, 9); ctx.fillRect(tl.x - 16, tl.y - 19, 11, 3); }
      }
      drawSprite(ctx, app, c, 80, 330, 120, { frame: Math.floor(g.t * 4) });
      text(ctx, `Digs left: ${g.digs} · found ${g.found}`, W / 2, 30);
    };
    g.dispose = () => canvas.removeEventListener('pointerdown', onDown);
    return g;
  },

  // hop the hurdles: click or space to jump; fast and flying helpers jump longer
  obstacle({ app, c, apt, canvas, hint, bg }) {
    const ctx = canvas.getContext('2d');
    const flies = /flying|gale/i.test((speciesOf(app.idx, c)?.types ?? []).map((t) => `${t} ${app.idx.types.get(t)?.name}`).join(' '));
    const g = { t: 0, y: 0, vy: 0, cleared: 0, hit: 0, total: 10, hurdles: [], next: 1.2, speed: 220 + apt * 60, done: false, flash: 0 };
    const jump = () => { if (g.y <= 0.01) { g.vy = 560 + apt * 120; sfx('blip'); } };
    const onDown = () => jump();
    const onKey = (e) => { if (e.code === 'Space' || e.key === 'ArrowUp') { e.preventDefault(); jump(); } };
    canvas.addEventListener('pointerdown', onDown); canvas.addEventListener('keydown', onKey);
    hint.textContent = `Click or press space to jump the hurdles.${flies ? ' Your helper flies, so it clears them more easily.' : ''}`;
    g.frame = (dt) => {
      g.t += dt; g.flash = Math.max(0, g.flash - dt);
      g.next -= dt;
      if (g.next <= 0 && g.hurdles.length + g.cleared + g.hit < g.total) { g.hurdles.push({ x: W + 20, h: 30 + Math.random() * 25, done: false }); g.next = 1 + Math.random() * 0.9; }
      g.vy -= 1500 * dt * (flies ? 0.7 : 1); g.y = Math.max(0, g.y + g.vy * dt); if (g.y === 0) g.vy = 0;
      for (const hd of g.hurdles) {
        hd.x -= g.speed * dt;
        if (!hd.done && hd.x < 150 && hd.x > 110) { if (g.y < hd.h - 4) { hd.done = true; g.hit++; g.flash = 0.4; sfx('miss'); } }
        if (!hd.done && hd.x < 110) { hd.done = true; g.cleared++; }
      }
      g.hurdles = g.hurdles.filter((hd) => hd.x > -30);
      ctx.drawImage(bg, -((g.t * 40) % 40), 0);
      ctx.fillStyle = '#7a5232'; ctx.fillRect(0, 300, W, 60); ctx.fillStyle = '#5a3a1c'; for (let x = -((g.t * g.speed) % 40); x < W; x += 40) ctx.fillRect(x, 300, 20, 6);
      for (const hd of g.hurdles) { ctx.fillStyle = '#ffffff'; ctx.fillRect(hd.x - 3, 300 - hd.h, 6, hd.h); ctx.fillStyle = '#e5484d'; ctx.fillRect(hd.x - 16, 300 - hd.h, 32, 8); }
      if (!(g.flash > 0 && Math.sin(g.t * 40) > 0)) drawSprite(ctx, app, c, 130, 302 - g.y, 90, { frame: Math.floor(g.t * 10), anim: 'walk' });
      text(ctx, `Cleared ${g.cleared} · bumped ${g.hit}`, W / 2, 30);
      if (g.cleared + g.hit >= g.total && !g.done) { g.perf = g.cleared / g.total; g.done = true; }
    };
    g.dispose = () => { canvas.removeEventListener('pointerdown', onDown); canvas.removeEventListener('keydown', onKey); };
    return g;
  },

  // pairs: match them within the flips; a psychic helper shows a pair or two at the start
  puzzle({ app, c, apt, canvas, hint, bg }) {
    const ctx = canvas.getContext('2d');
    const syms = ['◆', '●', '▲', '★', '♥', '♣'];
    const cols = ['#e5484d', '#3b8ae0', '#3fb26a', '#ffd23f', '#ff7ab0', '#8b5cf6'];
    const deck = [...syms.keys(), ...syms.keys()].sort(() => Math.random() - 0.5).map((k, i) => ({ k, i, x: 140 + (i % 4) * 120, y: 90 + Math.floor(i / 4) * 95, open: false, done: false }));
    const g = { t: 0, flips: 16, pairs: 0, sel: [], lock: 0, peek: apt > 0.45 ? 1.4 + apt : 0, done: false };
    if (g.peek) { const a = deck[0].k; for (const d of deck) if (d.k === a || (apt > 0.7 && d.k === deck[1].k)) d.peekable = true; }
    const onDown = (e) => {
      if (g.lock > 0 || g.peek > 0 || g.flips <= 0) return;
      const p = toLocal(canvas, e);
      const d = deck.find((q) => !q.open && !q.done && Math.abs(p.x - q.x) < 48 && Math.abs(p.y - q.y) < 38);
      if (!d) return;
      d.open = true; g.sel.push(d); sfx('move');
      if (g.sel.length === 2) {
        g.flips--;
        const [a, b] = g.sel;
        if (a.k === b.k) { a.done = b.done = true; g.pairs++; sfx('heal'); g.sel = []; }
        else { g.lock = 0.8; }
        if (g.pairs === syms.length || g.flips <= 0) setTimeout(() => { g.perf = g.pairs / syms.length; g.done = true; }, 800);
      }
    };
    canvas.addEventListener('pointerdown', onDown);
    hint.textContent = apt > 0.45 ? 'Your helper is concentrating… it shows you where some pairs are. Then match them all!' : 'Match all the pairs before you run out of flips.';
    g.frame = (dt) => {
      g.t += dt; g.peek = Math.max(0, g.peek - dt);
      if (g.lock > 0) { g.lock -= dt; if (g.lock <= 0) { for (const d of g.sel) d.open = false; g.sel = []; } }
      ctx.drawImage(bg, 0, 0); ctx.fillStyle = 'rgba(20,10,40,.35)'; ctx.fillRect(0, 0, W, H);
      for (const d of deck) {
        const show = d.open || d.done || (g.peek > 0 && d.peekable);
        ctx.fillStyle = d.done ? 'rgba(255,255,255,.35)' : show ? '#fdf8ea' : '#5b45c4'; ctx.fillRect(d.x - 44, d.y - 36, 88, 72);
        ctx.strokeStyle = '#2a2448'; ctx.lineWidth = 2; ctx.strokeRect(d.x - 44, d.y - 36, 88, 72);
        if (show) text(ctx, syms[d.k], d.x, d.y, { size: 34, color: cols[d.k] });
      }
      drawSprite(ctx, app, c, 60, 350, 100, { frame: Math.floor(g.t * 3) });
      if (g.peek > 0) text(ctx, '…!', 60, 240, { size: 22, color: '#d9c2ff' });
      text(ctx, `Pairs ${g.pairs}/${syms.length} · flips left ${g.flips}`, W / 2, 20, { size: 16 });
    };
    g.dispose = () => canvas.removeEventListener('pointerdown', onDown);
    return g;
  },

  // snap them mid-pose: three shots, the best one counts (and you keep the picture)
  photography({ app, c, apt, canvas, hint, bg }) {
    const ctx = canvas.getContext('2d');
    const g = { t: 0, shots: 3, best: 0, flash: 0, pose: 0, next: 1 + Math.random() * 2, x: W / 2, dir: 1, done: false, photo: null, msg: '', msgT: 0 };
    const shoot = () => {
      if (g.shots <= 0) return;
      g.shots--; g.flash = 0.35; sfx('dock');
      const q = g.pose > 0 ? Math.min(1, 0.55 + g.pose * 0.5 + apt * 0.2) : 0.15 + apt * 0.15;
      if (q >= g.best) { g.best = q; g.wantPhoto = true; }
      g.msg = g.pose > 0 ? 'Great pose!' : 'Blurry…'; g.msgT = 0.9;
      if (g.shots <= 0) setTimeout(() => { g.perf = g.best; g.done = true; }, 900);
    };
    const onDown = () => shoot();
    const onKey = (e) => { if (e.code === 'Space') { e.preventDefault(); shoot(); } };
    canvas.addEventListener('pointerdown', onDown); canvas.addEventListener('keydown', onKey);
    hint.textContent = 'Click (or press space) to take a picture when they strike a pose. Three shots: the best one counts.';
    g.frame = (dt) => {
      g.t += dt; g.flash = Math.max(0, g.flash - dt); g.msgT = Math.max(0, g.msgT - dt);
      g.next -= dt;
      if (g.pose > 0) g.pose = Math.max(0, g.pose - dt * (1.6 - apt * 0.8));
      else if (g.next <= 0) { g.pose = 1; g.next = 1.5 + Math.random() * 2.5; }
      if (g.pose <= 0) { g.x += g.dir * 70 * dt; if (g.x > W - 120) g.dir = -1; if (g.x < 120) g.dir = 1; }
      ctx.drawImage(bg, 0, 0);
      const posing = g.pose > 0;
      drawSprite(ctx, app, c, g.x, 320 - (posing ? Math.sin(g.pose * Math.PI) * 30 : 0), 170, { frame: Math.floor(g.t * (posing ? 6 : 8)), anim: posing ? 'happy' : 'walk', flip: g.dir < 0 && !posing });
      if (posing) { ctx.fillStyle = '#fff6a0'; for (let i = 0; i < 5; i++) { const a = g.t * 3 + i * 1.26; ctx.fillRect(g.x + Math.cos(a) * 90, 220 + Math.sin(a) * 60, 4, 4); } }
      if (g.wantPhoto) { g.wantPhoto = false; const pc = document.createElement('canvas'); pc.width = W; pc.height = H; pc.getContext('2d').drawImage(canvas, 0, 0); g.photo = pc.toDataURL('image/png'); }
      // the viewfinder
      ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 3;
      for (const [x, y, dx, dy] of [[30, 30, 1, 1], [W - 30, 30, -1, 1], [30, H - 30, 1, -1], [W - 30, H - 30, -1, -1]]) { ctx.beginPath(); ctx.moveTo(x, y + dy * 30); ctx.lineTo(x, y); ctx.lineTo(x + dx * 30, y); ctx.stroke(); }
      text(ctx, `Shots left: ${g.shots}`, W - 90, 56, { size: 15 });
      if (g.msgT > 0) text(ctx, g.msg, W / 2, 60, { size: 24, color: '#fff6a0' });
      if (g.flash > 0) { ctx.fillStyle = `rgba(255,255,255,${(g.flash * 2.4).toFixed(2)})`; ctx.fillRect(0, 0, W, H); }
    };
    g.dispose = () => { canvas.removeEventListener('pointerdown', onDown); canvas.removeEventListener('keydown', onKey); };
    return g;
  },
};
