// Activities: pick something to do and someone to do it with. Each activity is a little game on screen;
// the helper's types, moves, stats and temperament change how it plays (a wider stirring zone for a fire
// creature, fish biting sooner for a water one, sparkles over buried treasure for a digger, pairs shown
// to a psychic one…) and what comes of it (engine: activities.js).
import { h, mount, toast, chooseDialog } from '../../../../shared/ui/dom.js';
import { spriteCanvas, spriteIdOf } from '../../../../shared/ui/art.js';
import { runActivity } from '../../../../shared/ui/activityGames.js';
import { clothesImg } from './dressUp.js';
import { sfx, creatureCry } from '../../../../shared/ui/audio.js';
import {
  ACTIVITIES, activityOf, aptitude, canDo, finishActivity, dishFor, displayName, list, speciesOf, allFoods, itemInfo, mood,
} from '../../../../shared/engine/index.js';

const ACT_TINT = { cooking: '#e0882a', gardening: '#3fb26a', fishing: '#3b8ae0', scavenging: '#a0683a', obstacle: '#e5484d', puzzle: '#8b5cf6', training: '#d0583a', photography: '#ec4899' };

export function activitiesView(app) {
  const el = h('div', { class: 'activities' });
  let pick = activitiesView.last ?? null; // creature uid
  let running = null;
  let session = null;

  const helpers = () => list(app.save).filter((c) => !c.egg && ['party', 'box', 'ranch'].includes(c.location?.kind)).sort((a, b) => (a.location.kind === 'party' ? 0 : 1) - (b.location.kind === 'party' ? 0 : 1) || b.friendship - a.friendship);

  function render() {
    if (running) return;
    const c = pick && app.save.creatures[pick];
    mount(el,
      h('header', { class: 'act-head' },
        h('div', null, h('h1', null, 'Activities'), h('p', { class: 'dim' }, 'Spend time doing things together. Every creature is good at different things.')),
        h('button', { class: 'act-helper', onclick: chooseHelper },
          c ? [spriteCanvas(app.bank, c, { scale: 2, animate: true }), h('span', { class: 'col' }, h('strong', null, displayName(app.idx, c)), h('span', { class: 'micro dim' }, `${mood(c).label} · energy ${Math.round(c.needs?.energy ?? 0)}`))]
            : h('span', null, 'Choose a helper'))),
      h('div', { class: 'act-grid' }, ACTIVITIES.map((a) => {
        const apt = c ? aptitude(app.idx, c, a.id) : null;
        const ok = c ? canDo(app.idx, app.save, c, a.id) : { ok: false };
        return h('button', { class: 'act-card', style: { '--tint': ACT_TINT[a.id] }, disabled: !c, onclick: () => start(a.id) },
          h('div', { class: 'act-card-top' }, h('span', { class: 'act-name' }, a.name), apt ? h('span', { class: 'act-stars', title: 'How good they are at it' }, '★'.repeat(1 + Math.round(apt.score * 4)), h('span', { class: 'dim' }, '★'.repeat(4 - Math.round(apt.score * 4)))) : null),
          h('p', { class: 'micro dim' }, a.desc),
          apt?.perks.length ? h('ul', { class: 'act-perks' }, apt.perks.map((p) => h('li', null, p))) : null,
          c && !ok.ok ? h('p', { class: 'micro err-text' }, ok.reason) : null);
      })),
      !c ? h('p', { class: 'dim' }, 'Choose a helper to see what they’re good at.') : null);
  }

  async function chooseHelper() {
    const uid = await chooseDialog('Who wants to help?', helpers().map((c) => ({ value: c.uid, label: displayName(app.idx, c), detail: `Lv. ${c.level} · ${mood(c).label} · energy ${Math.round(c.needs?.energy ?? 0)}`, el: spriteCanvas(app.bank, c, { scale: 1 }) })), { empty: 'Nobody can help right now.' });
    if (!uid) return;
    pick = activitiesView.last = uid; sfx('move'); render();
  }

  async function start(actId) {
    const c = app.save.creatures[pick];
    const ok = canDo(app.idx, app.save, c, actId);
    if (!ok.ok) { toast(ok.reason, 'err'); return; }
    let extra = {};
    if (actId === 'cooking') {
      const foods = allFoods(app.idx).filter((f) => (app.save.inventory[f.id] ?? 0) > 0 && !f.id.startsWith('dish-'));
      if (foods.length < 1) { toast('You need food in the bag to cook with. Grow berries or buy some at the Market.', 'err'); return; }
      const a = await chooseDialog('First ingredient', foods.map((f) => ({ value: f.id, label: f.name, detail: `× ${app.save.inventory[f.id]}` })));
      if (!a) return;
      const rest = foods.filter((f) => f.id !== a || (app.save.inventory[f.id] ?? 0) > 1);
      const b = rest.length ? await chooseDialog('Second ingredient', rest.map((f) => ({ value: f.id, label: f.name, detail: `× ${app.save.inventory[f.id] - (f.id === a ? 1 : 0)}` }))) : null;
      extra.ingredients = [a, b].filter(Boolean);
      extra.dish = dishFor(app.idx, c, extra.ingredients);
    }
    running = actId;
    activitiesView.lastAct = actId;
    const apt = aptitude(app.idx, c, actId).score;
    const holder = h('div', { class: 'act-holder' });
    const stage = h('div', { class: 'act-stage' },
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, `${activityOf(actId).name} with ${displayName(app.idx, c)}`), h('button', { class: 'btn small', onclick: () => stop(null) }, 'Stop')),
      holder);
    mount(el, stage);
    sfx('access');
    // the game runs in the same 2.5D world as the R.A.N.C.H. (shared/ui/activityGames.js)
    // one place at a time: while they're busy here they step off the desktop (and out of the R.A.N.C.H.)
    app.busy = app.busy ?? new Set(); app.busy.add(c.uid); app.platform.petBusy?.(c.uid, true);
    const resolveTexture = (p) => app.textures?.[p.toLowerCase()] ?? null;
    session = runActivity(holder, { bank: app.bank, idx: app.idx, c, actId, apt, extra, clothesImg, resolveTexture, onDone: (perf, info) => stop(perf, info) });
    function stop(perf, info = {}) {
      session?.stop(); session = null;
      running = null;
      app.busy?.delete(c.uid); app.platform.petBusy?.(c.uid, false);
      if (perf == null) { render(); return; }
      let out;
      app.commit((s) => { out = finishActivity(app.idx, s, c.uid, actId, perf, { ...extra, moves: info.moves ?? undefined, photo: info.photo ? { scene: actId } : null }); }, 'activity', { quiet: true });
      if (!out?.ok) { toast(out?.reason ?? 'That didn’t work.', 'err'); render(); return; }
      sfx(out.stars >= 2 ? 'level' : 'heal');
      if (out.stars >= 2) creatureCry(speciesOf(app.idx, c), c, { mood: 'happy' });
      results(out, info);
    }
  }

  function results(out, game) {
    const c = app.save.creatures[pick];
    mount(el, h('div', { class: 'act-results panel' },
      h('div', { class: 'act-res-art' }, spriteCanvas(app.bank, c, { scale: 3, animate: true })),
      h('div', { class: 'col' },
        h('div', { class: 'act-stars big' }, '★'.repeat(out.stars), h('span', { class: 'dim' }, '★'.repeat(3 - out.stars))),
        h('p', null, out.text),
        out.coins ? h('p', null, h('span', { class: 'coin' }), ` +${out.coins} coins`) : null,
        out.items.length ? h('p', null, `Got: ${Object.entries(out.items.reduce((m, id) => ((m[id] = (m[id] ?? 0) + 1), m), {})).map(([id, n]) => `${itemInfo(app.idx, id)?.name ?? id}${n > 1 ? ` ×${n}` : ''}`).join(', ')}`) : null,
        out.firstTime ? h('p', { class: 'micro dim' }, 'A first time together: it went in their journal.') : null,
        game.photo ? h('div', { class: 'col' }, h('img', { class: 'act-photo', src: game.photo, alt: 'Your photo' }), h('a', { class: 'btn small', href: game.photo, download: `${displayName(app.idx, c)}-photo.png` }, 'Save the photo')) : null,
        h('div', { class: 'row' }, h('button', { class: 'btn primary', onclick: () => render() }, 'Done'), h('button', { class: 'btn', onclick: () => start(activitiesView.lastAct) }, 'Again')))));
  }

  render();
  // leaving the app stops whatever game is running
  return { el, update: () => { if (!running) render(); }, dispose() { session?.stop(); session = null; running = null; for (const uid of app.busy ?? []) app.platform.petBusy?.(uid, false); app.busy?.clear(); } };
}

