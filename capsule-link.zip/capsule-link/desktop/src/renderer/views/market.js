// The Market: an app of its own. Today's stock (changes every day), your bag (sell what you don't
// need, give things to hold), and blueprints for building up the R.A.N.C.H.
// Items aren't split by use: a berry can be eaten, planted or held; an incense held in battle or lit on
// a walk. Each item's description lists every way to use it.
import { itemIcon } from '../../../../shared/ui/itemIcon.js';
import { h, mount, toast, chooseDialog } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { sfx } from '../../../../shared/ui/audio.js';
import * as Paint from '../../../../shared/ui/paint.js';
import { buildArt } from '../../../../shared/ui/buildArt.js';
import { toyKindOf } from '../../../../shared/ui/yard.js';
import {
  shopStock, buy, wallet, itemInfo, shopResetIn, itemDesc, itemUses, sellPrice, sell, holdable, displayName, list,
  BLUEPRINTS, BLUEPRINT_KINDS, buyBlueprint, bpId, blueprintOf,
} from '../../../../shared/engine/index.js';
import { clothesImg } from './dressUp.js';

const fmtLeft = (ms) => { const m = Math.ceil(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`; };
const USE_LABEL = { feed: 'Eat', plant: 'Plant', hold: 'Hold', light: 'Light on a walk', wear: 'Wear', toy: 'Play', groom: 'Groom', build: 'Build', sell: 'Sell' };
const BAG_GROUPS = [
  ['Food and berries', (it) => it.kind === 'food'],
  ['Evolution items', (it) => !!it.evo],
  ['Gear', (it) => it.kind === 'held' || it.kind === 'incense'],
  ['Clothes', (it) => it.kind === 'clothes'],
  ['Valuables', (it) => it.kind === 'valuable'],
  ['Blueprints', (it) => it.kind === 'blueprint'],
  ['Other', () => true],
];

/** A little picture for an item. */
export function itemPic(app, it, size = 32) {
  if (it.kind === 'clothes') {
    const c = clothesImg(app.idx, it.id);
    if (c) { const cv = document.createElement('canvas'); const k = Math.max(1, Math.floor(size / Math.max(c.width, c.height))); cv.width = c.width * k; cv.height = c.height * k; const x = cv.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(c, 0, 0, cv.width, cv.height); cv.className = 'mk-pic'; return cv; }
  }
  if (it.kind === 'toy') { const cv = Paint.toy(toyKindOf(it), { w: size, h: size }); cv.className = 'mk-pic'; return cv; }
  if (it.kind === 'blueprint') {
    const b = blueprintOf(it.bp ?? it.id);
    const art = b?.art?.[0] && buildArt(b.art[0], app.save.trainer?.card?.accent);
    if (art) { const cv = document.createElement('canvas'); cv.width = size; cv.height = size; const x = cv.getContext('2d'); x.imageSmoothingEnabled = false; const k = Math.min(size / art.img.width, size / art.img.height); x.drawImage(art.img, (size - art.img.width * k) / 2, size - art.img.height * k, art.img.width * k, art.img.height * k); cv.className = 'mk-pic'; return cv; }
    return h('span', { class: 'mk-pic mk-bp' }, '▦');
  }
  // the downloaded item sprite, or a drawn one that looks like the thing (berry, TM disc, gem, bag…)
  const cv = itemIcon(it, size, { idx: app.idx }); cv.classList.add('mk-pic'); return cv;
}

export function marketView(app) {
  let tab = marketView.tab ?? 'shop';
  const el = h('div', { class: 'market' });
  const coins = () => wallet(app.save);

  function head() {
    return h('header', { class: 'mk-head' },
      h('div', null, h('h1', null, 'Market'), h('p', { class: 'dim' }, 'Fresh stock every day. Sell what you find on walks; buy blueprints to build up the R.A.N.C.H.')),
      h('div', { class: 'mk-wallet' }, h('span', { class: 'coin' }), h('strong', null, `${coins()}`), h('span', { class: 'dim' }, ' coins')));
  }
  function tabs() {
    return h('div', { class: 'tabs', role: 'tablist' }, [['shop', 'Today’s stock'], ['bag', 'Bag'], ['blueprints', 'Blueprints']].map(([id, label]) =>
      h('button', { role: 'tab', 'aria-selected': String(tab === id), onclick: () => { tab = marketView.tab = id; sfx('move'); render(); } }, label)));
  }

  function useChips(it) {
    return h('span', { class: 'mk-uses' }, itemUses(it).filter((u) => u !== 'sell').map((u) => h('span', { class: 'mk-chip' }, USE_LABEL[u])));
  }

  function shopTab() {
    const stock = shopStock(app.idx, app.save);
    const sections = [...new Set(stock.lines.map((l) => l.section))];
    return [
      h('p', { class: 'dim' }, `New stock in ${fmtLeft(shopResetIn())}. Coins come from walking (1 for every 25 steps), finds on walks, selling, and battles.`),
      sections.map((sec) => h('section', { class: 'panel mk-section' },
        h('h2', null, sec),
        h('div', { class: 'mk-list' }, stock.lines.filter((l) => l.section === sec).map((l) => {
          const it = l.item;
          return h('div', { class: 'mk-row' },
            itemPic(app, it),
            h('div', { class: 'mk-main' }, h('div', { class: 'row' }, h('strong', null, it.name), useChips(it)), h('p', { class: 'micro dim' }, itemDesc(it))),
            h('span', { class: 'dim micro' }, l.left ? `${l.left} left` : 'Sold out'),
            h('button', { class: 'btn small primary', disabled: !l.left || coins() < l.price, onclick: () => {
              let r; app.commit((s) => { r = buy(app.idx, s, l.id); }, 'shop', { quiet: true });
              if (!r?.ok) { toast(r?.reason ?? 'Could not buy that.', 'err'); return; }
              sfx('level'); toast(`Bought ${it.name}.`, 'ok'); render();
            } }, h('span', { class: 'coin small' }), ` ${l.price}`));
        })))),
    ];
  }

  async function giveToHold(it) {
    const folk = list(app.save).filter((c) => !c.egg && ['party', 'box', 'ranch'].includes(c.location?.kind));
    const uid = await chooseDialog(`Who should hold the ${it.name}?`, folk.map((c) => ({ value: c.uid, label: displayName(app.idx, c), detail: c.heldItemId ? `holding ${itemInfo(app.idx, c.heldItemId)?.name ?? 'something'}` : `Lv. ${c.level}`, el: spriteCanvas(app.bank, c, { scale: 1 }) })), { empty: 'Nobody to give it to.' });
    if (!uid) return;
    app.commit((s) => {
      const x = s.creatures[uid];
      if (x.heldItemId) s.inventory[x.heldItemId] = (s.inventory[x.heldItemId] ?? 0) + 1;
      s.inventory[it.id] = Math.max(0, (s.inventory[it.id] ?? 0) - 1);
      x.heldItemId = it.id; x.heldItem = it.showdownName || '';
    }, 'held');
    sfx('access'); toast(`${displayName(app.idx, app.save.creatures[uid])} is holding the ${it.name}.`, 'ok'); render();
  }

  function bagTab() {
    const inv = Object.entries(app.save.inventory ?? {}).filter(([, n]) => n > 0).map(([id, n]) => ({ it: itemInfo(app.idx, id) ?? { id, name: id, kind: 'other' }, n }));
    if (!inv.length) return h('p', { class: 'dim' }, 'Your bag is empty. Walks turn up coins, berries and shiny things to sell.');
    const used = new Set();
    const groups = BAG_GROUPS.map(([label, test]) => {
      const items = inv.filter((x) => !used.has(x.it.id) && test(x.it));
      items.forEach((x) => used.add(x.it.id));
      return [label, items];
    }).filter(([, items]) => items.length);
    const total = inv.reduce((a, x) => a + (x.it.kind === 'valuable' ? sellPrice(x.it) * x.n : 0), 0);
    return [
      total ? h('div', { class: 'row mk-sellall' }, h('span', { class: 'grow' }, `Valuables in the bag are worth ${total} coins.`), h('button', { class: 'btn small primary', onclick: () => {
        let got = 0; app.commit((s) => { for (const x of inv) if (x.it.kind === 'valuable') { const r = sell(app.idx, s, x.it.id, x.n); if (r.ok) got += r.coins; } }, 'sell', { quiet: true });
        sfx('level'); toast(`Sold your valuables for ${got} coins.`, 'ok'); render();
      } }, 'Sell all valuables')) : null,
      groups.map(([label, items]) => h('section', { class: 'panel mk-section' },
        h('h2', null, label),
        h('div', { class: 'mk-list' }, items.map(({ it, n }) => {
          const price = sellPrice(it);
          return h('div', { class: 'mk-row' },
            itemPic(app, it),
            h('div', { class: 'mk-main' }, h('div', { class: 'row' }, h('strong', null, it.name), h('span', { class: 'dim' }, `× ${n}`), useChips(it)), h('p', { class: 'micro dim' }, itemDesc(it))),
            h('div', { class: 'row wrap mk-actions' },
              holdable(it) ? h('button', { class: 'btn small', onclick: () => giveToHold(it) }, 'Give to hold') : null,
              it.kind === 'blueprint' ? h('button', { class: 'btn small', onclick: () => { app.ranchBuild = true; app.go('ranch'); } }, 'Build it') : null,
              price ? h('button', { class: 'btn small', title: `The market pays ${price} each`, onclick: () => {
                let r; app.commit((s) => { r = sell(app.idx, s, it.id, 1); }, 'sell', { quiet: true });
                if (!r?.ok) { toast(r?.reason ?? 'Couldn’t sell that.', 'err'); return; }
                sfx('blip'); render();
              } }, 'Sell ', h('span', { class: 'coin small' }), ` ${price}`) : null));
        })))),
    ];
  }

  function blueprintsTab() {
    const kinds = Object.keys(BLUEPRINT_KINDS);
    return [
      h('p', { class: 'dim' }, 'Buy a blueprint, then build it in a yard: open the R.A.N.C.H. and press Build. Creatures have their own feelings about what you build; the yard report shows who thrives.'),
      kinds.map((k) => {
        const bps = BLUEPRINTS.filter((b) => b.kind === k);
        if (!bps.length) return null;
        return h('section', { class: 'panel mk-section' },
          h('h2', null, BLUEPRINT_KINDS[k]),
          h('div', { class: 'mk-bp-grid' }, bps.map((b) => {
            const owned = app.save.inventory?.[bpId(b.id)] ?? 0;
            const it = { kind: 'blueprint', bp: b.id };
            return h('div', { class: `mk-bp ${b.kind === 'link' ? 'big' : ''}` },
              h('div', { class: 'mk-bp-art' }, itemPic(app, it, b.kind === 'link' ? 96 : 64)),
              h('strong', null, b.name),
              h('p', { class: 'micro dim' }, b.desc),
              b.tags?.length ? h('span', { class: 'mk-uses' }, b.tags.map((t) => h('span', { class: 'mk-chip' }, t))) : null,
              h('div', { class: 'row' }, h('span', { class: 'dim micro grow' }, owned ? `${owned} in the bag` : ''),
                h('button', { class: 'btn small primary', disabled: coins() < b.price, onclick: () => {
                  let r; app.commit((s) => { r = buyBlueprint(s, b.id); }, 'shop', { quiet: true });
                  if (!r?.ok) { toast(r?.reason ?? 'Couldn’t buy that.', 'err'); return; }
                  sfx('level'); toast(`Bought the ${b.name} blueprint. Build it from the R.A.N.C.H.`, 'ok'); render();
                } }, h('span', { class: 'coin small' }), ` ${b.price}`)));
          })));
      }),
    ];
  }

  function render() {
    mount(el, head(), tabs(), h('div', { class: 'mk-body' }, tab === 'shop' ? shopTab() : tab === 'bag' ? bagTab() : blueprintsTab()));
  }
  render();
  return { el, update: render };
}
