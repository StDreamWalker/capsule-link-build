// Dress up: put clothes from the bag anywhere on a creature. Pick a piece, click where it goes,
// drag it to move it, make it bigger or smaller. They grow to like the clothes you give them.
import { h, mount, dialog, toast } from '../../../../shared/ui/dom.js';
import { spriteBox } from '../../../../shared/ui/creatureSize.js';
import { spriteIdOf } from '../../../../shared/ui/art.js';
import { sfx } from '../../../../shared/ui/audio.js';
import * as Paint from '../../../../shared/ui/paint.js';
import { displayName, itemInfo, spareClothes, wear, unwear, applyCare, wornAt, formsOf } from '../../../../shared/engine/index.js';

/** The picture for a clothing item (null if it isn't clothing). */
export function clothesImg(idx, id) {
  const it = itemInfo(idx, id);
  return it?.kind === 'clothes' ? Paint.clothes(it.art ?? 'star', it.color ?? '#e5484d') : null;
}

const STAGE = 288;

export function openDressUp(app, uid) {
  const c = () => app.save.creatures[uid];
  let pending = null, chosen = null, drag = null, pendingSize = 1;
  // which form you're placing things for (each form's sprite is a different shape)
  let form = c().formId || c().speciesId;
  const forms = () => { const l = formsOf(app.idx, c().speciesId) ?? []; return l.length > 1 ? l.map((f) => ({ id: f.id, name: f.forme })) : []; };
  const placeOf = (wr) => wornAt(wr, form);
  const canvas = h('canvas', { class: 'dress-stage', width: STAGE, height: STAGE });
  const side = h('div', { class: 'dress-side col' });
  let raf = 0, t = 0;

  function geom() {
    const e = app.bank.get(spriteIdOf({ ...c(), formId: form === c().speciesId ? null : form }));
    const img = e.frames.idle[0];
    const k = Math.max(1, Math.floor((STAGE - 40) / Math.max(img.width, img.height)));
    const w = img.width * k, hh = img.height * k;
    const ox = Math.round((STAGE - w) / 2), oy = Math.round(STAGE - 16 - hh);
    const box = spriteBox(e);
    return { e, img, w, hh, ox, oy, box, bw: (box.right - box.left) * w, bh: (box.bottom - box.top) * hh };
  }
  function wornRect(g, wr) {
    const pic = clothesImg(app.idx, wr.id);
    if (!pic) return null;
    const pl = placeOf(wr);
    const k = Math.max(0.5, (g.bw * 0.3 * (pl.s ?? 1)) / pic.width);
    const cw = Math.round(pic.width * k), ch = Math.round(pic.height * k);
    const x = Math.round(g.ox + g.box.left * g.w + pl.fx * g.bw - cw / 2), y = Math.round(g.oy + g.box.top * g.hh + pl.fy * g.bh - ch / 2);
    return { pic, x, y, cw, ch };
  }
  function draw() {
    t += 1 / 60;
    const x = canvas.getContext('2d');
    x.imageSmoothingEnabled = false;
    const grd = x.createLinearGradient(0, 0, 0, STAGE);
    grd.addColorStop(0, '#2a2560'); grd.addColorStop(1, '#16132e');
    x.fillStyle = grd; x.fillRect(0, 0, STAGE, STAGE);
    x.fillStyle = 'rgba(125,255,207,.12)'; x.beginPath(); x.ellipse(STAGE / 2, STAGE - 16, STAGE * 0.32, 10, 0, 0, Math.PI * 2); x.fill();
    const g = geom();
    x.drawImage(g.img, g.ox, g.oy, g.w, g.hh);
    for (const wr of c().clothes ?? []) {
      const r = wornRect(g, wr);
      if (!r) continue;
      x.drawImage(r.pic, r.x, r.y, r.cw, r.ch);
      if (chosen === wr.id) { x.strokeStyle = Math.sin(t * 6) > 0 ? '#7dffcf' : '#ffffff'; x.lineWidth = 2; x.strokeRect(r.x - 3, r.y - 3, r.cw + 6, r.ch + 6); }
    }
    if (pending && hoverAt) {
      const pic = clothesImg(app.idx, pending);
      const k = Math.max(0.5, (g.bw * 0.3 * pendingSize) / pic.width);
      x.globalAlpha = 0.65; x.drawImage(pic, Math.round(hoverAt.x - (pic.width * k) / 2), Math.round(hoverAt.y - (pic.height * k) / 2), pic.width * k, pic.height * k); x.globalAlpha = 1;
    }
    raf = requestAnimationFrame(draw);
  }
  let hoverAt = null;
  const local = (e) => { const r = canvas.getBoundingClientRect(); return { x: ((e.clientX - r.left) / r.width) * STAGE, y: ((e.clientY - r.top) / r.height) * STAGE }; };
  const toFrac = (g, p) => ({ fx: (p.x - g.ox - g.box.left * g.w) / g.bw, fy: (p.y - g.oy - g.box.top * g.hh) / g.bh });

  function put(id, fx, fy, s, fresh) {
    let r;
    app.commit((save) => {
      r = wear(save, uid, id, fx, fy, s, form);
      if (r.ok && fresh) applyCare(app.idx, save.creatures[uid], 'dress', { item: id });
    }, 'dress', { quiet: true });
    if (!r?.ok) toast(r?.reason ?? 'Could not put that on.', 'err');
    else if (fresh) sfx('heal');
    return r?.ok;
  }

  canvas.addEventListener('pointermove', (e) => {
    const p = local(e);
    hoverAt = p;
    if (drag) {
      const g = geom(), f = toFrac(g, { x: p.x - drag.dx, y: p.y - drag.dy });
      const wr = (c().clothes ?? []).find((w) => w.id === drag.id);
      if (wr) drag.place = { ...placeOf(wr), fx: Math.max(0, Math.min(1, f.fx)), fy: Math.max(0, Math.min(1, f.fy)) };
      if (wr && drag.place) { if (form !== c().speciesId) wr.at = { ...(wr.at ?? {}), [form]: drag.place }; else Object.assign(wr, drag.place); }
    }
  });
  // the mouse wheel resizes what you picked (or what you're about to put on)
  canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    const d = e.deltaY > 0 ? -0.1 : 0.1;
    if (pending) { pendingSize = Math.max(0.3, Math.min(3, pendingSize + d)); render(); return; }
    const sel = (c().clothes ?? []).find((w) => w.id === chosen);
    if (sel) { const pl = placeOf(sel); put(sel.id, pl.fx, pl.fy, Math.max(0.3, Math.min(3, (pl.s ?? 1) + d)), false); render(); }
  }, { passive: false });
  canvas.addEventListener('pointerleave', () => { hoverAt = null; });
  canvas.addEventListener('pointerdown', (e) => {
    const p = local(e), g = geom();
    if (pending) { const f = toFrac(g, p); if (put(pending, f.fx, f.fy, pendingSize, true)) { chosen = pending; pending = null; pendingSize = 1; render(); } return; }
    // grab a piece they're wearing (topmost first)
    const worn = [...(c().clothes ?? [])].reverse();
    for (const wr of worn) {
      const r = wornRect(g, wr);
      if (r && p.x >= r.x && p.x <= r.x + r.cw && p.y >= r.y && p.y <= r.y + r.ch) {
        chosen = wr.id; drag = { id: wr.id, dx: p.x - (r.x + r.cw / 2), dy: p.y - (r.y + r.ch / 2) };
        canvas.setPointerCapture?.(e.pointerId);
        render();
        return;
      }
    }
    chosen = null; render();
  });
  const drop = () => {
    if (!drag) return;
    const wr = (c().clothes ?? []).find((w) => w.id === drag.id);
    drag = null;
    if (wr) { const pl = placeOf(wr); put(wr.id, pl.fx, pl.fy, pl.s, false); }
  };
  canvas.addEventListener('pointerup', drop);
  canvas.addEventListener('pointercancel', drop);

  const sizeSlider = (v, set) => {
    const out = h('span', { class: 'dim', style: { minWidth: '44px' } }, `${Math.round(v * 100)}%`);
    return h('label', { class: 'row grow', style: { gap: '8px', alignItems: 'center' } },
      h('input', { type: 'range', min: '0.3', max: '3', step: '0.05', value: String(v), class: 'grow', 'aria-label': 'Size', oninput: (e) => { const n = Number(e.target.value); out.textContent = `${Math.round(n * 100)}%`; set(n); }, onchange: () => render() }), out);
  };
  const feeling = (id) => { const v = c().prefs?.[`clothes:${id}`] ?? 0; return v >= 5 ? 'Loves it' : v >= 2 ? 'Likes it' : v <= -3 ? 'Not keen' : ''; };
  function render() {
    const spare = spareClothes(app.idx, app.save).filter((x) => x.spare > 0 && !(c().clothes ?? []).some((w) => w.id === x.item.id));
    const worn = c().clothes ?? [];
    const icon = (id) => { const pic = clothesImg(app.idx, id); const cv = document.createElement('canvas'); const k = Math.max(1, Math.floor(28 / Math.max(pic.width, pic.height))); cv.width = pic.width * k; cv.height = pic.height * k; const x = cv.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(pic, 0, 0, cv.width, cv.height); cv.className = 'shop-pic'; return cv; };
    const sel = worn.find((w) => w.id === chosen);
    const fl = forms();
    mount(side,
      fl.length ? h('div', { class: 'btn-group' },
        h('div', { class: 'btn-group-head' }, 'Placing for'),
        fl.map((f) => h('button', { class: `btn small ${form === f.id ? 'primary' : ''}`, onclick: () => { form = f.id; render(); } }, f.name)),
        h('p', { class: 'micro dim', style: { margin: 0 } }, 'Forms are different shapes: move and size things for each one. A form you haven’t set uses the first placement.')) : null,
      h('h2', null, 'Wearing'),
      worn.length ? h('div', { class: 'col' }, worn.map((w) => h('button', { class: `btn ${chosen === w.id ? 'primary' : ''}`, style: { justifyContent: 'flex-start' }, onclick: () => { chosen = w.id; pending = null; render(); } },
        icon(w.id), h('span', { class: 'grow', style: { textAlign: 'left' } }, itemInfo(app.idx, w.id)?.name ?? w.id), h('span', { class: 'dim' }, feeling(w.id)))))
        : h('p', { class: 'dim' }, 'Nothing yet.'),
      sel ? h('div', { class: 'btn-group' },
        h('div', { class: 'btn-group-head' }, `Size${forms().length ? ` (for this form)` : ''}`),
        sizeSlider(placeOf(sel).s ?? 1, (v) => { const pl = placeOf(sel); put(sel.id, pl.fx, pl.fy, v, false); }),
        h('button', { class: 'btn small danger', onclick: () => { app.commit((s) => unwear(s, uid, sel.id), 'dress', { quiet: true }); chosen = null; sfx('back'); render(); } }, 'Take off')) : null,
      pending ? h('div', { class: 'btn-group' }, h('div', { class: 'btn-group-head' }, 'Size to put it on at'), sizeSlider(pendingSize, (v) => { pendingSize = v; })) : null,
      h('h2', null, 'In the bag'),
      spare.length ? h('div', { class: 'col' }, spare.map(({ item }) => h('button', { class: `btn ${pending === item.id ? 'primary' : ''}`, style: { justifyContent: 'flex-start' }, onclick: () => { pending = pending === item.id ? null : item.id; chosen = null; render(); } },
        icon(item.id), h('span', { class: 'grow', style: { textAlign: 'left' } }, item.name), h('span', { class: 'dim' }, feeling(item.id)))))
        : h('p', { class: 'dim' }, 'No spare clothes. The shop sells a few each day.'),
      h('p', { class: 'micro dim' }, pending ? 'Click on them to put it on. Scroll to size it first.' : 'Pick something to put on. Drag what they’re wearing to move it; scroll over it to resize.'));
  }

  render();
  raf = requestAnimationFrame(draw);
  return dialog(`Dress up ${displayName(app.idx, c())}`, (close) => h('div', { class: 'dress-up' },
    h('div', { class: 'row', style: { alignItems: 'flex-start', gap: '16px', flexWrap: 'wrap' } }, canvas, side),
    h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: () => close(true) }, 'Done'))), { wide: true }).then((v) => { cancelAnimationFrame(raf); return v; });
}
