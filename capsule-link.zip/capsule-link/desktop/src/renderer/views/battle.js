// Battle: battles are played on Showdown. This screen sends your party there, pairs you with a phone by
// battle code, invites friends from your friends server to a battle (whoever accepts gets the challenge),
// lets you change your team's moves and held items within what they could really know (moves learned by
// levelling, TMs you own), and turns finished battles into experience in-house.
import { h, mount, toast, dialog, chooseDialog, confirmDialog } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { searchPick } from '../../../../shared/ui/searchPick.js';
import { sfx } from '../../../../shared/ui/audio.js';
import { teamPanel, resultPanel, historyPanel, showdownSettingsPanel, showdownSettings, prepareTeam } from '../../../../shared/ui/showdownUi.js';
import { party, MSG, toId, displayName, moveChoices, setMoves, holdable, itemInfo, rollWild, wildTeams, wildOutcome, applyWildResult, condition, healingOf, useMedicine, battleBag, healParty, findFamousTrainer, famousTeam, createCreature } from '../../../../shared/engine/index.js';
import { loadShowdown, playWildBattle } from '../../../../shared/ui/showdownWild.js';
import { BATTLE_PLACES, battlePlace } from '../../../../shared/ui/battleStage.js';
import { BIOME_IDS, BIOME_INFO } from '../../../../shared/ui/biomes.js';
import { hpBar } from '../../../../shared/ui/dom.js';
import { friendsSession, ago } from '../friendsSession.js';
import { joinBerryBlender } from '../../../../shared/ui/berryBlender.js';

/** Open Showdown with your party (config: { action: 'challenge' | 'accept', opponent, format }). */
export async function openShowdown(app, config = {}) {
  const s = showdownSettings(app.save);
  const team = prepareTeam(app.sdCtx());
  if (!team.sets.length) { toast('Add creatures to your party first.', 'err'); return false; }
  if (!app.platform.canEmbedShowdown) { window.open(s.server, '_blank', 'noopener'); return true; } // the web preview: a link
  await app.platform.openShowdown(s.server, { ...config, packed: team.packed, format: config.format || s.format });
  app.say(config.action === 'challenge' ? `Showdown is open. Challenging ${config.opponent}…` : config.action === 'accept' ? `Showdown is open. Accepting ${config.opponent}’s challenge…` : 'Showdown is open. Your team is ready in the Capsule team panel there.');
  return true;
}

/** App-wide: friends' battle invites and replies arrive wherever you are. */
export function watchFriendBattles(app) {
  const S = friendsSession(app);
  S.on((n) => {
    if (n.what === 'battle') {
      sfx('alert');
      toast(`${n.from} wants to battle! Open Battle Link to accept.`, 'ok');
      S.refreshBattles().catch(() => {});
    } else if (n.what === 'battle-reply') {
      if (!n.accept) { toast(`${n.from} can’t battle right now.`, 'err'); return; }
      // they accepted: you send the challenge, with your team
      sfx('access');
      openShowdown(app, { action: 'challenge', opponent: n.showdown, format: n.format });
    } else if (n.what === 'battle-cancel') S.refreshBattles().catch(() => {});
    else if (n.what === 'room' && n.kind === 'blender') {
      sfx('alert');
      const who = S.friends?.friends?.find((f) => f.username === n.from)?.trainerName ?? n.from;
      confirmDialog('Berry Blender', `${who} invited you to blend berries into Pokéblocks! Bring one creature and one berry.`, { ok: 'Join', cancel: 'Not now' })
        .then((yes) => { if (yes) joinBerryBlender(app, S, n.id); });
    }
  });
}

export function battleView(app) {
  const el = h('div', { class: 'battleview sd' });
  let waiting = null;
  let result = null;
  const S = friendsSession(app);
  const offs = [app.on((what) => { if (what === 'battle-result') { result = app.lastResult; render(); } }), S.on((n) => { if (['battles', 'refresh', 'online', 'offline'].includes(n.what)) render(); })];
  if (S.signedIn()) { S.refresh().then(() => S.refreshBattles()).catch(() => {}); }

  async function host(code) {
    const s = showdownSettings(app.save);
    if (!toId(s.name)) { toast('Enter your Showdown name first.', 'err'); return; }
    try {
      const client = await app.hubClient();
      const off = client.on(MSG.MATCHED, (m) => {
        off(); waiting = null; render();
        app.say(`Matched with ${m.opponent.name} (${m.opponent.showdown} on Showdown).`, 'ok');
        openShowdown(app, { action: m.role, opponent: m.opponent.showdown, format: m.format });
      });
      offs.push(off);
      const w = await client.request(MSG.FIND, { mode: 'code', code: code || undefined, name: app.save.trainer?.name ?? 'PC', showdown: s.name, format: s.format, server: s.server }, MSG.WAITING).catch((e) => {
        if (/did not answer/.test(e.message)) return null; // matched straight away
        throw e;
      });
      if (w) { waiting = w.code; render(); }
    } catch (e) { toast(e.message, 'err'); }
  }

  // ---------- battle a friend (friends server) ----------
  async function invite(f) {
    const s = showdownSettings(app.save);
    if (!toId(s.name)) { toast('Enter your Showdown name first (Showdown settings, on the right).', 'err'); return; }
    if (!party(app.save).length) { toast('Add creatures to your party first.', 'err'); return; }
    try { await S.client.inviteBattle(f.username, s.name, s.format); sfx('access'); toast(`Invite sent to ${f.trainerName}. When they accept, Showdown opens and you challenge them.`, 'ok'); await S.refreshBattles(); }
    catch (e) { toast(e.message, 'err'); }
  }
  async function answer(inv, yes) {
    const s = showdownSettings(app.save);
    if (yes && !toId(s.name)) { toast('Enter your Showdown name first (Showdown settings, on the right).', 'err'); return; }
    try {
      await S.client.respondBattle(inv.id, yes, s.name);
      await S.refreshBattles();
      if (yes) openShowdown(app, { action: 'accept', opponent: inv.showdown, format: inv.format });
    } catch (e) { toast(e.message, 'err'); }
  }
  function friendPanel() {
    if (!S.signedIn()) {
      return h('section', { class: 'panel col bl-friends' },
        h('h2', null, 'Battle a friend'),
        h('p', { class: 'dim' }, 'Sign in to a friends server in the Friends app, and every friend on it can be invited from here, wherever they are.'),
        trainerSearch(),
        h('button', { class: 'btn', onclick: () => app.go('friends') }, 'Open Friends'));
    }
    const fr = [...(S.friends?.friends ?? [])].sort((a, b) => (b.online ? 1 : 0) - (a.online ? 1 : 0) || (b.seenAt ?? 0) - (a.seenAt ?? 0));
    const inc = S.battles?.incoming ?? [], out = (S.battles?.outgoing ?? []).filter((b) => b.state === 'waiting');
    const pre = app.battleInvite; app.battleInvite = null;
    if (pre) { const f = fr.find((x) => x.username === pre); if (f) setTimeout(() => invite(f), 50); }
    return h('section', { class: 'panel col bl-friends' },
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, 'Battle a friend'), h('button', { class: 'btn small', onclick: () => { S.refresh().then(() => S.refreshBattles()); } }, 'Refresh')),
      trainerSearch(),
      inc.length ? h('div', { class: 'col bl-invites' }, inc.map((inv) => h('div', { class: 'fr-row bl-invite' },
        h('span', { class: 'grow' }, h('strong', null, inv.fromName ?? inv.from), ` wants to battle · ${inv.format}`),
        h('button', { class: 'btn small primary', onclick: () => answer(inv, true) }, 'Accept'),
        h('button', { class: 'btn small', onclick: () => answer(inv, false) }, 'Not now')))) : null,
      fr.length ? h('div', { class: 'col' }, fr.map((f) => {
        const sent = out.find((b) => b.to === f.username);
        return h('div', { class: 'fr-row' },
          h('span', { class: `fr-dot ${f.online ? 'on' : ''}` }),
          h('span', { class: 'grow' }, f.trainerName, h('span', { class: 'micro dim' }, f.online ? '  online' : `  ${ago(f.seenAt)}`)),
          sent ? [h('span', { class: 'micro dim' }, 'invited…'), h('button', { class: 'btn small', onclick: async () => { await S.client.cancelBattle(sent.id).catch(() => {}); S.refreshBattles(); } }, 'Cancel')]
            : h('button', { class: 'btn small primary', disabled: !party(app.save).length, title: f.online ? '' : 'They’re not online right now; the invite waits 15 minutes', onclick: () => invite(f) }, 'Invite'));
      })) : h('p', { class: 'dim' }, 'No friends on your server yet. Add some in the Friends app.'),
      h('p', { class: 'micro dim' }, 'You both battle with your own party. Change moves and held items below before you go.'));
  }

  // ---------- change your team (within what they could know) ----------
  async function editCreature(c) {
    const choices = moveChoices(app.idx, app.save, c);
    const why = { known: 'knows it', level: 'remembers it', tm: 'TM in your bag' };
    const opts = choices.map((m) => ({ value: m.id, label: `${m.name}  (${why[m.why]}${m.level ? `, Lv. ${m.level}` : ''})` }));
    const picked = (c.moves ?? []).map((m) => m.id).concat(['', '', '', '']).slice(0, 4);
    const holds = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && holdable(itemInfo(app.idx, id))).map(([id]) => ({ value: id, label: itemInfo(app.idx, id)?.name ?? id }));
    let held = c.heldItemId ?? '';
    const ok = await dialog(`${displayName(app.idx, c)}’s moves`, (close) => h('div', { class: 'col bl-edit' },
      h('div', { class: 'row' }, spriteCanvas(app.bank, c, { scale: 2, animate: true }), h('p', { class: 'dim' }, `Lv. ${c.level}. Pick up to four: moves it learned levelling up (up to its level) or from a TM in your bag.`)),
      picked.map((id, i) => h('label', { class: 'field' }, h('span', null, `Move ${i + 1}`), searchPick(opts, id, (v) => { picked[i] = v; }, { placeholder: 'Type a move…' }))),
      h('label', { class: 'field' }, h('span', null, 'Held item'), searchPick([{ value: '', label: '(nothing)' }, ...holds], held, (v) => { held = v; }, { placeholder: 'Type an item…' })),
      h('p', { class: 'micro dim' }, `${choices.filter((m) => m.why === 'tm').length} TM moves available. TMs are sold at the Market.`),
      h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(false) }, 'Cancel'), h('button', { class: 'btn primary', onclick: () => close(true) }, 'Save'))));
    if (!ok) return;
    let r;
    app.commit((s) => {
      r = setMoves(app.idx, s, c.uid, picked);
      if (r.ok) {
        const x = s.creatures[c.uid];
        // a held item comes out of the bag (and the old one goes back)
        if ((x.heldItemId ?? '') !== held) {
          if (x.heldItemId) s.inventory[x.heldItemId] = (s.inventory[x.heldItemId] ?? 0) + 1;
          if (held) s.inventory[held] = Math.max(0, (s.inventory[held] ?? 0) - 1);
          x.heldItemId = held || null;
        }
      }
    }, 'moves');
    if (!r?.ok) { toast(r?.reason ?? 'Couldn’t change that.', 'err'); return; }
    sfx('heal'); toast(`${displayName(app.idx, c)} is ready.`, 'ok'); render();
  }
  // the party's order (the first one leads), by dragging or the arrows
  function reorder(uid, to) {
    app.commit((sv) => {
      const list = party(sv).map((c) => c.uid), from = list.indexOf(uid);
      if (from < 0) return;
      list.splice(from, 1); list.splice(Math.max(0, Math.min(list.length, to)), 0, uid);
      list.forEach((u, i) => { sv.creatures[u].location = { ...sv.creatures[u].location, slot: i }; });
    }, 'party');
    render();
  }
  function editPanel() {
    const p = party(app.save);
    return h('section', { class: 'panel col bl-team-edit' },
      h('h2', null, 'Change your team'),
      p.length ? h('p', { class: 'micro dim' }, 'Drag to change the order. The first one leads in battle.') : null,
      p.length ? h('div', { class: 'col bl-order' }, p.map((c, i) => h('div', { class: 'fr-row bl-drag', draggable: 'true', 'data-uid': c.uid,
        ondragstart: (e) => { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', c.uid); e.currentTarget.classList.add('dragging'); },
        ondragend: (e) => { e.currentTarget.classList.remove('dragging'); document.querySelectorAll('.bl-drag.over').forEach((x) => x.classList.remove('over')); },
        ondragover: (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; e.currentTarget.classList.add('over'); },
        ondragleave: (e) => e.currentTarget.classList.remove('over'),
        ondrop: (e) => { e.preventDefault(); const from = e.dataTransfer.getData('text/plain'); if (from && from !== c.uid) reorder(from, i); } },
        h('span', { class: 'bl-grip', 'aria-hidden': 'true' }, '⋮⋮'),
        h('span', { class: 'bl-ordbtns' },
          h('button', { class: 'btn small icon', disabled: i === 0, title: 'Move up', 'aria-label': `Move ${displayName(app.idx, c)} up`, onclick: () => reorder(c.uid, i - 1) }, '▲'),
          h('button', { class: 'btn small icon', disabled: i === p.length - 1, title: 'Move down', 'aria-label': `Move ${displayName(app.idx, c)} down`, onclick: () => reorder(c.uid, i + 1) }, '▼')),
        spriteCanvas(app.bank, c, { scale: 1 }),
        h('span', { class: 'grow' }, h('strong', null, displayName(app.idx, c)), h('span', { class: 'micro dim' }, `  ${(c.moves ?? []).map((m) => app.idx.moves.get(m.id)?.name ?? m.id).join(' · ') || 'no moves'}${c.heldItemId ? ` · holds ${itemInfo(app.idx, c.heldItemId)?.name ?? c.heldItemId}` : ''}`)),
        h('button', { class: 'btn small', onclick: () => editCreature(c) }, 'Moves and item'))))
        : h('p', { class: 'dim' }, 'Your party is empty. Add creatures from the storage system.'));
  }

  // ---------- wild battles, right here ----------
  let wildBiome = app.save.settings?.wildBiome ?? 'meadow';
  let wildBusy = false;
  async function goWild() {
    if (wildBusy) return;
    wildBusy = true;
    try {
      let SD;
      try { SD = await loadShowdown(); } catch (e) { toast(e.message, 'err'); return; }
      const knowsSp = (sp) => SD.knows('species', sp.showdownName || sp.name);
      const seed = Date.now();
      // where to look: the place's own creatures (an arena can turn up anything)
      const pl = battlePlace(wildBiome);
      const findIn = pl.find ? pl.find[Math.floor(Math.random() * pl.find.length)] : null;
      const w = rollWild(app.idx, app.save, { biome: findIn, seed, known: knowsSp });
      if (!w) { toast('Showdown doesn’t know any of your data set’s species. Link them to their Showdown names in the Data Lab (or import Showdown’s Pokédex).', 'err'); return; }
      const teams = wildTeams(app.idx, app.save, w, SD.knows);
      if (!teams.team.length) { toast(teams.left.length ? `Showdown doesn’t know ${teams.left.join(', ')}: set their Showdown names in the Data Lab.` : 'Nobody in your party can battle right now (they need to heal first, or add someone to the party).', 'err'); return; }
      if (teams.left.length) toast(`${teams.left.join(', ')} can’t battle on Showdown (no Showdown name), so they sit this one out.`);
      sfx('warp');
      const st = app.save.settings ?? {};
      const res = await playWildBattle({ settings: app.save.settings ?? {}, idx: app.idx, bank: app.bank, resolve: (p) => app.textures[p.toLowerCase()] ?? null, trainer: app.save.trainer?.name ?? 'You',
        cardSprite: app.save.trainer?.card?.avatar?.sprite || '', sdAvatar: showdownSettings(app.save).avatar || '', sound: (st.battleSound ?? st.sound) !== false, volume: st.battleVolume ?? st.volume ?? 0.6, onVolume: (v) => app.commit((sv) => { sv.settings.battleVolume = v; }, 'settings'), onSound: (on) => app.commit((sv) => { sv.settings.battleSound = on; }, 'settings'), creatures: app.save.creatures, bag: battleBag(app.idx, app.save), onUseItem: (id) => app.commit((sv) => { sv.inventory[id] = Math.max(0, (sv.inventory[id] ?? 0) - 1); }, 'items', { quiet: true }) }, teams, { biome: wildBiome, seed });
      const r = wildOutcome(app.idx, w, res, teams.map);
      let out = [];
      app.commit((sv) => { out = applyWildResult(app.idx, sv, r); if (r.won) { sv.stats.battlesWon = (sv.stats.battlesWon ?? 0) + 1; sv.wallet = (sv.wallet ?? 0) + 20; } }, 'battle');
      const NAMES = { hp: 'HP', atk: 'Atk', def: 'Def', spa: 'SpA', spd: 'SpD', spe: 'Spe' };
      const lines = out.filter((o) => o.exp).map((o) => `${displayName(app.idx, app.save.creatures[o.uid])}: +${o.exp} exp${Object.keys(o.effort).length ? `, effort ${Object.entries(o.effort).map(([k, v]) => `${NAMES[k]} +${v}`).join(' ')}` : ''}`);
      if (r.won) toast(`Won against the wild ${teams.foeName}! ${lines.join(' · ')} (+20 coins)`, 'ok');
      else if (!r.ran) toast('Everyone needs a rest. They heal over time (or use a Potion).', 'err');
    } catch (e) { console.error(e); toast(`The battle stopped: ${e.message}`, 'err'); }
    finally { wildBusy = false; render(); }
  }
  // the Pokémon Center: everyone back to full HP and PP, cured of any status (fainted ones too)
  function center() {
    let n = 0; app.commit((sv) => { n = healParty(app.idx, sv); }, 'heal');
    sfx('heal');
    toast(n ? 'Your party is fully healed. We hope to see you again!' : 'Everyone’s already in perfect health.', 'ok');
    render();
  }
  // ---------- a hidden extra: battle one of the series' famous battlers ----------
  async function famousBattle(t) {
    if (wildBusy) return;
    const p = party(app.save);
    if (!p.length) { toast('Add creatures to your party first.', 'err'); return; }
    const top = Math.max(...p.map((c) => c.level ?? 5));
    const real = Math.max(...t.team.map((m) => m.level));
    const how = await chooseDialog(`${t.name} wants to battle!`, [
      { value: 'match', label: `Match their levels to yours (their strongest at Lv. ${Math.min(100, top + 2)})`, detail: `${t.name}’s team from ${t.title}, brought to your party’s level.` },
      { value: 'real', label: `Their real levels (up to Lv. ${real})`, detail: `Exactly as in ${t.title}. Good luck.` },
    ]);
    if (!how) return;
    wildBusy = true;
    try {
      let SD;
      try { SD = await loadShowdown(); } catch (e) { toast(e.message, 'err'); return; }
      const sets = famousTeam(t, { matchLevel: how === 'match' ? Math.min(100, top + 2) : null, knows: SD.knows });
      if (!sets.length) { toast('Showdown couldn’t field that team.', 'err'); return; }
      const anySp = app.idx.ds.species.find((sp) => SD.knows('species', sp.showdownName || sp.name)) ?? app.idx.ds.species[0];
      const w = { speciesId: anySp.id, level: sets[0].level, seed: Date.now() };
      const teams = wildTeams(app.idx, app.save, w, SD.knows);
      if (!teams.team.length) { toast('Nobody in your party can battle right now (they need to heal first).', 'err'); return; }
      // their creatures on the stage: this data set's own species when it has them, else Showdown's pictures
      const made = new Map();
      Object.assign(teams, { foeTeam: sets, foe: sets[0], foeTrainerName: t.name, foeAvatar: t.avatar,
        foeFor: (mon, bySd) => { const k = mon.name || mon.species; if (!made.has(k)) { const sid = bySd.get(String(mon.species).toLowerCase().replace(/[^a-z0-9]+/g, '')) ?? anySp.id; made.set(k, createCreature(app.idx, sid, { level: mon.level ?? 50, seed: k.length, location: { kind: 'wild' } })); } return made.get(k); } });
      sfx('warp');
      const st = app.save.settings ?? {};
      const res = await playWildBattle({ settings: app.save.settings ?? {}, idx: app.idx, bank: app.bank, resolve: (q) => app.textures[q.toLowerCase()] ?? null, trainer: app.save.trainer?.name ?? 'You',
        cardSprite: app.save.trainer?.card?.avatar?.sprite || '', sdAvatar: showdownSettings(app.save).avatar || '', sound: (st.battleSound ?? st.sound) !== false, volume: st.battleVolume ?? st.volume ?? 0.6,
        onVolume: (v) => app.commit((sv) => { sv.settings.battleVolume = v; }, 'settings'), onSound: (on) => app.commit((sv) => { sv.settings.battleSound = on; }, 'settings'), creatures: app.save.creatures,
        foeTrainer: app.textures[`trainers/${t.avatar}.png`] ?? `https://play.pokemonshowdown.com/sprites/trainers/${t.avatar}.png`,
        bag: battleBag(app.idx, app.save), onUseItem: (id) => app.commit((sv) => { sv.inventory[id] = Math.max(0, (sv.inventory[id] ?? 0) - 1); }, 'items', { quiet: true }) }, teams, { biome: 'stadium', seed: w.seed });
      // what the battle left behind (HP, PP, status) stays; an exhibition, so no experience
      const r = wildOutcome(app.idx, w, { ...res, won: false }, teams.map);
      app.commit((sv) => { applyWildResult(app.idx, sv, r); if (res.won) { sv.wallet = (sv.wallet ?? 0) + 200; sv.stats.famousWins = { ...(sv.stats.famousWins ?? {}), [t.name]: (sv.stats.famousWins?.[t.name] ?? 0) + 1 }; } }, 'battle');
      if (res.won) toast(`You beat ${t.name}! (+200 coins)`, 'ok');
      else if (!res.ran) toast(`${t.name} won this time.`, 'err');
    } catch (e) { console.error(e); toast(`The battle stopped: ${e.message}`, 'err'); }
    finally { wildBusy = false; render(); }
  }
  // the friend search: a friend's name finds them; a famous battler's name finds… someone else
  function trainerSearch() {
    const go = (v) => { const t = findFamousTrainer(v); if (t) { famousBattle(t); return true; } return false; };
    return h('input', { class: 'bl-search', type: 'search', placeholder: 'Find a trainer…', 'aria-label': 'Find a trainer', autocomplete: 'off', spellcheck: 'false',
      onkeydown: (e) => { if (e.key !== 'Enter') return; const v = e.target.value; if (go(v)) { e.target.value = ''; return; } const f = (S.friends?.friends ?? []).find((x) => String(x.trainerName ?? '').toLowerCase() === v.trim().toLowerCase() || String(x.username ?? '').toLowerCase() === v.trim().toLowerCase()); if (f) invite(f); else toast(`No trainer called “${v.trim()}” here.`); } });
  }
  async function heal(c) {
    const meds = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && healingOf(itemInfo(app.idx, id))).map(([id, n]) => ({ it: itemInfo(app.idx, id), n }));
    if (!meds.length) { toast('No medicine in the bag. The Market sells Potions; Oran, Sitrus and Leppa Berries help too.', 'err'); return; }
    const pick = await chooseDialog(`Heal ${displayName(app.idx, c)}`, meds.map(({ it, n }) => ({ value: it.id, label: `${it.name} × ${n}`, detail: it.desc ?? '' })));
    if (!pick) return;
    let r; app.commit((sv) => { r = useMedicine(app.idx, sv, c.uid, pick); }, 'heal');
    if (!r?.ok) toast(r?.reason ?? 'That didn’t help.', 'err'); else { sfx('heal'); toast(r.text, 'ok'); }
    render();
  }
  function wildPanel() {
    const p = party(app.save);
    return h('section', { class: 'panel col bl-wild' },
      h('h2', null, 'Battle a wild creature'),
      h('p', { class: 'dim' }, 'Your party against something wild, on Showdown’s own battle engine, shown as a 2.5D battle (★ places are battle arenas where anything can turn up). Winners share the experience and effort it gives. Damage and used-up PP stay afterwards and heal by themselves within about half an hour; Potions, Ethers and berries speed it up.'),
      h('div', { class: 'btn-group' },
        h('div', { class: 'btn-group-head' }, 'Where'),
        h('select', { 'aria-label': 'Where to look', onchange: (e) => { wildBiome = e.target.value; app.commit((sv) => { sv.settings.wildBiome = wildBiome; }, 'settings', { quiet: true }); } },
          BATTLE_PLACES.map((p) => h('option', { value: p.id, selected: p.id === wildBiome }, p.label))),
        h('button', { class: 'btn primary', disabled: !p.length, onclick: goWild }, 'Look for one'),
        h('button', { class: 'btn', disabled: !p.length, title: 'Heal everyone in your party back to full, like a Pokémon Center', onclick: center }, 'Heal party')),
      p.length ? h('div', { class: 'col' }, p.map((c) => {
        const cd = condition(app.idx, c);
        const low = cd.moves.filter((m) => m.pp < m.max);
        return h('div', { class: 'fr-row' },
          spriteCanvas(app.bank, c, { scale: 1 }),
          h('span', { class: 'grow col', style: { gap: '2px' } }, h('strong', null, `${displayName(app.idx, c)}${cd.fainted ? ' (fainted)' : c.status ? ` (${c.status})` : ''}`),
            hpBar(cd.hp, cd.max), low.length ? h('span', { class: 'micro dim' }, `PP: ${cd.moves.map((m) => `${app.idx.moves.get(m.id)?.name ?? m.id} ${m.pp}/${m.max}`).join(' · ')}`) : null),
          cd.hp < cd.max || low.length || c.status ? h('button', { class: 'btn small', onclick: () => heal(c) }, 'Heal…') : h('span', { class: 'micro dim' }, 'Ready'));
      })) : h('p', { class: 'dim' }, 'Add creatures to your party first.'));
  }

  function render() {
    const s = showdownSettings(app.save);
    const p = party(app.save);
    const embed = app.platform.canEmbedShowdown;
    const open = embed
      ? h('button', { class: 'btn primary', disabled: !p.length, onclick: () => openShowdown(app, {}) }, 'Open Showdown')
      : h('a', { class: 'btn primary', href: s.server, target: '_blank', rel: 'noopener' }, 'Open Showdown');
    let code = '';
    mount(el,
      result ? h('section', { class: 'panel results-panel' }, result, h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => { result = null; render(); } }, 'Close'))) : null,
      h('div', { class: 'sd-grid' },
        h('div', { class: 'col' },
          wildPanel(),
          teamPanel(app.sdCtx(), { actions: open }),
          friendPanel(),
          editPanel(),
          h('section', { class: 'panel col' },
            h('h2', null, 'Battle a phone'),
            app.platform.hasHub ? [
              h('p', { class: 'dim' }, 'Host a code and type it on the phone (Battle → code), or join the phone’s code. One of you is sent a Showdown challenge automatically.'),
              h('div', { class: 'row' },
                h('input', { type: 'text', id: 'battle-code', placeholder: 'Code', maxLength: 8, oninput: (e) => { code = e.target.value.toUpperCase(); } }),
                h('button', { class: 'btn', disabled: !p.length, onclick: () => host(code) }, 'Host or join')),
              waiting ? h('p', { class: 'waiting' }, `Waiting for the phone. Code ${waiting}`) : null,
            ] : h('p', { class: 'dim' }, 'Pairing with phones needs the desktop app.')),
          h('section', { class: 'panel col' },
            h('h2', null, 'How battles work'),
            h('p', null, embed
              ? 'Open Showdown here and log in once. Use the Capsule team panel in the corner of Showdown to challenge someone or accept their challenge, so your party is the team that battles. When the battle ends, experience, friendship and new moves are worked out here.'
              : 'In the desktop app, Showdown opens in its own window and results come back on their own. In this preview, copy the team into Showdown, then add the finished battle below.'))),
        h('div', { class: 'col' },
          showdownSettingsPanel(app.save, (fn) => app.commit(fn, 'settings', { quiet: true })),
          resultPanel(app.sdCtx(), (res) => { result = res; render(); }),
          historyPanel(app.sdCtx()))));
  }
  render();
  return {
    el,
    update: () => render(),
    dispose() { offs.forEach((o) => o()); if (waiting) { try { app.client?.send(MSG.CANCEL); } catch { /* closed */ } } },
  };
}
