// Battle: battles are played on Showdown. This screen sends your party there, pairs you
// with a phone by battle code, and turns finished battles into experience in-house.
import { h, mount, toast } from '../../../../shared/ui/dom.js';
import { teamPanel, resultPanel, historyPanel, showdownSettingsPanel, showdownSettings, prepareTeam } from '../../../../shared/ui/showdownUi.js';
import { party, MSG, toId } from '../../../../shared/engine/index.js';

export function battleView(app) {
  const el = h('div', { class: 'battleview sd' });
  let waiting = null;
  let result = null;
  const offs = [app.on((what) => { if (what === 'battle-result') { result = app.lastResult; render(); } })];

  async function openShowdown(config = {}) {
    const s = showdownSettings(app.save);
    const team = prepareTeam(app.sdCtx());
    if (!team.sets.length) { toast('Add creatures to your party first.', 'err'); return; }
    if (!app.platform.canEmbedShowdown) return; // the web preview shows a link instead
    await app.platform.openShowdown(s.server, { ...config, packed: team.packed, format: config.format || s.format });
    app.say(config.action === 'challenge' ? `Showdown is open. Challenging ${config.opponent}…` : 'Showdown is open. Your team is ready in the Capsule team panel there.');
  }

  async function host(code) {
    const s = showdownSettings(app.save);
    if (!toId(s.name)) { toast('Enter your Showdown name first.', 'err'); return; }
    try {
      const client = await app.hubClient();
      const off = client.on(MSG.MATCHED, (m) => {
        off(); waiting = null; render();
        app.say(`Matched with ${m.opponent.name} (${m.opponent.showdown} on Showdown).`, 'ok');
        openShowdown({ action: m.role, opponent: m.opponent.showdown, format: m.format });
      });
      offs.push(off);
      const w = await client.request(MSG.FIND, { mode: 'code', code: code || undefined, name: app.save.trainer?.name ?? 'PC', showdown: s.name, format: s.format, server: s.server }, MSG.WAITING).catch((e) => {
        if (/did not answer/.test(e.message)) return null; // matched straight away
        throw e;
      });
      if (w) { waiting = w.code; render(); }
    } catch (e) { toast(e.message, 'err'); }
  }

  function render() {
    const s = showdownSettings(app.save);
    const p = party(app.save);
    const embed = app.platform.canEmbedShowdown;
    const open = embed
      ? h('button', { class: 'btn primary', disabled: !p.length, onclick: () => openShowdown({}) }, 'Open Showdown')
      : h('a', { class: 'btn primary', href: s.server, target: '_blank', rel: 'noopener' }, 'Open Showdown');
    let code = '';
    mount(el,
      result ? h('section', { class: 'panel results-panel' }, result, h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => { result = null; render(); } }, 'Close'))) : null,
      h('div', { class: 'sd-grid' },
        h('div', { class: 'col' },
          teamPanel(app.sdCtx(), { actions: open }),
          h('section', { class: 'panel col' },
            h('h2', null, 'How battles work'),
            h('p', null, embed
              ? 'Open Showdown here and log in once. Use the Capsule team panel in the corner of Showdown to challenge someone or accept their challenge, so your party is the team that battles. When the battle ends, experience, friendship and new moves are worked out here.'
              : 'In the desktop app, Showdown opens in its own window and results come back on their own. In this preview, copy the team into Showdown, then add the finished battle below.')),
          h('section', { class: 'panel col' },
            h('h2', null, 'Battle a phone'),
            app.platform.hasHub ? [
              h('p', { class: 'dim' }, 'Host a code and type it on the phone (Battle → code), or join the phone’s code. One of you is sent a Showdown challenge automatically.'),
              h('div', { class: 'row' },
                h('input', { type: 'text', id: 'battle-code', placeholder: 'Code', maxLength: 8, oninput: (e) => { code = e.target.value.toUpperCase(); } }),
                h('button', { class: 'btn', disabled: !p.length, onclick: () => host(code) }, 'Host or join')),
              waiting ? h('p', { class: 'waiting' }, `Waiting for the phone. Code ${waiting}`) : null,
            ] : h('p', { class: 'dim' }, 'Pairing with phones needs the desktop app.'))),
        h('div', { class: 'col' },
          showdownSettingsPanel(app.save, (fn) => app.commit(fn, 'settings', { quiet: true })),
          resultPanel(app.sdCtx(), (res) => { result = res; render(); }),
          historyPanel(app.sdCtx()))));
  }
  render();
  return {
    el,
    update: () => render(),
    dispose() { offs.forEach((o) => o()); if (waiting) { try { app.client?.send(MSG.CANCEL); } catch { /* closed */ } } },
  };
}
