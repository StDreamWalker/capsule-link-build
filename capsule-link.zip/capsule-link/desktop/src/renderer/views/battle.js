// Battle: battles are played on Showdown. This screen sends your party there, pairs you with a phone by
// battle code, invites friends from your friends server to a battle (whoever accepts gets the challenge),
// lets you change your team's moves and held items within what they could really know (moves learned by
// levelling, TMs you own), and turns finished battles into experience in-house.
import { h, mount, toast, dialog, chooseDialog, confirmDialog } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { searchPick } from '../../../../shared/ui/searchPick.js';
import { sfx } from '../../../../shared/ui/audio.js';
import { teamPanel, resultPanel, historyPanel, showdownSettingsPanel, showdownSettings, prepareTeam } from '../../../../shared/ui/showdownUi.js';
import { battleKnows, battlePackage, party, MSG, toId, displayName, moveChoices, setMoves, holdable, itemInfo, rollWild, wildTeams, wildOutcome, applyWildResult, condition, healingOf, useMedicine, battleBag, healParty, healCost, noteDone, finishWish, findFamousTrainer, famousTeam, FAMOUS_TRAINERS, createCreature } from '../../../../shared/engine/index.js';
import { loadShowdown, playWildBattle } from '../../../../shared/ui/showdownWild.js';
import { openShowdownOnline, watchReplay } from '../../../../shared/ui/showdownOnline.js';
import { BATTLE_PLACES, battlePlace } from '../../../../shared/ui/battleStage.js';
import { atlasWeights, battlePlaceFor, tableLine, atlasProfileFor } from '../../../../shared/atlas/scan.js';
import { battleTracks, musicPicker } from '../../../../shared/ui/musicStore.js';
import { throwAtWild, caughtInBattle, battleBalls, ballBonus, BALL_ITEMS, addCreature, firstFreeBoxSlot } from '../../../../shared/engine/index.js';
import { localTable } from './atlas.js';
import { BIOME_IDS, BIOME_INFO } from '../../../../shared/ui/biomes.js';
import { hpBar } from '../../../../shared/ui/dom.js';
import { friendsSession, ago } from '../friendsSession.js';
import { joinBerryBlender } from '../../../../shared/ui/berryBlender.js';
import { hostLinkBattle, joinLinkBattle } from '../linkBattle.js';

/** Open Showdown with your party (config: { action: 'challenge' | 'accept', opponent, format }). */
export async function openShowdown(app, config = {}) {
  const s = showdownSettings(app.save);
  const team = prepareTeam(app.sdCtx());
  if (!team.sets.length) { toast('Add creatures to your party first.', 'err'); return false; }
  if (!app.platform.canEmbedShowdown) { window.open(s.server, '_blank', 'noopener'); return true; } // the web preview: a link
  await app.platform.openShowdown(s.server, { ...config, packed: team.packed, format: config.format || s.format });
  app.say(config.action === 'challenge' ? `Showdown is open. Challenging ${config.opponent}…` : config.action === 'accept' ? `Showdown is open. Accepting ${config.opponent}’s challenge…` : 'Showdown is open. Your team is ready in the Capsule team panel there.');
  return true;
}

/** App-wide: friends' battle invites and replies arrive wherever you are. */
export function watchFriendBattles(app) {
  const S = friendsSession(app);
  S.on((n) => {
    if (n.what === 'battle') {
      sfx('alert');
      toast(`${n.from} wants to battle! Open Battle Link to accept.`, 'ok');
      S.refreshBattles().catch(() => {});
    } else if (n.what === 'battle-reply') {
      if (!n.accept) { toast(`${n.from} can’t battle right now.`, 'err'); return; }
      // they accepted: you send the challenge, with your team
      sfx('access');
      openShowdown(app, { action: 'challenge', opponent: n.showdown, format: n.format });
    } else if (n.what === 'battle-cancel') S.refreshBattles().catch(() => {});
    else if (n.what === 'room' && n.kind === 'battle') {
      // an in-app battle (any creatures, your data sets' own too): they run it, you choose your moves
      sfx('alert');
      const who = S.friends?.friends?.find((f) => f.username === n.from)?.trainerName ?? n.from;
      confirmDialog('In-app battle', `${who} wants to battle you right here in the app, party against party (everyone at full health; nothing is won or lost but the battle).`, { ok: 'Battle!', cancel: 'Not now' })
        .then((yes) => { if (yes) joinLinkBattle(app, S, n.id, who); else S.client.joinRoom(n.id).then(() => S.client.leaveRoom(n.id)).catch(() => {}); });
    }
    else if (n.what === 'room' && n.kind === 'blender') {
      sfx('alert');
      const who = S.friends?.friends?.find((f) => f.username === n.from)?.trainerName ?? n.from;
      confirmDialog('Berry Blender', `${who} invited you to blend berries into Pokéblocks! Bring one creature and one berry.`, { ok: 'Join', cancel: 'Not now' })
        .then((yes) => { if (yes) joinBerryBlender(app, S, n.id); });
    }
  });
}

export function battleView(app) {
  const el = h('div', { class: 'battleview sd' });
  let waiting = null;
  let result = null;
  const S = friendsSession(app);
  const offs = [app.on((what) => { if (what === 'battle-result') { result = app.lastResult; render(); } }), S.on((n) => { if (['battles', 'refresh', 'online', 'offline'].includes(n.what)) render(); })];
  if (S.signedIn()) { S.refresh().then(() => S.refreshBattles()).catch(() => {}); }

  async function host(code) {
    const s = showdownSettings(app.save);
    if (!toId(s.name)) { toast('Enter your Showdown name first.', 'err'); return; }
    try {
      const client = await app.hubClient();
      const off = client.on(MSG.MATCHED, (m) => {
        off(); waiting = null; render();
        app.say(`Matched with ${m.opponent.name} (${m.opponent.showdown} on Showdown).`, 'ok');
        openShowdown(app, { action: m.role, opponent: m.opponent.showdown, format: m.format });
      });
      offs.push(off);
      const w = await client.request(MSG.FIND, { mode: 'code', code: code || undefined, name: app.save.trainer?.name ?? 'PC', showdown: s.name, format: s.format, server: s.server }, MSG.WAITING).catch((e) => {
        if (/did not answer/.test(e.message)) return null; // matched straight away
        throw e;
      });
      if (w) { waiting = w.code; render(); }
    } catch (e) { toast(e.message, 'err'); }
  }

  // ---------- battle a friend (friends server) ----------
  async function invite(f) {
    const s = showdownSettings(app.save);
    if (!toId(s.name)) { toast('Enter your Showdown name first (Showdown settings, on the right).', 'err'); return; }
    if (!party(app.save).length) { toast('Add creatures to your party first.', 'err'); return; }
    try { await S.client.inviteBattle(f.username, s.name, s.format); sfx('access'); toast(`Invite sent to ${f.trainerName}. When they accept, Showdown opens and you challenge them.`, 'ok'); await S.refreshBattles(); }
    catch (e) { toast(e.message, 'err'); }
  }
  async function answer(inv, yes) {
    const s = showdownSettings(app.save);
    if (yes && !toId(s.name)) { toast('Enter your Showdown name first (Showdown settings, on the right).', 'err'); return; }
    try {
      await S.client.respondBattle(inv.id, yes, s.name);
      await S.refreshBattles();
      if (yes) openShowdown(app, { action: 'accept', opponent: inv.showdown, format: inv.format });
    } catch (e) { toast(e.message, 'err'); }
  }
  function friendPanel() {
    if (!S.signedIn()) {
      return h('div', { class: 'col bl-friends' },
        h('p', { class: 'dim' }, 'Sign in to a friends server in the Friends app, and every friend on it can be invited from here, wherever they are.'),
        trainerSearch(),
        h('button', { class: 'btn', onclick: () => app.go('friends') }, 'Open Friends'));
    }
    const fr = [...(S.friends?.friends ?? [])].sort((a, b) => (b.online ? 1 : 0) - (a.online ? 1 : 0) || (b.seenAt ?? 0) - (a.seenAt ?? 0));
    const inc = S.battles?.incoming ?? [], out = (S.battles?.outgoing ?? []).filter((b) => b.state === 'waiting');
    const pre = app.battleInvite; app.battleInvite = null;
    if (pre) { const f = fr.find((x) => x.username === pre); if (f) setTimeout(() => invite(f), 50); }
    return h('div', { class: 'col bl-friends' },
      h('div', { class: 'row' }, h('span', { class: 'grow micro dim' }, 'Friends on your server'), h('button', { class: 'btn small', onclick: () => { S.refresh().then(() => S.refreshBattles()); } }, 'Refresh')),
      trainerSearch(),
      inc.length ? h('div', { class: 'col bl-invites' }, inc.map((inv) => h('div', { class: 'fr-row bl-invite' },
        h('span', { class: 'grow' }, h('strong', null, inv.fromName ?? inv.from), ` wants to battle · ${inv.format}`),
        h('button', { class: 'btn small primary', onclick: () => answer(inv, true) }, 'Accept'),
        h('button', { class: 'btn small', onclick: () => answer(inv, false) }, 'Not now')))) : null,
      fr.length ? h('div', { class: 'col' }, fr.map((f) => {
        const sent = out.find((b) => b.to === f.username);
        return h('div', { class: 'fr-row' },
          h('span', { class: `fr-dot ${f.online ? 'on' : ''}` }),
          h('span', { class: 'grow' }, f.trainerName, h('span', { class: 'micro dim' }, f.online ? '  online' : `  ${ago(f.seenAt)}`)),
          sent ? [h('span', { class: 'micro dim' }, 'invited…'), h('button', { class: 'btn small', onclick: async () => { await S.client.cancelBattle(sent.id).catch(() => {}); S.refreshBattles(); } }, 'Cancel')]
            : [h('button', { class: 'btn small primary', disabled: !party(app.save).length || !f.online, title: f.online ? 'A battle right here in the app: any creatures, your data set’s own too' : 'They need to be online for an in-app battle', onclick: () => hostLinkBattle(app, S, f) }, 'In-app battle'),
              h('button', { class: 'btn small', disabled: !party(app.save).length, title: f.online ? 'A battle on Showdown (Showdown’s own creatures only)' : 'They’re not online right now; the invite waits 15 minutes', onclick: () => invite(f) }, 'Showdown')]);
      })) : h('p', { class: 'dim' }, 'No friends on your server yet. Add some in the Friends app.'),
      h('p', { class: 'micro dim' }, 'You both battle with your own party. In-app battles take any creatures (your data set’s own too) and run right here; Showdown battles use Showdown’s own creatures. Change moves and held items below before you go.'));
  }

  // ---------- change your team (within what they could know) ----------
  async function editCreature(c) {
    const choices = moveChoices(app.idx, app.save, c);
    const why = { known: 'knows it', past: 'learned it before', level: 'from levelling up', tm: 'TM in your bag' };
    const opts = choices.map((m) => ({ value: m.id, label: `${m.name}  (${why[m.why]}${m.level ? `, Lv. ${m.level}` : ''})` }));
    const picked = (c.moves ?? []).map((m) => m.id).concat(['', '', '', '']).slice(0, 4);
    const holds = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && holdable(itemInfo(app.idx, id))).map(([id]) => ({ value: id, label: itemInfo(app.idx, id)?.name ?? id }));
    let held = c.heldItemId ?? '';
    const ok = await dialog(`${displayName(app.idx, c)}’s moves`, (close) => h('div', { class: 'col bl-edit' },
      h('div', { class: 'row' }, spriteCanvas(app.bank, c, { scale: 2, animate: true }), h('p', { class: 'dim' }, `Lv. ${c.level}. Pick up to four: moves it knew before, moves its kind learns up to its level, or a TM in your bag.`)),
      picked.map((id, i) => h('label', { class: 'field' }, h('span', null, `Move ${i + 1}`), searchPick(opts, id, (v) => { picked[i] = v; }, { placeholder: 'Type a move…' }))),
      h('label', { class: 'field' }, h('span', null, 'Held item'), searchPick([{ value: '', label: '(nothing)' }, ...holds], held, (v) => { held = v; }, { placeholder: 'Type an item…' })),
      h('p', { class: 'micro dim' }, `${choices.filter((m) => m.why === 'tm').length} TM moves available. TMs are sold at the Market.`),
      h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(false) }, 'Cancel'), h('button', { class: 'btn primary', onclick: () => close(true) }, 'Save'))));
    if (!ok) return;
    let r;
    app.commit((s) => {
      r = setMoves(app.idx, s, c.uid, picked);
      if (r.ok) {
        const x = s.creatures[c.uid];
        // a held item comes out of the bag (and the old one goes back)
        if ((x.heldItemId ?? '') !== held) {
          if (x.heldItemId) s.inventory[x.heldItemId] = (s.inventory[x.heldItemId] ?? 0) + 1;
          if (held) s.inventory[held] = Math.max(0, (s.inventory[held] ?? 0) - 1);
          x.heldItemId = held || null;
        }
      }
    }, 'moves');
    if (!r?.ok) { toast(r?.reason ?? 'Couldn’t change that.', 'err'); return; }
    sfx('heal'); toast(`${displayName(app.idx, c)} is ready.`, 'ok'); render();
  }
  // the party's order (the first one leads), by dragging or the arrows
  // who fights: the party, minus anyone you've sat out of battles (they stay in the party)
  const fighters = (sv = app.save) => party(sv).filter((c) => !c.benched);
  function bench(uid, off) { app.commit((sv) => { if (sv.creatures[uid]) sv.creatures[uid].benched = off || undefined; }, 'party'); render(); }
  function reorder(uid, to) {
    app.commit((sv) => {
      const list = party(sv).map((c) => c.uid), from = list.indexOf(uid);
      if (from < 0) return;
      list.splice(from, 1); list.splice(Math.max(0, Math.min(list.length, to)), 0, uid);
      list.forEach((u, i) => { sv.creatures[u].location = { ...sv.creatures[u].location, slot: i }; });
    }, 'party');
    render();
  }
  function editPanel() {
    const p = party(app.save);
    return h('section', { class: 'panel col bl-team-edit' },
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, 'Change your party'),
        h('button', { class: 'btn', disabled: !p.length, title: 'Heal everyone in your party back to full, like a Pokémon Center', onclick: center }, (() => { const c = healCost(app.idx, app.save); return c ? `Heal party (🪙 ${c})` : 'Heal party'; })())),
      p.length ? h('p', { class: 'micro dim' }, 'Drag to change the order. The first one leads in battle.') : null,
      p.length ? h('div', { class: 'col bl-order' }, p.map((c, i) => h('div', { class: 'fr-row bl-drag', draggable: 'true', 'data-uid': c.uid,
        ondragstart: (e) => { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', c.uid); e.currentTarget.classList.add('dragging'); },
        ondragend: (e) => { e.currentTarget.classList.remove('dragging'); document.querySelectorAll('.bl-drag.over').forEach((x) => x.classList.remove('over')); },
        ondragover: (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; e.currentTarget.classList.add('over'); },
        ondragleave: (e) => e.currentTarget.classList.remove('over'),
        ondrop: (e) => { e.preventDefault(); const from = e.dataTransfer.getData('text/plain'); if (from && from !== c.uid) reorder(from, i); } },
        h('span', { class: 'bl-grip', 'aria-hidden': 'true' }, '⋮⋮'),
        h('span', { class: 'bl-ordbtns' },
          h('button', { class: 'btn small icon', disabled: i === 0, title: 'Move up', 'aria-label': `Move ${displayName(app.idx, c)} up`, onclick: () => reorder(c.uid, i - 1) }, '▲'),
          h('button', { class: 'btn small icon', disabled: i === p.length - 1, title: 'Move down', 'aria-label': `Move ${displayName(app.idx, c)} down`, onclick: () => reorder(c.uid, i + 1) }, '▼')),
        spriteCanvas(app.bank, c, { scale: 1 }),
        h('span', { class: 'grow' }, h('strong', null, displayName(app.idx, c)), h('span', { class: 'micro dim' }, `  ${(c.moves ?? []).map((m) => app.idx.moves.get(m.id)?.name ?? m.id).join(' · ') || 'no moves'}${c.heldItemId ? ` · holds ${itemInfo(app.idx, c.heldItemId)?.name ?? c.heldItemId}` : ''}`)),
        h('label', { class: 'check bl-bench', title: 'Turn off to keep them in the party but out of battles' }, h('input', { type: 'checkbox', checked: !c.benched, onchange: (e) => bench(c.uid, !e.target.checked) }), 'Battles'),
        h('button', { class: 'btn small', onclick: () => editCreature(c) }, 'Moves and item'))))
        : h('p', { class: 'dim' }, 'Your party is empty. Add creatures from the storage system.'));
  }

  // ---------- wild battles, right here ----------
  let wildBiome = app.save.settings?.wildBiome ?? 'meadow';
  let wildBusy = false;
  async function goWild(soloUid = null) {
    if (wildBusy) return;
    // (one who asked to battle goes on its own, straight from where it is: no need to be in the party)
    const solo = soloUid && app.save.creatures[soloUid] && !app.save.creatures[soloUid].egg ? app.save.creatures[soloUid] : null;
    wildBusy = true;
    try {
      let SD;
      try { SD = await loadShowdown(); } catch (e) { toast(e.message, 'err'); return; }
      const canBattle = battleKnows(SD, app.idx), knowsSp = (sp) => canBattle('species', sp.showdownName || sp.name); // (a data set's own creatures battle too)
      const seed = Date.now();
      // where to look: the place's own creatures (an arena can turn up anything), or where you really are, with
      // the PokéAtlas deciding who lives there (and the stage that looks most like it)
      let stage = wildBiome, findIn = null, weights = null, here = null;
      if (wildBiome === 'here') {
        toast('Looking at where you are…');
        here = await localTable(app);
        if (!here) { toast('The app doesn’t know where you are yet. Pick a spot in the PokéAtlas (Home → PokéAtlas), or set your town in Settings.', 'err'); return; }
        stage = battlePlaceFor(here);
        weights = atlasWeights(app.idx, here, { filter: knowsSp });
        if (!weights) { toast(`Your data set has too few of the Pokémon that live around ${here.label}, so this one is found by how the place looks instead.`); const f = battlePlace(stage).find; findIn = f ? f[0] : null; }
        else toast(`Around ${tableLine(here)}`);
      } else {
        const pl = battlePlace(wildBiome);
        findIn = pl.find ? pl.find[Math.floor(Math.random() * pl.find.length)] : null;
      }
      const w = rollWild(app.idx, app.save, { biome: findIn, seed, known: knowsSp, weights });
      if (!w) { toast('Showdown doesn’t know any of your data set’s species. Link them to their Showdown names in the Data Lab (or import Showdown’s Pokédex).', 'err'); return; }
      const teams = wildTeams(app.idx, app.save, w, canBattle, solo ? [solo] : fighters());
      if (!teams.team.length && solo) { toast(teams.left.length ? `Showdown doesn’t know ${displayName(app.idx, solo)}: set its Showdown name in the Data Lab.` : `${displayName(app.idx, solo)} needs to heal before battling.`, 'err'); return; }
      if (!teams.team.length) { toast(teams.left.length ? `Showdown doesn’t know ${teams.left.join(', ')}: set their Showdown names in the Data Lab.` : 'Nobody in your party can battle right now (they need to heal first, or add someone to the party).', 'err'); return; }
      if (teams.left.length) toast(`${teams.left.join(', ')} can’t battle on Showdown (no Showdown name), so they sit this one out.`);
      sfx('warp');
      const st = app.save.settings ?? {};
      const res = await playWildBattle({ settings: app.save.settings ?? {}, idx: app.idx, bank: app.bank, resolve: (p) => app.textures[p.toLowerCase()] ?? null, trainer: app.save.trainer?.name ?? 'You',
        cardSprite: app.save.trainer?.card?.avatar?.sprite || '', sdAvatar: showdownSettings(app.save).avatar || '', sound: (st.battleSound ?? st.sound) !== false, volume: st.battleVolume ?? st.volume ?? 0.6, onVolume: (v) => app.commit((sv) => { sv.settings.battleVolume = v; }, 'settings'), onSound: (on) => app.commit((sv) => { sv.settings.battleSound = on; }, 'settings'), creatures: app.save.creatures, bag: battleBag(app.idx, app.save), onUseItem: (id) => app.commit((sv) => { sv.inventory[id] = Math.max(0, (sv.inventory[id] ?? 0) - 1); }, 'items', { quiet: true }),
        // Poké Balls from the bag: catch it (the games' odds, worked out here)
        music: (st.battleMusic ?? 'showdown') !== 'showdown' ? await battleTracks() : [], musicMode: st.battleMusic ?? 'showdown',
        balls: battleBalls(app.save, BALL_ITEMS).map((b) => ({ ...b, why: ballBonus(b.ball, {}).why })), onThrow: (id) => app.commit((sv) => { sv.inventory[id] = Math.max(0, (sv.inventory[id] ?? 0) - 1); }, 'items', { quiet: true }),
        catchCheck: (q) => throwAtWild(app.idx, app.save, q, { wild: w, stage, table: here, profile: atlasProfileFor(app.idx, app.idx.species.get(w.speciesId)), mineId: null }) }, teams, { biome: stage, seed });
      const r = wildOutcome(app.idx, w, res, teams.map);
      // caught: the very one from the battle, into the party (or a box), remembering where it happened
      let caughtC = null;
      if (res.caught && teams.foeCreature) {
        caughtC = caughtInBattle(app.idx, teams.foeCreature, { hp: res.caught.hp, status: res.caught.status, pp: res.caught.pp, ball: res.caught.ball, place: here?.label || battlePlace(stage).label, stage, trainer: app.save.trainer?.name, turns: res.caught.turns, critical: res.caught.critical });
        app.commit((sv) => { const inParty = Object.values(sv.creatures).filter((c) => c.location?.kind === 'party').length; addCreature(sv, caughtC, inParty < (app.idx.ds.rules.partySize ?? 6) ? { kind: 'party', slot: inParty } : firstFreeBoxSlot(sv) ?? { kind: 'ranch' }); }, 'catch');
      }
      let out = [];
      let wish = null;
      app.commit((sv) => { if (solo && !r.ran) wish = finishWish(app.idx, sv, solo.uid, 'battle'); out = applyWildResult(app.idx, sv, r); if (r.won) { sv.stats.battlesWon = (sv.stats.battlesWon ?? 0) + 1; sv.wallet = (sv.wallet ?? 0) + 20; for (const u of Object.values(teams.map ?? {})) if (u?.uid) noteDone(sv, u.uid, 'battleWon'); } }, 'battle');
      const NAMES = { hp: 'HP', atk: 'Atk', def: 'Def', spa: 'SpA', spd: 'SpD', spe: 'Spe' };
      const lines = out.filter((o) => o.exp).map((o) => `${displayName(app.idx, app.save.creatures[o.uid])}: +${o.exp} exp${Object.keys(o.effort).length ? `, effort ${Object.entries(o.effort).map(([k, v]) => `${NAMES[k]} +${v}`).join(' ')}` : ''}`);
      if (caughtC) { const loc = app.save.creatures[caughtC.uid]?.location; toast(`Gotcha! ${teams.foeName} was caught${loc?.kind === 'party' ? ' and joined your party' : loc?.kind === 'box' ? ` and went to ${app.save.boxes[loc.box]?.name ?? 'a box'}` : ''}. ${lines.join(' · ')}`, 'ok'); }
      else if (r.won) toast(`Won against the wild ${teams.foeName}! ${lines.join(' · ')} (+20 coins)`, 'ok');
      if (wish?.ok) setTimeout(() => toast(`${displayName(app.idx, solo)} got the battle they asked for!${wish.items?.length ? ` (+ ${wish.items.map(([id, n]) => `${n} ${itemInfo(app.idx, id)?.name ?? id}`).join(', ')})` : ''}`, 'ok'), 1200);
      else if (!r.ran && !r.won) toast('Everyone needs a rest. They heal over time (or use a Potion).', 'err');
    } catch (e) { console.error(e); toast(`The battle stopped: ${e.message}`, 'err'); }
    finally { wildBusy = false; render(); }
  }
  // the Pokémon Center: everyone back to full HP and PP, cured of any status (fainted ones too)
  // (it costs coins: 15 at the least, up to 20 for each one that fainted)
  function center() {
    const cost = healCost(app.idx, app.save);
    if (!cost) { toast('Everyone’s already in perfect health.', 'ok'); return; }
    if (cost > (app.save.wallet ?? 0)) { toast(`Healing your party costs ${cost} coins, and you have ${Math.floor(app.save.wallet ?? 0)}.`, 'err'); return; }
    let n = 0; app.commit((sv) => { n = healParty(app.idx, sv); if (n) sv.wallet = Math.max(0, (sv.wallet ?? 0) - cost); }, 'heal');
    sfx('heal');
    toast(n ? `Your party is fully healed (${cost} coins). We hope to see you again!` : 'Everyone’s already in perfect health.', 'ok');
    render();
  }
  // ---------- a hidden extra: battle one of the series' famous battlers ----------
  async function famousBattle(t) {
    if (wildBusy) return;
    const p = party(app.save);
    if (!p.length) { toast('Add creatures to your party first.', 'err'); return; }
    const top = Math.max(...p.map((c) => c.level ?? 5));
    const real = Math.max(...t.team.map((m) => m.level));
    const how = await chooseDialog(`${t.name} wants to battle!`, [
      { value: 'match', label: `Match their levels to yours (their strongest at Lv. ${Math.min(100, top + 2)})`, detail: `${t.name}’s team from ${t.title}, brought to your party’s level.` },
      { value: 'real', label: `Their real levels (up to Lv. ${real})`, detail: `Exactly as in ${t.title}. Good luck.` },
    ]);
    if (!how) return;
    wildBusy = true;
    try {
      let SD;
      try { SD = await loadShowdown(); } catch (e) { toast(e.message, 'err'); return; }
      const sets = famousTeam(t, { matchLevel: how === 'match' ? Math.min(100, top + 2) : null, knows: SD.knows });
      if (!sets.length) { toast('Showdown couldn’t field that team.', 'err'); return; }
      const anySp = app.idx.ds.species.find((sp) => SD.knows('species', sp.showdownName || sp.name)) ?? app.idx.ds.species[0];
      const w = { speciesId: anySp.id, level: sets[0].level, seed: Date.now() };
      const teams = wildTeams(app.idx, app.save, w, battleKnows(SD, app.idx), fighters());
      if (!teams.team.length) { toast('Nobody in your party can battle right now (they need to heal first).', 'err'); return; }
      // their creatures on the stage: this data set's own species when it has them, else Showdown's pictures
      const made = new Map();
      Object.assign(teams, { foeTeam: sets, foe: sets[0], foeTrainerName: t.name, foeAvatar: t.avatar,
        foeFor: (mon, bySd) => { const k = mon.name || mon.species; if (!made.has(k)) { const sid = bySd.get(String(mon.species).toLowerCase().replace(/[^a-z0-9]+/g, '')) ?? anySp.id; made.set(k, createCreature(app.idx, sid, { level: mon.level ?? 50, seed: k.length, location: { kind: 'wild' } })); } return made.get(k); } });
      sfx('warp');
      const st = app.save.settings ?? {};
      const res = await playWildBattle({ settings: app.save.settings ?? {}, idx: app.idx, bank: app.bank, resolve: (q) => app.textures[q.toLowerCase()] ?? null, trainer: app.save.trainer?.name ?? 'You',
        cardSprite: app.save.trainer?.card?.avatar?.sprite || '', sdAvatar: showdownSettings(app.save).avatar || '', sound: (st.battleSound ?? st.sound) !== false, volume: st.battleVolume ?? st.volume ?? 0.6,
        onVolume: (v) => app.commit((sv) => { sv.settings.battleVolume = v; }, 'settings'), onSound: (on) => app.commit((sv) => { sv.settings.battleSound = on; }, 'settings'), creatures: app.save.creatures,
        foeTrainer: app.textures[`trainers/${t.avatar}.png`] ?? `https://play.pokemonshowdown.com/sprites/trainers/${t.avatar}.png`,
        bag: battleBag(app.idx, app.save), onUseItem: (id) => app.commit((sv) => { sv.inventory[id] = Math.max(0, (sv.inventory[id] ?? 0) - 1); }, 'items', { quiet: true }) }, teams, { biome: 'stadium', seed: w.seed });
      // what the battle left behind (HP, PP, status) stays; an exhibition, so no experience
      const r = wildOutcome(app.idx, w, { ...res, won: false }, teams.map);
      app.commit((sv) => { applyWildResult(app.idx, sv, r); if (res.won) { sv.wallet = (sv.wallet ?? 0) + 200; sv.stats.famousWins = { ...(sv.stats.famousWins ?? {}), [t.name]: (sv.stats.famousWins?.[t.name] ?? 0) + 1 }; } }, 'battle');
      if (res.won) toast(`You beat ${t.name}! (+200 coins)`, 'ok');
      else if (!res.ran) toast(`${t.name} won this time.`, 'err');
    } catch (e) { console.error(e); toast(`The battle stopped: ${e.message}`, 'err'); }
    finally { wildBusy = false; render(); }
  }
  // the friend search: a friend's name finds them; a famous battler's name finds… someone else
  function trainerSearch() {
    const go = (v) => { const t = findFamousTrainer(v); if (t) { famousBattle(t); return true; } return false; };
    return h('input', { class: 'bl-search', type: 'search', placeholder: 'Find a trainer…', 'aria-label': 'Find a trainer', autocomplete: 'off', spellcheck: 'false',
      onkeydown: (e) => { if (e.key !== 'Enter') return; const v = e.target.value; if (go(v)) { e.target.value = ''; return; } const f = (S.friends?.friends ?? []).find((x) => String(x.trainerName ?? '').toLowerCase() === v.trim().toLowerCase() || String(x.username ?? '').toLowerCase() === v.trim().toLowerCase()); if (f) invite(f); else toast(`No trainer called “${v.trim()}” here.`); } });
  }
  async function heal(c) {
    const meds = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && healingOf(itemInfo(app.idx, id))).map(([id, n]) => ({ it: itemInfo(app.idx, id), n }));
    if (!meds.length) { toast('No medicine in the bag. The Market sells Potions; Oran, Sitrus and Leppa Berries help too.', 'err'); return; }
    const pick = await chooseDialog(`Heal ${displayName(app.idx, c)}`, meds.map(({ it, n }) => ({ value: it.id, label: `${it.name} × ${n}`, detail: it.desc ?? '' })));
    if (!pick) return;
    let r; app.commit((sv) => { r = useMedicine(app.idx, sv, c.uid, pick); }, 'heal');
    if (!r?.ok) toast(r?.reason ?? 'That didn’t help.', 'err'); else { sfx('heal'); toast(r.text, 'ok'); }
    render();
  }
  // ---------- online: Showdown's own server, friends, a phone ----------
  const replayCtx = () => { const st = app.save.settings ?? {}; return { settings: st, idx: app.idx, bank: app.bank, resolve: (q) => app.textures[q.toLowerCase()] ?? null, trainer: app.save.trainer?.name ?? 'You', cardSprite: '', sdAvatar: '', sound: (st.battleSound ?? st.sound) !== false, volume: st.battleVolume ?? st.volume ?? 0.6, creatures: app.save.creatures, biome: 'stadium' }; };
  const goReplay = async (link = '') => { try { await watchReplay(replayCtx(), { link, fetchText: async (u) => { const r = await app.platform.fetchUrl(u, 'text'); if (!r?.ok) throw new Error(`the replay site answered ${r?.status}`); return r.text; }, dialog }); } catch (e) { toast(e.message, 'err'); } };
  const goOnline = async () => {
    const st = app.save.settings ?? {};
    try {
      const SD = await loadShowdown();
      await openShowdownOnline({ settings: st, idx: app.idx, bank: app.bank, resolve: (q) => app.textures[q.toLowerCase()] ?? null, trainer: app.save.trainer?.name ?? 'You',
        cardSprite: app.save.trainer?.card?.avatar?.sprite || '', sdAvatar: showdownSettings(app.save).avatar || '', sound: (st.battleSound ?? st.sound) !== false, volume: st.battleVolume ?? st.volume ?? 0.6, creatures: app.save.creatures, biome: 'stadium' }, {
        party: () => wildTeams(app.idx, app.save, { speciesId: app.idx.ds.species[0].id, level: 5, seed: 1 }, SD.knows, fighters()),
        fetchText: async (u) => { const r = await app.platform.fetchUrl(u, 'text'); if (!r?.ok) throw new Error(`Showdown answered ${r?.status}`); return r.text; },
        dialog, getName: () => st.showdownOnlineName || showdownSettings(app.save).name || app.save.trainer?.name, setName: (n) => app.commit((sv) => { sv.settings.showdownOnlineName = n; }, 'settings', { quiet: true }),
      });
    } catch (e) { toast(e.message, 'err'); }
  };
  let friendsOpen = false, phoneCode = '';
  function onlinePanel() {
    const p = party(app.save);
    return h('section', { class: 'panel col bl-online' },
      h('h2', null, 'Battle online'),
      h('p', { class: 'dim' }, 'Real battles against real people on Pokémon Showdown’s server, shown on this battle screen: a Random Battle, your own party, or a challenge to or from anyone by name.'),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn primary', title: 'Battle real people on Pokémon Showdown’s server, on this battle screen', onclick: goOnline }, '🌐 Battle online'),
        h('button', { class: 'btn small', 'aria-expanded': String(friendsOpen), onclick: () => { friendsOpen = !friendsOpen; render(); } }, friendsOpen ? 'Battle a friend ▾' : 'Battle a friend ▸')),
      friendsOpen || app.battleInvite || (S.battles?.incoming ?? []).length ? friendPanel() : trainerSearch(),
      // a phone: host a code and type it on the phone, or join the phone's
      h('div', { class: 'col bl-phone' },
        h('span', { class: 'micro dim' }, 'A phone'),
        app.platform.hasHub ? [
          h('div', { class: 'row' },
            h('input', { type: 'text', id: 'battle-code', placeholder: 'Code', maxLength: 8, oninput: (e) => { phoneCode = e.target.value.toUpperCase(); } }),
            h('button', { class: 'btn small', disabled: !p.length, onclick: () => host(phoneCode) }, 'Host or join')),
          h('p', { class: 'micro dim' }, 'Host a code and type it on the phone (Battle → code), or join the phone’s code. One of you is sent a Showdown challenge automatically.'),
          waiting ? h('p', { class: 'waiting' }, `Waiting for the phone. Code ${waiting}`) : null,
        ] : h('p', { class: 'micro dim' }, 'Pairing with phones needs the desktop app.')));
  }
  // famous trainers from the series to battle (beaten ones get a ✓): a search box over a list that scrolls
  let trainerQ = '';
  function trainersPanel() {
    const wins = app.save.stats?.famousWins ?? {};
    const k = (x) => String(x ?? '').toLowerCase();
    const q = k(trainerQ).trim();
    const list = FAMOUS_TRAINERS.filter((t) => !q || k(t.name).includes(q) || k(t.title).includes(q) || t.aliases.some((a) => k(a).includes(q)) || t.team.some((m) => k(m.species).includes(q)));
    const rows = h('div', { class: 'col bl-trainer-list scroll' }, list.length ? list.map((t) => h('div', { class: 'fr-row' },
      h('span', { class: 'grow' }, h('strong', null, `${t.name}${wins[t.name] ? ' ✓' : ''}`), h('span', { class: 'micro dim' }, `  ${t.title} · ${t.team.length} Pokémon`)),
      h('button', { class: 'btn small', disabled: !fighters().length || wildBusy, onclick: () => famousBattle(t) }, 'Battle'))) : h('p', { class: 'dim micro' }, 'Nobody by that name: try a region, a game, or one of their Pokémon.'));
    return h('section', { class: 'panel col bl-trainers' },
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, 'Battle a trainer'), h('span', { class: 'dim micro' }, `${Object.keys(wins).length} of ${FAMOUS_TRAINERS.length} beaten`)),
      h('p', { class: 'dim' }, 'Famous trainers from the series, with their real teams (matched to your level if you like). Beat one for 200 coins.'),
      h('input', { type: 'search', class: 'bl-trainer-search', placeholder: `Search ${FAMOUS_TRAINERS.length} trainers: a name, a game, a Pokémon…`, value: trainerQ, 'aria-label': 'Search trainers',
        oninput: (e) => { trainerQ = e.target.value; const at = e.target.selectionStart; const box = e.target.closest('.bl-trainers'); const fresh = trainersPanel(); box.replaceWith(fresh); const f = fresh.querySelector('.bl-trainer-search'); f.focus(); try { f.setSelectionRange(at, at); } catch { /* fine */ } } }),
      rows);
  }
  function wildPanel() {
    const p = party(app.save);
    return h('section', { class: 'panel col bl-wild' },
      h('h2', null, 'Battle a wild creature'),
      h('p', { class: 'dim' }, 'Your party against something wild, on Showdown’s own battle engine, shown as a 2.5D battle (★ places are battle arenas where anything can turn up). Winners share the experience and effort it gives. Damage and used-up PP stay afterwards and heal by themselves within about half an hour; Potions, Ethers and berries speed it up.'),
      h('div', { class: 'btn-group' },
        h('div', { class: 'btn-group-head' }, 'Where'),
        h('select', { 'aria-label': 'Where to look', onchange: (e) => { wildBiome = e.target.value; app.commit((sv) => { sv.settings.wildBiome = wildBiome; }, 'settings', { quiet: true }); render(); } },
          [h('option', { value: 'here', selected: wildBiome === 'here' }, `📍 Where you are${app.save.settings?.atlasSpot?.label ? ` (${app.save.settings.atlasSpot.label})` : app.save.sky?.place ? ` (${app.save.sky.place})` : ''}`),
            ...BATTLE_PLACES.map((p) => h('option', { value: p.id, selected: p.id === wildBiome }, p.label))]),
        h('button', { class: 'btn primary', disabled: !p.length, onclick: () => goWild() }, 'Look for one')),
      musicPicker(h, { get: () => app.save.settings?.battleMusic, set: (v) => app.commit((sv) => { sv.settings.battleMusic = v; }, 'settings', { quiet: true }), toast }),
      wildBiome === 'here' ? h('p', { class: 'micro dim' }, 'Who turns up comes from the PokéAtlas for that spot: its land, climate, weather right now, time of day and the region’s own Pokémon. Change the spot in Home → PokéAtlas.') : null,
      p.length ? h('div', { class: 'col' }, p.map((c) => {
        const cd = condition(app.idx, c);
        const low = cd.moves.filter((m) => m.pp < m.max);
        return h('div', { class: 'fr-row' },
          spriteCanvas(app.bank, c, { scale: 1 }),
          h('span', { class: 'grow col', style: { gap: '2px' } }, h('strong', null, `${displayName(app.idx, c)}${cd.fainted ? ' (fainted)' : c.status ? ` (${c.status})` : ''}`),
            hpBar(cd.hp, cd.max), low.length ? h('span', { class: 'micro dim' }, `PP: ${cd.moves.map((m) => `${app.idx.moves.get(m.id)?.name ?? m.id} ${m.pp}/${m.max}`).join(' · ')}`) : null),
          cd.hp < cd.max || low.length || c.status ? h('button', { class: 'btn small', onclick: () => heal(c) }, 'Heal…') : h('span', { class: 'micro dim' }, 'Ready'));
      })) : h('p', { class: 'dim' }, 'Add creatures to your party first.'));
  }

  function render() {
    const s = showdownSettings(app.save);
    const p = party(app.save);
    const embed = app.platform.canEmbedShowdown;
    const open = embed
      ? h('button', { class: 'btn primary', disabled: !p.length, onclick: () => openShowdown(app, {}) }, 'Open Showdown')
      : h('a', { class: 'btn primary', href: s.server, target: '_blank', rel: 'noopener' }, 'Open Showdown');
    mount(el,
      result ? h('section', { class: 'panel results-panel' }, result, h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => { result = null; render(); } }, 'Close'))) : null,
      h('div', { class: 'sd-grid' },
        h('div', { class: 'col' },
          wildPanel(),
          editPanel(),
          trainersPanel(),
          onlinePanel(),
          h('section', { class: 'panel col' },
            h('h2', null, 'How battles work'),
            h('p', null, embed
              ? 'Open Showdown here and log in once. Use the Capsule team panel in the corner of Showdown to challenge someone or accept their challenge, so your party is the team that battles. When the battle ends, experience, friendship and new moves are worked out here.'
              : 'In the desktop app, Showdown opens in its own window and results come back on their own. In this preview, copy the team into Showdown, then add the finished battle below.'))),
        h('div', { class: 'col' },
          showdownSettingsPanel(app.save, (fn) => app.commit(fn, 'settings', { quiet: true })),
          teamPanel(app.sdCtx(), { actions: open }),
          resultPanel(app.sdCtx(), (res) => { result = res; render(); }, { onWatch: (link) => goReplay(link) }),
          historyPanel(app.sdCtx()))));
  }
  render();
  // one of them asked for a battle (“Let's do it now”): a wild battle, just them, straight away
  if (battleView.solo) { const u = battleView.solo; battleView.solo = null; setTimeout(() => goWild(u), 250); }
  return {
    el,
    update: () => render(),
    dispose() { offs.forEach((o) => o()); if (waiting) { try { app.client?.send(MSG.CANCEL); } catch { /* closed */ } } },
  };
}
