// Battle: battles are played on Showdown. This screen sends your party there, pairs you with a phone by
// battle code, invites friends from your friends server to a battle (whoever accepts gets the challenge),
// lets you change your team's moves and held items within what they could really know (moves learned by
// levelling, TMs you own), and turns finished battles into experience in-house.
import { h, mount, toast, dialog } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { searchPick } from '../../../../shared/ui/searchPick.js';
import { sfx } from '../../../../shared/ui/audio.js';
import { teamPanel, resultPanel, historyPanel, showdownSettingsPanel, showdownSettings, prepareTeam } from '../../../../shared/ui/showdownUi.js';
import { party, MSG, toId, displayName, moveChoices, setMoves, holdable, itemInfo } from '../../../../shared/engine/index.js';
import { friendsSession, ago } from '../friendsSession.js';

/** Open Showdown with your party (config: { action: 'challenge' | 'accept', opponent, format }). */
export async function openShowdown(app, config = {}) {
  const s = showdownSettings(app.save);
  const team = prepareTeam(app.sdCtx());
  if (!team.sets.length) { toast('Add creatures to your party first.', 'err'); return false; }
  if (!app.platform.canEmbedShowdown) { window.open(s.server, '_blank', 'noopener'); return true; } // the web preview: a link
  await app.platform.openShowdown(s.server, { ...config, packed: team.packed, format: config.format || s.format });
  app.say(config.action === 'challenge' ? `Showdown is open. Challenging ${config.opponent}…` : config.action === 'accept' ? `Showdown is open. Accepting ${config.opponent}’s challenge…` : 'Showdown is open. Your team is ready in the Capsule team panel there.');
  return true;
}

/** App-wide: friends' battle invites and replies arrive wherever you are. */
export function watchFriendBattles(app) {
  const S = friendsSession(app);
  S.on((n) => {
    if (n.what === 'battle') {
      sfx('alert');
      toast(`${n.from} wants to battle! Open Battle Link to accept.`, 'ok');
      S.refreshBattles().catch(() => {});
    } else if (n.what === 'battle-reply') {
      if (!n.accept) { toast(`${n.from} can’t battle right now.`, 'err'); return; }
      // they accepted: you send the challenge, with your team
      sfx('access');
      openShowdown(app, { action: 'challenge', opponent: n.showdown, format: n.format });
    } else if (n.what === 'battle-cancel') S.refreshBattles().catch(() => {});
  });
}

export function battleView(app) {
  const el = h('div', { class: 'battleview sd' });
  let waiting = null;
  let result = null;
  const S = friendsSession(app);
  const offs = [app.on((what) => { if (what === 'battle-result') { result = app.lastResult; render(); } }), S.on((n) => { if (['battles', 'refresh', 'online', 'offline'].includes(n.what)) render(); })];
  if (S.signedIn()) { S.refresh().then(() => S.refreshBattles()).catch(() => {}); }

  async function host(code) {
    const s = showdownSettings(app.save);
    if (!toId(s.name)) { toast('Enter your Showdown name first.', 'err'); return; }
    try {
      const client = await app.hubClient();
      const off = client.on(MSG.MATCHED, (m) => {
        off(); waiting = null; render();
        app.say(`Matched with ${m.opponent.name} (${m.opponent.showdown} on Showdown).`, 'ok');
        openShowdown(app, { action: m.role, opponent: m.opponent.showdown, format: m.format });
      });
      offs.push(off);
      const w = await client.request(MSG.FIND, { mode: 'code', code: code || undefined, name: app.save.trainer?.name ?? 'PC', showdown: s.name, format: s.format, server: s.server }, MSG.WAITING).catch((e) => {
        if (/did not answer/.test(e.message)) return null; // matched straight away
        throw e;
      });
      if (w) { waiting = w.code; render(); }
    } catch (e) { toast(e.message, 'err'); }
  }

  // ---------- battle a friend (friends server) ----------
  async function invite(f) {
    const s = showdownSettings(app.save);
    if (!toId(s.name)) { toast('Enter your Showdown name first (Showdown settings, on the right).', 'err'); return; }
    if (!party(app.save).length) { toast('Add creatures to your party first.', 'err'); return; }
    try { await S.client.inviteBattle(f.username, s.name, s.format); sfx('access'); toast(`Invite sent to ${f.trainerName}. When they accept, Showdown opens and you challenge them.`, 'ok'); await S.refreshBattles(); }
    catch (e) { toast(e.message, 'err'); }
  }
  async function answer(inv, yes) {
    const s = showdownSettings(app.save);
    if (yes && !toId(s.name)) { toast('Enter your Showdown name first (Showdown settings, on the right).', 'err'); return; }
    try {
      await S.client.respondBattle(inv.id, yes, s.name);
      await S.refreshBattles();
      if (yes) openShowdown(app, { action: 'accept', opponent: inv.showdown, format: inv.format });
    } catch (e) { toast(e.message, 'err'); }
  }
  function friendPanel() {
    if (!S.signedIn()) {
      return h('section', { class: 'panel col bl-friends' },
        h('h2', null, 'Battle a friend'),
        h('p', { class: 'dim' }, 'Sign in to a friends server in the Friends app, and every friend on it can be invited from here, wherever they are.'),
        h('button', { class: 'btn', onclick: () => app.go('friends') }, 'Open Friends'));
    }
    const fr = [...(S.friends?.friends ?? [])].sort((a, b) => (b.online ? 1 : 0) - (a.online ? 1 : 0) || (b.seenAt ?? 0) - (a.seenAt ?? 0));
    const inc = S.battles?.incoming ?? [], out = (S.battles?.outgoing ?? []).filter((b) => b.state === 'waiting');
    const pre = app.battleInvite; app.battleInvite = null;
    if (pre) { const f = fr.find((x) => x.username === pre); if (f) setTimeout(() => invite(f), 50); }
    return h('section', { class: 'panel col bl-friends' },
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, 'Battle a friend'), h('button', { class: 'btn small', onclick: () => { S.refresh().then(() => S.refreshBattles()); } }, 'Refresh')),
      inc.length ? h('div', { class: 'col bl-invites' }, inc.map((inv) => h('div', { class: 'fr-row bl-invite' },
        h('span', { class: 'grow' }, h('strong', null, inv.fromName ?? inv.from), ` wants to battle · ${inv.format}`),
        h('button', { class: 'btn small primary', onclick: () => answer(inv, true) }, 'Accept'),
        h('button', { class: 'btn small', onclick: () => answer(inv, false) }, 'Not now')))) : null,
      fr.length ? h('div', { class: 'col' }, fr.map((f) => {
        const sent = out.find((b) => b.to === f.username);
        return h('div', { class: 'fr-row' },
          h('span', { class: `fr-dot ${f.online ? 'on' : ''}` }),
          h('span', { class: 'grow' }, f.trainerName, h('span', { class: 'micro dim' }, f.online ? '  online' : `  ${ago(f.seenAt)}`)),
          sent ? [h('span', { class: 'micro dim' }, 'invited…'), h('button', { class: 'btn small', onclick: async () => { await S.client.cancelBattle(sent.id).catch(() => {}); S.refreshBattles(); } }, 'Cancel')]
            : h('button', { class: 'btn small primary', disabled: !party(app.save).length, title: f.online ? '' : 'They’re not online right now; the invite waits 15 minutes', onclick: () => invite(f) }, 'Invite'));
      })) : h('p', { class: 'dim' }, 'No friends on your server yet. Add some in the Friends app.'),
      h('p', { class: 'micro dim' }, 'You both battle with your own party. Change moves and held items below before you go.'));
  }

  // ---------- change your team (within what they could know) ----------
  async function editCreature(c) {
    const choices = moveChoices(app.idx, app.save, c);
    const why = { known: 'knows it', level: 'remembers it', tm: 'TM in your bag' };
    const opts = choices.map((m) => ({ value: m.id, label: `${m.name}  (${why[m.why]}${m.level ? `, Lv. ${m.level}` : ''})` }));
    const picked = (c.moves ?? []).map((m) => m.id).concat(['', '', '', '']).slice(0, 4);
    const holds = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && holdable(itemInfo(app.idx, id))).map(([id]) => ({ value: id, label: itemInfo(app.idx, id)?.name ?? id }));
    let held = c.heldItemId ?? '';
    const ok = await dialog(`${displayName(app.idx, c)}’s moves`, (close) => h('div', { class: 'col bl-edit' },
      h('div', { class: 'row' }, spriteCanvas(app.bank, c, { scale: 2, animate: true }), h('p', { class: 'dim' }, `Lv. ${c.level}. Pick up to four: moves it learned levelling up (up to its level) or from a TM in your bag.`)),
      picked.map((id, i) => h('label', { class: 'field' }, h('span', null, `Move ${i + 1}`), searchPick(opts, id, (v) => { picked[i] = v; }, { placeholder: 'Type a move…' }))),
      h('label', { class: 'field' }, h('span', null, 'Held item'), searchPick([{ value: '', label: '(nothing)' }, ...holds], held, (v) => { held = v; }, { placeholder: 'Type an item…' })),
      h('p', { class: 'micro dim' }, `${choices.filter((m) => m.why === 'tm').length} TM moves available. TMs are sold at the Market.`),
      h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(false) }, 'Cancel'), h('button', { class: 'btn primary', onclick: () => close(true) }, 'Save'))));
    if (!ok) return;
    let r;
    app.commit((s) => {
      r = setMoves(app.idx, s, c.uid, picked);
      if (r.ok) {
        const x = s.creatures[c.uid];
        // a held item comes out of the bag (and the old one goes back)
        if ((x.heldItemId ?? '') !== held) {
          if (x.heldItemId) s.inventory[x.heldItemId] = (s.inventory[x.heldItemId] ?? 0) + 1;
          if (held) s.inventory[held] = Math.max(0, (s.inventory[held] ?? 0) - 1);
          x.heldItemId = held || null;
        }
      }
    }, 'moves');
    if (!r?.ok) { toast(r?.reason ?? 'Couldn’t change that.', 'err'); return; }
    sfx('heal'); toast(`${displayName(app.idx, c)} is ready.`, 'ok'); render();
  }
  function editPanel() {
    const p = party(app.save);
    return h('section', { class: 'panel col bl-team-edit' },
      h('h2', null, 'Change your team'),
      p.length ? h('div', { class: 'col' }, p.map((c) => h('div', { class: 'fr-row' },
        spriteCanvas(app.bank, c, { scale: 1 }),
        h('span', { class: 'grow' }, h('strong', null, displayName(app.idx, c)), h('span', { class: 'micro dim' }, `  ${(c.moves ?? []).map((m) => app.idx.moves.get(m.id)?.name ?? m.id).join(' · ') || 'no moves'}${c.heldItemId ? ` · holds ${itemInfo(app.idx, c.heldItemId)?.name ?? c.heldItemId}` : ''}`)),
        h('button', { class: 'btn small', onclick: () => editCreature(c) }, 'Moves and item'))))
        : h('p', { class: 'dim' }, 'Your party is empty. Add creatures from the storage system.'));
  }

  function render() {
    const s = showdownSettings(app.save);
    const p = party(app.save);
    const embed = app.platform.canEmbedShowdown;
    const open = embed
      ? h('button', { class: 'btn primary', disabled: !p.length, onclick: () => openShowdown(app, {}) }, 'Open Showdown')
      : h('a', { class: 'btn primary', href: s.server, target: '_blank', rel: 'noopener' }, 'Open Showdown');
    let code = '';
    mount(el,
      result ? h('section', { class: 'panel results-panel' }, result, h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => { result = null; render(); } }, 'Close'))) : null,
      h('div', { class: 'sd-grid' },
        h('div', { class: 'col' },
          teamPanel(app.sdCtx(), { actions: open }),
          friendPanel(),
          editPanel(),
          h('section', { class: 'panel col' },
            h('h2', null, 'Battle a phone'),
            app.platform.hasHub ? [
              h('p', { class: 'dim' }, 'Host a code and type it on the phone (Battle → code), or join the phone’s code. One of you is sent a Showdown challenge automatically.'),
              h('div', { class: 'row' },
                h('input', { type: 'text', id: 'battle-code', placeholder: 'Code', maxLength: 8, oninput: (e) => { code = e.target.value.toUpperCase(); } }),
                h('button', { class: 'btn', disabled: !p.length, onclick: () => host(code) }, 'Host or join')),
              waiting ? h('p', { class: 'waiting' }, `Waiting for the phone. Code ${waiting}`) : null,
            ] : h('p', { class: 'dim' }, 'Pairing with phones needs the desktop app.')),
          h('section', { class: 'panel col' },
            h('h2', null, 'How battles work'),
            h('p', null, embed
              ? 'Open Showdown here and log in once. Use the Capsule team panel in the corner of Showdown to challenge someone or accept their challenge, so your party is the team that battles. When the battle ends, experience, friendship and new moves are worked out here.'
              : 'In the desktop app, Showdown opens in its own window and results come back on their own. In this preview, copy the team into Showdown, then add the finished battle below.'))),
        h('div', { class: 'col' },
          showdownSettingsPanel(app.save, (fn) => app.commit(fn, 'settings', { quiet: true })),
          resultPanel(app.sdCtx(), (res) => { result = res; render(); }),
          historyPanel(app.sdCtx()))));
  }
  render();
  return {
    el,
    update: () => render(),
    dispose() { offs.forEach((o) => o()); if (waiting) { try { app.client?.send(MSG.CANCEL); } catch { /* closed */ } } },
  };
}
