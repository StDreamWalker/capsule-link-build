// Trainer ID: edit the card that represents this profile on the PC and on phones.
import { h, mount, toast } from '../../../../shared/ui/dom.js';
import { pickTrainerPictures } from '../spriteImport.js';
import { cardEditor } from '../../../../shared/ui/idcardEditor.js';
import { sfx } from '../../../../shared/ui/audio.js';
import { cardNumber, party, displayName } from '../../../../shared/engine/index.js';
import { partyForCard } from '../../../../shared/ui/idcard.js';

export function trainerView(app) {
  const el = h('div', { class: 'trainerview col' });
  let dirty = false;
  let ed;
  const saveBtn = h('button', { class: 'btn primary', disabled: true, onclick: save }, 'Save card');

  function save() {
    const { name, card } = ed.value();
    app.commit((s) => { s.trainer.name = name; s.trainer.card = card; }, 'trainer');
    dirty = false; saveBtn.disabled = true;
    sfx('level');
    toast('Trainer ID saved. Phones pick it up on their next sync.', 'ok');
  }

  function render() {
    const t = app.save.trainer;
    ed = cardEditor({ trainer: t, editName: true, party: partyForCard(app.bank, party(app.save), (c) => displayName(app.idx, c)), onChange: () => { dirty = true; saveBtn.disabled = false; }, onAddSprites: () => pickTrainerPictures(app) });
    dirty = false; saveBtn.disabled = true;
    mount(el,
      h('div', { class: 'row' }, h('h1', { class: 'grow' }, 'Trainer ID'), h('span', { class: 'dim mono-num' }, `No. ${cardNumber(t.id, t.card)}`), saveBtn),
      h('p', { class: 'dim' }, 'This card is how this PC knows you on the log-on screen, and it travels to your phone with every sync. Pick any design: they are all equally official. Drag the card to spin it and see the back: sign it, stamp it, show off your party.'),
      h('section', { class: 'panel' }, ed.el));
  }

  render();
  return { el, update: () => { if (!dirty) render(); } };
}
