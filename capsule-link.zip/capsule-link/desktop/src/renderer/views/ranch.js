// R.A.N.C.H. (Remote Access Nurture & Care Hub): areas you load into. Each box has its own yard
// (in the box's environment); the berry farm and the shop are areas of their own.
// In a yard: pet by rubbing, pick creatures up and carry or fling them, throw toys and berries
// (from the bag), and watch them play. Mouse wheel or − / + zoom, drag the ground to look around.
import { h, mount, toast, chooseDialog, confirmDialog } from '../../../../shared/ui/dom.js';
import { sizeVariant } from '../../../../shared/ui/creatureSize.js';
import { Yard, toyKindOf, EXTRA_TOYS } from '../../../../shared/ui/yard.js';
import { spriteCanvas, spriteIdOf } from '../../../../shared/ui/art.js';
import { BIOME_IDS, BIOME_INFO } from '../../../../shared/ui/biomes.js';
import { creatureSummary, formPicker } from '../../../../shared/ui/summary.js';
import { playTransfer, transferLine } from '../../../../shared/ui/transfer.js';
import { sfx, creatureCry } from '../../../../shared/ui/audio.js';
import * as Paint from '../../../../shared/ui/paint.js';
import {
  atKind, displayName, applyCare, mood, tickNeeds, moveCreature, firstFreeBoxSlot, speciesOf, list, boxContents, party,
  farmState, plotStatus, plant, harvest, plantable, growInfo, FARM_PLOTS, releaseCreature, favorites, CARE_TOYS, friendsOf,
  shopStock, buy, wallet, itemInfo, shopResetIn, setForm, toggleBuddy, isDesktopBuddy, movementOf,
} from '../../../../shared/engine/index.js';
import { RANCH_NAME } from './home.js';
import { openCareRoom } from './careRoom.js';
import { openDressUp, clothesImg } from './dressUp.js';

const fmtLeft = (ms) => { const m = Math.ceil(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`; };
const AREAS = [['yard', 'Yard'], ['farm', 'Berry farm'], ['shop', 'Shop']];

/** What a creature looks like to the yard (shared with the care room). */
export function actorOf(app, c) {
  tickNeeds(app.idx, c);
  const sp = speciesOf(app.idx, c);
  const types = sp?.types ?? [];
  const typeNames = types.map((t) => app.idx.types.get(t)?.name ?? t);
  const all = [...types, ...typeNames].join(' ');
  const mv = movementOf(app.idx, sp, c);
  return {
    uid: c.uid, speciesId: spriteIdOf(c), sizeMul: sizeVariant(c).mult, name: displayName(app.idx, c), mood: mood(c).id,
    // speed stat sets how fast they scurry: slow ones plod, fast ones dart
    speed: c.egg ? 0 : 0.35 + (sp?.baseStats?.spe ?? 50) / 45,
    swim: mv.swim, fly: !c.egg && mv.float, fire: /fire|ember/i.test(all),
    types: [...types, ...typeNames], egg: !!c.egg,
    friends: friendsOf(c).map((f) => f.uid),
    clothes: (c.clothes ?? []).map((w) => ({ ...w, img: clothesImg(app.idx, w.id) })).filter((w) => w.img),
  };
}

export function ranchView(app) {
  const typeTint = (c) => app.idx.types.get(app.idx.species.get(c.speciesId)?.types?.[0])?.color ?? '#9fe8ff';
  const habitats = () => {
    const out = app.save.boxes.map((b, i) => ({ key: i, name: b.name, biome: b.biome ?? 'meadow' }));
    if (atKind(app.save, 'ranch').length) out.push({ key: 'ranch', name: app.save.ranch?.name ?? 'Free range', biome: app.save.ranch?.biome ?? 'meadow' });
    return out;
  };
  let cur = app.ranchHabitat ?? 0;
  if (!habitats().some((x) => x.key === cur)) cur = 0;
  let selected = null;
  let area = 'yard';
  let panelOpen = false;
  let lastPet = 0;
  let menu = null; // 'toys' | 'food' | null

  const canvas = h('canvas', { class: 'hab-canvas', tabindex: '0', 'aria-label': 'The yard. Rub a creature to pet it, drag it to carry it, let go to drop it. Drag the ground to look around, scroll to zoom.' });
  const hudTL = h('div', { class: 'hud hud-tl' });
  const hudTR = h('div', { class: 'hud hud-tr' });
  const hudBottom = h('div', { class: 'hud hud-bottom' });
  const menuEl = h('div', { class: 'hud-menu', hidden: true });
  const panel = h('aside', { class: 'holo-panel' });
  const intro = h('div', { class: 'hab-intro', 'aria-hidden': 'true' }, h('div', { class: 'rings' }, h('i'), h('i'), h('i')), h('div', { class: 'intro-text' }, 'R.A.N.C.H.', h('small', null, 'opening the gate…')));
  const el = h('div', { class: 'ranchvr' }, canvas, hudTL, hudTR, hudBottom, menuEl, panel, intro, h('div', { class: 'hud-frame', 'aria-hidden': 'true' }));

  const seedOf = (key) => (typeof key === 'number' ? key : 99) + 1;
  const yard = new Yard(canvas, {
    bank: app.bank,
    accent: app.save.trainer?.card?.accent,
    resolveTexture: (p) => app.textures[p.toLowerCase()] ?? null,
    biome: habitats().find((x) => x.key === cur)?.biome,
    seed: seedOf(cur),
    sizeScale: app.save.settings?.ranchScale ?? 1,
    onSelect: (uid) => { selected = uid; if (uid) { panelOpen = true; sfx('move'); } closeMenu(); renderPanel(); renderHud(); },
    onPet: (uid) => { const now = Date.now(); if (now - lastPet < 300) return; lastPet = now; care(uid, 'pet', null, true); },
    onDrop: (uid, speed) => {
      if (speed > 4) { yard.react(uid, 'dizzy', 2); sfx('miss'); care(uid, 'play', null, true, false); }
      else { yard.react(uid, 'sparkle', 2); sfx('blip'); }
    },
    onPlot: (i) => plotClick(i),
    onShop: () => { panelOpen = true; sfx('access'); renderPanel(); renderHud(); },
    onBounce: (t, hit) => { if (hit > 5) sfx('blip'); },
    onEat: (uid, item) => {
      const c = app.save.creatures[uid];
      if (!c || !item?.id) return;
      const fav = favorites(app.idx, c);
      let out;
      app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], 'feed', { item: item.id, favorite: item.id === fav.berry, inventory: save.inventory }); }, 'care', { quiet: true });
      if (out?.ok) { yard.react(uid, out.reaction === 'delighted' ? 'hearts' : out.reaction === 'full' ? 'sad' : 'munch', 4); sfx('munch'); app.say(`${displayName(app.idx, c)} ${out.reaction === 'full' ? 'sniffed the' : 'ate the'} ${item.name}${out.reaction === 'delighted' ? ' — a favourite!' : out.reaction === 'full' ? ', but is full.' : '.'}`); }
      else if (out?.reason) toast(out.reason, 'err');
      renderPanel(); if (menu) renderMenu();
    },
    onPlay: (uid, kind, item) => {
      const c = app.save.creatures[uid];
      if (!c) return;
      const id = item?.id ?? kind;
      const fav = favorites(app.idx, c);
      let out;
      app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], 'play', { toy: id, toyName: item?.name, favorite: id === fav.toy, inventory: save.inventory }); }, 'care', { quiet: true });
      if (out?.ok && out.reaction === 'delighted') { yard.react(uid, 'hearts', 3); app.say(`${displayName(app.idx, c)} loves the ${item?.name ?? kind}!`); }
      else if (out?.reaction === 'tired') yard.emote(uid, 'tired', false);
      if (selected === uid) renderPanel();
    },
  });

  const here = () => (cur === 'ranch' ? atKind(app.save, 'ranch') : boxContents(app.save, cur).filter(Boolean));
  const habitat = () => habitats().find((x) => x.key === cur) ?? habitats()[0];

  function syncActors() {
    yard.setCreatures(area === 'yard' ? here().map((c) => actorOf(app, c)) : []);
  }
  function syncPlots() { yard.setPlots(farmState(app.save).plots.map((p) => plotStatus(app.idx, p))); }

  function goArea(a) {
    if (a === area) return;
    area = a;
    selected = null; yard.selected = null;
    closeMenu();
    yard.setScene(a, habitat().biome, seedOf(cur));
    syncActors(); syncPlots();
    yard.materialize();
    panelOpen = a !== 'yard';
    sfx('warp');
    renderHud(); renderPanel();
  }
  function switchTo(key) {
    if (key === cur && area === 'yard') return;
    cur = key;
    app.ranchHabitat = key;
    selected = null; yard.selected = null;
    yard.actors.clear();
    area = 'yard';
    yard.setScene('yard', habitat().biome, seedOf(key));
    syncActors();
    yard.materialize();
    sfx('warp');
    renderHud(); renderPanel();
  }
  const stepHabitat = (d) => { const l = habitats(); const i = l.findIndex((x) => x.key === cur); switchTo(l[(i + d + l.length) % l.length].key); };

  function care(uid, action, item, quiet = false, react = true) {
    let out;
    app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], action, { item, inventory: save.inventory }); }, 'care', { quiet: true });
    if (!out?.ok) { if (out?.reason && !quiet) toast(out.reason, 'err'); return; }
    const reaction = { hearts: 'hearts', munch: 'munch', delighted: 'hearts', play: 'hearts', sparkle: 'sparkle', listen: 'note', sleep: 'sleep', full: 'sad', tired: 'sleep' }[out.reaction] ?? 'hearts';
    if (react) yard.react(uid, reaction, reaction === 'hearts' ? 3 : 4);
    if (action === 'pet') sfx('heart');
    if (action === 'feed') sfx(out.reaction === 'full' ? 'back' : 'munch');
    if (action === 'groom') sfx('heal');
    const nm = displayName(app.idx, app.save.creatures[uid]);
    if (out.reaction === 'full') app.say(`${nm} is full.`);
    if (out.reaction === 'tired') app.say(`${nm} is too tired to play.`);
    if (!quiet || out.friendship) renderPanel();
  }

  // ---------- quality time: the care room ----------
  async function careRoom(uid) {
    yard.stop();
    await openCareRoom(app, uid, {
      biome: habitat()?.biome ?? 'meadow',
      seed: seedOf(cur),
      doCare: (action, opts = {}) => {
        let out;
        app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], action, { ...opts, inventory: save.inventory }); }, 'care', { quiet: true });
        if (out && !out.ok && out.reason) toast(out.reason, 'err');
        return out;
      },
    });
    yard.start();
    syncActors(); renderPanel(); renderHud();
  }

  // ---------- toys and berries from the bag ----------
  const toyList = () => [...CARE_TOYS, ...EXTRA_TOYS, ...app.idx.ds.items.filter((i) => i.kind === 'toy' && (i.unlimited || (app.save.inventory[i.id] ?? 0) > 0))];
  const foodList = () => app.idx.ds.items.filter((it) => it.kind === 'food' && !it.unlimited && (app.save.inventory[it.id] ?? 0) > 0);
  function closeMenu() { menu = null; menuEl.hidden = true; renderHud(); }
  function openMenu(kind) { menu = menu === kind ? null : kind; renderMenu(); renderHud(); }
  function renderMenu() {
    menuEl.hidden = !menu;
    if (!menu) return;
    if (menu === 'toys') {
      mount(menuEl,
        h('div', { class: 'hud-menu-head' }, 'Throw a toy'),
        h('div', { class: 'hud-menu-grid' }, toyList().map((it) => {
          const kind = toyKindOf(it);
          const pic = Paint.toy(kind, { w: 40, h: 40 }); pic.className = 'hud-menu-pic';
          return h('button', { class: 'hud-menu-item', title: it.desc ?? '', onclick: () => { yard.throwToy(kind, it); sfx('blip'); } }, pic, h('span', null, it.name));
        })),
        h('div', { class: 'row' }, h('button', { class: 'hud-btn', onclick: () => { yard.clearToys(); sfx('back'); } }, 'Put the toys away'), h('span', { class: 'hud-hint' }, 'Drag a toy to pick it up and fling it.')));
    } else {
      const foods = foodList();
      mount(menuEl,
        h('div', { class: 'hud-menu-head' }, 'Toss a berry'),
        foods.length ? h('div', { class: 'hud-menu-grid' }, foods.map((it) => h('button', { class: 'hud-menu-item', title: it.desc ?? '', onclick: () => { if ((app.save.inventory[it.id] ?? 0) <= yard.toys.filter((t) => t.item?.id === it.id).length) { toast(`No more ${it.name} to toss.`, 'err'); return; } yard.tossBerry(it); sfx('blip'); } },
          h('span', { class: 'hud-menu-dot', style: { background: it.color ?? '#c98a3a' } }), h('span', null, it.name), h('small', null, `× ${app.save.inventory[it.id] ?? 0}`))))
          : h('p', { class: 'holo-dim' }, 'No berries in the bag. Grow some on the berry farm or buy them in the shop.'),
        h('span', { class: 'hud-hint' }, 'Whoever gets there first eats it.'));
    }
  }

  // ---------- the berry farm ----------
  async function plotClick(i) {
    const st = plotStatus(app.idx, farmState(app.save).plots[i]);
    if (st.ready) {
      let r;
      app.commit((s) => { r = harvest(app.idx, s, i); }, 'farm', { quiet: true });
      if (r?.ok) { sfx('level'); toast(`Picked ${r.count} ${r.item.name}.`, 'ok'); }
    } else if (st.empty) {
      const seeds = plantable(app.idx).filter((it) => it.unlimited || (app.save.inventory[it.id] ?? 0) > 0);
      const pick = await chooseDialog('Plant something', seeds.map((it) => ({ value: it.id, label: it.name, detail: `${app.save.inventory[it.id] ?? 0} in the bag · ripe in ${growInfo(it).hours} h · gives ${growInfo(it).yield}` })), { empty: 'Nothing to plant. Walks turn up berries and roots, and the shop sells them; plant one to grow more.' });
      if (!pick) return;
      let r;
      app.commit((s) => { r = plant(app.idx, s, i, pick); }, 'farm', { quiet: true });
      if (r && !r.ok) toast(r.reason, 'err'); else sfx('heal');
    } else toast(`${st.item?.name ?? 'It'} is ripe in ${fmtLeft(st.left)}.`);
    syncPlots(); renderPanel();
  }

  async function bring() {
    const to = cur === 'ranch' ? { kind: 'ranch' } : (() => { const t = firstFreeBoxSlot(app.save, 30, cur); return t && t.box === cur ? t : null; })();
    if (!to) { toast('This yard is full (30 creatures).', 'err'); return; }
    const options = list(app.save).filter((c) => ['party', 'box', 'ranch'].includes(c.location.kind) && !(cur === 'ranch' ? c.location.kind === 'ranch' : c.location.kind === 'box' && c.location.box === cur));
    const uid = await chooseDialog('Bring someone to this yard', options.map((c) => ({
      value: c.uid, label: displayName(app.idx, c), detail: `Lv. ${c.level} · ${c.location.kind === 'party' ? 'party' : c.location.kind === 'ranch' ? 'free range' : app.save.boxes[c.location.box]?.name}`,
      el: spriteCanvas(app.bank, c, { scale: 1 }),
    })), { empty: 'Everyone is already here.' });
    if (!uid) return;
    let r;
    app.commit((s) => { r = moveCreature(s, uid, { ...to }, app.idx.ds.rules.partySize); }, 'move', { quiet: true });
    if (r && !r.ok) { toast(r.error, 'err'); return; }
    syncActors();
    const a = yard.actors.get(uid);
    if (a) a.appear = -1.1; // shows up as the light lands
    const who = app.save.creatures[uid];
    const art = h('span', null, spriteCanvas(app.bank, who, { scale: 2 }));
    playTransfer({ to: yard.screenRect(uid), mode: 'arrive', spriteEl: art, tint: typeTint(who), say: transferLine(cur === 'ranch' ? 'ranch' : 'box', displayName(app.idx, who), { box: app.save.boxes[cur]?.name }) });
    renderHud();
  }

  function renderHud() {
    const hb = habitat();
    const n = here().length;
    const where = area === 'yard' ? (typeof cur === 'number' ? `YARD ${String(cur + 1).padStart(2, '0')}` : 'FREE RANGE') : area === 'farm' ? 'BERRY FARM' : 'SHOP';
    mount(hudTL,
      h('div', { class: 'hud-kicker' }, 'R.A.N.C.H.', h('span', null, ` // ${where}`)),
      h('div', { class: 'hud-title' }, area === 'yard' ? hb.name : area === 'farm' ? 'Berry farm' : 'Shop'),
      h('div', { class: 'hud-sub' }, area === 'yard' ? `${BIOME_INFO[hb.biome]?.label ?? hb.biome} · ${n} creature${n === 1 ? '' : 's'} here` : area === 'farm' ? 'Plant food, pick it when ripe' : `${wallet(app.save)} coins · new stock in ${fmtLeft(shopResetIn())}`),
      h('div', { class: 'hud-areas', role: 'tablist', 'aria-label': 'Area' }, AREAS.map(([id, label]) => h('button', { class: `hud-btn ${area === id ? 'on' : ''}`, role: 'tab', 'aria-selected': String(area === id), onclick: () => goArea(id) }, label))));
    mount(hudTR,
      h('div', { class: 'row' },
        h('button', { class: 'hud-btn', 'aria-label': 'Previous box', title: 'Previous box (Page Up)', onclick: () => stepHabitat(-1) }, '◀'),
        h('select', { class: 'hud-select', 'aria-label': 'Box', onchange: (e) => switchTo(e.target.value === 'ranch' ? 'ranch' : Number(e.target.value)) },
          habitats().map((x) => h('option', { value: String(x.key), selected: x.key === cur }, x.name))),
        h('button', { class: 'hud-btn', 'aria-label': 'Next box', title: 'Next box (Page Down)', onclick: () => stepHabitat(1) }, '▶'),
        h('button', { class: `hud-btn ${panelOpen ? 'on' : ''}`, title: 'Show or hide the side panel', onclick: () => { panelOpen = !panelOpen; renderPanel(); renderHud(); } }, panelOpen ? 'Hide log' : 'Log')),
      area === 'yard' ? h('label', { class: 'row hud-env' }, h('span', null, 'Environment'),
        h('select', { class: 'hud-select', onchange: (e) => {
          const v = e.target.value;
          app.commit((s) => { if (cur === 'ranch') s.ranch = { ...(s.ranch || {}), biome: v }; else s.boxes[cur].biome = v; }, 'wallpaper', { quiet: true });
          yard.setBiome(v, seedOf(cur)); syncActors(); yard.materialize(); sfx('warp'); renderHud();
        } }, BIOME_IDS.map((id) => h('option', { value: id, selected: id === hb.biome }, BIOME_INFO[id].label)))) : null);
    mount(hudBottom,
      area === 'yard' ? [
        h('button', { class: `hud-btn wide ${menu === 'toys' ? 'on' : ''}`, 'aria-expanded': String(menu === 'toys'), onclick: () => openMenu('toys') }, 'Toys ▴'),
        h('button', { class: `hud-btn wide ${menu === 'food' ? 'on' : ''}`, 'aria-expanded': String(menu === 'food'), onclick: () => openMenu('food') }, 'Berries ▴'),
        h('button', { class: 'hud-btn wide', onclick: bring }, 'Bring someone'),
        h('span', { class: 'hud-hint' }, 'Rub to pet · drag to pick up · fling to toss · drag the ground to look around · scroll to zoom'),
      ] : area === 'farm' ? h('span', { class: 'hud-hint' }, 'Click a plot to plant or pick · drag the ground to look around')
        : [h('button', { class: 'hud-btn wide', onclick: () => { panelOpen = true; renderPanel(); renderHud(); } }, 'Open the shop'), h('span', { class: 'hud-hint' }, 'Or click the stall. The stock changes every day.')],
      h('span', { class: 'hud-orbit' },
        h('button', { class: 'hud-btn', title: 'Zoom in (+)', 'aria-label': 'Zoom in', onclick: () => yard.zoom(-1) }, '+'),
        h('button', { class: 'hud-btn', title: 'Zoom out (−)', 'aria-label': 'Zoom out', onclick: () => yard.zoom(1) }, '−'),
        h('button', { class: 'hud-btn', title: 'Turn left (Q)', 'aria-label': 'Turn the view left', onclick: () => yard.turn(-1) }, '⟲'),
        h('button', { class: 'hud-btn', title: 'Face the front (R)', 'aria-label': 'Reset the view', onclick: () => { yard.turn(0); yard.zoom(0); } }, '◎'),
        h('button', { class: 'hud-btn', title: 'Turn right (E)', 'aria-label': 'Turn the view right', onclick: () => yard.turn(1) }, '⟳')),
      h('span', { class: 'hud-link', title: 'Live data link to this area' }, h('i'), 'LINK STABLE'));
  }

  function farmPanel() {
    const farm = farmState(app.save);
    const seeds = plantable(app.idx);
    return [
      h('div', { class: 'holo-head' }, 'Berry farm'),
      h('p', { class: 'holo-dim' }, 'Plant one of a food from your bag and pick several when it ripens. Plants keep growing while the app is closed.'),
      h('div', { class: 'holo-list' }, farm.plots.slice(0, FARM_PLOTS).map((p, i) => {
        const st = plotStatus(app.idx, p);
        return h('button', { class: 'holo-row', onclick: () => plotClick(i) },
          h('span', { class: 'plot-dot', style: { background: st.empty ? '#6b4423' : st.item?.color ?? '#3fb26a' } }),
          h('span', { class: 'grow' }, st.empty ? `Plot ${i + 1}: empty` : `${st.item?.name ?? st.itemId}`),
          h('span', { class: 'holo-dim' }, st.empty ? 'Plant' : st.ready ? 'Ready!' : fmtLeft(st.left)));
      })),
      h('div', { class: 'holo-head' }, 'Seeds in the bag'),
      h('div', { class: 'kv holo-kv' }, seeds.map((it) => [h('span', null, it.name), h('span', null, `× ${app.save.inventory[it.id] ?? 0}`)])),
    ];
  }
  function shopPanel() {
    const stock = shopStock(app.idx, app.save);
    const coins = wallet(app.save);
    const sections = [...new Set(stock.lines.map((l) => l.section))];
    const after = { clothes: 'Dress someone up from their panel in the yard.', held: 'Give it to someone to hold from their panel in the yard.', incense: 'Light it on your phone before a walk.', food: 'Toss it in the yard, feed it, or plant it on the farm.' };
    return [
      h('div', { class: 'holo-head' }, 'Shop'),
      h('div', { class: 'shop-wallet' }, h('span', { class: 'coin' }), h('strong', null, `${coins}`), h('span', { class: 'holo-dim' }, ` coins · new stock in ${fmtLeft(shopResetIn())}`)),
      h('p', { class: 'holo-dim' }, 'Coins come from walking (1 for every 25 steps) and battles.'),
      sections.map((sec) => [
        h('div', { class: 'holo-head small' }, sec),
        h('div', { class: 'holo-list' }, stock.lines.filter((l) => l.section === sec).map((l) => {
          const it = l.item;
          const pic = it.kind === 'clothes' ? (() => { const c = clothesImg(app.idx, it.id); const cv = document.createElement('canvas'); const k = Math.max(1, Math.floor(28 / Math.max(c.width, c.height))); cv.width = c.width * k; cv.height = c.height * k; const x = cv.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(c, 0, 0, cv.width, cv.height); cv.className = 'shop-pic'; return cv; })()
            : h('span', { class: 'plot-dot', style: { background: it.color ?? (it.kind === 'held' ? '#9aa6b8' : '#c98a3a') } });
          return h('div', { class: 'holo-row shop-row' },
            pic,
            h('span', { class: 'grow col' }, h('span', null, it.name), h('small', { class: 'holo-dim' }, it.desc ?? '')),
            h('span', { class: 'holo-dim' }, l.left ? `${l.left} left` : 'Sold out'),
            h('button', { class: 'btn small primary', disabled: !l.left || coins < l.price, onclick: () => {
              let r; app.commit((s) => { r = buy(app.idx, s, l.id); }, 'shop', { quiet: true });
              if (!r?.ok) { toast(r?.reason ?? 'Could not buy that.', 'err'); return; }
              sfx('level'); toast(`Bought ${it.name}. ${after[it.kind] ?? ''}`, 'ok');
              renderPanel(); renderHud();
            } }, `${l.price}`));
        })),
      ]),
    ];
  }

  async function giveHeld(c) {
    const held = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && itemInfo(app.idx, id)?.kind === 'held').map(([id, n]) => ({ item: itemInfo(app.idx, id), n }));
    const pick = await chooseDialog(`Something for ${displayName(app.idx, c)} to hold`, [
      ...(c.heldItemId ? [{ value: '__none', label: 'Take it back', detail: itemInfo(app.idx, c.heldItemId)?.name ?? '' }] : []),
      ...held.map(({ item, n }) => ({ value: item.id, label: item.name, detail: `${item.desc ?? ''} · ${n} in the bag${item.showdownName ? '' : ' · only for show until it has a battle name (Data Lab)'}` })),
    ], { empty: 'No battle items in the bag. The shop sells them.' });
    if (!pick) return;
    app.commit((s) => {
      const x = s.creatures[c.uid];
      if (x.heldItemId) s.inventory[x.heldItemId] = (s.inventory[x.heldItemId] ?? 0) + 1;
      if (pick === '__none') { x.heldItemId = null; x.heldItem = ''; return; }
      const it = itemInfo(app.idx, pick);
      s.inventory[pick] = Math.max(0, (s.inventory[pick] ?? 0) - 1);
      x.heldItemId = pick; x.heldItem = it.showdownName || '';
    }, 'held');
    sfx('access');
    renderPanel();
  }

  function renderPanel() {
    panel.classList.toggle('open', panelOpen);
    el.classList.toggle('panel-open', panelOpen);
    if (area === 'farm') { mount(panel, farmPanel()); return; }
    if (area === 'shop') { mount(panel, shopPanel()); return; }
    const c = selected && app.save.creatures[selected];
    const inHere = c && here().some((x) => x.uid === c.uid);
    if (!inHere) {
      const folk = here();
      mount(panel,
        h('div', { class: 'holo-head' }, 'Yard log'),
        h('p', { class: 'holo-dim' }, `${RANCH_NAME}. Whoever is in this box lives in this yard. Click someone to look after them.`),
        folk.length ? h('div', { class: 'holo-list' }, folk.map((x) => h('button', { class: 'holo-row', onclick: () => { selected = x.uid; yard.selected = x.uid; sfx('move'); renderPanel(); } },
          spriteCanvas(app.bank, x, { scale: 1 }), h('span', { class: 'grow' }, displayName(app.idx, x)), h('span', { class: 'holo-dim' }, mood(x).label))))
          : h('p', { class: 'holo-dim' }, 'Nobody lives here yet. Bring someone, or move creatures into this box from the storage system.'),
        h('div', { class: 'holo-head' }, 'Bag'),
        h('div', { class: 'shop-wallet' }, h('span', { class: 'coin' }), h('strong', null, `${wallet(app.save)}`), h('span', { class: 'holo-dim' }, ' coins')),
        (() => {
          const inv = Object.entries(app.save.inventory ?? {}).filter(([, n]) => n > 0);
          return inv.length ? h('div', { class: 'kv holo-kv' }, inv.map(([id, n]) => [h('span', null, itemInfo(app.idx, id)?.name ?? id), h('span', null, `× ${n}`)])) : h('p', { class: 'holo-dim' }, 'Empty. Walks turn up treats and toys.');
        })());
      return;
    }
    const foods = app.idx.ds.items.filter((it) => it.kind === 'food' && (it.unlimited || (app.save.inventory[it.id] ?? 0) > 0));
    const grooms = app.idx.ds.items.filter((it) => it.kind === 'groom' && (it.unlimited || (app.save.inventory[it.id] ?? 0) > 0));
    const count = (it) => (it.unlimited ? '' : ` (${app.save.inventory[it.id] ?? 0})`);
    const heldName = c.heldItemId ? itemInfo(app.idx, c.heldItemId)?.name : null;
    const actions = h('div', { class: 'col' },
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn primary', title: 'Just the two of you: wash, brush, feed by hand, play fetch', onclick: () => careRoom(c.uid) }, 'Quality time'),
        h('button', { class: 'btn', onclick: () => care(c.uid, 'pet') }, 'Pet'),
        h('button', { class: 'btn', onclick: () => { const t = yard.throwBall(); const a = yard.actors.get(c.uid); if (a && !a.egg) { a.state = 'chase'; a.toy = t; a.timer = 8; a.kicks = 0; } } }, 'Play'),
        h('button', { class: 'btn', onclick: () => { creatureCry(speciesOf(app.idx, c), c, { mood: mood(c).id === 'happy' ? 'happy' : mood(c).id === 'bored' ? 'upset' : undefined }); care(c.uid, 'talk'); yard.emote(c.uid); } }, 'Call'),
        h('button', { class: 'btn', onclick: () => care(c.uid, 'rest') }, 'Nap'),
        h('button', { class: 'btn', onclick: async () => { yard.stop(); await openDressUp(app, c.uid); yard.start(); syncActors(); renderPanel(); } }, 'Dress up')),
      formPicker(app.idx, c, (form) => { app.commit((s) => setForm(app.idx, s.creatures[c.uid], form), 'form', { quiet: true }); sfx('warp'); syncActors(); yard.react(c.uid, 'sparkle', 3); renderPanel(); }),
      foods.length ? h('div', { class: 'row wrap' }, h('span', { class: 'dim' }, 'Feed'), foods.map((it) => h('button', { class: 'btn small', title: it.desc, onclick: () => care(c.uid, 'feed', it.id) }, it.name + count(it)))) : null,
      grooms.length ? h('div', { class: 'row wrap' }, h('span', { class: 'dim' }, 'Groom'), grooms.map((it) => h('button', { class: 'btn small', title: it.desc, onclick: () => care(c.uid, 'groom', it.id) }, it.name + count(it)))) : null,
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small', onclick: () => giveHeld(c) }, heldName ? `Holding: ${heldName}` : 'Give an item to hold'),
        h('button', { class: 'btn small', disabled: party(app.save).length >= app.idx.ds.rules.partySize, onclick: () => {
          const rect = yard.screenRect(c.uid);
          let r; app.commit((s) => { r = moveCreature(s, c.uid, { kind: 'party' }, app.idx.ds.rules.partySize); }, 'move', { quiet: true });
          if (r && !r.ok) return toast(r.error, 'err');
          const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
          selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
          if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: typeTint(c), say: transferLine('party', displayName(app.idx, c)) });
          else sfx('access');
        } }, 'Take into party'),
        h('button', { class: `btn small ${isDesktopBuddy(app.save, c.uid) ? 'signal' : ''}`, onclick: () => { let r; app.commit((s) => { r = toggleBuddy(s, c.uid); }); if (!r.ok) toast(r.reason, 'err'); else toast(r.on ? `${displayName(app.idx, c)} is out on your desktop.` : `${displayName(app.idx, c)} came back from the desktop.`, 'ok'); renderPanel(); } }, isDesktopBuddy(app.save, c.uid) ? 'On the desktop' : 'Desktop buddy'),
        h('button', { class: 'btn small danger', onclick: async () => {
          const name = displayName(app.idx, c);
          if (!(await confirmDialog(`Release ${name}?`, `${name} will return to the wild for good. This can’t be undone.`, { ok: 'Release', danger: true }))) return;
          const rect = yard.screenRect(c.uid);
          const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
          app.commit((s) => releaseCreature(s, c.uid), 'release', { quiet: true });
          selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
          const say = `${name} looked back once, then headed off into the wild.`;
          if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: '#ffffff', say });
          app.say(say);
        } }, 'Release'),
        h('button', { class: 'btn small', onclick: () => { selected = null; yard.selected = null; panelOpen = false; renderPanel(); renderHud(); } }, 'Close')));
    mount(panel, creatureSummary(app.idx, app.bank, c, { compact: true, save: app.save, sections: ['care', 'walk', 'likes'], actions }));
  }

  const onKey = (e) => {
    if (e.target.closest?.('input, select, textarea')) return;
    if (e.key === 'q' || e.key === 'Q') yard.turn(-1);
    else if (e.key === 'e' || e.key === 'E') yard.turn(1);
    else if (e.key === 'r' || e.key === 'R') { yard.turn(0); yard.zoom(0); }
    else if (e.key === '+' || e.key === '=') yard.zoom(-1);
    else if (e.key === '-' || e.key === '_') yard.zoom(1);
    else if (e.key === 'ArrowLeft') yard.turn(-1);
    else if (e.key === 'ArrowRight') yard.turn(1);
    else if (e.key === '1') goArea('yard');
    else if (e.key === '2') goArea('farm');
    else if (e.key === '3') goArea('shop');
    else if (e.key === 'PageUp') stepHabitat(-1);
    else if (e.key === 'PageDown') stepHabitat(1);
    else if (e.key === 'Escape') { if (menu) closeMenu(); else { selected = null; yard.selected = null; panelOpen = false; renderPanel(); renderHud(); } }
    else return;
    e.preventDefault();
  };
  const onDocDown = (e) => { if (menu && !menuEl.contains(e.target) && !hudBottom.contains(e.target)) closeMenu(); };

  function update() { syncActors(); syncPlots(); renderHud(); renderPanel(); if (menu) renderMenu(); }

  update();
  let plotTimer = null;
  return {
    el,
    mounted() {
      yard.resize();
      yard.materialize();
      yard.start();
      window.addEventListener('keydown', onKey);
      document.addEventListener('pointerdown', onDocDown, true);
      plotTimer = setInterval(() => { syncPlots(); if (area !== 'yard') { renderPanel(); renderHud(); } }, 30000);
      setTimeout(() => intro.classList.add('done'), 900);
      canvas.focus({ preventScroll: true });
    },
    update,
    art: () => {},
    tick: () => { syncActors(); syncPlots(); renderPanel(); },
    dispose() { yard.destroy(); clearInterval(plotTimer); window.removeEventListener('keydown', onKey); document.removeEventListener('pointerdown', onDocDown, true); },
  };
}
