// R.A.N.C.H. (Remote Access Nurture & Care Hub): you stand inside a box's yard.
// Pet by rubbing, pick creatures up and carry or toss them, throw a ball.
// The edge arrows lead to the berry farm (left) and the shop (right).
import { h, mount, toast, chooseDialog, confirmDialog } from '../../../../shared/ui/dom.js';
import { sizeVariant } from '../../../../shared/ui/creatureSize.js';
import { Yard, ZONES } from '../../../../shared/ui/yard.js';
import { spriteCanvas, spriteIdOf } from '../../../../shared/ui/art.js';
import { BIOME_IDS, BIOME_INFO } from '../../../../shared/ui/biomes.js';
import { creatureSummary } from '../../../../shared/ui/summary.js';
import { playTransfer, transferLine } from '../../../../shared/ui/transfer.js';
import { sfx, playCry, creatureCry } from '../../../../shared/ui/audio.js';
import {
  atKind, displayName, applyCare, mood, tickNeeds, moveCreature, firstFreeBoxSlot, cryFor, speciesOf, list, boxContents, party,
  farmState, plotStatus, plant, harvest, plantable, growInfo, FARM_PLOTS, releaseCreature, favorites,
} from '../../../../shared/engine/index.js';
import { RANCH_NAME } from './home.js';
import { openCareRoom } from './careRoom.js';

const fmtLeft = (ms) => { const m = Math.ceil(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`; };

export function ranchView(app) {
  const typeTint = (c) => app.idx.types.get(app.idx.species.get(c.speciesId)?.types?.[0])?.color ?? '#9fe8ff';
  const habitats = () => {
    const out = app.save.boxes.map((b, i) => ({ key: i, name: b.name, biome: b.biome ?? 'meadow' }));
    if (atKind(app.save, 'ranch').length) out.push({ key: 'ranch', name: app.save.ranch?.name ?? 'Free range', biome: app.save.ranch?.biome ?? 'meadow' });
    return out;
  };
  let cur = app.ranchHabitat ?? 0;
  if (!habitats().some((x) => x.key === cur)) cur = 0;
  let selected = null;
  let zone = 'yard';
  let panelOpen = false;
  let lastPet = 0;

  const canvas = h('canvas', { class: 'hab-canvas', tabindex: '0', 'aria-label': 'The yard. Rub a creature to pet it, drag it to carry it, let go to drop it. Drag the ground to look around.' });
  const hudTL = h('div', { class: 'hud hud-tl' });
  const hudTR = h('div', { class: 'hud hud-tr' });
  const hudBottom = h('div', { class: 'hud hud-bottom' });
  const edgeL = h('button', { class: 'edge-arrow left', onclick: () => yard.step(-1) });
  const edgeR = h('button', { class: 'edge-arrow right', onclick: () => yard.step(1) });
  const panel = h('aside', { class: 'holo-panel' });
  const intro = h('div', { class: 'hab-intro', 'aria-hidden': 'true' }, h('div', { class: 'rings' }, h('i'), h('i'), h('i')), h('div', { class: 'intro-text' }, 'R.A.N.C.H.', h('small', null, 'opening the gate…')));
  const el = h('div', { class: 'ranchvr' }, canvas, hudTL, hudTR, hudBottom, edgeL, edgeR, panel, intro, h('div', { class: 'hud-frame', 'aria-hidden': 'true' }));

  const seedOf = (key) => (typeof key === 'number' ? key : 99) + 1;
  const yard = new Yard(canvas, {
    bank: app.bank,
    accent: app.save.trainer?.card?.accent,
    resolveTexture: (p) => app.textures[p.toLowerCase()] ?? null,
    biome: habitats().find((x) => x.key === cur)?.biome,
    seed: seedOf(cur),
    sizeScale: app.save.settings?.ranchScale ?? 1,
    onSelect: (uid) => { selected = uid; if (uid) { panelOpen = true; sfx('move'); } renderPanel(); renderHud(); },
    onPet: (uid) => { const now = Date.now(); if (now - lastPet < 300) return; lastPet = now; care(uid, 'pet', null, true); },
    onDrop: (uid, speed) => {
      if (speed > 4) { yard.react(uid, 'dizzy', 2); sfx('miss'); care(uid, 'play', null, true, false); }
      else { yard.react(uid, 'sparkle', 2); sfx('blip'); }
    },
    onPlot: (i) => plotClick(i),
    onEat: (uid, item) => {
      const fav = favorites(app.idx, app.save.creatures[uid]);
      let out;
      app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], 'feed', { item: item.id, favorite: item.id === fav.berry, inventory: save.inventory }); }, 'care', { quiet: true });
      if (out?.ok) { yard.react(uid, out.reaction === 'delighted' ? 'hearts' : 'munch', 4); sfx('munch'); app.say(`${displayName(app.idx, app.save.creatures[uid])} ate the ${item.name}${out.reaction === 'delighted' ? ' — a favourite!' : '.'}`); }
      renderPanel();
    },
    onZone: (z) => { zone = z; panelOpen = z !== 'yard'; sfx('move'); renderHud(); renderPanel(); },
  });

  const here = () => (cur === 'ranch' ? atKind(app.save, 'ranch') : boxContents(app.save, cur).filter(Boolean));
  const habitat = () => habitats().find((x) => x.key === cur) ?? habitats()[0];

  function syncActors() {
    yard.setCreatures(here().map((c) => {
      tickNeeds(app.idx, c);
      const sp = speciesOf(app.idx, c);
      const types = (sp?.types ?? []).join(' ');
      // speed stat sets how fast they scurry: slow ones plod, fast ones dart
      return { uid: c.uid, speciesId: spriteIdOf(c), sizeMul: sizeVariant(c).mult, name: displayName(app.idx, c), mood: mood(c).id, speed: c.egg ? 0 : 0.35 + (sp?.baseStats.spe ?? 50) / 45,
        swim: /water|tide/i.test(types), fly: /flying|gale/i.test(types), fire: /fire|ember/i.test(types) };
    }));
  }
  function syncPlots() {
    const farm = farmState(app.save);
    yard.setPlots(farm.plots.map((p) => plotStatus(app.idx, p)));
  }

  function switchTo(key) {
    if (key === cur) return;
    cur = key;
    app.ranchHabitat = key;
    selected = null; yard.selected = null;
    yard.actors.clear();
    yard.setBiome(habitat().biome, seedOf(key));
    syncActors();
    yard.materialize();
    sfx('warp');
    renderHud(); renderPanel();
  }
  const stepHabitat = (d) => { const l = habitats(); const i = l.findIndex((x) => x.key === cur); switchTo(l[(i + d + l.length) % l.length].key); };

  function care(uid, action, item, quiet = false, react = true) {
    let out;
    app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], action, { item, inventory: save.inventory }); }, 'care', { quiet: true });
    if (!out?.ok) { if (out?.reason && !quiet) toast(out.reason, 'err'); return; }
    const reaction = { hearts: 'hearts', munch: 'munch', delighted: 'hearts', play: 'hearts', sparkle: 'sparkle', listen: 'note', sleep: 'sleep', full: 'sad', tired: 'sleep' }[out.reaction] ?? 'hearts';
    if (react) yard.react(uid, reaction, reaction === 'hearts' ? 3 : 4);
    if (action === 'pet') sfx('heart');
    if (action === 'feed') sfx(out.reaction === 'full' ? 'back' : 'munch');
    if (action === 'groom') sfx('heal');
    const nm = displayName(app.idx, app.save.creatures[uid]);
    if (out.reaction === 'full') app.say(`${nm} is full.`);
    if (out.reaction === 'tired') app.say(`${nm} is too tired to play.`);
    if (!quiet || out.friendship) renderPanel();
  }

  // ---------- one on one: the care room ----------
  async function careRoom(uid) {
    await openCareRoom(app, uid, {
      biome: habitat()?.biome ?? 'meadow',
      doCare: (action, opts = {}) => {
        let out;
        app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], action, { ...opts, inventory: save.inventory }); }, 'care', { quiet: true });
        if (out && !out.ok && out.reason) toast(out.reason, 'err');
        return out;
      },
    });
    syncActors(); renderPanel(); renderHud();
  }
  // toss a berry into the yard: whoever gets there first eats it
  function tossBerry() {
    const foods = app.idx.ds.items.filter((it) => it.kind === 'food' && !it.unlimited && (app.save.inventory[it.id] ?? 0) > 0);
    const it = foods.find((f) => f.grow) ?? foods[0];
    if (!it) { toast('No berries to toss. Grow some on the berry farm.', 'err'); return; }
    yard.tossBerry(it);
    sfx('blip');
  }

  // ---------- the berry farm ----------
  async function plotClick(i) {
    const st = plotStatus(app.idx, farmState(app.save).plots[i]);
    if (st.ready) {
      let r;
      app.commit((s) => { r = harvest(app.idx, s, i); }, 'farm', { quiet: true });
      if (r?.ok) { sfx('level'); toast(`Picked ${r.count} ${r.item.name}.`, 'ok'); }
    } else if (st.empty) {
      const seeds = plantable(app.idx).filter((it) => it.unlimited || (app.save.inventory[it.id] ?? 0) > 0);
      const pick = await chooseDialog('Plant something', seeds.map((it) => ({ value: it.id, label: it.name, detail: `${app.save.inventory[it.id] ?? 0} in the bag · ripe in ${growInfo(it).hours} h · gives ${growInfo(it).yield}` })), { empty: 'Nothing to plant. Walks turn up berries and roots; plant one to grow more.' });
      if (!pick) return;
      let r;
      app.commit((s) => { r = plant(app.idx, s, i, pick); }, 'farm', { quiet: true });
      if (r && !r.ok) toast(r.reason, 'err'); else sfx('heal');
    } else toast(`${st.item?.name ?? 'It'} is ripe in ${fmtLeft(st.left)}.`);
    syncPlots(); renderPanel();
  }

  async function bring() {
    const to = cur === 'ranch' ? { kind: 'ranch' } : (() => { const t = firstFreeBoxSlot(app.save, 30, cur); return t && t.box === cur ? t : null; })();
    if (!to) { toast('This yard is full (30 creatures).', 'err'); return; }
    const options = list(app.save).filter((c) => ['party', 'box', 'ranch'].includes(c.location.kind) && !(cur === 'ranch' ? c.location.kind === 'ranch' : c.location.kind === 'box' && c.location.box === cur));
    const uid = await chooseDialog('Bring someone to this yard', options.map((c) => ({
      value: c.uid, label: displayName(app.idx, c), detail: `Lv. ${c.level} · ${c.location.kind === 'party' ? 'party' : c.location.kind === 'ranch' ? 'free range' : app.save.boxes[c.location.box]?.name}`,
      el: spriteCanvas(app.bank, c, { scale: 1 }),
    })), { empty: 'Everyone is already here.' });
    if (!uid) return;
    let r;
    app.commit((s) => { r = moveCreature(s, uid, { ...to }, app.idx.ds.rules.partySize); }, 'move', { quiet: true });
    if (r && !r.ok) { toast(r.error, 'err'); return; }
    syncActors();
    const a = yard.actors.get(uid);
    if (a) a.appear = -1.1; // shows up as the light lands
    const who = app.save.creatures[uid];
    const art = h('span', null, spriteCanvas(app.bank, who, { scale: 2 }));
    playTransfer({ to: yard.screenRect(uid), mode: 'arrive', spriteEl: art, tint: typeTint(who), say: transferLine(cur === 'ranch' ? 'ranch' : 'box', displayName(app.idx, who), { box: app.save.boxes[cur]?.name }) });
    renderHud();
  }

  function renderHud() {
    const hb = habitat();
    const n = here().length;
    const where = zone === 'yard' ? (typeof cur === 'number' ? `YARD ${String(cur + 1).padStart(2, '0')}` : 'FREE RANGE') : ZONES[zone].label.toUpperCase();
    mount(hudTL,
      h('div', { class: 'hud-kicker' }, 'R.A.N.C.H.', h('span', null, ` // ${where}`)),
      h('div', { class: 'hud-title' }, zone === 'yard' ? hb.name : ZONES[zone].label),
      h('div', { class: 'hud-sub' }, zone === 'yard' ? `${BIOME_INFO[hb.biome]?.label ?? hb.biome} · ${n} creature${n === 1 ? '' : 's'} here` : zone === 'farm' ? 'Plant food, pick it when ripe' : 'Opening soon'));
    mount(hudTR,
      h('div', { class: 'row' },
        h('button', { class: 'hud-btn', 'aria-label': 'Previous box', title: 'Previous box (Page Up)', onclick: () => stepHabitat(-1) }, '◀'),
        h('select', { class: 'hud-select', 'aria-label': 'Box', onchange: (e) => switchTo(e.target.value === 'ranch' ? 'ranch' : Number(e.target.value)) },
          habitats().map((x) => h('option', { value: String(x.key), selected: x.key === cur }, x.name))),
        h('button', { class: 'hud-btn', 'aria-label': 'Next box', title: 'Next box (Page Down)', onclick: () => stepHabitat(1) }, '▶'),
        h('button', { class: `hud-btn ${panelOpen ? 'on' : ''}`, title: 'Show or hide the side panel', onclick: () => { panelOpen = !panelOpen; renderPanel(); renderHud(); } }, panelOpen ? 'Hide log' : 'Log')),
      zone === 'yard' ? h('label', { class: 'row hud-env' }, h('span', null, 'Environment'),
        h('select', { class: 'hud-select', onchange: (e) => {
          const v = e.target.value;
          app.commit((s) => { if (cur === 'ranch') s.ranch = { ...(s.ranch || {}), biome: v }; else s.boxes[cur].biome = v; }, 'wallpaper', { quiet: true });
          yard.setBiome(v, seedOf(cur)); syncActors(); yard.materialize(); sfx('warp'); renderHud();
        } }, BIOME_IDS.map((id) => h('option', { value: id, selected: id === hb.biome }, BIOME_INFO[id].label)))) : null);
    mount(hudBottom,
      zone === 'yard' ? [
        h('button', { class: 'hud-btn wide', onclick: () => { yard.throwBall(); sfx('blip'); for (const c of here()) care(c.uid, 'play', null, true, false); } }, 'Throw a ball'),
        h('button', { class: 'hud-btn wide', onclick: tossBerry }, 'Toss a berry'),
        h('button', { class: 'hud-btn wide', onclick: bring }, 'Bring someone'),
        h('span', { class: 'hud-hint' }, 'Rub to pet · drag to pick up · fling to toss · drag the ground to look around'),
      ] : h('span', { class: 'hud-hint' }, zone === 'farm' ? 'Click a plot to plant or pick · drag the ground to look around' : 'The shopkeeper is still unpacking'),
      h('span', { class: 'hud-orbit' },
        h('button', { class: 'hud-btn', title: 'Turn left (Q)', 'aria-label': 'Turn the view left', onclick: () => yard.turn(-1) }, '⟲'),
        h('button', { class: 'hud-btn', title: 'Face the yard (R)', 'aria-label': 'Face the yard', onclick: () => yard.turn(0) }, '◎'),
        h('button', { class: 'hud-btn', title: 'Turn right (E)', 'aria-label': 'Turn the view right', onclick: () => yard.turn(1) }, '⟳')),
      h('span', { class: 'hud-link', title: 'Live data link to this yard' }, h('i'), 'LINK STABLE'));
    const ord = ['farm', 'yard', 'shop'], i = ord.indexOf(zone);
    const prev = ord[i - 1], next = ord[i + 1];
    edgeL.hidden = !prev; edgeR.hidden = !next;
    if (prev) mount(edgeL, h('span', { class: 'chev' }, '◀'), h('span', null, prev === 'yard' ? 'Yard' : ZONES[prev].label));
    if (next) mount(edgeR, h('span', { class: 'chev' }, '▶'), h('span', null, next === 'yard' ? 'Yard' : ZONES[next].label));
  }

  function farmPanel() {
    const farm = farmState(app.save);
    const seeds = plantable(app.idx);
    return [
      h('div', { class: 'holo-head' }, 'Berry farm'),
      h('p', { class: 'holo-dim' }, 'Plant one of a food from your bag and pick several when it ripens. Plants keep growing while the app is closed.'),
      h('div', { class: 'holo-list' }, farm.plots.slice(0, FARM_PLOTS).map((p, i) => {
        const st = plotStatus(app.idx, p);
        return h('button', { class: 'holo-row', onclick: () => plotClick(i) },
          h('span', { class: 'plot-dot', style: { background: st.empty ? '#6b4423' : st.item?.color ?? '#3fb26a' } }),
          h('span', { class: 'grow' }, st.empty ? `Plot ${i + 1}: empty` : `${st.item?.name ?? st.itemId}`),
          h('span', { class: 'holo-dim' }, st.empty ? 'Plant' : st.ready ? 'Ready!' : fmtLeft(st.left)));
      })),
      h('div', { class: 'holo-head' }, 'Seeds in the bag'),
      h('div', { class: 'kv holo-kv' }, seeds.map((it) => [h('span', null, it.name), h('span', null, `× ${app.save.inventory[it.id] ?? 0}`)])),
    ];
  }
  function shopPanel() {
    return [
      h('div', { class: 'holo-head' }, 'Shop'),
      h('p', null, 'The stall is up and the shopkeeper bot is unpacking.'),
      h('p', { class: 'holo-dim' }, 'Coming later: buying treats, toys and seeds. What it sells and what things cost will be set in the Data Lab like everything else.'),
    ];
  }

  function renderPanel() {
    panel.classList.toggle('open', panelOpen);
    el.classList.toggle('panel-open', panelOpen);
    if (zone === 'farm') { mount(panel, farmPanel()); return; }
    if (zone === 'shop') { mount(panel, shopPanel()); return; }
    const c = selected && app.save.creatures[selected];
    const inHere = c && here().some((x) => x.uid === c.uid);
    if (!inHere) {
      const folk = here();
      mount(panel,
        h('div', { class: 'holo-head' }, 'Yard log'),
        h('p', { class: 'holo-dim' }, `${RANCH_NAME}. Whoever is in this box lives in this yard. Click someone to look after them.`),
        folk.length ? h('div', { class: 'holo-list' }, folk.map((x) => h('button', { class: 'holo-row', onclick: () => { selected = x.uid; yard.selected = x.uid; sfx('move'); renderPanel(); } },
          spriteCanvas(app.bank, x, { scale: 1 }), h('span', { class: 'grow' }, displayName(app.idx, x)), h('span', { class: 'holo-dim' }, mood(x).label))))
          : h('p', { class: 'holo-dim' }, 'Nobody lives here yet. Bring someone, or move creatures into this box from the storage system.'),
        h('div', { class: 'holo-head' }, 'Bag'),
        (() => {
          const inv = Object.entries(app.save.inventory ?? {}).filter(([, n]) => n > 0);
          return inv.length ? h('div', { class: 'kv holo-kv' }, inv.map(([id, n]) => [h('span', null, app.idx.items.get(id)?.name ?? id), h('span', null, `× ${n}`)])) : h('p', { class: 'holo-dim' }, 'Empty. Walks turn up treats and toys.');
        })());
      return;
    }
    const foods = app.idx.ds.items.filter((it) => it.kind === 'food' && (it.unlimited || (app.save.inventory[it.id] ?? 0) > 0));
    const grooms = app.idx.ds.items.filter((it) => it.kind === 'groom' && (it.unlimited || (app.save.inventory[it.id] ?? 0) > 0));
    const count = (it) => (it.unlimited ? '' : ` (${app.save.inventory[it.id] ?? 0})`);
    const actions = h('div', { class: 'col' },
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn primary', onclick: () => careRoom(c.uid) }, 'One on one'),
        h('button', { class: 'btn', onclick: () => care(c.uid, 'pet') }, 'Pet'),
        h('button', { class: 'btn', onclick: () => { yard.throwBall(); care(c.uid, 'play'); } }, 'Play'),
        h('button', { class: 'btn', onclick: () => { creatureCry(speciesOf(app.idx, c), c); care(c.uid, 'talk'); } }, 'Call'),
        h('button', { class: 'btn', onclick: () => care(c.uid, 'rest') }, 'Nap')),
      foods.length ? h('div', { class: 'row wrap' }, h('span', { class: 'dim' }, 'Feed'), foods.map((it) => h('button', { class: 'btn small', title: it.desc, onclick: () => care(c.uid, 'feed', it.id) }, it.name + count(it)))) : null,
      grooms.length ? h('div', { class: 'row wrap' }, h('span', { class: 'dim' }, 'Groom'), grooms.map((it) => h('button', { class: 'btn small', title: it.desc, onclick: () => care(c.uid, 'groom', it.id) }, it.name + count(it)))) : null,
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small', disabled: party(app.save).length >= app.idx.ds.rules.partySize, onclick: () => {
          const rect = yard.screenRect(c.uid);
          let r; app.commit((s) => { r = moveCreature(s, c.uid, { kind: 'party' }, app.idx.ds.rules.partySize); }, 'move', { quiet: true });
          if (r && !r.ok) return toast(r.error, 'err');
          const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
          selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
          if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: typeTint(c), say: transferLine('party', displayName(app.idx, c)) });
          else sfx('access');
        } }, 'Take into party'),
        h('button', { class: 'btn small danger', onclick: async () => {
          const name = displayName(app.idx, c);
          if (!(await confirmDialog(`Release ${name}?`, `${name} will return to the wild for good. This can’t be undone.`, { ok: 'Release', danger: true }))) return;
          const rect = yard.screenRect(c.uid);
          const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
          app.commit((s) => releaseCreature(s, c.uid), 'release', { quiet: true });
          selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
          const say = `${name} looked back once, then headed off into the wild.`;
          if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: '#ffffff', say });
          app.say(say);
        } }, 'Release'),
        h('button', { class: 'btn small', onclick: () => { app.commit((s) => { s.settings.petUid = c.uid; s.settings.petEnabled = true; }); toast(`${displayName(app.idx, c)} is your desktop buddy.`, 'ok'); } }, 'Desktop buddy'),
        h('button', { class: 'btn small', onclick: () => { selected = null; yard.selected = null; panelOpen = false; renderPanel(); renderHud(); } }, 'Close')));
    mount(panel, creatureSummary(app.idx, app.bank, c, { compact: true, sections: ['care', 'walk'], actions }));
  }

  const onKey = (e) => {
    if (e.target.closest?.('input, select, textarea')) return;
    if (e.key === 'ArrowLeft') yard.step(-1);
    else if (e.key === 'ArrowRight') yard.step(1);
    else if (e.key === 'q' || e.key === 'Q') yard.turn(-1);
    else if (e.key === 'e' || e.key === 'E') yard.turn(1);
    else if (e.key === 'r' || e.key === 'R') yard.turn(0);
    else if (e.key === 'PageUp') stepHabitat(-1);
    else if (e.key === 'PageDown') stepHabitat(1);
    else if (e.key === 'Escape') { selected = null; yard.selected = null; panelOpen = false; renderPanel(); renderHud(); }
    else return;
    e.preventDefault();
  };

  function update() { syncActors(); syncPlots(); renderHud(); renderPanel(); }

  update();
  let plotTimer = null;
  return {
    el,
    mounted() {
      yard.resize();
      yard.materialize();
      yard.start();
      window.addEventListener('keydown', onKey);
      plotTimer = setInterval(() => { syncPlots(); if (zone === 'farm') renderPanel(); }, 30000);
      setTimeout(() => intro.classList.add('done'), 900);
      canvas.focus({ preventScroll: true });
    },
    update,
    art: () => {},
    tick: () => { syncActors(); syncPlots(); renderPanel(); },
    dispose() { yard.stop(); clearInterval(plotTimer); window.removeEventListener('keydown', onKey); },
  };
}
