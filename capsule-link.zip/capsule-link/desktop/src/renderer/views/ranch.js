// R.A.N.C.H. (Remote Access Nurture & Care Hub): areas you load into. Each box has its own yard
// (in the box's environment), which you can build up with blueprints from the Market; the berry farm
// is an area of its own. With a Link gate, a friend's yard (brought over as a file) joins yours.
// In a yard: pet by rubbing, pick creatures up and carry or fling them, throw toys and berries
// (from the bag), and watch them play. Mouse wheel or − / + zoom, drag the ground to look around.
import { h, mount, toast, chooseDialog, confirmDialog } from '../../../../shared/ui/dom.js';
import { sizeVariant } from '../../../../shared/ui/creatureSize.js';
import { Yard, toyKindOf, EXTRA_TOYS } from '../../../../shared/ui/yard.js';
import { spriteCanvas, spriteIdOf } from '../../../../shared/ui/art.js';
import { BIOME_IDS, BIOME_INFO } from '../../../../shared/ui/biomes.js';
import { creatureSummary, formPicker } from '../../../../shared/ui/summary.js';
import { playTransfer, transferLine } from '../../../../shared/ui/transfer.js';
import { sfx, creatureCry } from '../../../../shared/ui/audio.js';
import * as Paint from '../../../../shared/ui/paint.js';
import {
  atKind, displayName, applyCare, mood, tickNeeds, moveCreature, firstFreeBoxSlot, speciesOf, list, boxContents, party,
  farmState, plotStatus, plant, harvest, plantable, growInfo, FARM_PLOTS, releaseCreature, favorites, CARE_TOYS, friendsOf,
  wallet, itemInfo, setForm, toggleBuddy, isDesktopBuddy, movementOf, traitsOf, playedTogether, timeOfDay, napWait, holdable, allFoods,
  yardBuild, placeFeature, moveFeature, removeFeature, expandYard, appeal, featureLife, thriveReport, blueprintOf, bpId, BLUEPRINTS,
  YARD_SIZES, MAX_YARD_SIZE, featureRoom, ranchSnapshot, readSnapshot, experience, addMemory,
} from '../../../../shared/engine/index.js';
import { RANCH_NAME } from './home.js';
import { openCareRoom } from './careRoom.js';
import { openDressUp, clothesImg } from './dressUp.js';

const fmtLeft = (ms) => { const m = Math.ceil(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`; };
const AREAS = [['yard', 'Yard'], ['farm', 'Berry farm']];

/** What a creature looks like to the yard (shared with the care room). */
export function actorOf(app, c) {
  tickNeeds(app.idx, c);
  const sp = speciesOf(app.idx, c);
  const types = sp?.types ?? [];
  const typeNames = types.map((t) => app.idx.types.get(t)?.name ?? t);
  const all = [...types, ...typeNames].join(' ');
  const mv = movementOf(app.idx, sp, c);
  return {
    uid: c.uid, speciesId: spriteIdOf(c), sizeMul: sizeVariant(c).mult, name: displayName(app.idx, c), mood: mood(c).id,
    // speed stat sets how fast they scurry: slow ones plod, fast ones dart
    speed: c.egg ? 0 : 0.35 + (sp?.baseStats?.spe ?? 50) / 45,
    swim: mv.swim, fly: !c.egg && mv.float, canFly: !c.egg && mv.canFly, waterOnly: !mv.walk && mv.swim, prefersWater: mv.def === 'swim', fire: /fire|ember/i.test(all),
    types: [...types, ...typeNames], egg: !!c.egg,
    ...traitsOf(app.idx, c),
    friends: friendsOf(c).map((f) => f.uid),
    clothes: (c.clothes ?? []).map((w) => ({ ...w, img: clothesImg(app.idx, w.id) })).filter((w) => w.img),
  };
}

export function ranchView(app) {
  const typeTint = (c) => app.idx.types.get(app.idx.species.get(c.speciesId)?.types?.[0])?.color ?? '#9fe8ff';
  const habitats = () => {
    const out = app.save.boxes.map((b, i) => ({ key: i, name: b.name, biome: b.biome ?? 'meadow' }));
    if (atKind(app.save, 'ranch').length) out.push({ key: 'ranch', name: app.save.ranch?.name ?? 'Free range', biome: app.save.ranch?.biome ?? 'meadow' });
    return out;
  };
  let cur = app.ranchHabitat ?? 0;
  if (!habitats().some((x) => x.key === cur)) cur = 0;
  let selected = null;
  let area = 'yard';
  let panelOpen = false;
  let lastPet = 0;
  let menu = null; // 'toys' | 'food' | null
  const playLog = new Map();
  const visitLog = new Map();
  // build mode: placing a blueprint, or moving something already built
  let building = !!app.ranchBuild; app.ranchBuild = false;
  let placing = null;      // a blueprint id from the bag
  let picked = null;       // a feature id (to move or put away)
  let guests = null;       // a friend's yard brought over through the Link gate: { snap, key }

  const canvas = h('canvas', { class: 'hab-canvas', tabindex: '0', 'aria-label': 'The yard. Rub a creature to pet it, drag it to carry it, let go to drop it. Drag the ground to look around, scroll to zoom.' });
  const hudTL = h('div', { class: 'hud hud-tl' });
  const hudTR = h('div', { class: 'hud hud-tr' });
  const hudBottom = h('div', { class: 'hud hud-bottom' });
  const menuEl = h('div', { class: 'hud-menu', hidden: true });
  const panel = h('aside', { class: 'holo-panel' });
  const intro = h('div', { class: 'hab-intro', 'aria-hidden': 'true' }, h('div', { class: 'rings' }, h('i'), h('i'), h('i')), h('div', { class: 'intro-text' }, 'R.A.N.C.H.', h('small', null, 'opening the gate…')));
  const el = h('div', { class: 'ranchvr' }, canvas, hudTL, hudTR, hudBottom, menuEl, panel, intro, h('div', { class: 'hud-frame', 'aria-hidden': 'true' }));

  const seedOf = (key) => (typeof key === 'number' ? key : 99) + 1;
  const yard = new Yard(canvas, {
    bank: app.bank,
    accent: app.save.trainer?.card?.accent,
    resolveTexture: (p) => app.textures[p.toLowerCase()] ?? null,
    biome: habitats().find((x) => x.key === cur)?.biome,
    seed: seedOf(cur),
    sizeScale: app.save.settings?.ranchScale ?? 1,
    onSelect: (uid) => { selected = uid; if (uid) { panelOpen = true; sfx('move'); } closeMenu(); renderPanel(); renderHud(); },
    onPet: (uid) => { const now = Date.now(); if (now - lastPet < 300) return; lastPet = now; care(uid, 'pet', null, true, true, 0.3); },
    onDrop: (uid, speed) => {
      if (speed > 4) { yard.react(uid, 'dizzy', 2); sfx('miss'); care(uid, 'play', null, true, false); }
      else { yard.react(uid, 'sparkle', 2); sfx('blip'); }
    },
    onPlot: (i) => plotClick(i),
    onPlace: (at) => placeAt(at),
    onFeature: (fid) => { picked = picked === fid ? null : fid; placing = null; yard.pickedFeature = picked; sfx('move'); renderPanel(); renderHud(); },
    onFeatureVisit: (uid, bp) => {
      const now = Date.now();
      if (!app.save.creatures[uid] || now - (visitLog.get(uid) ?? 0) < 60000) return;
      visitLog.set(uid, now);
      app.commit((s) => { const c = s.creatures[uid]; if (c) experience(c, [`feature:${bp}`], 3 + appeal(app.idx, c, bp) * 4, { t: now, coreChance: 0 }); }, 'visit', { quiet: true });
    },
    onBounce: (t, hit) => { if (hit > 5) sfx('blip'); },
    tod: timeOfDay(),
    onPlayTogether: (a, b) => {
      const key = [a, b].sort().join(':'), now = Date.now();
      if (now - (playLog.get(key) ?? 0) < 20000) return;
      playLog.set(key, now);
      // one of them is visiting from a friend's yard: a memory for ours
      const guest = [a, b].find((u) => String(u).startsWith('guest:'));
      if (guest) {
        const mine = a === guest ? b : a, g = guests?.snap.creatures.find((x) => `guest:${x.uid}` === guest);
        if (g && app.save.creatures[mine]) {
          app.commit((s) => { const c = s.creatures[mine]; c.metGuests = c.metGuests || {}; if (!c.metGuests[g.uid]) { c.metGuests[g.uid] = now; addMemory(c, `Played with ${g.name} from ${guests.snap.trainer.name}’s ranch.`, now, { core: Object.keys(c.metGuests).length <= 3 }); } }, 'guest', { quiet: true });
        }
        return;
      }
      let r; app.commit((s) => { r = playedTogether(app.idx, s, a, b, now); }, 'bond', { quiet: true });
      if (r?.friends) app.say(`${displayName(app.idx, app.save.creatures[a])} and ${displayName(app.idx, app.save.creatures[b])} became friends playing together!`);
    },
    onEat: (uid, item) => {
      const c = app.save.creatures[uid];
      if (!c || !item?.id) return;
      const fav = favorites(app.idx, c);
      let out;
      app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], 'feed', { item: item.id, favorite: item.id === fav.berry, inventory: save.inventory, direct: false }); }, 'care', { quiet: true });
      if (out?.ok) { yard.react(uid, out.reaction === 'delighted' ? 'hearts' : out.reaction === 'full' ? 'sad' : 'munch', 4); sfx('munch'); app.say(`${displayName(app.idx, c)} ${out.reaction === 'full' ? 'sniffed the' : 'ate the'} ${item.name}${out.reaction === 'delighted' ? ' — a favourite!' : out.reaction === 'full' ? ', but is full.' : '.'}`); }
      else if (out?.reason) toast(out.reason, 'err');
      renderPanel(); if (menu) renderMenu();
    },
    onPlay: (uid, kind, item) => {
      const c = app.save.creatures[uid];
      if (!c) return;
      const id = item?.id ?? kind;
      const fav = favorites(app.idx, c);
      let out;
      app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], 'play', { toy: id, toyName: item?.name, favorite: id === fav.toy, inventory: save.inventory, direct: false }); }, 'care', { quiet: true });
      if (out?.ok && out.reaction === 'delighted') { yard.react(uid, 'hearts', 3); app.say(`${displayName(app.idx, c)} loves the ${item?.name ?? kind}!`); }
      else if (out?.reaction === 'tired') yard.emote(uid, 'tired', false);
      if (selected === uid) renderPanel();
    },
  });

  // creatures out on the desktop aren't in the yard while they're out there
  const residents = () => (cur === 'ranch' ? atKind(app.save, 'ranch') : boxContents(app.save, cur).filter(Boolean));
  const here = () => residents().filter((c) => !isDesktopBuddy(app.save, c.uid));
  const outOnDesktop = () => residents().filter((c) => isDesktopBuddy(app.save, c.uid));
  const habitat = () => habitats().find((x) => x.key === cur) ?? habitats()[0];

  const buildOf = () => yardBuild(app.save, cur);
  function syncActors() {
    yard.tod = timeOfDay();
    const folk = area === 'yard' ? here() : [];
    // the yard's size and what's built there (features come alive with the right residents)
    if (area === 'yard') {
      const b = buildOf();
      yard.setYardSize(b.size ?? 0);
      yard.setFeatures(b.features.map((f) => ({ ...f, life: featureLife(app.idx, f.bp, folk) })));
    }
    const feats = area === 'yard' ? buildOf().features : [];
    const actors = folk.map((c) => ({ ...actorOf(app, c), featLikes: Object.fromEntries(feats.map((f) => [f.id, appeal(app.idx, c, f.bp)])) }));
    // visitors through the Link gate
    if (area === 'yard' && guests?.key === cur) for (const g of guests.snap.creatures) actors.push({ uid: `guest:${g.uid}`, speciesId: app.idx.species.has(g.formId ?? '') ? g.formId : g.speciesId, name: `${g.name} (${guests.snap.trainer.name})`, mood: 'happy', speed: 1.3, sizeMul: 1, types: g.types ?? [], friends: [], clothes: [], guest: true, temper: 'playful' });
    yard.setCreatures(actors);
  }
  function syncPlots() { yard.setPlots(farmState(app.save).plots.map((p) => plotStatus(app.idx, p))); }

  function goArea(a) {
    if (a === area) return;
    area = a;
    selected = null; yard.selected = null;
    closeMenu();
    yard.setScene(a, habitat().biome, seedOf(cur));
    syncActors(); syncPlots();
    yard.materialize();
    panelOpen = a !== 'yard';
    sfx('warp');
    renderHud(); renderPanel();
  }
  function switchTo(key) {
    if (key === cur && area === 'yard') return;
    cur = key;
    app.ranchHabitat = key;
    selected = null; yard.selected = null;
    yard.actors.clear();
    area = 'yard';
    placing = null; picked = null; yard.pickedFeature = null;
    const b = buildOf();
    yard.yardSize = b.size ?? 0;
    yard.features = []; yard.featKey = null;
    yard.setScene('yard', habitat().biome, seedOf(key));
    syncActors();
    yard.materialize();
    sfx('warp');
    renderHud(); renderPanel();
  }
  const stepHabitat = (d) => { const l = habitats(); const i = l.findIndex((x) => x.key === cur); switchTo(l[(i + d + l.length) % l.length].key); };

  function care(uid, action, item, quiet = false, react = true, weight = 1) {
    let out;
    app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], action, { item, inventory: save.inventory, weight }); }, 'care', { quiet: true });
    if (!out?.ok) { if (out?.reason && !quiet) toast(out.reason, 'err'); return; }
    const nm0 = displayName(app.idx, app.save.creatures[uid]);
    if (out.reaction === 'annoyed') { yard.react(uid, 'sad', 4); yard.emote(uid, 'angry', false); sfx('miss'); app.say(`${nm0} has had enough and is upset with you. Give them some space.`); renderPanel(); return; }
    if (out.reaction === 'awake') { yard.emote(uid, 'meh', false); if (!quiet) app.say(`${nm0}: ${out.reason}`); renderPanel(); return; }
    const reaction = { hearts: 'hearts', munch: 'munch', delighted: 'hearts', play: 'hearts', sparkle: 'sparkle', listen: 'note', sleep: 'sleep', full: 'sad', tired: 'sleep', meh: 'note' }[out.reaction] ?? 'hearts';
    if (out.reaction === 'meh' && !quiet) app.say(`${nm0} is getting a bit tired of that.`);
    if (react) yard.react(uid, reaction, reaction === 'hearts' ? 3 : 4);
    if (action === 'pet') sfx('heart');
    if (action === 'feed') sfx(out.reaction === 'full' ? 'back' : 'munch');
    if (action === 'groom') sfx('heal');
    const nm = displayName(app.idx, app.save.creatures[uid]);
    if (out.reaction === 'full') app.say(`${nm} is full.`);
    if (out.reaction === 'tired') app.say(`${nm} is too tired to play.`);
    if (!quiet || out.friendship) renderPanel();
  }

  // ---------- quality time: the care room ----------
  async function careRoom(uid) {
    yard.stop();
    await openCareRoom(app, uid, {
      biome: habitat()?.biome ?? 'meadow',
      seed: seedOf(cur),
      doCare: (action, opts = {}) => {
        let out;
        app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], action, { ...opts, inventory: save.inventory }); }, 'care', { quiet: true });
        if (out && !out.ok && out.reason) toast(out.reason, 'err');
        return out;
      },
    });
    yard.start();
    syncActors(); renderPanel(); renderHud();
  }

  // ---------- toys and berries from the bag ----------
  const toyList = () => [...CARE_TOYS, ...EXTRA_TOYS, ...app.idx.ds.items.filter((i) => i.kind === 'toy' && (i.unlimited || (app.save.inventory[i.id] ?? 0) > 0))];
  const foodList = () => allFoods(app.idx).filter((it) => !it.unlimited && (app.save.inventory[it.id] ?? 0) > 0);
  function closeMenu() { menu = null; menuEl.hidden = true; renderHud(); }
  function openMenu(kind) { menu = menu === kind ? null : kind; renderMenu(); renderHud(); }
  function renderMenu() {
    menuEl.hidden = !menu;
    if (!menu) return;
    if (menu === 'toys') {
      mount(menuEl,
        h('div', { class: 'hud-menu-head' }, 'Throw a toy'),
        h('div', { class: 'hud-menu-grid' }, toyList().map((it) => {
          const kind = toyKindOf(it);
          const pic = Paint.toy(kind, { w: 40, h: 40 }); pic.className = 'hud-menu-pic';
          return h('button', { class: 'hud-menu-item', title: it.desc ?? '', onclick: () => { yard.throwToy(kind, it); sfx('blip'); } }, pic, h('span', null, it.name));
        })),
        h('div', { class: 'row' }, h('button', { class: 'hud-btn', onclick: () => { yard.clearToys(); sfx('back'); } }, 'Put the toys away'), h('span', { class: 'hud-hint' }, 'Drag a toy to pick it up and fling it.')));
    } else {
      const foods = foodList();
      mount(menuEl,
        h('div', { class: 'hud-menu-head' }, 'Toss a berry'),
        foods.length ? h('div', { class: 'hud-menu-grid' }, foods.map((it) => h('button', { class: 'hud-menu-item', title: it.desc ?? '', onclick: () => { if ((app.save.inventory[it.id] ?? 0) <= yard.toys.filter((t) => t.item?.id === it.id).length) { toast(`No more ${it.name} to toss.`, 'err'); return; } yard.tossBerry(it); sfx('blip'); } },
          h('span', { class: 'hud-menu-dot', style: { background: it.color ?? '#c98a3a' } }), h('span', null, it.name), h('small', null, `× ${app.save.inventory[it.id] ?? 0}`))))
          : h('p', { class: 'holo-dim' }, 'No berries in the bag. Grow some on the berry farm or buy them at the Market.'),
        h('span', { class: 'hud-hint' }, 'Whoever gets there first eats it.'));
    }
  }

  // ---------- the berry farm ----------
  async function plotClick(i) {
    const st = plotStatus(app.idx, farmState(app.save).plots[i]);
    if (st.ready) {
      let r;
      app.commit((s) => { r = harvest(app.idx, s, i); }, 'farm', { quiet: true });
      if (r?.ok) { sfx('level'); toast(`Picked ${r.count} ${r.item.name}.`, 'ok'); }
    } else if (st.empty) {
      const seeds = plantable(app.idx).filter((it) => it.unlimited || (app.save.inventory[it.id] ?? 0) > 0);
      const pick = await chooseDialog('Plant something', seeds.map((it) => ({ value: it.id, label: it.name, detail: `${app.save.inventory[it.id] ?? 0} in the bag · ripe in ${growInfo(it).hours} h · gives ${growInfo(it).yield}` })), { empty: 'Nothing to plant. Walks turn up berries and roots, and the Market sells them; plant one to grow more.' });
      if (!pick) return;
      let r;
      app.commit((s) => { r = plant(app.idx, s, i, pick); }, 'farm', { quiet: true });
      if (r && !r.ok) toast(r.reason, 'err'); else sfx('heal');
    } else toast(`${st.item?.name ?? 'It'} is ripe in ${fmtLeft(st.left)}.`);
    syncPlots(); renderPanel();
  }

  async function bring() {
    const to = cur === 'ranch' ? { kind: 'ranch' } : (() => { const t = firstFreeBoxSlot(app.save, 30, cur); return t && t.box === cur ? t : null; })();
    if (!to) { toast('This yard is full (30 creatures).', 'err'); return; }
    const options = list(app.save).filter((c) => ['party', 'box', 'ranch'].includes(c.location.kind) && !(cur === 'ranch' ? c.location.kind === 'ranch' : c.location.kind === 'box' && c.location.box === cur));
    const uid = await chooseDialog('Bring someone to this yard', options.map((c) => ({
      value: c.uid, label: displayName(app.idx, c), detail: `Lv. ${c.level} · ${c.location.kind === 'party' ? 'party' : c.location.kind === 'ranch' ? 'free range' : app.save.boxes[c.location.box]?.name}`,
      el: spriteCanvas(app.bank, c, { scale: 1 }),
    })), { empty: 'Everyone is already here.' });
    if (!uid) return;
    let r;
    app.commit((s) => { r = moveCreature(s, uid, { ...to }, app.idx.ds.rules.partySize); }, 'move', { quiet: true });
    if (r && !r.ok) { toast(r.error, 'err'); return; }
    syncActors();
    const a = yard.actors.get(uid);
    if (a) a.appear = -1.1; // shows up as the light lands
    const who = app.save.creatures[uid];
    const art = h('span', null, spriteCanvas(app.bank, who, { scale: 2 }));
    playTransfer({ to: yard.screenRect(uid), mode: 'arrive', spriteEl: art, tint: typeTint(who), say: transferLine(cur === 'ranch' ? 'ranch' : 'box', displayName(app.idx, who), { box: app.save.boxes[cur]?.name }) });
    renderHud();
  }

  function renderHud() {
    const hb = habitat();
    const n = here().length;
    const where = area === 'yard' ? (typeof cur === 'number' ? `YARD ${String(cur + 1).padStart(2, '0')}` : 'FREE RANGE') : 'BERRY FARM';
    mount(hudTL,
      h('div', { class: 'hud-kicker' }, 'R.A.N.C.H.', h('span', null, ` // ${where}`)),
      h('div', { class: 'hud-title' }, area === 'yard' ? hb.name : 'Berry farm'),
      h('div', { class: 'hud-sub' }, area === 'yard' ? `${BIOME_INFO[hb.biome]?.label ?? hb.biome} · ${YARD_SIZES[buildOf().size ?? 0].label} · ${n} creature${n === 1 ? '' : 's'} here${guests?.key === cur ? ` · ${guests.snap.creatures.length} visiting` : ''}` : 'Plant food, pick it when ripe'),
      h('div', { class: 'hud-areas', role: 'tablist', 'aria-label': 'Area' }, AREAS.map(([id, label]) => h('button', { class: `hud-btn ${area === id ? 'on' : ''}`, role: 'tab', 'aria-selected': String(area === id), onclick: () => goArea(id) }, label))));
    mount(hudTR,
      h('div', { class: 'row' },
        h('button', { class: 'hud-btn', 'aria-label': 'Previous box', title: 'Previous box (Page Up)', onclick: () => stepHabitat(-1) }, '◀'),
        h('select', { class: 'hud-select', 'aria-label': 'Box', onchange: (e) => switchTo(e.target.value === 'ranch' ? 'ranch' : Number(e.target.value)) },
          habitats().map((x) => h('option', { value: String(x.key), selected: x.key === cur }, x.name))),
        h('button', { class: 'hud-btn', 'aria-label': 'Next box', title: 'Next box (Page Down)', onclick: () => stepHabitat(1) }, '▶'),
        h('button', { class: `hud-btn ${panelOpen ? 'on' : ''}`, title: 'Show or hide the side panel', onclick: () => { panelOpen = !panelOpen; renderPanel(); renderHud(); } }, panelOpen ? 'Hide log' : 'Log')),
      area === 'yard' ? h('label', { class: 'row hud-env' }, h('span', null, 'Environment'),
        h('select', { class: 'hud-select', onchange: (e) => {
          const v = e.target.value;
          app.commit((s) => { if (cur === 'ranch') s.ranch = { ...(s.ranch || {}), biome: v }; else s.boxes[cur].biome = v; }, 'wallpaper', { quiet: true });
          yard.setBiome(v, seedOf(cur)); syncActors(); yard.materialize(); sfx('warp'); renderHud();
        } }, BIOME_IDS.map((id) => h('option', { value: id, selected: id === hb.biome }, BIOME_INFO[id].label)))) : null);
    mount(hudBottom,
      area === 'yard' && building ? [
        h('button', { class: 'hud-btn wide on', onclick: () => setBuilding(false) }, 'Done building'),
        h('span', { class: 'hud-hint' }, placing ? `Click the ground to place the ${blueprintOf(placing)?.name}` : picked ? 'Click the ground to move it there · or put it away from the panel' : 'Pick a blueprint from the panel, or click something built to move it'),
      ] : area === 'yard' ? [
        h('button', { class: `hud-btn wide ${menu === 'toys' ? 'on' : ''}`, 'aria-expanded': String(menu === 'toys'), onclick: () => openMenu('toys') }, 'Toys ▴'),
        h('button', { class: `hud-btn wide ${menu === 'food' ? 'on' : ''}`, 'aria-expanded': String(menu === 'food'), onclick: () => openMenu('food') }, 'Berries ▴'),
        h('button', { class: 'hud-btn wide', onclick: bring }, 'Bring someone'),
        h('button', { class: 'hud-btn wide', title: 'Place blueprints from the Market, expand the yard, see who thrives here', onclick: () => setBuilding(true) }, 'Build'),
        h('span', { class: 'hud-hint' }, 'Rub to pet · drag to pick up · fling to toss · drag the ground to look around · scroll to zoom'),
      ] : h('span', { class: 'hud-hint' }, 'Click a plot to plant or pick · drag the ground to look around'),
      h('span', { class: 'hud-orbit' },
        h('button', { class: 'hud-btn', title: 'Zoom in (+)', 'aria-label': 'Zoom in', onclick: () => yard.zoom(-1) }, '+'),
        h('button', { class: 'hud-btn', title: 'Zoom out (−)', 'aria-label': 'Zoom out', onclick: () => yard.zoom(1) }, '−'),
        h('button', { class: 'hud-btn', title: 'Turn left (Q)', 'aria-label': 'Turn the view left', onclick: () => yard.turn(-1) }, '⟲'),
        h('button', { class: 'hud-btn', title: 'Face the front (R)', 'aria-label': 'Reset the view', onclick: () => { yard.turn(0); yard.zoom(0); } }, '◎'),
        h('button', { class: 'hud-btn', title: 'Turn right (E)', 'aria-label': 'Turn the view right', onclick: () => yard.turn(1) }, '⟳')),
      h('span', { class: 'hud-link', title: 'Live data link to this area' }, h('i'), 'LINK STABLE'));
  }

  function farmPanel() {
    const farm = farmState(app.save);
    const seeds = plantable(app.idx);
    return [
      h('div', { class: 'holo-head' }, 'Berry farm'),
      h('p', { class: 'holo-dim' }, 'Plant one of a food from your bag and pick several when it ripens. Plants keep growing while the app is closed.'),
      h('div', { class: 'holo-list' }, farm.plots.slice(0, FARM_PLOTS).map((p, i) => {
        const st = plotStatus(app.idx, p);
        return h('button', { class: 'holo-row', onclick: () => plotClick(i) },
          h('span', { class: 'plot-dot', style: { background: st.empty ? '#6b4423' : st.item?.color ?? '#3fb26a' } }),
          h('span', { class: 'grow' }, st.empty ? `Plot ${i + 1}: empty` : `${st.item?.name ?? st.itemId}`),
          h('span', { class: 'holo-dim' }, st.empty ? 'Plant' : st.ready ? 'Ready!' : fmtLeft(st.left)));
      })),
      h('div', { class: 'holo-head' }, 'Seeds in the bag'),
      h('div', { class: 'kv holo-kv' }, seeds.map((it) => [h('span', null, it.name), h('span', null, `× ${app.save.inventory[it.id] ?? 0}`)])),
    ];
  }
  // ---------- building: blueprints from the Market ----------
  function setBuilding(on) {
    building = on; placing = null; picked = null;
    yard.buildMode = on; yard.pickedFeature = null;
    closeMenu();
    if (on) { panelOpen = true; selected = null; yard.selected = null; }
    sfx(on ? 'access' : 'back');
    renderPanel(); renderHud();
  }
  function placeAt(at) {
    if (!building) return;
    let r;
    if (placing) {
      app.commit((s) => { r = placeFeature(s, cur, placing, at.x, at.z); }, 'build', { quiet: true });
      if (!r?.ok) { toast(r?.reason ?? 'Couldn’t build that here.', 'err'); return; }
      sfx('level'); app.say(`Built the ${blueprintOf(placing)?.name}.`);
      if ((app.save.inventory[bpId(placing)] ?? 0) <= 0) placing = null;
    } else if (picked) {
      app.commit((s) => { r = moveFeature(s, cur, picked, at.x, at.z); }, 'build', { quiet: true });
      sfx('blip');
    } else return;
    syncActors(); renderPanel(); renderHud();
  }
  function buildPanel() {
    const b = buildOf();
    const folk = here();
    const owned = BLUEPRINTS.filter((bp) => bp.kind !== 'expand' && (app.save.inventory[bpId(bp.id)] ?? 0) > 0);
    const expands = app.save.inventory[bpId('expand')] ?? 0;
    const rep = thriveReport(app.idx, app.save, cur, folk);
    const gate = b.features.some((f) => f.bp === 'link-gate');
    const pickedF = b.features.find((f) => f.id === picked);
    return [
      h('div', { class: 'holo-head' }, 'Build'),
      h('p', { class: 'holo-dim' }, `${YARD_SIZES[b.size ?? 0].label} yard · ${b.features.length} of ${featureRoom(b.size)} spots used. Blueprints come from the Market.`),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small', disabled: (b.size ?? 0) >= MAX_YARD_SIZE || !expands, title: expands ? '' : 'Buy a Yard Expansion at the Market', onclick: () => {
          let r; app.commit((s) => { r = expandYard(s, cur); }, 'build', { quiet: true });
          if (!r?.ok) { toast(r.reason, 'err'); return; }
          sfx('warp'); app.say(`The yard grew: now ${YARD_SIZES[r.size].label.toLowerCase()}.`); syncActors(); yard.materialize(); renderPanel(); renderHud();
        } }, (b.size ?? 0) >= MAX_YARD_SIZE ? 'Biggest it gets' : `Expand the yard${expands ? ` (${expands})` : ''}`),
        h('button', { class: 'btn small', onclick: () => app.go('market') }, 'Market')),
      pickedF ? [
        h('div', { class: 'holo-head small' }, blueprintOf(pickedF.bp)?.name),
        h('p', { class: 'holo-dim' }, 'Click the ground to move it.'),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn small', onclick: () => { app.commit((s) => removeFeature(s, cur, pickedF.id), 'build', { quiet: true }); picked = null; yard.pickedFeature = null; sfx('back'); syncActors(); renderPanel(); renderHud(); } }, 'Put it away'),
          h('button', { class: 'btn small', onclick: () => { picked = null; yard.pickedFeature = null; renderPanel(); renderHud(); } }, 'Done'))] : null,
      h('div', { class: 'holo-head small' }, 'Blueprints in the bag'),
      owned.length ? h('div', { class: 'holo-list' }, owned.map((bp) => h('button', { class: `holo-row ${placing === bp.id ? 'on' : ''}`, onclick: () => { placing = placing === bp.id ? null : bp.id; picked = null; yard.pickedFeature = null; sfx('move'); renderPanel(); renderHud(); } },
        h('span', { class: 'grow' }, bp.name), h('span', { class: 'holo-dim' }, `× ${app.save.inventory[bpId(bp.id)]}`), h('span', { class: 'holo-dim' }, placing === bp.id ? 'placing…' : 'Place'))))
        : h('p', { class: 'holo-dim' }, 'None. Buy blueprints at the Market (ponds, sun patches, slides, toy chests…).'),
      b.features.length ? [h('div', { class: 'holo-head small' }, 'Built here'),
        h('div', { class: 'holo-list' }, b.features.map((f) => {
          const fans = folk.filter((c) => appeal(app.idx, c, f.bp) > 0.35).length, foes = folk.filter((c) => appeal(app.idx, c, f.bp) < -0.35).length;
          return h('button', { class: `holo-row ${picked === f.id ? 'on' : ''}`, onclick: () => { picked = picked === f.id ? null : f.id; placing = null; yard.pickedFeature = picked; renderPanel(); renderHud(); } },
            h('span', { class: 'grow' }, blueprintOf(f.bp)?.name ?? f.bp), h('span', { class: 'holo-dim' }, `${fans ? `♥ ${fans}` : ''}${foes ? ` ✗ ${foes}` : ''}`));
        }))] : null,
      h('div', { class: 'holo-head small' }, 'Who thrives here'),
      rep.rows.length ? h('div', { class: 'holo-list' }, rep.rows.map((r) => h('div', { class: 'holo-row thrive' },
        h('span', { class: `thrive-dot t-${r.label.toLowerCase()}` }), h('span', { class: 'grow col' }, h('span', null, `${r.name} · ${r.label}`), h('small', { class: 'holo-dim' }, r.reasons.join(', ') || '—')))))
        : h('p', { class: 'holo-dim' }, 'Nobody lives here yet.'),
      rep.pairs.length ? [h('div', { class: 'holo-head small' }, 'Good together'), h('div', { class: 'holo-list' }, rep.pairs.map((p) => h('div', { class: 'holo-row' }, h('span', { class: 'grow' }, `${p.a} & ${p.b}`), h('span', { class: 'holo-dim' }, p.why))))] : null,
      gate ? linkGatePanel() : null,
    ];
  }
  // ---------- the Link gate: a friend's yard beside yours ----------
  function linkGatePanel() {
    const snapFile = () => {
      const snap = ranchSnapshot(app.idx, app.save, cur, here());
      const blob = new Blob([JSON.stringify(snap, null, 1)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = `${(app.save.trainer?.name ?? 'ranch').replace(/[^\w-]+/g, '_')}-${(habitat().name ?? 'yard').replace(/[^\w-]+/g, '_')}.clranch`;
      a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      toast('Saved your yard. Send the file to a friend; they open it at their Link gate.', 'ok');
    };
    const open = () => {
      const inp = h('input', { type: 'file', accept: '.clranch,application/json', class: 'hidden', onchange: async (e) => {
        const f = e.target.files[0]; if (!f) return;
        const r = readSnapshot(app.idx, await f.text());
        if (!r.ok) { toast(r.reason, 'err'); return; }
        guests = { snap: r.snap, key: cur };
        syncActors();
        for (const g of r.snap.creatures) { const a = yard.actors.get(`guest:${g.uid}`); if (a) a.appear = -0.6 - Math.random(); }
        sfx('warp');
        app.say(`${r.snap.trainer.name}’s creatures came through the Link gate to visit!${r.missing.length ? ` (${r.missing.length} kind${r.missing.length > 1 ? 's' : ''} you don’t have data for yet: ${r.missing.slice(0, 3).join(', ')}${r.missing.length > 3 ? '…' : ''})` : ''}`);
        renderPanel(); renderHud();
      } });
      document.body.append(inp); inp.click(); setTimeout(() => inp.remove(), 60000);
    };
    return [
      h('div', { class: 'holo-head small' }, 'Link gate'),
      h('p', { class: 'holo-dim' }, 'Join a friend’s yard to yours, side by side: their creatures visit and play with yours, and they can make friends. For now you swap yards as files; live links over the internet come later.'),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small', onclick: snapFile }, 'Save this yard for a friend'),
        guests?.key === cur ? h('button', { class: 'btn small', onclick: () => { guests = null; syncActors(); sfx('back'); app.say('Your visitors headed home.'); renderPanel(); renderHud(); } }, 'Send visitors home')
          : h('button', { class: 'btn small primary', onclick: open }, 'Open a friend’s yard')),
    ];
  }

  async function giveHeld(c) {
    const held = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && holdable(itemInfo(app.idx, id))).map(([id, n]) => ({ item: itemInfo(app.idx, id), n }));
    const pick = await chooseDialog(`Something for ${displayName(app.idx, c)} to hold`, [
      ...(c.heldItemId ? [{ value: '__none', label: 'Take it back', detail: itemInfo(app.idx, c.heldItemId)?.name ?? '' }] : []),
      ...held.map(({ item, n }) => ({ value: item.id, label: item.name, detail: `${item.desc ?? ''} · ${n} in the bag${item.showdownName ? '' : ' · only for show until it has a battle name (Data Lab)'}` })),
    ], { empty: 'Nothing to hold in the bag. The Market sells gear; berries and incense can be held too.' });
    if (!pick) return;
    app.commit((s) => {
      const x = s.creatures[c.uid];
      if (x.heldItemId) s.inventory[x.heldItemId] = (s.inventory[x.heldItemId] ?? 0) + 1;
      if (pick === '__none') { x.heldItemId = null; x.heldItem = ''; return; }
      const it = itemInfo(app.idx, pick);
      s.inventory[pick] = Math.max(0, (s.inventory[pick] ?? 0) - 1);
      x.heldItemId = pick; x.heldItem = it.showdownName || '';
    }, 'held');
    sfx('access');
    renderPanel();
  }

  function renderPanel() {
    panel.classList.toggle('open', panelOpen);
    el.classList.toggle('panel-open', panelOpen);
    if (area === 'farm') { mount(panel, farmPanel()); return; }
    if (building) { mount(panel, buildPanel()); return; }
    if (selected && String(selected).startsWith('guest:') && guests) {
      const g = guests.snap.creatures.find((x) => `guest:${x.uid}` === selected);
      if (g) {
        mount(panel,
          h('div', { class: 'holo-head' }, g.name),
          h('p', { class: 'holo-dim' }, `${g.species} · Lv. ${g.level} · visiting from ${guests.snap.trainer.name}’s ranch${guests.snap.trainer.code ? ` (ID ${guests.snap.trainer.code})` : ''}.`),
          h('p', { class: 'holo-dim' }, 'Guests can’t be looked after here, but they play with your creatures, and they can become friends.'),
          h('button', { class: 'btn small', onclick: () => { selected = null; yard.selected = null; renderPanel(); } }, 'Close'));
        return;
      }
    }
    const c = selected && app.save.creatures[selected];
    const inHere = c && here().some((x) => x.uid === c.uid);
    if (!inHere) {
      const folk = here();
      mount(panel,
        h('div', { class: 'holo-head' }, 'Yard log'),
        h('p', { class: 'holo-dim' }, `${RANCH_NAME}. Whoever is in this box lives in this yard. Click someone to look after them.`),
        folk.length ? h('div', { class: 'holo-list' }, folk.map((x) => h('button', { class: 'holo-row', onclick: () => { selected = x.uid; yard.selected = x.uid; sfx('move'); renderPanel(); } },
          spriteCanvas(app.bank, x, { scale: 1 }), h('span', { class: 'grow' }, displayName(app.idx, x)), h('span', { class: 'holo-dim' }, mood(x).label))))
          : h('p', { class: 'holo-dim' }, 'Nobody lives here yet. Bring someone, or move creatures into this box from the storage system.'),
        outOnDesktop().length ? [h('div', { class: 'holo-head small' }, 'Out on the desktop'),
          h('div', { class: 'holo-list' }, outOnDesktop().map((x) => h('div', { class: 'holo-row' }, spriteCanvas(app.bank, x, { scale: 1 }), h('span', { class: 'grow' }, displayName(app.idx, x)),
            h('button', { class: 'btn small', onclick: () => { app.commit((s) => { toggleBuddy(s, x.uid, false); }); syncActors(); const a = yard.actors.get(x.uid); if (a) a.appear = -1.1; sfx('warp'); app.say(`${displayName(app.idx, x)} came back to the yard.`); renderPanel(); renderHud(); } }, 'Call back'))))] : null,
        h('div', { class: 'row' }, h('div', { class: 'holo-head grow' }, 'Bag'), h('button', { class: 'btn small', onclick: () => app.go('market') }, 'Market')),
        h('div', { class: 'shop-wallet' }, h('span', { class: 'coin' }), h('strong', null, `${wallet(app.save)}`), h('span', { class: 'holo-dim' }, ' coins')),
        (() => {
          const inv = Object.entries(app.save.inventory ?? {}).filter(([, n]) => n > 0);
          return inv.length ? h('div', { class: 'kv holo-kv' }, inv.map(([id, n]) => [h('span', null, itemInfo(app.idx, id)?.name ?? id), h('span', null, `× ${n}`)])) : h('p', { class: 'holo-dim' }, 'Empty. Walks turn up treats and toys.');
        })());
      return;
    }
    const foods = allFoods(app.idx).filter((it) => it.unlimited || (app.save.inventory[it.id] ?? 0) > 0);
    const grooms = app.idx.ds.items.filter((it) => it.kind === 'groom' && (it.unlimited || (app.save.inventory[it.id] ?? 0) > 0));
    const count = (it) => (it.unlimited ? '' : ` (${app.save.inventory[it.id] ?? 0})`);
    const heldName = c.heldItemId ? itemInfo(app.idx, c.heldItemId)?.name : null;
    const actions = h('div', { class: 'col' },
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn primary', title: 'Just the two of you: wash, brush, feed by hand, play fetch', onclick: () => careRoom(c.uid) }, 'Quality time'),
        h('button', { class: 'btn', onclick: () => care(c.uid, 'pet') }, 'Pet'),
        h('button', { class: 'btn', onclick: () => { const t = yard.throwBall(); const a = yard.actors.get(c.uid); if (a && !a.egg) { a.state = 'chase'; a.toy = t; a.timer = 8; a.kicks = 0; } } }, 'Play'),
        h('button', { class: 'btn', onclick: () => { creatureCry(speciesOf(app.idx, c), c, { talk: true }); care(c.uid, 'talk'); yard.emote(c.uid); } }, 'Call'),
        h('button', { class: 'btn', title: napWait(c) ? `Napped not long ago: rested again in ${napWait(c)} min` : 'A long nap brings their energy back', onclick: () => care(c.uid, 'rest') }, napWait(c) ? `Nap (${napWait(c)} min)` : 'Nap'),
        h('button', { class: 'btn', onclick: async () => { yard.stop(); await openDressUp(app, c.uid); yard.start(); syncActors(); renderPanel(); } }, 'Dress up')),
      formPicker(app.idx, c, (form) => { app.commit((s) => setForm(app.idx, s.creatures[c.uid], form), 'form', { quiet: true }); sfx('warp'); syncActors(); yard.react(c.uid, 'sparkle', 3); renderPanel(); }),
      foods.length ? h('div', { class: 'row wrap' }, h('span', { class: 'dim' }, 'Feed'), foods.map((it) => h('button', { class: 'btn small', title: it.desc, onclick: () => care(c.uid, 'feed', it.id) }, it.name + count(it)))) : null,
      grooms.length ? h('div', { class: 'row wrap' }, h('span', { class: 'dim' }, 'Groom'), grooms.map((it) => h('button', { class: 'btn small', title: it.desc, onclick: () => care(c.uid, 'groom', it.id) }, it.name + count(it)))) : null,
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small', onclick: () => giveHeld(c) }, heldName ? `Holding: ${heldName}` : 'Give an item to hold'),
        h('button', { class: 'btn small', disabled: party(app.save).length >= app.idx.ds.rules.partySize, onclick: () => {
          const rect = yard.screenRect(c.uid);
          let r; app.commit((s) => { r = moveCreature(s, c.uid, { kind: 'party' }, app.idx.ds.rules.partySize); }, 'move', { quiet: true });
          if (r && !r.ok) return toast(r.error, 'err');
          const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
          selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
          if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: typeTint(c), say: transferLine('party', displayName(app.idx, c)) });
          else sfx('access');
        } }, 'Take into party'),
        h('button', { class: 'btn small', onclick: () => {
          const rect = yard.screenRect(c.uid);
          let r; app.commit((s) => { r = toggleBuddy(s, c.uid, true); });
          if (!r.ok) { toast(r.reason, 'err'); return; }
          const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
          selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
          const say = `${displayName(app.idx, c)} hopped out onto your desktop.`;
          if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: typeTint(c), say }); else app.say(say);
        } }, 'Send to the desktop'),
        h('button', { class: 'btn small danger', onclick: async () => {
          const name = displayName(app.idx, c);
          if (!(await confirmDialog(`Release ${name}?`, `${name} will return to the wild for good. This can’t be undone.`, { ok: 'Release', danger: true }))) return;
          const rect = yard.screenRect(c.uid);
          const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
          app.commit((s) => releaseCreature(s, c.uid), 'release', { quiet: true });
          selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
          const say = `${name} looked back once, then headed off into the wild.`;
          if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: '#ffffff', say });
          app.say(say);
        } }, 'Release'),
        h('button', { class: 'btn small', onclick: () => { selected = null; yard.selected = null; panelOpen = false; renderPanel(); renderHud(); } }, 'Close')));
    mount(panel, creatureSummary(app.idx, app.bank, c, { compact: true, save: app.save, sections: ['care', 'walk'], actions }));
  }

  const onKey = (e) => {
    if (e.target.closest?.('input, select, textarea')) return;
    if (e.key === 'q' || e.key === 'Q') yard.turn(-1);
    else if (e.key === 'e' || e.key === 'E') yard.turn(1);
    else if (e.key === 'r' || e.key === 'R') { yard.turn(0); yard.zoom(0); }
    else if (e.key === '+' || e.key === '=') yard.zoom(-1);
    else if (e.key === '-' || e.key === '_') yard.zoom(1);
    else if (e.key === 'ArrowLeft') yard.turn(-1);
    else if (e.key === 'ArrowRight') yard.turn(1);
    else if (e.key === '1') goArea('yard');
    else if (e.key === '2') goArea('farm');
    else if (e.key === 'PageUp') stepHabitat(-1);
    else if (e.key === 'PageDown') stepHabitat(1);
    else if (e.key === 'Escape') { if (menu) closeMenu(); else { selected = null; yard.selected = null; panelOpen = false; renderPanel(); renderHud(); } }
    else return;
    e.preventDefault();
  };
  const onDocDown = (e) => { if (menu && !menuEl.contains(e.target) && !hudBottom.contains(e.target)) closeMenu(); };

  function update() { syncActors(); syncPlots(); renderHud(); renderPanel(); if (menu) renderMenu(); }

  yard.buildMode = building;
  if (building) panelOpen = true;
  // visitors from a friend's yard (Friends → Visit their yard): they come through a Link gate
  if (app.pendingGuests) {
    const snap = app.pendingGuests; app.pendingGuests = null;
    const gateAt = [...app.save.boxes.keys()].find((k) => (app.save.boxes[k].build?.features ?? []).some((f) => f.bp === 'link-gate'));
    if (gateAt == null) setTimeout(() => toast('Build a Link gate in one of your yards first (blueprint from the Market), then visit again.', 'err'), 300);
    else { if (cur !== gateAt) switchTo(gateAt); guests = { snap, key: gateAt }; setTimeout(() => { syncActors(); app.say(`${snap.trainer.name}’s creatures came through the Link gate!`); renderHud(); }, 1200); }
  }
  update();
  let plotTimer = null;
  return {
    el,
    mounted() {
      yard.resize();
      yard.materialize();
      yard.start();
      window.addEventListener('keydown', onKey);
      document.addEventListener('pointerdown', onDocDown, true);
      plotTimer = setInterval(() => { syncPlots(); if (area !== 'yard') { renderPanel(); renderHud(); } }, 30000);
      setTimeout(() => intro.classList.add('done'), 900);
      canvas.focus({ preventScroll: true });
    },
    update,
    art: () => {},
    tick: () => { syncActors(); syncPlots(); renderPanel(); },
    dispose() { yard.destroy(); clearInterval(plotTimer); window.removeEventListener('keydown', onKey); document.removeEventListener('pointerdown', onDocDown, true); },
  };
}
