// R.A.N.C.H. (Remote Access Nurture & Care Hub): areas you load into. Each box has its own yard
// (in the box's environment), which you can build up with blueprints from the Market; the berry farm
// is an area of its own. With a Link gate, a friend's yard (brought over as a file) joins yours.
// In a yard: pet by rubbing, pick creatures up and carry or fling them, throw toys and berries
// (from the bag), and watch them play. Mouse wheel or − / + zoom, drag the ground to look around.
import { itemIcon } from '../../../../shared/ui/itemIcon.js';
import { openJournal } from '../../../../shared/ui/journal.js';
import { hostBerryBlender, chooseBlock } from '../../../../shared/ui/berryBlender.js';
import { changeItems } from '../../../../shared/ui/changeUi.js';
import { talkOverlay } from '../../../../shared/ui/talkOverlay.js';
import { friendsSession } from '../friendsSession.js';
import { h, mount, toast, chooseDialog, confirmDialog, dialog } from '../../../../shared/ui/dom.js';
import { sizeVariant } from '../../../../shared/ui/creatureSize.js';
import { Yard, toyKindOf, EXTRA_TOYS, WEATHER_LABEL } from '../../../../shared/ui/yard.js';
import { spriteCanvas, spriteIdOf } from '../../../../shared/ui/art.js';
import { BIOME_IDS, BIOME_INFO } from '../../../../shared/ui/biomes.js';
import { creatureSummary, formPicker } from '../../../../shared/ui/summary.js';
import { playTransfer, transferLine } from '../../../../shared/ui/transfer.js';
import { sfx, creatureCry } from '../../../../shared/ui/audio.js';
import * as Paint from '../../../../shared/ui/paint.js';
import {
  atKind, displayName, applyCare, mood, tickNeeds, moveCreature, firstFreeBoxSlot, speciesOf, list, boxContents, party,
  farmState, plotStatus, plant, harvest, plantable, growInfo, FARM_PLOTS, farmPlots, expandFarm, farmTools, mulchInBag, MAX_FARM_SIZE, releaseCreature, favorites, CARE_TOYS, ownedToys, friendsOf,
  wallet, itemInfo, setForm, toggleBuddy, isDesktopBuddy, movementOf, traitsOf, playedTogether, timeOfDay, napWait, holdable, allFoods,
  yardBuild, placeFeature, moveFeature, removeFeature, expandYard, appeal, featureLife, thriveReport, blueprintOf, bpId, BLUEPRINTS,
  YARD_SIZES, MAX_YARD_SIZE, featureRoom, ranchSnapshot, readSnapshot, experience, addMemory, topPrefs, dislikes, isAsleep, sleepLeft, moodNote, foodBlurb,
  journalOf, itemUses, itemDesc, isIncense, lightIncense, activeIncense, yardWeather, misfitHabitat, healingOf, useMedicine, currentFormId,
  feedPokeblock, CONDITION_NAMES, machinesIn, revivalStatus, startRevival, collectRevival, FOSSILS, fossilSpecies, REVIVE_HOURS, eggProgress,
  meetGuest, talkTo, yardWeatherSetting, calledWeather, chatTargets, wakeRisk, WAKE_HINT, cravingOf, foodStats,
  completeTask, denyTask, noteDone, trackable, volunteers, addTask, tasteFor, whimFor, INVITES, noteDid, startWish, finishWish, cleanOf, restoreItem,
  makeDeal, settleDeal, owedOf, wishedFor, thoughtsOf,
} from '../../../../shared/engine/index.js';
import { openMoveTo } from './moveTo.js';
import { activitiesView } from './activities.js';
import { battleView } from './battle.js';
import { RANCH_NAME } from './home.js';
import { actorFor } from '../../../../shared/ui/actor.js';
import { openCareRoom } from './careRoom.js';
import { openDressUp, clothesImg } from './dressUp.js';

const fmtLeft = (ms) => { const m = Math.ceil(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`; };
const AREAS = [['yard', 'Yard'], ['farm', 'Berry farm']];

/** What a creature looks like to the yard (shared with the care room). */
export function actorOf(app, c) { return actorFor(app.idx, c, { clothesImg }); }

export function ranchView(app) {
  const typeTint = (c) => app.idx.types.get(app.idx.species.get(c.speciesId)?.types?.[0])?.color ?? '#9fe8ff';
  const habitats = () => {
    const out = app.save.boxes.map((b, i) => ({ key: i, name: b.name, biome: b.biome ?? 'meadow' }));
    if (atKind(app.save, 'ranch').length) out.push({ key: 'ranch', name: app.save.ranch?.name ?? 'Free range', biome: app.save.ranch?.biome ?? 'meadow' });
    return out;
  };
  let cur = app.ranchHabitat ?? 0;
  if (!habitats().some((x) => x.key === cur)) cur = 0;
  let selected = null;
  let area = 'yard';
  let panelOpen = false;
  let logPinned = false; // the yard log only stays open when you asked for it (the Log button)
  let lastPet = 0;
  let menu = null; // 'bag' | null
  let bagTab = 'food'; // 'food' | 'toys' | 'items'
  let bagPick = null; // an item id picked in the bag's Items tab
  let cinemaOn = false;
  const playLog = new Map();
  const visitLog = new Map();
  // build mode: placing a blueprint, or moving something already built
  let building = !!app.ranchBuild; app.ranchBuild = false;
  let placing = null;      // a blueprint id from the bag
  let picked = null;       // a feature id (to move or put away)
  let guests = null;       // a friend's yard brought over through the Link gate: { snap, key }

  const canvas = h('canvas', { class: 'hab-canvas', tabindex: '0', 'aria-label': 'The yard. Rub a creature to pet it, drag it to carry it, let go to drop it. Drag the ground to look around, scroll to zoom.' });
  const hudTL = h('div', { class: 'hud hud-tl' });
  const hudTR = h('div', { class: 'hud hud-tr' });
  const hudBottom = h('div', { class: 'hud hud-bottom' });
  const menuEl = h('div', { class: 'hud-menu', hidden: true });
  const panel = h('aside', { class: 'holo-panel' });
  const intro = h('div', { class: 'hab-intro', 'aria-hidden': 'true' }, h('div', { class: 'rings' }, h('i'), h('i'), h('i')), h('div', { class: 'intro-text' }, 'R.A.N.C.H.', h('small', null, 'opening the gate…')));
  const el = h('div', { class: 'ranchvr' }, canvas, hudTL, hudTR, hudBottom, menuEl, panel, intro, h('div', { class: 'hud-frame', 'aria-hidden': 'true' }));
  const moodEl = h('div', { class: 'ranch-mood', hidden: true });
  let moodKey = '', moodSel = null, moodAt = 0, moodTimer = null;
  el.append(moodEl);

  const seedOf = (key) => (typeof key === 'number' ? key : 99) + 1;
  const yard = new Yard(canvas, {
    bank: app.bank,
    accent: app.save.trainer?.card?.accent,
    resolveTexture: (p) => app.textures[p.toLowerCase()] ?? null,
    biome: habitats().find((x) => x.key === cur)?.biome,
    seed: seedOf(cur),
    sizeScale: app.save.settings?.ranchScale ?? 1,
    // clicking someone opens their page; clicking away closes it (back to the log only if you'd opened it)
    onContext: (uid, ev) => creatureMenu(uid, ev),
    onSelect: (uid) => { if (uid && asks.has(uid)) { openAsk(uid); } selected = uid; if (uid) { panelOpen = true; sfx('move'); } else if (!building && area === 'yard') panelOpen = logPinned; if (menu) renderMenu(); renderPanel(); renderHud(); renderMood(); },
    onPet: (uid) => { const now = Date.now(); if (now - lastPet < 300) return; lastPet = now; care(uid, 'pet', null, true, true, 0.3); },
    onDrop: (uid, speed) => {
      if (speed > 4) { yard.react(uid, 'dizzy', 2); sfx('miss'); care(uid, 'play', null, true, false); }
      else { yard.react(uid, 'sparkle', 2); sfx('blip'); }
    },
    onPlot: (i) => plotClick(i),
    onPlace: (at) => placeAt(at),
    onFeatureOpen: (fid, bp) => useMachine(fid, bp),
    onPlaceBlocked: (why) => { sfx('miss'); toast(why ? `Can’t put it there: ${why.toLowerCase()}.` : 'Can’t put it there.', 'err'); },
    onFeature: (fid) => { picked = picked === fid ? null : fid; placing = null; yard.pickedFeature = picked; sfx('move'); renderPanel(); renderHud(); },
    onFeatureVisit: (uid, bp) => {
      const now = Date.now();
      if (!app.save.creatures[uid] || now - (visitLog.get(uid) ?? 0) < 60000) return;
      visitLog.set(uid, now);
      app.commit((s) => { const c = s.creatures[uid]; if (c) experience(c, [`feature:${bp}`], 3 + appeal(app.idx, c, bp) * 4, { t: now, coreChance: 0 }); }, 'visit', { quiet: true });
    },
    onBounce: (t, hit) => { if (hit > 5) sfx('blip'); },
    tod: timeOfDay(),
    onPlayTogether: (a, b) => {
      const key = [a, b].sort().join(':'), now = Date.now();
      if (now - (playLog.get(key) ?? 0) < 20000) return;
      playLog.set(key, now);
      // one of them is visiting from a friend's yard: a memory for ours
      const guest = [a, b].find((u) => String(u).startsWith('guest:'));
      if (guest) {
        const mine = a === guest ? b : a, g = guests?.snap.creatures.find((x) => `guest:${x.uid}` === guest);
        if (g && app.save.creatures[mine]) {
          let met;
          app.commit((s) => {
            const c = s.creatures[mine];
            met = meetGuest(c, g, guests.snap.trainer, 3, now);
            c.metGuests = c.metGuests || {};
            if (!c.metGuests[g.uid]) { c.metGuests[g.uid] = now; addMemory(c, `Played with ${g.name} from ${guests.snap.trainer.name}’s ranch.`, now, { core: Object.keys(c.metGuests).length <= 3 }); }
            else if (met.entry.visits > 1 && met.entry.greeted !== met.entry.visits) { met.entry.greeted = met.entry.visits; met.again = true; }
            if (met.friends && !met.entry.friendAt) { met.entry.friendAt = now; addMemory(c, `Became friends with ${g.name} from ${guests.snap.trainer.name}’s ranch.`, now, { core: true }); met.newFriend = true; }
          }, 'guest', { quiet: true });
          const nm = displayName(app.idx, app.save.creatures[mine]);
          if (met?.newFriend) app.say(`${nm} and ${g.name} became friends!`);
          else if (met?.again) app.say(`${nm} remembers ${g.name} and is happy to see them again!`);
        }
        return;
      }
      let r; app.commit((s) => { r = playedTogether(app.idx, s, a, b, now); }, 'bond', { quiet: true });
      if (r?.friends) app.say(`${displayName(app.idx, app.save.creatures[a])} and ${displayName(app.idx, app.save.creatures[b])} became friends playing together!`);
    },
    onEat: (uid, item) => {
      const c = app.save.creatures[uid];
      if (!c || !item?.id) return;
      const fav = favorites(app.idx, c);
      let out;
      app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], 'feed', { item: item.id, favorite: item.id === fav.berry, inventory: save.inventory, direct: false }); if (out?.ok !== false && out?.reaction !== 'full') tasksDone(noteDone(save, uid, 'feed', item.id)); }, 'care', { quiet: true });
      if (out?.ok) { yard.react(uid, out.reaction === 'delighted' ? 'hearts' : out.reaction === 'full' ? 'sad' : 'munch', 4); sfx('munch'); app.say(`${displayName(app.idx, c)} ${out.reaction === 'full' ? 'sniffed the' : 'ate the'} ${item.name}${out.reaction === 'delighted' ? ' — a favourite!' : out.reaction === 'full' ? ', but is full.' : '.'}`); }
      else if (out?.reason) toast(out.reason, 'err');
      renderPanel(); if (menu) renderMenu();
    },
    onPlay: (uid, kind, item) => {
      const c = app.save.creatures[uid];
      if (!c) return;
      const id = item?.id ?? kind;
      const fav = favorites(app.idx, c);
      let out;
      app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], 'play', { toy: id, toyName: item?.name, favorite: id === fav.toy, inventory: save.inventory, direct: false }); if (out?.ok !== false) tasksDone(noteDone(save, uid, 'play')); }, 'care', { quiet: true });
      if (out?.ok && out.reaction === 'delighted') { yard.react(uid, 'hearts', 3); app.say(`${displayName(app.idx, c)} loves the ${item?.name ?? kind}!`); }
      else if (out?.reaction === 'tired') yard.emote(uid, 'tired', false);
      if (selected === uid) renderPanel();
    },
  });

  // creatures out on the desktop aren't in the yard while they're out there
  const residents = () => (cur === 'ranch' ? atKind(app.save, 'ranch') : boxContents(app.save, cur).filter(Boolean));
  // one place at a time: out on the desktop, or busy with an activity, means not in the yard
  const here = () => residents().filter((c) => !isDesktopBuddy(app.save, c.uid) && !app.busy?.has(c.uid));
  const outOnDesktop = () => residents().filter((c) => isDesktopBuddy(app.save, c.uid));
  const habitat = () => habitats().find((x) => x.key === cur) ?? habitats()[0];

  const buildOf = () => yardBuild(app.save, cur);
  function syncActors() {
    yard.tod = yard.light ?? timeOfDay();
    const folk = area === 'yard' ? here() : [];
    // the yard's size and what's built there (features come alive with the right residents)
    if (area === 'yard') {
      const b = buildOf();
      yard.setYardSize(b.size ?? 0);
      yard.setFeatures(b.features.map((f) => ({ ...f, life: featureLife(app.idx, f.bp, folk) })));
    }
    const feats = area === 'yard' ? buildOf().features : [];
    const biomeHere = habitat().biome;
    const actors = folk.map((c) => ({ ...actorOf(app, c), misfit: misfitHabitat(app.idx, app.idx.species.get(currentFormId(app.idx, c)) ?? speciesOf(app.idx, c), biomeHere), featLikes: Object.fromEntries(feats.map((f) => [f.id, appeal(app.idx, c, f.bp)])) }));
    // visitors through the Link gate
    if (area === 'yard' && guests?.key === cur) for (const g of guests.snap.creatures) actors.push({ uid: `guest:${g.uid}`, speciesId: app.idx.species.has(g.formId ?? '') ? g.formId : g.speciesId, name: `${g.name} (${guests.snap.trainer.name})`, mood: 'happy', speed: 1.3, sizeMul: 1, types: g.types ?? [], friends: [], clothes: [], guest: true, temper: 'playful' });
    yard.setCreatures(actors);
  }
  function syncPlots() { yard.setFarmSize?.(farmState(app.save).size ?? 0); yard.setPlots(farmState(app.save).plots.map((p) => plotStatus(app.idx, p))); }

  function goArea(a) {
    if (a === area) return;
    area = a;
    selected = null; yard.selected = null;
    closeMenu();
    yard.farmSize = farmState(app.save).size ?? 0;
    yard.setScene(a, habitat().biome, seedOf(cur));
    yard.setWeather(yardWeatherSetting(app.save));
    syncActors(); syncPlots();
    yard.materialize();
    panelOpen = a !== 'yard';
    sfx('warp');
    renderHud(); renderPanel();
  }
  function switchTo(key) {
    if (key === cur && area === 'yard') return;
    cur = key;
    app.ranchHabitat = key;
    selected = null; yard.selected = null;
    yard.actors.clear();
    area = 'yard';
    placing = null; picked = null; yard.pickedFeature = null;
    const b = buildOf();
    yard.yardSize = b.size ?? 0;
    yard.features = []; yard.featKey = null;
    yard.setScene('yard', habitat().biome, seedOf(key));
    yard.setWeather(yardWeatherSetting(app.save));
    syncActors();
    yard.materialize();
    sfx('warp');
    renderHud(); renderPanel();
  }
  const stepHabitat = (d) => { const l = habitats(); const i = l.findIndex((x) => x.key === cur); switchTo(l[(i + d + l.length) % l.length].key); };

  function care(uid, action, item, quiet = false, react = true, weight = 1) {
    let out;
    app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], action, { item, inventory: save.inventory, weight, save, asked: action === 'play' && wishedFor(save, uid, 'play') }); if (out?.ok !== false && !out?.asleep) tasksDone(noteDone(save, uid, action, item?.id ?? item ?? null)); }, 'care', { quiet: true });
    if (out?.kept) setTimeout(() => { toast(out.kept, 'ok'); try { yard.react(uid, 'hearts', 3); } catch { /* fine */ } }, 600);
    if (!out?.ok) { if (out?.reason && !quiet) toast(`${displayName(app.idx, app.save.creatures[uid])}: ${out.reason}`, 'err'); renderMood(uid); return; }
    const nm0 = displayName(app.idx, app.save.creatures[uid]);
    if (out.reaction === 'annoyed') { yard.react(uid, 'sad', 4); yard.emote(uid, 'angry', false); sfx('miss'); app.say(`${nm0} has had enough and is upset with you. Give them some space.`); renderPanel(); return; }
    if (out.reaction === 'grumpy') { syncActors(); yard.emote(uid, 'angry', false); sfx('back'); app.say(`${nm0} woke up, a bit grumpy.`); renderPanel(); renderMood(); return; }
    if (out.reaction === 'sleep' && action === 'rest') { syncActors(); const a = yard.actors.get(uid); if (a) { a.state = 'sleep'; a.timer = 4; } }
    if (out.woke && out.reaction === 'awake') { syncActors(); yard.emote(uid, 'smile', false); sfx('back'); app.say(`${nm0} woke up and stretched. Energy ${Math.round(out.needs?.energy ?? 0)}.`); renderPanel(); renderMood(); return; }
    if (out.reaction === 'awake') { yard.emote(uid, 'meh', false); if (!quiet) app.say(`${nm0}: ${out.reason}`); renderPanel(); return; }
    const reaction = { hearts: 'hearts', munch: 'munch', delighted: 'hearts', play: 'hearts', sparkle: 'sparkle', listen: 'note', sleep: 'sleep', full: 'sad', tired: 'sleep', meh: 'note' }[out.reaction] ?? 'hearts';
    if (out.reaction === 'meh' && !quiet) app.say(`${nm0} is getting a bit tired of that.`);
    if (react) yard.react(uid, reaction, reaction === 'hearts' ? 3 : 4);
    if (action === 'pet') sfx('heart');
    if (action === 'feed') sfx(out.reaction === 'full' ? 'back' : 'munch');
    if (action === 'groom') sfx('heal');
    const nm = displayName(app.idx, app.save.creatures[uid]);
    if (out.reaction === 'full') app.say(`${nm} is full.`);
    if (out.reaction === 'tired') app.say(`${nm} is too tired to play.`);
    if (!quiet || out.friendship) renderPanel();
    renderMood();
  }
  // how someone's doing and what would help, big and plain (bottom left): the one you picked, or anyone upset
  function renderMood(force) {
    const pick = (force && app.save.creatures[force]) || (selected && app.save.creatures[selected]) || here().find((c) => ['upset', 'asleep'].includes(mood(c).id));
    const note = pick && moodNote(app.idx, pick, displayName(app.idx, pick));
    // it shows when something changes, then fades after a few seconds (click them again to see it)
    const key = note ? `${pick.uid}:${note.mood}` : '';
    if (key !== moodKey || force || (selected && selected !== moodSel)) { moodKey = key; moodSel = selected; moodAt = Date.now(); moodEl.classList.remove('faded'); clearTimeout(moodTimer); moodTimer = setTimeout(() => moodEl.classList.add('faded'), 6000); }
    moodEl.hidden = !note || cinemaOn || building || !!menu;
    if (!note) return;
    let th = null; try { th = thoughtsOf(app.idx, app.save, pick)[0] ?? null; } catch { /* fine */ }
    mount(moodEl, h('div', { class: `ranch-mood-title m-${note.mood}` }, note.title), h('div', { class: 'ranch-mood-why' }, note.why), th ? h('div', { class: 'ranch-mood-why' }, `${th.pic} On its mind: ${th.text.replace(/^it('s| is| has| keeps)?\s*/, (m) => (/has/.test(m) ? 'has ' : /keeps/.test(m) ? 'keeps ' : ''))}.`) : null, h('div', { class: 'ranch-mood-help' }, note.help));
  }

  /** The creature you have selected (berries and toys you throw go to them first), or null. */
  const forSelected = () => (selected && app.save.creatures[selected] && !app.save.creatures[selected].egg && !isAsleep(app.save.creatures[selected]) ? selected : null);
  // ---------- talking (T): everyone in the yard, or just the ones you name ----------
  function askOne(uid, text, group) {
    let out = null;
    app.commit((s) => { const c = s.creatures[uid]; if (c) out = talkTo(app.idx, s, c, text, Date.now(), { group }); if (out?.act?.kind === 'pair') tasksDone(noteDone(s, uid, 'pair')); }, 'chat', { quiet: true });
    if (out?.task) setTimeout(() => { onTasks([{ ...out.task, chat: true }]); }, 900); // (what they asked for went on the task list)
    if (out?.act?.kind === 'weather' && out.done?.ok) { yard.setWeather(out.act.weather); weatherReact(); renderHud(); }
    if (out?.act && ['nap', 'wake', 'change'].includes(out.act.kind)) { syncActors(); renderPanel(); }
    return out;
  }
  // (“who's awake and wants to play?” isn't waking anyone: only a real “wake up, everyone” reaches the sleepers)
  const WAKE_ALL = /\b(wake up|wakey|rise and shine|get up|up and at|time to get up|everyone up|everybody up)\b/i;
  // someone sent to use something, or somewhere (click them, then it; shift+click anywhere)
  yard.onSent = (uid, what) => { try { sfx('move'); const n = displayName(app.idx, app.save.creatures[uid]); if (what.feature) toast(`${n} heads over to the ${what.feature.def?.name?.toLowerCase() ?? 'play area'}.`); else if (what.toy) toast(`${n} goes after the toy.`); else if (what.perch) toast(`${n} hops up for a sit.`); } catch { /* fine */ } };
  const talk = talkOverlay({
    // (in the R.A.N.C.H. itself, so it's there and can be pressed in full screen too)
    app, host: el, yard,
    listeners: () => (area === 'yard' ? here().filter((c) => !c.egg).map((c) => c.uid) : []),
    // sleeping ones only hear you when you name them (or tell everyone to wake up)
    pick: (uids, text, P) => {
      // said to some by name: them; about someone ("do you like Mindle?"): everyone else; else everyone awake
      const to = (P?.addressees ?? []).filter((u) => uids.includes(u));
      const named = to.length ? to : P?.about?.length ? uids.filter((u) => !P.about.includes(u)) : chatTargets(app.idx, app.save, uids, text);
      const all = named.length === uids.length || (!to.length && P?.about?.length);
      return all && !WAKE_ALL.test(text) ? named.filter((u) => !isAsleep(app.save.creatures[u])) : named;
    },
    ask: askOne,
    invite: (uids, inv, text, opts) => runInvite(uids, inv, text, opts),
    deal: (uids, P, text) => offerDeal(uids, P, text),
    onReply: () => { renderPanel(); renderMood(); },
    // what each one's doing in the yard right now (for “what are you up to?”)
    doing: (u) => { const a = yard.actors?.get(u); if (!a) return null; if (a.toy) return 'playing with a toy'; if (a.perch || a.sitting) return 'sitting up on something, looking around';
      return { sleep: 'having a nap', walk: 'wandering about', play: 'playing', dance: 'dancing', happy: 'feeling happy', eat: 'eating', sit: 'sitting down', swim: 'swimming', bath: 'taking a bath', held: 'being held by you', chase: 'chasing something', drink: 'having a drink', dig: 'digging', puppet: 'with you', idle: 'just hanging around', sad: 'feeling a bit down', ball: 'playing ball', run: 'running around', fly: 'flying about' }[a.state] ?? 'just hanging around'; },
    context: () => ({ where: 'out in the R.A.N.C.H. yard together', happening: (() => { try { return `it is ${timeOfDay()} and the weather is ${yard.weather ?? 'clear'}`; } catch { return null; } })() }),
  });

  // ---------- “!”: something one of them wants to tell you or do ----------
  // Every few minutes someone has something on its mind — usually what it most feels like doing right now (its
  // own tastes, today's mood), sometimes a battle or just something to tell you. A “!” stays over its head until
  // you click it: start it now, put it on the task list, or not now.
  const asks = new Map();
  function makeAsk() {
    const here = [...yard.actors.keys()].filter((u) => { const c = app.save.creatures[u]; return c && !c.egg && !isAsleep(c) && !asks.has(u); });
    if (!here.length || asks.size >= 2) return;
    const uid = here[Math.floor(Math.random() * here.length)], c = app.save.creatures[uid];
    const opts = INVITES.filter((i) => i.act || i.id === 'battle' || i.id === 'desktop' || i.id === 'groom');
    let best = null, bs = -9;
    for (const inv of opts) { const L = tasteFor(app.idx, c, inv.id), W = whimFor(c, inv.id); const sc = L * 0.6 + W.day * 0.5 + W.hour * 0.3 + Math.random() * 0.1; if (sc > bs) { bs = sc; best = inv; } }
    // owed something (a walk it won)? that's what it comes to you about, more often than not
    const owed = (c.owed ?? []).find((o) => o.prize?.kind === 'walk');
    const ask = owed && Math.random() < 0.6 ? { kind: 'walk', id: 'walk', label: `go on the walk it ${owed.won ? `won in ${owed.won}` : 'was promised'}`, icon: '🚶' }
      : Math.random() < 0.18 ? { kind: 'talk', id: 'talk', label: 'tell you something', icon: '💬' } : { kind: best.act ? 'activity' : best.id, id: best.id, act: best.act ?? null, label: best.label, icon: { battle: '⚔️', desktop: '🖥️', groom: '🛁' }[best.id] ?? '✨' };
    ask.made = Date.now(); asks.set(uid, ask); showAsks(); sfx('blip');
  }
  function showAsks() { for (const u of asks.keys()) { try { const a = yard.actors.get(u); if (a && (!a.bubble || a.bubble.pic !== '!')) yard.think(u, '!', 9999); } catch { /* fine */ } } }
  // not answered in a few minutes: the “!” turns into a ball of light and flies off into the task list (it's
  // kept there, so nothing's missed)
  const ASK_LIFE = 4 * 60000;
  function askToList(uid) {
    const q = asks.get(uid), c = app.save.creatures[uid]; if (!q || !c) { asks.delete(uid); return; }
    asks.delete(uid);
    try { const a = yard.actors.get(uid); if (a?.bubble?.pic === '!') { a.bubble = null; a.bubbleRect = null; } } catch { /* fine */ }
    if (q.kind === 'talk') return;
    const nm2 = displayName(app.idx, c), t0 = Date.now(); let tk = null;
    app.commit((sv) => { tk = addTask(sv, { id: `task-${uid}-${t0.toString(36)}`, uid, made: t0, due: t0 + 2 * 86400000, kind: 'wish', key: `wish:${q.id}`, act: q.act ?? null, icon: q.icon, text: `${nm2} wants to ${q.label}.` }); }, 'task', { quiet: true });
    if (tk) { const was = selected; selected = null; onTasks([tk]); selected = was; }
  }
  const askTimer = setInterval(() => {
    for (const [u, q] of asks) if (Date.now() - (q.made ?? Date.now()) > ASK_LIFE && !(inviteEl && inviteEl.dataset.ask === u)) askToList(u);
    showAsks(); if (Math.random() < 1 / 36) makeAsk(); // (about one every 3 minutes)
    // now and then someone's thoughts show (what's really on its mind: a prize it's waiting for, a song stuck in its
    // head, a friend, something it'd love to do)
    if (Math.random() < 1 / 14 && !talk.isOpen?.()) { try { const us = [...yard.actors.keys()].filter((u) => { const c = app.save.creatures[u]; const a = yard.actors.get(u); return c && !c.egg && !isAsleep(c) && !asks.has(u) && !a?.bubble; }); const u = us[Math.floor(Math.random() * us.length)]; if (u) { const th = thoughtsOf(app.idx, app.save, app.save.creatures[u])[0]; if (th) yard.think(u, th.pic, 3.2); } } catch { /* fine */ } }
    // a helper who offered to look after the next one to nap
    const helper = [...yard.actors.keys()].find((u) => Date.now() - (app.save.creatures[u]?.dreamHelper ?? 0) < 6 * 3600000);
    if (helper && [...yard.actors.keys()].some((u) => u !== helper && isAsleep(app.save.creatures[u]) && !((app.save.creatures[u].dreamHelpUntil ?? 0) > Date.now()))) { app.commit((sv) => { sv.creatures[helper].dreamHelper = null; }, 'care', { quiet: true }); dreamHelp([helper]); }
  }, 5000);
  function openAsk(uid) {
    const q = asks.get(uid), c = app.save.creatures[uid]; if (!q || !c) return;
    const nm = displayName(app.idx, c);
    const done = () => { asks.delete(uid); try { const a = yard.actors.get(uid); if (a?.bubble?.pic === '!') a.bubble = null; } catch { /* fine */ } inviteEl?.remove(); inviteEl = null; };
    const go = (label, fn, primary) => h('button', { class: `btn small ${primary ? 'primary' : ''}`, onclick: () => { done(); fn(); } }, label);
    inviteEl?.remove();
    const acts = q.kind === 'talk' ? [go(`💬 Talk to ${nm}`, () => { selected = uid; yard.selected = uid; talk.open(); }, true), go('Not now', () => {})]
      : [go('▶ Let’s do it now', () => {
          // (done now, it counts just like a ticked-off task: the reward comes once it's done — no party needed)
          const t0 = Date.now(), wish = { uid, key: `wish:${q.id}`, act: q.act ?? (q.id === 'battle' ? 'battle' : null), icon: q.icon, text: `${nm} wants to ${q.label}.` };
          app.commit((sv) => { startWish(sv, wish, t0); }, 'wish', { quiet: true });
          if (q.kind === 'walk') { openMoveTo(app, app.save.creatures[uid]).then(() => { syncActors(); renderPanel(); }); return; }
          if (q.act) { activitiesView.last = uid; activitiesView.autoStart = q.act; app.go('activities'); }
          else if (q.id === 'battle') { battleView.solo = uid; app.go('battle'); }
          else {
            if (q.id === 'desktop') { app.commit((sv) => { toggleBuddy(sv, uid, true); }); syncActors(); toast(`${nm} hopped out onto your desktop.`, 'ok'); }
            else if (q.id === 'groom') careRoom(uid);
            // (things done on the spot: granted straight away)
            let r = null; app.commit((sv) => { r = finishWish(app.idx, sv, uid, q.id); }, 'wish', { quiet: true });
            if (r?.ok) setTimeout(() => toast(`${nm} got their wish!${r.items?.length ? ` (+ ${r.items.map(([id, n]) => `${n} ${itemInfo(app.idx, id)?.name ?? id}`).join(', ')})` : ''}`, 'ok'), 700);
          }
        }, true),
        go('📝 Add to the task list', () => { const t0 = Date.now(); let tk = null; app.commit((sv) => { tk = addTask(sv, { id: `task-${uid}-${t0.toString(36)}`, uid, made: t0, due: t0 + 2 * 86400000, kind: 'wish', key: `wish:${q.id}`, act: q.act ?? null, icon: q.icon, text: `${nm} wants to ${q.label}.` }); }); if (tk) onTasks([tk]); else toast(`${nm} already has something on the task list.`); }),
        go('Not now', () => { try { yard.think(uid, '…', 2); } catch { /* fine */ } })];
    inviteEl = h('div', { class: 'invite-card', role: 'dialog', 'data-ask': uid },
      h('div', { class: 'row', style: { alignItems: 'center', gap: '8px' } }, spriteCanvas(app.bank, c, { scale: 1 }), h('b', { class: 'grow' }, q.kind === 'talk' ? `${nm} has something to tell you.` : `${q.icon} ${nm} wants to ${q.label}!`), h('button', { class: 'btn small', 'aria-label': 'Close', onclick: () => { inviteEl?.remove(); inviteEl = null; } }, '✕')),
      h('div', { class: 'row wrap', style: { gap: '6px' } }, acts));
    el.append(inviteEl);
  }

  // ---------- races and helping others rest: asked for in words, done right here ----------
  // A race: they gather, then dash for the spot you named (a tree, the pond, the fence…) or the far side of the
  // yard. Faster kinds have the edge, but anyone can win. It tires them a little and cheers them up.
  let raceOn = null;
  // where a place you named really is in this yard: something built ("the hammock", "the toy box"), scenery ("the
  // big tree", "the rock"), or a spot ("the fence", "the middle", "me")
  function spotOf(pl, from = null) {
    if (!pl) return null;
    const S = yard.S ?? {}, near = from ?? { x: 0, z: ((S.z0 ?? 1) + (S.z1 ?? 10)) / 2 };
    const far = (list) => list.sort((p1, p2) => Math.hypot(p2.x - near.x, p2.z - near.z) - Math.hypot(p1.x - near.x, p1.z - near.z))[0];
    const f = (yard.features ?? []).filter((q) => q.bp === pl.id || (pl.id === 'swing' && q.bp === 'tire-swing') || (pl.id === 'pond' && /pond|hot-spring|fountain/.test(q.bp)) || (pl.id === 'campfire' && /campfire|lantern/.test(q.bp)));
    if (f.length) { const q = far(f); return { x: q.x, z: q.z + (q.def?.r ?? 0.6) * 0.7, name: `the ${String(q.def?.name ?? pl.words).toLowerCase()}` }; }
    const KIND = { tree: /tree|pine|palm|kelp|bamboo/, rock: /rock|boulder|stone/, bush: /bush|shrub|hedge/, pond: /pond|lily|reed/, bench: /bench/, lanterns: /lamp|lantern/ };
    if (KIND[pl.id]) { const ps = (yard.props ?? []).filter((q) => KIND[pl.id].test(q.kind ?? '') && !q.outside && !q.border && Math.abs(q.x) < (S.x1 ?? 8) && q.z < (S.z1 ?? 10)); if (ps.length) { const q = far(ps); return { x: q.x, z: q.z - 0.7, name: `the ${pl.words.replace(/^(?:the|that|big|tall|old) /, '')}` }; } }
    if (pl.id === 'pond') { const w = yard.waterSpot?.(); if (w) return { x: w.x, z: w.z, name: 'the water' }; }
    if (pl.id === 'gazebo' && yard.shelter) return { x: yard.shelter.x, z: yard.shelter.z - 1.2, name: 'the gazebo' };
    if (pl.id === 'fence' || pl.id === 'back') return { x: near.x * 0.3, z: (S.z1 ?? 10) - 0.6, name: pl.id === 'fence' ? 'the fence' : 'the back of the yard' };
    if (pl.id === 'middle') return { x: 0, z: ((S.z0 ?? 1) + (S.z1 ?? 10)) / 2, name: 'the middle' };
    if (pl.id === 'me') return { x: 0, z: (S.z0 ?? 1) + 0.6, name: 'you' };
    return null;
  }
  /** A race: they gather (at the start you named, or where they are), then dash for the finish. Ones keen on a prize
   * someone's offered run that bit harder. A deal for "the next race" is settled when someone wins. */
  function startRace(uids, said = '', route = null) {
    uids = uids.filter((u) => yard.actors.get(u)); if (!uids.length || raceOn) return;
    const acts = uids.map((u) => yard.actors.get(u));
    let cx = acts.reduce((a, x) => a + x.x, 0) / acts.length, cz = acts.reduce((a, x) => a + x.z, 0) / acts.length;
    const start = route?.from ? spotOf(route.from) : null;
    if (start) { cx = start.x; cz = start.z; }
    const deal0 = (app.save.deals ?? []).filter((d) => d.state === 'open' && (d.cond?.kind === 'race' || d.cond?.kind === 'any')).sort((a, b) => b.made - a.made)[0] ?? null;
    let goal = null, goalName = 'the far side';
    const to = route?.to ?? deal0?.cond?.route?.to ?? null;
    if (to) { const g = spotOf(to, { x: cx, z: cz }); if (g) { goal = { x: yard.clampX(g.x), z: yard.clampZ(g.z) }; goalName = g.name; } }
    if (!goal) {
      const want = /tree/.test(said) ? /tree/ : /pond|water|lake/.test(said) ? /pond|water|lake/ : /fence/.test(said) ? /fence/ : /house|home|barn/.test(said) ? /house|barn|hut|home/ : /rock|stone|boulder/.test(said) ? /rock|boulder|stone/ : null;
      if (want) { const ps = (yard.props ?? []).filter((p) => want.test(p.kind ?? '') && !p.border && !p.outside).sort((a, b) => Math.hypot(b.x - cx, b.z - cz) - Math.hypot(a.x - cx, a.z - cz)); if (ps[0]) { goal = { x: ps[0].x, z: ps[0].z + 0.6 }; goalName = `the ${String(ps[0].kind).replace(/[-_]/g, ' ')}`; } }
    }
    if (!goal) goal = { x: yard.clampX(-cx * 0.9 || 3), z: yard.clampZ(-cz * 0.9 || 3) };
    // line up beside each other at the start, facing the finish
    const dx = goal.x - cx, dz = goal.z - cz, dl = Math.hypot(dx, dz) || 1, px = -dz / dl, pz = dx / dl;
    uids.forEach((u, i) => yard.command?.(u, { kind: 'goto', x: yard.clampX(cx + px * (i - (uids.length - 1) / 2) * 0.9), z: yard.clampZ(cz + pz * (i - (uids.length - 1) / 2) * 0.9) }));
    const fromName = start ? ` from ${start.name}` : '';
    toast(`On your marks… racing${fromName} to ${goalName}!${deal0 ? ` (The winner gets ${deal0.prize?.label}.)` : ''}`);
    // keen on the prize: a little faster (and you can see it in them)
    const keenOf = (u) => (deal0 ? (app.save.creatures[u]?.hopes ?? []).find((h) => h.dealId === deal0.id)?.keen ?? 0 : 0);
    if (deal0) uids.forEach((u, i) => setTimeout(() => { try { if (keenOf(u) > 0.6) yard.think?.(u, deal0.prize?.icon ?? '🏆', 2.2); } catch { /* fine */ } }, 600 + i * 200));
    raceOn = { uids, goal, t0: 0 };
    setTimeout(() => {
      if (!raceOn) return;
      sfx('warp'); toast('Go!', 'ok');
      // (keen on the prize, or just given a pep talk: a little faster)
      const pep = (u) => (Date.now() - (app.save.creatures[u]?.pepTalk ?? 0) < 10 * 60000 ? 0.2 : 0);
      uids.forEach((u) => yard.command?.(u, { kind: 'goto', x: goal.x, z: goal.z, dash: true, pace: 2 + Math.random() * 0.5 + keenOf(u) * 0.35 + pep(u) }));
      raceOn.t0 = performance.now();
      const iv = setInterval(() => {
        const won = uids.find((u) => { const a = yard.actors.get(u); return a && Math.hypot(a.x - goal.x, a.z - goal.z) < 0.45; });
        if (!won && performance.now() - raceOn.t0 < 20000) return;
        clearInterval(iv);
        const others = uids.filter((u) => u !== won);
        if (won) { try { yard.react?.(won, 'hearts', 2); yard.think?.(won, '!', 2.5); } catch { /* fine */ } for (const o of others) try { yard.think?.(o, '…', 2.5); } catch { /* fine */ } sfx('level'); toast(`${nm(won)} wins the race to ${goalName}!`, 'ok'); }
        let settled = null, tk = null;
        app.commit((sv) => { const t = Date.now(); for (const u of uids) { const c = sv.creatures[u]; if (!c) continue; tickNeeds(app.idx, c, t); c.needs.energy = Math.max(5, (c.needs.energy ?? 60) - 6); c.needs.joy = Math.min(100, (c.needs.joy ?? 60) + (u === won ? 8 : 4)); noteDid(c, 'race', { t, joy: u === won ? 0.9 : 0.55 }); }
          if (won && uids.length > 1 && !sv.creatures[won].firsts?.raceWin) { const c = sv.creatures[won]; c.firsts = { ...(c.firsts ?? {}), raceWin: Date.now() }; addMemory(c, `Won a race to ${goalName} against ${others.map((o) => nm(o)).join(' and ')}.`, Date.now(), { core: false }); }
          // a deal riding on it: the winner's owed the prize (and knows exactly why)
          if (won) { settled = settleDeal(app.idx, sv, { kind: 'race', winner: won, uids, goal: goalName.replace(/^the /, '') }, t); if (settled?.task) tk = addTask(sv, settled.task); }
        }, 'care', { quiet: true });
        if (settled) {
          setTimeout(() => {
            try { yard.think?.(won, settled.prize?.icon ?? '🏆', 4); yard.react?.(won, 'hearts', 3); yard.command?.(won, { kind: 'jump' }); } catch { /* fine */ }
            for (const o of others) { const keen = (app.save.creatures[o]?.hopes ?? []).find((hh) => hh.dealId === settled.deal.id)?.keen ?? 0; if (keen > 0.6) try { yard.think?.(o, '😤', 2.5); } catch { /* fine */ } }
            toast(settled.note, 'ok'); sfx('level');
            if (tk) { const was = selected; selected = null; onTasks([tk]); selected = was; }
          }, 1300);
        }
        raceOn = null; renderPanel();
      }, 120);
    }, start ? 3600 : 2600);
  }
  // a deal: everyone who heard it reacts, by how much they want the prize (and how much they trust you)
  function offerDeal(uids, P, text) {
    let res = null;
    app.commit((sv) => { res = makeDeal(app.idx, sv, P, uids, Date.now()); }, 'chat', { quiet: true });
    if (!res) return;
    res.reactions.forEach((r, i) => setTimeout(() => { try { yard.think?.(r.uid, r.keen > 0.4 ? r.pic : '…', 3.5); if (r.keen > 0.75) { yard.react?.(r.uid, 'hearts', 1.8); yard.command?.(r.uid, { kind: 'jump' }); } creatureCry(speciesOf(app.idx, app.save.creatures[r.uid]), app.save.creatures[r.uid], { talk: true, mood: r.keen > 0.5 ? 'happy' : undefined }); } catch { /* fine */ } }, 250 + i * 320));
    const what = P.cond?.kind === 'race' ? 'the next race' : P.cond?.kind === 'battle' ? 'the next battle' : 'the next game';
    showDealCard(res, `Deal: whoever wins ${what} gets ${res.deal.prize.label}.`, P, text);
  }
  function showDealCard(res, title, P, text) {
    inviteEl?.remove();
    const close = () => { inviteEl?.remove(); inviteEl = null; };
    const keenest = [...res.reactions].sort((a, b) => b.keen - a.keen);
    const raceNow = P.cond?.kind === 'race' && keenest.length;
    const runners = keenest.filter((r) => r.keen > 0.3).slice(0, 4).map((r) => r.uid);
    inviteEl = h('div', { class: 'invite-card answers-card', role: 'dialog', 'aria-label': title },
      h('div', { class: 'row', style: { alignItems: 'center', gap: '8px' } }, h('b', { class: 'grow' }, `${res.deal.prize.icon ?? '🏆'} ${title}`), h('button', { class: 'btn small', 'aria-label': 'Close', onclick: close }, '✕')),
      h('div', { class: 'col answers-list' }, keenest.map((r) => h('div', { class: 'answer-row' }, spriteCanvas(app.bank, app.save.creatures[r.uid], { scale: 1 }), h('span', { class: 'answer-pic', 'aria-hidden': 'true' }, r.keen > 0.4 ? r.pic : '😐'), h('span', { class: 'answer-text' }, r.note)))),
      raceNow ? h('div', { class: 'row wrap', style: { gap: '6px' } },
        h('button', { class: 'btn small primary', onclick: () => { close(); startRace(runners.length >= 2 ? runners : keenest.slice(0, Math.max(2, Math.min(4, keenest.length))).map((r) => r.uid), text, P.route ?? P.cond?.route ?? null); } }, `Race now! (${(runners.length >= 2 ? runners : keenest.slice(0, 4).map((r) => r.uid)).map(nm).join(', ')})`),
        h('button', { class: 'btn small', onclick: close }, 'Later')) : null);
    for (const ev of ['pointerdown', 'mousedown', 'click', 'wheel']) inviteEl.addEventListener(ev, (e) => e.stopPropagation());
    el.append(inviteEl);
    // "let's race to the tree — winner gets a berry": off they go straight away
    if (P.alsoStart && raceNow) setTimeout(() => { if (!inviteEl) return; close(); startRace(runners.length >= 2 ? runners : keenest.slice(0, 4).map((r) => r.uid), text, P.route ?? P.cond?.route ?? null); }, 2600);
    else setTimeout(() => { if (inviteEl && !inviteEl.matches(':hover')) close(); }, 45000);
  }
  const nm = (u) => displayName(app.idx, app.save.creatures[u]);
  // Helping others rest: one curls up beside whoever's asleep and shares its dreams — they get their energy back
  // half as fast again for a couple of hours; it costs the helper a little (it gets peckish, a little less cheery).
  function dreamHelp(helpers) {
    const sleepers = [...yard.actors.keys()].filter((u) => !helpers.includes(u) && isAsleep(app.save.creatures[u]));
    const h0 = helpers[0]; if (!h0) return;
    if (!sleepers.length) { toast(`Nobody’s asleep right now. ${nm(h0)} will look after whoever naps next.`); app.commit((sv) => { sv.creatures[h0].dreamHelper = Date.now(); }, 'care', { quiet: true }); return; }
    const t = Date.now();
    app.commit((sv) => {
      for (const u of sleepers) { const c = sv.creatures[u]; tickNeeds(app.idx, c, t); c.dreamHelpUntil = t + 2 * 3600000; }
      for (const u of helpers) { const c = sv.creatures[u]; tickNeeds(app.idx, c, t); c.needs.fullness = Math.max(0, (c.needs.fullness ?? 60) - 6); c.needs.joy = Math.max(0, (c.needs.joy ?? 60) - 3); noteDid(c, 'dreamhelp', { t, joy: 0.6 }); }
    }, 'care', { quiet: true });
    const s0 = yard.actors.get(sleepers[0]); if (s0) yard.command?.(h0, { kind: 'goto', x: s0.x + 0.7, z: s0.z });
    setTimeout(() => { for (const u of helpers) askOne(u, 'take a nap', true); syncActors(); renderPanel(); }, 2500);
    toast(`${helpers.map(nm).join(' and ')} curl${helpers.length > 1 ? '' : 's'} up beside ${sleepers.map(nm).slice(0, 3).join(', ')}${sleepers.length > 3 ? '…' : ''} to share their dreams: they’ll rest half as fast again for a couple of hours.`, 'ok');
  }

  // ---------- "who wants to …?": the ones who'd like to step forward, and a button to go and do it ----------
  let inviteEl = null;
  const WANT_COLS = ['#e53935', '#f4511e', '#fb8c00', '#fdd835', '#c0ca33', '#7cb342', '#2e9e48'];
  // the little things done right there in the yard: a cuddle, tag, hide-and-seek, a swim, stargazing…
  function yardRoutine(uids, inv) {
    const S = yard.S ?? {}, x0 = S.x0 ?? -8, x1 = S.x1 ?? 8, z0 = S.z0 ?? 1, z1 = S.z1 ?? 10;
    const rx = () => x0 + 1 + Math.random() * (x1 - x0 - 2), rz = () => z0 + 1 + Math.random() * (z1 - z0 - 2);
    const [seq, pic] = String(inv.seq).split(':');
    const at = (ms, fn) => setTimeout(() => { try { fn(); } catch { /* fine */ } }, ms);
    const cmd = (u, k, extra) => yard.command?.(u, { kind: k, ...extra });
    uids.forEach((u, i) => at(i * 320, () => {
      const c = app.save.creatures[u];
      switch (seq) {
        case 'cuddle': cmd(u, 'come'); at(1500, () => yard.react?.(u, 'hearts', 4)); at(3200, () => yard.react?.(u, 'hearts', 2)); break;
        case 'cheer': cmd(u, 'come'); at(1400, () => { cmd(u, 'jump'); yard.react?.(u, 'hearts', 3); }); at(2600, () => cmd(u, 'spin')); break;
        case 'fetch': cmd(u, 'fetch', { toy: 'ball' }); break;
        case 'ball': cmd(u, 'play'); at(2500, () => cmd(u, 'jump')); break;
        case 'chase': for (let k = 0; k < 4; k++) at(k * 1500, () => cmd(u, 'goto', { x: rx(), z: rz(), dash: true, pace: 1.8 })); at(6200, () => { cmd(u, 'come'); yard.react?.(u, 'note', 2); }); break;
        case 'hide': cmd(u, 'goto', { x: Math.random() < 0.5 ? x0 + 0.8 : x1 - 0.8, z: z1 - 0.8 - Math.random() * 2, dash: true }); at(4500, () => yard.think?.(u, '🙈', 3)); at(8000, () => { yard.emote?.(u, 'exclaim'); cmd(u, 'come'); }); break;
        case 'swim': { const w = yard.waterSpot?.(); if (w) cmd(u, 'goto', { x: w.x, z: w.z }); else cmd(u, 'come'); at(2600, () => { yard.react?.(u, 'note', 2); cmd(u, 'jump'); }); break; }
        case 'show': cmd(u, 'spin'); at(1000, () => cmd(u, 'jump')); at(1900, () => yard.react?.(u, 'sparkle', 4)); at(2800, () => cmd(u, 'spin')); break;
        case 'stretch': cmd(u, 'spin'); at(1600, () => cmd(u, 'sit')); at(2200, () => yard.react?.(u, 'sparkle', 2)); break;
        case 'hop': cmd(u, 'jump'); at(700, () => cmd(u, 'jump')); at(1400, () => { cmd(u, 'jump'); yard.react?.(u, 'note', 2); }); break;
        case 'song': cmd(u, 'dance'); yard.react?.(u, 'note', 5); at(2400, () => yard.react?.(u, 'note', 3)); break;
        case 'climb': cmd(u, 'goto', { x: rx(), z: z1 - 0.6 }); at(3000, () => cmd(u, 'jump')); at(3700, () => cmd(u, 'jump')); break;
        case 'patrol': cmd(u, 'goto', { x: x0 + 0.8, z: rz() }); at(4000, () => cmd(u, 'goto', { x: x1 - 0.8, z: rz() })); at(8500, () => yard.think?.(u, '👀', 3)); break;
        case 'roam': for (let k = 0; k < 3; k++) at(k * 2600, () => cmd(u, 'goto', { x: rx(), z: rz() })); at(8000, () => yard.think?.(u, pic ?? '❓', 3.5)); break;
        case 'think': cmd(u, 'come'); at(1800, () => { cmd(u, 'sit'); yard.think?.(u, pic ?? '💭', 5); }); at(4000, () => yard.react?.(u, 'sparkle', 2)); break;
        case 'follow': cmd(u, 'come'); at(1500, () => cmd(u, 'spin')); at(2500, () => cmd(u, 'jump')); break;
        case 'pair': { const others = [...uids.filter((x) => x !== u), ...(yard.actors ? [...yard.actors.keys()] : [])].filter((x) => x !== u && app.save.creatures[x]); const w = others[0]; if (w) cmd(u, 'pair', { with: w }); else cmd(u, 'come'); break; }
        default: cmd(u, 'come');
      }
      // a little joy for it, and (when it's the running-about kind) a little tiredness; the calm ones rest them a bit
      try { app.commit((sv) => { const cc = sv.creatures[u]; if (!cc) return; const t = Date.now(); tickNeeds(app.idx, cc, t); cc.needs.joy = Math.min(100, (cc.needs.joy ?? 60) + 5); cc.needs.energy = Math.max(5, Math.min(100, (cc.needs.energy ?? 60) + (inv.en === 'active' ? -5 : inv.en === 'calm' ? 2 : -1))); noteDid(cc, inv.id, { t, joy: 0.7 }); }); } catch { /* fine */ }
    }));
    sfx('level');
  }
  function runInvite(uids, inv, said = '', opts = {}) {
    const route = opts?.route ?? null;
    const res = volunteers(app.idx, app.save, uids, inv);
    const kind = inv.like ?? inv.id; // (a picnic is done like a snack…)
    const yes = res.yes.slice(0, kind === 'desktop' ? 6 : kind === 'movie' ? 8 : 4);
    // they come forward, one after another, cheering; the rest shrug
    yes.forEach((v, i) => setTimeout(() => { try { yard.command?.(v.uid, { kind: 'come' }); yard.react?.(v.uid, 'hearts', 1.5); yard.think?.(v.uid, '!', 2.5); creatureCry(speciesOf(app.idx, app.save.creatures[v.uid]), app.save.creatures[v.uid], { talk: true, mood: 'happy' }); } catch { /* fine */ } }, 250 + i * 380));
    res.no.slice(0, 4).forEach((v, i) => setTimeout(() => { try { yard.think?.(v.uid, '…', 2.2); } catch { /* fine */ } }, 400 + i * 300));
    inviteEl?.remove();
    const close = () => { inviteEl?.remove(); inviteEl = null; };
    const names = yes.map((v) => nm(v.uid));
    const list2 = names.length <= 2 ? names.join(' and ') : `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`;
    const go = (label, fn, primary = false) => h('button', { class: `btn small ${primary ? 'primary' : ''}`, onclick: () => { close(); fn(); } }, label);
    let actions = [];
    const first = yes[0]?.uid;
    // doing it with just one of them
    const rowAct = (u) => inv.act ? () => { activitiesView.last = u; activitiesView.autoStart = inv.act; app.go('activities'); }
      : kind === 'desktop' ? () => { let r; app.commit((sv) => { r = toggleBuddy(sv, u, true); }); syncActors(); sfx('warp'); toast(r?.ok === false ? r.reason : `${nm(u)} hopped out onto your desktop.`, r?.ok === false ? 'err' : 'ok'); }
      : kind === 'movie' ? () => { const t0 = Date.now(); let tk = null; app.commit((sv) => { toggleBuddy(sv, u, true); tk = addTask(sv, { id: `task-${u}-${t0.toString(36)}`, uid: u, made: t0, due: t0 + 2 * 86400000, kind: 'wish', key: 'wish:movie', icon: '🎬', text: `${nm(u)} wants to watch a movie with you: right-click them on the desktop → Watch a movie with me, put a video on full screen, then tick this off.` }); }); syncActors(); if (tk) onTasks([tk]); toast(`${nm(u)} came out onto your desktop for the movie.`, 'ok'); }
      : kind === 'groom' ? () => careRoom(u)
      : kind === 'walk' ? () => openMoveTo(app, app.save.creatures[u]).then(() => { syncActors(); renderPanel(); })
      : kind === 'nap' ? () => { askOne(u, 'take a nap', true); syncActors(); renderPanel(); }
      : kind === 'snack' || kind === 'play' ? () => { selected = u; yard.selected = u; openMenu('bag'); }
      : kind === 'dance' ? () => { yard.command?.(u, { kind: 'dance' }); sfx('level'); }
      : kind === 'race' ? () => startRace([u, ...res.yes.map((v) => v.uid).filter((x) => x !== u).slice(0, 1)], said, route)
      : kind === 'dreamhelp' ? () => dreamHelp([u])
      : kind === 'battle' ? () => app.go('battle')
      : inv.seq ? () => yardRoutine([u], inv)
      : () => { yard.command?.(u, { kind: 'come' }); };
    if (yes.length) {
      if (inv.act) actions = yes.slice(0, 3).map((v, i) => go(`${inv.verb} with ${nm(v.uid)}`, () => { activitiesView.last = v.uid; activitiesView.autoStart = inv.act; app.go('activities'); }, i === 0));
      else if (kind === 'desktop') actions = [go(`Send ${yes.length === 1 ? nm(first) : `all ${yes.length}`} to the desktop`, () => { let n = 0, why = ''; app.commit((sv) => { for (const v of yes) { const r = toggleBuddy(sv, v.uid, true); if (r?.ok !== false) n++; else why = r.reason; } }); syncActors(); sfx('warp'); toast(n ? `${n === 1 ? nm(first) : `${n} of them`} hopped out onto your desktop. Call them back from Boxes or the desktop.` : why || 'Couldn’t do that.', n ? 'ok' : 'err'); }, true)];
      else if (kind === 'movie') actions = [go(`Out onto the desktop for a movie`, () => {
        // they come out onto the desktop, and it goes on the task list: put something on full screen (a video in
        // Chrome, a media player…) while they sit with you, then tick it off
        let n = 0; const added = [], t0 = Date.now();
        app.commit((sv) => { for (const v of yes.slice(0, 6)) { const r = toggleBuddy(sv, v.uid, true); if (r?.ok === false && !isDesktopBuddy(sv, v.uid)) continue; n++;
          const tk = addTask(sv, { id: `task-${v.uid}-${(t0 + n).toString(36)}`, uid: v.uid, made: t0, due: t0 + 2 * 86400000, kind: 'wish', key: 'wish:movie', icon: '🎬', text: `${nm(v.uid)} wants to watch a movie with you: with them out on the desktop, right-click them on the desktop → Watch a movie with me, put a video on full screen, then tick this off.` }); if (tk) added.push(tk); } });
        syncActors(); sfx('warp'); if (added.length) onTasks(added);
        toast(n ? `${n === 1 ? nm(first) : `${n} of them`} came out onto your desktop. Put a film on full screen and enjoy it together.` : 'Couldn’t send anyone out.', n ? 'ok' : 'err'); }, true)];
      else if (kind === 'battle') actions = [go('Go to Battle Link', () => app.go('battle'), true)];
      else if (kind === 'race') actions = [go(yes.length >= 2 ? `Race! (${yes.slice(0, 4).map((v) => nm(v.uid)).join(', ')})` : 'Race me!', () => startRace(yes.slice(0, 4).map((v) => v.uid), said, route), true)];
      else if (kind === 'dreamhelp') actions = [go(`${nm(first)} helps the others rest`, () => dreamHelp(yes.slice(0, 2).map((v) => v.uid)), true)];
      else if (kind === 'groom') actions = yes.slice(0, 2).map((v, i) => go(`Quality time with ${nm(v.uid)}`, () => careRoom(v.uid), i === 0));
      else if (kind === 'nap') actions = [go('Off to sleep, then', () => { for (const v of yes) askOne(v.uid, 'take a nap', true); syncActors(); renderPanel(); }, true)];
      else if (kind === 'walk') actions = yes.slice(0, 2).map((v, i) => go(`Send ${nm(v.uid)} to your phone…`, () => openMoveTo(app, app.save.creatures[v.uid]).then(() => { syncActors(); renderPanel(); }), i === 0));
      else if (kind === 'snack') actions = [go('Open the food bag', () => { selected = first; yard.selected = first; openMenu('bag'); }, true)];
      else if (kind === 'play') actions = [go('Get the toys out', () => { selected = first; yard.selected = first; openMenu('bag'); }, true)];
      else if (inv.seq) actions = [go(`${inv.verb}${yes.length > 1 ? ` (${yes.slice(0, 4).map((v) => nm(v.uid)).join(', ')})` : ''}`, () => yardRoutine(yes.slice(0, 4).map((v) => v.uid), inv), true)];
      else if (kind === 'dance') actions = [go('Dance!', () => { yes.forEach((v, i) => setTimeout(() => yard.command?.(v.uid, { kind: 'dance' }), i * 200)); sfx('level'); }, true)];
    }
    inviteEl = h('div', { class: 'invite-card', role: 'dialog', 'aria-label': `Who wants to ${inv.label}` },
      h('div', { class: 'row', style: { alignItems: 'center', gap: '8px' } }, h('b', { class: 'grow' }, `“Who wants to ${inv.label}?”`), h('button', { class: 'btn small', 'aria-label': 'Close', onclick: close }, '✕')),
      yes.length ? h('p', null, `${list2} ${yes.length === 1 ? 'wants' : 'want'} to!`) : h('p', { class: 'dim' }, 'Nobody fancies it right now.'),
      // everyone, by how much they want to: a bar of seven, red (not at all) to green (very much), and a button
      // to pick just that one (when there's only room for one, take whoever wants it most — or whoever you like)
      h('div', { class: 'col invite-who' }, [...res.yes, ...res.no].sort((a, b) => b.score - a.score).slice(0, 12).map((v) => {
        const keen = res.yes.includes(v), segs = Math.max(keen ? 1 : 0, Math.min(7, Math.round((Math.min(0.9, v.score) / 0.9) * 7)));
        const one = keen ? rowAct(v.uid) : null;
        return h('div', { class: `invite-row ${keen ? '' : 'no'}`, title: v.why },
          spriteCanvas(app.bank, app.save.creatures[v.uid], { scale: 1 }),
          h('span', { class: 'invite-name' }, nm(v.uid)),
          h('span', { class: 'want-bar', 'aria-label': `wants to: ${segs} of 7` }, WANT_COLS.map((col, i) => h('i', { style: { background: i < segs ? col : null } }))),
          h('span', { class: 'dim micro invite-why' }, keen || !v.why.startsWith(`${nm(v.uid)} `) ? v.why : v.why.slice(nm(v.uid).length + 1)),
          one ? h('button', { class: 'btn small', onclick: () => { close(); one(); } }, 'Pick') : null);
      })),
      actions.length ? h('div', { class: 'row wrap', style: { gap: '6px' } }, actions) : null);
    el.append(inviteEl);
    setTimeout(() => { if (inviteEl && !inviteEl.matches(':hover')) close(); }, 45000);
    return true;
  }


  // ---------- quality time: the care room ----------
  async function careRoom(uid) {
    yard.stop();
    await openCareRoom(app, uid, {
      biome: habitat()?.biome ?? 'meadow',
      seed: seedOf(cur),
      doCare: (action, opts = {}) => {
        let out;
        app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], action, { ...opts, inventory: save.inventory, save, asked: action === 'play' && wishedFor(save, uid, 'play') }); if (out?.ok !== false && !out?.asleep) tasksDone(noteDone(save, uid, action, opts.item?.id ?? opts.item ?? null)); }, 'care', { quiet: true });
        if (out?.kept) setTimeout(() => toast(out.kept, 'ok'), 500);
        if (out && !out.ok && out.reason) toast(out.reason, 'err');
        return out;
      },
      doTalk: (text) => askOne(uid, text, false),
      doMedicine: (id) => { let r; app.commit((sv) => { r = useMedicine(app.idx, sv, uid, id); }, 'heal'); return r; },
    });
    yard.start();
    syncActors(); renderPanel(); renderHud();
  }

  // ---------- toys and berries from the bag ----------
  // (the toys you own: four to start with, the rest bought at the market)
  const toyList = () => [...ownedToys(app.save), ...app.idx.ds.items.filter((i) => i.kind === 'toy' && !i.unlimited && (app.save.inventory[i.id] ?? 0) > 0)];
  // kibble first (it never runs out), then everything in the bag
  const foodList = () => allFoods(app.idx).filter((it) => it.unlimited || (app.save.inventory[it.id] ?? 0) > 0).sort((a, b) => (b.unlimited ? 1 : 0) - (a.unlimited ? 1 : 0));
  function closeMenu() { menu = null; menuEl.hidden = true; renderHud(); renderMood(); }
  function openMenu(kind) { menu = menu === kind ? null : kind; renderMenu(); renderHud(); renderMood(); }
  // everything other than food and toys: gear to hold, incense, TMs, valuables…
  const otherItems = () => Object.entries(app.save.inventory ?? {}).filter(([, n]) => n > 0).map(([id, n]) => ({ it: itemInfo(app.idx, id), n }))
    .filter(({ it }) => it && it.kind !== 'food' && it.kind !== 'toy' && it.kind !== 'blueprint');
  // (a long bag: smaller list-like rows that scroll inside the bag, and a filter box once it's very long)
  let bagFilter = '';
  const BAG_COMPACT = 10, BAG_FILTER = 18;
  const bagGrid = (list, make) => {
    const q = bagFilter.trim().toLowerCase();
    const shown = q && list.length >= BAG_FILTER ? list.filter((x) => String((x.it ?? x).name ?? '').toLowerCase().includes(q)) : list;
    return [
      list.length >= BAG_FILTER ? h('input', { class: 'hud-bag-filter', type: 'search', placeholder: `Find… (${list.length})`, value: bagFilter, 'aria-label': 'Find in the bag',
        oninput: (e) => { bagFilter = e.target.value; const at = e.target.selectionStart; renderMenu(); const f = menuEl.querySelector('.hud-bag-filter'); if (f) { f.focus(); try { f.setSelectionRange(at, at); } catch { /* fine */ } } } }) : null,
      h('div', { class: `hud-menu-grid ${list.length >= BAG_COMPACT ? 'compact' : ''}` }, shown.length ? shown.map(make) : h('span', { class: 'hud-hint' }, 'Nothing by that name.'))];
  };
  function renderMenu() {
    menuEl.hidden = !menu;
    if (!menu) return;
    const keepScroll = menuEl.querySelector('.hud-menu-grid')?.scrollTop ?? 0;
    const sel = selected && app.save.creatures[selected];
    const tabs = h('div', { class: 'hud-menu-tabs', role: 'tablist' },
      [['food', 'Food'], ['toys', 'Toys'], ['items', 'Items']].map(([k, l]) => h('button', { class: `hud-btn ${bagTab === k ? 'on' : ''}`, role: 'tab', 'aria-selected': String(bagTab === k), onclick: () => { bagTab = k; bagPick = null; bagFilter = ''; renderMenu(); } }, l)),
      h('span', { class: 'grow' }),
      h('span', { class: 'hud-wallet' }, h('span', { class: 'coin' }), ` ${wallet(app.save)}`),
      h('button', { class: 'hud-btn', onclick: () => app.go('market') }, 'Market'));
    let body;
    if (bagTab === 'toys') {
      body = [
        ...bagGrid(toyList(), (it) => {
          const kind = toyKindOf(it);
          const pic = Paint.toy(kind, { w: 40, h: 40 }); pic.className = 'hud-menu-pic';
          return h('button', { class: 'hud-menu-item', title: it.desc ?? '', onclick: () => { yard.throwToy(kind, it, null, forSelected()); sfx('blip'); } }, pic, h('span', null, it.name));
        }),
        h('div', { class: 'row' }, h('button', { class: 'hud-btn', onclick: () => { yard.clearToys(); sfx('back'); } }, 'Put the toys away'), h('span', { class: 'hud-hint' }, forSelected() ? `Click to give one to ${displayName(app.idx, app.save.creatures[forSelected()])} · T to talk` : 'Click to throw one in (select someone first to give it to them) · drag a toy to fling it · T to talk.'))];
    } else if (bagTab === 'food') {
      body = [
        ...bagGrid(foodList(), (it) => h('button', { class: 'hud-menu-item', title: [it.name, foodStats(it), it.desc].filter(Boolean).join('\n'), onclick: () => { if (!it.unlimited && (app.save.inventory[it.id] ?? 0) <= yard.toys.filter((t) => t.item?.id === it.id).length) { toast(`No more ${it.name} to toss.`, 'err'); return; } yard.tossBerry(it, forSelected()); sfx('blip'); } },
          itemIcon(it, 32, { idx: app.idx }), h('span', null, it.name), h('small', null, it.unlimited ? '∞' : `× ${app.save.inventory[it.id] ?? 0}`))),
        h('span', { class: 'hud-hint' }, forSelected() ? `Click to give it to ${displayName(app.idx, app.save.creatures[forSelected()])}: it drops right in front of them.` : 'Click to toss it in: whoever gets there first eats it (select someone first to give it to them). Kibble never runs out, but only fills them a little.')];
    } else {
      const items = otherItems();
      const pickIt = bagPick && itemInfo(app.idx, bagPick);
      const uses = pickIt ? itemUses(pickIt) : [];
      const inc = activeIncense(app.save);
      body = [
        ...(items.length ? bagGrid(items, ({ it, n }) => h('button', { class: `hud-menu-item ${bagPick === it.id ? 'on' : ''}`, title: [it.name, foodStats(it), itemDesc(it)].filter(Boolean).join('\n'), onclick: () => { bagPick = bagPick === it.id ? null : it.id; renderMenu(); } },
          itemIcon(it, 32, { idx: app.idx }), h('span', null, it.name), h('small', null, `× ${n}`)))
          : [h('p', { class: 'hud-hint' }, 'No items yet. Walks turn things up, and the Market sells gear, incense and TMs.')]),
        pickIt ? h('div', { class: 'hud-bag-pick' },
          h('div', { class: 'col grow' }, h('strong', null, pickIt.name), foodStats(pickIt) ? h('small', { class: 'food-stats' }, foodStats(pickIt)) : null, h('small', null, itemDesc(pickIt))),
          h('div', { class: 'row wrap' },
            uses.includes('hold') ? h('button', { class: 'hud-btn', disabled: !sel, title: sel ? '' : 'Click someone in the yard first', onclick: () => giveHeld(sel, pickIt.id) }, sel ? `Give to ${displayName(app.idx, sel)}` : 'Give to… (pick someone)') : null,
            uses.includes('light') ? h('button', { class: 'hud-btn', disabled: !!inc, title: inc ? `${inc.name} is already burning` : 'An hour of its type turning up more on walks', onclick: () => {
              let r; app.commit((sv) => { r = lightIncense(app.idx, sv, pickIt.id); }, 'incense', { quiet: true });
              if (!r?.ok) { toast(r?.reason ?? 'Couldn’t light it.', 'err'); return; }
              sfx('heal'); app.say(`${pickIt.name} is lit: an hour of its type turning up more on walks.`); bagPick = null; renderMenu();
            } }, inc ? 'One is already lit' : 'Light it') : null,
            healingOf(pickIt) ? h('button', { class: 'hud-btn', disabled: !sel, title: sel ? '' : 'Click someone in the yard first', onclick: () => {
              let r; app.commit((sv) => { r = useMedicine(app.idx, sv, sel.uid, pickIt.id); }, 'heal', { quiet: true });
              if (!r?.ok) { toast(r?.reason ?? 'That didn’t help.', 'err'); return; }
              sfx('heal'); yard.react(sel.uid, 'sparkle', 3); app.say(r.text); renderMenu(); renderPanel();
            } }, sel ? `Use on ${displayName(app.idx, sel)}` : 'Use on… (pick someone)') : null,
            uses.includes('wear') && sel ? h('button', { class: 'hud-btn', onclick: async () => { closeMenu(); yard.stop(); await openDressUp(app, sel.uid); yard.start(); syncActors(); renderPanel(); } }, 'Dress up…') : null,
            pickIt.kind === 'tm' ? h('button', { class: 'hud-btn', onclick: () => app.go('battle') }, 'Teach (Battle Link → team)') : null,
            uses.includes('sell') ? h('button', { class: 'hud-btn', onclick: () => app.go('market') }, 'Sell…') : null)) : null,
        inc ? h('span', { class: 'hud-hint' }, `${inc.name} is burning for another ${Math.ceil((inc.until - Date.now()) / 60000)} min.`) : null];
    }
    mount(menuEl, h('div', { class: 'hud-menu-head' }, 'Bag'), tabs, body);
    const g = menuEl.querySelector('.hud-menu-grid'); if (g && keepScroll) g.scrollTop = keepScroll;
  }

  /** Right-click someone in the yard: everything you can do with them, in one place. */
  function creatureMenu(uid, ev) {
    const c = app.save.creatures[uid];
    if (!c) return;
    document.querySelector('.quick-menu')?.remove();
    selected = uid; yard.selected = uid; panelOpen = true; renderPanel(); renderHud();
    const item = (label, fn, cls = '') => h('button', { class: cls, onclick: () => { menuBox.remove(); fn(); } }, label);
    const sep = (t) => h('div', { class: 'qm-sep' }, t);
    const heldName = c.heldItemId ? itemInfo(app.idx, c.heldItemId)?.name : null;
    const menuBox = h('div', { class: 'quick-menu', style: { left: `${Math.min(ev.clientX, innerWidth - 230)}px`, top: `${Math.min(ev.clientY, innerHeight - 340)}px` } },
      h('div', { class: 'qm-title' }, displayName(app.idx, c)),
      sep('Care'),
      item('Quality time', () => careRoom(uid)),
      item('Pet', () => care(uid, 'pet')),
      isAsleep(c) ? (() => { const b = item('Wake up', () => care(uid, 'wake')); if (wakeRisk(c)) b.title = WAKE_HINT; return b; })() : item('Nap', () => care(uid, 'rest')),
      item('Dress up', async () => { yard.stop(); await openDressUp(app, uid); yard.start(); syncActors(); renderPanel(); }),
      item('📖 Journal', () => openJournal({ idx: app.idx, bank: app.bank, save: app.save }, c)),
      item(yard.followUid === uid ? 'Stop following' : '🎥 Follow with the camera', () => { yard.follow(yard.followUid === uid ? null : uid); renderHud(); }),
      sep('Items'),
      item(heldName ? `Holding: ${heldName}…` : 'Give an item to hold…', () => giveHeld(c)),
      (app.save.pokeblocks ?? []).length && !c.egg ? item(`Give a Pokéblock… (${app.save.pokeblocks.length})`, () => giveBlock(c)) : null,
      ...(() => { const ch = changeItems(app, c, item, () => { syncActors(); yard.react(c.uid, 'sparkle', 4); renderPanel(); renderHud(); }); return ch.length ? [sep('Change'), ...ch] : []; })(),
      sep('Move'),
      party(app.save).length < app.idx.ds.rules.partySize ? item('Take into the party', () => toParty(c)) : null,
      !c.egg ? item('Send to the desktop', () => toDesktop(c)) : null,
      item('Release…', () => releaseIt(c), 'danger'));
    document.body.append(menuBox);
    // keep it on screen
    const rb = menuBox.getBoundingClientRect();
    menuBox.style.top = `${Math.max(8, Math.min(ev.clientY, innerHeight - rb.height - 8))}px`;
    menuBox.style.left = `${Math.max(8, Math.min(ev.clientX, innerWidth - rb.width - 8))}px`;
    const close = (e) => { if (!menuBox.contains(e.target)) { menuBox.remove(); window.removeEventListener('pointerdown', close, true); } };
    setTimeout(() => window.addEventListener('pointerdown', close, true), 0);
  }
  function toParty(c) {
    const rect = yard.screenRect(c.uid);
    let r; app.commit((s) => { r = moveCreature(s, c.uid, { kind: 'party' }, app.idx.ds.rules.partySize); }, 'move', { quiet: true });
    if (r && !r.ok) return toast(r.error, 'err');
    const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
    selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
    if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: typeTint(c), say: transferLine('party', displayName(app.idx, c)) });
    else sfx('access');
  }
  function toDesktop(c) {
    const rect = yard.screenRect(c.uid);
    let r; app.commit((s) => { r = toggleBuddy(s, c.uid, true); });
    if (!r.ok) { toast(r.reason, 'err'); return; }
    const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
    selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
    const say = `${displayName(app.idx, c)} hopped out onto your desktop.`;
    if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: typeTint(c), say }); else app.say(say);
  }
  async function releaseIt(c) {
    const name = displayName(app.idx, c);
    if (!(await confirmDialog(`Release ${name}?`, `${name} will return to the wild for good. This can’t be undone.`, { ok: 'Release', danger: true }))) return;
    const rect = yard.screenRect(c.uid);
    const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
    app.commit((s) => releaseCreature(s, c.uid), 'release', { quiet: true });
    selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
    const say = `${name} looked back once, then headed off into the wild.`;
    if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: '#ffffff', say });
    app.say(say);
  }

  // ---------- the berry farm ----------
  async function plotClick(i) {
    const st = plotStatus(app.idx, farmState(app.save).plots[i]);
    if (st.ready) {
      let r;
      app.commit((s) => { r = harvest(app.idx, s, i); }, 'farm', { quiet: true });
      if (r?.ok) { sfx('level'); toast(`Picked ${r.count} ${r.item.name}${r.bonus ? ` (${r.bonus} extra!)` : ''}.${r.regrew ? ' The Gooey Mulch makes it grow back.' : ''}`, 'ok'); }
    } else if (st.empty) {
      const seeds = plantable(app.idx).filter((it) => it.unlimited || (app.save.inventory[it.id] ?? 0) > 0);
      const pick = await chooseDialog('Plant something', seeds.map((it) => ({ value: it.id, label: it.name, detail: `${app.save.inventory[it.id] ?? 0} in the bag · ripe in ${growInfo(it).hours} h · gives ${growInfo(it).yield}` })), { empty: 'Nothing to plant. Walks turn up berries and roots, and the Market sells them; plant one to grow more.' });
      if (!pick) return;
      // mulch, if you have some
      let mulch = null;
      const ms = mulchInBag(app.save);
      if (ms.length) {
        mulch = await chooseDialog('Spread some mulch?', [{ value: '__none', label: 'No mulch', detail: 'Just plant it.' }, ...ms.map((m) => ({ value: m.id, label: m.name, detail: `${m.desc} · ${m.n} in the bag` }))]);
        if (!mulch) return;
        if (mulch === '__none') mulch = null;
      }
      let r;
      app.commit((s) => { r = plant(app.idx, s, i, pick, Date.now(), mulch); }, 'farm', { quiet: true });
      if (r && !r.ok) toast(r.reason, 'err'); else sfx('heal');
    } else toast(`${st.item?.name ?? 'It'} is ripe in ${fmtLeft(st.left)}.`);
    syncPlots(); renderPanel();
  }

  async function bring() {
    const to = cur === 'ranch' ? { kind: 'ranch' } : (() => { const t = firstFreeBoxSlot(app.save, 30, cur); return t && t.box === cur ? t : null; })();
    if (!to) { toast('This yard is full (30 creatures).', 'err'); return; }
    const options = list(app.save).filter((c) => ['party', 'box', 'ranch'].includes(c.location.kind) && !(cur === 'ranch' ? c.location.kind === 'ranch' : c.location.kind === 'box' && c.location.box === cur));
    const uid = await chooseDialog('Bring someone to this yard', options.map((c) => ({
      value: c.uid, label: displayName(app.idx, c), detail: `Lv. ${c.level} · ${c.location.kind === 'party' ? 'party' : c.location.kind === 'ranch' ? 'free range' : app.save.boxes[c.location.box]?.name}`,
      el: spriteCanvas(app.bank, c, { scale: 1 }),
    })), { empty: 'Everyone is already here.' });
    if (!uid) return;
    let r;
    app.commit((s) => { r = moveCreature(s, uid, { ...to }, app.idx.ds.rules.partySize); }, 'move', { quiet: true });
    if (r && !r.ok) { toast(r.error, 'err'); return; }
    syncActors();
    const a = yard.actors.get(uid);
    if (a) a.appear = -1.1; // shows up as the light lands
    const who = app.save.creatures[uid];
    const art = h('span', null, spriteCanvas(app.bank, who, { scale: 2 }));
    playTransfer({ to: yard.screenRect(uid), mode: 'arrive', spriteEl: art, tint: typeTint(who), say: transferLine(cur === 'ranch' ? 'ranch' : 'box', displayName(app.idx, who), { box: app.save.boxes[cur]?.name }) });
    renderHud();
  }

  function renderHud() {
    // build mode: the thing being placed (or moved) follows the pointer
    try { yard.setGhost(building && area === 'yard' ? (placing ?? (picked ? buildOf().features.find((f) => f.id === picked)?.bp ?? null : null)) : null, placing ? null : picked); } catch { /* not ready */ }
    const hb = habitat();
    const n = here().length;
    const where = area === 'yard' ? (typeof cur === 'number' ? `YARD ${String(cur + 1).padStart(2, '0')}` : 'FREE RANGE') : 'BERRY FARM';
    mount(hudTL,
      h('div', { class: 'hud-kicker' }, 'R.A.N.C.H.', h('span', null, ` // ${where}`)),
      h('div', { class: 'hud-title' }, area === 'yard' ? hb.name : 'Berry farm'),
      h('div', { class: 'hud-sub' }, area === 'yard' ? `${BIOME_INFO[hb.biome]?.label ?? hb.biome} · ${YARD_SIZES[buildOf().size ?? 0].label} · ${n} creature${n === 1 ? '' : 's'} here${guests?.key === cur ? ` · ${guests.snap.creatures.length} visiting` : ''}` : 'Plant food, pick it when ripe'),
      h('div', { class: 'hud-areas', role: 'tablist', 'aria-label': 'Area' }, AREAS.map(([id, label]) => h('button', { class: `hud-btn ${area === id ? 'on' : ''}`, role: 'tab', 'aria-selected': String(area === id), onclick: () => goArea(id) }, label))));
    mount(hudTR,
      h('div', { class: 'row' },
        h('button', { class: 'hud-btn task-btn', title: 'Your creatures’ wishes: things they’ve asked for', 'aria-label': `Task list, ${(app.save.tasks ?? []).length} waiting`, onclick: openTasks },
          '📝 Tasks', (app.save.tasks ?? []).length ? h('span', { class: 'task-count' }, String((app.save.tasks ?? []).length)) : null),
        h('button', { class: 'hud-btn', 'aria-label': 'Previous box', title: 'Previous box (Page Up)', onclick: () => stepHabitat(-1) }, '◀'),
        h('select', { class: 'hud-select', 'aria-label': 'Box', onchange: (e) => switchTo(e.target.value === 'ranch' ? 'ranch' : Number(e.target.value)) },
          habitats().map((x) => h('option', { value: String(x.key), selected: x.key === cur }, x.name))),
        h('button', { class: 'hud-btn', 'aria-label': 'Next box', title: 'Next box (Page Down)', onclick: () => stepHabitat(1) }, '▶'),
        h('button', { class: `hud-btn ${panelOpen ? 'on' : ''}`, title: 'Show or hide the yard log', onclick: () => { panelOpen = !panelOpen; logPinned = panelOpen; if (panelOpen) { selected = null; yard.selected = null; } renderPanel(); renderHud(); } }, panelOpen ? 'Hide log' : 'Log')),
      area === 'yard' ? h('label', { class: 'row hud-env' }, h('span', null, 'Environment'),
        h('select', { class: 'hud-select', onchange: (e) => {
          const v = e.target.value;
          app.commit((s) => { if (cur === 'ranch') s.ranch = { ...(s.ranch || {}), biome: v }; else s.boxes[cur].biome = v; }, 'wallpaper', { quiet: true });
          yard.setBiome(v, seedOf(cur)); yard.setWeather(yardWeatherSetting(app.save)); syncActors(); yard.materialize(); sfx('warp'); renderHud();
        } }, BIOME_IDS.map((id) => h('option', { value: id, selected: id === hb.biome }, BIOME_INFO[id].label)))) : null,
      h('label', { class: 'row hud-env' }, h('span', null, 'Time'),
        h('select', { class: 'hud-select', title: 'Local time follows the real sunrise and sunset where you are (Settings → Where you are), or this computer’s clock', onchange: (e) => {
          const v = e.target.value; app.commit((s) => { s.settings.ranchTime = v; }, 'settings', { quiet: true }); yard.setTime(v); syncActors(); sfx('warp');
        } }, [['local', 'Local time'], ['dawn', 'Morning'], ['day', 'Day'], ['dusk', 'Evening'], ['night', 'Night']].map(([v, l]) => h('option', { value: v, selected: v === (app.save.settings?.ranchTime ?? 'local') }, l)))),
      area === 'yard' ? h('label', { class: 'row hud-env' }, h('span', null, 'Weather'),
        h('select', { class: 'hud-select', title: 'Where you are: the real weather (from your phone, or Settings → Where you are). Simulated: changes every few hours, the way this kind of place tends to.', onchange: (e) => {
          const v = e.target.value; app.commit((s) => { s.settings.ranchWeather = v; }, 'settings', { quiet: true }); yard.setWeather(v); weatherReact(); sfx('warp'); renderHud();
        } }, [['real', `Where you are (${yardWeather() ? WEATHER_LABEL[yardWeather()] ?? '' : 'not known: simulated'})`], ['sim', `Simulated (${WEATHER_LABEL[yard.weatherMode === 'sim' ? yard.weather : 'clear'] ?? '☀ Clear'})`], ...Object.entries(WEATHER_LABEL)].map(([v, l]) => h('option', { value: v, selected: v === (yardWeatherSetting(app.save)) }, l)))) : null,
      area === 'yard' ? h('label', { class: 'row hud-env' }, h('span', null, 'Camera'),
        h('select', { class: 'hud-select', title: 'Keep the camera on someone (in cinematic mode too)', onchange: (e) => { yard.follow(e.target.value || null); sfx('move'); renderHud(); } },
          [h('option', { value: '' }, 'Free'), ...here().filter((x) => !x.egg).map((x) => h('option', { value: x.uid, selected: yard.followUid === x.uid }, `Follow ${displayName(app.idx, x)}`))])) : null,
      h('button', { class: 'hud-btn', title: 'Cinematic mode: full screen, no buttons, the camera drifts on its own (or round whoever you follow). Esc to leave.', onclick: () => cinematic(true) }, '🎬 Cinematic'));
    mount(hudBottom,
      area === 'yard' && building ? [
        h('button', { class: 'hud-btn wide on', onclick: () => setBuilding(false) }, 'Done building'),
        h('span', { class: 'hud-hint' }, placing ? `Click the ground to place the ${blueprintOf(placing)?.name}` : picked ? 'Click the ground to move it there · or put it away from the panel' : 'Pick a blueprint from the panel, or click something built to move it'),
      ] : area === 'yard' ? [
        h('span', { class: 'hud-group' },
          h('button', { class: `hud-btn wide ${menu === 'bag' ? 'on' : ''}`, 'aria-expanded': String(menu === 'bag'), title: 'Food, toys and items', onclick: () => openMenu('bag') }, '🎒 Bag ▴')),
        h('span', { class: 'hud-group' },
          h('button', { class: 'hud-btn wide', onclick: bring }, 'Bring someone'),
          h('button', { class: 'hud-btn wide', title: 'Place blueprints from the Market, expand the yard, see who thrives here', onclick: () => setBuilding(true) }, 'Build')),
        h('span', { class: 'hud-hint' }, 'Rub to pet · right-click for more · drag to pick up · click someone, then a toy or play area to use it · shift+click: send them anywhere · scroll to zoom'),
      ] : h('span', { class: 'hud-hint' }, 'Click a plot to plant or pick · drag the ground to look around'),
      h('span', { class: 'hud-orbit' },
        h('button', { class: 'hud-btn', title: 'Zoom in (+)', 'aria-label': 'Zoom in', onclick: () => yard.zoom(-1) }, '+'),
        h('button', { class: 'hud-btn', title: 'Zoom out (−)', 'aria-label': 'Zoom out', onclick: () => yard.zoom(1) }, '−'),
        h('button', { class: 'hud-btn', title: 'Turn left (Q)', 'aria-label': 'Turn the view left', onclick: () => yard.turn(-1) }, '⟲'),
        h('button', { class: 'hud-btn', title: 'Face the front (R)', 'aria-label': 'Reset the view', onclick: () => { yard.turn(0); yard.zoom(0); } }, '◎'),
        h('button', { class: 'hud-btn', title: 'Turn right (E)', 'aria-label': 'Turn the view right', onclick: () => yard.turn(1) }, '⟳')),
      h('span', { class: 'hud-link', title: 'Live data link to this area' }, h('i'), 'LINK STABLE'));
  }

  function farmPanel() {
    const farm = farmState(app.save);
    const seeds = plantable(app.idx);
    return [
      h('div', { class: 'holo-head' }, 'Berry farm'),
      h('p', { class: 'holo-dim' }, 'Plant one of a food from your bag and pick several when it ripens. Plants keep growing while the app is closed.'),
      h('div', { class: 'holo-list' }, farm.plots.slice(0, farmPlots(app.save)).map((p, i) => {
        const st = plotStatus(app.idx, p);
        return h('button', { class: 'holo-row', onclick: () => plotClick(i) },
          h('span', { class: 'plot-dot', style: { background: st.empty ? '#6b4423' : st.item?.color ?? '#3fb26a' } }),
          h('span', { class: 'grow' }, st.empty ? `Plot ${i + 1}: empty` : `${st.item?.name ?? st.itemId}${st.mulch ? ` · ${blueprintOf(st.mulch)?.name ?? 'mulch'}` : ''}`),
          h('span', { class: 'holo-dim' }, st.empty ? 'Plant' : st.ready ? 'Ready!' : fmtLeft(st.left)));
      })),
      h('div', { class: 'row wrap gap' },
        h('span', { class: 'holo-dim grow' }, `${farmPlots(app.save)} planters${(farm.size ?? 0) < MAX_FARM_SIZE ? '' : ' (as big as it gets)'}`),
        (farm.size ?? 0) < MAX_FARM_SIZE ? h('button', { class: 'btn small', title: 'Needs a Farm Expansion from the Market (Blueprints → Berry farm)', onclick: () => {
          let r; app.commit((s) => { r = expandFarm(s); }, 'farm', { quiet: true });
          if (!r?.ok) { toast(r?.reason ?? 'Couldn’t expand.', 'err'); return; }
          sfx('level'); toast(`The farm grew: ${r.plots} planters now!`, 'ok'); yard.setFarmSize(r.size); syncPlots(); renderPanel();
        } }, `Expand the farm (${app.save.inventory[bpId('farm-expand')] ?? 0})`) : null),
      h('div', { class: 'holo-head' }, 'Tools'),
      farmTools(app.save).length ? h('div', { class: 'col' }, farmTools(app.save).map((t) => h('small', { class: 'holo-dim' }, `${t.name}: ${t.desc.replace(/ Kept for good\.$/, '')}`)))
        : h('p', { class: 'holo-dim' }, 'No tools yet. A Sprayduck or Wailmer Pail speeds everything up; a Harvest Basket or Golden Shears gets you more at harvest (Market → Blueprints → Berry farm).'),
      mulchInBag(app.save).length ? h('p', { class: 'holo-dim' }, `Mulch: ${mulchInBag(app.save).map((m) => `${m.name} × ${m.n}`).join(', ')} (choose when planting)`) : null,
      h('div', { class: 'holo-head' }, 'Seeds in the bag'),
      h('div', { class: 'kv holo-kv' }, seeds.map((it) => [h('span', null, it.name), h('span', null, `× ${app.save.inventory[it.id] ?? 0}`)])),
    ];
  }
  // ---------- cinematic mode: a living wallpaper of the yard ----------
  function cinematic(on) {
    if (on === cinemaOn) return;
    cinemaOn = on;
    el.classList.toggle('cinema', on);
    yard.cinema(on);
    if (on) { selected = null; yard.selected = null; panelOpen = false; closeMenu(); renderPanel(); el.requestFullscreen?.().catch(() => {}); sfx('warp'); }
    else if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
    setTimeout(() => yard.resize(), 200);
  }
  const onFsChange = () => { if (!document.fullscreenElement && cinemaOn) cinematic(false); };
  document.addEventListener('fullscreenchange', onFsChange);
  el.addEventListener('pointerdown', () => { if (cinemaOn) cinematic(false); }, true);

  // ---------- building: blueprints from the Market ----------
  function setBuilding(on) {
    building = on; placing = null; picked = null;
    yard.buildMode = on; yard.pickedFeature = null;
    closeMenu();
    if (on) { panelOpen = true; selected = null; yard.selected = null; }
    sfx(on ? 'access' : 'back');
    renderPanel(); renderHud();
  }
  function placeAt(at) {
    if (!building) return;
    let r;
    if (placing) {
      app.commit((s) => { r = placeFeature(s, cur, placing, at.x, at.z); }, 'build', { quiet: true });
      if (!r?.ok) { toast(r?.reason ?? 'Couldn’t build that here.', 'err'); return; }
      sfx('level'); app.say(`Built the ${blueprintOf(placing)?.name}.`);
      if ((app.save.inventory[bpId(placing)] ?? 0) <= 0) placing = null;
    } else if (picked) {
      app.commit((s) => { r = moveFeature(s, cur, picked, at.x, at.z); }, 'build', { quiet: true });
      sfx('blip');
    } else return;
    syncActors(); renderPanel(); renderHud();
  }
  function buildPanel() {
    const b = buildOf();
    const folk = here();
    const owned = BLUEPRINTS.filter((bp) => bp.kind !== 'expand' && bp.kind !== 'farm' && bp.kind !== 'gear' && (app.save.inventory[bpId(bp.id)] ?? 0) > 0);
    const expands = app.save.inventory[bpId('expand')] ?? 0;
    const rep = thriveReport(app.idx, app.save, cur, folk);
    const gate = b.features.some((f) => f.bp === 'link-gate');
    const pickedF = b.features.find((f) => f.id === picked);
    return [
      h('div', { class: 'holo-head' }, 'Build'),
      h('p', { class: 'holo-dim' }, `${YARD_SIZES[b.size ?? 0].label} yard · ${b.features.length} of ${featureRoom(b.size)} spots used. Blueprints come from the Market.`),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small', disabled: (b.size ?? 0) >= MAX_YARD_SIZE || !expands, title: expands ? '' : 'Buy a Yard Expansion at the Market', onclick: () => {
          let r; app.commit((s) => { r = expandYard(s, cur); }, 'build', { quiet: true });
          if (!r?.ok) { toast(r.reason, 'err'); return; }
          sfx('warp'); app.say(`The yard grew: now ${YARD_SIZES[r.size].label.toLowerCase()}.`); syncActors(); yard.materialize(); renderPanel(); renderHud();
        } }, (b.size ?? 0) >= MAX_YARD_SIZE ? 'Biggest it gets' : `Expand the yard${expands ? ` (${expands})` : ''}`),
        h('button', { class: 'btn small', onclick: () => app.go('market') }, 'Market')),
      pickedF ? [
        h('div', { class: 'holo-head small' }, blueprintOf(pickedF.bp)?.name),
        h('p', { class: 'holo-dim' }, 'Click the ground to move it.'),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn small', onclick: () => { let r; app.commit((s) => { r = removeFeature(s, cur, pickedF.id); }, 'build', { quiet: true }); if (!r?.ok) { toast(r?.reason ?? 'Couldn’t put it away.', 'err'); return; } picked = null; yard.pickedFeature = null; sfx('back'); syncActors(); renderPanel(); renderHud(); } }, 'Put it away'),
          h('button', { class: 'btn small', onclick: () => { picked = null; yard.pickedFeature = null; renderPanel(); renderHud(); } }, 'Done'))] : null,
      h('div', { class: 'holo-head small' }, 'Blueprints in the bag'),
      owned.length ? h('div', { class: 'holo-list' }, owned.map((bp) => h('button', { class: `holo-row ${placing === bp.id ? 'on' : ''}`, onclick: () => { placing = placing === bp.id ? null : bp.id; picked = null; yard.pickedFeature = null; sfx('move'); renderPanel(); renderHud(); } },
        h('span', { class: 'grow' }, bp.name), h('span', { class: 'holo-dim' }, `× ${app.save.inventory[bpId(bp.id)]}`), h('span', { class: 'holo-dim' }, placing === bp.id ? 'placing…' : 'Place'))))
        : h('p', { class: 'holo-dim' }, 'None. Buy blueprints at the Market (ponds, sun patches, slides, toy chests…).'),
      b.features.length ? [h('div', { class: 'holo-head small' }, 'Built here'),
        h('div', { class: 'holo-list' }, b.features.map((f) => {
          const fans = folk.filter((c) => appeal(app.idx, c, f.bp) > 0.35).length, foes = folk.filter((c) => appeal(app.idx, c, f.bp) < -0.35).length;
          return h('button', { class: `holo-row ${picked === f.id ? 'on' : ''}`, onclick: () => { picked = picked === f.id ? null : f.id; placing = null; yard.pickedFeature = picked; renderPanel(); renderHud(); } },
            h('span', { class: 'grow' }, blueprintOf(f.bp)?.name ?? f.bp), h('span', { class: 'holo-dim' }, `${fans ? `♥ ${fans}` : ''}${foes ? ` ✗ ${foes}` : ''}`));
        }))] : null,
      h('div', { class: 'holo-head small' }, 'Who thrives here'),
      rep.rows.length ? h('div', { class: 'holo-list' }, rep.rows.map((r) => h('div', { class: 'holo-row thrive' },
        h('span', { class: `thrive-dot t-${r.label.toLowerCase()}` }), h('span', { class: 'grow col' }, h('span', null, `${r.name} · ${r.label}`), h('small', { class: 'holo-dim' }, r.reasons.join(', ') || '—')))))
        : h('p', { class: 'holo-dim' }, 'Nobody lives here yet.'),
      rep.pairs.length ? [h('div', { class: 'holo-head small' }, 'Good together'), h('div', { class: 'holo-list' }, rep.pairs.map((p) => h('div', { class: 'holo-row' }, h('span', { class: 'grow' }, `${p.a} & ${p.b}`), h('span', { class: 'holo-dim' }, p.why))))] : null,
      gate ? linkGatePanel() : null,
    ];
  }
  // ---------- the Link gate: a friend's yard beside yours ----------
  function linkGatePanel() {
    const snapFile = () => {
      const snap = ranchSnapshot(app.idx, app.save, cur, here());
      const blob = new Blob([JSON.stringify(snap, null, 1)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = `${(app.save.trainer?.name ?? 'ranch').replace(/[^\w-]+/g, '_')}-${(habitat().name ?? 'yard').replace(/[^\w-]+/g, '_')}.clranch`;
      a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      toast('Saved your yard. Send the file to a friend; they open it at their Link gate.', 'ok');
    };
    const open = () => {
      const inp = h('input', { type: 'file', accept: '.clranch,application/json', class: 'hidden', onchange: async (e) => {
        const f = e.target.files[0]; if (!f) return;
        const r = readSnapshot(app.idx, await f.text());
        if (!r.ok) { toast(r.reason, 'err'); return; }
        guests = { snap: r.snap, key: cur };
        syncActors();
        for (const g of r.snap.creatures) { const a = yard.actors.get(`guest:${g.uid}`); if (a) a.appear = -0.6 - Math.random(); }
        sfx('warp');
        app.say(`${r.snap.trainer.name}’s creatures came through the Link gate to visit!${r.missing.length ? ` (${r.missing.length} kind${r.missing.length > 1 ? 's' : ''} you don’t have data for yet: ${r.missing.slice(0, 3).join(', ')}${r.missing.length > 3 ? '…' : ''})` : ''}`);
        renderPanel(); renderHud();
      } });
      document.body.append(inp); inp.click(); setTimeout(() => inp.remove(), 60000);
    };
    return [
      h('div', { class: 'holo-head small' }, 'Link gate'),
      h('p', { class: 'holo-dim' }, 'Join a friend’s yard to yours, side by side: their creatures visit and play with yours, and they can make friends. For now you swap yards as files; live links over the internet come later.'),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small', onclick: snapFile }, 'Save this yard for a friend'),
        guests?.key === cur ? h('button', { class: 'btn small', onclick: () => { guests = null; syncActors(); sfx('back'); app.say('Your visitors headed home.'); renderPanel(); renderHud(); } }, 'Send visitors home')
          : h('button', { class: 'btn small primary', onclick: open }, 'Open a friend’s yard')),
    ];
  }

  // ---------- machines: fossil revival and the egg incubator ----------
  function machinesPanel() {
    const fm = machinesIn(app.save, cur, 'fossil-machine'), inc = machinesIn(app.save, cur, 'incubator'), bl = machinesIn(app.save, cur, 'berry-blender');
    if (!fm.length && !inc.length && !bl.length) return null;
    const hrs = (ms) => { const m = Math.ceil(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`; };
    const eggs = here().filter((x) => x.egg);
    return [
      h('div', { class: 'holo-head small' }, 'Machines'),
      fm.map((f) => {
        const st = revivalStatus(app.idx, app.save, f.id);
        return h('div', { class: 'holo-row' }, h('span', { class: 'grow col' }, h('span', null, 'Fossil Revival Machine'),
          h('small', { class: 'holo-dim' }, st.idle ? 'Empty. Fossils turn up (very rarely) when scavenging.' : st.busy ? `Reviving a ${st.fossil?.name}… ${hrs(st.left)} left` : `Done! Something’s moving in there.`)),
          st.idle ? h('button', { class: 'btn small', onclick: () => reviveFossil(f.id) }, 'Revive a fossil…')
            : st.ready ? h('button', { class: 'btn small primary', onclick: () => {
              let r; app.commit((s) => { r = collectRevival(app.idx, s, f.id, { trainer: s.trainer?.name ?? '' }); }, 'revive');
              if (!r?.ok) { toast(r?.reason ?? 'Not yet.', 'err'); return; }
              sfx('level'); app.say(`${r.name} woke up from a very long sleep and joined you!`); syncActors(); const a = yard.actors.get(r.creature.uid); if (a) a.appear = -1.2; renderPanel(); renderHud();
            } }, 'Open it') : null);
      }),
      bl.length ? h('div', { class: 'holo-row' }, h('span', { class: 'grow col' }, h('span', null, 'Berry Blender'),
        h('small', { class: 'holo-dim' }, `Make Pokéblocks with friends (or helpers). ${(app.save.pokeblocks ?? []).length} in your Pokéblock Case.`)),
        h('button', { class: 'btn small primary', onclick: () => openBlender() }, 'Blend…')) : null,
      inc.length ? h('div', { class: 'holo-row' }, h('span', { class: 'grow col' }, h('span', null, 'Egg Incubator'),
        h('small', { class: 'holo-dim' }, eggs.length ? eggs.map((e) => `${displayName(app.idx, e)} ${Math.round(eggProgress(e) * 100)}%`).join(' · ') + ' — warm and hatching four times as fast' : 'No eggs in this yard. Eggs living here hatch four times as fast.'))) : null,
    ];
  }
  function openBlender() {
    yard.stop();
    hostBerryBlender(app, { session: friendsSession(app), yardKey: cur }).finally(() => { const wait = setInterval(() => { if (!document.querySelector('.bb-scrim')) { clearInterval(wait); yard.start(); renderPanel(); } }, 500); });
  }
  /** Double-clicked a machine in the yard. */
  // the Item Restorer: pick something dug up dirty, then brush it off, rinse it and polish it (hold each one
  // until its bar fills, in order) — and it's the real thing
  function openRestorer() {
    const dirty = () => Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && cleanOf(id)).map(([id, n]) => ({ id, n, it: itemInfo(app.idx, id), real: itemInfo(app.idx, cleanOf(id)) }));
    if (!dirty().length) { toast('Nothing dirty to clean. Great scavenging digs sometimes turn up muddy TMs, incense and gear.', 'err'); return; }
    dialog('Item Restorer', (close) => {
      const body = h('div', { class: 'col restorer' });
      const STEPS = [['🪥', 'Brush off', '#c8a06a'], ['💧', 'Rinse', '#4aa8e8'], ['✨', 'Polish', '#ffd23f']];
      const pickOne = () => {
        const L = dirty();
        if (!L.length) { mount(body, h('p', null, 'All clean!'), h('button', { class: 'btn primary', onclick: () => close() }, 'Done')); return; }
        mount(body, h('p', { class: 'dim' }, 'What shall we clean up?'), h('div', { class: 'col', style: { gap: '6px' } }, L.map((d) => h('button', { class: 'btn choose-row', style: { justifyContent: 'flex-start' }, onclick: () => clean(d) }, itemIcon(d.real ?? d.it, 32, { idx: app.idx }), h('span', { class: 'grow', style: { textAlign: 'left' } }, d.it?.name ?? d.id), h('span', { class: 'dim' }, `× ${d.n}`)))));
      };
      const clean = (d) => {
        let step = 0, prog = 0, holding = false, last = 0, raf = 0;
        const pic = itemIcon(d.real ?? d.it, 64, { idx: app.idx }); pic.style.filter = 'sepia(1) brightness(.55) contrast(.9)'; pic.className = 'restorer-pic';
        const bar = h('div', { class: 'restorer-bar' }, h('i'));
        const btns = STEPS.map(([e, label], i) => h('button', { class: 'btn restorer-btn', type: 'button', disabled: i !== 0 }, `${e} ${label}`));
        const look = () => { const k = (step + prog) / 3; pic.style.filter = `sepia(${(1 - k).toFixed(2)}) brightness(${(0.55 + k * 0.45).toFixed(2)}) contrast(${(0.9 + k * 0.1).toFixed(2)}) saturate(${(0.4 + k * 0.6).toFixed(2)})`; bar.firstChild.style.width = `${Math.round(prog * 100)}%`; bar.firstChild.style.background = STEPS[Math.min(2, step)][2]; btns.forEach((b, i) => { b.disabled = i !== step; b.classList.toggle('on', i === step && holding); }); };
        const tick = (now) => {
          if (!body.isConnected) return; // (closed)
          const dt = Math.min(0.05, (now - last) / 1000); last = now;
          if (holding && step < 3) { prog = Math.min(1, prog + dt / 1.4); if (Math.random() < 0.25) sfx('blip'); if (prog >= 1) { step++; prog = 0; holding = false; sfx('move'); } }
          look();
          if (step >= 3) {
            let r; app.commit((sv) => { r = restoreItem(sv, d.id); }, 'restore', { quiet: true });
            sfx('level'); toast(r?.ok ? `Good as new: a ${d.real?.name ?? 'thing'}! It’s in the bag.` : r?.reason ?? 'Couldn’t clean it.', r?.ok ? 'ok' : 'err');
            setTimeout(pickOne, 900); return;
          }
          raf = requestAnimationFrame(tick);
        };
        btns.forEach((b, i) => {
          const on = (e) => { e.preventDefault(); if (i === step) { holding = true; last = performance.now(); } };
          const off = () => { holding = false; };
          b.addEventListener('pointerdown', on); b.addEventListener('pointerup', off); b.addEventListener('pointerleave', off); b.addEventListener('pointercancel', off);
        });
        mount(body, h('div', { class: 'restorer-stage' }, pic, h('b', null, d.it?.name ?? '')), bar, h('p', { class: 'dim micro' }, 'Hold each button until the bar fills: brush the mud off, rinse it, then polish it up.'), h('div', { class: 'row', style: { gap: '6px', justifyContent: 'center' } }, btns));
        last = performance.now(); raf = requestAnimationFrame(tick);
      };
      pickOne();
      return body;
    });
  }
  function useMachine(fid, bp) {
    if (bp === 'item-restorer') { openRestorer(); return; }
    if (bp === 'berry-blender') { openBlender(); return; }
    if (bp === 'fossil-machine') {
      const st = revivalStatus(app.idx, app.save, fid);
      if (st.idle) { reviveFossil(fid); return; }
      if (st.busy) { app.say(`The machine hums: a ${st.fossil?.name ?? 'fossil'} is coming back to life (${Math.ceil(st.left / 60000)} min left).`); return; }
      let r; app.commit((s) => { r = collectRevival(app.idx, s, fid, { trainer: s.trainer?.name ?? '' }); }, 'revive');
      if (!r?.ok) { toast(r?.reason ?? 'Not yet.', 'err'); return; }
      sfx('level'); app.say(`${r.name} woke up from a very long sleep and joined you!`); syncActors(); const a = yard.actors.get(r.creature.uid); if (a) a.appear = -1.2; renderPanel(); renderHud();
      return;
    }
    if (bp === 'incubator') {
      const eggs = here().filter((x) => x.egg);
      app.say(eggs.length ? `Warm and cosy: ${eggs.map((e) => `${displayName(app.idx, e)} ${Math.round(eggProgress(e) * 100)}%`).join(', ')}.` : 'The incubator is warm, but there are no eggs in this yard.');
    }
  }
  async function giveBlock(c) {
    const id = await chooseBlock(app, c); if (!id) return;
    let r; app.commit((s) => { r = feedPokeblock(app.idx, s, c.uid, id); }, 'pokeblock', { quiet: true });
    if (!r?.ok) { toast(r?.reason ?? 'They didn’t want it.', 'err'); return; }
    sfx('munch'); yard.react(c.uid, r.taste === 'disdain' ? 'sad' : r.taste === 'happily' ? 'hearts' : 'munch', 3);
    const g = Object.entries(r.gains).map(([k, v]) => `${CONDITION_NAMES[k]} +${v}`).join(', ');
    app.say(`${displayName(app.idx, c)} ate it ${r.taste === 'happily' ? 'happily' : r.taste === 'disdain' ? 'with disdain' : 'up'}.${g ? ` ${g}.` : ' Their conditions are already as high as they go.'} Sheen ${'★'.repeat(r.stars)}`);
    renderPanel();
  }
  async function reviveFossil(fid) {
    const have = FOSSILS.filter((f) => (app.save.inventory[f.id] ?? 0) > 0);
    const pick = await chooseDialog('Put a fossil in the machine', have.map((f) => ({ value: f.id, label: f.name, detail: `${fossilSpecies(app.idx, f)?.name ?? '???'} · ${app.save.inventory[f.id]} in the bag · ${REVIVE_HOURS} hours` })),
      { empty: 'No fossils in the bag. They turn up, very rarely, when your creatures go scavenging.' });
    if (!pick) return;
    let r; app.commit((s) => { r = startRevival(app.idx, s, cur, fid, pick); }, 'revive');
    if (!r?.ok) { toast(r?.reason ?? 'The machine wouldn’t start.', 'err'); return; }
    sfx('access'); app.say(`The machine hums… the fossil will wake in about ${REVIVE_HOURS} hours.`); renderPanel();
  }

  async function giveHeld(c, preset = null) {
    if (preset) return holdIt(c, preset);
    const held = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && holdable(itemInfo(app.idx, id))).map(([id, n]) => ({ item: itemInfo(app.idx, id), n }));
    const pick = await chooseDialog(`Something for ${displayName(app.idx, c)} to hold`, [
      ...(c.heldItemId ? [{ value: '__none', label: 'Take it back', detail: itemInfo(app.idx, c.heldItemId)?.name ?? '' }] : []),
      ...held.map(({ item, n }) => ({ value: item.id, label: item.name, detail: `${item.desc ?? ''} · ${n} in the bag${item.showdownName ? '' : ' · only for show until it has a battle name (Data Lab)'}` })),
    ], { empty: 'Nothing to hold in the bag. The Market sells gear; berries and incense can be held too.' });
    if (!pick) return;
    holdIt(c, pick);
  }
  function holdIt(c, pick) {
    app.commit((s) => {
      const x = s.creatures[c.uid];
      if (x.heldItemId) s.inventory[x.heldItemId] = (s.inventory[x.heldItemId] ?? 0) + 1;
      if (pick === '__none') { x.heldItemId = null; x.heldItem = ''; return; }
      const it = itemInfo(app.idx, pick);
      s.inventory[pick] = Math.max(0, (s.inventory[pick] ?? 0) - 1);
      x.heldItemId = pick; x.heldItem = it.showdownName || '';
    }, 'held');
    sfx('access');
    if (pick !== '__none') app.say(`${displayName(app.idx, c)} is holding the ${itemInfo(app.idx, pick)?.name ?? 'item'}.`);
    bagPick = null; if (menu) renderMenu();
    renderPanel();
  }

  function renderPanel() {
    panel.classList.toggle('open', panelOpen);
    el.classList.toggle('panel-open', panelOpen);
    if (area === 'farm') { mount(panel, farmPanel()); return; }
    if (building) { mount(panel, buildPanel()); return; }
    if (selected && String(selected).startsWith('guest:') && guests) {
      const g = guests.snap.creatures.find((x) => `guest:${x.uid}` === selected);
      if (g) {
        mount(panel,
          h('div', { class: 'holo-head' }, g.name),
          h('p', { class: 'holo-dim' }, `${g.species} · Lv. ${g.level} · visiting from ${guests.snap.trainer.name}’s ranch${guests.snap.trainer.code ? ` (ID ${guests.snap.trainer.code})` : ''}.`),
          h('p', { class: 'holo-dim' }, 'Guests can’t be looked after here, but they play with your creatures, and they can become friends.'),
          h('button', { class: 'btn small', onclick: () => { selected = null; yard.selected = null; renderPanel(); } }, 'Close'));
        return;
      }
    }
    const c = selected && app.save.creatures[selected];
    const inHere = c && here().some((x) => x.uid === c.uid);
    if (!inHere) {
      const folk = here();
      mount(panel,
        h('div', { class: 'holo-head' }, 'Yard log'),
        h('p', { class: 'holo-dim' }, `${RANCH_NAME}. Whoever is in this box lives in this yard. Click someone to look after them.`),
        folk.length ? h('div', { class: 'holo-list' }, folk.map((x) => h('button', { class: 'holo-row', onclick: () => { selected = x.uid; yard.selected = x.uid; sfx('move'); renderPanel(); } },
          spriteCanvas(app.bank, x, { scale: 1 }), h('span', { class: 'grow' }, displayName(app.idx, x)), h('span', { class: 'holo-dim' }, mood(x).label))))
          : h('p', { class: 'holo-dim' }, 'Nobody lives here yet. Bring someone, or move creatures into this box from the storage system.'),
        outOnDesktop().length ? [h('div', { class: 'holo-head small' }, 'Out on the desktop'),
          h('div', { class: 'holo-list' }, outOnDesktop().map((x) => h('div', { class: 'holo-row' }, spriteCanvas(app.bank, x, { scale: 1 }), h('span', { class: 'grow' }, displayName(app.idx, x)),
            h('button', { class: 'btn small', onclick: () => { app.commit((s) => { toggleBuddy(s, x.uid, false); }); syncActors(); const a = yard.actors.get(x.uid); if (a) a.appear = -1.1; sfx('warp'); app.say(`${displayName(app.idx, x)} came back to the yard.`); renderPanel(); renderHud(); } }, 'Call back'))))] : null,
        machinesPanel(),
        h('p', { class: 'holo-dim' }, 'Food, toys and items: the Bag at the bottom left. Right-click someone for everything you can do with them.'));
      return;
    }
    const j = journalOf(app.idx, app.save, c);
    const heldName = c.heldItemId ? itemInfo(app.idx, c.heldItemId)?.name : null;
    const group = (title, ...kids) => h('div', { class: 'ranch-group' }, h('div', { class: 'ranch-group-head' }, title), ...kids);
    const actions = h('div', { class: 'col' },
      group('Look after',
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn primary', title: 'Just the two of you: wash, brush, feed by hand, play fetch', onclick: () => careRoom(c.uid) }, 'Quality time'),
          h('button', { class: 'btn', onclick: () => care(c.uid, 'pet') }, 'Pet'),
          h('button', { class: 'btn', onclick: () => { creatureCry(speciesOf(app.idx, c), c, { talk: true }); care(c.uid, 'talk'); yard.emote(c.uid); } }, 'Call'),
          isAsleep(c) ? h('button', { class: 'btn', title: wakeRisk(c) ? `They keep the energy they got so far. ${WAKE_HINT}` : 'They keep the energy they got so far.', onclick: () => care(c.uid, 'wake') }, 'Wake up')
            : h('button', { class: 'btn', title: 'A proper nap: energy comes back bit by bit until they wake up. Tired creatures also nap by themselves.', onclick: () => care(c.uid, 'rest') }, 'Nap'))),
      group('Looks',
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn small', onclick: async () => { yard.stop(); await openDressUp(app, c.uid); yard.start(); syncActors(); renderPanel(); } }, 'Dress up'),
          heldName ? h('span', { class: 'chip' }, `Holding: ${heldName}`) : null),
        (() => { const ch = changeItems(app, c, (label, fn) => h('button', { class: 'btn small', onclick: fn }, label), () => { syncActors(); yard.react(c.uid, 'sparkle', 4); renderPanel(); renderHud(); }); return ch.length ? h('div', { class: 'row wrap change-row' }, ch) : null; })()),
      // the field journal (as on the phone): what you've found out about them
      group('Journal',
        h('div', { class: 'row' }, h('p', { class: 'micro dim grow', style: { margin: 0 } }, `${j.temper} · ${j.style}`),
          h('button', { class: 'btn small primary', title: 'Their whole journal, like on the phone', onclick: () => openJournal({ idx: app.idx, bank: app.bank, save: app.save }, c) }, '📖 Open journal')),
        h('dl', { class: 'cj-favs ranch-journal' }, j.favourites.map((f) => [h('dt', null, f.label), h('dd', { class: f.value === '???' ? 'dim' : '' }, f.value)])),
        Object.keys(j.likes).length ? Object.entries(j.likes).slice(0, 4).map(([head, l]) => h('p', { class: 'cj-line' }, h('b', null, `${head}: `), l.slice(0, 5).join(', '))) : h('p', { class: 'cj-line dim' }, 'Nothing yet. Spend time together and you’ll find out.'),
        j.dislikes.length ? h('p', { class: 'cj-line' }, h('b', null, 'Can’t stand: '), j.dislikes.slice(0, 5).join(', ')) : null,
        j.friends.length ? h('p', { class: 'cj-line' }, h('b', null, 'Friends: '), j.friends.join(', ')) : null,
        j.notes.slice(0, 3).map((n) => h('p', { class: 'cj-line' }, `• ${n}`))),
      h('div', { class: 'row' },
        h('span', { class: 'micro dim grow' }, 'Right-click them in the yard to give an item, take them along, or send them off.'),
        h('button', { class: 'btn small', onclick: () => { selected = null; yard.selected = null; panelOpen = false; renderPanel(); renderHud(); } }, 'Close')));
    mount(panel, creatureSummary(app.idx, app.bank, c, { compact: true, save: app.save, sections: ['care', 'walk'], actions }));
  }

  const onKey = (e) => {
    if (e.target.closest?.('input, select, textarea')) return;
    if ((e.key === 't' || e.key === 'T') && !e.ctrlKey && !e.metaKey) { e.preventDefault(); talk.open(); return; }
    if (e.key === 'q' || e.key === 'Q') yard.turn(-1);
    else if (e.key === 'e' || e.key === 'E') yard.turn(1);
    else if (e.key === 'r' || e.key === 'R') { yard.turn(0); yard.zoom(0); }
    else if (e.key === '+' || e.key === '=') yard.zoom(-1);
    else if (e.key === '-' || e.key === '_') yard.zoom(1);
    else if (e.key === 'ArrowLeft') yard.turn(-1);
    else if (e.key === 'ArrowRight') yard.turn(1);
    else if (e.key === '1') goArea('yard');
    else if (e.key === '2') goArea('farm');
    else if (e.key === 'PageUp') stepHabitat(-1);
    else if (e.key === 'PageDown') stepHabitat(1);
    else if (e.key === 'Escape' && cinemaOn) cinematic(false);
    else if (e.key === 'Escape') { if (menu) closeMenu(); else { selected = null; yard.selected = null; panelOpen = false; renderPanel(); renderHud(); } }
    else return;
    e.preventDefault();
  };
  const onDocDown = (e) => { if (menu && !menuEl.contains(e.target) && !hudBottom.contains(e.target) && e.target !== canvas) closeMenu(); };

  function update() { yard.ownedToys = ownedToys(app.save).map((t) => t.id); syncActors(); syncPlots(); renderHud(); renderPanel(); renderMood(); if (menu) renderMenu(); }
  yard.ownedToys = ownedToys(app.save).map((t) => t.id);

  yard.setTime(app.save.settings?.ranchTime ?? 'local');
  yard.autoReflect = true; // polished floors always, hard ground when it rains, ice anywhere (see reflectFor)
  yard.setWeather(yardWeatherSetting(app.save));
  if (app.ranchArea) { const a = app.ranchArea; app.ranchArea = null; setTimeout(() => goArea(a), 0); }
  // how they feel about the weather: rain lovers perk up, fire types and water-haters grumble, thunder startles
  function weatherReact() {
    const w = yard.weather; if (!w || w === 'clear') return;
    const key = { cloudy: 'weather:clouds', rain: 'weather:rain', storm: 'weather:storm', snow: 'weather:snow', fog: 'weather:fog', windy: 'weather:wind' }[w];
    for (const c of here()) {
      const a = yard.actors.get(c.uid); if (!a || a.egg) continue;
      const v = c.prefs?.[key] ?? 0;
      if (v >= 2) { yard.emote(c.uid, 'love', false); a.hop = 1; }
      else if (v <= -2 || ((w === 'rain' || w === 'storm') && a.fire)) yard.emote(c.uid, 'frown', false);
    }
  }
  yard.onThunder = () => { for (const a of yard.actors.values()) if (!a.egg && Math.random() < 0.5) { a.hop = 1; yard.emote(a.uid, 'wow', false); } sfx('miss'); };
  yard.buildMode = building;
  if (building) panelOpen = true;
  // visitors from a friend's yard (Friends → Visit their yard): they come through a Link gate
  if (app.pendingGuests) {
    const snap = app.pendingGuests; app.pendingGuests = null;
    const gateAt = [...app.save.boxes.keys()].find((k) => (app.save.boxes[k].build?.features ?? []).some((f) => f.bp === 'link-gate'));
    if (gateAt == null) setTimeout(() => toast('Build a Link gate in one of your yards first (blueprint from the Market), then visit again.', 'err'), 300);
    else { if (cur !== gateAt) switchTo(gateAt); guests = { snap, key: gateAt }; setTimeout(() => { syncActors(); app.say(`${snap.trainer.name}’s creatures came through the Link gate!`); renderHud(); }, 1200); }
  }
  update();
  let plotTimer = null;
  // a task the game saw being done: ticked off, waiting in the notebook to be collected
  function tasksDone(list) { if (!list?.length) return; setTimeout(() => { for (const tk of list) toast(`✓ Done: ${tk.text} Open the task list to collect.`, 'ok'); sfx('level'); renderHud(); }, 300); }
  // ---------- the task list: what they've asked for, on a page from a notebook ----------
  function openTasks() {
    const left = (ms) => { const d = Math.max(0, ms) / 86400000; return d >= 1 ? `${Math.round(d)} day${Math.round(d) === 1 ? '' : 's'} left` : `${Math.max(1, Math.round(d * 24))} h left`; };
    dialog('Task list', (close) => {
      const body = h('div', { class: 'notebook' });
      const paint = () => {
        const list = (app.save.tasks ?? []).filter((x) => app.save.creatures[x.uid]).sort((a, b) => (b.ready ? 1 : 0) - (a.ready ? 1 : 0) || a.due - b.due);
        mount(body,
          h('div', { class: 'nb-head' }, 'Wishes & requests'),
          list.length ? h('ul', { class: 'nb-list' }, list.map((tk) => h('li', { class: `nb-item${tk.ready ? ' ready' : ''}` },
            h('span', { class: 'nb-pic' }, spriteCanvas(app.bank, app.save.creatures[tk.uid], { scale: 1 })),
            h('span', { class: 'nb-text' }, h('span', null, `${tk.icon ?? '•'} ${tk.text}`), h('span', { class: 'nb-due' }, tk.ready ? '✓ done: ready to collect' : trackable(tk) ? `${left(tk.due - Date.now())} · ticks itself off when it happens` : left(tk.due - Date.now()))),
            h('span', { class: 'nb-acts' },
              h('button', { class: `btn small ${tk.ready ? 'primary' : trackable(tk) ? 'ghost' : 'primary'}`, disabled: trackable(tk) && !tk.ready, title: tk.ready ? 'Collect your reward' : trackable(tk) ? 'This one ticks itself off once it really happens' : 'It happened: tick it off', onclick: () => {
                let r; app.commit((s) => { r = completeTask(app.idx, s, tk.id); }, 'tasks');
                if (r?.ok) { sfx('level'); toast(`${r.note} You got ${r.items.map(([id, n]) => `${n}× ${itemInfo(app.idx, id)?.name ?? id}`).join(', ') || 'a thank-you'}.`, 'ok'); }
                paint(); renderHud();
              } }, tk.ready ? '🎁 Collect' : '✓ Done'),
              h('button', { class: 'btn small ghost', title: 'Not this time', onclick: () => { app.commit((s) => { denyTask(app.idx, s, tk.id); }, 'tasks'); sfx('back'); paint(); renderHud(); } }, '✕'))))) :
            h('p', { class: 'nb-empty' }, 'Nothing yet. When your creatures want something (a berry, somewhere to go, something to do) it’s written down here.'),
          h('p', { class: 'nb-foot' }, 'Tick one off once it’s really happened. Each one waits a day to a week or so.'));
      };
      paint();
      return h('div', { class: 'col' }, body, h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close() }, 'Close')));
    }, { wide: true });
  }
  // a new wish from someone you're not looking at: a little dot flies from them to the Tasks button
  function onTasks(added) {
    renderHud();
    const btn = hudTR.querySelector('.task-btn');
    for (const tk of added) {
      if ((selected === tk.uid && !tk.chat) || !btn) continue;
      const b = yard.actorBox(tk.uid);
      const r = canvas.getBoundingClientRect(), to = btn.getBoundingClientRect();
      const sx = b ? r.left + ((b.x0 + b.x1) / 2) * (r.width / (canvas.width || 1)) : r.left + r.width / 2, sy = b ? r.top + b.y0 * (r.height / (canvas.height || 1)) : r.top + r.height / 2;
      const dot = h('div', { class: 'task-dot', 'aria-hidden': 'true' });
      Object.assign(dot.style, { left: `${sx}px`, top: `${sy}px` });
      (document.fullscreenElement && el.contains(document.fullscreenElement) ? document.fullscreenElement : document.fullscreenElement === el ? el : document.body).append(dot);
      requestAnimationFrame(() => requestAnimationFrame(() => { dot.style.transform = `translate(${to.left + to.width - 8 - sx}px, ${to.top + 4 - sy}px) scale(.6)`; dot.style.opacity = '0.9'; }));
      setTimeout(() => { dot.remove(); btn.classList.remove('bump'); void btn.offsetWidth; btn.classList.add('bump'); }, 900);
    }
  }

  return {
    onTasks,
    el,
    mounted() {
      yard.resize();
      yard.materialize();
      yard.start();
      window.addEventListener('keydown', onKey);
      document.addEventListener('pointerdown', onDocDown, true);
      plotTimer = setInterval(() => {
        // weather a creature called up wears off
        const wc = app.save.weatherCall;
        if (wc && !calledWeather(app.save) && !wc.ended) { app.commit((s) => { if (s.weatherCall) s.weatherCall.ended = true; }, 'weather', { quiet: true }); yard.setWeather(yardWeatherSetting(app.save)); renderHud(); }
        syncPlots(); if (area !== 'yard') { renderPanel(); renderHud(); } if (Math.random() < 0.5) weatherReact(); }, 30000);
      setTimeout(weatherReact, 2500);
      setTimeout(() => intro.classList.add('done'), 900);
      canvas.focus({ preventScroll: true });
    },
    update,
    art: () => {},
    tick: () => { syncActors(); syncPlots(); renderPanel(); },
    dispose() { clearInterval(askTimer); inviteEl?.remove(); document.removeEventListener('fullscreenchange', onFsChange); if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {}); yard.destroy(); talk.destroy(); clearInterval(plotTimer); window.removeEventListener('keydown', onKey); document.removeEventListener('pointerdown', onDocDown, true); },
  };
}
