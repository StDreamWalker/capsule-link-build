// R.A.N.C.H. (Remote Access Nurture & Care Hub): areas you load into. Each box has its own yard
// (in the box's environment), which you can build up with blueprints from the Market; the berry farm
// is an area of its own. With a Link gate, a friend's yard (brought over as a file) joins yours.
// In a yard: pet by rubbing, pick creatures up and carry or fling them, throw toys and berries
// (from the bag), and watch them play. Mouse wheel or − / + zoom, drag the ground to look around.
import { itemIcon } from '../../../../shared/ui/itemIcon.js';
import { openJournal } from '../../../../shared/ui/journal.js';
import { hostBerryBlender, chooseBlock } from '../../../../shared/ui/berryBlender.js';
import { changeItems } from '../../../../shared/ui/changeUi.js';
import { talkOverlay } from '../../../../shared/ui/talkOverlay.js';
import { friendsSession } from '../friendsSession.js';
import { h, mount, toast, chooseDialog, confirmDialog, dialog } from '../../../../shared/ui/dom.js';
import { sizeVariant } from '../../../../shared/ui/creatureSize.js';
import { Yard, toyKindOf, EXTRA_TOYS, WEATHER_LABEL } from '../../../../shared/ui/yard.js';
import { spriteCanvas, spriteIdOf } from '../../../../shared/ui/art.js';
import { BIOME_IDS, BIOME_INFO } from '../../../../shared/ui/biomes.js';
import { creatureSummary, formPicker } from '../../../../shared/ui/summary.js';
import { playTransfer, transferLine } from '../../../../shared/ui/transfer.js';
import { sfx, creatureCry } from '../../../../shared/ui/audio.js';
import * as Paint from '../../../../shared/ui/paint.js';
import {
  atKind, displayName, applyCare, mood, tickNeeds, moveCreature, firstFreeBoxSlot, speciesOf, list, boxContents, party,
  farmState, plotStatus, plant, harvest, plantable, growInfo, FARM_PLOTS, farmPlots, expandFarm, farmTools, mulchInBag, MAX_FARM_SIZE, releaseCreature, favorites, CARE_TOYS, friendsOf,
  wallet, itemInfo, setForm, toggleBuddy, isDesktopBuddy, movementOf, traitsOf, playedTogether, timeOfDay, napWait, holdable, allFoods,
  yardBuild, placeFeature, moveFeature, removeFeature, expandYard, appeal, featureLife, thriveReport, blueprintOf, bpId, BLUEPRINTS,
  YARD_SIZES, MAX_YARD_SIZE, featureRoom, ranchSnapshot, readSnapshot, experience, addMemory, topPrefs, dislikes, isAsleep, sleepLeft, moodNote, foodBlurb,
  journalOf, itemUses, itemDesc, isIncense, lightIncense, activeIncense, yardWeather, misfitHabitat, healingOf, useMedicine, currentFormId,
  feedPokeblock, CONDITION_NAMES, machinesIn, revivalStatus, startRevival, collectRevival, FOSSILS, fossilSpecies, REVIVE_HOURS, eggProgress,
  meetGuest, talkTo, yardWeatherSetting, calledWeather, chatTargets, wakeRisk, WAKE_HINT, cravingOf, foodStats,
  completeTask, denyTask, noteDone, trackable, volunteers,
} from '../../../../shared/engine/index.js';
import { openMoveTo } from './moveTo.js';
import { activitiesView } from './activities.js';
import { RANCH_NAME } from './home.js';
import { actorFor } from '../../../../shared/ui/actor.js';
import { openCareRoom } from './careRoom.js';
import { openDressUp, clothesImg } from './dressUp.js';

const fmtLeft = (ms) => { const m = Math.ceil(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`; };
const AREAS = [['yard', 'Yard'], ['farm', 'Berry farm']];

/** What a creature looks like to the yard (shared with the care room). */
export function actorOf(app, c) { return actorFor(app.idx, c, { clothesImg }); }

export function ranchView(app) {
  const typeTint = (c) => app.idx.types.get(app.idx.species.get(c.speciesId)?.types?.[0])?.color ?? '#9fe8ff';
  const habitats = () => {
    const out = app.save.boxes.map((b, i) => ({ key: i, name: b.name, biome: b.biome ?? 'meadow' }));
    if (atKind(app.save, 'ranch').length) out.push({ key: 'ranch', name: app.save.ranch?.name ?? 'Free range', biome: app.save.ranch?.biome ?? 'meadow' });
    return out;
  };
  let cur = app.ranchHabitat ?? 0;
  if (!habitats().some((x) => x.key === cur)) cur = 0;
  let selected = null;
  let area = 'yard';
  let panelOpen = false;
  let logPinned = false; // the yard log only stays open when you asked for it (the Log button)
  let lastPet = 0;
  let menu = null; // 'bag' | null
  let bagTab = 'food'; // 'food' | 'toys' | 'items'
  let bagPick = null; // an item id picked in the bag's Items tab
  let cinemaOn = false;
  const playLog = new Map();
  const visitLog = new Map();
  // build mode: placing a blueprint, or moving something already built
  let building = !!app.ranchBuild; app.ranchBuild = false;
  let placing = null;      // a blueprint id from the bag
  let picked = null;       // a feature id (to move or put away)
  let guests = null;       // a friend's yard brought over through the Link gate: { snap, key }

  const canvas = h('canvas', { class: 'hab-canvas', tabindex: '0', 'aria-label': 'The yard. Rub a creature to pet it, drag it to carry it, let go to drop it. Drag the ground to look around, scroll to zoom.' });
  const hudTL = h('div', { class: 'hud hud-tl' });
  const hudTR = h('div', { class: 'hud hud-tr' });
  const hudBottom = h('div', { class: 'hud hud-bottom' });
  const menuEl = h('div', { class: 'hud-menu', hidden: true });
  const panel = h('aside', { class: 'holo-panel' });
  const intro = h('div', { class: 'hab-intro', 'aria-hidden': 'true' }, h('div', { class: 'rings' }, h('i'), h('i'), h('i')), h('div', { class: 'intro-text' }, 'R.A.N.C.H.', h('small', null, 'opening the gate…')));
  const el = h('div', { class: 'ranchvr' }, canvas, hudTL, hudTR, hudBottom, menuEl, panel, intro, h('div', { class: 'hud-frame', 'aria-hidden': 'true' }));
  const moodEl = h('div', { class: 'ranch-mood', hidden: true });
  let moodKey = '', moodSel = null, moodAt = 0, moodTimer = null;
  el.append(moodEl);

  const seedOf = (key) => (typeof key === 'number' ? key : 99) + 1;
  const yard = new Yard(canvas, {
    bank: app.bank,
    accent: app.save.trainer?.card?.accent,
    resolveTexture: (p) => app.textures[p.toLowerCase()] ?? null,
    biome: habitats().find((x) => x.key === cur)?.biome,
    seed: seedOf(cur),
    sizeScale: app.save.settings?.ranchScale ?? 1,
    // clicking someone opens their page; clicking away closes it (back to the log only if you'd opened it)
    onContext: (uid, ev) => creatureMenu(uid, ev),
    onSelect: (uid) => { selected = uid; if (uid) { panelOpen = true; sfx('move'); } else if (!building && area === 'yard') panelOpen = logPinned; if (menu) renderMenu(); renderPanel(); renderHud(); renderMood(); },
    onPet: (uid) => { const now = Date.now(); if (now - lastPet < 300) return; lastPet = now; care(uid, 'pet', null, true, true, 0.3); },
    onDrop: (uid, speed) => {
      if (speed > 4) { yard.react(uid, 'dizzy', 2); sfx('miss'); care(uid, 'play', null, true, false); }
      else { yard.react(uid, 'sparkle', 2); sfx('blip'); }
    },
    onPlot: (i) => plotClick(i),
    onPlace: (at) => placeAt(at),
    onFeatureOpen: (fid, bp) => useMachine(fid, bp),
    onPlaceBlocked: (why) => { sfx('miss'); toast(why ? `Can’t put it there: ${why.toLowerCase()}.` : 'Can’t put it there.', 'err'); },
    onFeature: (fid) => { picked = picked === fid ? null : fid; placing = null; yard.pickedFeature = picked; sfx('move'); renderPanel(); renderHud(); },
    onFeatureVisit: (uid, bp) => {
      const now = Date.now();
      if (!app.save.creatures[uid] || now - (visitLog.get(uid) ?? 0) < 60000) return;
      visitLog.set(uid, now);
      app.commit((s) => { const c = s.creatures[uid]; if (c) experience(c, [`feature:${bp}`], 3 + appeal(app.idx, c, bp) * 4, { t: now, coreChance: 0 }); }, 'visit', { quiet: true });
    },
    onBounce: (t, hit) => { if (hit > 5) sfx('blip'); },
    tod: timeOfDay(),
    onPlayTogether: (a, b) => {
      const key = [a, b].sort().join(':'), now = Date.now();
      if (now - (playLog.get(key) ?? 0) < 20000) return;
      playLog.set(key, now);
      // one of them is visiting from a friend's yard: a memory for ours
      const guest = [a, b].find((u) => String(u).startsWith('guest:'));
      if (guest) {
        const mine = a === guest ? b : a, g = guests?.snap.creatures.find((x) => `guest:${x.uid}` === guest);
        if (g && app.save.creatures[mine]) {
          let met;
          app.commit((s) => {
            const c = s.creatures[mine];
            met = meetGuest(c, g, guests.snap.trainer, 3, now);
            c.metGuests = c.metGuests || {};
            if (!c.metGuests[g.uid]) { c.metGuests[g.uid] = now; addMemory(c, `Played with ${g.name} from ${guests.snap.trainer.name}’s ranch.`, now, { core: Object.keys(c.metGuests).length <= 3 }); }
            else if (met.entry.visits > 1 && met.entry.greeted !== met.entry.visits) { met.entry.greeted = met.entry.visits; met.again = true; }
            if (met.friends && !met.entry.friendAt) { met.entry.friendAt = now; addMemory(c, `Became friends with ${g.name} from ${guests.snap.trainer.name}’s ranch.`, now, { core: true }); met.newFriend = true; }
          }, 'guest', { quiet: true });
          const nm = displayName(app.idx, app.save.creatures[mine]);
          if (met?.newFriend) app.say(`${nm} and ${g.name} became friends!`);
          else if (met?.again) app.say(`${nm} remembers ${g.name} and is happy to see them again!`);
        }
        return;
      }
      let r; app.commit((s) => { r = playedTogether(app.idx, s, a, b, now); }, 'bond', { quiet: true });
      if (r?.friends) app.say(`${displayName(app.idx, app.save.creatures[a])} and ${displayName(app.idx, app.save.creatures[b])} became friends playing together!`);
    },
    onEat: (uid, item) => {
      const c = app.save.creatures[uid];
      if (!c || !item?.id) return;
      const fav = favorites(app.idx, c);
      let out;
      app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], 'feed', { item: item.id, favorite: item.id === fav.berry, inventory: save.inventory, direct: false }); if (out?.ok !== false && out?.reaction !== 'full') tasksDone(noteDone(save, uid, 'feed', item.id)); }, 'care', { quiet: true });
      if (out?.ok) { yard.react(uid, out.reaction === 'delighted' ? 'hearts' : out.reaction === 'full' ? 'sad' : 'munch', 4); sfx('munch'); app.say(`${displayName(app.idx, c)} ${out.reaction === 'full' ? 'sniffed the' : 'ate the'} ${item.name}${out.reaction === 'delighted' ? ' — a favourite!' : out.reaction === 'full' ? ', but is full.' : '.'}`); }
      else if (out?.reason) toast(out.reason, 'err');
      renderPanel(); if (menu) renderMenu();
    },
    onPlay: (uid, kind, item) => {
      const c = app.save.creatures[uid];
      if (!c) return;
      const id = item?.id ?? kind;
      const fav = favorites(app.idx, c);
      let out;
      app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], 'play', { toy: id, toyName: item?.name, favorite: id === fav.toy, inventory: save.inventory, direct: false }); if (out?.ok !== false) tasksDone(noteDone(save, uid, 'play')); }, 'care', { quiet: true });
      if (out?.ok && out.reaction === 'delighted') { yard.react(uid, 'hearts', 3); app.say(`${displayName(app.idx, c)} loves the ${item?.name ?? kind}!`); }
      else if (out?.reaction === 'tired') yard.emote(uid, 'tired', false);
      if (selected === uid) renderPanel();
    },
  });

  // creatures out on the desktop aren't in the yard while they're out there
  const residents = () => (cur === 'ranch' ? atKind(app.save, 'ranch') : boxContents(app.save, cur).filter(Boolean));
  // one place at a time: out on the desktop, or busy with an activity, means not in the yard
  const here = () => residents().filter((c) => !isDesktopBuddy(app.save, c.uid) && !app.busy?.has(c.uid));
  const outOnDesktop = () => residents().filter((c) => isDesktopBuddy(app.save, c.uid));
  const habitat = () => habitats().find((x) => x.key === cur) ?? habitats()[0];

  const buildOf = () => yardBuild(app.save, cur);
  function syncActors() {
    yard.tod = yard.light ?? timeOfDay();
    const folk = area === 'yard' ? here() : [];
    // the yard's size and what's built there (features come alive with the right residents)
    if (area === 'yard') {
      const b = buildOf();
      yard.setYardSize(b.size ?? 0);
      yard.setFeatures(b.features.map((f) => ({ ...f, life: featureLife(app.idx, f.bp, folk) })));
    }
    const feats = area === 'yard' ? buildOf().features : [];
    const biomeHere = habitat().biome;
    const actors = folk.map((c) => ({ ...actorOf(app, c), misfit: misfitHabitat(app.idx, app.idx.species.get(currentFormId(app.idx, c)) ?? speciesOf(app.idx, c), biomeHere), featLikes: Object.fromEntries(feats.map((f) => [f.id, appeal(app.idx, c, f.bp)])) }));
    // visitors through the Link gate
    if (area === 'yard' && guests?.key === cur) for (const g of guests.snap.creatures) actors.push({ uid: `guest:${g.uid}`, speciesId: app.idx.species.has(g.formId ?? '') ? g.formId : g.speciesId, name: `${g.name} (${guests.snap.trainer.name})`, mood: 'happy', speed: 1.3, sizeMul: 1, types: g.types ?? [], friends: [], clothes: [], guest: true, temper: 'playful' });
    yard.setCreatures(actors);
  }
  function syncPlots() { yard.setFarmSize?.(farmState(app.save).size ?? 0); yard.setPlots(farmState(app.save).plots.map((p) => plotStatus(app.idx, p))); }

  function goArea(a) {
    if (a === area) return;
    area = a;
    selected = null; yard.selected = null;
    closeMenu();
    yard.farmSize = farmState(app.save).size ?? 0;
    yard.setScene(a, habitat().biome, seedOf(cur));
    yard.setWeather(yardWeatherSetting(app.save));
    syncActors(); syncPlots();
    yard.materialize();
    panelOpen = a !== 'yard';
    sfx('warp');
    renderHud(); renderPanel();
  }
  function switchTo(key) {
    if (key === cur && area === 'yard') return;
    cur = key;
    app.ranchHabitat = key;
    selected = null; yard.selected = null;
    yard.actors.clear();
    area = 'yard';
    placing = null; picked = null; yard.pickedFeature = null;
    const b = buildOf();
    yard.yardSize = b.size ?? 0;
    yard.features = []; yard.featKey = null;
    yard.setScene('yard', habitat().biome, seedOf(key));
    yard.setWeather(yardWeatherSetting(app.save));
    syncActors();
    yard.materialize();
    sfx('warp');
    renderHud(); renderPanel();
  }
  const stepHabitat = (d) => { const l = habitats(); const i = l.findIndex((x) => x.key === cur); switchTo(l[(i + d + l.length) % l.length].key); };

  function care(uid, action, item, quiet = false, react = true, weight = 1) {
    let out;
    app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], action, { item, inventory: save.inventory, weight }); if (out?.ok !== false && !out?.asleep) tasksDone(noteDone(save, uid, action, item?.id ?? item ?? null)); }, 'care', { quiet: true });
    if (!out?.ok) { if (out?.reason && !quiet) toast(`${displayName(app.idx, app.save.creatures[uid])}: ${out.reason}`, 'err'); renderMood(uid); return; }
    const nm0 = displayName(app.idx, app.save.creatures[uid]);
    if (out.reaction === 'annoyed') { yard.react(uid, 'sad', 4); yard.emote(uid, 'angry', false); sfx('miss'); app.say(`${nm0} has had enough and is upset with you. Give them some space.`); renderPanel(); return; }
    if (out.reaction === 'grumpy') { syncActors(); yard.emote(uid, 'angry', false); sfx('back'); app.say(`${nm0} woke up, a bit grumpy.`); renderPanel(); renderMood(); return; }
    if (out.reaction === 'sleep' && action === 'rest') { syncActors(); const a = yard.actors.get(uid); if (a) { a.state = 'sleep'; a.timer = 4; } }
    if (out.woke && out.reaction === 'awake') { syncActors(); yard.emote(uid, 'smile', false); sfx('back'); app.say(`${nm0} woke up and stretched. Energy ${Math.round(out.needs?.energy ?? 0)}.`); renderPanel(); renderMood(); return; }
    if (out.reaction === 'awake') { yard.emote(uid, 'meh', false); if (!quiet) app.say(`${nm0}: ${out.reason}`); renderPanel(); return; }
    const reaction = { hearts: 'hearts', munch: 'munch', delighted: 'hearts', play: 'hearts', sparkle: 'sparkle', listen: 'note', sleep: 'sleep', full: 'sad', tired: 'sleep', meh: 'note' }[out.reaction] ?? 'hearts';
    if (out.reaction === 'meh' && !quiet) app.say(`${nm0} is getting a bit tired of that.`);
    if (react) yard.react(uid, reaction, reaction === 'hearts' ? 3 : 4);
    if (action === 'pet') sfx('heart');
    if (action === 'feed') sfx(out.reaction === 'full' ? 'back' : 'munch');
    if (action === 'groom') sfx('heal');
    const nm = displayName(app.idx, app.save.creatures[uid]);
    if (out.reaction === 'full') app.say(`${nm} is full.`);
    if (out.reaction === 'tired') app.say(`${nm} is too tired to play.`);
    if (!quiet || out.friendship) renderPanel();
    renderMood();
  }
  // how someone's doing and what would help, big and plain (bottom left): the one you picked, or anyone upset
  function renderMood(force) {
    const pick = (force && app.save.creatures[force]) || (selected && app.save.creatures[selected]) || here().find((c) => ['upset', 'asleep'].includes(mood(c).id));
    const note = pick && moodNote(app.idx, pick, displayName(app.idx, pick));
    // it shows when something changes, then fades after a few seconds (click them again to see it)
    const key = note ? `${pick.uid}:${note.mood}` : '';
    if (key !== moodKey || force || (selected && selected !== moodSel)) { moodKey = key; moodSel = selected; moodAt = Date.now(); moodEl.classList.remove('faded'); clearTimeout(moodTimer); moodTimer = setTimeout(() => moodEl.classList.add('faded'), 6000); }
    moodEl.hidden = !note || cinemaOn || building || !!menu;
    if (!note) return;
    mount(moodEl, h('div', { class: `ranch-mood-title m-${note.mood}` }, note.title), h('div', { class: 'ranch-mood-why' }, note.why), h('div', { class: 'ranch-mood-help' }, note.help));
  }

  /** The creature you have selected (berries and toys you throw go to them first), or null. */
  const forSelected = () => (selected && app.save.creatures[selected] && !app.save.creatures[selected].egg && !isAsleep(app.save.creatures[selected]) ? selected : null);
  // ---------- talking (T): everyone in the yard, or just the ones you name ----------
  function askOne(uid, text, group) {
    let out = null;
    app.commit((s) => { const c = s.creatures[uid]; if (c) out = talkTo(app.idx, s, c, text, Date.now(), { group }); if (out?.act?.kind === 'pair') tasksDone(noteDone(s, uid, 'pair')); }, 'chat', { quiet: true });
    if (out?.task) setTimeout(() => { onTasks([{ ...out.task, chat: true }]); }, 900); // (what they asked for went on the task list)
    if (out?.act?.kind === 'weather' && out.done?.ok) { yard.setWeather(out.act.weather); weatherReact(); renderHud(); }
    if (out?.act && ['nap', 'wake', 'change'].includes(out.act.kind)) { syncActors(); renderPanel(); }
    return out;
  }
  const talk = talkOverlay({
    app, host: document.body, yard,
    listeners: () => (area === 'yard' ? here().filter((c) => !c.egg).map((c) => c.uid) : []),
    // sleeping ones only hear you when you name them (or tell everyone to wake up)
    pick: (uids, text) => { const named = chatTargets(app.idx, app.save, uids, text); const all = named.length === uids.length; return all && !/wake/i.test(text) ? named.filter((u) => !isAsleep(app.save.creatures[u])) : named; },
    ask: askOne,
    invite: (uids, inv) => runInvite(uids, inv),
    onReply: () => { renderPanel(); renderMood(); },
  });

  // ---------- "who wants to …?": the ones who'd like to step forward, and a button to go and do it ----------
  let inviteEl = null, movieOn = null;
  function runInvite(uids, inv) {
    const res = volunteers(app.idx, app.save, uids, inv);
    const yes = res.yes.slice(0, inv.id === 'desktop' ? 6 : inv.id === 'movie' ? 8 : 4);
    const nm = (u) => displayName(app.idx, app.save.creatures[u]);
    // they come forward, one after another, cheering; the rest shrug
    yes.forEach((v, i) => setTimeout(() => { try { yard.command?.(v.uid, { kind: 'come' }); yard.react?.(v.uid, 'hearts', 1.5); yard.think?.(v.uid, '!', 2.5); creatureCry(speciesOf(app.idx, app.save.creatures[v.uid]), app.save.creatures[v.uid], { talk: true, mood: 'happy' }); } catch { /* fine */ } }, 250 + i * 380));
    res.no.slice(0, 4).forEach((v, i) => setTimeout(() => { try { yard.think?.(v.uid, '…', 2.2); } catch { /* fine */ } }, 400 + i * 300));
    inviteEl?.remove();
    const close = () => { inviteEl?.remove(); inviteEl = null; };
    const names = yes.map((v) => nm(v.uid));
    const list2 = names.length <= 2 ? names.join(' and ') : `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`;
    const go = (label, fn, primary = false) => h('button', { class: `btn small ${primary ? 'primary' : ''}`, onclick: () => { close(); fn(); } }, label);
    let actions = [];
    const first = yes[0]?.uid;
    if (yes.length) {
      if (inv.act) actions = yes.slice(0, 3).map((v, i) => go(`${inv.verb} with ${nm(v.uid)}`, () => { activitiesView.last = v.uid; activitiesView.autoStart = inv.act; app.go('activities'); }, i === 0));
      else if (inv.id === 'desktop') actions = [go(`Send ${yes.length === 1 ? nm(first) : `all ${yes.length}`} to the desktop`, () => { let n = 0, why = ''; app.commit((sv) => { for (const v of yes) { const r = toggleBuddy(sv, v.uid, true); if (r?.ok !== false) n++; else why = r.reason; } }); syncActors(); sfx('warp'); toast(n ? `${n === 1 ? nm(first) : `${n} of them`} hopped out onto your desktop. Call them back from Boxes or the desktop.` : why || 'Couldn’t do that.', n ? 'ok' : 'err'); }, true)];
      else if (inv.id === 'movie') actions = [go('Start movie night', () => startMovie(yes.map((v) => v.uid)), true)];
      else if (inv.id === 'battle') actions = [go('Go to Battle Link', () => app.go('battle'), true)];
      else if (inv.id === 'groom') actions = yes.slice(0, 2).map((v, i) => go(`Quality time with ${nm(v.uid)}`, () => careRoom(v.uid), i === 0));
      else if (inv.id === 'nap') actions = [go('Off to sleep, then', () => { for (const v of yes) askOne(v.uid, 'take a nap', true); syncActors(); renderPanel(); }, true)];
      else if (inv.id === 'walk') actions = yes.slice(0, 2).map((v, i) => go(`Send ${nm(v.uid)} to your phone…`, () => openMoveTo(app, app.save.creatures[v.uid]).then(() => { syncActors(); renderPanel(); }), i === 0));
      else if (inv.id === 'snack') actions = [go('Open the food bag', () => { selected = first; yard.selected = first; openMenu('bag'); }, true)];
      else if (inv.id === 'play') actions = [go('Get the toys out', () => { selected = first; yard.selected = first; openMenu('bag'); }, true)];
      else if (inv.id === 'dance') actions = [go('Dance!', () => { yes.forEach((v, i) => setTimeout(() => yard.command?.(v.uid, { kind: 'dance' }), i * 200)); sfx('level'); }, true)];
    }
    inviteEl = h('div', { class: 'invite-card', role: 'dialog', 'aria-label': `Who wants to ${inv.label}` },
      h('div', { class: 'row', style: { alignItems: 'center', gap: '8px' } }, h('b', { class: 'grow' }, `“Who wants to ${inv.label}?”`), h('button', { class: 'btn small', 'aria-label': 'Close', onclick: close }, '✕')),
      yes.length ? h('p', null, `${list2} ${yes.length === 1 ? 'wants' : 'want'} to!`) : h('p', { class: 'dim' }, 'Nobody fancies it right now.'),
      yes.length ? h('div', { class: 'col invite-who' }, yes.map((v) => h('div', { class: 'row', style: { gap: '6px', alignItems: 'center' } }, spriteCanvas(app.bank, app.save.creatures[v.uid], { scale: 1 }), h('span', null, nm(v.uid)), h('span', { class: 'dim micro' }, `· ${v.why}`)))) : null,
      res.no.length ? h('details', null, h('summary', { class: 'micro dim' }, `${res.no.length} said no`), h('div', { class: 'micro dim col' }, res.no.slice(0, 8).map((v) => h('span', null, v.why)))) : null,
      inv.id === 'movie' && yes.length ? h('p', { class: 'micro dim' }, 'There’s no film player in the game: movie night gathers them in front of a big screen in the yard to sit and watch the show together (it cheers them up and brings them closer).') : null,
      actions.length ? h('div', { class: 'row wrap', style: { gap: '6px' } }, actions) : null);
    el.append(inviteEl);
    setTimeout(() => { if (inviteEl && !inviteEl.matches(':hover')) close(); }, 45000);
    return true;
  }
  // movie night: everyone who came sits in a row before a glowing screen, the lights go down, the camera drifts
  function startMovie(uids) {
    stopMovie();
    const screen = h('div', { class: 'movie-screen' }, h('div', { class: 'movie-film' }), h('div', { class: 'movie-bar' }, h('span', null, `🎬 Movie night · ${uids.length} watching`), h('button', { class: 'btn small', onclick: () => stopMovie(true) }, 'Lights up')));
    el.append(screen);
    uids.forEach((u, i) => setTimeout(() => { try { yard.command?.(u, { kind: 'come' }); setTimeout(() => yard.command?.(u, { kind: 'sit' }), 1600); } catch { /* fine */ } }, i * 250));
    const iv = setInterval(() => { const u = uids[Math.floor(Math.random() * uids.length)]; try { yard.react?.(u, Math.random() < 0.5 ? 'note' : 'hearts', 1.4); } catch { /* fine */ } }, 2600);
    movieOn = { screen, iv, uids, at: Date.now() };
  }
  function stopMovie(reward = false) {
    if (!movieOn) return;
    clearInterval(movieOn.iv); movieOn.screen.remove();
    const mins = (Date.now() - movieOn.at) / 60000;
    if (reward && mins > 0.25) {
      app.commit((sv) => { for (const u of movieOn.uids) { const c = sv.creatures[u]; if (!c) continue; tickNeeds(app.idx, c); c.needs.joy = Math.min(100, (c.needs.joy ?? 60) + Math.min(20, 6 + mins * 4)); c.friendship = Math.min(255, (c.friendship ?? 0) + Math.min(6, 2 + Math.round(mins))); addMemory?.(c, 'Watched a movie with you and the others.'); } }, 'care', { quiet: true });
      toast('Movie night was a hit: everyone’s cheered up and a little closer.', 'ok');
    }
    movieOn = null; syncActors(); renderPanel();
  }

  // ---------- quality time: the care room ----------
  async function careRoom(uid) {
    yard.stop();
    await openCareRoom(app, uid, {
      biome: habitat()?.biome ?? 'meadow',
      seed: seedOf(cur),
      doCare: (action, opts = {}) => {
        let out;
        app.commit((save) => { out = applyCare(app.idx, save.creatures[uid], action, { ...opts, inventory: save.inventory }); if (out?.ok !== false && !out?.asleep) tasksDone(noteDone(save, uid, action, opts.item?.id ?? opts.item ?? null)); }, 'care', { quiet: true });
        if (out && !out.ok && out.reason) toast(out.reason, 'err');
        return out;
      },
      doTalk: (text) => askOne(uid, text, false),
      doMedicine: (id) => { let r; app.commit((sv) => { r = useMedicine(app.idx, sv, uid, id); }, 'heal'); return r; },
    });
    yard.start();
    syncActors(); renderPanel(); renderHud();
  }

  // ---------- toys and berries from the bag ----------
  const toyList = () => [...CARE_TOYS, ...EXTRA_TOYS, ...app.idx.ds.items.filter((i) => i.kind === 'toy' && (i.unlimited || (app.save.inventory[i.id] ?? 0) > 0))];
  // kibble first (it never runs out), then everything in the bag
  const foodList = () => allFoods(app.idx).filter((it) => it.unlimited || (app.save.inventory[it.id] ?? 0) > 0).sort((a, b) => (b.unlimited ? 1 : 0) - (a.unlimited ? 1 : 0));
  function closeMenu() { menu = null; menuEl.hidden = true; renderHud(); renderMood(); }
  function openMenu(kind) { menu = menu === kind ? null : kind; renderMenu(); renderHud(); renderMood(); }
  // everything other than food and toys: gear to hold, incense, TMs, valuables…
  const otherItems = () => Object.entries(app.save.inventory ?? {}).filter(([, n]) => n > 0).map(([id, n]) => ({ it: itemInfo(app.idx, id), n }))
    .filter(({ it }) => it && it.kind !== 'food' && it.kind !== 'toy' && it.kind !== 'blueprint');
  function renderMenu() {
    menuEl.hidden = !menu;
    if (!menu) return;
    const sel = selected && app.save.creatures[selected];
    const tabs = h('div', { class: 'hud-menu-tabs', role: 'tablist' },
      [['food', 'Food'], ['toys', 'Toys'], ['items', 'Items']].map(([k, l]) => h('button', { class: `hud-btn ${bagTab === k ? 'on' : ''}`, role: 'tab', 'aria-selected': String(bagTab === k), onclick: () => { bagTab = k; bagPick = null; renderMenu(); } }, l)),
      h('span', { class: 'grow' }),
      h('span', { class: 'hud-wallet' }, h('span', { class: 'coin' }), ` ${wallet(app.save)}`),
      h('button', { class: 'hud-btn', onclick: () => app.go('market') }, 'Market'));
    let body;
    if (bagTab === 'toys') {
      body = [
        h('div', { class: 'hud-menu-grid' }, toyList().map((it) => {
          const kind = toyKindOf(it);
          const pic = Paint.toy(kind, { w: 40, h: 40 }); pic.className = 'hud-menu-pic';
          return h('button', { class: 'hud-menu-item', title: it.desc ?? '', onclick: () => { yard.throwToy(kind, it, null, forSelected()); sfx('blip'); } }, pic, h('span', null, it.name));
        })),
        h('div', { class: 'row' }, h('button', { class: 'hud-btn', onclick: () => { yard.clearToys(); sfx('back'); } }, 'Put the toys away'), h('span', { class: 'hud-hint' }, forSelected() ? `Click to give one to ${displayName(app.idx, app.save.creatures[forSelected()])} · T to talk` : 'Click to throw one in (select someone first to give it to them) · drag a toy to fling it · T to talk.'))];
    } else if (bagTab === 'food') {
      body = [
        h('div', { class: 'hud-menu-grid' }, foodList().map((it) => h('button', { class: 'hud-menu-item', title: [it.name, foodStats(it), it.desc].filter(Boolean).join('\n'), onclick: () => { if (!it.unlimited && (app.save.inventory[it.id] ?? 0) <= yard.toys.filter((t) => t.item?.id === it.id).length) { toast(`No more ${it.name} to toss.`, 'err'); return; } yard.tossBerry(it, forSelected()); sfx('blip'); } },
          itemIcon(it, 32, { idx: app.idx }), h('span', null, it.name), h('small', null, it.unlimited ? '∞' : `× ${app.save.inventory[it.id] ?? 0}`)))),
        h('span', { class: 'hud-hint' }, forSelected() ? `Click to give it to ${displayName(app.idx, app.save.creatures[forSelected()])}: it drops right in front of them.` : 'Click to toss it in: whoever gets there first eats it (select someone first to give it to them). Kibble never runs out, but only fills them a little.')];
    } else {
      const items = otherItems();
      const pickIt = bagPick && itemInfo(app.idx, bagPick);
      const uses = pickIt ? itemUses(pickIt) : [];
      const inc = activeIncense(app.save);
      body = [
        items.length ? h('div', { class: 'hud-menu-grid' }, items.map(({ it, n }) => h('button', { class: `hud-menu-item ${bagPick === it.id ? 'on' : ''}`, title: [it.name, foodStats(it), itemDesc(it)].filter(Boolean).join('\n'), onclick: () => { bagPick = bagPick === it.id ? null : it.id; renderMenu(); } },
          itemIcon(it, 32, { idx: app.idx }), h('span', null, it.name), h('small', null, `× ${n}`))))
          : h('p', { class: 'hud-hint' }, 'No items yet. Walks turn things up, and the Market sells gear, incense and TMs.'),
        pickIt ? h('div', { class: 'hud-bag-pick' },
          h('div', { class: 'col grow' }, h('strong', null, pickIt.name), foodStats(pickIt) ? h('small', { class: 'food-stats' }, foodStats(pickIt)) : null, h('small', null, itemDesc(pickIt))),
          h('div', { class: 'row wrap' },
            uses.includes('hold') ? h('button', { class: 'hud-btn', disabled: !sel, title: sel ? '' : 'Click someone in the yard first', onclick: () => giveHeld(sel, pickIt.id) }, sel ? `Give to ${displayName(app.idx, sel)}` : 'Give to… (pick someone)') : null,
            uses.includes('light') ? h('button', { class: 'hud-btn', disabled: !!inc, title: inc ? `${inc.name} is already burning` : 'An hour of its type turning up more on walks', onclick: () => {
              let r; app.commit((sv) => { r = lightIncense(app.idx, sv, pickIt.id); }, 'incense', { quiet: true });
              if (!r?.ok) { toast(r?.reason ?? 'Couldn’t light it.', 'err'); return; }
              sfx('heal'); app.say(`${pickIt.name} is lit: an hour of its type turning up more on walks.`); bagPick = null; renderMenu();
            } }, inc ? 'One is already lit' : 'Light it') : null,
            healingOf(pickIt) ? h('button', { class: 'hud-btn', disabled: !sel, title: sel ? '' : 'Click someone in the yard first', onclick: () => {
              let r; app.commit((sv) => { r = useMedicine(app.idx, sv, sel.uid, pickIt.id); }, 'heal', { quiet: true });
              if (!r?.ok) { toast(r?.reason ?? 'That didn’t help.', 'err'); return; }
              sfx('heal'); yard.react(sel.uid, 'sparkle', 3); app.say(r.text); renderMenu(); renderPanel();
            } }, sel ? `Use on ${displayName(app.idx, sel)}` : 'Use on… (pick someone)') : null,
            uses.includes('wear') && sel ? h('button', { class: 'hud-btn', onclick: async () => { closeMenu(); yard.stop(); await openDressUp(app, sel.uid); yard.start(); syncActors(); renderPanel(); } }, 'Dress up…') : null,
            pickIt.kind === 'tm' ? h('button', { class: 'hud-btn', onclick: () => app.go('battle') }, 'Teach (Battle Link → team)') : null,
            uses.includes('sell') ? h('button', { class: 'hud-btn', onclick: () => app.go('market') }, 'Sell…') : null)) : null,
        inc ? h('span', { class: 'hud-hint' }, `${inc.name} is burning for another ${Math.ceil((inc.until - Date.now()) / 60000)} min.`) : null];
    }
    mount(menuEl, h('div', { class: 'hud-menu-head' }, 'Bag'), tabs, body);
  }

  /** Right-click someone in the yard: everything you can do with them, in one place. */
  function creatureMenu(uid, ev) {
    const c = app.save.creatures[uid];
    if (!c) return;
    document.querySelector('.quick-menu')?.remove();
    selected = uid; yard.selected = uid; panelOpen = true; renderPanel(); renderHud();
    const item = (label, fn, cls = '') => h('button', { class: cls, onclick: () => { menuBox.remove(); fn(); } }, label);
    const sep = (t) => h('div', { class: 'qm-sep' }, t);
    const heldName = c.heldItemId ? itemInfo(app.idx, c.heldItemId)?.name : null;
    const menuBox = h('div', { class: 'quick-menu', style: { left: `${Math.min(ev.clientX, innerWidth - 230)}px`, top: `${Math.min(ev.clientY, innerHeight - 340)}px` } },
      h('div', { class: 'qm-title' }, displayName(app.idx, c)),
      sep('Care'),
      item('Quality time', () => careRoom(uid)),
      item('Pet', () => care(uid, 'pet')),
      isAsleep(c) ? (() => { const b = item('Wake up', () => care(uid, 'wake')); if (wakeRisk(c)) b.title = WAKE_HINT; return b; })() : item('Nap', () => care(uid, 'rest')),
      item('Dress up', async () => { yard.stop(); await openDressUp(app, uid); yard.start(); syncActors(); renderPanel(); }),
      item('📖 Journal', () => openJournal({ idx: app.idx, bank: app.bank, save: app.save }, c)),
      item(yard.followUid === uid ? 'Stop following' : '🎥 Follow with the camera', () => { yard.follow(yard.followUid === uid ? null : uid); renderHud(); }),
      sep('Items'),
      item(heldName ? `Holding: ${heldName}…` : 'Give an item to hold…', () => giveHeld(c)),
      (app.save.pokeblocks ?? []).length && !c.egg ? item(`Give a Pokéblock… (${app.save.pokeblocks.length})`, () => giveBlock(c)) : null,
      ...(() => { const ch = changeItems(app, c, item, () => { syncActors(); yard.react(c.uid, 'sparkle', 4); renderPanel(); renderHud(); }); return ch.length ? [sep('Change'), ...ch] : []; })(),
      sep('Move'),
      party(app.save).length < app.idx.ds.rules.partySize ? item('Take into the party', () => toParty(c)) : null,
      !c.egg ? item('Send to the desktop', () => toDesktop(c)) : null,
      item('Release…', () => releaseIt(c), 'danger'));
    document.body.append(menuBox);
    // keep it on screen
    const rb = menuBox.getBoundingClientRect();
    menuBox.style.top = `${Math.max(8, Math.min(ev.clientY, innerHeight - rb.height - 8))}px`;
    menuBox.style.left = `${Math.max(8, Math.min(ev.clientX, innerWidth - rb.width - 8))}px`;
    const close = (e) => { if (!menuBox.contains(e.target)) { menuBox.remove(); window.removeEventListener('pointerdown', close, true); } };
    setTimeout(() => window.addEventListener('pointerdown', close, true), 0);
  }
  function toParty(c) {
    const rect = yard.screenRect(c.uid);
    let r; app.commit((s) => { r = moveCreature(s, c.uid, { kind: 'party' }, app.idx.ds.rules.partySize); }, 'move', { quiet: true });
    if (r && !r.ok) return toast(r.error, 'err');
    const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
    selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
    if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: typeTint(c), say: transferLine('party', displayName(app.idx, c)) });
    else sfx('access');
  }
  function toDesktop(c) {
    const rect = yard.screenRect(c.uid);
    let r; app.commit((s) => { r = toggleBuddy(s, c.uid, true); });
    if (!r.ok) { toast(r.reason, 'err'); return; }
    const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
    selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
    const say = `${displayName(app.idx, c)} hopped out onto your desktop.`;
    if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: typeTint(c), say }); else app.say(say);
  }
  async function releaseIt(c) {
    const name = displayName(app.idx, c);
    if (!(await confirmDialog(`Release ${name}?`, `${name} will return to the wild for good. This can’t be undone.`, { ok: 'Release', danger: true }))) return;
    const rect = yard.screenRect(c.uid);
    const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
    app.commit((s) => releaseCreature(s, c.uid), 'release', { quiet: true });
    selected = null; yard.selected = null; panelOpen = false; syncActors(); renderPanel(); renderHud();
    const say = `${name} looked back once, then headed off into the wild.`;
    if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: '#ffffff', say });
    app.say(say);
  }

  // ---------- the berry farm ----------
  async function plotClick(i) {
    const st = plotStatus(app.idx, farmState(app.save).plots[i]);
    if (st.ready) {
      let r;
      app.commit((s) => { r = harvest(app.idx, s, i); }, 'farm', { quiet: true });
      if (r?.ok) { sfx('level'); toast(`Picked ${r.count} ${r.item.name}${r.bonus ? ` (${r.bonus} extra!)` : ''}.${r.regrew ? ' The Gooey Mulch makes it grow back.' : ''}`, 'ok'); }
    } else if (st.empty) {
      const seeds = plantable(app.idx).filter((it) => it.unlimited || (app.save.inventory[it.id] ?? 0) > 0);
      const pick = await chooseDialog('Plant something', seeds.map((it) => ({ value: it.id, label: it.name, detail: `${app.save.inventory[it.id] ?? 0} in the bag · ripe in ${growInfo(it).hours} h · gives ${growInfo(it).yield}` })), { empty: 'Nothing to plant. Walks turn up berries and roots, and the Market sells them; plant one to grow more.' });
      if (!pick) return;
      // mulch, if you have some
      let mulch = null;
      const ms = mulchInBag(app.save);
      if (ms.length) {
        mulch = await chooseDialog('Spread some mulch?', [{ value: '__none', label: 'No mulch', detail: 'Just plant it.' }, ...ms.map((m) => ({ value: m.id, label: m.name, detail: `${m.desc} · ${m.n} in the bag` }))]);
        if (!mulch) return;
        if (mulch === '__none') mulch = null;
      }
      let r;
      app.commit((s) => { r = plant(app.idx, s, i, pick, Date.now(), mulch); }, 'farm', { quiet: true });
      if (r && !r.ok) toast(r.reason, 'err'); else sfx('heal');
    } else toast(`${st.item?.name ?? 'It'} is ripe in ${fmtLeft(st.left)}.`);
    syncPlots(); renderPanel();
  }

  async function bring() {
    const to = cur === 'ranch' ? { kind: 'ranch' } : (() => { const t = firstFreeBoxSlot(app.save, 30, cur); return t && t.box === cur ? t : null; })();
    if (!to) { toast('This yard is full (30 creatures).', 'err'); return; }
    const options = list(app.save).filter((c) => ['party', 'box', 'ranch'].includes(c.location.kind) && !(cur === 'ranch' ? c.location.kind === 'ranch' : c.location.kind === 'box' && c.location.box === cur));
    const uid = await chooseDialog('Bring someone to this yard', options.map((c) => ({
      value: c.uid, label: displayName(app.idx, c), detail: `Lv. ${c.level} · ${c.location.kind === 'party' ? 'party' : c.location.kind === 'ranch' ? 'free range' : app.save.boxes[c.location.box]?.name}`,
      el: spriteCanvas(app.bank, c, { scale: 1 }),
    })), { empty: 'Everyone is already here.' });
    if (!uid) return;
    let r;
    app.commit((s) => { r = moveCreature(s, uid, { ...to }, app.idx.ds.rules.partySize); }, 'move', { quiet: true });
    if (r && !r.ok) { toast(r.error, 'err'); return; }
    syncActors();
    const a = yard.actors.get(uid);
    if (a) a.appear = -1.1; // shows up as the light lands
    const who = app.save.creatures[uid];
    const art = h('span', null, spriteCanvas(app.bank, who, { scale: 2 }));
    playTransfer({ to: yard.screenRect(uid), mode: 'arrive', spriteEl: art, tint: typeTint(who), say: transferLine(cur === 'ranch' ? 'ranch' : 'box', displayName(app.idx, who), { box: app.save.boxes[cur]?.name }) });
    renderHud();
  }

  function renderHud() {
    // build mode: the thing being placed (or moved) follows the pointer
    try { yard.setGhost(building && area === 'yard' ? (placing ?? (picked ? buildOf().features.find((f) => f.id === picked)?.bp ?? null : null)) : null, placing ? null : picked); } catch { /* not ready */ }
    const hb = habitat();
    const n = here().length;
    const where = area === 'yard' ? (typeof cur === 'number' ? `YARD ${String(cur + 1).padStart(2, '0')}` : 'FREE RANGE') : 'BERRY FARM';
    mount(hudTL,
      h('div', { class: 'hud-kicker' }, 'R.A.N.C.H.', h('span', null, ` // ${where}`)),
      h('div', { class: 'hud-title' }, area === 'yard' ? hb.name : 'Berry farm'),
      h('div', { class: 'hud-sub' }, area === 'yard' ? `${BIOME_INFO[hb.biome]?.label ?? hb.biome} · ${YARD_SIZES[buildOf().size ?? 0].label} · ${n} creature${n === 1 ? '' : 's'} here${guests?.key === cur ? ` · ${guests.snap.creatures.length} visiting` : ''}` : 'Plant food, pick it when ripe'),
      h('div', { class: 'hud-areas', role: 'tablist', 'aria-label': 'Area' }, AREAS.map(([id, label]) => h('button', { class: `hud-btn ${area === id ? 'on' : ''}`, role: 'tab', 'aria-selected': String(area === id), onclick: () => goArea(id) }, label))));
    mount(hudTR,
      h('div', { class: 'row' },
        h('button', { class: 'hud-btn task-btn', title: 'Your creatures’ wishes: things they’ve asked for', 'aria-label': `Task list, ${(app.save.tasks ?? []).length} waiting`, onclick: openTasks },
          '📝 Tasks', (app.save.tasks ?? []).length ? h('span', { class: 'task-count' }, String((app.save.tasks ?? []).length)) : null),
        h('button', { class: 'hud-btn', 'aria-label': 'Previous box', title: 'Previous box (Page Up)', onclick: () => stepHabitat(-1) }, '◀'),
        h('select', { class: 'hud-select', 'aria-label': 'Box', onchange: (e) => switchTo(e.target.value === 'ranch' ? 'ranch' : Number(e.target.value)) },
          habitats().map((x) => h('option', { value: String(x.key), selected: x.key === cur }, x.name))),
        h('button', { class: 'hud-btn', 'aria-label': 'Next box', title: 'Next box (Page Down)', onclick: () => stepHabitat(1) }, '▶'),
        h('button', { class: `hud-btn ${panelOpen ? 'on' : ''}`, title: 'Show or hide the yard log', onclick: () => { panelOpen = !panelOpen; logPinned = panelOpen; if (panelOpen) { selected = null; yard.selected = null; } renderPanel(); renderHud(); } }, panelOpen ? 'Hide log' : 'Log')),
      area === 'yard' ? h('label', { class: 'row hud-env' }, h('span', null, 'Environment'),
        h('select', { class: 'hud-select', onchange: (e) => {
          const v = e.target.value;
          app.commit((s) => { if (cur === 'ranch') s.ranch = { ...(s.ranch || {}), biome: v }; else s.boxes[cur].biome = v; }, 'wallpaper', { quiet: true });
          yard.setBiome(v, seedOf(cur)); yard.setWeather(yardWeatherSetting(app.save)); syncActors(); yard.materialize(); sfx('warp'); renderHud();
        } }, BIOME_IDS.map((id) => h('option', { value: id, selected: id === hb.biome }, BIOME_INFO[id].label)))) : null,
      h('label', { class: 'row hud-env' }, h('span', null, 'Time'),
        h('select', { class: 'hud-select', title: 'Local time follows the real sunrise and sunset where you are (Settings → Where you are), or this computer’s clock', onchange: (e) => {
          const v = e.target.value; app.commit((s) => { s.settings.ranchTime = v; }, 'settings', { quiet: true }); yard.setTime(v); syncActors(); sfx('warp');
        } }, [['local', 'Local time'], ['dawn', 'Morning'], ['day', 'Day'], ['dusk', 'Evening'], ['night', 'Night']].map(([v, l]) => h('option', { value: v, selected: v === (app.save.settings?.ranchTime ?? 'local') }, l)))),
      area === 'yard' ? h('label', { class: 'row hud-env' }, h('span', null, 'Weather'),
        h('select', { class: 'hud-select', title: 'Where you are: the real weather (from your phone, or Settings → Where you are). Simulated: changes every few hours, the way this kind of place tends to.', onchange: (e) => {
          const v = e.target.value; app.commit((s) => { s.settings.ranchWeather = v; }, 'settings', { quiet: true }); yard.setWeather(v); weatherReact(); sfx('warp'); renderHud();
        } }, [['real', `Where you are (${yardWeather() ? WEATHER_LABEL[yardWeather()] ?? '' : 'not known: simulated'})`], ['sim', `Simulated (${WEATHER_LABEL[yard.weatherMode === 'sim' ? yard.weather : 'clear'] ?? '☀ Clear'})`], ...Object.entries(WEATHER_LABEL)].map(([v, l]) => h('option', { value: v, selected: v === (yardWeatherSetting(app.save)) }, l)))) : null,
      area === 'yard' ? h('label', { class: 'row hud-env' }, h('span', null, 'Camera'),
        h('select', { class: 'hud-select', title: 'Keep the camera on someone (in cinematic mode too)', onchange: (e) => { yard.follow(e.target.value || null); sfx('move'); renderHud(); } },
          [h('option', { value: '' }, 'Free'), ...here().filter((x) => !x.egg).map((x) => h('option', { value: x.uid, selected: yard.followUid === x.uid }, `Follow ${displayName(app.idx, x)}`))])) : null,
      h('button', { class: 'hud-btn', title: 'Cinematic mode: full screen, no buttons, the camera drifts on its own (or round whoever you follow). Esc to leave.', onclick: () => cinematic(true) }, '🎬 Cinematic'));
    mount(hudBottom,
      area === 'yard' && building ? [
        h('button', { class: 'hud-btn wide on', onclick: () => setBuilding(false) }, 'Done building'),
        h('span', { class: 'hud-hint' }, placing ? `Click the ground to place the ${blueprintOf(placing)?.name}` : picked ? 'Click the ground to move it there · or put it away from the panel' : 'Pick a blueprint from the panel, or click something built to move it'),
      ] : area === 'yard' ? [
        h('span', { class: 'hud-group' },
          h('button', { class: `hud-btn wide ${menu === 'bag' ? 'on' : ''}`, 'aria-expanded': String(menu === 'bag'), title: 'Food, toys and items', onclick: () => openMenu('bag') }, '🎒 Bag ▴')),
        h('span', { class: 'hud-group' },
          h('button', { class: 'hud-btn wide', onclick: bring }, 'Bring someone'),
          h('button', { class: 'hud-btn wide', title: 'Place blueprints from the Market, expand the yard, see who thrives here', onclick: () => setBuilding(true) }, 'Build')),
        h('span', { class: 'hud-hint' }, 'Rub to pet · right-click someone for more · drag to pick up · fling to toss · scroll to zoom'),
      ] : h('span', { class: 'hud-hint' }, 'Click a plot to plant or pick · drag the ground to look around'),
      h('span', { class: 'hud-orbit' },
        h('button', { class: 'hud-btn', title: 'Zoom in (+)', 'aria-label': 'Zoom in', onclick: () => yard.zoom(-1) }, '+'),
        h('button', { class: 'hud-btn', title: 'Zoom out (−)', 'aria-label': 'Zoom out', onclick: () => yard.zoom(1) }, '−'),
        h('button', { class: 'hud-btn', title: 'Turn left (Q)', 'aria-label': 'Turn the view left', onclick: () => yard.turn(-1) }, '⟲'),
        h('button', { class: 'hud-btn', title: 'Face the front (R)', 'aria-label': 'Reset the view', onclick: () => { yard.turn(0); yard.zoom(0); } }, '◎'),
        h('button', { class: 'hud-btn', title: 'Turn right (E)', 'aria-label': 'Turn the view right', onclick: () => yard.turn(1) }, '⟳')),
      h('span', { class: 'hud-link', title: 'Live data link to this area' }, h('i'), 'LINK STABLE'));
  }

  function farmPanel() {
    const farm = farmState(app.save);
    const seeds = plantable(app.idx);
    return [
      h('div', { class: 'holo-head' }, 'Berry farm'),
      h('p', { class: 'holo-dim' }, 'Plant one of a food from your bag and pick several when it ripens. Plants keep growing while the app is closed.'),
      h('div', { class: 'holo-list' }, farm.plots.slice(0, farmPlots(app.save)).map((p, i) => {
        const st = plotStatus(app.idx, p);
        return h('button', { class: 'holo-row', onclick: () => plotClick(i) },
          h('span', { class: 'plot-dot', style: { background: st.empty ? '#6b4423' : st.item?.color ?? '#3fb26a' } }),
          h('span', { class: 'grow' }, st.empty ? `Plot ${i + 1}: empty` : `${st.item?.name ?? st.itemId}${st.mulch ? ` · ${blueprintOf(st.mulch)?.name ?? 'mulch'}` : ''}`),
          h('span', { class: 'holo-dim' }, st.empty ? 'Plant' : st.ready ? 'Ready!' : fmtLeft(st.left)));
      })),
      h('div', { class: 'row wrap gap' },
        h('span', { class: 'holo-dim grow' }, `${farmPlots(app.save)} planters${(farm.size ?? 0) < MAX_FARM_SIZE ? '' : ' (as big as it gets)'}`),
        (farm.size ?? 0) < MAX_FARM_SIZE ? h('button', { class: 'btn small', title: 'Needs a Farm Expansion from the Market (Blueprints → Berry farm)', onclick: () => {
          let r; app.commit((s) => { r = expandFarm(s); }, 'farm', { quiet: true });
          if (!r?.ok) { toast(r?.reason ?? 'Couldn’t expand.', 'err'); return; }
          sfx('level'); toast(`The farm grew: ${r.plots} planters now!`, 'ok'); yard.setFarmSize(r.size); syncPlots(); renderPanel();
        } }, `Expand the farm (${app.save.inventory[bpId('farm-expand')] ?? 0})`) : null),
      h('div', { class: 'holo-head' }, 'Tools'),
      farmTools(app.save).length ? h('div', { class: 'col' }, farmTools(app.save).map((t) => h('small', { class: 'holo-dim' }, `${t.name}: ${t.desc.replace(/ Kept for good\.$/, '')}`)))
        : h('p', { class: 'holo-dim' }, 'No tools yet. A Sprayduck or Wailmer Pail speeds everything up; a Harvest Basket or Golden Shears gets you more at harvest (Market → Blueprints → Berry farm).'),
      mulchInBag(app.save).length ? h('p', { class: 'holo-dim' }, `Mulch: ${mulchInBag(app.save).map((m) => `${m.name} × ${m.n}`).join(', ')} (choose when planting)`) : null,
      h('div', { class: 'holo-head' }, 'Seeds in the bag'),
      h('div', { class: 'kv holo-kv' }, seeds.map((it) => [h('span', null, it.name), h('span', null, `× ${app.save.inventory[it.id] ?? 0}`)])),
    ];
  }
  // ---------- cinematic mode: a living wallpaper of the yard ----------
  function cinematic(on) {
    if (on === cinemaOn) return;
    cinemaOn = on;
    el.classList.toggle('cinema', on);
    yard.cinema(on);
    if (on) { selected = null; yard.selected = null; panelOpen = false; closeMenu(); renderPanel(); el.requestFullscreen?.().catch(() => {}); sfx('warp'); }
    else if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
    setTimeout(() => yard.resize(), 200);
  }
  const onFsChange = () => { if (!document.fullscreenElement && cinemaOn) cinematic(false); };
  document.addEventListener('fullscreenchange', onFsChange);
  el.addEventListener('pointerdown', () => { if (cinemaOn) cinematic(false); }, true);

  // ---------- building: blueprints from the Market ----------
  function setBuilding(on) {
    building = on; placing = null; picked = null;
    yard.buildMode = on; yard.pickedFeature = null;
    closeMenu();
    if (on) { panelOpen = true; selected = null; yard.selected = null; }
    sfx(on ? 'access' : 'back');
    renderPanel(); renderHud();
  }
  function placeAt(at) {
    if (!building) return;
    let r;
    if (placing) {
      app.commit((s) => { r = placeFeature(s, cur, placing, at.x, at.z); }, 'build', { quiet: true });
      if (!r?.ok) { toast(r?.reason ?? 'Couldn’t build that here.', 'err'); return; }
      sfx('level'); app.say(`Built the ${blueprintOf(placing)?.name}.`);
      if ((app.save.inventory[bpId(placing)] ?? 0) <= 0) placing = null;
    } else if (picked) {
      app.commit((s) => { r = moveFeature(s, cur, picked, at.x, at.z); }, 'build', { quiet: true });
      sfx('blip');
    } else return;
    syncActors(); renderPanel(); renderHud();
  }
  function buildPanel() {
    const b = buildOf();
    const folk = here();
    const owned = BLUEPRINTS.filter((bp) => bp.kind !== 'expand' && bp.kind !== 'farm' && (app.save.inventory[bpId(bp.id)] ?? 0) > 0);
    const expands = app.save.inventory[bpId('expand')] ?? 0;
    const rep = thriveReport(app.idx, app.save, cur, folk);
    const gate = b.features.some((f) => f.bp === 'link-gate');
    const pickedF = b.features.find((f) => f.id === picked);
    return [
      h('div', { class: 'holo-head' }, 'Build'),
      h('p', { class: 'holo-dim' }, `${YARD_SIZES[b.size ?? 0].label} yard · ${b.features.length} of ${featureRoom(b.size)} spots used. Blueprints come from the Market.`),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small', disabled: (b.size ?? 0) >= MAX_YARD_SIZE || !expands, title: expands ? '' : 'Buy a Yard Expansion at the Market', onclick: () => {
          let r; app.commit((s) => { r = expandYard(s, cur); }, 'build', { quiet: true });
          if (!r?.ok) { toast(r.reason, 'err'); return; }
          sfx('warp'); app.say(`The yard grew: now ${YARD_SIZES[r.size].label.toLowerCase()}.`); syncActors(); yard.materialize(); renderPanel(); renderHud();
        } }, (b.size ?? 0) >= MAX_YARD_SIZE ? 'Biggest it gets' : `Expand the yard${expands ? ` (${expands})` : ''}`),
        h('button', { class: 'btn small', onclick: () => app.go('market') }, 'Market')),
      pickedF ? [
        h('div', { class: 'holo-head small' }, blueprintOf(pickedF.bp)?.name),
        h('p', { class: 'holo-dim' }, 'Click the ground to move it.'),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn small', onclick: () => { let r; app.commit((s) => { r = removeFeature(s, cur, pickedF.id); }, 'build', { quiet: true }); if (!r?.ok) { toast(r?.reason ?? 'Couldn’t put it away.', 'err'); return; } picked = null; yard.pickedFeature = null; sfx('back'); syncActors(); renderPanel(); renderHud(); } }, 'Put it away'),
          h('button', { class: 'btn small', onclick: () => { picked = null; yard.pickedFeature = null; renderPanel(); renderHud(); } }, 'Done'))] : null,
      h('div', { class: 'holo-head small' }, 'Blueprints in the bag'),
      owned.length ? h('div', { class: 'holo-list' }, owned.map((bp) => h('button', { class: `holo-row ${placing === bp.id ? 'on' : ''}`, onclick: () => { placing = placing === bp.id ? null : bp.id; picked = null; yard.pickedFeature = null; sfx('move'); renderPanel(); renderHud(); } },
        h('span', { class: 'grow' }, bp.name), h('span', { class: 'holo-dim' }, `× ${app.save.inventory[bpId(bp.id)]}`), h('span', { class: 'holo-dim' }, placing === bp.id ? 'placing…' : 'Place'))))
        : h('p', { class: 'holo-dim' }, 'None. Buy blueprints at the Market (ponds, sun patches, slides, toy chests…).'),
      b.features.length ? [h('div', { class: 'holo-head small' }, 'Built here'),
        h('div', { class: 'holo-list' }, b.features.map((f) => {
          const fans = folk.filter((c) => appeal(app.idx, c, f.bp) > 0.35).length, foes = folk.filter((c) => appeal(app.idx, c, f.bp) < -0.35).length;
          return h('button', { class: `holo-row ${picked === f.id ? 'on' : ''}`, onclick: () => { picked = picked === f.id ? null : f.id; placing = null; yard.pickedFeature = picked; renderPanel(); renderHud(); } },
            h('span', { class: 'grow' }, blueprintOf(f.bp)?.name ?? f.bp), h('span', { class: 'holo-dim' }, `${fans ? `♥ ${fans}` : ''}${foes ? ` ✗ ${foes}` : ''}`));
        }))] : null,
      h('div', { class: 'holo-head small' }, 'Who thrives here'),
      rep.rows.length ? h('div', { class: 'holo-list' }, rep.rows.map((r) => h('div', { class: 'holo-row thrive' },
        h('span', { class: `thrive-dot t-${r.label.toLowerCase()}` }), h('span', { class: 'grow col' }, h('span', null, `${r.name} · ${r.label}`), h('small', { class: 'holo-dim' }, r.reasons.join(', ') || '—')))))
        : h('p', { class: 'holo-dim' }, 'Nobody lives here yet.'),
      rep.pairs.length ? [h('div', { class: 'holo-head small' }, 'Good together'), h('div', { class: 'holo-list' }, rep.pairs.map((p) => h('div', { class: 'holo-row' }, h('span', { class: 'grow' }, `${p.a} & ${p.b}`), h('span', { class: 'holo-dim' }, p.why))))] : null,
      gate ? linkGatePanel() : null,
    ];
  }
  // ---------- the Link gate: a friend's yard beside yours ----------
  function linkGatePanel() {
    const snapFile = () => {
      const snap = ranchSnapshot(app.idx, app.save, cur, here());
      const blob = new Blob([JSON.stringify(snap, null, 1)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = `${(app.save.trainer?.name ?? 'ranch').replace(/[^\w-]+/g, '_')}-${(habitat().name ?? 'yard').replace(/[^\w-]+/g, '_')}.clranch`;
      a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      toast('Saved your yard. Send the file to a friend; they open it at their Link gate.', 'ok');
    };
    const open = () => {
      const inp = h('input', { type: 'file', accept: '.clranch,application/json', class: 'hidden', onchange: async (e) => {
        const f = e.target.files[0]; if (!f) return;
        const r = readSnapshot(app.idx, await f.text());
        if (!r.ok) { toast(r.reason, 'err'); return; }
        guests = { snap: r.snap, key: cur };
        syncActors();
        for (const g of r.snap.creatures) { const a = yard.actors.get(`guest:${g.uid}`); if (a) a.appear = -0.6 - Math.random(); }
        sfx('warp');
        app.say(`${r.snap.trainer.name}’s creatures came through the Link gate to visit!${r.missing.length ? ` (${r.missing.length} kind${r.missing.length > 1 ? 's' : ''} you don’t have data for yet: ${r.missing.slice(0, 3).join(', ')}${r.missing.length > 3 ? '…' : ''})` : ''}`);
        renderPanel(); renderHud();
      } });
      document.body.append(inp); inp.click(); setTimeout(() => inp.remove(), 60000);
    };
    return [
      h('div', { class: 'holo-head small' }, 'Link gate'),
      h('p', { class: 'holo-dim' }, 'Join a friend’s yard to yours, side by side: their creatures visit and play with yours, and they can make friends. For now you swap yards as files; live links over the internet come later.'),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small', onclick: snapFile }, 'Save this yard for a friend'),
        guests?.key === cur ? h('button', { class: 'btn small', onclick: () => { guests = null; syncActors(); sfx('back'); app.say('Your visitors headed home.'); renderPanel(); renderHud(); } }, 'Send visitors home')
          : h('button', { class: 'btn small primary', onclick: open }, 'Open a friend’s yard')),
    ];
  }

  // ---------- machines: fossil revival and the egg incubator ----------
  function machinesPanel() {
    const fm = machinesIn(app.save, cur, 'fossil-machine'), inc = machinesIn(app.save, cur, 'incubator'), bl = machinesIn(app.save, cur, 'berry-blender');
    if (!fm.length && !inc.length && !bl.length) return null;
    const hrs = (ms) => { const m = Math.ceil(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`; };
    const eggs = here().filter((x) => x.egg);
    return [
      h('div', { class: 'holo-head small' }, 'Machines'),
      fm.map((f) => {
        const st = revivalStatus(app.idx, app.save, f.id);
        return h('div', { class: 'holo-row' }, h('span', { class: 'grow col' }, h('span', null, 'Fossil Revival Machine'),
          h('small', { class: 'holo-dim' }, st.idle ? 'Empty. Fossils turn up (very rarely) when scavenging.' : st.busy ? `Reviving a ${st.fossil?.name}… ${hrs(st.left)} left` : `Done! Something’s moving in there.`)),
          st.idle ? h('button', { class: 'btn small', onclick: () => reviveFossil(f.id) }, 'Revive a fossil…')
            : st.ready ? h('button', { class: 'btn small primary', onclick: () => {
              let r; app.commit((s) => { r = collectRevival(app.idx, s, f.id, { trainer: s.trainer?.name ?? '' }); }, 'revive');
              if (!r?.ok) { toast(r?.reason ?? 'Not yet.', 'err'); return; }
              sfx('level'); app.say(`${r.name} woke up from a very long sleep and joined you!`); syncActors(); const a = yard.actors.get(r.creature.uid); if (a) a.appear = -1.2; renderPanel(); renderHud();
            } }, 'Open it') : null);
      }),
      bl.length ? h('div', { class: 'holo-row' }, h('span', { class: 'grow col' }, h('span', null, 'Berry Blender'),
        h('small', { class: 'holo-dim' }, `Make Pokéblocks with friends (or helpers). ${(app.save.pokeblocks ?? []).length} in your Pokéblock Case.`)),
        h('button', { class: 'btn small primary', onclick: () => openBlender() }, 'Blend…')) : null,
      inc.length ? h('div', { class: 'holo-row' }, h('span', { class: 'grow col' }, h('span', null, 'Egg Incubator'),
        h('small', { class: 'holo-dim' }, eggs.length ? eggs.map((e) => `${displayName(app.idx, e)} ${Math.round(eggProgress(e) * 100)}%`).join(' · ') + ' — warm and hatching four times as fast' : 'No eggs in this yard. Eggs living here hatch four times as fast.'))) : null,
    ];
  }
  function openBlender() {
    yard.stop();
    hostBerryBlender(app, { session: friendsSession(app), yardKey: cur }).finally(() => { const wait = setInterval(() => { if (!document.querySelector('.bb-scrim')) { clearInterval(wait); yard.start(); renderPanel(); } }, 500); });
  }
  /** Double-clicked a machine in the yard. */
  function useMachine(fid, bp) {
    if (bp === 'berry-blender') { openBlender(); return; }
    if (bp === 'fossil-machine') {
      const st = revivalStatus(app.idx, app.save, fid);
      if (st.idle) { reviveFossil(fid); return; }
      if (st.busy) { app.say(`The machine hums: a ${st.fossil?.name ?? 'fossil'} is coming back to life (${Math.ceil(st.left / 60000)} min left).`); return; }
      let r; app.commit((s) => { r = collectRevival(app.idx, s, fid, { trainer: s.trainer?.name ?? '' }); }, 'revive');
      if (!r?.ok) { toast(r?.reason ?? 'Not yet.', 'err'); return; }
      sfx('level'); app.say(`${r.name} woke up from a very long sleep and joined you!`); syncActors(); const a = yard.actors.get(r.creature.uid); if (a) a.appear = -1.2; renderPanel(); renderHud();
      return;
    }
    if (bp === 'incubator') {
      const eggs = here().filter((x) => x.egg);
      app.say(eggs.length ? `Warm and cosy: ${eggs.map((e) => `${displayName(app.idx, e)} ${Math.round(eggProgress(e) * 100)}%`).join(', ')}.` : 'The incubator is warm, but there are no eggs in this yard.');
    }
  }
  async function giveBlock(c) {
    const id = await chooseBlock(app, c); if (!id) return;
    let r; app.commit((s) => { r = feedPokeblock(app.idx, s, c.uid, id); }, 'pokeblock', { quiet: true });
    if (!r?.ok) { toast(r?.reason ?? 'They didn’t want it.', 'err'); return; }
    sfx('munch'); yard.react(c.uid, r.taste === 'disdain' ? 'sad' : r.taste === 'happily' ? 'hearts' : 'munch', 3);
    const g = Object.entries(r.gains).map(([k, v]) => `${CONDITION_NAMES[k]} +${v}`).join(', ');
    app.say(`${displayName(app.idx, c)} ate it ${r.taste === 'happily' ? 'happily' : r.taste === 'disdain' ? 'with disdain' : 'up'}.${g ? ` ${g}.` : ' Their conditions are already as high as they go.'} Sheen ${'★'.repeat(r.stars)}`);
    renderPanel();
  }
  async function reviveFossil(fid) {
    const have = FOSSILS.filter((f) => (app.save.inventory[f.id] ?? 0) > 0);
    const pick = await chooseDialog('Put a fossil in the machine', have.map((f) => ({ value: f.id, label: f.name, detail: `${fossilSpecies(app.idx, f)?.name ?? '???'} · ${app.save.inventory[f.id]} in the bag · ${REVIVE_HOURS} hours` })),
      { empty: 'No fossils in the bag. They turn up, very rarely, when your creatures go scavenging.' });
    if (!pick) return;
    let r; app.commit((s) => { r = startRevival(app.idx, s, cur, fid, pick); }, 'revive');
    if (!r?.ok) { toast(r?.reason ?? 'The machine wouldn’t start.', 'err'); return; }
    sfx('access'); app.say(`The machine hums… the fossil will wake in about ${REVIVE_HOURS} hours.`); renderPanel();
  }

  async function giveHeld(c, preset = null) {
    if (preset) return holdIt(c, preset);
    const held = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && holdable(itemInfo(app.idx, id))).map(([id, n]) => ({ item: itemInfo(app.idx, id), n }));
    const pick = await chooseDialog(`Something for ${displayName(app.idx, c)} to hold`, [
      ...(c.heldItemId ? [{ value: '__none', label: 'Take it back', detail: itemInfo(app.idx, c.heldItemId)?.name ?? '' }] : []),
      ...held.map(({ item, n }) => ({ value: item.id, label: item.name, detail: `${item.desc ?? ''} · ${n} in the bag${item.showdownName ? '' : ' · only for show until it has a battle name (Data Lab)'}` })),
    ], { empty: 'Nothing to hold in the bag. The Market sells gear; berries and incense can be held too.' });
    if (!pick) return;
    holdIt(c, pick);
  }
  function holdIt(c, pick) {
    app.commit((s) => {
      const x = s.creatures[c.uid];
      if (x.heldItemId) s.inventory[x.heldItemId] = (s.inventory[x.heldItemId] ?? 0) + 1;
      if (pick === '__none') { x.heldItemId = null; x.heldItem = ''; return; }
      const it = itemInfo(app.idx, pick);
      s.inventory[pick] = Math.max(0, (s.inventory[pick] ?? 0) - 1);
      x.heldItemId = pick; x.heldItem = it.showdownName || '';
    }, 'held');
    sfx('access');
    if (pick !== '__none') app.say(`${displayName(app.idx, c)} is holding the ${itemInfo(app.idx, pick)?.name ?? 'item'}.`);
    bagPick = null; if (menu) renderMenu();
    renderPanel();
  }

  function renderPanel() {
    panel.classList.toggle('open', panelOpen);
    el.classList.toggle('panel-open', panelOpen);
    if (area === 'farm') { mount(panel, farmPanel()); return; }
    if (building) { mount(panel, buildPanel()); return; }
    if (selected && String(selected).startsWith('guest:') && guests) {
      const g = guests.snap.creatures.find((x) => `guest:${x.uid}` === selected);
      if (g) {
        mount(panel,
          h('div', { class: 'holo-head' }, g.name),
          h('p', { class: 'holo-dim' }, `${g.species} · Lv. ${g.level} · visiting from ${guests.snap.trainer.name}’s ranch${guests.snap.trainer.code ? ` (ID ${guests.snap.trainer.code})` : ''}.`),
          h('p', { class: 'holo-dim' }, 'Guests can’t be looked after here, but they play with your creatures, and they can become friends.'),
          h('button', { class: 'btn small', onclick: () => { selected = null; yard.selected = null; renderPanel(); } }, 'Close'));
        return;
      }
    }
    const c = selected && app.save.creatures[selected];
    const inHere = c && here().some((x) => x.uid === c.uid);
    if (!inHere) {
      const folk = here();
      mount(panel,
        h('div', { class: 'holo-head' }, 'Yard log'),
        h('p', { class: 'holo-dim' }, `${RANCH_NAME}. Whoever is in this box lives in this yard. Click someone to look after them.`),
        folk.length ? h('div', { class: 'holo-list' }, folk.map((x) => h('button', { class: 'holo-row', onclick: () => { selected = x.uid; yard.selected = x.uid; sfx('move'); renderPanel(); } },
          spriteCanvas(app.bank, x, { scale: 1 }), h('span', { class: 'grow' }, displayName(app.idx, x)), h('span', { class: 'holo-dim' }, mood(x).label))))
          : h('p', { class: 'holo-dim' }, 'Nobody lives here yet. Bring someone, or move creatures into this box from the storage system.'),
        outOnDesktop().length ? [h('div', { class: 'holo-head small' }, 'Out on the desktop'),
          h('div', { class: 'holo-list' }, outOnDesktop().map((x) => h('div', { class: 'holo-row' }, spriteCanvas(app.bank, x, { scale: 1 }), h('span', { class: 'grow' }, displayName(app.idx, x)),
            h('button', { class: 'btn small', onclick: () => { app.commit((s) => { toggleBuddy(s, x.uid, false); }); syncActors(); const a = yard.actors.get(x.uid); if (a) a.appear = -1.1; sfx('warp'); app.say(`${displayName(app.idx, x)} came back to the yard.`); renderPanel(); renderHud(); } }, 'Call back'))))] : null,
        machinesPanel(),
        h('p', { class: 'holo-dim' }, 'Food, toys and items: the Bag at the bottom left. Right-click someone for everything you can do with them.'));
      return;
    }
    const j = journalOf(app.idx, app.save, c);
    const heldName = c.heldItemId ? itemInfo(app.idx, c.heldItemId)?.name : null;
    const group = (title, ...kids) => h('div', { class: 'ranch-group' }, h('div', { class: 'ranch-group-head' }, title), ...kids);
    const actions = h('div', { class: 'col' },
      group('Look after',
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn primary', title: 'Just the two of you: wash, brush, feed by hand, play fetch', onclick: () => careRoom(c.uid) }, 'Quality time'),
          h('button', { class: 'btn', onclick: () => care(c.uid, 'pet') }, 'Pet'),
          h('button', { class: 'btn', onclick: () => { creatureCry(speciesOf(app.idx, c), c, { talk: true }); care(c.uid, 'talk'); yard.emote(c.uid); } }, 'Call'),
          isAsleep(c) ? h('button', { class: 'btn', title: wakeRisk(c) ? `They keep the energy they got so far. ${WAKE_HINT}` : 'They keep the energy they got so far.', onclick: () => care(c.uid, 'wake') }, 'Wake up')
            : h('button', { class: 'btn', title: 'A proper nap: energy comes back bit by bit until they wake up. Tired creatures also nap by themselves.', onclick: () => care(c.uid, 'rest') }, 'Nap'))),
      group('Looks',
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn small', onclick: async () => { yard.stop(); await openDressUp(app, c.uid); yard.start(); syncActors(); renderPanel(); } }, 'Dress up'),
          heldName ? h('span', { class: 'chip' }, `Holding: ${heldName}`) : null),
        (() => { const ch = changeItems(app, c, (label, fn) => h('button', { class: 'btn small', onclick: fn }, label), () => { syncActors(); yard.react(c.uid, 'sparkle', 4); renderPanel(); renderHud(); }); return ch.length ? h('div', { class: 'row wrap change-row' }, ch) : null; })()),
      // the field journal (as on the phone): what you've found out about them
      group('Journal',
        h('div', { class: 'row' }, h('p', { class: 'micro dim grow', style: { margin: 0 } }, `${j.temper} · ${j.style}`),
          h('button', { class: 'btn small primary', title: 'Their whole journal, like on the phone', onclick: () => openJournal({ idx: app.idx, bank: app.bank, save: app.save }, c) }, '📖 Open journal')),
        h('dl', { class: 'cj-favs ranch-journal' }, j.favourites.map((f) => [h('dt', null, f.label), h('dd', { class: f.value === '???' ? 'dim' : '' }, f.value)])),
        Object.keys(j.likes).length ? Object.entries(j.likes).slice(0, 4).map(([head, l]) => h('p', { class: 'cj-line' }, h('b', null, `${head}: `), l.slice(0, 5).join(', '))) : h('p', { class: 'cj-line dim' }, 'Nothing yet. Spend time together and you’ll find out.'),
        j.dislikes.length ? h('p', { class: 'cj-line' }, h('b', null, 'Can’t stand: '), j.dislikes.slice(0, 5).join(', ')) : null,
        j.friends.length ? h('p', { class: 'cj-line' }, h('b', null, 'Friends: '), j.friends.join(', ')) : null,
        j.notes.slice(0, 3).map((n) => h('p', { class: 'cj-line' }, `• ${n}`))),
      h('div', { class: 'row' },
        h('span', { class: 'micro dim grow' }, 'Right-click them in the yard to give an item, take them along, or send them off.'),
        h('button', { class: 'btn small', onclick: () => { selected = null; yard.selected = null; panelOpen = false; renderPanel(); renderHud(); } }, 'Close')));
    mount(panel, creatureSummary(app.idx, app.bank, c, { compact: true, save: app.save, sections: ['care', 'walk'], actions }));
  }

  const onKey = (e) => {
    if (e.target.closest?.('input, select, textarea')) return;
    if ((e.key === 't' || e.key === 'T') && !e.ctrlKey && !e.metaKey) { e.preventDefault(); talk.open(); return; }
    if (e.key === 'q' || e.key === 'Q') yard.turn(-1);
    else if (e.key === 'e' || e.key === 'E') yard.turn(1);
    else if (e.key === 'r' || e.key === 'R') { yard.turn(0); yard.zoom(0); }
    else if (e.key === '+' || e.key === '=') yard.zoom(-1);
    else if (e.key === '-' || e.key === '_') yard.zoom(1);
    else if (e.key === 'ArrowLeft') yard.turn(-1);
    else if (e.key === 'ArrowRight') yard.turn(1);
    else if (e.key === '1') goArea('yard');
    else if (e.key === '2') goArea('farm');
    else if (e.key === 'PageUp') stepHabitat(-1);
    else if (e.key === 'PageDown') stepHabitat(1);
    else if (e.key === 'Escape' && cinemaOn) cinematic(false);
    else if (e.key === 'Escape') { if (menu) closeMenu(); else { selected = null; yard.selected = null; panelOpen = false; renderPanel(); renderHud(); } }
    else return;
    e.preventDefault();
  };
  const onDocDown = (e) => { if (menu && !menuEl.contains(e.target) && !hudBottom.contains(e.target) && e.target !== canvas) closeMenu(); };

  function update() { syncActors(); syncPlots(); renderHud(); renderPanel(); renderMood(); if (menu) renderMenu(); }

  yard.setTime(app.save.settings?.ranchTime ?? 'local');
  yard.autoReflect = true; // polished floors always, hard ground when it rains, ice anywhere (see reflectFor)
  yard.setWeather(yardWeatherSetting(app.save));
  if (app.ranchArea) { const a = app.ranchArea; app.ranchArea = null; setTimeout(() => goArea(a), 0); }
  // how they feel about the weather: rain lovers perk up, fire types and water-haters grumble, thunder startles
  function weatherReact() {
    const w = yard.weather; if (!w || w === 'clear') return;
    const key = { cloudy: 'weather:clouds', rain: 'weather:rain', storm: 'weather:storm', snow: 'weather:snow', fog: 'weather:fog', windy: 'weather:wind' }[w];
    for (const c of here()) {
      const a = yard.actors.get(c.uid); if (!a || a.egg) continue;
      const v = c.prefs?.[key] ?? 0;
      if (v >= 2) { yard.emote(c.uid, 'love', false); a.hop = 1; }
      else if (v <= -2 || ((w === 'rain' || w === 'storm') && a.fire)) yard.emote(c.uid, 'frown', false);
    }
  }
  yard.onThunder = () => { for (const a of yard.actors.values()) if (!a.egg && Math.random() < 0.5) { a.hop = 1; yard.emote(a.uid, 'wow', false); } sfx('miss'); };
  yard.buildMode = building;
  if (building) panelOpen = true;
  // visitors from a friend's yard (Friends → Visit their yard): they come through a Link gate
  if (app.pendingGuests) {
    const snap = app.pendingGuests; app.pendingGuests = null;
    const gateAt = [...app.save.boxes.keys()].find((k) => (app.save.boxes[k].build?.features ?? []).some((f) => f.bp === 'link-gate'));
    if (gateAt == null) setTimeout(() => toast('Build a Link gate in one of your yards first (blueprint from the Market), then visit again.', 'err'), 300);
    else { if (cur !== gateAt) switchTo(gateAt); guests = { snap, key: gateAt }; setTimeout(() => { syncActors(); app.say(`${snap.trainer.name}’s creatures came through the Link gate!`); renderHud(); }, 1200); }
  }
  update();
  let plotTimer = null;
  // a task the game saw being done: ticked off, waiting in the notebook to be collected
  function tasksDone(list) { if (!list?.length) return; setTimeout(() => { for (const tk of list) toast(`✓ Done: ${tk.text} Open the task list to collect.`, 'ok'); sfx('level'); renderHud(); }, 300); }
  // ---------- the task list: what they've asked for, on a page from a notebook ----------
  function openTasks() {
    const left = (ms) => { const d = Math.max(0, ms) / 86400000; return d >= 1 ? `${Math.round(d)} day${Math.round(d) === 1 ? '' : 's'} left` : `${Math.max(1, Math.round(d * 24))} h left`; };
    dialog('Task list', (close) => {
      const body = h('div', { class: 'notebook' });
      const paint = () => {
        const list = (app.save.tasks ?? []).filter((x) => app.save.creatures[x.uid]).sort((a, b) => (b.ready ? 1 : 0) - (a.ready ? 1 : 0) || a.due - b.due);
        mount(body,
          h('div', { class: 'nb-head' }, 'Wishes & requests'),
          list.length ? h('ul', { class: 'nb-list' }, list.map((tk) => h('li', { class: `nb-item${tk.ready ? ' ready' : ''}` },
            h('span', { class: 'nb-pic' }, spriteCanvas(app.bank, app.save.creatures[tk.uid], { scale: 1 })),
            h('span', { class: 'nb-text' }, h('span', null, `${tk.icon ?? '•'} ${tk.text}`), h('span', { class: 'nb-due' }, tk.ready ? '✓ done: ready to collect' : trackable(tk) ? `${left(tk.due - Date.now())} · ticks itself off when it happens` : left(tk.due - Date.now()))),
            h('span', { class: 'nb-acts' },
              h('button', { class: `btn small ${tk.ready ? 'primary' : trackable(tk) ? 'ghost' : 'primary'}`, disabled: trackable(tk) && !tk.ready, title: tk.ready ? 'Collect your reward' : trackable(tk) ? 'This one ticks itself off once it really happens' : 'It happened: tick it off', onclick: () => {
                let r; app.commit((s) => { r = completeTask(app.idx, s, tk.id); }, 'tasks');
                if (r?.ok) { sfx('level'); toast(`${r.note} You got ${r.items.map(([id, n]) => `${n}× ${itemInfo(app.idx, id)?.name ?? id}`).join(', ') || 'a thank-you'}.`, 'ok'); }
                paint(); renderHud();
              } }, tk.ready ? '🎁 Collect' : '✓ Done'),
              h('button', { class: 'btn small ghost', title: 'Not this time', onclick: () => { app.commit((s) => { denyTask(app.idx, s, tk.id); }, 'tasks'); sfx('back'); paint(); renderHud(); } }, '✕'))))) :
            h('p', { class: 'nb-empty' }, 'Nothing yet. When your creatures want something (a berry, somewhere to go, something to do) it’s written down here.'),
          h('p', { class: 'nb-foot' }, 'Tick one off once it’s really happened. Each one waits a day to a week or so.'));
      };
      paint();
      return h('div', { class: 'col' }, body, h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close() }, 'Close')));
    }, { wide: true });
  }
  // a new wish from someone you're not looking at: a little dot flies from them to the Tasks button
  function onTasks(added) {
    renderHud();
    const btn = hudTR.querySelector('.task-btn');
    for (const tk of added) {
      if ((selected === tk.uid && !tk.chat) || !btn) continue;
      const b = yard.actorBox(tk.uid);
      const r = canvas.getBoundingClientRect(), to = btn.getBoundingClientRect();
      const sx = b ? r.left + ((b.x0 + b.x1) / 2) * (r.width / (canvas.width || 1)) : r.left + r.width / 2, sy = b ? r.top + b.y0 * (r.height / (canvas.height || 1)) : r.top + r.height / 2;
      const dot = h('div', { class: 'task-dot', 'aria-hidden': 'true' });
      Object.assign(dot.style, { left: `${sx}px`, top: `${sy}px` });
      document.body.append(dot);
      requestAnimationFrame(() => requestAnimationFrame(() => { dot.style.transform = `translate(${to.left + to.width - 8 - sx}px, ${to.top + 4 - sy}px) scale(.6)`; dot.style.opacity = '0.9'; }));
      setTimeout(() => { dot.remove(); btn.classList.remove('bump'); void btn.offsetWidth; btn.classList.add('bump'); }, 900);
    }
  }

  return {
    onTasks,
    el,
    mounted() {
      yard.resize();
      yard.materialize();
      yard.start();
      window.addEventListener('keydown', onKey);
      document.addEventListener('pointerdown', onDocDown, true);
      plotTimer = setInterval(() => {
        // weather a creature called up wears off
        const wc = app.save.weatherCall;
        if (wc && !calledWeather(app.save) && !wc.ended) { app.commit((s) => { if (s.weatherCall) s.weatherCall.ended = true; }, 'weather', { quiet: true }); yard.setWeather(yardWeatherSetting(app.save)); renderHud(); }
        syncPlots(); if (area !== 'yard') { renderPanel(); renderHud(); } if (Math.random() < 0.5) weatherReact(); }, 30000);
      setTimeout(weatherReact, 2500);
      setTimeout(() => intro.classList.add('done'), 900);
      canvas.focus({ preventScroll: true });
    },
    update,
    art: () => {},
    tick: () => { syncActors(); syncPlots(); renderPanel(); },
    dispose() { stopMovie(); inviteEl?.remove(); document.removeEventListener('fullscreenchange', onFsChange); if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {}); yard.destroy(); talk.destroy(); clearInterval(plotTimer); window.removeEventListener('keydown', onKey); document.removeEventListener('pointerdown', onDocDown, true); },
  };
}
