import { chooseBall } from '../../../../shared/ui/ballPicker.js';
import { ballIcon } from '../../../../shared/ui/capsuleArt.js';
// Boxes: storage grid on a biome wallpaper, the party column, and the summary panel.
import { h, mount, toast, promptDialog, confirmDialog, dialog, chooseDialog, hpBar, typeChip } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { BIOME_IDS, BIOME_INFO } from '../../../../shared/ui/biomes.js';
import { wallpaperChoices, wallpaperStyle, boxWallpaper } from '../../../../shared/ui/wallpapers.js';
import { creatureSummary } from '../../../../shared/ui/summary.js';
import { sfx } from '../../../../shared/ui/audio.js';
import { playTransfer, transferLine } from '../../../../shared/ui/transfer.js';
import {
  boxContents, party, moveCreature, displayName, calcStats, atKind, createCreature, addCreature, firstFreeBoxSlot,
  releaseCreature, capsuleName, readPkm, matchSpecies, pkhexToCreature, alreadyImported,
} from '../../../../shared/engine/index.js';

const COLS = 6, ROWS = 5, SLOTS = COLS * ROWS;

/** Pick a wallpaper for one box (or all of them). */
async function chooseWallpaper(app, current) {
  const choices = wallpaperChoices(Object.keys(app.textures ?? {}));
  let applyAll = false;
  const result = await dialog('Box wallpaper', (close) => {
    const groups = [...new Set(choices.map((c) => c.group))];
    return h('div', { class: 'col' },
      groups.map((g) => [
        h('h3', { class: 'wall-group' }, g),
        h('div', { class: 'wall-grid' }, choices.filter((c) => c.group === g).map((c) => {
          const st = wallpaperStyle(c.id, app.textures, app.bank.version);
          return h('button', { class: `wall-pick ${st.url ? '' : 'wp-clean'} ${st.pixel ? 'pixel' : ''}`, 'aria-pressed': c.id === current ? 'true' : 'false', style: st.url ? { backgroundImage: `url(${st.url})` } : null, onclick: () => close(c.id) },
            h('span', null, c.label));
        })),
      ]),
      h('p', { class: 'micro dim' }, 'Your own pictures: put PNGs in textures/boxes (any name, 216×180 or larger) and they appear under “Yours”.'),
      h('div', { class: 'actions' },
        h('label', { class: 'check grow' }, h('input', { type: 'checkbox', onchange: (e) => { applyAll = e.target.checked; } }), 'Use for every box'),
        h('button', { class: 'btn', onclick: () => close(null) }, 'Cancel')));
  }, { wide: true });
  return result ? { id: result, all: applyAll } : null;
}

export function boxesView(app) {
  let box = 0;
  let selected = null;
  const el = h('div', { class: 'boxes' });
  const dragData = (ev) => ev.dataTransfer.getData('text/uid');

  function dropOn(target) {
    return {
      ondragover: (ev) => { ev.preventDefault(); ev.currentTarget.classList.add('drop'); },
      ondragleave: (ev) => ev.currentTarget.classList.remove('drop'),
      ondrop: (ev) => {
        ev.preventDefault();
        ev.currentTarget.classList.remove('drop');
        const uid = dragData(ev);
        if (!uid) return;
        move(uid, target);
      },
    };
  }

  function move(uid, to) {
    const c = app.save.creatures[uid];
    if (!c) return;
    if (c.location.kind === 'phone' || c.location.kind === 'capsule') { toast(`${displayName(app.idx, c)} is away right now.`, 'err'); return; }
    const fromEl = el.querySelector(`[data-uid="${uid}"]`);
    const fromRect = fromEl?.getBoundingClientRect();
    const sprite = fromEl?.querySelector('canvas');
    const before = c.location.kind;
    let result;
    app.commit((save) => { result = moveCreature(save, uid, { ...to }, app.idx.ds.rules.partySize); }, 'move');
    if (result && !result.ok) { toast(result.error, 'err'); return; }
    const now = app.save.creatures[uid]?.location ?? to;
    const name = displayName(app.idx, c);
    const kind = now.kind === 'ranch' ? 'ranch' : now.kind === 'party' && before !== 'party' ? 'party' : 'box';
    const say = kind === 'box' && before === 'box' ? '' : transferLine(kind, name, { box: app.save.boxes[now.box]?.name });
    const tint = app.idx.types.get(app.idx.species.get(c.speciesId)?.types?.[0])?.color ?? '#9fe8ff';
    const toEl = now.kind === 'ranch' ? null : el.querySelector(`[data-uid="${uid}"]`);
    const toTarget = toEl ?? (now.kind === 'box' ? el.querySelector('.box-name')?.getBoundingClientRect() : null);
    if (!fromRect) { sfx('blip'); return; }
    playTransfer({ from: fromRect, to: toTarget, mode: now.kind === 'ranch' ? 'beacon' : 'move', tint, say, spriteEl: sprite?.parentElement ?? null });
    if (say) app.say(say);
  }

  /** Say goodbye: confirm, then they go up as a beacon and out into the wild. */
  async function release(uid) {
    const c = app.save.creatures[uid];
    if (!c) return;
    if (c.location.kind === 'phone' || c.location.kind === 'capsule') { toast(`${displayName(app.idx, c)} is away. Releasing only works here at the PC.`, 'err'); return; }
    const name = displayName(app.idx, c);
    const ok = await dialog(`Release ${name}?`, (close) => h('div', { class: 'col center-items' },
      spriteCanvas(app.bank, c.speciesId, { scale: 3, animate: true }),
      h('p', { class: 'center' }, `${name} will return to the wild for good. Their memories leave with them, and this can’t be undone.`),
      h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(false) }, 'Keep them'), h('button', { class: 'btn danger', onclick: () => close(true) }, 'Release'))));
    if (!ok) return;
    const fromEl = el.querySelector(`[data-uid="${uid}"]`);
    const rect = fromEl?.getBoundingClientRect();
    const art = h('span', null, spriteCanvas(app.bank, c.speciesId, { scale: 2 }));
    app.commit((s) => releaseCreature(s, uid), 'release');
    if (selected === uid) selected = null;
    render();
    const lines = [`${name} looked back once, then headed off into the wild.`, `${name} waved goodbye.`, `${name} is free. Take care out there!`];
    const say = lines[Math.floor(Math.random() * lines.length)];
    if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: '#ffffff', say });
    app.say(say);
  }

  /** Right-click a creature for the quick actions. */
  function quickMenu(ev, c) {
    ev.preventDefault();
    document.querySelector('.quick-menu')?.remove();
    const away = c.location.kind === 'phone' || c.location.kind === 'capsule';
    const item = (label, fn, cls = '') => h('button', { class: cls, onclick: () => { menu.remove(); fn(); } }, label);
    const menu = h('div', { class: 'quick-menu', style: { left: `${ev.clientX}px`, top: `${ev.clientY}px` } },
      h('div', { class: 'qm-title' }, displayName(app.idx, c)),
      item('Summary', () => { selected = c.uid; render(); }),
      !away && c.location.kind !== 'party' ? item('Add to party', () => move(c.uid, { kind: 'party' })) : null,
      !away && c.location.kind !== 'ranch' ? item('Send to free range', () => move(c.uid, { kind: 'ranch' })) : null,
      !away ? item('Release…', () => release(c.uid), 'danger') : null);
    document.body.append(menu);
    const close = (e) => { if (!menu.contains(e.target)) { menu.remove(); window.removeEventListener('pointerdown', close, true); } };
    setTimeout(() => window.addEventListener('pointerdown', close, true), 0);
  }

  function slotButton(c, extra = {}) {
    const btn = h('button', {
      class: `slot ${c && selected === c.uid ? 'sel' : ''}`, 'data-uid': c?.uid ?? null,
      draggable: !!c, title: c ? `${displayName(app.idx, c)}  Lv. ${c.level}` : 'Empty',
      onclick: () => { if (c) { selected = c.uid; sfx('move'); render(); } },
      ondragstart: (ev) => { ev.dataTransfer.setData('text/uid', c.uid); ev.dataTransfer.effectAllowed = 'move'; },
      oncontextmenu: (ev) => { if (c) quickMenu(ev, c); },
      ...extra,
    }, c ? spriteCanvas(app.bank, c.speciesId, { scale: 1 }) : null);
    return btn;
  }

  function partyColumn() {
    const p = party(app.save);
    const size = app.idx.ds.rules.partySize;
    const away = app.save ? Object.values(app.save.creatures).filter((c) => c.location.kind === 'phone' || c.location.kind === 'capsule') : [];
    return h('section', { class: 'panel party-col', 'aria-label': 'Party' },
      h('h2', null, 'Party'),
      h('div', { class: 'party-list' }, Array.from({ length: size }, (_, i) => {
        const c = p[i];
        const stats = c ? calcStats(app.idx, c) : null;
        return h('div', { class: `party-row ${c && selected === c.uid ? 'sel' : ''}`, 'data-uid': c?.uid ?? null, ...dropOn({ kind: 'party', slot: i }),
          draggable: !!c, ondragstart: (ev) => c && ev.dataTransfer.setData('text/uid', c.uid),
          onclick: () => { if (c) { selected = c.uid; render(); } }, oncontextmenu: (ev) => { if (c) quickMenu(ev, c); } },
        c ? [spriteCanvas(app.bank, c.speciesId, { scale: 1 }), h('div', { class: 'grow' },
          h('div', { class: 'row' }, ballIcon(c.ball, 12), h('span', { class: 'grow ell' }, displayName(app.idx, c)), h('span', { class: 'dim' }, `Lv${c.level}`)),
          hpBar(c.hp ?? stats.hp, stats.hp))] : h('span', { class: 'faint' }, 'Empty'));
      })),
      h('div', { class: 'ranch-drop', ...dropOn({ kind: 'ranch' }) }, `Drop here to let them roam free range (${atKind(app.save, 'ranch').length})`),
      h('div', { class: 'ranch-drop release-drop', ondragover: (ev) => { ev.preventDefault(); ev.currentTarget.classList.add('drop'); }, ondragleave: (ev) => ev.currentTarget.classList.remove('drop'),
        ondrop: (ev) => { ev.preventDefault(); ev.currentTarget.classList.remove('drop'); const uid = dragData(ev); if (uid) release(uid); } }, 'Drop here to release into the wild'),
      away.length ? h('div', { class: 'away' }, h('h2', null, 'Out and about'),
        away.map((c) => h('button', { class: 'away-row', onclick: () => { selected = c.uid; render(); } },
          spriteCanvas(app.bank, c.speciesId, { scale: 1 }),
          h('span', { class: 'grow ell' }, displayName(app.idx, c)),
          h('span', { class: 'dim' }, c.location.kind === 'phone' ? 'Phone' : capsuleName(app.save, c.location.tag))))) : null);
  }

  function boxPanel() {
    const b = app.save.boxes[box];
    const contents = boxContents(app.save, box, SLOTS);
    const count = contents.filter(Boolean).length;
    const wpId = boxWallpaper(b);
    const wp = wallpaperStyle(wpId, app.textures, app.bank.version);
    const wpLabel = wallpaperChoices(Object.keys(app.textures ?? {})).find((x) => x.id === wpId)?.label ?? 'Clean';
    const wall = h('div', { class: `wallpaper ${wp.url ? '' : 'wp-clean'} ${wp.dark ? 'wp-dark' : ''} ${wp.pixel ? 'pixel' : ''}`, style: wp.url ? { backgroundImage: `url(${wp.url})` } : null },
      h('div', { class: 'slots' }, contents.map((c, i) => slotButton(c, dropOn({ kind: 'box', box, slot: i })))));
    return h('section', { class: 'box-panel', 'aria-label': 'Box' },
      h('div', { class: 'box-head' },
        h('button', { class: 'btn icon', 'aria-label': 'Previous box', onclick: () => { box = (box + app.save.boxes.length - 1) % app.save.boxes.length; sfx('move'); render(); } }, '◀'),
        h('button', { class: 'box-name', title: 'Rename box', onclick: async () => {
          const name = await promptDialog('Rename box', 'Box name', b.name, { maxLength: 18 });
          if (name) app.commit((s) => { s.boxes[box].name = name.trim() || s.boxes[box].name; });
        } }, b.name),
        h('button', { class: 'btn icon', 'aria-label': 'Next box', onclick: () => { box = (box + 1) % app.save.boxes.length; sfx('move'); render(); } }, '▶')),
      wall,
      h('div', { class: 'row box-foot' },
        h('button', { class: 'btn', title: 'Change this box’s wallpaper', onclick: async () => {
          const pick = await chooseWallpaper(app, wpId);
          if (!pick) return;
          app.commit((s) => { for (const [i, bx] of s.boxes.entries()) if (pick.all || i === box) bx.wallpaper = pick.id; });
          sfx('blip');
        } }, `Wallpaper: ${wpLabel}`),
        h('label', { class: 'row', title: 'The scene this box’s creatures live in at the R.A.N.C.H.' }, h('span', { class: 'dim' }, 'Habitat'),
          h('select', { onchange: (e) => app.commit((s) => { s.boxes[box].biome = e.target.value; }) },
            BIOME_IDS.map((id) => h('option', { value: id, selected: id === b.biome }, BIOME_INFO[id].label)))),
        h('span', { class: 'spacer' }),
        h('span', { class: 'dim' }, `${count}/${SLOTS}`),
        h('button', { class: 'btn', onclick: () => { app.ranchHabitat = box; sfx('warp'); app.go('ranch'); } }, 'Visit in R.A.N.C.H.'),
        h('label', { class: 'btn', title: 'Bring creatures over from PKHeX (.pk8, .pb8, .pk9)' }, 'Import from PKHeX…',
          h('input', { type: 'file', class: 'hidden', multiple: true, accept: '.pk8,.pb8,.pk9,.ek8,.eb8,.ek9', onchange: (e) => { const f = [...(e.target.files ?? [])]; e.target.value = ''; if (f.length) importPkhex(f); } })),
        h('button', { class: 'btn', onclick: addDialog }, 'Add a creature')));
  }

  function summaryPanel() {
    const c = selected && app.save.creatures[selected];
    if (!c) {
      return h('aside', { class: 'panel summary-col' }, h('h2', null, 'Summary'),
        h('p', { class: 'dim' }, 'Pick a creature to see its stats, moves and memories. Drag creatures between boxes and the party. Visit a box in the R.A.N.C.H. to spend time with whoever lives there.'));
    }
    const away = c.location.kind === 'phone' || c.location.kind === 'capsule';
    const isPet = app.save.settings.petUid === c.uid && app.save.settings.petEnabled;
    const actions = h('div', { class: 'row wrap' },
      h('button', { class: 'btn', title: 'Which capsule picture this creature shows', onclick: async () => {
        const t = await chooseBall(c.ball);
        if (t != null) { app.commit((s) => { s.creatures[c.uid].ball = t; }); sfx('blip'); }
      } }, ballIcon(c.ball, 16, 'closed'), ' Capsule'),
      away ? h('p', { class: 'dim' }, c.location.kind === 'phone' ? 'Walking with your phone. Return it from the phone app.' : `In ${capsuleName(app.save, c.location.tag)}. Place the capsule on the dock to bring it home.`) : [
        c.location.kind !== 'party' ? h('button', { class: 'btn', onclick: () => move(c.uid, { kind: 'party' }) }, 'Add to party') : null,
        c.location.kind !== 'ranch' ? h('button', { class: 'btn', onclick: () => move(c.uid, { kind: 'ranch' }) }, 'Send to ranch') : null,
        c.location.kind !== 'box' ? h('button', { class: 'btn', onclick: () => { const to = firstFreeBoxSlot(app.save); if (to) move(c.uid, to); else toast('Every box is full.', 'err'); } }, 'Put in a box') : null,
        h('button', { class: `btn ${isPet ? 'signal' : ''}`, onclick: () => app.commit((s) => { s.settings.petUid = c.uid; s.settings.petEnabled = !isPet; }) }, isPet ? 'Buddy is on the desktop' : 'Make desktop buddy'),
        h('button', { class: 'btn', onclick: async () => {
          const name = await promptDialog('Nickname', 'Leave empty to use the species name', c.nickname, { maxLength: 12 });
          if (name != null) app.commit((s) => { s.creatures[c.uid].nickname = name.trim().slice(0, 12); });
        } }, 'Rename'),
        h('button', { class: 'btn danger', onclick: () => release(c.uid) }, 'Release'),
      ]);
    return h('aside', { class: 'panel summary-col scroll' }, creatureSummary(app.idx, app.bank, c, { actions }));
  }

  async function addDialog() {
    const idx = app.idx;
    const result = await dialog('Add a creature', (close) => {
      const sp = h('select', null, idx.ds.species.map((s) => h('option', { value: s.id }, `#${s.no} ${s.name}`)));
      const lv = h('input', { type: 'number', value: 5, min: 1, max: idx.ds.rules.maxLevel });
      const nick = h('input', { type: 'text', maxLength: 12, placeholder: 'optional' });
      const preview = h('div', { class: 'pedestal-sm' });
      const paint = () => mount(preview, spriteCanvas(app.bank, sp.value, { scale: 3, animate: true }), h('div', { class: 'row' }, idx.species.get(sp.value)?.types.map((t) => typeChip(idx, t))));
      sp.addEventListener('change', paint);
      paint();
      return h('div', { class: 'col' },
        h('p', { class: 'dim' }, 'Creates a creature from your Data Lab species list and puts it in the first free box slot.'),
        h('div', { class: 'row', style: { alignItems: 'flex-start' } }, preview,
          h('div', { class: 'col grow' },
            h('label', { class: 'field' }, h('span', null, 'Species'), sp),
            h('label', { class: 'field' }, h('span', null, 'Level'), lv),
            h('label', { class: 'field' }, h('span', null, 'Nickname'), nick))),
        h('div', { class: 'actions' },
          h('button', { class: 'btn', onclick: () => close(null) }, 'Cancel'),
          h('button', { class: 'btn primary', onclick: () => close({ sp: sp.value, level: Number(lv.value) || 5, nick: nick.value.trim() }) }, 'Add')));
    });
    if (!result) return;
    const c = createCreature(app.idx, result.sp, { level: result.level, nickname: result.nick, trainer: app.save.trainer?.name, metHow: 'Added at the terminal' });
    const spot = boxContents(app.save, box, SLOTS).findIndex((x) => !x);
    const loc = spot >= 0 ? { kind: 'box', box, slot: spot } : firstFreeBoxSlot(app.save);
    if (!loc) { toast('Every box is full.', 'err'); return; }
    app.commit((s) => { if (!s.creatures[c.uid]) addCreature(s, c, { ...loc }); });
    selected = c.uid;
    sfx('level');
  }

  /** PKHeX files → creatures in this box (or the next free one). Showdown sets never come back this way. */
  async function importPkhex(files) {
    const done = [], failed = [];
    for (const f of files) {
      const pk = readPkm(new Uint8Array(await f.arrayBuffer()), f.name);
      if (!pk.ok) { failed.push(`${f.name}: ${pk.error}`); continue; }
      if (pk.isEgg) { failed.push(`${f.name}: eggs can’t come over yet. Hatch it first.`); continue; }
      const dup = alreadyImported(app.save, pk);
      if (dup) { failed.push(`${f.name}: ${displayName(app.idx, dup)} already came over from this file.`); continue; }
      let { species } = matchSpecies(app.idx, pk);
      if (!species) {
        const pick = await chooseDialog(`Which species is ${pk.nickname || f.name}?`, app.idx.ds.species.map((sp) => ({ value: sp.id, label: `#${sp.no} ${sp.name}`, el: spriteCanvas(app.bank, sp.id, { scale: 1 }) })),
          { empty: 'Your data set has no species yet.' });
        if (!pick) { failed.push(`${f.name}: skipped (no species chosen).`); continue; }
        species = app.idx.species.get(pick);
      }
      const spot = boxContents(app.save, box, SLOTS).findIndex((x) => !x);
      const loc = spot >= 0 ? { kind: 'box', box, slot: spot } : firstFreeBoxSlot(app.save);
      if (!loc) { failed.push(`${f.name}: every box is full.`); break; }
      try {
        const { creature, notes } = pkhexToCreature(app.idx, pk, { species, trainer: app.save.trainer?.name, location: { ...loc } });
        app.commit((s) => { if (!s.creatures[creature.uid]) addCreature(s, creature, { ...loc }); }, 'import');
        done.push({ c: creature, notes, game: creature.origin?.game });
      } catch (err) { failed.push(`${f.name}: ${err.message}`); }
    }
    render();
    for (const [k, d] of done.entries()) {
      const slotEl = el.querySelector(`[data-uid="${d.c.uid}"]`);
      if (slotEl) setTimeout(() => playTransfer({ to: slotEl, mode: 'arrive', tint: app.idx.types.get(app.idx.species.get(d.c.speciesId)?.types?.[0])?.color, say: k === 0 ? transferLine('home', displayName(app.idx, d.c)) : '' }), k * 350);
    }
    if (done.length) selected = done[0].c.uid;
    await new Promise((r) => setTimeout(r, Math.min(2200, 900 + done.length * 350)));
    render();
    await dialog(done.length ? `${done.length} came over` : 'Nothing came over', (close) => h('div', { class: 'col' },
      done.map((d) => h('div', { class: 'row', style: { alignItems: 'flex-start' } },
        spriteCanvas(app.bank, d.c.speciesId, { scale: 2 }),
        h('div', { class: 'col grow', style: { gap: '4px' } },
          h('b', null, `${displayName(app.idx, d.c)} · Lv. ${d.c.level}${d.c.shiny ? ' ✦' : ''}`),
          h('span', { class: 'micro dim' }, `From ${d.game}. Trainer ${d.c.origin?.ot || '—'}.`),
          (d.c.memories ?? []).slice(0, 4).map((m) => h('span', { class: 'micro' }, `• ${m.text}`)),
          d.notes.length ? h('span', { class: 'micro err-text' }, d.notes.join(' ')) : null))),
      failed.length ? h('ul', { class: 'warn-list' }, failed.map((x) => h('li', null, x))) : null,
      h('p', { class: 'micro dim' }, 'Creatures can be sent to Showdown to battle, but Showdown sets never come back in — PKHeX files are the way in.'),
      h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: () => close() }, 'Done'))));
  }

  function render() {
    if (selected && !app.save.creatures[selected]) selected = null;
    mount(el, partyColumn(), boxPanel(), summaryPanel());
  }
  render();
  return { el, update: render, art: render };
}
