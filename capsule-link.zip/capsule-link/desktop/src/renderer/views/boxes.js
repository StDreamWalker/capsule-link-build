import { chooseBall } from '../../../../shared/ui/ballPicker.js';
import { ballIcon, creatureBall } from '../../../../shared/ui/capsuleArt.js';
// Boxes: storage grid on a biome wallpaper, the party column, and the summary panel.
import { h, mount, toast, promptDialog, confirmDialog, dialog, chooseDialog, hpBar, typeChip } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { BIOME_IDS, BIOME_INFO } from '../../../../shared/ui/biomes.js';
import { wallpaperChoices, wallpaperStyle, boxWallpaper } from '../../../../shared/ui/wallpapers.js';
import { creatureSummary } from '../../../../shared/ui/summary.js';
import { sfx, creatureCry } from '../../../../shared/ui/audio.js';
import { playTransfer, transferLine } from '../../../../shared/ui/transfer.js';
import { rememberDialog } from './memoryImport.js';
import { openJournal } from '../../../../shared/ui/journal.js';
import {
  boxContents, party, moveCreature, displayName, calcStats, atKind, createCreature, addCreature, firstFreeBoxSlot,
  releaseCreature, capsuleName, readPkm, matchSpecies, pkhexToCreature, alreadyImported, missingQuestions, applyAnswers, sameSave, linkSaveFriends, FRIEND_AT, toggleBuddy, isDesktopBuddy,
  exportPkm, exportPlan, refreshFromPkm, openGameSave, randomId,
  ballChoices, ballsForGame, reball,
} from '../../../../shared/engine/index.js';
import { browseSave, importTutorial, importNotice } from './saveBrowser.js';
import { openMoveTo, openTracker, whereLabel } from './moveTo.js';
import { openMoveSwap } from '../../../../shared/ui/moveSwap.js';

const COLS = 6, ROWS = 5, SLOTS = COLS * ROWS;

/** Pick a wallpaper for one box (or all of them). */
async function chooseWallpaper(app, current) {
  const choices = wallpaperChoices(Object.keys(app.textures ?? {}));
  let applyAll = false;
  const result = await dialog('Box wallpaper', (close) => {
    const groups = [...new Set(choices.map((c) => c.group))];
    return h('div', { class: 'col' },
      groups.map((g) => [
        h('h3', { class: 'wall-group' }, g),
        h('div', { class: 'wall-grid' }, choices.filter((c) => c.group === g).map((c) => {
          const st = wallpaperStyle(c.id, app.textures, app.bank.version);
          return h('button', { class: `wall-pick ${st.url ? '' : 'wp-clean'} ${st.pixel ? 'pixel' : ''}`, 'aria-pressed': c.id === current ? 'true' : 'false', style: st.url ? { backgroundImage: `url(${st.url})` } : null, onclick: () => close(c.id) },
            h('span', null, c.label));
        })),
      ]),
      h('p', { class: 'micro dim' }, 'Your own pictures: put PNGs in textures/boxes (any name, 216×180 or larger) and they appear under “Yours”.'),
      h('div', { class: 'actions' },
        h('label', { class: 'check grow' }, h('input', { type: 'checkbox', onchange: (e) => { applyAll = e.target.checked; } }), 'Use for every box'),
        h('button', { class: 'btn', onclick: () => close(null) }, 'Cancel')));
  }, { wide: true });
  return result ? { id: result, all: applyAll } : null;
}

export function boxesView(app) {
  let box = 0;
  let selected = null;
  const el = h('div', { class: 'boxes' });
  const dragData = (ev) => ev.dataTransfer.getData('text/uid');

  function dropOn(target) {
    return {
      ondragover: (ev) => { ev.preventDefault(); ev.currentTarget.classList.add('drop'); },
      ondragleave: (ev) => ev.currentTarget.classList.remove('drop'),
      ondrop: (ev) => {
        ev.preventDefault();
        ev.currentTarget.classList.remove('drop');
        const uid = dragData(ev);
        if (!uid) return;
        move(uid, target);
      },
    };
  }

  function move(uid, to) {
    const c = app.save.creatures[uid];
    if (!c) return;
    if (c.location.kind === 'phone' || c.location.kind === 'capsule') { toast(`${displayName(app.idx, c)} is away right now.`, 'err'); return; }
    const fromEl = el.querySelector(`[data-uid="${uid}"]`);
    const fromRect = fromEl?.getBoundingClientRect();
    const sprite = fromEl?.querySelector('canvas');
    const before = c.location.kind;
    let result;
    app.commit((save) => { result = moveCreature(save, uid, { ...to }, app.idx.ds.rules.partySize); }, 'move');
    if (result && !result.ok) { toast(result.error, 'err'); return; }
    const now = app.save.creatures[uid]?.location ?? to;
    const name = displayName(app.idx, c);
    const kind = now.kind === 'ranch' ? 'ranch' : now.kind === 'party' && before !== 'party' ? 'party' : 'box';
    const say = kind === 'box' && before === 'box' ? '' : transferLine(kind, name, { box: app.save.boxes[now.box]?.name });
    const tint = app.idx.types.get(app.idx.species.get(c.speciesId)?.types?.[0])?.color ?? '#9fe8ff';
    const toEl = now.kind === 'ranch' ? null : el.querySelector(`[data-uid="${uid}"]`);
    const toTarget = toEl ?? (now.kind === 'box' ? el.querySelector('.box-name')?.getBoundingClientRect() : null);
    if (!fromRect) { sfx('blip'); return; }
    playTransfer({ from: fromRect, to: toTarget, mode: now.kind === 'ranch' ? 'beacon' : 'move', tint, say, spriteEl: sprite?.parentElement ?? null });
    if (say) app.say(say);
  }

  /** Say goodbye: confirm, then they go up as a beacon and out into the wild. */
  async function release(uid) {
    const c = app.save.creatures[uid];
    if (!c) return;
    if (c.location.kind === 'phone' || c.location.kind === 'capsule') { toast(`${displayName(app.idx, c)} is away. Releasing only works here at the PC.`, 'err'); return; }
    const name = displayName(app.idx, c);
    const ok = await dialog(`Release ${name}?`, (close) => h('div', { class: 'col center-items' },
      spriteCanvas(app.bank, c, { scale: 3, animate: true }),
      h('p', { class: 'center' }, `${name} will return to the wild for good. Their memories leave with them, and this can’t be undone.`),
      h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => close(false) }, 'Keep them'), h('button', { class: 'btn danger', onclick: () => close(true) }, 'Release'))));
    if (!ok) return;
    const fromEl = el.querySelector(`[data-uid="${uid}"]`);
    const rect = fromEl?.getBoundingClientRect();
    const art = h('span', null, spriteCanvas(app.bank, c, { scale: 2 }));
    app.commit((s) => releaseCreature(s, uid), 'release');
    if (selected === uid) selected = null;
    render();
    const lines = [`${name} looked back once, then headed off into the wild.`, `${name} waved goodbye.`, `${name} is free. Take care out there!`];
    const say = lines[Math.floor(Math.random() * lines.length)];
    if (rect) playTransfer({ from: rect, mode: 'beacon', spriteEl: art, tint: '#ffffff', say });
    app.say(say);
  }

  /** Right-click a creature for the quick actions. */
  function quickMenu(ev, c) {
    ev.preventDefault();
    document.querySelector('.quick-menu')?.remove();
    const away = c.location.kind === 'phone' || c.location.kind === 'capsule';
    const item = (label, fn, cls = '') => h('button', { class: cls, onclick: () => { menu.remove(); fn(); } }, label);
    const menu = h('div', { class: 'quick-menu', style: { left: `${ev.clientX}px`, top: `${ev.clientY}px` } },
      h('div', { class: 'qm-title' }, displayName(app.idx, c)),
      item('Move to…', () => openMoveTo(app, c, { move }).then(() => render()), 'primary'),
      item('Summary', () => { selected = c.uid; render(); }),
      !c.egg ? item('Journal', () => openJournal({ idx: app.idx, bank: app.bank, save: app.save }, c)) : null,
      !away && c.location.kind !== 'party' ? item('Add to party', () => move(c.uid, { kind: 'party' })) : null,
      !away && c.location.kind !== 'ranch' ? item('Send to free range', () => move(c.uid, { kind: 'ranch' })) : null,
      // one place at a time: out on the desktop means not in the R.A.N.C.H. until they're called back
      !away && !c.egg ? (isDesktopBuddy(app.save, c.uid)
        ? item('Call back from the desktop', () => { app.commit((s) => { toggleBuddy(s, c.uid, false); }); sfx('warp'); app.say?.(`${displayName(app.idx, c)} came back in.`); render(); })
        : item('Send to the desktop', () => { let r; app.commit((s) => { r = toggleBuddy(s, c.uid, true); }); if (!r?.ok) { toast(r?.reason ?? 'Couldn’t do that.', 'err'); return; } sfx('warp'); app.say?.(`${displayName(app.idx, c)} hopped out onto your desktop.`); render(); })) : null,
      !c.egg ? item('Send to PKHeX…', () => exportOne(c.uid)) : null,
      !away ? item('Release…', () => release(c.uid), 'danger') : null);
    document.body.append(menu);
    { const rb = menu.getBoundingClientRect(); menu.style.top = `${Math.max(8, Math.min(ev.clientY, innerHeight - rb.height - 8))}px`; menu.style.left = `${Math.max(8, Math.min(ev.clientX, innerWidth - rb.width - 8))}px`; }
    const close = (e) => { if (!menu.contains(e.target)) { menu.remove(); window.removeEventListener('pointerdown', close, true); } };
    setTimeout(() => window.addEventListener('pointerdown', close, true), 0);
  }

  function slotButton(c, extra = {}) {
    const btn = h('button', {
      class: `slot ${c && selected === c.uid ? 'sel' : ''}`, 'data-uid': c?.uid ?? null,
      draggable: !!c, title: c ? `${displayName(app.idx, c)}  Lv. ${c.level}` : 'Empty',
      onclick: () => { if (c) { selected = c.uid; sfx('move'); render(); } },
      ondragstart: (ev) => { ev.dataTransfer.setData('text/uid', c.uid); ev.dataTransfer.effectAllowed = 'move'; },
      oncontextmenu: (ev) => { if (c) quickMenu(ev, c); },
      ...extra,
    }, c ? spriteCanvas(app.bank, c, { scale: 1 }) : null);
    return btn;
  }

  function partyColumn() {
    const p = party(app.save);
    const size = app.idx.ds.rules.partySize;
    const away = app.save ? Object.values(app.save.creatures).filter((c) => c.location.kind === 'phone' || c.location.kind === 'capsule') : [];
    return h('section', { class: 'panel party-col', 'aria-label': 'Party' },
      h('h2', null, 'Party'),
      h('div', { class: 'party-list' }, Array.from({ length: size }, (_, i) => {
        const c = p[i];
        const stats = c ? calcStats(app.idx, c) : null;
        return h('div', { class: `party-row ${c && selected === c.uid ? 'sel' : ''}`, 'data-uid': c?.uid ?? null, ...dropOn({ kind: 'party', slot: i }),
          draggable: !!c, ondragstart: (ev) => c && ev.dataTransfer.setData('text/uid', c.uid),
          onclick: () => { if (c) { selected = c.uid; render(); } }, oncontextmenu: (ev) => { if (c) quickMenu(ev, c); } },
        c ? [spriteCanvas(app.bank, c, { scale: 1 }), h('div', { class: 'grow' },
          h('div', { class: 'row' }, ballIcon(creatureBall(c), 12), h('span', { class: 'grow ell' }, displayName(app.idx, c)), h('span', { class: 'dim' }, `Lv${c.level}`)),
          hpBar(c.hp ?? stats.hp, stats.hp))] : h('span', { class: 'faint' }, 'Empty'));
      })),
      h('div', { class: 'ranch-drop', ...dropOn({ kind: 'ranch' }) }, `Drop here to let them roam free range (${atKind(app.save, 'ranch').length})`),
      h('div', { class: 'ranch-drop release-drop', ondragover: (ev) => { ev.preventDefault(); ev.currentTarget.classList.add('drop'); }, ondragleave: (ev) => ev.currentTarget.classList.remove('drop'),
        ondrop: (ev) => { ev.preventDefault(); ev.currentTarget.classList.remove('drop'); const uid = dragData(ev); if (uid) release(uid); } }, 'Drop here to release into the wild'),
      away.length ? h('div', { class: 'away' }, h('h2', null, 'Out and about'),
        away.map((c) => h('button', { class: 'away-row', onclick: () => { selected = c.uid; render(); } },
          spriteCanvas(app.bank, c, { scale: 1 }),
          h('span', { class: 'grow ell' }, displayName(app.idx, c)),
          h('span', { class: 'dim' }, c.location.kind === 'phone' ? 'Phone' : capsuleName(app.save, c.location.tag))))) : null);
  }

  function boxPanel() {
    const b = app.save.boxes[box];
    const contents = boxContents(app.save, box, SLOTS);
    const count = contents.filter(Boolean).length;
    const wpId = boxWallpaper(b);
    const wp = wallpaperStyle(wpId, app.textures, app.bank.version);
    const wpLabel = wallpaperChoices(Object.keys(app.textures ?? {})).find((x) => x.id === wpId)?.label ?? 'Clean';
    const wall = h('div', { class: `wallpaper ${wp.url ? '' : 'wp-clean'} ${wp.dark ? 'wp-dark' : ''} ${wp.pixel ? 'pixel' : ''}`, style: wp.url ? { backgroundImage: `url(${wp.url})` } : null },
      h('div', { class: 'slots' }, contents.map((c, i) => slotButton(c, dropOn({ kind: 'box', box, slot: i })))));
    return h('section', { class: 'box-panel', 'aria-label': 'Box' },
      h('div', { class: 'box-head' },
        h('button', { class: 'btn icon', 'aria-label': 'Previous box', onclick: () => { box = (box + app.save.boxes.length - 1) % app.save.boxes.length; sfx('move'); render(); } }, '◀'),
        h('button', { class: 'box-name', title: 'Rename box', onclick: async () => {
          const name = await promptDialog('Rename box', 'Box name', b.name, { maxLength: 18 });
          if (name) app.commit((s) => { s.boxes[box].name = name.trim() || s.boxes[box].name; });
        } }, b.name),
        h('button', { class: 'btn icon', 'aria-label': 'Next box', onclick: () => { box = (box + 1) % app.save.boxes.length; sfx('move'); render(); } }, '▶')),
      wall,
      h('div', { class: 'row box-foot' },
        h('button', { class: 'btn', title: 'Change this box’s wallpaper', onclick: async () => {
          const pick = await chooseWallpaper(app, wpId);
          if (!pick) return;
          app.commit((s) => { for (const [i, bx] of s.boxes.entries()) if (pick.all || i === box) bx.wallpaper = pick.id; });
          sfx('blip');
        } }, `Wallpaper: ${wpLabel}`),
        h('label', { class: 'row', title: 'The scene this box’s creatures live in at the R.A.N.C.H.' }, h('span', { class: 'dim' }, 'Habitat'),
          h('select', { onchange: (e) => app.commit((s) => { s.boxes[box].biome = e.target.value; }) },
            BIOME_IDS.map((id) => h('option', { value: id, selected: id === b.biome }, BIOME_INFO[id].label)))),
        h('span', { class: 'spacer' }),
        h('span', { class: 'dim' }, `${count}/${SLOTS}`),
        h('button', { class: 'btn', onclick: () => { app.ranchHabitat = box; sfx('warp'); app.go('ranch'); } }, 'Visit in R.A.N.C.H.'),
        h('button', { class: 'btn small', title: 'Everyone grouped by where they are, and anyone on their way somewhere', onclick: () => openTracker(app, { move }).then(() => render()) }, '📍 Where is everyone?'),
        h('span', { class: 'btn-group inline', role: 'group', 'aria-label': 'Bring someone in' },
          h('button', { class: 'btn small', title: 'Bring creatures over from PKHeX files (.pk1 to .pk9, any game from Red/Blue on)', onclick: async () => { if (await importTutorial(app, 'pkhex')) pickFile('.pk1,.pk2,.pk3,.pk4,.pk5,.pk6,.pk7,.ek3,.ek4,.ek5,.ek6,.ek7,.pk8,.pb8,.pk9,.ek8,.eb8,.ek9', true, importPkhex); } }, 'Import from PKHeX…'),
          h('button', { class: 'btn small', title: 'Open a game’s save file (Red/Blue/Yellow to Scarlet/Violet) and bring creatures over from its boxes — or put them back', onclick: async () => { if (await importNotice(app) && await importTutorial(app, 'save')) pickFile('', false, importSave); } }, 'Import from save…'),
          h('button', { class: 'btn small', title: 'No file? Answer what you remember (the way PKHeX shows it), and the search narrows down who they are', onclick: importMemory }, 'Import from memory…'))));
  }

  function summaryPanel() {
    const c = selected && app.save.creatures[selected];
    if (!c) {
      return h('aside', { class: 'panel summary-col' }, h('h2', null, 'Summary'),
        h('p', { class: 'dim' }, 'Pick a creature to see its stats, moves and memories. Drag creatures between boxes and the party. Visit a box in the R.A.N.C.H. to spend time with whoever lives there.'));
    }
    const away = c.location.kind === 'phone' || c.location.kind === 'capsule';
    const isPet = isDesktopBuddy(app.save, c.uid);
    const grp = (title, ...kids) => h('div', { class: 'btn-group' }, h('div', { class: 'btn-group-head' }, title), ...kids);
    const actions = h('div', { class: 'col', style: { gap: '8px' } },
      h('div', { class: 'col', style: { gap: '4px' } }, h('span', { class: 'dim' }, `📍 ${whereLabel(app, c)}`),
        h('button', { class: 'btn primary', title: 'Party, free range, a box, the desktop, a phone or a ball: everywhere they can go, in one place', onclick: () => openMoveTo(app, c, { move }).then(() => render()) }, away ? 'Bring them home…' : 'Move to…')),
      away ? h('p', { class: 'dim' }, c.location.kind === 'phone' ? 'Walking with your phone. Ask for them back with the button above, or return them from the phone app.' : `In ${capsuleName(app.save, c.location.tag)}. Place the capsule on the dock to bring it home.`)
        : grp('Where they live',
          c.location.kind !== 'party' ? h('button', { class: 'btn small', onclick: () => move(c.uid, { kind: 'party' }) }, 'Add to party') : null,
          c.location.kind !== 'ranch' ? h('button', { class: 'btn small', onclick: () => move(c.uid, { kind: 'ranch' }) }, 'Send to ranch') : null,
          c.location.kind !== 'box' ? h('button', { class: 'btn small', onclick: () => { const to = firstFreeBoxSlot(app.save); if (to) move(c.uid, to); else toast('Every box is full.', 'err'); } }, 'Put in a box') : null,
          h('button', { class: `btn small ${isPet ? 'signal' : ''}`, title: 'Up to six buddies can be out at once', onclick: () => { let r; app.commit((s) => { r = toggleBuddy(s, c.uid); }); if (!r.ok) toast(r.reason, 'err'); } }, isPet ? 'On the desktop (take back)' : 'Put on the desktop')),
      grp('About them',
        !c.egg ? h('button', { class: 'btn small primary', title: 'What you’ve found out about them: favourites, likes, dislikes, friends', onclick: () => openJournal({ idx: app.idx, bank: app.bank, save: app.save }, c) }, '📖 Journal') : null,
        c.location.kind !== 'capsule' ? h('button', { class: 'btn small', title: 'Move them into a ball from your bag (buy them at the market): only balls their game has, and they go home in it.', onclick: () => changeBall(c) }, ballIcon(creatureBall(c), 16, 'closed'), ' Swap ball') : null,
        !away ? h('button', { class: 'btn small', onclick: async () => {
          const name = await promptDialog('Nickname', 'Leave empty to use the species name', c.nickname, { maxLength: 12 });
          if (name != null) app.commit((s) => { s.creatures[c.uid].nickname = name.trim().slice(0, 12); });
        } }, 'Rename') : null,
        !c.egg ? h('button', { class: 'btn small', title: 'Save a .pk9 / .pk8 file PKHeX opens', onclick: () => exportOne(c.uid) }, 'Send to PKHeX…') : null),
      !away ? grp('Goodbye', h('button', { class: 'btn small danger', onclick: () => release(c.uid) }, 'Release')) : null);
    // a different ball, for coins (the summary's About section and the button above)
    // into a different ball: one you've bought at the market (only balls its own game has; it goes home in it)
    async function changeBall(cc) {
      const opts = ballChoices(app.save, cc), okGame = ballsForGame(cc);
      if (!opts.length) { toast(okGame ? `No balls in the bag that ${displayName(app.idx, cc)}’s game has. The market sells Poké Balls.` : 'No Poké Balls in the bag yet: the market sells them.', 'err'); return; }
      const pick = await chooseDialog(`A new ball for ${displayName(app.idx, cc)}`, opts.map((o) => ({ value: String(o.ball), label: o.name, detail: `${o.have} in the bag` })), { note: okGame ? 'Only balls its own game has: it goes back to its game in this ball.' : '' });
      if (!pick) return;
      let r; app.commit((s) => { r = reball(s, s.creatures[cc.uid], Number(pick)); }, 'reball');
      if (!r?.ok) { toast(r?.reason ?? 'Couldn’t do that.', 'err'); return; }
      sfx('blip'); toast(`${displayName(app.idx, cc)} is in their new ball.`, 'ok');
    }
    return h('aside', { class: 'panel summary-col scroll' }, creatureSummary(app.idx, app.bank, c, { actions, save: app.save, onChangeBall: changeBall, reballCost: 0, onMove: c.egg || away ? null : (slot) => openMoveSwap(app, c, slot).then((ok) => ok && render()) }));
  }

  // Adding a creature by hand lives in Settings → Debug → Add creatures.

  /**
   * Questions about a creature coming over (what the game never kept, and what made them theirs).
   * Resolves to the answers, null if skipped, or 'skip-all'.
   */
  function questionnaire(c, pk, { many = false } = {}) {
    const friends = Object.values(app.save.creatures).filter((o) => sameSave(c, o)).map((o) => ({ uid: o.uid, name: displayName(app.idx, o) }));
    const qs = missingQuestions(pk, { friends });
    const ans = { memories: [], friends: [] };
    const sp = app.idx.species.get(c.speciesId);
    const SIZE = [[30, 'Much smaller'], [80, 'A little smaller'], [128, 'About normal'], [180, 'A little bigger'], [230, 'Much bigger']];
    const input = (q) => {
      if (q.kind === 'choice') return h('select', { onchange: (e) => { ans[q.id] = e.target.value || undefined; } }, h('option', { value: '' }, 'I don’t remember'), q.options.map(([v, l]) => h('option', { value: v }, l)));
      if (q.kind === 'memories') return h('div', { class: 'col', style: { gap: '6px' } }, q.placeholders.map((ph, i) => h('input', { type: 'text', placeholder: ph, maxLength: 140, oninput: (e) => { ans.memories[i] = e.target.value; } })));
      if (q.kind === 'size') {
        const label = h('span', { class: 'micro dim' }, 'Not sure (leave as the game says)');
        return h('div', { class: 'col', style: { gap: '4px' } },
          h('input', { type: 'range', min: 0, max: 255, value: Number.isFinite(c.sizeScalar) ? c.sizeScalar : 128, oninput: (e) => { ans.size = Number(e.target.value); label.textContent = SIZE.reduce((best, s) => (Math.abs(s[0] - ans.size) < Math.abs(best[0] - ans.size) ? s : best))[1]; } }),
          h('div', { class: 'row micro dim quiz-scale' }, h('span', null, 'Tiny'), h('span', { class: 'spacer' }), h('span', null, 'Normal'), h('span', { class: 'spacer' }), h('span', null, 'Huge')), label);
      }
      if (q.kind === 'pitch') {
        const hear = () => creatureCry(sp, { ...c, cryPitch: Number.isFinite(ans.pitch) ? ans.pitch : c.cryPitch });
        return h('div', { class: 'row' },
          h('span', { class: 'micro dim' }, 'Deeper'),
          h('input', { type: 'range', class: 'grow', min: -6, max: 6, step: 0.5, value: 0, onchange: (e) => { ans.pitch = Number(e.target.value); hear(); } }),
          h('span', { class: 'micro dim' }, 'Higher'),
          h('button', { class: 'btn small', type: 'button', onclick: hear }, 'Hear'));
      }
      if (q.kind === 'friends') return h('div', { class: 'chip-row' }, q.options.map(([uid, name]) => h('button', { type: 'button', class: 'chip-toggle', onclick: (e) => {
        const on = ans.friends.includes(uid); ans.friends = on ? ans.friends.filter((x) => x !== uid) : [...ans.friends, uid]; e.currentTarget.classList.toggle('on', !on);
      } }, name)));
      return h('input', { type: 'text', placeholder: q.placeholder ?? '', maxLength: 140, oninput: (e) => { ans[q.id] = e.target.value; } });
    };
    const groups = [...new Set(qs.map((q) => q.group))];
    return dialog(`Tell us about ${displayName(app.idx, c)}`, (close) => h('div', { class: 'col quiz' },
      h('div', { class: 'row' }, spriteCanvas(app.bank, c, { scale: 2 }), h('p', { class: 'dim' }, `${c.origin?.game ?? 'Games'} only keep so much. Tell us what you remember, and it becomes part of who they are here: their memories, their voice, their size, their quirks${pk.missing?.includes('when') ? ', and when you met' : ''}. Skip anything you don’t know.`)),
      groups.map((g) => h('fieldset', { class: 'quiz-group' }, h('legend', null, g),
        qs.filter((q) => q.group === g).map((q) => h('div', { class: 'field' }, h('span', null, q.ask), input(q))))),
      h('div', { class: 'actions' },
        many ? h('button', { class: 'btn ghost', onclick: () => close('skip-all') }, 'Skip for all the rest') : null,
        h('button', { class: 'btn', onclick: () => close(null) }, 'Skip'),
        h('button', { class: 'btn primary', onclick: () => close(ans) }, 'Save their story'))));
  }

  /** Import from memory: the questionnaire, then they arrive in this box. */
  async function importMemory() {
    const spot = boxContents(app.save, box, SLOTS).findIndex((x) => !x);
    const loc = spot >= 0 ? { kind: 'box', box, slot: spot } : firstFreeBoxSlot(app.save);
    if (!loc) { toast('Every box is full.', 'err'); return; }
    const out = await rememberDialog(app, { location: { ...loc } });
    if (!out) return;
    const { creature, notes } = out;
    app.commit((s) => { addCreature(s, creature, { ...loc }); }, 'import');
    selected = creature.uid;
    render();
    const slotEl = el.querySelector(`[data-uid="${creature.uid}"]`);
    if (slotEl) playTransfer({ to: slotEl, mode: 'arrive', tint: app.idx.types.get(app.idx.species.get(creature.speciesId)?.types?.[0])?.color, say: transferLine('home', displayName(app.idx, creature)) });
    if (notes.length) setTimeout(() => toast(notes.join(' '), 'ok'), 1600);
  }

  /** A creature → a PKHeX file (with a word about what doesn't fit in one). */
  async function exportOne(uid) {
    const c = app.save.creatures[uid];
    const plan = exportPlan(app.idx, c);
    if (!plan.ok) { toast(plan.reason, 'err'); return; }
    const name = displayName(app.idx, c);
    if (!app.save.settings?.pkExportWarned) {
      const ok = await confirmDialog(`Send ${name} to PKHeX`, `PKHeX files only hold what the games keep. ${name}’s memories here, their mood, journal, voice and friends don’t fit in one, so they won’t travel with the file. They aren’t lost: ${name} stays here too, and if you bring this same file back in, we’ll recognise them and keep all of it.`, { ok: 'Save the file' });
      if (!ok) return;
      app.commit((s) => { s.settings.pkExportWarned = true; }, 'settings', { quiet: true });
    }
    const r = exportPkm(app.idx, app.save.creatures[uid]);
    if (!r.ok) { toast(r.error, 'err'); return; }
    app.commit((s) => { const x = s.creatures[uid]; x.pk = { ...(x.pk ?? {}), exported: r.ident, ...(x.pk?.raw ? {} : { pid: r.ident.pid, ec: r.ident.ec }) }; }, 'export', { quiet: true });
    const blob = new Blob([r.bytes], { type: 'application/octet-stream' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = r.name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    sfx('access');
    toast(`Saved ${r.name}.${r.notes.length ? ` ${r.notes.join(' ')}` : ''}`, 'ok');
  }

  /** PKHeX files → creatures in this box (or the next free one). Showdown sets never come back this way. */
  async function importPkhex(files) {
    const items = [];
    for (const f of files) items.push({ name: f.name, pk: readPkm(new Uint8Array(await f.arrayBuffer()), f.name) });
    return importPks(items);
  }
  /** Bring read creatures in ([{ name, pk }]); returns { arrived: [indices] }. */
  async function importPks(items, { fromSave = null } = {}) {
    const done = [], failed = [], arrived = [];
    let skipAsk = false;
    for (const [i, { name: fname, pk }] of items.entries()) {
      const f = { name: fname };
      if (!pk.ok) { failed.push(`${f.name}: ${pk.error}`); continue; }
      if (pk.isEgg) { failed.push(`${f.name}: eggs can’t come over yet. Hatch it first.`); continue; }
      const dup = alreadyImported(app.save, pk);
      if (dup && dup.location?.kind === 'game') {
        // back from the game they were put into: home again, with everything they remember
        const spot0 = boxContents(app.save, box, SLOTS).findIndex((x) => !x);
        const loc0 = spot0 >= 0 ? { kind: 'box', box, slot: spot0 } : firstFreeBoxSlot(app.save);
        if (!loc0) { failed.push(`${f.name}: every box is full.`); break; }
        app.commit((s) => { const x = s.creatures[dup.uid]; x.location = { ...loc0 }; refreshFromPkm(app.idx, x, pk); }, 'import');
        done.push({ c: app.save.creatures[dup.uid], notes: ['Back home: they remember everything from before.'], game: fromSave ?? dup.origin?.game });
        arrived.push(i);
        continue;
      }
      if (dup) {
        // the same creature, back from PKHeX: take the file's changes, keep everything that lives here
        const name = displayName(app.idx, dup);
        if (!(await confirmDialog(`${name} is back`, `${name} already lives here (this file is theirs). Update them from the file? Their memories, mood, journal and friends stay as they are.`, { ok: 'Update them' }))) { failed.push(`${f.name}: left as is (${name} is already here).`); continue; }
        let changed = [];
        app.commit((s) => { changed = refreshFromPkm(app.idx, s.creatures[dup.uid], pk); }, 'import');
        toast(changed.length ? `${name} updated: ${changed.join(', ')}.` : `${name} is unchanged.`, 'ok');
        arrived.push(i);
        continue;
      }
      let { species } = matchSpecies(app.idx, pk);
      if (!species) {
        const pick = await chooseDialog(`Which species is ${pk.nickname || f.name}?`, app.idx.ds.species.map((sp) => ({ value: sp.id, label: `#${sp.no} ${sp.name}`, el: spriteCanvas(app.bank, sp.id, { scale: 1 }) })),
          { empty: 'Your data set has no species yet.' });
        if (!pick) { failed.push(`${f.name}: skipped (no species chosen).`); continue; }
        species = app.idx.species.get(pick);
      }
      const spot = boxContents(app.save, box, SLOTS).findIndex((x) => !x);
      const loc = spot >= 0 ? { kind: 'box', box, slot: spot } : firstFreeBoxSlot(app.save);
      if (!loc) { failed.push(`${f.name}: every box is full.`); break; }
      try {
        const { creature, notes } = pkhexToCreature(app.idx, pk, { species, trainer: app.save.trainer?.name, location: { ...loc } });
        if (fromSave && pk.gb) creature.origin.game = fromSave;
        // ask the trainer about what the game never kept (memories, voice, size, quirks, old friends)
        if (pk.old) notes.push(`${creature.origin?.game ?? 'This game'} didn’t keep everything newer games do, so some details were filled in simply.`);
        if (!skipAsk) {
          const answers = await questionnaire(creature, pk, { many: items.length > 1 });
          if (answers === 'skip-all') skipAsk = true;
          else if (answers) applyAnswers(creature, pk, answers);
        }
        app.commit((s) => {
          // never drop someone silently: a clashing id gets a new one
          while (s.creatures[creature.uid]) creature.uid = randomId(8);
          addCreature(s, creature, { ...loc });
          // teammates from the same save know each other; the ones named as friends stay friends
          linkSaveFriends(s, s.creatures[creature.uid], { friendAt: FRIEND_AT, nameOf: (x) => displayName(app.idx, x) });
        }, 'import');
        done.push({ c: creature, notes, game: creature.origin?.game });
        arrived.push(i);
      } catch (err) { failed.push(`${f.name}: ${err.message}`); }
    }
    render();
    for (const [k, d] of done.entries()) {
      const slotEl = el.querySelector(`[data-uid="${d.c.uid}"]`);
      if (slotEl) setTimeout(() => playTransfer({ to: slotEl, mode: 'arrive', tint: app.idx.types.get(app.idx.species.get(d.c.speciesId)?.types?.[0])?.color, say: k === 0 ? transferLine('home', displayName(app.idx, d.c)) : '' }), k * 350);
    }
    if (done.length) selected = done[0].c.uid;
    await new Promise((r) => setTimeout(r, Math.min(2200, 900 + done.length * 350)));
    render();
    await dialog(done.length ? `${done.length} came over` : 'Nothing came over', (close) => h('div', { class: 'col' },
      done.map((d) => h('div', { class: 'row', style: { alignItems: 'flex-start' } },
        spriteCanvas(app.bank, d.c.speciesId, { scale: 2 }),
        h('div', { class: 'col grow', style: { gap: '4px' } },
          h('b', null, `${displayName(app.idx, d.c)} · Lv. ${d.c.level}${d.c.shiny ? ' ✦' : ''}`),
          h('span', { class: 'micro dim' }, `From ${d.game}. Trainer ${d.c.origin?.ot || '—'}.`),
          (d.c.memories ?? []).slice(0, 4).map((m) => h('span', { class: 'micro' }, `• ${m.text}`)),
          d.notes.length ? h('span', { class: 'micro err-text' }, d.notes.join(' ')) : null))),
      failed.length ? h('ul', { class: 'warn-list' }, failed.map((x) => h('li', null, x))) : null,
      h('p', { class: 'micro dim' }, 'Creatures can be sent to Showdown to battle, but Showdown sets never come back in — PKHeX files are the way in.'),
      h('div', { class: 'actions' }, h('button', { class: 'btn primary', onclick: () => close() }, 'Done'))));
    return { arrived };
  }

  /** A game's save file: browse its boxes, bring creatures over or put them back. */
  async function importSave(file) {
    const bytes = new Uint8Array(await file.arrayBuffer());
    const sav = openGameSave(bytes, file.name);
    if (!sav.ok) { toast(sav.error, 'err'); return; }
    sfx('access');
    await browseSave(app, sav, file.name, { onBring: (items, o) => importPks(items, o), reopen: (romhack) => openGameSave(bytes, file.name, { romhack }) });
    render();
  }
  const pickFile = (accept, multiple, fn) => { const i = h('input', { type: 'file', class: 'hidden', accept, multiple }); i.onchange = () => { const f = [...(i.files ?? [])]; if (f.length) fn(multiple ? f : f[0]); }; document.body.append(i); i.click(); setTimeout(() => i.remove(), 60000); };

  function render() {
    if (selected && !app.save.creatures[selected]) selected = null;
    mount(el, partyColumn(), boxPanel(), summaryPanel());
  }
  render();
  return { el, update: render, art: render };
}
