// The PokéAtlas on the PC: the whole atlas, and the spot it hands the app ("Use this spot") is where wild
// battles here look when you choose "Where you are".
import { toast } from '../../../../shared/ui/dom.js';
import { atlasApp } from '../../../../shared/ui/atlasApp.js';
import { atlasTableAt, tableLine, atlasProfileFor } from '../../../../shared/atlas/scan.js';
import { h, mount } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { feelPlace, party as partyOf } from '../../../../shared/engine/index.js';

/** Scan a spot and keep it as the PC's atlas spot. */
export async function setAtlasSpot(app, { lat, lon, radiusKm = 1.5, label = '' }) {
  const table = await atlasTableAt(lat, lon, { radiusKm: Math.min(3, radiusKm || 1.5), label });
  app.commit((s) => { s.settings.atlasSpot = { lat: table.lat, lon: table.lon, radiusKm: table.radiusKm, label: table.label, at: Date.now(), table }; }, 'settings', { quiet: true });
  return table;
}

export function atlasView(app) {
  const A = atlasApp({
    current: () => app.save.settings?.atlasSpot ?? null,
    start: () => app.save.settings?.atlasSpot ?? (Number.isFinite(app.save.sky?.lat) ? { lat: app.save.sky.lat, lon: app.save.sky.lon } : null),
    onSpot: async (spot) => {
      try { const t = await setAtlasSpot(app, spot); toast(`Wild battles here now look around ${tableLine(t)}.`, 'ok'); }
      catch (e) { toast(`Couldn’t read that spot: ${e.message}`, 'err'); }
    },
    onClear: () => app.commit((s) => { delete s.settings.atlasSpot; }, 'settings', { quiet: true }),
    note: 'Tap the map to scan anywhere on Earth. “Use this spot” makes it where wild battles look (Battle Link → Where → 📍 Where you are).',
  });
  // how your party would feel about the spot (just a guess: they aren't really there)
  const strip = h('div', { class: 'atlas-feel' });
  const paintFeel = () => {
    const t = app.save.settings?.atlasSpot?.table;
    const party = partyOf(app.save).filter((c) => !c.egg);
    if (!t || !party.length) { mount(strip); return; }
    mount(strip, h('span', { class: 'micro dim' }, `If your party were at ${t.label}:`), party.map((c) => {
      const sp = app.idx.species.get(c.formId ?? c.speciesId) ?? app.idx.species.get(c.speciesId);
      const r = feelPlace(app.idx, JSON.parse(JSON.stringify(c)), t, atlasProfileFor(app.idx, sp), { mode: 'out' });
      return r ? h('span', { class: 'atlas-feel-one', title: r.line }, spriteCanvas(app.bank, c, { scale: 1 }), `${r.emoji} ${r.mood}`) : null;
    }));
  };
  A.el.insertBefore(strip, A.el.querySelector('.atlas-frame'));
  paintFeel();
  return { el: A.el, dispose: () => A.dispose(), update: () => { A.refresh(); paintFeel(); } };
}

/**
 * Where you are, for wild battles: the spot picked in the atlas, or else where the app knows you are (the town
 * set in Settings, this connection, or the phone's last walk). Read again when it's more than 45 minutes old
 * (the weather and the time of day change who's out). Null when there's nowhere to go on.
 */
export async function localTable(app) {
  const st = app.save.settings ?? {};
  const fresh = (t) => t && Date.now() - t.at < 45 * 60000;
  if (st.atlasSpot) {
    if (fresh(st.atlasSpot.table)) return st.atlasSpot.table;
    try { return await setAtlasSpot(app, st.atlasSpot); } catch { return st.atlasSpot.table ?? null; }
  }
  const sky = app.save.sky;
  if (!Number.isFinite(sky?.lat) || !Number.isFinite(sky?.lon)) return null;
  const old = st.atlasHere;
  if (fresh(old) && Math.abs(old.lat - sky.lat) < 0.01 && Math.abs(old.lon - sky.lon) < 0.01) return old;
  try {
    const t = await atlasTableAt(sky.lat, sky.lon, { radiusKm: 1.5, label: sky.place || '' });
    app.commit((s) => { s.settings.atlasHere = t; }, 'settings', { quiet: true });
    return t;
  } catch { return old ?? null; }
}
