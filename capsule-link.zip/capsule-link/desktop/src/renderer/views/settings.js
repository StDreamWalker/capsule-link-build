// Settings: trainer, sound, desktop buddy, textures and backups.
import { h, mount, toast, confirmDialog } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { setSound, sfx } from '../../../../shared/ui/audio.js';
import { displayName, list } from '../../../../shared/engine/index.js';
import { importSprites, spriteCoverage } from '../spriteImport.js';
import { runSetup } from '../setup.js';
import { extrasTool, spriteTool, trainerTool } from '../dataTools.js';
import { debugPanel } from './debugPanel.js';
import { updatesPanel } from '../updates.js';
import { playIntro } from '../../../../shared/ui/introShow.js';
import { normalizeBrand } from '../../../../shared/engine/index.js';

export function settingsView(app) {
  const body = h('div', { class: 'settings' });
  const tabsEl = h('div', { class: 'tabs settings-tabs', role: 'tablist' });
  const el = h('div', { class: 'settings-wrap' }, tabsEl, body);
  const set = (fn) => app.commit((s) => fn(s.settings), 'settings');
  let tab = settingsView.tab ?? 'general';
  const tools = {};
  let dbg = null;

  function render() {
    mount(tabsEl, [['general', 'General'], ['art', 'Data and art'], ['debug', 'Debug']].map(([k, l]) => h('button', { role: 'tab', 'aria-selected': tab === k ? 'true' : 'false', onclick: () => { tab = settingsView.tab = k; render(); } }, l)));
    if (tab === 'art') {
      tools.extras = tools.extras ?? extrasTool(app);
      tools.sprites = tools.sprites ?? spriteTool(app);
      tools.trainers = tools.trainers ?? trainerTool(app);
      mount(body, h('div', { class: 'col span-all art-tools' }, tools.sprites, tools.trainers, tools.extras,
        h('p', { class: 'micro dim' }, 'Species, moves, learnsets and natures: Settings → General → Bring in data and sprites, or the Data Lab’s Paste tab.')));
      return;
    }
    if (tab === 'debug') {
      dbg = dbg ?? debugPanel(app, render);
      dbg.update();
      mount(body, dbg.el);
      return;
    }
    renderGeneral();
  }

  function renderGeneral() {
    const el = body;
    const s = app.save.settings;
    const buddyOptions = list(app.save).filter((c) => !['phone', 'capsule'].includes(c.location.kind));
    const buddy = s.petUid && app.save.creatures[s.petUid];
    const textureCount = Object.keys(app.textures ?? {}).length;
    const b = normalizeBrand(app.dataset.brand);
    const setup = async (start) => {
      const host = h('div', { class: 'setup-overlay' });
      document.body.append(host);
      try { await runSetup(app, host, { start }); } finally { host.remove(); }
      app.refresh(); app.renderTop?.(); render();
    };
    mount(el,
      h('section', { class: 'panel col span-all' },
        h('h2', null, 'Names and setup'),
        h('p', { class: 'dim' }, `The apps call themselves “${b.app}”, carry ${b.creatures} in ${b.balls} and connect through ${b.company}. Change any of it — every screen, the phone and ID cards follow.`),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn primary', onclick: () => setup('names') }, 'Change names and pictures'),
          h('button', { class: 'btn', onclick: () => setup('data') }, 'Bring in data and sprites'),
          h('button', { class: 'btn', onclick: () => setup('intro') }, 'Run setup again'),
          h('button', { class: 'btn', onclick: async () => {
            const host = h('div', { class: 'setup-overlay bare' });
            document.body.append(host);
            try { await playIntro(host, { text: app.dataset.introText }); } finally { host.remove(); }
          } }, 'Play the introduction'))),
      updatesPanel(app, render),
      h('section', { class: 'panel col' },
        h('h2', null, 'Trainer'),
        h('label', { class: 'field' }, h('span', null, 'Your name (shown to friends in link battles)'),
          h('input', { type: 'text', value: app.save.trainer?.name ?? '', maxLength: 10, onchange: (e) => app.commit((sv) => { sv.trainer.name = e.target.value.trim().slice(0, 10) || 'Trainer'; }) })),
        h('div', { class: 'kv' },
          h('span', null, 'Battles won'), h('span', null, String(app.save.stats?.battlesWon ?? 0)),
          h('span', null, 'Battles lost'), h('span', null, String(app.save.stats?.battlesLost ?? 0)),
          h('span', null, 'Steps walked'), h('span', null, (app.save.stats?.totalSteps ?? 0).toLocaleString('en-US')))),
      h('section', { class: 'panel col' },
        h('h2', null, 'Desktop buddy'),
        h('p', { class: 'dim' }, 'One creature walks along the bottom of your screen, over other windows. Rub it to pet it; right-click it for more. Closing this window keeps it running in the system tray.'),
        h('div', { class: 'row' },
          buddy ? spriteCanvas(app.bank, buddy.speciesId, { scale: 2, animate: true }) : null,
          h('select', { onchange: (e) => set((st) => { st.petUid = e.target.value || null; }) },
            [h('option', { value: '' }, 'Choose a creature'), ...buddyOptions.map((c) => h('option', { value: c.uid, selected: c.uid === s.petUid }, `${displayName(app.idx, c)} (Lv. ${c.level})`))]),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!s.petEnabled, disabled: app.platform.kind !== 'desktop', onchange: (e) => set((st) => { st.petEnabled = e.target.checked; }) }), 'Show on desktop')),
        app.platform.kind !== 'desktop' ? h('p', { class: 'micro faint' }, 'Only in the desktop app.') : null),
      h('section', { class: 'panel col' },
        h('h2', null, 'Capsules'),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.autoSync !== false, onchange: (e) => set((st) => { st.autoSync = e.target.checked; }) }), 'Sync steps as soon as a capsule is docked'),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.askLetOut !== false, onchange: (e) => set((st) => { st.askLetOut = e.target.checked; }) }), 'Ask to let creatures out when they come home')),
      h('section', { class: 'panel col' },
        h('h2', null, 'Sound'),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.sound !== false, onchange: (e) => { set((st) => { st.sound = e.target.checked; }); setSound(e.target.checked, s.volume); } }), 'Cries and interface sounds'),
        h('label', { class: 'row' }, h('span', { class: 'dim' }, 'Volume'),
          h('input', { type: 'range', min: 0, max: 1, step: 0.05, value: s.volume ?? 0.6, onchange: (e) => { const v = Number(e.target.value); set((st) => { st.volume = v; }); setSound(s.sound !== false, v); sfx('blip'); } }))),
      texturePanel(textureCount),
      h('section', { class: 'panel col' },
        h('h2', null, 'Save data'),
        h('p', { class: 'dim' }, 'The desktop app keeps a daily backup of the last two weeks in the data folder.'),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn', onclick: () => app.platform.exportFile('capsule-link-save.json', JSON.stringify(app.save)) }, 'Export save'),
          h('button', { class: 'btn', onclick: async () => {
            const f = await app.platform.importFile([{ name: 'Save', extensions: ['json'] }]);
            if (!f) return;
            let incoming;
            try { incoming = JSON.parse(f.text); } catch { return toast('That file is not a save.', 'err'); }
            if (!incoming?.creatures || !incoming?.boxes) return toast('That file is not a save.', 'err');
            if (!(await confirmDialog('Replace your save?', 'Everything in this terminal is replaced with the file.', { ok: 'Replace', danger: true }))) return;
            app.commit((sv) => { for (const k of Object.keys(sv)) delete sv[k]; Object.assign(sv, JSON.parse(f.text)); }, 'import');
            toast('Save loaded.', 'ok');
          } }, 'Import save'),
          h('button', { class: 'btn', disabled: app.platform.kind !== 'desktop', onclick: () => app.platform.openData() }, 'Open data folder'))));
  }
  let spriteReport = null;
  let backViews = false;
  let showMissing = false;
  function texturePanel(textureCount) {
    const cov = spriteCoverage(app);
    const r = spriteReport;
    const add = async (e) => {
      const files = [...(e.target.files ?? [])];
      e.target.value = '';
      if (!files.length) return;
      toast(`Adding ${files.length} file${files.length === 1 ? '' : 's'}…`);
      try { spriteReport = await importSprites(app, files, { back: backViews }); sfx('heal'); }
      catch (err) { toast(`Could not add those: ${err.message}`, 'err'); }
      render();
    };
    return h('section', { class: 'panel col' },
      h('h2', null, 'Textures'),
      h('p', { class: 'dim' }, `${textureCount} custom texture${textureCount === 1 ? '' : 's'} loaded. Creature sprites: ${cov.have} of ${cov.total} species have their own art; the rest use generated pixel art.`),
      h('div', { class: 'row wrap' },
        h('label', { class: 'btn primary' }, 'Add creature sprites…', h('input', { type: 'file', id: 'add-sprites', class: 'hidden', accept: 'image/png', multiple: true, onchange: add })),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: backViews, onchange: (e) => { backViews = e.target.checked; } }), 'These are back views')),
      h('p', { class: 'micro faint' }, 'Select a whole folder of PNGs at once. Each file is matched by name (sproutle.png, Sproutle.png, 0001.png or 1.png) and saved under the species id. See docs/adding-your-data.md.'),
      r ? h('div', { class: 'col note-box' },
        h('div', null, `Added ${r.saved} file${r.saved === 1 ? '' : 's'}: ${r.matched} matched a species.`),
        r.unmatched.length ? h('div', { class: 'dim' }, `${r.unmatched.length} matched no species yet (kept, in case you add those species later): ${r.unmatched.slice(0, 12).join(', ')}${r.unmatched.length > 12 ? '…' : ''}`) : null,
        r.skipped.length ? h('div', { class: 'dim' }, `Skipped ${r.skipped.length} that were not PNG.`) : null,
        r.big.length ? h('div', { class: 'dim' }, `${r.big.length} are over 512 KB and stay on this PC only (phones skip them).`) : null,
        r.failed.length ? h('div', { class: 'err-text' }, `${r.failed.length} could not be saved: ${r.failed[0].error}`) : null) : null,
      cov.missing.length && cov.have ? h('div', null,
        h('button', { class: 'btn small', onclick: () => { showMissing = !showMissing; render(); } }, showMissing ? 'Hide species without art' : `Show species without art (${cov.missing.length})`),
        showMissing ? h('p', { class: 'micro dim' }, cov.missing.slice(0, 300).join(', ') + (cov.missing.length > 300 ? '…' : '')) : null) : null,
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn', disabled: app.platform.kind !== 'desktop', onclick: () => app.platform.openTextures() }, 'Open textures folder'),
        h('button', { class: 'btn', onclick: async () => { app.textures = await app.platform.textures(); app.bank.setResolver((p) => app.textures[p.toLowerCase()] ?? null); toast('Textures reloaded.'); render(); } }, 'Reload textures')));
  }

  render();
  return { el, update: render };
}
