// Settings, in four tabs: General (you, look, sound, updates, backups), Creatures (desktop buddies, sizes,
// the R.A.N.C.H., capsules), Data and art (Download everything, names, setup, textures) and Debug.
import { h, mount, toast, confirmDialog } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { setSound, sfx } from '../../../../shared/ui/audio.js';
import { displayName, list, desktopBuddies, toggleBuddy, MAX_BUDDIES, sunFor } from '../../../../shared/engine/index.js';
import { locateByName, locateByConnection } from '../sky.js';
import { importSprites, spriteCoverage } from '../spriteImport.js';
import { runSetup } from '../setup.js';
import { everythingTool, extrasTool, spriteTool, trainerTool } from '../dataTools.js';
import { debugPanel } from './debugPanel.js';
import { updatesPanel } from '../updates.js';
import { backupsPanel } from '../backups.js';
import { playIntro } from '../../../../shared/ui/introShow.js';
import { normalizeBrand } from '../../../../shared/engine/index.js';
import { applyTheme } from '../theme.js';

export function settingsView(app) {
  const body = h('div', { class: 'settings' });
  const tabsEl = h('div', { class: 'tabs settings-tabs', role: 'tablist' });
  const el = h('div', { class: 'settings-wrap' }, tabsEl, body);
  const set = (fn) => app.commit((s) => fn(s.settings), 'settings');
  let tab = settingsView.tab ?? 'general';
  const tools = {};
  let dbg = null;

  // four tabs, each a set of related sections that flow into columns (no gaps beside short panels):
  //   General      you, how it looks and sounds, updates and backups
  //   Creatures    desktop buddies, sizes, the R.A.N.C.H., capsules
  //   Data and art names and setup, downloads (Download everything first), your own textures
  //   Debug        hosting a server, adding and editing creatures, tools
  const TABS = [['general', 'General'], ['creatures', 'Creatures'], ['art', 'Data and art'], ['debug', 'Debug']];
  function render() {
    if (!TABS.some(([k]) => k === tab)) tab = 'general';
    mount(tabsEl, TABS.map(([k, l]) => h('button', { role: 'tab', 'aria-selected': tab === k ? 'true' : 'false', onclick: () => { tab = settingsView.tab = k; render(); } }, l)));
    body.className = `settings settings-${tab}`;
    if (tab === 'art') { renderArt(); return; }
    if (tab === 'debug') {
      dbg = dbg ?? debugPanel(app, render);
      dbg.update();
      mount(body, dbg.el);
      return;
    }
    if (tab === 'creatures') { renderCreatures(); return; }
    renderGeneral();
  }
  const group = (title, ...sections) => h('div', { class: 'set-group' }, h('h3', { class: 'set-group-title' }, title), h('div', { class: 'set-flow' }, sections));

  function renderGeneral() {
    const theme = (() => { try { return localStorage.getItem('capsule-link:theme') || 'system'; } catch { return 'system'; } })();
    const s = app.save.settings;
    mount(body,
      group('You and the app',
        h('section', { class: 'panel col' },
          h('h2', null, 'Trainer'),
          h('label', { class: 'field' }, h('span', null, 'Your name (shown to friends in link battles)'),
            h('input', { type: 'text', value: app.save.trainer?.name ?? '', maxLength: 10, onchange: (e) => app.commit((sv) => { sv.trainer.name = e.target.value.trim().slice(0, 10) || 'Trainer'; }) })),
          h('div', { class: 'kv' },
            h('span', null, 'Battles won'), h('span', null, String(app.save.stats?.battlesWon ?? 0)),
            h('span', null, 'Battles lost'), h('span', null, String(app.save.stats?.battlesLost ?? 0)),
            h('span', null, 'Steps walked'), h('span', null, (app.save.stats?.totalSteps ?? 0).toLocaleString('en-US'))),
          h('button', { class: 'btn small', onclick: () => app.go('trainer') }, 'Edit your trainer ID')),
        h('section', { class: 'panel col' },
          h('h2', null, 'Look'),
          h('div', { class: 'seg', role: 'radiogroup' }, [['system', 'Match the computer'], ['light', 'Light'], ['dark', 'Dark']].map(([v, l]) => h('button', { class: `btn small ${theme === v ? 'primary' : ''}`, role: 'radio', 'aria-checked': String(theme === v), onclick: () => { applyTheme(v); sfx('move'); render(); } }, l))),
          h('p', { class: 'micro dim' }, 'Every app has its own colours, in a light and a dark version.')),
        h('section', { class: 'panel col' },
          h('h2', null, 'Sound'),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.sound !== false, onchange: (e) => { set((st) => { st.sound = e.target.checked; }); setSound(e.target.checked, s.volume); } }), 'Cries and interface sounds'),
          h('label', { class: 'row' }, h('span', { class: 'dim' }, 'Volume'),
            h('input', { type: 'range', min: 0, max: 1, step: 0.05, value: s.volume ?? 0.6, onchange: (e) => { const v = Number(e.target.value); set((st) => { st.volume = v; }); setSound(s.sound !== false, v); sfx('blip'); } })))),
      group('Keeping it safe and up to date',
        updatesPanel(app, render),
        backupsPanel(app, render)));
  }

  function renderCreatures() {
    const s = app.save.settings;
    const buddyOptions = list(app.save).filter((c) => !['phone', 'capsule'].includes(c.location.kind) && !c.egg);
    const buddies = desktopBuddies(app.save).map((u) => app.save.creatures[u]);
    const slider = (label, key, min, max, step, def) => h('label', { class: 'row' }, h('span', { class: 'dim set-label' }, label),
      h('input', { type: 'range', min, max, step, value: s[key] ?? def, oninput: (e) => { e.target.nextSibling.textContent = `${Math.round(Number(e.target.value) * 100)}%`; }, onchange: (e) => { const v = Number(e.target.value); set((st) => { st[key] = v; }); } }),
      h('span', { class: 'micro dim' }, `${Math.round((s[key] ?? def) * 100)}%`));
    mount(body,
      group('On your desktop, and how big they look',
        h('section', { class: 'panel col' },
          h('h2', null, 'Desktop buddies'),
          h('p', { class: 'dim' }, `Up to ${MAX_BUDDIES} creatures live on your desktop, over other windows: walkers along the bottom, fliers anywhere. Rub to pet, drag to pick up and fling, double-click to call, right-click for more. Now and then one wanders off and brings something back. While they're out, they're not in the R.A.N.C.H.`),
          buddies.length ? h('div', { class: 'row wrap' }, buddies.map((c) => h('span', { class: 'buddy-chip' }, spriteCanvas(app.bank, c, { scale: 1 }), displayName(app.idx, c),
            h('button', { class: 'btn small ghost', title: 'Take back', onclick: () => set((st) => { const sv = { settings: st, creatures: app.save.creatures }; toggleBuddy(sv, c.uid, false); }) }, '✕')))) : null,
          h('div', { class: 'row wrap' },
            h('select', { disabled: buddies.length >= MAX_BUDDIES, onchange: (e) => { const uid = e.target.value; if (uid) set((st) => { toggleBuddy({ settings: st, creatures: app.save.creatures }, uid, true); }); } },
              [h('option', { value: '' }, buddies.length >= MAX_BUDDIES ? 'All six are out' : 'Add a buddy…'), ...buddyOptions.filter((c) => !buddies.includes(c)).map((c) => h('option', { value: c.uid }, `${displayName(app.idx, c)} (Lv. ${c.level})`))]),
            h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!s.petEnabled, disabled: app.platform.kind !== 'desktop', onchange: (e) => set((st) => { st.petEnabled = e.target.checked; }) }), 'Show on desktop')),
          h('p', { class: 'micro faint' }, 'Also: right-click anyone in the storage system → Send to the desktop.'),
          app.platform.kind !== 'desktop' ? h('p', { class: 'micro faint' }, 'Only in the desktop app.') : null),
        h('section', { class: 'panel col' },
          h('h2', null, 'Sizes'),
          slider('On the desktop', 'petSize', 0.25, 3, 0.05, 1),
          slider('In the R.A.N.C.H.', 'ranchScale', 0.1, 2, 0.05, 1),
          h('p', { class: 'micro faint' }, 'Each creature also follows its own height (and any size it was given). Right-click a desktop buddy for Smaller and Bigger.'))),
      group('The R.A.N.C.H. and capsules',
        h('section', { class: 'panel col' },
          h('h2', null, 'Time and weather'),
          h('label', { class: 'row' }, h('span', { class: 'dim set-label' }, 'Time of day'),
            h('select', { onchange: (e) => set((st) => { st.ranchTime = e.target.value; }) }, [['local', 'Local time'], ['dawn', 'Morning'], ['day', 'Day'], ['dusk', 'Evening'], ['night', 'Night']].map(([v, l]) => h('option', { value: v, selected: v === (s.ranchTime ?? 'local') }, l)))),
          h('label', { class: 'row' }, h('span', { class: 'dim set-label' }, 'Weather'),
            h('select', { onchange: (e) => set((st) => { st.ranchWeather = e.target.value; }) }, [['real', 'Where you are (real weather, falls back to simulated)'], ['sim', 'Simulated (changes through the day)'], ['clear', 'Clear'], ['cloudy', 'Cloudy'], ['rain', 'Rain'], ['storm', 'Storm'], ['snow', 'Snow'], ['fog', 'Fog'], ['windy', 'Windy']].map(([v, l]) => h('option', { value: v, selected: v === (s.ranchWeather ?? 'real') }, l)))),
          h('p', { class: 'micro faint' }, 'Also in the R.A.N.C.H. itself, top right.'),
          whereYouAre()),
        h('section', { class: 'panel col' },
          h('h2', null, 'Docking'),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.autoSync !== false, onchange: (e) => set((st) => { st.autoSync = e.target.checked; }) }), 'Sync steps as soon as a capsule is docked'),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.askLetOut !== false, onchange: (e) => set((st) => { st.askLetOut = e.target.checked; }) }), 'Ask to let creatures out when they come home'))));
  }

  // where you are: real sunrise, sunset, weather and fog
  function whereYouAre() {
    const sky = app.save.sky;
    const tm = (ms) => (ms ? new Date(ms).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : '—');
    const sun = sunFor(Date.now());
    const busy = (btn, job) => async () => { btn.disabled = true; try { await job(); toast('Got it: the R.A.N.C.H. now follows the real sky there.', 'ok'); } catch (e) { toast(e.message, 'err'); } finally { btn.disabled = false; render(); } };
    const input = h('input', { type: 'text', placeholder: 'Town or city', value: '', 'aria-label': 'Town or city', style: { flex: '1 1 160px' } });
    const findBtn = h('button', { class: 'btn small' }, 'Use this town');
    findBtn.onclick = busy(findBtn, () => { if (!input.value.trim()) throw new Error('Type a town or city first.'); return locateByName(app, input.value); });
    const ipBtn = h('button', { class: 'btn small' }, 'Find me (roughly)');
    ipBtn.onclick = busy(ipBtn, () => locateByConnection(app));
    return h('div', { class: 'btn-group col' },
      h('div', { class: 'btn-group-head' }, 'Where you are'),
      h('p', { class: 'micro dim', style: { margin: 0 } }, sky?.lat != null
        ? `${sky.place ?? 'From your phone'} · sunrise ${tm(sun?.sunrise)}, sunset ${tm(sun?.sunset)}${sky.weather ? ` · ${sky.weather}${sky.visibility != null && sky.visibility < 1000 ? ' (foggy)' : ''}${sky.temp != null ? `, ${sky.temp}°C` : ''} (${Math.max(1, Math.round((Date.now() - sky.at) / 60000))} min ago)` : ''}`
        : 'Not set: night and day follow this computer’s clock. Set a town (or walk with the phone and its location on) for the real sunrise, sunset, weather and fog.'),
      h('div', { class: 'row wrap' }, input, findBtn, ipBtn),
      h('p', { class: 'micro faint', style: { margin: 0 } }, 'Only a rough position (about 10 km) and the weather are kept. Looked up on Open-Meteo every 30 minutes; the phone sends its own after walks.'));
  }

  function renderArt() {
    const textureCount = Object.keys(app.textures ?? {}).length;
    const b = normalizeBrand(app.dataset.brand);
    const setup = async (start) => {
      const host = h('div', { class: 'setup-overlay' });
      document.body.append(host);
      try { await runSetup(app, host, { start }); } finally { host.remove(); }
      app.refresh(); app.renderTop?.(); render();
    };
    tools.all = tools.all ?? everythingTool(app, { big: true });
    tools.extras = tools.extras ?? extrasTool(app);
    tools.sprites = tools.sprites ?? spriteTool(app);
    tools.trainers = tools.trainers ?? trainerTool(app);
    mount(body,
      group('Get everything',
        h('div', { class: 'set-wide' }, tools.all)),
      group('Names and setup',
        h('section', { class: 'panel col' },
          h('h2', null, 'Names and pictures'),
          h('p', { class: 'dim' }, `The apps call themselves “${b.app}”, carry ${b.creatures} in ${b.balls} and connect through ${b.company}. Change any of it — every screen, the phone and ID cards follow.`),
          h('div', { class: 'row wrap' },
            h('button', { class: 'btn primary', onclick: () => setup('names') }, 'Change names and pictures'),
            h('button', { class: 'btn', onclick: async () => {
              const host = h('div', { class: 'setup-overlay bare' });
              document.body.append(host);
              try { await playIntro(host, { text: app.dataset.introText }); } finally { host.remove(); }
            } }, 'Play the introduction'))),
        h('section', { class: 'panel col' },
          h('h2', null, 'Setup'),
          h('p', { class: 'dim' }, 'The step-by-step data setup: each file on its own, with an example and a check. Handy for your own data.'),
          h('div', { class: 'row wrap' },
            h('button', { class: 'btn', onclick: () => setup('data') }, 'Bring in data step by step'),
            h('button', { class: 'btn', onclick: () => setup('intro') }, 'Run the whole setup again')))),
      group('One thing at a time',
        h('div', { class: 'set-wide col' }, tools.sprites, tools.trainers, tools.extras)),
      group('Your own art',
        texturePanel(textureCount)));
  }
  let spriteReport = null;
  let backViews = false;
  let showMissing = false;
  function texturePanel(textureCount) {
    const cov = spriteCoverage(app);
    const r = spriteReport;
    const add = async (e) => {
      const files = [...(e.target.files ?? [])];
      e.target.value = '';
      if (!files.length) return;
      toast(`Adding ${files.length} file${files.length === 1 ? '' : 's'}…`);
      try { spriteReport = await importSprites(app, files, { back: backViews }); sfx('heal'); }
      catch (err) { toast(`Could not add those: ${err.message}`, 'err'); }
      render();
    };
    return h('section', { class: 'panel col' },
      h('h2', null, 'Textures'),
      h('p', { class: 'dim' }, `${textureCount} custom texture${textureCount === 1 ? '' : 's'} loaded. Creature sprites: ${cov.have} of ${cov.total} species have their own art; the rest use generated pixel art.`),
      h('div', { class: 'row wrap' },
        h('label', { class: 'btn primary' }, 'Add creature sprites…', h('input', { type: 'file', id: 'add-sprites', class: 'hidden', accept: 'image/png', multiple: true, onchange: add })),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: backViews, onchange: (e) => { backViews = e.target.checked; } }), 'These are back views')),
      h('p', { class: 'micro faint' }, 'Select a whole folder of PNGs at once. Each file is matched by name (sproutle.png, Sproutle.png, 0001.png or 1.png) and saved under the species id. See docs/adding-your-data.md.'),
      r ? h('div', { class: 'col note-box' },
        h('div', null, `Added ${r.saved} file${r.saved === 1 ? '' : 's'}: ${r.matched} matched a species.`),
        r.unmatched.length ? h('div', { class: 'dim' }, `${r.unmatched.length} matched no species yet (kept, in case you add those species later): ${r.unmatched.slice(0, 12).join(', ')}${r.unmatched.length > 12 ? '…' : ''}`) : null,
        r.skipped.length ? h('div', { class: 'dim' }, `Skipped ${r.skipped.length} that were not PNG.`) : null,
        r.big.length ? h('div', { class: 'dim' }, `${r.big.length} are over 512 KB and stay on this PC only (phones skip them).`) : null,
        r.failed.length ? h('div', { class: 'err-text' }, `${r.failed.length} could not be saved: ${r.failed[0].error}`) : null) : null,
      cov.missing.length && cov.have ? h('div', null,
        h('button', { class: 'btn small', onclick: () => { showMissing = !showMissing; render(); } }, showMissing ? 'Hide species without art' : `Show species without art (${cov.missing.length})`),
        showMissing ? h('p', { class: 'micro dim' }, cov.missing.slice(0, 300).join(', ') + (cov.missing.length > 300 ? '…' : '')) : null) : null,
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn', disabled: app.platform.kind !== 'desktop', onclick: () => app.platform.openTextures() }, 'Open textures folder'),
        h('button', { class: 'btn', onclick: async () => { app.textures = await app.platform.textures(); app.bank.setResolver((p) => app.textures[p.toLowerCase()] ?? null); toast('Textures reloaded.'); render(); } }, 'Reload textures')));
  }

  render();
  return { el, update: render };
}
