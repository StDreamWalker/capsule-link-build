// Settings: trainer, sound, desktop buddy, textures and backups.
import { h, mount, toast, confirmDialog } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { setSound, sfx } from '../../../../shared/ui/audio.js';
import { displayName, list, desktopBuddies, toggleBuddy, MAX_BUDDIES } from '../../../../shared/engine/index.js';
import { importSprites, spriteCoverage } from '../spriteImport.js';
import { runSetup } from '../setup.js';
import { extrasTool, spriteTool, trainerTool } from '../dataTools.js';
import { debugPanel } from './debugPanel.js';
import { updatesPanel } from '../updates.js';
import { backupsPanel } from '../backups.js';
import { playIntro } from '../../../../shared/ui/introShow.js';
import { normalizeBrand } from '../../../../shared/engine/index.js';

export function settingsView(app) {
  const body = h('div', { class: 'settings' });
  const tabsEl = h('div', { class: 'tabs settings-tabs', role: 'tablist' });
  const el = h('div', { class: 'settings-wrap' }, tabsEl, body);
  const set = (fn) => app.commit((s) => fn(s.settings), 'settings');
  let tab = settingsView.tab ?? 'general';
  const tools = {};
  let dbg = null;

  function render() {
    mount(tabsEl, [['general', 'General'], ['art', 'Data and art'], ['debug', 'Debug']].map(([k, l]) => h('button', { role: 'tab', 'aria-selected': tab === k ? 'true' : 'false', onclick: () => { tab = settingsView.tab = k; render(); } }, l)));
    if (tab === 'art') {
      tools.extras = tools.extras ?? extrasTool(app);
      tools.sprites = tools.sprites ?? spriteTool(app);
      tools.trainers = tools.trainers ?? trainerTool(app);
      mount(body, h('div', { class: 'col span-all art-tools' }, tools.sprites, tools.trainers, tools.extras,
        h('p', { class: 'micro dim' }, 'Species, moves, learnsets and natures: Settings → General → Bring in data and sprites, or the Data Lab’s Paste tab.')));
      return;
    }
    if (tab === 'debug') {
      dbg = dbg ?? debugPanel(app, render);
      dbg.update();
      mount(body, dbg.el);
      return;
    }
    renderGeneral();
  }

  function renderGeneral() {
    const el = body;
    const s = app.save.settings;
    const buddyOptions = list(app.save).filter((c) => !['phone', 'capsule'].includes(c.location.kind));
    const buddies = desktopBuddies(app.save).map((u) => app.save.creatures[u]);
    const textureCount = Object.keys(app.textures ?? {}).length;
    const b = normalizeBrand(app.dataset.brand);
    const setup = async (start) => {
      const host = h('div', { class: 'setup-overlay' });
      document.body.append(host);
      try { await runSetup(app, host, { start }); } finally { host.remove(); }
      app.refresh(); app.renderTop?.(); render();
    };
    mount(el,
      h('section', { class: 'panel col span-all' },
        h('h2', null, 'Names and setup'),
        h('p', { class: 'dim' }, `The apps call themselves “${b.app}”, carry ${b.creatures} in ${b.balls} and connect through ${b.company}. Change any of it — every screen, the phone and ID cards follow.`),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn primary', onclick: () => setup('names') }, 'Change names and pictures'),
          h('button', { class: 'btn', onclick: () => setup('data') }, 'Bring in data and sprites'),
          h('button', { class: 'btn', onclick: () => setup('intro') }, 'Run setup again'),
          h('button', { class: 'btn', onclick: async () => {
            const host = h('div', { class: 'setup-overlay bare' });
            document.body.append(host);
            try { await playIntro(host, { text: app.dataset.introText }); } finally { host.remove(); }
          } }, 'Play the introduction'))),
      updatesPanel(app, render),
      backupsPanel(app, render),
      h('section', { class: 'panel col' },
        h('h2', null, 'Trainer'),
        h('label', { class: 'field' }, h('span', null, 'Your name (shown to friends in link battles)'),
          h('input', { type: 'text', value: app.save.trainer?.name ?? '', maxLength: 10, onchange: (e) => app.commit((sv) => { sv.trainer.name = e.target.value.trim().slice(0, 10) || 'Trainer'; }) })),
        h('div', { class: 'kv' },
          h('span', null, 'Battles won'), h('span', null, String(app.save.stats?.battlesWon ?? 0)),
          h('span', null, 'Battles lost'), h('span', null, String(app.save.stats?.battlesLost ?? 0)),
          h('span', null, 'Steps walked'), h('span', null, (app.save.stats?.totalSteps ?? 0).toLocaleString('en-US')))),
      h('section', { class: 'panel col' },
        h('h2', null, 'Desktop buddies'),
        h('p', { class: 'dim' }, `Up to ${MAX_BUDDIES} creatures live on your desktop, over other windows: walkers along the bottom, fliers anywhere. Rub to pet, drag to pick up and fling, double-click to call, right-click for more. Friends play together, and now and then one finds something. Closing this window keeps them running in the system tray.`),
        buddies.length ? h('div', { class: 'row wrap' }, buddies.map((c) => h('span', { class: 'buddy-chip' }, spriteCanvas(app.bank, c, { scale: 1 }), displayName(app.idx, c),
          h('button', { class: 'btn small ghost', title: 'Take back', onclick: () => set((st) => { const sv = { settings: st, creatures: app.save.creatures }; toggleBuddy(sv, c.uid, false); }) }, '✕')))) : null,
        h('div', { class: 'row' },
          h('select', { disabled: buddies.length >= MAX_BUDDIES, onchange: (e) => { const uid = e.target.value; if (uid) set((st) => { toggleBuddy({ settings: st, creatures: app.save.creatures }, uid, true); }); } },
            [h('option', { value: '' }, buddies.length >= MAX_BUDDIES ? 'All six are out' : 'Add a buddy…'), ...buddyOptions.filter((c) => !buddies.includes(c)).map((c) => h('option', { value: c.uid }, `${displayName(app.idx, c)} (Lv. ${c.level})`))]),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!s.petEnabled, disabled: app.platform.kind !== 'desktop', onchange: (e) => set((st) => { st.petEnabled = e.target.checked; }) }), 'Show on desktop')),
        h('label', { class: 'row' }, h('span', { class: 'dim' }, 'Size'),
          h('input', { type: 'range', min: 0.25, max: 3, step: 0.05, value: s.petSize ?? 1, oninput: (e) => { e.target.nextSibling.textContent = `${Math.round(Number(e.target.value) * 100)}%`; }, onchange: (e) => { const v = Number(e.target.value); set((st) => { st.petSize = v; }); } }),
          h('span', { class: 'micro dim' }, `${Math.round((s.petSize ?? 1) * 100)}%`)),
        h('p', { class: 'micro faint' }, 'Each creature also follows its own height. Right-click the buddy for Smaller and Bigger, or use the tray icon.'),
        h('label', { class: 'row' }, h('span', { class: 'dim' }, 'R.A.N.C.H. size'),
          h('input', { type: 'range', min: 0.1, max: 2, step: 0.05, value: s.ranchScale ?? 1, oninput: (e) => { e.target.nextSibling.textContent = `${Math.round(Number(e.target.value) * 100)}%`; }, onchange: (e) => { const v = Number(e.target.value); set((st) => { st.ranchScale = v; }); } }),
          h('span', { class: 'micro dim' }, `${Math.round((s.ranchScale ?? 1) * 100)}%`)),
        app.platform.kind !== 'desktop' ? h('p', { class: 'micro faint' }, 'Only in the desktop app.') : null),
      h('section', { class: 'panel col' },
        h('h2', null, 'Capsules'),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.autoSync !== false, onchange: (e) => set((st) => { st.autoSync = e.target.checked; }) }), 'Sync steps as soon as a capsule is docked'),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.askLetOut !== false, onchange: (e) => set((st) => { st.askLetOut = e.target.checked; }) }), 'Ask to let creatures out when they come home')),
      h('section', { class: 'panel col' },
        h('h2', null, 'Sound'),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: s.sound !== false, onchange: (e) => { set((st) => { st.sound = e.target.checked; }); setSound(e.target.checked, s.volume); } }), 'Cries and interface sounds'),
        h('label', { class: 'row' }, h('span', { class: 'dim' }, 'Volume'),
          h('input', { type: 'range', min: 0, max: 1, step: 0.05, value: s.volume ?? 0.6, onchange: (e) => { const v = Number(e.target.value); set((st) => { st.volume = v; }); setSound(s.sound !== false, v); sfx('blip'); } }))),
      texturePanel(textureCount));
  }
  let spriteReport = null;
  let backViews = false;
  let showMissing = false;
  function texturePanel(textureCount) {
    const cov = spriteCoverage(app);
    const r = spriteReport;
    const add = async (e) => {
      const files = [...(e.target.files ?? [])];
      e.target.value = '';
      if (!files.length) return;
      toast(`Adding ${files.length} file${files.length === 1 ? '' : 's'}…`);
      try { spriteReport = await importSprites(app, files, { back: backViews }); sfx('heal'); }
      catch (err) { toast(`Could not add those: ${err.message}`, 'err'); }
      render();
    };
    return h('section', { class: 'panel col' },
      h('h2', null, 'Textures'),
      h('p', { class: 'dim' }, `${textureCount} custom texture${textureCount === 1 ? '' : 's'} loaded. Creature sprites: ${cov.have} of ${cov.total} species have their own art; the rest use generated pixel art.`),
      h('div', { class: 'row wrap' },
        h('label', { class: 'btn primary' }, 'Add creature sprites…', h('input', { type: 'file', id: 'add-sprites', class: 'hidden', accept: 'image/png', multiple: true, onchange: add })),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: backViews, onchange: (e) => { backViews = e.target.checked; } }), 'These are back views')),
      h('p', { class: 'micro faint' }, 'Select a whole folder of PNGs at once. Each file is matched by name (sproutle.png, Sproutle.png, 0001.png or 1.png) and saved under the species id. See docs/adding-your-data.md.'),
      r ? h('div', { class: 'col note-box' },
        h('div', null, `Added ${r.saved} file${r.saved === 1 ? '' : 's'}: ${r.matched} matched a species.`),
        r.unmatched.length ? h('div', { class: 'dim' }, `${r.unmatched.length} matched no species yet (kept, in case you add those species later): ${r.unmatched.slice(0, 12).join(', ')}${r.unmatched.length > 12 ? '…' : ''}`) : null,
        r.skipped.length ? h('div', { class: 'dim' }, `Skipped ${r.skipped.length} that were not PNG.`) : null,
        r.big.length ? h('div', { class: 'dim' }, `${r.big.length} are over 512 KB and stay on this PC only (phones skip them).`) : null,
        r.failed.length ? h('div', { class: 'err-text' }, `${r.failed.length} could not be saved: ${r.failed[0].error}`) : null) : null,
      cov.missing.length && cov.have ? h('div', null,
        h('button', { class: 'btn small', onclick: () => { showMissing = !showMissing; render(); } }, showMissing ? 'Hide species without art' : `Show species without art (${cov.missing.length})`),
        showMissing ? h('p', { class: 'micro dim' }, cov.missing.slice(0, 300).join(', ') + (cov.missing.length > 300 ? '…' : '')) : null) : null,
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn', disabled: app.platform.kind !== 'desktop', onclick: () => app.platform.openTextures() }, 'Open textures folder'),
        h('button', { class: 'btn', onclick: async () => { app.textures = await app.platform.textures(); app.bank.setResolver((p) => app.textures[p.toLowerCase()] ?? null); toast('Textures reloaded.'); render(); } }, 'Reload textures')));
  }

  render();
  return { el, update: render };
}
