// Home after signing in: the storage system, the R.A.N.C.H., and the other apps.
import { friendsSession, ago } from '../friendsSession.js';
import { h, mount, fmtNum } from '../../../../shared/ui/dom.js';
import { idCardEl, partyForCard } from '../../../../shared/ui/idcard.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { svgIcon } from '../../../../shared/ui/icons.js';
import { sfx } from '../../../../shared/ui/audio.js';
import { party, list, boxContents, displayName } from '../../../../shared/engine/index.js';

export const RANCH_NAME = 'Remote Access Nurture & Care Hub';

const APPS = [
  { id: 'market', title: 'Market', desc: 'Daily stock, your bag, blueprints', icon: 'market', tint: '#e0882a' },
  { id: 'activities', title: 'Activities', desc: 'Cook, fish, garden, explore together', icon: 'activities', tint: '#2fa36b' },
  { id: 'friends', title: 'Friends', desc: 'Who’s online, battles, trades, gifts', icon: 'friends', tint: '#0ea5e9' },
  { id: 'dock', title: 'Capsule Dock', desc: 'Send creatures to capsules, sync walks', icon: 'dock', tint: '#3b6cf6' },
  { id: 'battle', title: 'Battle Link', desc: 'Showdown battles, rewards here', icon: 'battle', tint: '#e5484d' },
  { id: 'trainer', title: 'Trainer ID', desc: 'Your card on PC and phone', icon: 'id', tint: '#8b5cf6' },
  { id: 'phone', title: 'Phone Link', desc: 'Pair over Wi-Fi or USB-C', icon: 'phone', tint: '#12b5a5' },
  { id: 'data', title: 'Data Lab', desc: 'Species, moves and formulas', icon: 'lab', tint: '#f2a516' },
  { id: 'settings', title: 'Settings', desc: 'Sound, textures, backups', icon: 'settings', tint: '#64748b' },
];

export function homeView(app) {
  const el = h('div', { class: 'home' });
  const open = (id) => { sfx(id === 'storage' ? 'access' : id === 'ranch' ? 'warp' : 'blip'); app.go(id); };

  function render() {
    const t = app.save.trainer;
    const all = list(app.save);
    const team = party(app.save);
    const firstBox = app.save.boxes.findIndex((_, i) => boxContents(app.save, i).some(Boolean));
    const yardFolk = firstBox >= 0 ? boxContents(app.save, firstBox).filter(Boolean).slice(0, 5) : [];
    const hour = new Date().getHours();
    const greet = hour < 5 ? 'Up late' : hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
    mount(el,
      h('div', { class: 'home-main' },
        h('header', { class: 'home-head' },
          h('h1', null, `${greet}, ${t?.name ?? 'Trainer'}`),
          h('p', { class: 'dim' }, `${all.length} creatures · ${app.save.boxes.length} boxes · ${fmtNum(app.save.stats?.totalSteps ?? 0)} steps walked`)),
        h('div', { class: 'hero-row' },
          h('button', { class: 'hero storage', id: 'open-storage', onclick: () => open('storage') },
            h('span', { class: 'hero-icon' }, svgIcon('storage', { size: 22 })),
            h('span', { class: 'hero-title' }, 'Creature Storage'),
            h('span', { class: 'hero-desc' }, 'Deposit, withdraw and swap between your party and boxes.'),
            h('span', { class: 'hero-art storage-art' }, team.slice(0, 6).map((c) => h('span', { class: 'orb' }, spriteCanvas(app.bank, c, { scale: 1 }))))),
          h('button', { class: 'hero ranch', id: 'open-ranch', onclick: () => open('ranch') },
            h('span', { class: 'hero-icon' }, svgIcon('ranch', { size: 22 })),
            h('span', { class: 'hero-title' }, 'R.A.N.C.H.'),
            h('span', { class: 'hero-desc' }, `${RANCH_NAME}. Visit a box’s yard, build it up, tend the berry farm.`),
            h('span', { class: 'hero-art ranch-art' }, h('span', { class: 'hills' }), yardFolk.map((c) => spriteCanvas(app.bank, c, { scale: 1, animate: true }))))),
        h('h2', { class: 'section-title' }, 'Apps'),
        h('div', { class: 'app-grid' }, APPS.map((p) => h('button', { class: 'app-tile', onclick: () => open(p.id) },
          h('span', { class: 'app-icon', style: { '--tint': p.tint } }, svgIcon(p.icon, { size: 22 })),
          h('span', { class: 'app-text' }, h('span', { class: 'app-title' }, p.title), h('span', { class: 'app-desc' }, p.desc)))))),
      h('aside', { class: 'home-side' },
        h('button', { class: 'card-btn', title: 'Edit your trainer ID', onclick: () => open('trainer') }, idCardEl(t, { scale: 1.4, party: partyForCard(app.bank, team, (c) => displayName(app.idx, c)) })),
        h('section', { class: 'panel side-card' },
          h('h2', null, 'Party'),
          team.length ? h('div', { class: 'party-mini' }, team.map((c) => h('div', { class: 'party-mini-row' }, spriteCanvas(app.bank, c, { scale: 1 }), h('span', { class: 'grow' }, displayName(app.idx, c)), h('span', { class: 'dim' }, `Lv ${c.level}`))))
            : h('p', { class: 'dim' }, 'Nobody in your party yet.')),
        h('section', { class: 'panel side-card stats-card' },
          h('div', null, h('div', { class: 'stat-num' }, fmtNum(app.save.stats?.battlesWon ?? 0)), h('div', { class: 'dim micro' }, 'Battles won')),
          h('div', null, h('div', { class: 'stat-num' }, fmtNum(Object.keys(app.save.capsules ?? {}).length)), h('div', { class: 'dim micro' }, 'Capsules')),
          h('div', null, h('div', { class: 'stat-num' }, fmtNum(Object.keys(app.save.devices ?? {}).length)), h('div', { class: 'dim micro' }, 'Phones'))),
        friendsCard()));
  }

  // friends on your server: who's online now, and when the others were last about
  const S = friendsSession(app);
  const unsub = S.on((n) => { if (['refresh', 'online', 'offline'].includes(n.what)) render(); });
  if (S.signedIn() && !S.friends) S.refresh().catch(() => {});
  function friendsCard() {
    if (!S.signedIn()) {
      return h('button', { class: 'panel side-card friends-card empty', onclick: () => open('friends') },
        h('h2', null, 'Friends'), h('p', { class: 'dim micro' }, 'Sign in to a friends server to see who’s online.'));
    }
    const fr = [...(S.friends?.friends ?? [])].sort((a, b) => (b.online ? 1 : 0) - (a.online ? 1 : 0) || (b.seenAt ?? 0) - (a.seenAt ?? 0));
    const on = fr.filter((f) => f.online).length;
    return h('button', { class: 'panel side-card friends-card', onclick: () => open('friends') },
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, 'Friends'), h('span', { class: `micro ${on ? 'ok-text' : 'dim'}` }, on ? `${on} online` : 'nobody online')),
      fr.length ? h('div', { class: 'friends-mini' }, fr.slice(0, 6).map((f) => h('div', { class: 'party-mini-row' },
        h('span', { class: `fr-dot ${f.online ? 'on' : ''}` }), h('span', { class: 'grow' }, f.trainerName), h('span', { class: 'dim micro' }, f.online ? 'online' : ago(f.seenAt)))))
        : h('p', { class: 'dim micro' }, S.friends ? 'No friends yet. Add some in Friends.' : 'Checking…'),
      fr.length > 6 ? h('p', { class: 'dim micro' }, `and ${fr.length - 6} more`) : null);
  }

  render();
  return { el, update: render, dispose() { unsub(); } };
}
