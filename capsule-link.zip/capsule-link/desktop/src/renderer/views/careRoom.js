// The care room: one creature, up close, in a zoomed-in corner of its R.A.N.C.H. scene.
// Pick a tool and rub it over them: wash with the sponge, dry with the towel and the dryer,
// brush and comb, or just pet. Hold a toy out to play, hold food in front of them to feed it
// bite by bite, or toss a berry and they fetch it back before eating it.
// Everyone has a favourite berry and toy (engine: favorites) and lights up when they get them.
import { h, mount } from '../../../../shared/ui/dom.js';
import { fitSprite } from '../../../../shared/ui/creatureSize.js';
import { spriteIdOf } from '../../../../shared/ui/art.js';
import { sfx, creatureCry } from '../../../../shared/ui/audio.js';
import { displayName, speciesOf, favorites, CARE_TOYS, mood } from '../../../../shared/engine/index.js';

const W = 480, H = 270, FLOOR = 228;
const TOOLS = [
  ['hand', 'Pet', 'Rub to pet'],
  ['sponge', 'Wash', 'Scrub them clean'],
  ['towel', 'Towel', 'Rub them dry'],
  ['dryer', 'Dryer', 'Blow-dry the last of the damp'],
  ['brush', 'Brush', 'Brush their coat'],
  ['comb', 'Comb', 'Comb out the tangles'],
];

/**
 * app: the PC app; uid: the creature; doCare(action, opts) applies care and returns its result.
 * Returns a promise that resolves when the room is closed.
 */
export function openCareRoom(app, uid, { biome = 'meadow', doCare }) {
  return new Promise((resolve) => {
    const c = () => app.save.creatures[uid];
    if (!c()) { resolve(); return; }
    const fav = favorites(app.idx, c());
    const toys = [...CARE_TOYS, ...app.idx.ds.items.filter((i) => i.kind === 'toy')];
    const foods = () => app.idx.ds.items.filter((i) => i.kind === 'food' && (i.unlimited || (app.save.inventory[i.id] ?? 0) > 0));
    const st = {
      tool: 'hand', held: null, // held: { kind: 'toy'|'food', item }
      x: W / 2, y: FLOOR, flip: false, state: 'idle', t: 0, hop: 0, ft: 0,
      // dirt spots from how grubby they are; wet after a wash
      dirt: Math.max(0, Math.round((100 - (c().needs?.hygiene ?? 90)) / 12)), wet: 0, stroke: 0, play: 0, bites: 0,
      berry: null, // a tossed berry: { x, y, vx, vy, item, carried }
      fx: [], words: [], cursor: null, down: false,
    };
    const spots = Array.from({ length: 8 }, (_, i) => ({ fx: 0.25 + ((i * 37) % 50) / 100, fy: 0.3 + ((i * 53) % 55) / 100, r: 3 + (i % 3) }));

    const canvas = h('canvas', { class: 'care-canvas', width: W, height: H });
    const ctx = canvas.getContext('2d');
    const status = h('div', { class: 'care-status' });
    const bar = h('div', { class: 'care-tools' });
    const root = h('div', { class: 'care-room' }, canvas, status, bar);
    document.body.append(root);
    sfx('warp');

    const bank = app.bank;
    const bg = bank.background('ranch', biome, 320, 180, 5);

    // ---------- the creature on screen ----------
    function geom() {
      const e = bank.get(spriteIdOf(c()));
      const tall = Math.min(H * 0.55, 60 + 70 * Math.min(1.6, (speciesOf(app.idx, c())?.height ?? 1)));
      const f = fitSprite(e, tall, st.y);
      const b = f.box;
      return { e, f, tall, left: st.x - (b.right - b.left) * f.size / 2, right: st.x + (b.right - b.left) * f.size / 2, top: st.y - tall, bottom: st.y };
    }
    const over = (p, g = geom()) => p && p.x > g.left - 6 && p.x < g.right + 6 && p.y > g.top - 6 && p.y < g.bottom + 4;
    const mouth = (g = geom()) => ({ x: st.x + (st.flip ? -1 : 1) * (g.right - g.left) * 0.25, y: g.top + g.tall * 0.38 });

    function say(text, color = '#ffffff') { st.words.push({ text, x: st.x, y: geom().top - 10, life: 1.8, color }); }
    function burst(kind, x, y, n = 4) { for (let i = 0; i < n; i++) st.fx.push({ kind, x: x + (Math.random() - 0.5) * 16, y: y + (Math.random() - 0.5) * 10, vx: (Math.random() - 0.5) * 30, vy: kind === 'drip' ? 20 : -20 - Math.random() * 20, life: 1 + Math.random() * 0.6 }); }

    function care(action, opts = {}) {
      const out = doCare(action, opts);
      renderStatus();
      if (!out?.ok) return out;
      if (out.reaction === 'delighted') { say('♥ Favourite!', '#ff8fb8'); burst('heart', st.x, geom().top + 10, 6); creatureCry(speciesOf(app.idx, c()), c(), { mood: 'happy' }); st.hop = 1; }
      else if (out.reaction === 'full') say('Full…', '#cde');
      else if (out.reaction === 'tired') say('Too tired…', '#cde');
      return out;
    }

    // ---------- tools ----------
    function useTool(p, dist) {
      const g = geom();
      if (!over(p, g)) return;
      st.stroke += dist;
      const tool = st.tool;
      if (tool === 'hand') { if (st.stroke > 160) { st.stroke = 0; burst('heart', p.x, p.y, 2); sfx('heart'); care('pet'); st.hop = 0.6; } return; }
      if (tool === 'sponge') {
        if (Math.random() < 0.5) burst('bubble', p.x, p.y, 1);
        if (st.stroke > 140) { st.stroke = 0; st.dirt = Math.max(0, st.dirt - 1); st.wet = 1; sfx('blip'); if (st.dirt === 0 && !st.washed) { st.washed = true; care('wash'); say('Squeaky clean!'); } }
        return;
      }
      if (tool === 'towel') {
        if (!st.wet) { if (st.stroke > 200) { st.stroke = 0; say('Already dry'); } return; }
        if (st.stroke > 120) { st.stroke = 0; const was = st.wet; st.wet = Math.max(0.3, st.wet - 0.35); if (st.wet <= 0.3 && was > 0.3) { care('towel'); say('Nearly dry — try the dryer'); } }
        return;
      }
      if (tool === 'dryer') {
        burst('air', p.x - 14, p.y, 1);
        if (!st.wet) return;
        if (st.stroke > 160) { st.stroke = 0; st.wet = Math.max(0, st.wet - 0.2); if (st.wet <= 0) { st.washed = false; care('dry'); say('Fluffy!'); burst('sparkle', st.x, g.top + 20, 5); } }
        return;
      }
      if (tool === 'brush' || tool === 'comb') {
        if (st.wet > 0.3) { if (st.stroke > 200) { st.stroke = 0; say('Dry them first'); } return; }
        if (Math.random() < 0.3) burst('sparkle', p.x, p.y, 1);
        if (st.stroke > 180) { st.stroke = 0; sfx('heal'); care(tool); }
      }
    }

    function tossBerry(item) {
      st.berry = { x: W / 2, y: H * 0.35, vx: (Math.random() < 0.5 ? -1 : 1) * (90 + Math.random() * 80), vy: -90, item, landed: false, carried: false };
      st.state = 'fetch'; sfx('blip');
    }

    // ---------- loop ----------
    let raf = 0, last = 0, closed = false;
    function update(dt) {
      st.t += dt; st.ft += dt;
      st.hop = Math.max(0, st.hop - dt * 2.5);
      if (st.wet > 0 && Math.random() < dt * 4 * st.wet) { const g = geom(); burst('drip', g.left + Math.random() * (g.right - g.left), g.top + g.tall * 0.6, 1); }
      // a tossed berry: they run to it, pick it up, bring it back, then eat it
      const b = st.berry;
      if (b && !b.carried) {
        if (!b.landed) { b.vy += 300 * dt; b.x += b.vx * dt; b.y += b.vy * dt; if (b.y >= FLOOR - 3) { b.y = FLOOR - 3; b.landed = true; } b.x = Math.max(20, Math.min(W - 20, b.x)); }
        const dx = b.x - st.x;
        st.flip = dx < 0;
        const sp = 70 + (speciesOf(app.idx, c())?.baseStats?.spe ?? 50) * 0.8;
        if (b.landed && Math.abs(dx) < 6) { b.carried = true; st.state = 'return'; say('Got it!'); }
        else st.x += Math.sign(dx) * Math.min(Math.abs(dx), sp * dt);
      } else if (b && b.carried) {
        const dx = W / 2 - st.x;
        st.flip = dx < 0;
        if (Math.abs(dx) < 4) { st.state = 'eat'; st.berry = null; st.bites = 0; st.biteItem = b.item; st.biteT = 0; st.flip = false; }
        else st.x += Math.sign(dx) * Math.min(Math.abs(dx), (70 + (speciesOf(app.idx, c())?.baseStats?.spe ?? 50) * 0.8) * dt);
      }
      if (st.state === 'eat' && st.biteItem) {
        st.biteT += dt;
        if (st.biteT > 0.55) { st.biteT = 0; st.bites++; sfx('munch'); burst('crumb', mouth().x, mouth().y, 2); if (st.bites >= 3) { care('feed', { item: st.biteItem.id, favorite: st.biteItem.id === fav.berry }); st.biteItem = null; st.state = 'idle'; } }
      }
      // holding food in front of their mouth: bite by bite
      if (st.held?.kind === 'food' && st.cursor && st.state === 'idle') {
        const m = mouth(), g = geom();
        // anywhere in front of their face counts
        const near = st.cursor.x > g.left - 24 && st.cursor.x < g.right + 24 && st.cursor.y > g.top - 30 && st.cursor.y < g.top + g.tall * 0.65;
        st.flip = st.cursor.x < st.x;
        if (near) {
          st.feedT = (st.feedT ?? 0) + dt;
          if (st.feedT > 0.6) {
            st.feedT = 0; st.held.bites = (st.held.bites ?? 0) + 1; sfx('munch'); burst('crumb', m.x, m.y, 2);
            if (st.held.bites >= 3) { const it = st.held.item; st.held = null; care('feed', { item: it.id, favorite: it.id === fav.berry }); renderTools(); }
          }
        }
      }
      // holding a toy out: they follow it and bat at it
      if (st.held?.kind === 'toy' && st.cursor && st.state === 'idle') {
        const dx = st.cursor.x - st.x;
        st.flip = dx < 0;
        if (Math.abs(dx) > 30) st.x += Math.sign(dx) * Math.min(Math.abs(dx) - 30, 60 * dt);
        const g = geom();
        if (Math.abs(dx) < 50 && st.cursor.y > g.top - 30) {
          st.play += dt;
          if (Math.random() < dt * 3) st.hop = 0.8;
          if (st.play > 2.5) { st.play = 0; const it = st.held.item; care('play', { toy: it.id, toyName: it.name, favorite: it.id === fav.toy, item: it.kind === 'toy' ? it.id : undefined }); burst('note', st.x, g.top, 2); }
        }
      }
      st.x = Math.max(40, Math.min(W - 40, st.x));
      for (const f of st.fx) { f.life -= dt; f.x += f.vx * dt; f.y += f.vy * dt; if (f.kind === 'drip') f.vy += 200 * dt; }
      st.fx = st.fx.filter((f) => f.life > 0 && f.y < FLOOR + 4);
      for (const w of st.words) { w.life -= dt; w.y -= 12 * dt; }
      st.words = st.words.filter((w) => w.life > 0);
    }

    function draw() {
      ctx.imageSmoothingEnabled = false;
      // the scene, zoomed in on its lower middle
      ctx.drawImage(bg, 60, 60, 200, 113, 0, 0, W, H);
      ctx.fillStyle = 'rgba(10,8,30,.12)'; ctx.fillRect(0, FLOOR, W, H - FLOOR);
      const g = geom();
      const { e, f } = g;
      // shadow
      ctx.fillStyle = 'rgba(10,8,30,.28)';
      const sw = (g.right - g.left) * 0.8;
      ctx.beginPath(); ctx.ellipse(st.x, st.y + 1, sw / 2, 5, 0, 0, Math.PI * 2); ctx.fill();
      // creature
      const moving = st.state === 'fetch' || st.state === 'return';
      const anim = moving ? 'walk' : st.state === 'eat' || st.hop > 0 ? 'happy' : 'idle';
      const list = e.frames[anim] ?? e.frames.idle;
      const img = list[Math.floor(st.ft * (moving ? 8 : 2.5)) % list.length];
      const hop = Math.sin(st.hop * Math.PI) * 10;
      const x0 = st.x - f.size / 2 + (0.5 - (f.box.left + f.box.right) / 2) * f.size * (st.flip ? -1 : 1);
      const y0 = f.top - hop;
      ctx.save();
      ctx.imageSmoothingEnabled = img.width > f.size;
      if (st.flip) { ctx.translate(x0 + f.size, y0); ctx.scale(-1, 1); ctx.drawImage(img, 0, 0, f.size, f.size); } else ctx.drawImage(img, x0, y0, f.size, f.size);
      ctx.restore();
      // dirt and damp
      for (let i = 0; i < st.dirt; i++) {
        const s = spots[i % spots.length];
        ctx.fillStyle = 'rgba(96,70,40,.55)';
        ctx.beginPath(); ctx.arc(g.left + s.fx * (g.right - g.left), g.top + s.fy * g.tall - hop, s.r, 0, Math.PI * 2); ctx.fill();
      }
      if (st.wet > 0) {
        // water beads on their coat
        ctx.fillStyle = `rgba(190,225,255,${(0.9 * st.wet).toFixed(3)})`;
        for (let i = 0; i < 10; i++) { const s = spots[i % spots.length]; ctx.fillRect(Math.round(g.left + ((s.fx + i * 0.07) % 1) * (g.right - g.left)), Math.round(g.top + ((s.fy + i * 0.11) % 0.9) * g.tall - hop), 2, 3); }
      }
      // berry being fetched or carried
      const b = st.berry;
      if (b) { const p = b.carried ? mouth(g) : b; berryShape(p.x, p.y, b.item.color); }
      if (st.state === 'eat' && st.biteItem) { const m = mouth(g); berryShape(m.x, m.y, st.biteItem.color, 1 - st.bites / 3); }
      // effects
      for (const fx of st.fx) {
        ctx.globalAlpha = Math.min(1, fx.life);
        if (fx.kind === 'bubble') { ctx.strokeStyle = '#ffffff'; ctx.beginPath(); ctx.arc(fx.x, fx.y, 4, 0, Math.PI * 2); ctx.stroke(); }
        else if (fx.kind === 'drip') { ctx.fillStyle = '#7fb8ff'; ctx.fillRect(fx.x, fx.y, 2, 4); }
        else if (fx.kind === 'air') { ctx.fillStyle = 'rgba(255,255,255,.6)'; ctx.fillRect(fx.x, fx.y, 8, 1); }
        else if (fx.kind === 'crumb') { ctx.fillStyle = '#c98a3a'; ctx.fillRect(fx.x, fx.y, 2, 2); }
        else { ctx.fillStyle = fx.kind === 'heart' ? '#ff5d8f' : fx.kind === 'note' ? '#ffffff' : '#fff6a0'; ctx.font = '12px sans-serif'; ctx.fillText(fx.kind === 'heart' ? '♥' : fx.kind === 'note' ? '♪' : '✦', fx.x, fx.y); }
      }
      ctx.globalAlpha = 1;
      for (const w of st.words) {
        ctx.globalAlpha = Math.min(1, w.life);
        ctx.font = 'bold 13px sans-serif'; ctx.textAlign = 'center';
        ctx.fillStyle = 'rgba(10,8,30,.6)'; ctx.fillText(w.text, w.x + 1, w.y + 1);
        ctx.fillStyle = w.color; ctx.fillText(w.text, w.x, w.y);
        ctx.textAlign = 'start';
      }
      ctx.globalAlpha = 1;
      // what you're holding, at the pointer
      if (st.cursor && st.held) {
        if (st.held.kind === 'food') berryShape(st.cursor.x, st.cursor.y, st.held.item.color ?? '#c98a3a', 1 - (st.held.bites ?? 0) / 3);
        else toyShape(st.cursor.x, st.cursor.y, st.held.item.id);
      } else if (st.cursor && st.tool !== 'hand') toolShape(st.cursor.x, st.cursor.y, st.tool);
    }
    function berryShape(x, y, color, left = 1) {
      const r = Math.max(2, 7 * left);
      ctx.fillStyle = color || '#c0306a'; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#3f7a35'; ctx.fillRect(x - 1, y - r - 4, 3, 4);
    }
    function toyShape(x, y, id) {
      const col = { ball: '#e5484d', feather: '#f2a33a', plush: '#b07ad8', bell: '#ffd23f', ribbon: '#ff6fa8' }[id] ?? '#5b9bd5';
      ctx.fillStyle = col;
      if (id === 'feather') { ctx.fillRect(x - 1, y, 2, 18); ctx.beginPath(); ctx.ellipse(x, y - 4, 4, 9, 0.3, 0, Math.PI * 2); ctx.fill(); }
      else if (id === 'ribbon') { for (let i = 0; i < 6; i++) ctx.fillRect(x + Math.sin(st.t * 8 + i) * 6, y + i * 3, 4, 3); }
      else { ctx.beginPath(); ctx.arc(x, y, 7, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#ffffff'; ctx.fillRect(x - 3, y - 4, 2, 2); }
    }
    function toolShape(x, y, tool) {
      ctx.save(); ctx.translate(x, y);
      if (tool === 'sponge') { ctx.fillStyle = '#ffd23f'; ctx.fillRect(-9, -6, 18, 12); ctx.fillStyle = '#e6b800'; ctx.fillRect(-6, -3, 2, 2); ctx.fillRect(2, 1, 2, 2); }
      else if (tool === 'towel') { ctx.fillStyle = '#7fc8ff'; ctx.fillRect(-11, -7, 22, 14); ctx.fillStyle = '#ffffff'; ctx.fillRect(-11, 3, 22, 2); }
      else if (tool === 'dryer') { ctx.fillStyle = '#e9e9f2'; ctx.fillRect(-4, -6, 16, 9); ctx.fillStyle = '#9a9ab0'; ctx.fillRect(4, 3, 4, 10); ctx.fillStyle = '#5b5b70'; ctx.fillRect(-6, -5, 2, 7); }
      else if (tool === 'brush') { ctx.fillStyle = '#a0623a'; ctx.fillRect(-10, -4, 20, 6); ctx.fillStyle = '#f4e3c3'; for (let i = -9; i < 10; i += 3) ctx.fillRect(i, 2, 1, 5); }
      else if (tool === 'comb') { ctx.fillStyle = '#b58cff'; ctx.fillRect(-10, -4, 20, 4); for (let i = -9; i < 10; i += 2) ctx.fillRect(i, 0, 1, 6); }
      ctx.restore();
    }

    function loop(t) {
      if (closed) return;
      const dt = Math.min(0.05, (t - (last || t)) / 1000); last = t;
      update(dt); draw();
      raf = requestAnimationFrame(loop);
    }
    raf = requestAnimationFrame(loop);

    // ---------- pointer ----------
    const toLocal = (ev) => { const r = canvas.getBoundingClientRect(); return { x: ((ev.clientX - r.left) / r.width) * W, y: ((ev.clientY - r.top) / r.height) * H }; };
    canvas.addEventListener('pointermove', (ev) => {
      const p = toLocal(ev), prev = st.cursor;
      st.cursor = p;
      if (st.down && prev && !st.held) useTool(p, Math.hypot(p.x - prev.x, p.y - prev.y));
    });
    canvas.addEventListener('pointerdown', (ev) => { st.down = true; st.cursor = toLocal(ev); canvas.setPointerCapture?.(ev.pointerId); });
    const up = () => { st.down = false; };
    canvas.addEventListener('pointerup', up);
    canvas.addEventListener('pointercancel', up);
    canvas.addEventListener('pointerleave', () => { st.cursor = null; st.down = false; });

    // ---------- the bars ----------
    function renderStatus() {
      const cr = c();
      const n = cr.needs ?? {};
      const known = (k) => cr.firsts?.[`fav:${k}`];
      const favBerry = fav.berry && app.idx.items.get(fav.berry);
      const favToy = toys.find((t) => t.id === fav.toy);
      mount(status,
        h('strong', null, displayName(app.idx, cr)),
        h('span', null, mood(cr).label),
        ['fullness', 'joy', 'hygiene', 'energy'].map((k) => h('span', { class: 'care-need' }, `${{ fullness: 'Full', joy: 'Joy', hygiene: 'Clean', energy: 'Energy' }[k]} ${Math.round(n[k] ?? 0)}`)),
        h('span', { class: 'care-likes' }, `Loves: ${known(fav.berry) && favBerry ? favBerry.name : '?'} · ${known(fav.toy) && favToy ? favToy.name : '?'}`));
    }
    function renderTools() {
      const pick = (kind, item) => { st.held = st.held?.item?.id === item.id ? null : { kind, item }; st.tool = 'hand'; renderTools(); };
      mount(bar,
        h('div', { class: 'care-row' },
          TOOLS.map(([id, label, hint]) => h('button', { class: `care-btn ${st.tool === id && !st.held ? 'on' : ''}`, title: hint, onclick: () => { st.tool = id; st.held = null; renderTools(); } }, label)),
          h('span', { class: 'spacer' }),
          h('button', { class: 'care-btn', onclick: close }, 'Back to the yard')),
        h('div', { class: 'care-row' },
          h('span', { class: 'care-label' }, 'Toys'),
          toys.map((t) => h('button', { class: `care-btn small ${st.held?.item?.id === t.id ? 'on' : ''}`, onclick: () => pick('toy', t) }, t.name))),
        h('div', { class: 'care-row' },
          h('span', { class: 'care-label' }, 'Food'),
          foods().length ? foods().slice(0, 10).map((it) => h('span', { class: 'care-food' },
            h('button', { class: `care-btn small ${st.held?.item?.id === it.id ? 'on' : ''}`, title: 'Hold it in front of them', onclick: () => pick('food', it) }, `${it.name}${it.unlimited ? '' : ` ×${app.save.inventory[it.id] ?? 0}`}`),
            h('button', { class: 'care-btn small ghost', title: 'Toss it: they fetch it back before eating', disabled: st.state !== 'idle', onclick: () => { if (st.state === 'idle') tossBerry(it); } }, 'Toss'))) : h('span', { class: 'care-label' }, 'No food. Grow berries on the farm.')),
        h('div', { class: 'care-hint' }, st.held ? (st.held.kind === 'food' ? 'Hold the food in front of their mouth.' : 'Wave the toy near them.') : TOOLS.find((t) => t[0] === st.tool)?.[2]));
    }
    function close() {
      closed = true; cancelAnimationFrame(raf);
      root.remove(); window.removeEventListener('keydown', onKey);
      sfx('back');
      resolve();
    }
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    window.addEventListener('keydown', onKey);
    renderStatus(); renderTools();
    if (st.dirt >= 3) setTimeout(() => say('A bit grubby… time for a wash?', '#f4e3c3'), 600);
    creatureCry(speciesOf(app.idx, c()), c());
  });
}
