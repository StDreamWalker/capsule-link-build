// Quality time on the PC: the shared care room (shared/ui/careRoom.js) with the PC's own art.
import { openCareRoom as openShared } from '../../../../shared/ui/careRoom.js';
import { clothesImg } from './dressUp.js';

export function openCareRoom(app, uid, opts) {
  return openShared(app, uid, { ...opts, resolveTexture: (p) => app.textures[p.toLowerCase()] ?? null, clothesImg });
}
