// Settings → Debug: add and remove creatures freely (to check sprites, cards, the R.A.N.C.H.)
// and see every species' sprite at a glance. Creatures made here are marked so they can all be
// cleared again in one go.
import { h, mount, toast, confirmDialog, refocus } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { sfx } from '../../../../shared/ui/audio.js';
import { openCreatureEditor } from './creatureEditor.js';
import { baseSpeciesOf, createCreature, addCreature, firstFreeBoxSlot, releaseCreature, list, party, displayName, makeEgg, EGG_DEFAULT_STEPS } from '../../../../shared/engine/index.js';

const SLOTS = 30;

export function debugPanel(app, rerender) {
  const st = debugPanel.state ?? (debugPanel.state = { q: '', level: 30, shiny: false, dest: 'box', checkPose: 'idle', missingOnly: false, page: 0 });
  const el = h('div', { class: 'debug-panel' });
  const species = () => app.idx.ds.species;

  function ensureRoom(save, n) {
    // add boxes until n more creatures fit
    const free = () => save.boxes.length * SLOTS - list(save).filter((c) => c.location.kind === 'box').length;
    while (free() < n) save.boxes.push({ name: `Box ${save.boxes.length + 1}`, biome: save.boxes[save.boxes.length % 12]?.biome ?? 'meadow', wallpaper: 'clean' });
  }
  function make(sp) {
    // a form (Deoxys-Speed) is the base species in that form; a regional variant is its own species
    const base = baseSpeciesOf(app.idx, sp);
    const c = createCreature(app.idx, base.id, { level: Math.max(1, Math.min(app.idx.ds.rules.maxLevel ?? 100, st.level)), trainer: app.save.trainer?.name, metHow: 'Made with the debug tools' });
    c.debug = true;
    if (base !== sp) c.formId = sp.id;
    if (st.shiny) c.shiny = true;
    if (st.egg) makeEgg(c, EGG_DEFAULT_STEPS);
    return c;
  }
  function addOne(sp) {
    const c = make(sp);
    let where = 'a box';
    app.commit((s) => {
      if (st.dest === 'party' && party(s).length < (app.idx.ds.rules.partySize ?? 6)) { addCreature(s, c, { kind: 'party', slot: party(s).length }); where = 'the party'; }
      else if (st.dest === 'ranch') { addCreature(s, c, { kind: 'ranch' }); where = 'free range'; }
      else { ensureRoom(s, 1); addCreature(s, c, firstFreeBoxSlot(s)); where = s.boxes[c.location.box]?.name ?? 'a box'; }
    }, 'debug');
    sfx('blip');
    app.say(`${displayName(app.idx, c)} (Lv. ${c.level}) added to ${where}.`);
  }
  async function addAll() {
    const all = species();
    if (!(await confirmDialog(`Add all ${all.length} species?`, 'One of each goes into the boxes (new boxes are added if needed). They are marked as debug creatures, so “Remove debug creatures” clears them again.', { ok: 'Add them' }))) return;
    app.commit((s) => {
      ensureRoom(s, all.length);
      for (const sp of all) { const c = make(sp); addCreature(s, c, firstFreeBoxSlot(s)); }
    }, 'debug');
    sfx('level');
    toast(`Added ${all.length} creatures.`, 'ok');
  }
  async function removeWhere(test, what) {
    const doomed = list(app.save).filter(test);
    if (!doomed.length) { toast(`No ${what} to remove.`); return; }
    if (!(await confirmDialog(`Remove ${doomed.length} ${what}?`, 'They are deleted for good (the daily backup still has them).', { ok: 'Remove', danger: true }))) return;
    app.commit((s) => { for (const c of doomed) releaseCreature(s, c.uid); }, 'debug');
    sfx('back');
    toast(`Removed ${doomed.length}.`, 'ok');
  }

  function render() {
    const q = st.q.trim().toLowerCase();
    const all = species();
    const shown = all.filter((sp) => !q || sp.name.toLowerCase().includes(q) || String(sp.no) === q || sp.id.includes(q));
    const missing = all.filter((sp) => !app.bank.find(sp, st.checkPose === 'idle' ? 'idle' : st.checkPose));
    const grid = (st.missingOnly ? shown.filter((sp) => missing.includes(sp)) : shown);
    const per = 120, pages = Math.max(1, Math.ceil(grid.length / per));
    st.page = Math.min(st.page, pages - 1);
    const pageItems = grid.slice(st.page * per, st.page * per + per);
    const debugCount = list(app.save).filter((c) => c.debug).length;
    mount(el,
      h('section', { class: 'panel col span-all' },
        h('h2', null, 'Add creatures'),
        h('p', { class: 'dim' }, 'Click any species to add one. Handy for checking sprites, ID cards and the R.A.N.C.H. without catching anything.'),
        h('div', { class: 'row wrap' },
          h('input', { type: 'search', placeholder: 'Search species, number or id…', value: st.q, oninput: (e) => { st.q = e.target.value; st.page = 0; render(); refocus(el.querySelector('input[type=search]')); } }),
          h('label', { class: 'row' }, h('span', { class: 'dim' }, 'Level'), h('input', { type: 'number', min: 1, max: 255, value: st.level, style: { width: '80px' }, onchange: (e) => { st.level = Number(e.target.value) || 5; } })),
          h('label', { class: 'row' }, h('span', { class: 'dim' }, 'Into'),
            h('select', { onchange: (e) => { st.dest = e.target.value; } }, [['box', 'Boxes'], ['party', 'Party'], ['ranch', 'Free range']].map(([v, l]) => h('option', { value: v, selected: v === st.dest }, l)))),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: st.shiny, onchange: (e) => { st.shiny = e.target.checked; } }), 'Shiny'),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: !!st.egg, onchange: (e) => { st.egg = e.target.checked; } }), 'As an egg'),
          h('span', { class: 'spacer' }),
          h('button', { class: 'btn', onclick: addAll }, `Add one of every species (${all.length})`)),
        h('div', { class: 'row wrap' },
          h('span', { class: 'dim' }, `Sprite check: ${all.length - missing.length} of ${all.length} species have ${st.checkPose === 'idle' ? 'a front sprite' : `a ${st.checkPose} sprite`}.`),
          h('select', { onchange: (e) => { st.checkPose = e.target.value; render(); } }, [['idle', 'Front'], ['back', 'Back'], ['walk', 'Walk'], ['sleep', 'Sleep'], ['happy', 'Happy']].map(([v, l]) => h('option', { value: v, selected: v === st.checkPose }, l))),
          h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: st.missingOnly, onchange: (e) => { st.missingOnly = e.target.checked; st.page = 0; render(); } }), 'Only species missing it')),
        h('div', { class: 'dex-grid' }, pageItems.map((sp) => {
          const has = !missing.includes(sp);
          return h('button', { class: `dex-cell ${has ? '' : 'missing'}`, title: `#${sp.no} ${sp.name}${has ? '' : ' — no sprite yet (generated art shown)'}`, onclick: () => addOne(sp) },
            spriteCanvas(app.bank, sp.id, { scale: 2, anim: st.checkPose }),
            h('span', { class: 'micro mono-num' }, `#${String(sp.no).padStart(3, '0')}`),
            h('span', { class: 'micro ell' }, sp.name),
            baseSpeciesOf(app.idx, sp) !== sp ? h('span', { class: 'micro dim' }, 'form') : null);
        })),
        pages > 1 ? h('div', { class: 'row center-items' },
          h('button', { class: 'btn small', disabled: st.page === 0, onclick: () => { st.page--; render(); } }, '◀'),
          h('span', { class: 'dim' }, `Page ${st.page + 1} of ${pages}`),
          h('button', { class: 'btn small', disabled: st.page >= pages - 1, onclick: () => { st.page++; render(); } }, '▶')) : null),
      h('section', { class: 'panel col span-all' },
        h('h2', null, 'Edit a creature'),
        h('p', { class: 'dim' }, 'Change anything about someone you have, like a save editor: species and form, level, identity numbers, shininess, genes and effort, moves and PP, temperament, ability, held item, size, cry pitch, needs, memories and likes.'),
        h('div', { class: 'row wrap' },
          h('select', { id: 'dbg-edit' }, list(app.save).filter((c) => !['phone', 'capsule'].includes(c.location.kind)).map((c) => h('option', { value: c.uid }, `${displayName(app.idx, c)} · Lv. ${c.level}${c.shiny ? ' ★' : ''}`))),
          h('button', { class: 'btn primary', onclick: async () => { const uid = el.querySelector('#dbg-edit').value; if (uid && await openCreatureEditor(app, uid)) render(); } }, 'Edit'))),
      h('section', { class: 'panel col span-all' },
        h('h2', null, 'Remove creatures'),
        h('p', { class: 'dim' }, `One at a time: select it in Storage and press Release. In bulk: ${debugCount} were made here.`),
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn', onclick: () => removeWhere((c) => c.debug, 'debug creatures') }, 'Remove debug creatures'),
          h('select', { id: 'dbg-box' }, app.save.boxes.map((b, k) => h('option', { value: k }, b.name))),
          h('button', { class: 'btn', onclick: () => { const k = Number(el.querySelector('#dbg-box').value); removeWhere((c) => c.location.kind === 'box' && c.location.box === k, `creatures from ${app.save.boxes[k]?.name}`); } }, 'Empty this box'),
          h('button', { class: 'btn danger', onclick: () => removeWhere((c) => !['phone', 'capsule'].includes(c.location.kind), 'creatures (everyone on this PC)') }, 'Remove everyone'))));
  }
  render();
  void rerender;
  return { el, update: render };
}
