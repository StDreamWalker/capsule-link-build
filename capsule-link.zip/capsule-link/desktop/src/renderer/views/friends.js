// Friends (preview): sign in to a Capsule Link home server (server/home-server.mjs, which you can run on
// an old computer), add friends by username or trainer code, message them, send gifts, trade, visit their
// yards through your Link gate, and share creature data they're missing. Everything else in the app
// works without it.
import { h, mount, toast, chooseDialog, confirmDialog, promptDialog } from '../../../../shared/ui/dom.js';
import { spriteCanvas } from '../../../../shared/ui/art.js';
import { sfx } from '../../../../shared/ui/audio.js';
import { fetchMissingSpecies, shareSpecies } from '../../../../shared/net/friends.js';
import { friendsSession, saveAcct, ago } from '../friendsSession.js';
import { shareMyDatalab, offerFriendData, presetMenu } from '../friendsData.js';
import {
  displayName, list, itemInfo, firstFreeBoxSlot, normalizeDataset, ranchSnapshot, boxContents, readSnapshot,
} from '../../../../shared/engine/index.js';


export function friendsView(app) {
  const el = h('div', { class: 'friends' });
  // one connection for the whole app (Battle Link and the home screen use it too)
  const S = friendsSession(app);
  let acct = S.acct;
  let client = S.client;
  let state = { me: null, friends: null, inbox: null, sel: null, thread: [], busy: false, error: '' };

  const run = async (fn, okMsg) => {
    state.busy = true; render();
    try { const r = await fn(); if (okMsg) toast(okMsg, 'ok'); return r; } catch (e) { toast(e.message, 'err'); return null; } finally { state.busy = false; render(); }
  };
  async function refresh() {
    if (!client.token) return;
    try {
      const [me, fr, inbox] = await Promise.all([client.me(), client.friends(), client.inbox()]);
      state.me = me.user; state.friends = fr; S.friends = fr; state.inbox = inbox; state.error = '';
      if (state.sel) state.thread = (await client.messages(state.sel)).messages;
      // your server trainer code on your card's "Other trainer IDs"
      const card = app.save.trainer?.card;
      if (card && me.user.code && !(card.history ?? []).some((x) => x.num === me.user.code.replace(/ /g, '').slice(0, 14))) {
        app.commit((s) => { const c = s.trainer.card; c.history = [...(c.history ?? []), { num: me.user.code.replace(/ /g, '').slice(0, 14), region: 'Online', issued: Date.now() }].slice(-8); }, 'card', { quiet: true });
      }
    } catch (e) {
      if (e.status === 401) { client.token = null; acct.token = null; saveAcct(acct); }
      state.error = e.message;
    }
    render();
  }
  const NOTE = { message: (n) => `New message from ${n.from}`, gift: (n) => `${n.from} sent you something!`, request: (n) => `${n.from} wants to be friends`, friend: (n) => `You and ${n.from} are friends now`, trade: (n) => `${n.from}: trade update` };
  const unsub = S.on((n) => {
    if (n.what === 'refresh') { state.friends = S.friends ?? state.friends; render(); return; }
    if (NOTE[n.what]) { sfx('alert'); toast(NOTE[n.what](n), 'ok'); refresh(); }
  });

  // ---------- signing in ----------
  function serverForm() {
    const addr = h('input', { type: 'text', value: acct.server ?? '', placeholder: 'http://192.168.1.20:47830', spellcheck: false });
    return h('section', { class: 'panel' },
      h('h2', null, 'Server'),
      h('p', { class: 'dim' }, 'Friends connect through a Capsule Link home server. Anyone can host one from the PC app (Settings → Debug → Host a server from this PC), on an old computer for example. Put its address here.'),
      h('div', { class: 'row' }, addr, h('button', { class: 'btn', onclick: () => run(async () => {
        acct.server = addr.value.trim();
        client = S.setAccount(acct);
        const info = await client.info();
        state.serverInfo = info;
      }, 'Connected to the server.') }, 'Connect')),
      state.serverInfo ? h('p', { class: 'micro dim' }, `${state.serverInfo.name} · ${state.serverInfo.trainers} trainer${state.serverInfo.trainers === 1 ? '' : 's'}`) : null);
  }
  function signInForm() {
    const user = h('input', { type: 'text', placeholder: 'username', autocomplete: 'username', value: acct.username ?? '' });
    const pass = h('input', { type: 'password', placeholder: 'password (8+ characters)', autocomplete: 'current-password' });
    const done = (r) => { acct.token = r.token; acct.username = r.user.username; client = S.setAccount(acct); state.me = r.user; refresh(); };
    return h('section', { class: 'panel' },
      h('h2', null, 'Your account'),
      h('p', { class: 'dim' }, 'Your username is how friends find you. You also get a trainer code from the server, added to your card’s other IDs.'),
      h('div', { class: 'form-grid two' }, h('label', { class: 'field' }, h('span', null, 'Username'), user), h('label', { class: 'field' }, h('span', null, 'Password'), pass)),
      h('div', { class: 'row' },
        h('button', { class: 'btn primary', disabled: state.busy, onclick: () => run(async () => done(await client.login(user.value, pass.value))) }, 'Sign in'),
        h('button', { class: 'btn', disabled: state.busy, onclick: () => run(async () => done(await client.signup(user.value, pass.value, app.save.trainer?.name)), 'Account made. Welcome!') }, 'Create account')));
  }

  // ---------- friends ----------
  function friendsPanel() {
    const fr = state.friends ?? { friends: [], incoming: [], outgoing: [] };
    const add = h('input', { type: 'text', placeholder: 'username or trainer code' });
    return h('section', { class: 'panel fr-list' },
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, 'Friends'), h('button', { class: 'btn small', onclick: refresh }, 'Refresh')),
      h('div', { class: 'row' }, add, h('button', { class: 'btn small', onclick: () => run(() => client.request(add.value.trim()), 'Friend request sent.').then(refresh) }, 'Add')),
      fr.incoming.length ? [h('h3', null, 'Wants to be friends'), fr.incoming.map((u) => h('div', { class: 'fr-row' }, h('span', { class: 'grow' }, `${u.trainerName} (@${u.username})`), h('button', { class: 'btn small primary', onclick: () => run(() => client.accept(u.username), `You and ${u.trainerName} are friends!`).then(refresh) }, 'Accept')))] : null,
      fr.friends.length ? [...fr.friends].sort((a, b) => (b.online ? 1 : 0) - (a.online ? 1 : 0) || (b.seenAt ?? 0) - (a.seenAt ?? 0)).map((u) => h('button', { class: `fr-row ${state.sel === u.username ? 'on' : ''}`, onclick: async () => { state.sel = u.username; state.thread = []; render(); await refresh(); } },
        h('span', { class: `fr-dot ${u.online ? 'on' : ''}`, title: u.online ? 'Online now' : `Last seen ${ago(u.seenAt)}` }),
        h('span', { class: 'grow' }, u.trainerName), h('span', { class: 'micro dim' }, u.online ? 'online' : u.seenAt ? ago(u.seenAt) : `@${u.username}`)))
        : h('p', { class: 'dim' }, 'No friends yet. Add someone by their username or trainer code.'),
      fr.outgoing.length ? h('p', { class: 'micro dim' }, `Waiting on: ${fr.outgoing.map((u) => u.username).join(', ')}`) : null);
  }

  function threadPanel() {
    const f = state.friends?.friends.find((u) => u.username === state.sel);
    if (!f) return h('section', { class: 'panel fr-thread' }, h('p', { class: 'dim' }, 'Pick a friend to message them, send a gift, trade or visit their yard.'));
    const input = h('input', { type: 'text', placeholder: `Message ${f.trainerName}…`, maxLength: 500, onkeydown: (e) => { if (e.key === 'Enter') sendMsg(); } });
    const sendMsg = () => { const t = input.value.trim(); if (!t) return; input.value = ''; run(() => client.say(f.username, t)).then(refresh); };
    return h('section', { class: 'panel fr-thread' },
      h('div', { class: 'row' }, h('h2', { class: 'grow' }, f.trainerName), h('span', { class: 'micro dim' }, `${f.online ? '● online now' : `last seen ${ago(f.seenAt)}`} · trainer code ${f.code}`)),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small primary', title: 'Invite them to a battle on Showdown (Battle Link)', onclick: () => { app.battleInvite = f.username; app.go('battle'); } }, 'Battle'),
        h('button', { class: 'btn small', onclick: () => sendGift(f) }, 'Send a gift'),
        h('button', { class: 'btn small', onclick: () => offerTrade(f) }, 'Offer a trade'),
        h('button', { class: 'btn small', onclick: () => visit(f) }, 'Visit their yard'),
        h('button', { class: 'btn small danger', onclick: async () => { if (await confirmDialog('Remove friend?', `${f.trainerName} won’t be your friend on this server any more.`, { ok: 'Remove', danger: true })) run(() => client.remove(f.username)).then(() => { state.sel = null; refresh(); }); } }, 'Remove')),
      h('div', { class: 'fr-msgs' }, state.thread.length ? state.thread.map((m) => h('div', { class: `fr-msg ${m.from === state.me?.username ? 'mine' : ''}` }, h('span', null, m.text), h('small', null, ago(m.at)))) : h('p', { class: 'dim' }, 'Say hello!')),
      h('div', { class: 'row' }, input, h('button', { class: 'btn primary', onclick: sendMsg }, 'Send')));
  }

  // ---------- gifts, trades, visits ----------
  async function sendGift(f) {
    const bag = Object.entries(app.save.inventory ?? {}).filter(([id, n]) => n > 0 && !itemInfo(app.idx, id)?.unlimited && itemInfo(app.idx, id)?.kind !== 'blueprint');
    const id = await chooseDialog(`A gift for ${f.trainerName}`, [{ value: '__coins', label: 'Coins', detail: `${Math.floor(app.save.wallet ?? 0)} in your wallet` }, ...bag.map(([iid, n]) => ({ value: iid, label: itemInfo(app.idx, iid)?.name ?? iid, detail: `× ${n}` }))], { empty: 'Nothing to give.' });
    if (!id) return;
    const amount = Number(await promptDialog(id === '__coins' ? 'How many coins?' : 'How many?', 'Amount', id === '__coins' ? '50' : '1', { ok: 'Send' }));
    if (!Number.isInteger(amount) || amount <= 0) return;
    const have = id === '__coins' ? Math.floor(app.save.wallet ?? 0) : app.save.inventory[id] ?? 0;
    if (amount > have) { toast('You don’t have that many.', 'err'); return; }
    // it leaves your bag when the server has it
    const gift = id === '__coins' ? { coins: amount } : { items: { [id]: amount } };
    const r = await run(() => client.gift(f.username, { ...gift, note: '' }), `Sent to ${f.trainerName}!`);
    if (r) app.commit((s) => { if (id === '__coins') s.wallet -= amount; else s.inventory[id] -= amount; }, 'gift');
  }
  const pickCreature = (title) => chooseDialog(title, list(app.save).filter((c) => !c.egg && c.location?.kind === 'box').map((c) => ({ value: c.uid, label: displayName(app.idx, c), detail: `Lv. ${c.level}`, el: spriteCanvas(app.bank, c, { scale: 1 }) })), { empty: 'Only creatures in your boxes can be traded.' });
  async function offerTrade(f) {
    const uid = await pickCreature(`Offer someone to ${f.trainerName}`);
    if (!uid) return;
    const want = await promptDialog('What would you like back?', 'A note for them', '', { ok: 'Offer', maxLength: 140 });
    if (want == null) return;
    const c = app.save.creatures[uid];
    if (!(await confirmDialog('Offer this trade?', `${displayName(app.idx, c)} goes to the server and waits for ${f.trainerName}. If they decline, they come back to you.`, { ok: 'Offer' }))) return;
    const r = await run(() => client.offerTrade(f.username, { creature: JSON.parse(JSON.stringify(c)) }, want), 'Trade offered.');
    if (r) app.commit((s) => { delete s.creatures[uid]; }, 'trade-out');
  }
  async function visit(f) {
    // their Data Lab: use it for the visit (or a saved preset of it), or keep yours
    const go = await offerFriendData(app, client, f, { onProgress: (a, b, what) => { state.progress = `${what}: ${a} of ${b}`; render(); } }).catch((e) => { toast(e.message, 'err'); return true; });
    state.progress = null;
    if (!go) return;
    const snap = await run(() => client.visitRanch(f.username));
    if (!snap) return;
    const r = readSnapshot(app.idx, snap);
    if (!r.ok) { toast(r.reason, 'err'); return; }
    await bringMissing(r.snap.creatures.map((g) => g.speciesId));
    app.pendingGuests = r.snap;
    toast(`Heading to your Link gate: ${f.trainerName}’s creatures are coming over.`, 'ok');
    app.go('ranch');
  }
  async function shareYard() {
    const keys = [...app.save.boxes.keys()].filter((k) => (app.save.boxes[k].build?.features ?? []).some((x) => x.bp === 'link-gate'));
    if (!keys.length) { toast('Build a Link gate in a yard first (blueprint from the Market).', 'err'); return; }
    const key = keys.length === 1 ? keys[0] : await chooseDialog('Which yard?', keys.map((k) => ({ value: k, label: app.save.boxes[k].name })));
    if (key == null) return;
    await run(() => client.shareRanch(ranchSnapshot(app.idx, app.save, key, boxContents(app.save, key).filter(Boolean))), 'Your yard is shared. Friends can visit it now.');
  }
  // data and sprites for creatures you don't have (sprites you already have are never re-downloaded)
  async function bringMissing(ids) {
    const r = await fetchMissingSpecies(client, ids, {
      haveSpecies: (id) => app.idx.species.has(id),
      haveSprite: (p) => !!app.textures[p.toLowerCase()],
      addSpecies: async (rec) => { const ds = JSON.parse(JSON.stringify(app.dataset)); if (!ds.species.some((x) => x.id === rec.id)) ds.species.push(rec); await app.saveDataset(normalizeDataset(ds)); },
      saveSprite: async (p, bytes) => { app.textures = await app.platform.importTexture(p, bytes); app.bank.setResolver((q) => app.textures[q.toLowerCase()] ?? null); },
    }).catch((e) => { toast(e.message, 'err'); return null; });
    if (r?.added.length) toast(`Brought in ${r.added.length} creature${r.added.length > 1 ? 's' : ''} you didn’t have (${r.sprites} picture${r.sprites === 1 ? '' : 's'}).`, 'ok');
    return r;
  }
  async function shareData() {
    const ids = [...new Set(list(app.save).map((c) => c.speciesId))];
    const recs = ids.map((id) => app.dataset.species.find((s) => s.id === id)).filter(Boolean);
    const n = await run(() => shareSpecies(client, recs, async (p) => { const url = app.textures[p.toLowerCase()]; if (!url) return null; try { return new Uint8Array(await (await fetch(url)).arrayBuffer()); } catch { return null; } }));
    if (n) toast(`Shared data for ${n} kinds of creature. Friends who don’t have them can fetch them now.`, 'ok');
  }
  async function open(item) {
    if (item.kind === 'gift') {
      const r = await run(() => client.claimGift(item.id));
      if (!r) return;
      const g = r.gift;
      if (g.creature) await bringMissing([g.creature.speciesId]);
      app.commit((s) => {
        for (const [id, n] of Object.entries(g.items ?? {})) s.inventory[id] = (s.inventory[id] ?? 0) + n;
        if (g.coins) s.wallet = (s.wallet ?? 0) + g.coins;
        if (g.creature && app.idx.species.has(g.creature.speciesId)) {
          const c = { ...g.creature };
          if (s.creatures[c.uid]) c.uid = `${c.uid}-${Date.now().toString(36)}`;
          c.location = firstFreeBoxSlot(s) ?? { kind: 'ranch' };
          c.memories = [...(c.memories ?? []), { t: Date.now(), text: `Arrived from ${g.from}.`, core: true }];
          s.creatures[c.uid] = c;
        }
      }, 'gift-in');
      sfx('level'); toast(`Opened ${g.from}’s ${g.creature ? 'trade' : 'gift'}!`, 'ok');
    } else if (item.kind === 'trade') {
      const yes = await confirmDialog(`${item.from} offers ${item.give.creature ? displayName(app.idx, item.give.creature) : 'a trade'}`, `${item.want ? `They’d like: “${item.want}”. ` : ''}Accept and pick someone to send back, or decline (their offer goes back to them).`, { ok: 'Accept…', cancel: 'Decline' });
      if (!yes) { await run(() => client.respondTrade(item.id, false), 'Declined.'); refresh(); return; }
      const uid = await pickCreature(`Who goes to ${item.from}?`);
      if (!uid) return;
      const c = app.save.creatures[uid];
      const r = await run(() => client.respondTrade(item.id, true, { creature: JSON.parse(JSON.stringify(c)) }));
      if (!r) return;
      app.commit((s) => { delete s.creatures[uid]; }, 'trade-out');
      const got = await run(() => client.claimTrade(item.id));
      if (got?.trade?.give?.creature) {
        const nc = got.trade.give.creature;
        await bringMissing([nc.speciesId]);
        app.commit((s) => { const x = { ...nc, location: firstFreeBoxSlot(s) ?? { kind: 'ranch' } }; if (s.creatures[x.uid]) x.uid = `${x.uid}-${Date.now().toString(36)}`; x.memories = [...(x.memories ?? []), { t: Date.now(), text: `Traded from ${item.from}.`, core: true }]; s.creatures[x.uid] = x; }, 'trade-in');
        sfx('level'); toast(`${displayName(app.idx, nc)} arrived from ${item.from}!`, 'ok');
      }
    }
    refresh();
  }
  function inboxPanel() {
    const items = (state.inbox?.inbox ?? []).filter((x) => x.id);
    return h('section', { class: 'panel' },
      h('h2', null, 'Inbox'),
      items.length ? items.map((x) => h('div', { class: 'fr-row' },
        h('span', { class: 'grow' }, x.kind === 'trade' ? `Trade offer from ${x.from}` : `Gift from ${x.from}${x.note ? `: “${x.note}”` : ''}`),
        h('span', { class: 'micro dim' }, ago(x.at)),
        h('button', { class: 'btn small primary', onclick: () => open(x) }, x.kind === 'trade' ? 'Look' : 'Open')))
        : h('p', { class: 'dim' }, 'Nothing waiting.'),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn small', onclick: shareYard }, 'Share my yard'),
        h('button', { class: 'btn small', title: 'So friends can fetch creatures (and pictures) they don’t have', onclick: shareData }, 'Share my creature data'),
        h('button', { class: 'btn small', title: 'Your whole Data Lab (species, moves, items… and the pictures that go with them), so friends can visit with it', onclick: async () => {
          const r = await run(() => shareMyDatalab(app, client, { onProgress: (a, b, what) => { state.progress = `${what}: ${a} of ${b}`; render(); } }));
          state.progress = null; render();
          if (r) toast(`Your Data Lab is shared (${r.pictures} pictures, ${r.uploaded} new). Friends visiting you can use it.`, 'ok');
        } }, 'Share my Data Lab'),
        h('button', { class: 'btn small', title: 'Switch to a friend’s Data Lab you saved', onclick: () => presetMenu(app) }, 'Friends’ presets')),
      state.progress ? h('p', { class: 'micro dim' }, state.progress) : null);
  }

  function render() {
    const signedIn = !!client.token;
    mount(el,
      h('header', { class: 'fr-head' },
        h('div', null, h('h1', null, 'Friends'), h('p', { class: 'dim' }, 'Visit friends’ yards, trade, send gifts and messages, over the internet through a home server.')),
        signedIn && state.me ? h('div', { class: 'fr-me' }, h('strong', null, state.me.trainerName), h('span', { class: 'micro dim' }, `@${state.me.username} · ${state.me.code}`), h('button', { class: 'btn small', onclick: () => run(async () => { await client.logout(); acct.token = null; client = S.setAccount(acct); state = { ...state, me: null, friends: null, inbox: null, sel: null }; }) }, 'Sign out')) : null),
      state.error ? h('p', { class: 'err-text' }, state.error) : null,
      !signedIn ? [serverForm(), acct.server ? signInForm() : null]
        : h('div', { class: 'fr-grid' }, h('div', { class: 'col' }, friendsPanel(), inboxPanel()), threadPanel()));
  }
  render();
  if (client.token) refresh();
  return { el, update: () => {}, dispose() { unsub(); } };
}
