// Bridge between the PC app windows and the main process.
const { contextBridge, ipcRenderer } = require('electron');

const on = (channel) => (fn) => {
  const handler = (_e, payload) => fn(payload);
  ipcRenderer.on(channel, handler);
  return () => ipcRenderer.removeListener(channel, handler);
};

contextBridge.exposeInMainWorld('capsule', {
  load: () => ipcRenderer.invoke('app:load'),
  commit: (save, baseRev, reason) => ipcRenderer.invoke('save:commit', { save, baseRev, reason }),
  saveDataset: (ds) => ipcRenderer.invoke('dataset:save', ds),
  listTextures: () => ipcRenderer.invoke('textures:list'),
  openTextures: () => ipcRenderer.invoke('textures:open'),
  openData: () => ipcRenderer.invoke('data:open'),
  importTexture: (path, data) => ipcRenderer.invoke('textures:import', { path, data }),
  importTextures: (files) => ipcRenderer.invoke('textures:importMany', files),
  listProfiles: () => ipcRenderer.invoke('profiles:list'),
  createProfile: (p) => ipcRenderer.invoke('profiles:create', p),
  openProfile: (id) => ipcRenderer.invoke('profiles:open', id),
  deleteProfile: (id) => ipcRenderer.invoke('profiles:delete', id),
  hubInfo: () => ipcRenderer.invoke('hub:info'),
  usbSetup: () => ipcRenderer.invoke('usb:setup'),
  newPairCode: () => ipcRenderer.invoke('hub:newCode'),
  forgetDevice: (id) => ipcRenderer.invoke('hub:forget', id),
  exportFile: (name, text) => ipcRenderer.invoke('file:export', { name, text }),
  reportDock: (d) => ipcRenderer.send('dock:state', d),
  backupExport: (opts) => ipcRenderer.invoke('backup:export', opts),
  backupList: () => ipcRenderer.invoke('backup:list'),
  backupCopy: (file) => ipcRenderer.invoke('backup:copy', file),
  backupRead: (file) => ipcRenderer.invoke('backup:read', file),
  backupRestore: (text) => ipcRenderer.invoke('backup:restore', text),
  importFile: (filters) => ipcRenderer.invoke('file:import', { filters }),
  fetchUrl: (url, as) => ipcRenderer.invoke('net:fetch', { url, as }),
  updateInfo: () => ipcRenderer.invoke('update:info'),
  installUpdate: (bytes) => ipcRenderer.invoke('update:install', bytes),
  revertUpdate: () => ipcRenderer.invoke('update:revert'),
  restart: () => ipcRenderer.invoke('app:restart'),
  onSaveChanged: on('save:changed'),
  onDatasetChanged: on('dataset:changed'),
  onTexturesChanged: on('textures:changed'),
  onHubChanged: on('hub:changed'),
  // hosting a home server from this PC
  hostStatus: () => ipcRenderer.invoke('host:status'),
  hostStart: () => ipcRenderer.invoke('host:start'),
  hostStop: () => ipcRenderer.invoke('host:stop'),
  hostConfigure: (patch) => ipcRenderer.invoke('host:configure', patch),
  hostForward: () => ipcRenderer.invoke('host:forward'),
  hostCheck: () => ipcRenderer.invoke('host:check'),
  hostFirewall: () => ipcRenderer.invoke('host:firewall'),
  onHostStatus: on('host:status'),
  onSerialChoose: on('serial:choose'),
  chooseSerial: (portId) => ipcRenderer.send('serial:chosen', portId),
  // Showdown
  openShowdown: (url, config) => ipcRenderer.invoke('showdown:open', { url, config }),
  fetchText: (url) => ipcRenderer.invoke('showdown:fetch', url),
  onShowdown: on('showdown:event'),
  // desktop buddy window
  petData: () => ipcRenderer.invoke('pet:data'),
  onPetData: on('pet:data'),
  petMouse: (over) => ipcRenderer.send('pet:mouse', over),
  petCare: (action, item, uid) => ipcRenderer.invoke('pet:care', { action, item, uid }),
  petGift: (uid, found) => ipcRenderer.invoke('pet:gift', { uid, found }),
  petForm: (uid, form) => ipcRenderer.invoke('pet:form', { uid, form }),
  petOpenApp: () => ipcRenderer.send('pet:open-app'),
  petAway: (uid) => ipcRenderer.send('pet:away', uid),
  petBusy: (uid, on) => ipcRenderer.send('pet:busy', { uid, on }),
  petSize: (v) => ipcRenderer.send('pet:size', v),
});
