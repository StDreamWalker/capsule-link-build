// Builds the PC app into desktop/dist (and optionally a single-file web preview).
//   node build.mjs           -> dist/ for Electron
//   node build.mjs --web     -> dist-web/index.html (everything inlined, runs in any browser)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const shared = path.join(here, '..', 'shared');
const esbuild = await loadEsbuild();

async function loadEsbuild() {
  try { return await import('esbuild'); } catch { /* not installed here */ }
  if (process.env.ESBUILD_PATH) return import(pathToFileURL(process.env.ESBUILD_PATH).href);
  console.error('esbuild is missing. Run "npm install" in the desktop folder first.');
  process.exit(1);
}

const { buildInfo } = await import(pathToFileURL(path.join(here, '..', 'tools', 'buildinfo.mjs')).href);
const info = buildInfo();
const common = { bundle: true, charset: 'ascii', logLevel: 'warning', sourcemap: false, legalComments: 'none', define: { __BUILD__: JSON.stringify(info) } };
const web = process.argv.includes('--web');

if (!web) {
  const out = path.join(here, 'dist');
  fs.rmSync(out, { recursive: true, force: true });
  fs.mkdirSync(path.join(out, 'renderer'), { recursive: true });
  fs.mkdirSync(path.join(out, 'pet'), { recursive: true });
  await esbuild.build({ ...common, entryPoints: [path.join(here, 'src/main/main.js')], outfile: path.join(out, 'main.cjs'), platform: 'node', format: 'cjs', target: 'node20', external: ['electron'] });
  await esbuild.build({ ...common, entryPoints: [path.join(here, 'src/preload.js')], outfile: path.join(out, 'preload.cjs'), platform: 'node', format: 'cjs', external: ['electron'] });
  await esbuild.build({ ...common, entryPoints: [path.join(here, 'src/showdown-preload.js')], outfile: path.join(out, 'showdown-preload.cjs'), platform: 'node', format: 'cjs', external: ['electron'] });
  await esbuild.build({ ...common, entryPoints: [path.join(here, 'src/renderer/app.js')], outfile: path.join(out, 'renderer/app.js'), platform: 'browser', format: 'iife', target: 'chrome120' });
  await esbuild.build({ ...common, entryPoints: [path.join(here, 'src/pet/pet.js')], outfile: path.join(out, 'pet/pet.js'), platform: 'browser', format: 'iife', target: 'chrome120' });
  fs.copyFileSync(path.join(here, 'src/renderer/index.html'), path.join(out, 'renderer/index.html'));
  fs.copyFileSync(path.join(here, 'src/renderer/styles.css'), path.join(out, 'renderer/styles.css'));
  fs.copyFileSync(path.join(here, 'src/pet/pet.html'), path.join(out, 'pet/pet.html'));
  fs.copyFileSync(path.join(shared, 'ui/font/font.css'), path.join(out, 'font.css'));
  fs.copyFileSync(path.join(shared, 'ui/base.css'), path.join(out, 'base.css'));
  fs.writeFileSync(path.join(out, 'version.json'), JSON.stringify(info, null, 2));
  console.log(`Built desktop/dist (version ${info.version})`);
} else {
  const out = path.join(here, 'dist-web');
  fs.mkdirSync(out, { recursive: true });
  const r = await esbuild.build({ ...common, entryPoints: [path.join(here, 'src/renderer/app.js')], write: false, platform: 'browser', format: 'iife', target: 'chrome110', minify: true });
  const js = r.outputFiles[0].text;
  const css = [fs.readFileSync(path.join(shared, 'ui/font/font.css'), 'utf8'), fs.readFileSync(path.join(shared, 'ui/base.css'), 'utf8'), fs.readFileSync(path.join(here, 'src/renderer/styles.css'), 'utf8')].join('\n');
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Capsule Link</title><style>${css}</style></head><body><script>${js.replace(/<\/script/gi, '<\\/script')}</script></body></html>`;
  fs.writeFileSync(path.join(out, 'index.html'), html);
  console.log(`Built desktop/dist-web/index.html (${Math.round(html.length / 1024)} KB)`);
}
