// Starts the PC app. If an update file has been installed (Settings → Updates), its newer code is
// loaded from the app's data folder instead of the code that came with this download. If that
// update fails to start twice in a row, the app goes back to its built-in code by itself.
// Keep this file small and stable: an update file can't replace it.
const { app } = require('electron');
const path = require('path');
const fs = require('fs');

const builtIn = path.join(__dirname, 'dist', 'main.cjs');
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
const newer = (a, b) => {
  const pa = String(a ?? '0').split(/[.-]/).map(Number), pb = String(b ?? '0').split(/[.-]/).map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0; }
  return false;
};

let target = builtIn, active = null;
const updates = path.join(app.getPath('userData'), 'app-update');
try {
  const cur = readJson(path.join(updates, 'current.json'));
  const mine = readJson(path.join(__dirname, 'dist', 'version.json'));
  const file = cur && path.join(updates, cur.dir, 'dist', 'main.cjs');
  if (cur && fs.existsSync(file) && newer(cur.version, mine?.version) && cur.pcNative === mine?.pcNative) {
    const tries = readJson(path.join(updates, 'starting.json'));
    if (tries?.version === cur.version && tries.count >= 2) {
      // it didn't make it to the first screen twice: give up on it
      fs.rmSync(path.join(updates, 'current.json'), { force: true });
      fs.writeFileSync(path.join(updates, 'failed.json'), JSON.stringify({ version: cur.version, at: Date.now() }));
    } else {
      fs.writeFileSync(path.join(updates, 'starting.json'), JSON.stringify({ version: cur.version, count: (tries?.version === cur.version ? tries.count : 0) + 1 }));
      target = file; active = cur;
    }
  }
} catch { target = builtIn; active = null; }

global.capsuleBoot = {
  builtInRoot: __dirname,
  active,
  /** Called once the first screen has loaded: the update works. */
  started() { try { fs.rmSync(path.join(updates, 'starting.json'), { force: true }); } catch { /* fine */ } },
};

try { require(target); }
catch (e) {
  if (target === builtIn) throw e;
  console.error('Update failed to load, using the built-in version', e);
  try {
    fs.rmSync(path.join(updates, 'current.json'), { force: true });
    fs.writeFileSync(path.join(updates, 'failed.json'), JSON.stringify({ version: active?.version, at: Date.now(), error: String(e?.message ?? e) }));
  } catch { /* fine */ }
  global.capsuleBoot.active = null;
  require(builtIn);
}
