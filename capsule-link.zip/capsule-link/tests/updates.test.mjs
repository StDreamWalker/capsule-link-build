// Update files: the hub offers newer phone code only to phones it fits.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';
import { Hub, newerVersion } from '../shared/net/hub.js';

test('versions compare by number', () => {
  assert.equal(newerVersion('0.3.10', '0.3.9'), true);
  assert.equal(newerVersion('0.3.0', '0.3.0'), false);
  assert.equal(newerVersion('0.2.9', '0.3.0'), false);
});

test('phones get newer app code when their Android side matches', () => {
  const idx = E.indexDataset(E.createDefaultDataset());
  const save = E.createSave('Ziggy', 1);
  const pu = { version: '0.3.1', phoneNative: 'n1', notes: 'x', files: { 'index.html': 'PGh0bWw+', 'version.json': Buffer.from(JSON.stringify({ version: '0.3.1', phoneNative: 'n1' })).toString('base64') } };
  const hub = new Hub({ getIdx: () => idx, getSave: () => save, getPhoneUpdate: () => pu });
  const sent = [];
  hub.send = (_c, type, payload) => sent.push(payload);
  const client = { device: 'p1' };
  hub.sendState(client, { app: { version: '0.3.0', phoneNative: 'n1' } });
  assert.equal(sent.at(-1).appUpdate?.version, '0.3.1');
  hub.sendState(client, { app: { version: '0.3.0', phoneNative: 'other' } });
  assert.equal(sent.at(-1).appUpdate?.nativeMismatch, true, 'a different Android build is still offered, flagged');
  assert.equal(JSON.parse(Buffer.from(sent.at(-1).appUpdate.files['version.json'], 'base64')).phoneNative, 'other', 'stamped with the phone’s own build so it stays installed');
  assert.equal(JSON.parse(Buffer.from(pu.files['version.json'], 'base64')).phoneNative, 'n1', 'the PC copy is untouched');
  hub.sendState(client, { app: { version: '0.3.1', phoneNative: 'n1' } });
  assert.equal(sent.at(-1).appUpdate, undefined, 'already up to date');
  hub.sendState(client, { app: { version: '0.3.0', phoneNative: 'n1', declined: '0.3.1' } });
  assert.equal(sent.at(-1).appUpdate, undefined, 'not offered again after "Not now"');
  assert.equal(sent.at(-1).appStatus.state, 'declined');
  // a different Android fingerprint says so, and the phone can ask for it anyway
  hub.sendState(client, { app: { version: '0.3.0', phoneNative: 'other' } });
  assert.equal(sent.at(-1).appStatus.mismatch, true);
  assert.equal(sent.at(-1).appStatus.need, 'n1');
  assert.equal(hub.phoneApps.get('p1').status, 'offered');
});
