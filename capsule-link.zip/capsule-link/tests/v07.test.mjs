// 0.7.0: move data that keeps its power, several habitats per species, richer PKHeX questions with old
// friends kept together, and training.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const base = () => {
  const idx = E.indexDataset(E.createDefaultDataset());
  const save = E.createSave('Kim', 2);
  E.tickAll(idx, save);
  return { idx, save };
};

test('move descriptions never wipe move power (a text "damage" column is not a number)', () => {
  const ds = E.createDefaultDataset();
  const moves = E.parsePaste(`export const Moves = {
    tackle: { num: 33, accuracy: 100, basePower: 40, category: "Physical", name: "Tackle", pp: 35, priority: 0, type: "Normal" },
    bind: { num: 20, accuracy: 85, basePower: 15, category: "Physical", name: "Bind", pp: 20, priority: 0, type: "Normal" },
  };`);
  E.applyImport(ds, 'moves', moves.rows, E.guessMapping(moves.columns, 'moves'), { mode: 'merge' });
  const text = E.parsePaste(`export const MovesText = {
    tackle: { name: "Tackle", shortDesc: "No additional effect." },
    bind: { name: "Bind", shortDesc: "Traps and damages the target for 4-5 turns.", damage: "  [POKEMON] is hurt by [MOVE]!" },
  };`);
  const rep = E.applyImport(ds, 'moves', text.rows, E.guessMapping(text.columns, 'moves'), { mode: 'merge' });
  assert.ok(rep.updated >= 2);
  const tackle = ds.moves.find((m) => m.id === 'tackle'), bind = ds.moves.find((m) => m.id === 'bind');
  assert.equal(tackle.power, 40);
  assert.equal(bind.power, 15);
  assert.match(bind.desc, /Traps/);
});

test('a species can like several habitats: its own plus what its types suggest, or the trainer’s choice', () => {
  const idx = { types: new Map([['grass', { name: 'Grass' }], ['poison', { name: 'Poison' }]]) };
  assert.deepEqual(E.habitatsOf(idx, { habitat: 'meadow', types: ['grass', 'poison'] }), ['meadow', 'marsh', 'forest']);
  assert.deepEqual(E.habitatsOf(idx, { habitat: 'meadow', habitats: ['forest', 'marsh'], types: ['grass'] }), ['forest', 'marsh']);
  assert.ok(E.likesHabitat(idx, { habitat: 'meadow', types: ['grass', 'poison'] }, 'marsh'));
});

test('the import questions shape who they are, and friends from the same save stay friends', () => {
  const pk = { old: false, missing: [], version: 47, otName: 'Ash' };
  const qs = E.missingQuestions(pk, { friends: [{ uid: 'b', name: 'Pika' }] });
  for (const id of ['where', 'memories', 'size', 'pitch', 'newthing', 'daytime', 'touch', 'love', 'hate', 'friends']) assert.ok(qs.some((q) => q.id === id), id);
  const save = { creatures: { b: { uid: 'b', nickname: 'Pika', origin: { from: 'pkhex', ot: 'Ash', otId: 1 } }, x: { uid: 'x', origin: { from: 'pkhex', ot: 'Misty', otId: 2 } } } };
  const c = { uid: 'a', nickname: 'Bulby', origin: { from: 'pkhex', ot: 'Ash', otId: 1, version: 47 } };
  E.applyAnswers(c, pk, { memories: ['won a gym', 'slept on my bed'], size: 230, pitch: -2, friends: ['b'], newthing: 'shy', touch: 'no', hate: 'activity:bath' });
  assert.equal(c.sizeScalar, 230); assert.equal(c.cryPitch, -2); assert.equal(c.toldStyle, 'shy');
  assert.equal(c.prefs['activity:bath'], -5); assert.ok(c.prefs['activity:pet'] < 0);
  assert.equal(c.memories.filter((m) => m.core).length, 2);
  save.creatures.a = c;
  E.linkSaveFriends(save, c, { friendAt: E.FRIEND_AT });
  assert.ok(c.bonds.b >= E.FRIEND_AT && save.creatures.b.bonds.a >= E.FRIEND_AT);
  assert.ok(!c.bonds.x, 'a different save is a stranger');
  assert.ok(E.friendsOf(c).some((f) => f.uid === 'b'));
});

test('training builds effort in the stat its moves use, and some experience', () => {
  const { idx, save } = base();
  const c = E.createCreature(idx, idx.ds.species[0].id, { level: 10, location: { kind: 'box', box: 0, slot: 0 } });
  save.creatures[c.uid] = c;
  c.needs.energy = 100;
  const exp0 = c.exp, atk0 = c.effort?.atk ?? 0, spa0 = c.effort?.spa ?? 0;
  const r = E.finishActivity(idx, save, c.uid, 'training', 1, { moves: c.moves.map((m) => m.id) });
  assert.ok(r.ok, r.reason);
  assert.ok(r.stars >= 2);
  assert.ok((c.effort.atk ?? 0) > atk0 || (c.effort.spa ?? 0) > spa0);
  assert.ok(c.exp > exp0);
  assert.ok(E.ACTIVITIES.some((a) => a.id === 'training'));
});

test('friends server: who is online, last seen, and battle invites between friends', async () => {
  const fs = await import('node:fs'), os = await import('node:os'), path = await import('node:path');
  const { makeServer } = await import('../server/core.mjs');
  const { FriendsClient } = await import('../shared/net/friends.js');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'clhs7-'));
  const s = makeServer({ port: 0, dataDir: dir });
  await s.server.ready;
  const base = `http://127.0.0.1:${s.server.address().port}`;
  try {
    const a = new FriendsClient(base), b = new FriendsClient(base);
    const ra = await a.signup('ash', 'pikapika1', 'Ash');
    await b.signup('misty', 'starmie12', 'Misty');
    await b.request(ra.user.code); await a.accept('misty');
    const f = (await b.friends()).friends[0];
    assert.equal(f.username, 'ash');
    assert.equal(f.online, false, 'not connected to /live');
    assert.ok(f.seenAt > Date.now() - 60000, 'seen just now (made requests)');
    // battle invite: ash invites, misty sees it and accepts with her Showdown name
    await assert.rejects(() => a.inviteBattle('misty', '', 'gen9customgame'), /Showdown name/);
    const inv = (await a.inviteBattle('misty', 'AshK', 'gen9customgame')).invite;
    const inc = (await b.battles()).incoming;
    assert.equal(inc.length, 1); assert.equal(inc[0].showdown, 'AshK');
    const r = (await b.respondBattle(inv.id, true, 'MistyW')).invite;
    assert.equal(r.state, 'accepted'); assert.equal(r.replyShowdown, 'MistyW');
    await assert.rejects(() => b.respondBattle(inv.id, true, 'MistyW'), /already/);
    // strangers can't invite
    const c = new FriendsClient(base); await c.signup('brock', 'onixonix1');
    await assert.rejects(() => c.inviteBattle('ash', 'Brock', 'gen9customgame'), /friends/);
  } finally { await s.close(); }
});

test('TMs: owned TMs add moves a creature can learn, and setMoves keeps to what it could know', () => {
  const { idx, save } = base();
  const sp = idx.ds.species[0];
  const c = E.createCreature(idx, sp.id, { level: 30, location: { kind: 'box', box: 0, slot: 0 } });
  save.creatures[c.uid] = c;
  const foreign = idx.ds.moves.find((mv) => !sp.types.includes(mv.type) && !sp.learnset.some((l) => l.move === mv.id));
  const own = idx.ds.moves.find((mv) => sp.types.includes(mv.type) && !c.moves.some((m) => m.id === mv.id) && !sp.learnset.some((l) => l.move === mv.id && l.level <= 30));
  assert.ok(!E.moveChoices(idx, save, c).some((m) => m.id === foreign?.id));
  assert.equal(E.setMoves(idx, save, c.uid, [foreign?.id ?? 'nope']).ok, false);
  if (own) {
    save.inventory[E.tmId(own.id)] = 1;
    assert.ok(E.moveChoices(idx, save, c).some((m) => m.id === own.id && m.why === 'tm'));
    assert.ok(E.setMoves(idx, save, c.uid, [own.id, c.moves[0]?.id].filter(Boolean)).ok);
    assert.equal(c.moves[0].id, own.id);
    assert.match(E.itemInfo(idx, E.tmId(own.id)).name, /^TM /);
  }
  // Showdown learnsets bring TM lists along
  const ds = E.createDefaultDataset();
  const mvId = ds.moves[0].id, spId = ds.species[0].id;
  const p = E.parsePaste(`export const Learnsets = { ${spId}: { learnset: { ${mvId}: ["9M", "8L5"] } } };`);
  E.applyImport(ds, 'learnset', p.rows, E.guessMapping(p.columns, 'learnset'), {});
  assert.deepEqual(ds.species.find((x) => x.id === spId).tms, [mvId]);
});
