import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';
import { Hub } from '../shared/net/hub.js';

const setup = () => {
  const idx = E.indexDataset(E.createDefaultDataset());
  const save = E.createSave('Kim', 1);
  const sent = [];
  let changed = 0;
  const hub = new Hub({ mode: 'home', getIdx: () => idx, getSave: () => save, onSaveChanged: () => { changed++; } });
  hub.send = (_c, type, data) => sent.push({ type, ...data });
  const phone = { id: 'p', device: 'phone-1', name: 'Phone', authed: true, kind: 'phone' };
  return { idx, save, hub, sent, phone, changes: () => changed };
};

test('returning creatures from the phone says why when it can’t', () => {
  const { idx, save, hub, sent, phone } = setup();
  const a = E.createCreature(idx, 'sproutle', { location: { kind: 'phone', device: 'phone-1', from: { kind: 'box', box: 0, slot: 5 } } });
  const b = E.createCreature(idx, 'cindrop', { location: { kind: 'capsule', tag: 'T1' } });
  const fresh = E.createCreature(idx, 'zapkit', { location: { kind: 'phone', device: 'phone-1' } }); // caught on a walk, never synced
  save.creatures[a.uid] = a; save.creatures[b.uid] = b;
  hub.onReturn(phone, { uids: [a.uid, b.uid, fresh.uid, 'nobody'], creatures: [a, fresh] });
  const r = Object.fromEntries(sent.at(-1).returned.map((x) => [x.uid, x]));
  assert.equal(r[a.uid].ok, true);
  assert.deepEqual(save.creatures[a.uid].location, { kind: 'box', box: 0, slot: 5 });
  assert.equal(r[b.uid].ok, false);
  assert.match(r[b.uid].error, /inside a ball/);
  assert.equal(r[fresh.uid].ok, true, 'a creature the PC never saw is taken in');
  assert.ok(['box', 'ranch'].includes(save.creatures[fresh.uid].location.kind));
  assert.equal(r.nobody.ok, false);
});

test('unsyncing a ball forgets it and brings its creature home', () => {
  const { idx, save } = setup();
  const c = E.createCreature(idx, 'sproutle', { location: { kind: 'capsule', tag: 'T1' } });
  save.creatures[c.uid] = c;
  save.capsules.T1 = { name: 'Capsule 1', uid: c.uid, holder: 'phone-1' };
  save.virtualTags = { T1: '00' };
  const home = E.unsyncCapsule(save, 'T1');
  assert.equal(home.uid, c.uid);
  assert.notEqual(c.location.kind, 'capsule');
  assert.equal(save.capsules.T1, undefined);
  assert.equal(save.virtualTags.T1, undefined);
});

test('the phone takes a virtual ball off the PC and gives it back', async () => {
  const { save, hub, sent, phone } = setup();
  const t = E.makeVirtualTag('04AA'); t.mem.set([3, 0, 0xfe], 0);
  save.virtualTags = { '04AA': E.toHex(t.mem) };
  save.capsules['04AA'] = { name: 'Capsule 1', holder: 'pc' };
  await hub.onVirtualTag(phone, { type: E.MSG.VTAG_TAKE, uid: '04AA' });
  assert.equal(sent.at(-1).ok, true);
  assert.equal(save.virtualTags['04AA'], undefined, 'the PC no longer has it');
  await hub.onVirtualTag(phone, { type: E.MSG.VTAG_GIVE, uid: '04AA', hex: sent.at(-1).hex, capsule: { name: 'Capsule 1' } });
  assert.ok(save.virtualTags['04AA']);
  assert.equal(save.capsules['04AA'].holder, 'pc');
  // the docked ball can't be taken
  hub.getDock = () => ({ uid: '04AA' });
  await hub.onVirtualTag(phone, { type: E.MSG.VTAG_TAKE, uid: '04AA' });
  assert.equal(sent.at(-1).ok, false);
});

test('a ball synced by the phone records who holds it', () => {
  const { idx, save } = setup();
  E.applyEvent(idx, save, E.makeEvent('capsule', { tag: 'T9', name: 'Capsule 9', holder: 'phone-1' }));
  assert.equal(save.capsules.T9.holder, 'phone-1');
});
