// Wild battles on Showdown's simulator (as bundled into the app): hurt creatures start hurt, with the PP
// they have left, and the battle plays out to a winner. Needs esbuild (npm install in desktop/, or ESBUILD_PATH).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

async function esbuild() {
  try { return await import('esbuild'); } catch { /* not here */ }
  if (process.env.ESBUILD_PATH) return import(pathToFileURL(process.env.ESBUILD_PATH).href);
  for (const p of ['../desktop/node_modules/esbuild/lib/main.js']) { const f = new URL(p, import.meta.url); if (fs.existsSync(f)) return import(f.href); }
  return null;
}

test('a Capsule wild battle on the Showdown simulator', async (t) => {
  const eb = await esbuild();
  if (!eb) { t.skip('esbuild not installed'); return; }
  const { buildShowdownSim } = await import('../shared/sdbattle/build.mjs');
  const out = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'clsd-')), 'sim.mjs');
  await buildShowdownSim(eb, out);
  const { BattleStream, getPlayerStreams, Dex } = await import(pathToFileURL(out).href);
  assert.ok(Dex.species.get('Pikachu').exists);
  assert.ok(!Dex.species.get('Sproutle').exists);
  const stream = new BattleStream();
  const ps = getPlayerStreams(stream);
  const lines = [];
  const auto = async (s, choice) => { for await (const chunk of s) { const m = /\|request\|(.+)/.exec(chunk); if (m) { const r = JSON.parse(m[1]); if (r.active) s.write(choice); } } };
  auto(ps.p2, 'move 1');
  (async () => { for await (const chunk of ps.p1) { lines.push(chunk); const m = /\|request\|(.+)/.exec(chunk); if (m) { const r = JSON.parse(m[1]); if (r.active) ps.p1.write('move 1'); } } })();
  ps.omniscient.write(`>start ${JSON.stringify({ formatid: 'gen9capsulewild', seed: [1, 2, 3, 4] })}\n` +
    `>player p1 ${JSON.stringify({ name: 'Kim', team: [{ name: 'Sparky', species: 'Pikachu', moves: ['Thunderbolt', 'Quick Attack'], level: 20, hpLeft: 25, ppLeft: [5, 30] }] })}\n` +
    `>player p2 ${JSON.stringify({ name: 'Wild', team: [{ name: 'Rattata', species: 'Rattata', moves: ['Tackle'], level: 5 }] })}`);
  for (let i = 0; i < 50 && !stream.battle?.ended; i++) await new Promise((r) => setTimeout(r, 20));
  const text = lines.join('\n');
  assert.match(text, /\|switch\|p1a: Sparky\|Pikachu, L20[^|]*\|25\//, 'started hurt');
  assert.ok(stream.battle.ended);
  assert.equal(stream.battle.winner, 'Kim');
  assert.ok(stream.battle.p1.pokemon[0].baseMoveSlots[0].pp < 5, 'used its PP from what it had left');
});
