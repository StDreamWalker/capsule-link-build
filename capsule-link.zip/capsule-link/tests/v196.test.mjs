// 1.9.6: presets for "Get everything", the phone's own PC (Full PC mode) pieces, the PC screens' styles on the
// phone, and the PokéAtlas's "What's special here".
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const P = await import('../desktop/src/renderer/presets.js');
const { DATA_STEPS } = await import('../desktop/src/renderer/dataSteps.js');

test('the built-in preset covers every data table and every kind of download', () => {
  const B = P.BUILTIN_PRESET;
  assert.equal(B.builtIn, true);
  for (const d of DATA_STEPS) assert.ok(B.steps.some((s) => s.kind === 'data' && s.table === d.id && /^https:\/\//.test(s.url)), d.id);
  for (const k of P.KIND_ORDER) assert.ok(B.steps.some((s) => s.kind === k), k);
  for (const s of B.steps) for (const f of P.STEP_KINDS[s.kind].fields) if (!f.select && !/optional/.test(f.label)) assert.ok(String(s[f.k] ?? '').trim(), `${s.kind}.${f.k}`);
});

test('a shared preset file is cleaned: unknown kinds dropped, fields kept as text, a new id', () => {
  const p = P.cleanPreset({ name: 'My dex', steps: [{ kind: 'sprites', front: 'https://x.test/{num}.png', evil: '<script>' }, { kind: 'rm -rf' }, { kind: 'data', table: 'nope', url: 'https://x.test/s.csv' }] });
  assert.equal(p.name, 'My dex');
  assert.equal(p.steps.length, 2);
  assert.equal(p.steps[0].evil, undefined);
  assert.equal(p.steps[1].table, DATA_STEPS[0].id);
  assert.match(p.id, /^p/);
  assert.throws(() => P.cleanPreset({ steps: [{ kind: 'nothing' }] }));
  assert.throws(() => P.cleanPreset('hello'));
});

test('new steps start from the built-in addresses, and every step has a name', () => {
  assert.equal(P.defaultStep('data', 'moves').url, DATA_STEPS.find((d) => d.id === 'moves').raw);
  assert.ok(P.defaultStep('cries').template.includes('{sd}'));
  for (const s of P.BUILTIN_PRESET.steps) assert.ok(P.stepLabel(s).length > 2);
});

test('the PC screens the phone shows get their styles, and only those', async () => {
  const { pickCss } = await import('../tools/pcviews-css.mjs');
  const out = pickCss('body { color: red } .datalab { display: flex } .topbar, .lab-bar { gap: 2px } @media (max-width: 9px) { .fr-row { x: 1 } .shell { y: 2 } } @keyframes spin { to { opacity: 0 } }');
  assert.match(out, /\.datalab/);
  assert.match(out, /\.lab-bar \{/);
  assert.doesNotMatch(out, /body|topbar|\.shell|keyframes/);
  assert.match(out, /@media \(max-width: 9px\) \{\n\.fr-row/);
});

test('the PokéAtlas page carries the Local Ecology "What’s special here"', async () => {
  const { ATLAS_PAGE } = await import('../shared/atlas/atlasPage.js');
  assert.match(ATLAS_PAGE, /function ecoUnique\(env, pop\)/);
  assert.match(ATLAS_PAGE, /you'd expect\.<\/div>\$\{ecoUnique\(env, pop\)\}/);
});

test('the phone: Settings replaces Debug, PC Link has a desktop icon, Data Lab, Friends and Trainer ID are apps', () => {
  const home = readFileSync(new URL('../mobile/src/home.js', import.meta.url), 'utf8');
  assert.match(home, /id: 'link', title: 'PC Link'[^}]*icon: 'desktop'/);
  for (const id of ['settings', 'datalab', 'friends', 'trainer']) assert.match(home, new RegExp(`id: '${id}'`));
  assert.doesNotMatch(home, /id: 'debug'/);
  const icons = readFileSync(new URL('../shared/ui/icons.js', import.meta.url), 'utf8');
  assert.match(icons, /\n  desktop: '/);
  // battle music moved to Settings on both
  assert.doesNotMatch(readFileSync(new URL('../mobile/src/views.js', import.meta.url), 'utf8'), /musicPicker\(/);
  assert.doesNotMatch(readFileSync(new URL('../desktop/src/renderer/views/battle.js', import.meta.url), 'utf8'), /musicPicker\(/);
  assert.match(readFileSync(new URL('../desktop/src/renderer/views/settings.js', import.meta.url), 'utf8'), /musicPicker\(/);
  assert.match(readFileSync(new URL('../mobile/src/settings.js', import.meta.url), 'utf8'), /musicPicker\(/);
});

test('the PC settings: no step-by-step setup button, a red Creature System Reset', () => {
  const s = readFileSync(new URL('../desktop/src/renderer/views/settings.js', import.meta.url), 'utf8');
  assert.doesNotMatch(s, /Bring in data step by step|Run the whole setup again/);
  assert.match(s, /danger-solid[^\n]*Creature System Reset/);
  assert.match(s, /can’t be undone/);
});
