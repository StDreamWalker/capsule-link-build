// 1.0.0: the battle arenas are real 3D models (not flat pictures), kept clear of the field and the camera.
import test from 'node:test';
import assert from 'node:assert/strict';

// the crowd and flags are little canvases: a stand-in is enough here
const ctx2d = new Proxy({}, { get: () => () => {}, set: () => true });
globalThis.document ??= { createElement: () => ({ width: 0, height: 0, getContext: () => ctx2d }) };
const { arenaProps } = await import('../shared/ui/arenaModels.js');

const CZ = 5;
for (const kind of ['stadium', 'colosseum', 'ruins', 'shrine', 'park']) {
  test(`${kind}: built from models, nothing on the battle field`, () => {
    const props = arenaProps(kind, { seed: 3, CZ });
    const meshes = props.filter((p) => p.mesh);
    assert.ok(meshes.length >= 12, `${kind} has plenty of models (${meshes.length})`);
    const faces = meshes.reduce((n, p) => n + p.mesh.f.length, 0);
    assert.ok(faces > 300, `${kind} has real detail (${faces} faces)`);
    for (const p of props) {
      assert.ok(Number.isFinite(p.x) && Number.isFinite(p.z));
      // the field the creatures stand on (and walk across to hit each other) stays clear
      assert.ok(!(Math.abs(p.x) < 5.4 && p.z > -0.4 && p.z < 10.4), `${kind}: ${p.kind} at ${p.x.toFixed(1)},${p.z.toFixed(1)} is on the field`);
      if (p.mesh) for (const f of p.mesh.f) { assert.ok(f.n.every(Number.isFinite)); assert.ok(f.i.every((k) => p.mesh.v[k])); }
    }
  });
}

test('the stadium is big, with stands on all four sides and floodlights', () => {
  const props = arenaProps('stadium', { seed: 1, CZ });
  for (const [sx, sz] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) assert.ok(props.some((p) => p.mesh && (sx ? Math.sign(p.x) === sx && Math.abs(p.x) > 14 : Math.sign(p.z - CZ) === sz && Math.abs(p.z - CZ) > 12)), `stands at ${sx},${sz}`);
  assert.equal(props.filter((p) => p.glow >= 1).length, 4);
});

test('the crowd is fixed onto the seats and faces the field (it never turns to face the camera)', () => {
  for (const kind of ['stadium', 'colosseum']) {
    const props = arenaProps(kind, { seed: 2, CZ });
    assert.equal(props.filter((p) => p.img && p.lift > 0 && /crowd/.test(p.kind ?? '')).length, 0);
    let rows = 0;
    for (const p of props) for (const f of p.mesh?.f ?? []) if (f.tex) {
      rows++;
      // pointing back towards the middle of the field
      const wx = p.x + f.c[0], wz = p.z + f.c[2];
      assert.ok(f.n[0] * (0 - wx) + f.n[2] * (CZ - wz) > 0, `${kind}: a crowd row faces away from the field`);
    }
    assert.ok(rows > 150, `${kind} has rows of spectators (${rows})`);
  }
});
