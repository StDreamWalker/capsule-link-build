import test from 'node:test';
import assert from 'node:assert/strict';
import { createWsServer } from '../shared/net/wsserver.js';
import { Hub } from '../shared/net/hub.js';
import * as E from '../shared/engine/index.js';

function client(url) {
  const ws = new WebSocket(url);
  const inbox = [];
  const waiters = [];
  ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data);
    const w = waiters.findIndex((x) => x.type === msg.type);
    if (w >= 0) { const [x] = waiters.splice(w, 1); x.resolve(msg); } else inbox.push(msg);
  };
  const api = {
    ws,
    open: new Promise((r) => { ws.onopen = r; }),
    send: (type, data = {}) => ws.send(JSON.stringify({ type, ...data })),
    next: (type, ms = 3000) => {
      const i = inbox.findIndex((m) => m.type === type);
      if (i >= 0) return Promise.resolve(inbox.splice(i, 1)[0]);
      return new Promise((resolve, reject) => {
        const t = setTimeout(() => reject(new Error(`timeout waiting for ${type}; inbox: ${inbox.map((m) => m.type)}`)), ms);
        waiters.push({ type, resolve: (m) => { clearTimeout(t); resolve(m); } });
      });
    },
    close: () => ws.close(),
  };
  return api;
}

test('home hub: pairing, sync, pocket and a bump battle', async () => {
  const idx = E.indexDataset(E.createDefaultDataset());
  const save = E.createSave('Tester');
  const a = E.addCreature(save, E.createCreature(idx, 'zapkit', { level: 12, seed: 1 }), { kind: 'party', slot: 0 });
  const b = E.addCreature(save, E.createCreature(idx, 'cindrop', { level: 12, seed: 2 }), { kind: 'party', slot: 1 });
  let saves = 0;
  const hub = new Hub({ mode: 'home', getIdx: () => idx, getSave: () => save, onSaveChanged: () => saves++, pairCode: '123456' });
  const server = createWsServer({ port: 0, host: '127.0.0.1', onConnection: (c) => hub.attach(c) });
  await server.ready;
  const url = `ws://127.0.0.1:${server.address().port}`;

  const phone = client(url);
  await phone.open;
  phone.send('hello', { deviceId: 'phone-1', name: 'Pixel', pairCode: '000000' });
  assert.equal((await phone.next('error')).code, 'pair');
  phone.send('hello', { deviceId: 'phone-1', name: 'Pixel', pairCode: '123456' });
  const welcome = await phone.next('welcome');
  assert.ok(welcome.token);

  phone.send('pocket.take', { uids: [a.uid] });
  const st = await phone.next('sync.state');
  assert.equal(st.pocket.length, 1);
  assert.ok(st.dataset, 'dataset sent when hash unknown');

  const ev = E.makeEvent('walk', { uid: a.uid, steps: 4000 });
  phone.send('sync.push', { events: [ev, ev], datasetHash: idx.syncHash });
  const st2 = await phone.next('sync.state');
  assert.deepEqual(st2.acked, [ev.id, ev.id]);
  assert.equal(st2.results[1].duplicate, true);
  assert.equal(save.creatures[a.uid].walk.totalSteps, 4000);
  assert.equal(st2.dataset, undefined);

  // reconnect with token instead of code
  const phone2 = client(url);
  await phone2.open;
  phone2.send('hello', { deviceId: 'phone-1', name: 'Pixel', token: welcome.token });
  await phone2.next('welcome');

  const pc = client(url);
  await pc.open;
  pc.send('hello', { deviceId: 'pc', name: 'PC', localToken: hub.localToken, kind: 'pc' });
  await pc.next('welcome');

  // bump pairing: the hub introduces the two players for a Showdown battle
  phone2.send('battle.find', { mode: 'bump', name: 'Phone', showdown: 'AshK', capsules: ['A1B2C3D4'] });
  pc.send('battle.find', { mode: 'bump', name: 'PC', showdown: 'Gary Oak', format: 'gen9customgame' });
  await phone2.next('battle.waiting');
  await pc.next('battle.waiting');
  phone2.send('battle.bump', { elapsed: 300 });
  pc.send('battle.bump', {});
  const m1 = await phone2.next('battle.matched');
  const m2 = await pc.next('battle.matched');
  assert.equal(m1.role, 'challenge', 'the first to wait challenges');
  assert.equal(m2.role, 'accept');
  assert.equal(m1.opponent.showdown, 'Gary Oak');
  assert.equal(m2.opponent.showdown, 'AshK');
  assert.deepEqual(m2.opponent.capsules, ['A1B2C3D4']);
  assert.equal(m1.format, 'gen9customgame');
  // without a Showdown name you are told what to do
  pc.send('battle.find', { mode: 'bump', name: 'PC' });
  assert.equal((await pc.next('error')).code, 'showdown');

  phone.close(); phone2.close(); pc.close();
  await server.close();
  assert.ok(saves > 0);
});

test('relay matches by code and needs no data set', async () => {
  const hub = new Hub({ mode: 'relay' });
  const server = createWsServer({ port: 0, host: '127.0.0.1', onConnection: (c) => hub.attach(c) });
  await server.ready;
  const url = `ws://127.0.0.1:${server.address().port}`;
  const p1 = client(url), p2 = client(url);
  await Promise.all([p1.open, p2.open]);
  p1.send('hello', { name: 'A' }); p2.send('hello', { name: 'B' });
  await p1.next('welcome'); await p2.next('welcome');
  p1.send('battle.find', { mode: 'code', code: 'abc1', showdown: 'Alpha' });
  const w = await p1.next('battle.waiting');
  assert.equal(w.code, 'ABC1');
  p2.send('battle.find', { mode: 'code', code: 'ABC1', showdown: 'Beta' });
  const a = await p1.next('battle.matched');
  const b = await p2.next('battle.matched');
  assert.equal(a.role, 'challenge');
  assert.equal(b.opponent.showdown, 'Alpha');
  // same Showdown name on both sides is refused
  p1.send('battle.find', { mode: 'code', code: 'X9', showdown: 'Same' });
  await p1.next('battle.waiting');
  p2.send('battle.find', { mode: 'code', code: 'X9', showdown: 'same' });
  assert.match((await p2.next('error')).message, /same Showdown name/);
  p1.close(); p2.close();
  await server.close();
});

test('a phone can be a simulated capsule on the PC dock', async () => {
  const idx = E.indexDataset(E.createDefaultDataset());
  const save = E.createSave('Dock');
  const hub = new Hub({ mode: 'home', getIdx: () => idx, getSave: () => save, onSaveChanged: () => {}, pairCode: '111111' });
  const server = createWsServer({ port: 0, host: '127.0.0.1', onConnection: (c) => hub.attach(c) });
  await server.ready;
  const url = `ws://127.0.0.1:${server.address().port}`;
  const phone = client(url), pc = client(url);
  await Promise.all([phone.open, pc.open]);
  phone.send('hello', { deviceId: 'ph', name: 'Pixel', pairCode: '111111' });
  pc.send('hello', { deviceId: 'pc', name: 'PC', kind: 'pc', localToken: hub.localToken });
  await phone.next('welcome'); await pc.next('welcome');

  // the phone's capsule memory
  const tag = E.makeVirtualTag('04A1B2C3D4E5F6');
  tag.mem.set([0x03, 0x00, 0xfe], 0);
  phone.send('capsule.attach', { uid: '04A1B2C3D4E5F6' });
  await phone.next('capsule.attached');
  const att = await pc.next('capsule.attached');
  assert.equal(att.uid, '04A1B2C3D4E5F6');
  assert.equal(att.name, 'Pixel');

  // the phone answers reads and writes from its memory
  phone.ws.addEventListener('message', async (ev) => {
    const m = JSON.parse(ev.data);
    if (m.type === 'capsule.read') phone.send('capsule.reply', { rid: m.rid, hex: E.toHex(await tag.readUser()) });
    if (m.type === 'capsule.write') { await tag.writePages(m.page, E.fromHex(m.hex)); phone.send('capsule.reply', { rid: m.rid }); }
  });
  // the PC side uses it exactly like a tag on the dock
  let rid = 0;
  const call = async (type, data) => { const id = ++rid; pc.send(type, { uid: att.uid, rid: id, ...data }); const r = await pc.next('capsule.reply'); assert.equal(r.rid, id); if (!r.ok) throw new Error(r.error); return r; };
  const remote = {
    uid: att.uid,
    readUser: async () => E.fromHex((await call('capsule.read', {})).hex),
    writePages: async (page, bytes) => { await call('capsule.write', { page, hex: E.toHex(bytes) }); },
  };
  const c = E.addCreature(save, E.createCreature(idx, 'zapkit', { level: 9, seed: 4 }), { kind: 'party', slot: 0 });
  let info = await E.readCapsule(idx, remote);
  assert.equal(info.state, 'blank');
  await E.sendToCapsule(idx, save, remote, info, c.uid, { mode: 'walk' });
  info = await E.readCapsule(idx, tag);
  assert.equal(info.state, 'creature', 'the phone now holds the creature');
  assert.equal(info.rec.uid, c.uid);
  tag.addSteps(2500);
  const res = await E.syncCapsule(idx, save, remote, await E.readCapsule(idx, remote));
  assert.equal(res.walk.steps, 2500);

  // lifting the phone off (or disconnecting) tells the PC
  phone.close();
  const gone = await pc.next('capsule.detached');
  assert.equal(gone.uid, att.uid);
  pc.close();
  await server.close();
});
