// 1.1.1: DS saves inside emulator/device wrappings (DeSmuME .dsv, Action Replay .duc, 1 MB dumps), Brilliant
// Diamond/Shining Pearl saves, and the ROM hack warning on every hack creature.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import * as E from '../shared/engine/index.js';

const w16 = (d, o, v) => { d[o] = v & 255; d[o + 1] = (v >> 8) & 255; };
const w32 = (d, o, v) => { w16(d, o, v & 0xffff); w16(d, o + 2, (v >>> 16) & 0xffff); };
const u16 = (d, o) => d[o] | (d[o + 1] << 8);

/** A decrypted Gen 4 creature: Pikachu. */
function pk4(species = 25) {
  const d = new Uint8Array(136);
  w32(d, 0, 0x12345678); w32(d, 4, 0x0000abcd); w16(d, 8, species); w32(d, 0x10, 1000); d[0x14] = 70; d[0x15] = 9;
  w16(d, 0x28, 84); // Thunder Shock
  for (let i = 0; i < 11; i++) w16(d, 0x48 + i * 2, 0xffff);
  let sum = 0; for (let i = 8; i < 136; i += 2) sum = (sum + u16(d, i)) & 0xffff; w16(d, 6, sum);
  return E.encrypt4567(d, 4);
}
/** A HeartGold/SoulSilver save (both copies), with Pikachu in Box 1. */
function hgss() {
  const d = new Uint8Array(0x80000);
  const G = 0xf628, SS = 0xf700, SZ = 0x12310;
  for (const base of [0, 0x40000]) {
    w32(d, base + G - 0x10, 1); w32(d, base + G - 0xc, G); w32(d, base + G - 8, 0x20060623);
    w32(d, base + SS + SZ - 0x10, 1); w32(d, base + SS + SZ - 0xc, SZ); w32(d, base + SS + SZ - 8, 0x20060623);
    d.set(pk4(), base + SS);
  }
  return d;
}

test('HeartGold/SoulSilver opens as a plain .sav, a DeSmuME .dsv, an Action Replay .duc and a 1 MB dump', () => {
  const plain = hgss();
  const footer = new Uint8Array(0x7a); [...'|-DESMUME SAVE-|'].forEach((ch, i) => { footer[0x7a - 16 + i] = ch.charCodeAt(0); });
  const dsv = new Uint8Array(0x8007a); dsv.set(plain); dsv.set(footer, 0x80000);
  const duc = new Uint8Array(0x800a4); duc.set(plain, 0xa4); duc[0] = 0x41;
  const mb = new Uint8Array(0x100000); mb.set(plain); mb.set(plain, 0x80000);
  for (const [bytes, name, kind] of [[plain, 'hg.sav'], [dsv, 'hg.dsv', 'DeSmuME'], [duc, 'hg.duc', 'Action Replay'], [mb, 'hg.sav', '1 MB dump']]) {
    const sav = E.openGameSave(bytes, name);
    assert.notEqual(sav.ok, false, `${name}: ${sav.error}`);
    assert.equal(sav.game, 'HeartGold or SoulSilver');
    assert.equal(sav.boxes[0].slots[0]?.pk?.national, 25, name);
    assert.equal(sav.container, kind);
    const out = sav.toBytes();
    assert.equal(out.length, bytes.length, `${name} keeps its size`);
    if (kind === 'DeSmuME') assert.deepEqual([...out.subarray(-16)], [...footer.subarray(-16)]);
    if (kind === 'Action Replay') assert.equal(out[0], 0x41);
    const again = E.openGameSave(out, name);
    assert.equal(again.boxes[0].slots[0]?.pk?.national, 25, `${name} reopens`);
  }
});

test('Brilliant Diamond/Shining Pearl: a creature goes in, the save is re-signed (MD5) and reads back', () => {
  const d = new Uint8Array(0xe9828); w32(d, 0, 0x25);
  [...'LUCAS'].forEach((ch, i) => w16(d, 0x79bb4 + i * 2, ch.charCodeAt(0))); w16(d, 0x79bb4 + 0x1c, 12345);
  const sav = E.openGameSave(d, 'main');
  assert.notEqual(sav.ok, false, sav.error);
  assert.equal(sav.game, 'Brilliant Diamond or Shining Pearl');
  assert.equal(sav.trainer.name, 'LUCAS'); assert.equal(sav.boxes.length, 40);
  // a plain .pb8: Piplup
  const pb8 = new Uint8Array(0x158); w32(pb8, 0, 0xdeadbeef); w16(pb8, 8, 393); w32(pb8, 0x10, 135);
  let sum = 0; for (let i = 8; i < 0x148; i += 2) sum = (sum + u16(pb8, i)) & 0xffff; w16(pb8, 6, sum);
  assert.equal(sav.put(0, 0, pb8, 'pb8').ok, true);
  const out = sav.toBytes();
  const check = out.slice(); const H = 0xe9828 - 16; const stored = check.slice(H, H + 16); check.fill(0, H, H + 16);
  assert.equal(Buffer.from(stored).toString('hex'), createHash('md5').update(check).digest('hex'));
  assert.equal(E.openGameSave(out, 'main').boxes[0].slots[0]?.pk?.national, 393);
});

test('unknown sizes explain which files work (DS .dsv/.duc, 3DS and Switch "main")', () => {
  const r = E.openGameSave(new Uint8Array(12345), 'x.bin');
  assert.equal(r.ok, false); assert.match(r.error, /\.dsv/); assert.match(r.error, /Brilliant Diamond/);
});

test('every ROM hack creature carries the warning marker', async () => {
  const { homeTransferNote } = await import('../shared/engine/hackTransfer.js');
  for (const romhack of ['unbound', 'radicalred', 'seaglass', 'expansion', 'rowe', 'cfru']) assert.match(homeTransferNote({ pk: { romhack, hackRaw: 'AA==' }, origin: { game: 'X' } }), /backup/);
});

// PKHeX's MemeCrypto.VerifyMemeData (key 3), written independently with Node's crypto, to check our signing
function verifyMeme(input) {
  const { createDecipheriv, createHash } = require_crypto();
  const { der, n, e } = MEME.MEME_PUBLIC;
  const sigIn = input.subarray(input.length - 0x60);
  let M = 0n; for (const b of sigIn) M = (M << 8n) | BigInt(b);
  let r = 1n, base = M % n, ex = e; while (ex > 0n) { if (ex & 1n) r = (r * base) % n; base = (base * base) % n; ex >>= 1n; }
  const sigBuf = new Uint8Array(0x60); for (let i = 0x5f; i >= 0 && r > 0n; i--) { sigBuf[i] = Number(r & 0xffn); r >>= 8n; }
  for (const top of [false, true]) {
    const out = Uint8Array.from(input); const sb = sigBuf.slice(); if (top) sb[0] |= 0x80;
    out.set(sb, out.length - 0x60);
    const payload = out.subarray(0, out.length - 0x60), sig = out.subarray(out.length - 0x60);
    const key = createHash('sha1').update(Buffer.concat([Buffer.from(der), Buffer.from(payload)])).digest().subarray(0, 16);
    const dec = (blk) => { const d = createDecipheriv('aes-128-ecb', key, null); d.setAutoPadding(false); return d.update(blk); };
    const xor = (a, b) => { for (let i = 0; i < b.length; i++) a[i] ^= b[i]; };
    let temp = new Uint8Array(16);
    for (let i = 0x50; i >= 0; i -= 16) { const sl = sig.subarray(i, i + 16); xor(temp, sl); temp = Uint8Array.from(dec(temp)); sl.set(temp); }
    xor(temp, sig.subarray(0x50));
    const k = new Uint8Array(16); for (let i = 0; i < 16; i += 2) { k[i] = (2 * temp[i] + (temp[i + 1] >> 7)) & 255; k[i + 1] = (2 * temp[i + 1]) & 255; if (i + 2 < 16) k[i + 1] = (k[i + 1] + (temp[i + 2] >> 7)) & 255; } if (temp[0] & 0x80) k[15] ^= 0x87;
    for (let i = 0; i < 0x60; i += 16) xor(sig.subarray(i, i + 16), k);
    let nx = new Uint8Array(16);
    for (let i = 0; i < 0x60; i += 16) { const sl = sig.subarray(i, i + 16); const t = sl.slice(); sl.set(dec(sl)); xor(sl, nx); nx = t; }
    const h = createHash('sha1').update(out.subarray(0, out.length - 8)).digest();
    if (h.subarray(0, 8).equals(Buffer.from(out.subarray(out.length - 8)))) return true;
  }
  return false;
}
import * as MEME from '../shared/engine/memecrypto.js';
import { createRequire } from 'node:module';
const require_crypto = () => createRequire(import.meta.url)('node:crypto');

test('Sun/Moon saves are re-signed the way the game checks them (MemeCrypto verifies)', () => {
  for (let i = 0; i < 5; i++) {
    const area = new Uint8Array(0x80); area.set(createHash('sha256').update(String(i)).digest());
    MEME.signMemeInPlace(area);
    assert.equal(verifyMeme(area), true, `signature ${i}`);
    area[3] ^= 1; assert.equal(verifyMeme(area), false, 'a changed hash fails');
  }
});

test('Japanese Gold/Silver/Crystal and Sun/Moon saves can be written now', () => {
  const src = (globalThis.__src ??= require_crypto() && createRequire(import.meta.url)('node:fs').readFileSync(new URL('../shared/engine/gameSaves.js', import.meta.url), 'utf8'));
  assert.doesNotMatch(src, /can be read but not written/);
  assert.match(src, /signSaveInPlace\(data, memeAt/);
});

test('the battle bag: consumables only, with what each does and whether it would do anything', () => {
  const idx = { items: new Map(), ds: { items: [] } };
  const save = { inventory: { 'med-potion': 2, 'med-revive': 1, 'med-ether': 1, 'power-bracer': 1, 'val-pearl': 3, 'med-full-heal': 0 } };
  const bag = E.battleBag(idx, save);
  assert.deepEqual(bag.map((b) => b.name), ['Potion', 'Revive', 'Ether']);
  assert.equal(bag.find((b) => b.name === 'Revive').target, 'fainted');
  assert.equal(bag.find((b) => b.name === 'Ether').needsMove, true);
  assert.deepEqual(E.battleUseOf({ name: 'X Attack' }), { boost: { atk: 2 } });
  assert.equal(E.battleUseOf({ name: 'Poké Ball' }), null);
  assert.equal(E.battleUseOf({ name: 'Leftovers', kind: 'held' }), null);
  const mon = { name: 'Pika', hp: 20, maxhp: 20, status: '', fainted: false, moves: [{ pp: 10, maxpp: 10 }] };
  assert.match(E.whyNoEffect({ hp: 20 }, mon), /won’t have any effect/);
  assert.equal(E.whyNoEffect({ hp: 20 }, { ...mon, hp: 5 }), null);
  assert.equal(E.whyNoEffect({ cure: 'psn' }, { ...mon, status: 'tox' }), null);
  assert.match(E.whyNoEffect({ revive: 0.5 }, mon), /hasn’t fainted/);
  assert.equal(E.whyNoEffect({ pp: 10, one: true }, { ...mon, moves: [{ pp: 3, maxpp: 10 }] }, 0), null);
});

test('famous battlers: 50 of them, found by name or alias, with their teams brought to a level', () => {
  assert.equal(E.FAMOUS_TRAINERS.length, 50);
  assert.equal(new Set(E.FAMOUS_TRAINERS.map((t) => t.name)).size, 50);
  assert.equal(E.findFamousTrainer('  CYNTHIA ')?.name, 'Cynthia');
  assert.equal(E.findFamousTrainer('Gary Oak')?.name, 'Blue');
  assert.equal(E.findFamousTrainer('lt. surge')?.name, 'Lt. Surge');
  assert.equal(E.findFamousTrainer('Someone'), null);
  for (const t of E.FAMOUS_TRAINERS) for (const m of t.team) { assert.ok(m.level > 0 && m.moves.length >= 2, `${t.name} ${m.species}`); }
  const red = E.famousTeam(E.findFamousTrainer('red'), { matchLevel: 30 });
  assert.equal(Math.max(...red.map((s) => s.level)), 30);
  assert.equal(red.find((s) => s.species === 'Snorlax').level, 24); // keeps its gap below the strongest
  const clair = E.famousTeam(E.findFamousTrainer('clair'));
  assert.equal(new Set(clair.map((s) => s.name)).size, clair.length, 'every one has its own name');
});

test('Heal party: everyone back to full HP and PP, cured', () => {
  const idx = { moves: new Map([['m1', { pp: 20 }]]) };
  const save = { creatures: { a: { uid: 'a', hp: 3, status: 'psn', moves: [{ id: 'm1', pp: 2 }], location: { kind: 'party' } }, b: { uid: 'b', hp: null, moves: [], location: { kind: 'box' } } } };
  assert.equal(E.healParty(idx, save), 1);
  assert.equal(save.creatures.a.hp, null); assert.equal(save.creatures.a.status, null); assert.equal(save.creatures.a.moves[0].pp, 20);
  assert.ok(E.HEAL_MIN <= 10 && E.PP_MIN <= 15, 'healing on its own is quicker now');
});

test('chat: answers are about what you said, and they remember it', () => {
  const idx = E.indexDataset(E.createDefaultDataset()); const save = E.createSave('Kim', 2); E.tickAll(idx, save);
  const c = E.createCreature(idx, idx.ds.species[1].id, { level: 60 }); c.friendship = 220; c.origin = { from: 'pkhex' }; save.creatures[c.uid] = c;
  const t = new Date(2026, 9, 3, 14).getTime();
  const plan = E.chatReply(idx, save, c, 'I am going to the beach later', t);
  assert.match(plan.note, /beach/i);
  const op1 = E.chatReply(idx, save, c, 'what do you think about cats?', t + 60000), op2 = E.chatReply(idx, save, c, 'do you like cats?', t + 120000);
  assert.match(op1.note, /cats/); assert.equal(/likes|loves/.test(op1.note), /likes|loves/.test(op2.note), 'the same opinion both times');
  const mem = Array.from({ length: 6 }, (_, i) => E.chatReply(idx, save, c, 'do you remember?', t + 600000 * (i + 1)).note);
  assert.ok(mem.some((n) => /beach|cats/.test(n)), mem.join(' | '));
  // a word learned stays learned when the phone and PC copies are joined
  const merged = E.mergeChat({ known: { food: 1 }, heard: { food: 5 }, n: 9 }, { known: {}, heard: { food: 2, walk: 1 }, n: 3 });
  assert.equal(merged.known.food, 1); assert.equal(merged.heard.food, 5); assert.equal(merged.heard.walk, 1); assert.equal(merged.n, 9);
});

test('task list: wishes, places from their game, done gives items and joy, turned down comes off', () => {
  const idx = E.indexDataset(E.createDefaultDataset()); const save = E.createSave('Kim', 2); E.tickAll(idx, save);
  const c = E.createCreature(idx, idx.ds.species[0].id, { level: 10, location: { kind: 'ranch' } }); c.origin = { game: 'HeartGold or SoulSilver' }; save.creatures[c.uid] = c;
  assert.equal(E.gamePlacesFor(c).region, 'Johto');
  let seen = new Set(); let x = 7;
  for (let i = 0; i < 60; i++) { const tk = E.wishTask(idx, save, c, Date.now() + i * 3600000, String(i)); seen.add(tk.kind); assert.ok(tk.due - tk.made >= 86400000 && tk.due - tk.made <= 9 * 86400000); }
  assert.ok(seen.has('place') && seen.has('wish'), [...seen].join());
  const added = E.tickTasks(idx, save, Date.now(), () => ((x = (x * 9301 + 49297) % 233280) / 233280) * 0 , { chance: 1 });
  assert.equal(added.length, 1); assert.equal(E.tickTasks(idx, save, Date.now(), () => 0, { chance: 1 }).length, 0, 'one at a time each');
  const joy = c.needs.joy, fr = c.friendship;
  let q = 0; const r = E.completeTask(idx, save, added[0].id, Date.now(), () => ((q += 0.37) % 1));
  assert.ok(r.ok && r.items.length >= 2); assert.ok(c.needs.joy > joy && c.friendship > fr); assert.equal(save.tasks.length, 0);
  E.addTask(save, E.wishTask(idx, save, c, Date.now(), 'z'));
  assert.equal(E.denyTask(idx, save, save.tasks[0].id).ok, true); assert.equal(save.tasks.length, 0);
});

test('real sky in battles: on by default, can be corrected, and carries rain into the battle', () => {
  E.setSky({ lat: 47.6, lon: -122.3, weather: 'rain', at: Date.now(), temp: 12 });
  const a = E.battleSky({});
  assert.equal(a.weather, 'rain'); assert.equal(a.field, 'RainDance');
  assert.equal(E.battleSky({ realSkyBattles: false }), null);
  const b = E.battleSky({ skyFix: { weather: 'fog', tod: 'dusk', until: Date.now() + 3600000 } });
  assert.equal(b.weather, 'fog'); assert.equal(b.tod, 'dusk'); assert.equal(b.field, null); assert.equal(b.source, 'fixed');
  assert.equal(E.battleSky({ skyFix: { weather: 'snow', until: Date.now() - 1 } }).weather, 'rain', 'an old correction has run out');
  E.setSky(null);
});
