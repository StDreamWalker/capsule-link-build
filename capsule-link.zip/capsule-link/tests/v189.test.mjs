import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createDefaultDataset, indexDataset, createCreature, questionOf, answersTo, ballsForGame, ballChoices, reball, BALL_ITEMS,
  rareFinds, dirtyId, cleanOf, restoreItem, ownedToys, buyToy, STARTER_TOYS, TOY_SHOP, BLUEPRINTS, blueprintUnlocked, buyBlueprint,
  FAMOUS_TRAINERS, growInfo, shopStock, itemInfo,
} from '../shared/engine/index.js';
import { modelFor } from '../shared/ui/m3d/catalog.js';

const setup = () => {
  const ds = createDefaultDataset(), idx = indexDataset(ds);
  const a = createCreature(idx, ds.species[0].id, { level: 10, seed: 'q-1' });
  const b = createCreature(idx, ds.species[1 % ds.species.length].id, { level: 12, seed: 'q-2' });
  const save = { creatures: { [a.uid]: a, [b.uid]: b }, inventory: {}, tasks: [], wallet: 5000, boxes: [], ranch: {} };
  return { ds, idx, a, b, save };
};

test('questions get a real answer from each creature', () => {
  const { idx, a, b, save } = setup();
  assert.equal(questionOf('who wants to play fetch?'), null); // (an invitation, not a question)
  assert.equal(questionOf('hello everyone'), null);
  for (const [text, id] of [['what do you want to do?', 'want'], ['are you hungry?', 'hungry'], ["what's your favourite thing?", 'favorite'], ['who are your friends?', 'friends']]) {
    const q = questionOf(text);
    assert.equal(q?.id, id, text);
    const ans = answersTo(idx, save, [a.uid, b.uid], q, { t: Date.now() });
    assert.equal(ans.length, 2);
    for (const x of ans) { assert.ok(x.text && x.text.length > 4, x.text); assert.ok(save.creatures[x.uid]); }
  }
});

test('balls: bought at the market, swapped into, and only ones its game has', () => {
  const { idx, a, save } = setup();
  assert.ok(BALL_ITEMS.length >= 10 && BALL_ITEMS.every((x) => x.price > 0));
  assert.ok(!BALL_ITEMS.some((x) => x.ball === 16)); // (no Cherish Ball for sale)
  const stock = shopStock(idx, save, Date.now());
  assert.ok(JSON.stringify(stock).includes('ball-4'));
  assert.ok(/Ball/.test(itemInfo(idx, 'ball-2')?.name ?? ''));
  // made here: any ball it has in the bag
  assert.deepEqual(ballChoices(save, a), []);
  assert.equal(reball(save, a, 2).ok, false);
  save.inventory['ball-2'] = 1;
  assert.deepEqual(ballChoices(save, a).map((x) => x.ball), [2]);
  assert.ok(reball(save, a, 2).ok);
  assert.equal(a.ballSkin, '2');
  assert.equal(save.inventory['ball-2'], 0);
  // from a Gen 3 game: no Dusk Ball (13), but a Great Ball (3) is fine
  const g3 = { ...a, ballSkin: null, origin: { game: 'Pokémon Emerald' }, pk: {} };
  save.inventory['ball-13'] = 1; save.inventory['ball-3'] = 1;
  assert.ok(ballsForGame(g3).includes(3) && !ballsForGame(g3).includes(13));
  assert.deepEqual(ballChoices(save, g3).map((x) => x.ball), [3]);
  assert.equal(reball(save, g3, 13).ok, false);
  assert.ok(reball(save, g3, 3).ok);
  assert.equal(g3.pk.ballChanged, 3);
});

test('rare finds unlock blueprints; locked blueprints cannot be bought; dirty items get restored', () => {
  const { idx, save } = setup();
  const locked = BLUEPRINTS.find((b) => b.found);
  assert.ok(locked, 'some blueprints have to be found first');
  assert.equal(blueprintUnlocked(save, locked), false);
  assert.equal(buyBlueprint(save, locked.id).ok, false);
  assert.ok(BLUEPRINTS.filter((b) => !b.found).every((b) => blueprintUnlocked(save, b)));
  let found = [];
  for (let i = 0; i < 40 && !found.some((f) => f.kind === 'blueprint'); i++) found = rareFinds(idx, save, 'walk', { perfect: true, rnd: () => 0.001 });
  const f = found.find((x) => x.kind === 'blueprint');
  assert.ok(f, 'a lucky walk turns up a blueprint');
  assert.ok(blueprintUnlocked(save, BLUEPRINTS.find((b) => b.id === f.bp)));
  assert.ok(save.findsNew.length >= 1);
  assert.equal(rareFinds(idx, save, 'walk', { rnd: () => 0.99 }).length, 0);
  save.inventory[dirtyId('incense-calm')] = 1;
  assert.equal(cleanOf('dirty:incense-calm'), 'incense-calm');
  assert.ok(restoreItem(save, 'dirty:incense-calm').ok);
  assert.equal(save.inventory['incense-calm'], 1);
  assert.equal(restoreItem(save, 'dirty:incense-calm').ok, false);
});

test('toys: four to start with, more to buy, and the toy chest is what you own', () => {
  const save = { wallet: 1000 };
  assert.deepEqual(ownedToys(save).map((t) => t.id).sort(), [...STARTER_TOYS].sort());
  assert.ok(TOY_SHOP.length >= 12);
  const extra = TOY_SHOP.find((t) => !STARTER_TOYS.includes(t.id) && t.price <= 1000);
  assert.ok(buyToy(save, extra.id).ok);
  assert.ok(ownedToys(save).some((t) => t.id === extra.id));
  assert.equal(buyToy(save, extra.id).ok, false);
  assert.equal(buyToy(save, 'ball').ok, false);
});

test('more famous trainers, mystery seeds grow slowly, and the new scenery models build', () => {
  assert.ok(FAMOUS_TRAINERS.length >= 150);
  const ids = new Set(FAMOUS_TRAINERS.map((t) => t.id ?? t.name));
  assert.equal(ids.size, FAMOUS_TRAINERS.length, 'no duplicate trainers');
  const g = growInfo({ id: 'berry-mystery', name: 'Mystery Seed', kind: 'seed', hours: 2 });
  if (g) assert.ok((g.hours ?? g) >= 24 || JSON.stringify(g).includes('24'), JSON.stringify(g));
  for (const k of ['snowdrift', 'snowman', 'coral', 'rock', 'reed', 'crystal', 'bush']) {
    for (const seed of [1, 2, 3, 4]) { const m = modelFor(k, { seed }); assert.ok(m && m.h > 0.1, `${k} ${seed}`); }
  }
});
