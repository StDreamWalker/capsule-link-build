import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const world = () => {
  const ds = E.createDefaultDataset(), idx = E.indexDataset(ds);
  const save = E.createSave('Kim', 2); E.tickAll(idx, save);
  const mk = (i, nick) => { const c = E.createCreature(idx, ds.species[i % ds.species.length].id, { level: 12 + i * 3, seed: `t${i}`, location: { kind: 'ranch' } }); c.nickname = nick; c.needs = { energy: 70, fullness: 70, joy: 70, hygiene: 70 }; save.creatures[c.uid] = c; return c; };
  const A = mk(0, 'Musharna'), B = mk(1, 'Cogsy'), C = mk(2, 'Mindle');
  A.bonds = { [B.uid]: 70 }; B.bonds = { [A.uid]: 65 };
  return { ds, idx, save, A, B, C, names: E.namesFor(idx, save) };
};

test('understanding: what kind of thing was said', () => {
  const { names, A, B, C } = world();
  const u = (t) => E.understand(t, { names });
  const cases = [
    ['Who wants to battle right now?', 'groupQ', 'want', 'battle'],
    ['Who likes battling in general?', 'groupQ', 'like', 'battle'],
    ['Who wants to race from the hammock to the toy box?', 'groupQ', 'want', 'race'],
    ['which of you likes rock music?', 'groupQ', 'like', null],
    ["who's the fastest?", 'groupQ', 'stat', null],
    ['who has never been fishing?', 'groupQ', 'done', 'fishing'],
    ["who's the best at fishing?", 'groupQ', 'skill', 'fishing'],
    ['Whoever wins the next race gets to go with me on a walk', 'deal', null, null],
    ['first one to the pond gets belly rubs!', 'deal', null, null],
    ["Musharna I never took you for someone who'd like jazz", 'remark', null, null],
    ["I'd like to show you some lo-fi music", 'share', null, null],
    ['have you heard "Bohemian Rhapsody"?', 'share', null, null],
    ['why are you so happy?', 'why', null, null],
    ['why?', 'followup', null, null],
    ['do you remember the race?', 'remember', null, 'race'],
    ['Cogsy, do you like Mindle?', 'opinionOf', null, null],
    ['what kind of music do you like?', 'tasteQ', null, null],
    ['do you want to play fetch?', 'ynQ', 'want', 'fetch'],
    ['do you like swimming?', 'ynQ', 'like', 'swim'],
    ['are you good at cooking?', 'ynQ', 'skill', 'cooking'],
    ['have you ever been swimming?', 'ynQ', 'done', 'swim'],
    ["I'll take you on a walk later", 'promise', null, 'walk'],
    ['who won the last race?', 'eventQ', null, 'race'],
    ['what did you do today?', 'dayQ', null, null],
    ['do you trust me?', 'aboutMe', null, null],
    ['does Cogsy like battling?', 'thirdQ', 'like', 'battle'],
    ["what's your favourite thing to do?", 'favQ', null, null],
    ["let's race to the tree", 'propose', null, 'race'],
  ];
  for (const [t, kind, stance, act] of cases) {
    const p = u(t);
    assert.equal(p.kind, kind, t);
    if (stance) assert.equal(p.stance, stance, t);
    if (act) assert.equal(p.act?.id, act, t);
  }
  // the details that matter
  const r = u('Who wants to race from the hammock to the toy box?');
  assert.equal(r.route.from.id, 'hammock'); assert.equal(r.route.to.id, 'toy-chest');
  const d = u('Whoever wins the next race gets to go with me on a walk');
  assert.equal(d.cond.kind, 'race'); assert.equal(d.prize.kind, 'walk');
  assert.equal(u('first one to the pond gets belly rubs!').route.to.id, 'pond');
  const m = u('I want to show you "Clair de Lune" by Debussy');
  assert.equal(m.title, 'Clair de Lune'); assert.equal(m.artist, 'debussy');
  const rm = u("Musharna I never took you for someone who'd like jazz");
  assert.equal(rm.genre, 'jazz'); assert.equal(rm.surprise, true); assert.deepEqual(rm.addressees, [A.uid]);
  const op = u('Cogsy, do you like Mindle?');
  assert.deepEqual(op.addressees, [B.uid]); assert.deepEqual(op.about, [C.uid]);
  assert.deepEqual(u('what do you think of Mindle?').about, [C.uid]);
  assert.equal(u('who is faster, Cogsy or Mindle?').compare.length, 2);
  // things that aren't promises or deals
  assert.notEqual(u("Sorry we can't go outside today").kind, 'promise');
  assert.equal(u('who does not want to nap?').neg, true);
});

test('wanting to now is not the same as liking in general', () => {
  const { idx, save, A, names } = world();
  A.needs.energy = 8; // worn out
  const now = E.understand('Who wants to battle right now?', { names }), gen = E.understand('Who likes battling in general?', { names });
  const res = E.volunteers(idx, save, [A.uid], E.INVITES.find((i) => i.id === now.act.inv));
  assert.equal(res.yes.length, 0, 'too tired to battle now');
  const rows = E.groupAnswers(idx, save, [A.uid], gen);
  assert.ok(rows?.length === 1 && /battling/.test(rows[0].text), 'still answers whether it likes battling');
  assert.ok(!/tired/.test(rows[0].text));
});

test('a deal is remembered, settled by the race, owed, celebrated for the right reason, and kept by the walk', () => {
  const { idx, save, A, B, C, names } = world();
  const t0 = Date.now();
  const p = E.understand('Whoever wins the next race gets to go with me on a walk', { names });
  const { deal, reactions } = E.makeDeal(idx, save, p, [A.uid, B.uid, C.uid], t0);
  assert.equal(reactions.length, 3);
  assert.ok(reactions.every((r) => /walk/.test(r.note)));
  const s = E.settleDeal(idx, save, { kind: 'race', winner: B.uid, uids: [A.uid, B.uid, C.uid], goal: 'toy box' }, t0 + 60000);
  assert.ok(s && s.task && /walk/.test(s.task.text));
  assert.equal(E.owedOf(B).length, 1);
  assert.equal(deal.state, 'won');
  // it knows exactly why it's excited
  const why = E.converseOne(idx, save, B, 'why are you so excited?', t0 + 120000, { names });
  assert.match(why.note, /won .*walk.*race to the toy box|race to the toy box.*walk/);
  // the others remember losing it
  const lost = E.converseOne(idx, save, C, 'do you remember the race?', t0 + 130000, { names });
  assert.match(lost.note, /lost the race to the toy box to Cogsy/);
  // the walk: kept, and remembered as the walk it won
  const out = E.applyEvent(idx, save, { id: 'walk-test-1', type: 'walk', uid: B.uid, steps: 800, at: t0 + 3600000 });
  assert.ok(out.outcome.kept && /walk it won in the race to the toy box/.test(out.outcome.kept), out.outcome.kept);
  assert.equal(E.owedOf(B).length, 0);
  assert.ok(B.memories.some((m) => /walk it won in the race to the toy box, beating Musharna and Mindle/.test(m.text)));
  const happy = E.converseOne(idx, save, B, 'why are you so happy?', t0 + 3700000, { names });
  assert.match(happy.note, /finally got the walk it won in the race to the toy box/);
  // a second deal: whoever wins the next battle
  const pb = E.understand('if you win your next battle you get an extra berry', { names });
  assert.equal(pb.kind, 'deal'); assert.equal(pb.cond.kind, 'battle'); assert.equal(pb.prize.kind, 'food');
});

test('a promise you never keep is remembered, and makes the next one harder to believe', () => {
  const { idx, save, A, names } = world();
  const t0 = Date.now();
  E.converseOne(idx, save, A, "I'll take you on a walk later", t0, { names });
  assert.equal(E.owedOf(A).length, 1);
  const broken = E.checkPromises(idx, save, t0 + 4 * 86400000);
  assert.equal(broken.length, 1);
  assert.equal(E.owedOf(A).length, 0);
  assert.ok([...(A.memories ?? []), ...(A.journal ?? [])].some((m) => /promised it a walk/.test(m.text)));
  E.converseOne(idx, save, A, "I'll take you on a walk later", t0 + 4.1 * 86400000, { names });
  A.trust.broken = 2;
  const again = E.converseOne(idx, save, A, 'I promise we will go for a walk tomorrow', t0 + 4.2 * 86400000, { names });
  assert.match(again.note, /believe it when it sees it|never happened/);
  const mad = E.converseOne(idx, save, A, 'do you trust me?', t0 + 4.3 * 86400000, { names });
  assert.match(mad.note, /broken|hesitates/);
});

test('music: its own opinion the first time, recognised after, artists known, and remembered', () => {
  const { idx, save, A, names } = world();
  const t0 = Date.now();
  const first = E.converseOne(idx, save, A, 'I want to show you "Clair de Lune" by Debussy', t0, { names });
  assert.ok(first.music?.first);
  assert.equal(A.music[first.music.key].genre, 'classical');
  const again = E.converseOne(idx, save, A, 'play it again', t0 + 60000, { names });
  assert.ok(again && again.music && !again.music.first, 'knows it now');
  assert.match(again.note, /Clair De Lune/i);
  const asked = E.converseOne(idx, save, A, 'have you heard "Clair de Lune"?', t0 + 120000, { names });
  assert.match(asked.note, /remembers/);
  const never = E.converseOne(idx, save, A, 'have you heard "Song Nobody Knows"?', t0 + 180000, { names });
  assert.match(never.note, /hasn't heard/);
  // the same song is always first heard the same way by the same creature
  const { save: s2, A: A2, idx: i2 } = world();
  const f2 = E.converseOne(i2, s2, A2, 'I want to show you "Clair de Lune" by Debussy', t0, { names: E.namesFor(i2, s2) });
  assert.equal(Math.round(f2.music.op * 100), Math.round(first.music.op * 100));
  // its taste in music, and the desktop's listening, agree
  assert.equal(E.musicTaste(idx, A, 'lo-fi'), Math.round(E.genreTaste(idx, A, 'lofi') * 100) / 100);
  const fav = E.converseOne(idx, save, A, 'what kind of music do you like?', t0 + 240000, { names });
  assert.match(fav.note, /favourite kind of music/);
});

test('remarks about its taste get a true answer, and "why?" follows on', () => {
  const { idx, save, A, names } = world();
  const t0 = Date.now();
  for (const g of ['jazz', 'metal', 'folk', 'classical']) {
    const r = E.converseOne(idx, save, A, `Musharna I never took you for someone who'd like ${g}`, t0, { names });
    const taste = E.genreTaste(idx, A, E.genreIn(g));
    if (taste >= 0.45) assert.match(r.note, /of course|always has|noticed|loves|likes/);
    else if (taste < -0.15) assert.match(r.note, /doesn't like|really doesn't|had it right/);
    else assert.ok(r.note.length > 10);
  }
  const why = E.converseOne(idx, save, A, 'why?', t0 + 1000, { names });
  assert.ok(why && why.note.length > 10);
  const op1 = E.converseOne(idx, save, A, 'do you like swimming?', t0 + 2000, { names });
  const op2 = E.converseOne(idx, save, A, "you love swimming, don't you?", t0 + 3000, { names });
  assert.equal(op1.yes, op2.yes, 'the same feeling both ways');
});

test('who likes, who is good at, who has done: real answers for each', () => {
  const { idx, save, A, B, C, names } = world();
  E.noteDid(B, 'fishing'); E.noteDid(B, 'fishing');
  const done = E.groupAnswers(idx, save, [A.uid, B.uid, C.uid], E.understand('who has been fishing?', { names }));
  assert.equal(done[0].uid, B.uid); assert.match(done[0].text, /fishing 2 times/);
  assert.match(done.at(-1).text, /never been fishing/);
  const like = E.groupAnswers(idx, save, [A.uid, B.uid, C.uid], E.understand('who likes cooking?', { names }));
  assert.equal(like.length, 3); assert.ok(like[0].v >= like[2].v);
  const fast = E.groupAnswers(idx, save, [A.uid, B.uid, C.uid], E.understand("who's the fastest?", { names }));
  assert.ok(fast[0].v >= fast[1].v && /Speed/.test(fast[0].text));
  const third = E.converseOne(idx, save, A, 'does Cogsy like cooking?', Date.now(), { names });
  assert.match(third.note, /Cogsy/);
  const fav = E.converseOne(idx, save, A, "what's your favourite thing to do?", Date.now(), { names });
  assert.match(fav.note, /favourite thing to do is/);
  const day = E.converseOne(idx, save, B, 'what did you do today?', Date.now(), { names });
  assert.ok(day && day.note.length > 10);
});

test('something it asked for itself is never refused for being tired', () => {
  const { idx, save, A } = world();
  A.needs.energy = 3;
  assert.equal(E.canDo(idx, save, A, 'fishing').ok, false);
  E.startWish(save, { uid: A.uid, key: 'wish:fishing', act: 'fishing', text: 'wants to go fishing' });
  assert.equal(E.canDo(idx, save, A, 'fishing').ok, true);
  const r = E.volunteers(idx, save, [A.uid], E.INVITES.find((i) => i.id === 'fishing'));
  assert.equal(r.yes[0]?.uid, A.uid);
  // asking to play, even worn out
  E.startWish(save, { uid: A.uid, key: 'wish:play', text: 'wants to play' });
  const out = E.applyCare(idx, A, 'play', { save, asked: E.wishedFor(save, A.uid, 'play') });
  assert.notEqual(out.reaction, 'tired');
});

test('debug: unlock everything, then everything back as it was', () => {
  const { idx, save } = world();
  save.inventory['med-potion'] = 3; save.wallet = 9000;
  const keepCount = Object.keys(save.inventory).length;
  const on = E.setUnlockAll(idx, save, true);
  assert.ok(on.ok && on.added > 50);
  assert.ok(E.BLUEPRINTS.every((b) => E.blueprintUnlocked(save, b)));
  assert.equal(save.boxes[0].build.size, E.MAX_YARD_SIZE);
  assert.ok(E.ownedToys(save).length === E.TOY_SHOP.length);
  assert.ok(E.placeFeature(save, 0, 'carousel', 0, 5).ok);
  // a real purchase while it's on is kept
  const stock = E.shopStock(idx, save); const line = stock.lines.find((l) => l.left > 0);
  assert.ok(E.buy(idx, save, line.id).ok);
  const off = E.setUnlockAll(idx, save, false);
  assert.ok(off.restored);
  assert.equal(save.boxes[0].build.features.length, 0, 'what was built with it came down');
  assert.equal(save.boxes[0].build.size, 0);
  assert.equal(save.inventory['med-potion'] >= 3, true);
  assert.ok((save.inventory[line.id] ?? 0) >= 1, 'the real purchase stayed');
  assert.ok(Object.keys(save.inventory).filter((k) => save.inventory[k] > 0).length <= keepCount + 2);
  assert.equal(E.unlockAllOn(save), false);
});

test('Data Lab: learnsets bring TM, TR, tutor and egg moves', () => {
  const ds = E.createDefaultDataset();
  const sp = ds.species[0], m = ds.moves;
  // a gen-8 "M" on the TR list is a TR; other "M"s are TMs; "T" tutor; "E" egg
  m.push({ id: 'swords-dance', name: 'Swords Dance', type: ds.types[0].id, category: 'status', power: 0, accuracy: 100, pp: 20, priority: 0 });
  const p = E.parsePaste(`export const Learnsets = { "${sp.id}": { learnset: { swordsdance: ["8M", "9M"], "${m[0].id}": ["8M", "8L5"], "${m[1].id}": ["8T"], "${m[2].id}": ["9E"] } } };`);
  E.applyImport(ds, 'learnset', p.rows, E.guessMapping(p.columns, 'learnset'), {});
  const s = ds.species.find((x) => x.id === sp.id);
  assert.ok(s.tms.includes('swords-dance') && s.trs.includes('swords-dance'), 'a TM in gen 9 and a TR in gen 8');
  assert.ok(s.tms.includes(m[0].id));
  assert.deepEqual(s.tutor, [m[1].id]);
  assert.deepEqual(s.eggMoves, [m[2].id]);
  const idx = E.indexDataset(ds);
  assert.ok(E.canLearnTm(idx, idx.species.get(sp.id), 'swords-dance'));
});
