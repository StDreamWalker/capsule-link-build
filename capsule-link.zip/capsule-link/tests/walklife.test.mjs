// Walk life (thoughts, encounters, catching), the brand layer and trainer card compatibility.
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const idx = E.indexDataset(E.createDefaultDataset());

// encounters lean on the environment and time of day
const night = new Date(2026, 9, 1, 23).getTime();
const water = E.encounterTable(idx, { env: ['water'], t: new Date(2026, 9, 1, 12).getTime(), walkMinutes: 10 });
assert.equal(idx.species.get(water[0].id).types.includes('tide'), true, 'water walks turn up water types');
const snow = E.encounterTable(idx, { env: ['snow'], t: night, walkMinutes: 10 });
assert.equal(idx.species.get(snow[0].id).types.includes('frost'), true);
const sum = water.reduce((a, r) => a + r.p, 0);
assert.ok(Math.abs(sum - 1) < 1e-9, 'probabilities add up');
assert.deepEqual(E.normalizeEnv(['urban', 'forest', 'snow', 'bogus']), ['urban', 'forest'], 'at most two environments');
assert.ok(E.encounterChance({ walkMinutes: 60 }) > E.encounterChance({ walkMinutes: 0 }), 'longer walks find more');

let enc = null;
for (let s = 0; !enc && s < 50; s++) enc = E.rollEncounter(idx, { env: ['forest'], walkMinutes: 15, seed: s });
assert.ok(enc && idx.species.has(enc.speciesId));
const c = E.caughtCreature(idx, enc, { trainer: 'Ziggy', location: { kind: 'phone', device: 'p1' } });
assert.match(c.memories[0].text, /Ziggy/);
assert.ok(E.tryCatch({ catchRate: 0.9 }, 1, 1).p > E.tryCatch({ catchRate: 0.9 }, 0, 1).p, 'better throws catch more');

// thoughts name the creature; firsts are only new places
assert.match(E.thoughtFor(idx, c, { env: ['urban'], seed: 3 }), new RegExp(E.displayName(idx, c)));
const firsts = E.walkFirsts(c, ['water', 'urban'], new Date(2026, 9, 1, 12).getTime());
assert.deepEqual(firsts.map((f) => f.key), ['water', 'urban']);
c.seen = { water: 1 };
assert.deepEqual(E.walkFirsts(c, ['water'], new Date(2026, 9, 1, 12).getTime()), []);

// inside a capsule, hunger barely moves
const a = E.createCreature(idx, 'sproutle', { location: { kind: 'capsule', tag: 'x' }, now: 0 });
const b = E.createCreature(idx, 'sproutle', { location: { kind: 'box', box: 0, slot: 0 }, now: 0 });
E.tickNeeds(idx, a, 3600000 * 6); E.tickNeeds(idx, b, 3600000 * 6);
assert.ok(a.needs.fullness > b.needs.fullness, 'resting in a capsule');

// brand: every default word follows, case kept
const f = E.brandRewriter({ app: 'OrbLink', ball: 'orb', creature: 'monster', company: 'Orbis Labs' });
assert.equal(f('Capsule Link: put a creature in the capsule. Capsules hold Creatures.'), 'OrbLink: put a monster in the orb. Orbs hold Monsters.');
assert.equal(f('Contacting Capsule Link Network servers…'), 'Contacting Orbis Labs servers…');
assert.equal(E.brandRewriter({})('a capsule'), 'a capsule', 'defaults leave text alone');
assert.equal(E.normalizeBrand({ ball: 'box' }).balls, 'boxes');
const ds = E.normalizeDataset({ ...E.createDefaultDataset(), brand: { creature: 'beast' } });
assert.equal(ds.brand.creatures, 'beasts', 'the brand lives in the data set (and so reaches phones)');

// trainer cards from older versions still load
const old = E.normalizeCard({ avatar: { hair: 'cap', accessory: 'glasses', outfit: '#3d7bff' } });
assert.equal(old.avatar.hat, 'cap'); assert.equal(old.avatar.hair, 'short');
assert.deepEqual(old.avatar.accessories, ['glasses']);
const many = E.normalizeCard({ avatar: { accessories: ['glasses', 'scarf', 'flower', 'blush', 'mask', 'bogus'] } });
assert.equal(many.avatar.accessories.length, 4, 'at most four extras');
assert.equal(E.normalizeCard({ avatar: { sprite: 'trainers/ace.png' } }).avatar.sprite, 'trainers/ace.png');
assert.equal(E.normalizeCard({ avatar: { sprite: '../evil.png' } }).avatar.sprite, '');
console.log('walk life, brand, cards: ok');

// renaming things changes what phones must download, without breaking capsule numbering
{
  const a = E.indexDataset(E.createDefaultDataset());
  const b = E.indexDataset({ ...E.createDefaultDataset(), brand: { app: 'OrbLink' } });
  assert.equal(a.hash, b.hash, 'capsule numbering unchanged');
  assert.notEqual(a.syncHash, b.syncHash, 'phones pick up new names on their next sync');
  console.log('sync fingerprint: ok');
}

// PokéAPI tables fill the extras by national number
{
  const ds = E.createDefaultDataset();
  const T = {};
  assert.equal(E.addCsvExtrasText(T, 'id,identifier,species_id,height,weight,base_experience,order,is_default\n1,a,1,7,69,64,1,1\n10001,a-mega,1,7,69,99,2,0'), 'pokemon');
  assert.equal(E.addCsvExtrasText(T, 'id,identifier,generation_id,evolves_from_species_id,evolution_chain_id,color_id,shape_id,habitat_id,gender_rate,capture_rate,base_happiness,is_baby,hatch_counter,has_gender_differences,growth_rate_id\n1,a,1,,1,5,8,3,1,45,50,0,20,0,4'), 'species');
  assert.equal(E.addCsvExtrasText(T, 'pokemon_id,stat_id,base_stat,effort\n1,4,65,1'), 'stats');
  const r = E.applyCsvExtras(ds, T);
  const sp = ds.species.find((s) => s.no === 1);
  assert.equal(r.updated, 1);
  assert.equal(sp.baseExp, 64, 'the default form wins, not the mega');
  assert.equal(sp.growthRate, 'wavy');
  assert.equal(sp.catchRate, 45);
  assert.deepEqual(sp.effortYield, { spa: 1 });
  console.log('extras tables: ok');
}
