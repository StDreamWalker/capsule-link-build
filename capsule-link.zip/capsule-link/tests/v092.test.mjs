// 0.9.2: fossils, the Fossil Revival Machine, the Egg Incubator, memory-import confidence, rotated clothes.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const base = () => { const idx = E.indexDataset(E.createDefaultDataset()); const save = E.createSave('Kim', 2); E.tickAll(idx, save); return { idx, save }; };

test('fossils are items; a revival machine brings one back after a few hours into its own yard', () => {
  const { idx, save } = base();
  assert.equal(E.itemInfo(idx, 'fossil-helix').name, 'Helix Fossil');
  save.wallet = 5000; assert.ok(E.buyBlueprint(save, 'fossil-machine').ok);
  const f = E.placeFeature(save, 0, 'fossil-machine', 0, 0).feature;
  save.inventory['fossil-helix'] = 1;
  const t = Date.now();
  const r = E.startRevival(idx, save, 0, f.id, 'fossil-helix', t);
  assert.ok(r.ok, r.reason); assert.equal(save.inventory['fossil-helix'], 0);
  assert.ok(E.revivalStatus(idx, save, f.id, t + 1000).busy);
  assert.equal(E.removeFeature(save, 0, f.id).ok, false);
  assert.equal(E.collectRevival(idx, save, f.id, { t: t + 1000 }).ok, false);
  const got = E.collectRevival(idx, save, f.id, { t: t + E.REVIVE_HOURS * 3600000 + 1 });
  assert.ok(got.ok); assert.equal(got.creature.location.kind, 'box'); assert.equal(got.creature.location.box, 0);
  assert.ok(got.creature.memories.some((m) => /Fossil/.test(m.text)));
  assert.ok(E.revivalStatus(idx, save, f.id).idle);
});

test('scavenging very rarely digs up a fossil', () => {
  let found = 0, runs = 0;
  const { idx, save } = base();
  const c = E.createCreature(idx, idx.ds.species[0].id, { level: 10 }); save.creatures[c.uid] = c;
  for (let i = 0; i < 1500; i++) {
    const res = E.finishActivity(idx, save, c.uid, 'scavenging', 1, {}, Date.now() + i * 7919, { check: false });
    assert.ok(res.ok !== false, res.reason); runs++;
  }
  found = Object.keys(save.inventory).filter((k) => k.startsWith('fossil-')).reduce((n, k) => n + save.inventory[k], 0);
  assert.ok(found > 0 && found < runs * 0.08, `fossils: ${found} in ${runs}`);
});

test('eggs in a yard with an incubator hatch faster', () => {
  const { idx, save } = base();
  const mk = (box) => { const e = E.createCreature(idx, idx.ds.species[0].id, { level: 1, location: { kind: 'box', box, slot: 0 } }); E.makeEgg(e); save.creatures[e.uid] = e; return e; };
  const warm = mk(0), cold = mk(1);
  save.wallet = 5000; E.buyBlueprint(save, 'incubator'); E.placeFeature(save, 0, 'incubator', 0, 0);
  const t = Date.now();
  E.incubate(save, t); E.incubate(save, t + 30 * 60000);
  assert.ok(warm.egg.steps < cold.egg.steps);
  assert.ok(warm.incAt); assert.equal(cold.incAt, undefined);
});

test('memory-import confidence: PID gets far, memories make it certain', () => {
  const a = E.memoryConfidence({ speciesId: 'x', pid: '1234', nickname: 'Bo' });
  const b = E.memoryConfidence({ speciesId: 'x' });
  assert.ok(a.pct > b.pct && a.pct < 100);
  assert.equal(E.memoryConfidence({ speciesId: 'x', memories: ['the beach'] }).pct, 100);
});

test('clothes can be turned, and keep the turn per form', () => {
  const save = { creatures: { a: { uid: 'a', speciesId: 'x', clothes: [] } }, inventory: { 'clothes-bow': 1 } };
  assert.ok(E.wear(save, 'a', 'clothes-bow', 0.5, 0.2, 1, null, 45).ok);
  assert.equal(E.wornAt(save.creatures.a.clothes[0], 'x').r, 45);
  assert.ok(E.wear(save, 'a', 'clothes-bow', 0.5, 0.2, 1, null, 400).ok);
  assert.equal(E.wornAt(save.creatures.a.clothes[0], 'x').r, 180);
});

test('Pokéblocks blend like the games: flavours mixed, weakened, multiplied by top RPM; colours and Black for doubles', () => {
  const cheri = { id: 'cheri', name: 'Cheri Berry' }, pecha = { id: 'pecha', name: 'Pecha Berry' }, chesto = { id: 'chesto', name: 'Chesto Berry' };
  assert.deepEqual(E.berryBlend(cheri).flavors, { spicy: 10, dry: 0, sweet: 0, bitter: 0, sour: 0 });
  const b = E.blendPokeblock([cheri, pecha], 110);
  // spicy 10 - dry 0 = 10, sweet 10 - bitter 0 = 10, sour 0 - spicy 10 = -10, dry 0 - sweet 10 = -10 → two negatives: -2 each → 8, 8; ×1.33 → 11
  assert.equal(b.flavors.spicy, 11); assert.equal(b.flavors.sweet, 11); assert.equal(b.color, 'purple');
  assert.equal(b.level, 11); assert.equal(b.feel, 23);
  assert.equal(E.blendPokeblock([cheri, cheri], 110, { rng: () => 0.1 }).color, 'black');
  assert.equal(E.blendPokeblock([cheri, chesto], 60).color, 'blue'); // dry cancels the spicy out; dry stays
  assert.ok(E.blenderRpm(50, 'perfect', 1) > E.blenderRpm(50, 'good', 1));
  assert.equal(E.blenderRpm(90, 'good', 1), 90);
  assert.equal(E.blenderRpm(8, 'miss', 1), E.RPM_MIN);
});

test('feeding Pokéblocks raises conditions and sheen; a full sheen refuses more', () => {
  const { idx, save } = base();
  const c = E.createCreature(idx, idx.ds.species[0].id, { level: 5 }); save.creatures[c.uid] = c;
  const b = E.addPokeblock(save, { flavors: { spicy: 20, dry: 0, sweet: 5, bitter: 0, sour: 0 }, level: 20, feel: 200, color: 'purple', name: 'Purple Pokéblock' });
  const r = E.feedPokeblock(idx, save, c.uid, b.id);
  assert.ok(r.ok); assert.ok(c.condition.cool >= 18); assert.ok(c.condition.cute >= 4); assert.equal(c.condition.sheen, 200);
  const b2 = E.addPokeblock(save, { flavors: { spicy: 2, dry: 0, sweet: 0, bitter: 0, sour: 0 }, level: 2, feel: 100, color: 'red', name: 'Red Pokéblock' });
  assert.ok(E.feedPokeblock(idx, save, c.uid, b2.id).ok); assert.equal(c.condition.sheen, 255);
  const b3 = E.addPokeblock(save, { flavors: { spicy: 2, dry: 0, sweet: 0, bitter: 0, sour: 0 }, level: 2, feel: 10, color: 'red', name: 'Red Pokéblock' });
  assert.equal(E.feedPokeblock(idx, save, c.uid, b3.id).ok, false);
  assert.equal(E.sheenStars(255), 9);
});

test('play rooms on the friends server: invite, join, and messages passed to the others', async () => {
  const { makeServer } = await import('../server/core.mjs');
  const { FriendsClient } = await import('../shared/net/friends.js');
  const os = await import('node:os'); const fs = await import('node:fs'); const path = await import('node:path');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cl-rooms-'));
  const port = 48000 + Math.floor(Math.random() * 1000);
  const srv = makeServer({ port, dataDir: dir });
  await new Promise((r) => setTimeout(r, 200));
  try {
    const base = `http://127.0.0.1:${port}`;
    const a = new FriendsClient(base), b = new FriendsClient(base);
    await a.signup('amy', 'password1', 'Amy'); await b.signup('bob', 'password1', 'Bob');
    await a.request('bob'); await b.accept('amy');
    if (typeof WebSocket === 'undefined') return; // older Node: the socket half is tested in the app
    const got = [];
    a.listen(() => {}); b.listen((n) => got.push(n));
    b.onRoom((m) => got.push(m));
    await new Promise((r) => setTimeout(r, 300));
    const room = (await a.openRoom('blender', ['bob'])).room;
    await new Promise((r) => setTimeout(r, 150));
    assert.ok(got.some((n) => n.what === 'room' && n.id === room.id));
    assert.equal((await b.rooms()).incoming.length, 1);
    await b.joinRoom(room.id);
    a.roomSend(room.id, { t: 'hello-there' });
    await new Promise((r) => setTimeout(r, 200));
    assert.ok(got.some((m) => m.type === 'room' && m.data?.t === 'hello-there' && m.from === 'amy'));
    await a.leaveRoom(room.id);
    a.ws?.close(); b.ws?.close(); a.token = null; b.token = null;
  } finally { await srv.close(); }
});
