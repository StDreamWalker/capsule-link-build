import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import * as E from '../shared/engine/index.js';
import { Store } from '../desktop/src/main/storage.js';

test('trainer cards: defaults, numbers and cleaning bad data', () => {
  const a = E.defaultTrainerCard('Ziggy', 'abcd1234');
  assert.ok(E.CARD_DESIGNS.some((d) => d.id === a.design));
  assert.match(E.trainerNumber('abcd1234'), /^\d{4}-\d{4}$/);
  assert.equal(E.trainerNumber('abcd1234'), E.trainerNumber('abcd1234'));
  const n = E.normalizeCard({ design: 'nope', accent: 'red', title: 'x'.repeat(40), avatar: { hair: 'mullet-9000', skin: '#123456' } });
  assert.equal(n.design, 'classic');
  assert.equal(n.accent, E.CARD_ACCENTS[0]);
  assert.equal(n.title.length, 14);
  assert.equal(n.avatar.hair, 'short');
  assert.equal(n.avatar.skin, '#123456');
  const save = { trainer: { name: 'Old' } };
  E.ensureTrainerCard(save);
  assert.ok(save.trainer.id && save.trainer.card.avatar);
});

test('profiles: an old single save becomes the first profile; switching and removing work', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cl-prof-'));
  const legacy = E.createSave('Legacy');
  legacy.stats.totalSteps = 1234;
  fs.writeFileSync(path.join(dir, 'save.json'), JSON.stringify(legacy));
  const store = new Store(dir).load();
  let list = store.listProfiles();
  assert.equal(list.length, 1);
  assert.equal(list[0].trainer.name, 'Legacy');
  assert.equal(list[0].steps, 1234);
  assert.ok(store.save.trainer.card, 'old saves get a card');
  assert.ok(!fs.existsSync(path.join(dir, 'save.json')), 'the old file moves to backups');

  const id = store.createProfile({ name: 'Ziggy' });
  list = store.listProfiles();
  assert.equal(list.length, 2);
  assert.equal(store.save.trainer.name, 'Legacy', 'creating does not log on');
  store.save.inventory.marker = 1;
  store.openProfile(id);
  assert.equal(store.save.trainer.name, 'Ziggy');
  assert.ok(Object.keys(store.save.creatures).length > 0, 'a new trainer gets starter creatures');
  // the first profile's change was written before switching
  const first = list.find((p) => p.trainer.name === 'Legacy').id;
  assert.equal(JSON.parse(fs.readFileSync(store.profileFile(first), 'utf8')).inventory.marker, 1);

  // reopening the app lands on the last trainer
  const again = new Store(dir).load();
  assert.equal(again.save.trainer.name, 'Ziggy');
  again.deleteProfile(id);
  assert.equal(again.save.trainer.name, 'Legacy');
  assert.throws(() => again.deleteProfile(first), /last profile/);
});
