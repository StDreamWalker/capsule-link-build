import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

// 1.9.2: time away is lived through — they nap while you're out, so coming back after work finds one or two
// still asleep, not everyone needing a nap at once.
test('after a working day away, most have already napped and only a few are still asleep', () => {
  const ds = E.createDefaultDataset(), idx = E.indexDataset(ds);
  const d = new Date(); d.setHours(8, 0, 0, 0); const t0 = d.getTime();
  for (const hours of [9, 11]) {
    let asleep = 0, low = 0, napped = 0; const N = 12;
    for (let i = 0; i < N; i++) {
      const c = E.createCreature(idx, ds.species[i % ds.species.length].id, { level: 10 + i, seed: `s${i}`, location: { kind: 'ranch' } });
      c.needs = { energy: 55 + (i * 7) % 40, fullness: 80, joy: 70, hygiene: 80 }; c.needsAt = t0;
      E.tickNeeds(idx, c, t0 + hours * 3600000);
      if (E.isAsleep(c, t0 + hours * 3600000)) asleep++;
      if (c.needs.energy < 30) low++;
      if ((c.lastNap ?? 0) > t0) napped++;
    }
    assert.ok(asleep <= 3, `${hours}h away: ${asleep} of ${N} asleep`);
    assert.ok(napped >= N / 2, `${hours}h away: only ${napped} napped while you were out`);
    assert.ok(low <= 2, `${hours}h away: ${low} low on energy`);
  }
});

test('a short absence is still ticked the ordinary way', () => {
  const ds = E.createDefaultDataset(), idx = E.indexDataset(ds);
  const d = new Date(); d.setHours(14, 0, 0, 0); const t0 = d.getTime();
  const c = E.createCreature(idx, ds.species[0].id, { level: 10, seed: 'q', location: { kind: 'ranch' } });
  c.needs = { energy: 80, fullness: 80, joy: 80, hygiene: 80 }; c.needsAt = t0;
  E.tickNeeds(idx, c, t0 + 20 * 60000);
  assert.ok(c.needs.energy < 80 && c.needs.energy > 70);
});
