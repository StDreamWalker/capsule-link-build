import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { makeBackup, readBackup, backupFileName } from '../shared/engine/backup.js';
import { Store } from '../desktop/src/main/storage.js';
import { Hub } from '../shared/net/hub.js';
import { MSG } from '../shared/engine/index.js';
import { sizeFactor, heightOf } from '../shared/ui/creatureSize.js';

test('a PC backup round-trips every profile, the data set and textures', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cl-bk-'));
  const st = new Store(dir).load();
  const second = st.createProfile({ name: 'Rival' });
  st.save.trainer.name = 'Kim';
  st.save.inventory.berry = 7;
  st.dataset.brand = { ...(st.dataset.brand ?? {}), app: 'Nexus Link' };
  st.setDataset(st.dataset);
  st.writeNow();
  fs.writeFileSync(path.join(st.textures, 'ui', 'logo.png'), Buffer.from([137, 80, 78, 71, 1, 2, 3]));
  const b = st.fullBackup({ version: '0.3.1' });
  const text = JSON.stringify(b);
  const r = readBackup(text);
  assert.equal(r.ok, true);
  assert.equal(r.kind, 'pc');
  assert.match(r.summary, /2 trainers/);
  assert.match(r.summary, /1 texture/);

  // things go wrong: the save is wiped, a profile deleted, the texture gone, the name changed
  st.save.inventory = {}; st.save.trainer.name = 'Oops'; st.writeNow();
  st.deleteProfile(second);
  fs.rmSync(path.join(st.textures, 'ui', 'logo.png'));
  st.dataset.brand.app = 'Broken'; st.setDataset(st.dataset);

  const out = st.restoreBackup(text, { version: '0.3.1' });
  assert.equal(out.profiles, 2);
  assert.equal(out.textures, 1);
  assert.equal(st.save.trainer.name, 'Kim');
  assert.equal(st.save.inventory.berry, 7);
  assert.equal(st.listProfiles().length, 2);
  assert.equal(st.dataset.brand.app, 'Nexus Link');
  assert.ok(fs.existsSync(path.join(st.textures, 'ui', 'logo.png')));
  // what was there before the restore was kept, and shows up in the list
  const list = st.listBackups();
  const safety = list.find((x) => x.file === out.safety);
  assert.ok(safety, 'safety backup listed');
  assert.equal(safety.kind, 'pc');
  assert.match(safety.summary, /before restore/);
  // and it can be read back and restored too (undo)
  const undo = readBackup(st.readBackupFile(out.safety));
  assert.equal(undo.backup.profiles.saves[st.activeId]?.trainer.name ?? Object.values(undo.backup.profiles.saves)[0].trainer.name, 'Oops');
});

test('restore refuses phone backups and junk without touching anything', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cl-bk-'));
  const st = new Store(dir).load();
  const before = JSON.stringify(st.save);
  assert.throws(() => st.restoreBackup('{"hello":1}'), /not a backup/);
  assert.throws(() => st.restoreBackup('nope'), /not JSON/);
  const phone = makeBackup('phone', '0.3.1', { save: st.save, pcList: [] });
  assert.throws(() => st.restoreBackup(JSON.stringify(phone)), /phone backup/);
  assert.equal(JSON.stringify(st.save), before);
  assert.equal(st.listBackups().filter((b) => b.kind === 'pc').length, 0);
});

test('older single-save exports are still read', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cl-bk-'));
  const st = new Store(dir).load();
  const r = readBackup(JSON.stringify(st.save));
  assert.equal(r.kind, 'save');
  assert.match(backupFileName('phone', 'My Phone!'), /^capsule-link-phone-backup-my-phone-\d{4}-\d\d-\d\d-\d{4}\.json$/);
});

test('phones keep backups on the PC over the link', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cl-bk-'));
  const st = new Store(dir).load();
  const sent = [];
  const hub = new Hub({
    mode: 'home', getIdx: () => st.idx, getSave: () => st.save, onSaveChanged: () => {},
    backups: { put: (d, b) => st.keepPhoneBackup(d, b), list: () => st.listBackups().filter((b) => b.kind === 'phone'), get: (f) => st.readBackupFile(f) },
  });
  const client = { id: 'p1', authed: true, kind: 'phone', name: 'Pixel 8', conn: { send: (t) => sent.push(JSON.parse(t)) } };
  hub.send = (c, type, data) => sent.push({ type, ...data });
  const phoneSave = { ...st.save, trainer: { ...st.save.trainer, name: 'Walker' } };
  hub.onBackup(client, { type: MSG.BACKUP_PUT, backup: makeBackup('phone', '0.3.1', { save: phoneSave, pcList: [] }) });
  assert.equal(sent.at(-1).ok, true, sent.at(-1).error);
  assert.match(sent.at(-1).file, /^capsule-link-phone-backup-pixel-8-/);
  hub.onBackup(client, { type: MSG.BACKUP_LIST });
  const list = sent.at(-1).list;
  assert.equal(list.length, 1);
  assert.match(list[0].summary, /Walker/);
  hub.onBackup(client, { type: MSG.BACKUP_GET, file: list[0].file });
  assert.equal(readBackup(sent.at(-1).text).backup.save.trainer.name, 'Walker');
  // a PC backup can't be pushed in as a phone one
  hub.onBackup(client, { type: MSG.BACKUP_PUT, backup: { hello: 1 } });
  assert.equal(sent.at(-1).ok, false);
});

test('creature sizes follow height, squeezed into a sane range', () => {
  const f = (h) => sizeFactor({ height: h });
  assert.ok(Math.abs(f(0.7) - 0.31) < 0.01, 'Bulbasaur-sized');
  assert.ok(Math.abs(f(14.5) - 2.86) < 0.05, 'Wailord-sized: as before');
  assert.equal(f(0.01), f(0.05), 'tiny ones stop shrinking');
  assert.equal(f(14.5), f(100), 'huge ones stop growing');
  assert.equal(heightOf({}), 1);
  assert.ok(heightOf({ baseStats: { hp: 45, atk: 49, def: 49, spa: 65, spd: 65, spe: 45 } }) < 1, 'low stat totals are guessed small');
});

test('a phone can tap the PC’s virtual capsules and sees the dock', async () => {
  const { makeVirtualTag, toHex, fromHex, EGG_DEFAULT_STEPS, makeEgg, applyWalk, createCreature } = await import('../shared/engine/index.js');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cl-vt-'));
  const st = new Store(dir).load();
  const t = makeVirtualTag('04AABBCCDDEEFF'); t.mem.set([3, 0, 0xfe], 0);
  st.save.virtualTags = { '04AABBCCDDEEFF': toHex(t.mem) };
  const sent = [];
  let changed = 0;
  const hub = new Hub({ mode: 'home', getIdx: () => st.idx, getSave: () => st.save, onSaveChanged: () => { changed++; }, getDock: () => ({ uid: '04AABBCCDDEEFF', state: 'creature', name: 'Sproutle' }) });
  hub.send = (c, type, data) => sent.push({ type, ...data });
  const client = { id: 'p', authed: true, kind: 'phone', name: 'Phone' };
  await hub.onVirtualTag(client, { type: MSG.VTAG_LIST });
  assert.equal(sent.at(-1).list[0].docked, true);
  await hub.onVirtualTag(client, { type: MSG.VTAG_WRITE, uid: '04AABBCCDDEEFF', page: 4, hex: '01020304' });
  assert.equal(sent.at(-1).ok, true);
  await hub.onVirtualTag(client, { type: MSG.VTAG_READ, uid: '04AABBCCDDEEFF' });
  assert.deepEqual([...fromHex(sent.at(-1).hex).slice(0, 4)], [1, 2, 3, 4]);
  assert.equal(changed, 1);
  // eggs: walking takes off double, and they hatch
  const c = makeEgg(createCreature(st.idx, st.idx.ds.species[0].id, { level: 1 }), 1000);
  applyWalk(st.idx, c, 400);
  assert.equal(c.egg.steps, 200);
  const out = applyWalk(st.idx, c, 150);
  assert.equal(c.egg, undefined);
  assert.equal(out.events[0].kind, 'hatched');
  assert.ok(EGG_DEFAULT_STEPS > 0);
});
