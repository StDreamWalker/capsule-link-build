import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as E from '../shared/engine/index.js';
import * as S from '../shared/atlas/scan.js';

// 1.9.5: how they feel about where they are; catching wild ones in battle (the games' odds).
let dex = null;
function pokedex() {
  if (dex) return dex;
  const p = E.parsePaste(readFileSync(new URL('../vendor/showdown/data/pokedex.ts', import.meta.url), 'utf8'));
  const ds = E.createDefaultDataset();
  E.applyImport(ds, 'species', p.rows, E.guessMapping(p.columns, 'species'), { replace: true });
  return (dex = E.indexDataset(ds));
}
const ARCTIC = { at: 2, label: 'Tromsø, Norway', C: { P: 0.4, C: 0.6 }, H: { i: 0.8, m: 0.6, s: 0.5 }, hab: [], weather: 'snow', temp: -8, night: true };
const DESERT = { at: 3, label: 'Phoenix, Arizona', C: { A: 1 }, H: { d: 0.9, u: 0.5, r: 0.5 }, hab: [], weather: 'sunny', temp: 39, night: false };

test('a creature made for the cold is at home in the snow and wilts in the desert', () => {
  const idx = pokedex();
  const sp = idx.species.get('snorunt'), prof = S.atlasProfileFor(idx, sp);
  assert.ok(prof && /[CP]/.test(prof.clim));
  const c = E.createCreature(idx, 'snorunt', { level: 20, seed: 's', location: { kind: 'phone' } });
  assert.equal(E.feelPlace(idx, c, ARCTIC, prof, { apply: true }).kind, 'home');
  assert.equal(E.feelPlace(idx, c, DESERT, prof, { apply: true }).kind, 'hot');
});

test('firsts become memories, and a place visited over and over gets boring for a playful one', () => {
  const idx = pokedex();
  const c = E.createCreature(idx, 'pikachu', { level: 20, seed: 'p', location: { kind: 'phone' } });
  c.toldStyle = 'playful';
  const prof = S.atlasProfileFor(idx, idx.species.get('pikachu'));
  const r = E.feelPlace(idx, c, ARCTIC, prof, { apply: true, trainer: 'Kim' });
  assert.ok(r.firsts.includes('snow'));
  assert.ok(c.memories.some((m) => /snow for the first time/.test(m.text)));
  const park = { label: 'Mount Trashmore Park', C: { M: 1 }, H: { h: 0.6, g: 0.4 }, hab: [], weather: 'cloudy', temp: 15 };
  let last = null;
  for (let i = 0; i < 14; i++) last = E.feelPlace(idx, c, { ...park, at: 100 + i }, prof, { apply: true });
  assert.ok(['bored', 'meh', 'nostalgic'].includes(last.kind), last.kind);
  assert.ok(c.felt['place:mount trashmore park'] >= 14);
});

test('"how do you like it here?" is answered from what it last felt', () => {
  const idx = pokedex(), save = E.createSave('Kim', 1);
  const c = E.createCreature(idx, 'snorunt', { level: 20, seed: 'q', location: { kind: 'party', slot: 0 } });
  save.creatures[c.uid] = c;
  E.feelPlace(idx, c, ARCTIC, S.atlasProfileFor(idx, idx.species.get('snorunt')), { apply: true });
  const r = E.converseOne(idx, save, c, 'How do you like it here?');
  assert.ok(r?.exact && r.note === c.feltHere.line);
});

test('catch odds follow the games: health, status and the ball', () => {
  const odds = (o) => { let n = 0; for (let i = 0; i < 20000; i++) if (E.catchCheck(o).caught) n++; return n / 20000; };
  const full = odds({ rate: 45, hp: 100, maxhp: 100, level: 30, ball: E.ballBonus(4, {}) });
  const low = odds({ rate: 45, hp: 5, maxhp: 100, level: 30, ball: E.ballBonus(4, {}) });
  const lowSleep = odds({ rate: 45, hp: 5, maxhp: 100, status: 'slp', level: 30, ball: E.ballBonus(2, {}) });
  assert.ok(full < 0.15 && low > full * 2 && lowSleep > low, `${full} ${low} ${lowSleep}`);
  assert.equal(E.catchCheck({ rate: 3, hp: 100, maxhp: 100, ball: E.ballBonus(1, {}) }).caught, true);
  assert.equal(E.ballBonus(6, { foe: { types: ['water'] } }).mult, 3.5);
  assert.equal(E.ballBonus(15, { turn: 1 }).mult, 5);
  assert.equal(E.ballBonus(13, { night: true }).mult, 3);
  assert.equal(E.ballBonus(20, { foe: { weightkg: 350 } }).add, 30);
});

test('the one caught is the one battled: genes, temperament, size and moves kept; where it happened remembered', () => {
  const idx = pokedex();
  const foe = E.createCreature(idx, 'magikarp', { level: 12, seed: 42, location: { kind: 'wild' } });
  const c = E.caughtInBattle(idx, foe, { hp: 7, status: 'par', pp: [3], ball: 6, place: 'Virginia Beach, Virginia', stage: 'shoreline', trainer: 'Kim', turns: 4 });
  for (const k of ['speciesId', 'level', 'genes', 'temper', 'ability', 'shiny', 'size', 'height', 'weight', 'pid']) assert.deepEqual(c[k], foe[k], k);
  assert.equal(c.uid, foe.uid);
  assert.equal(c.hp, 7); assert.equal(c.status, 'par'); assert.equal(c.ball, '6');
  assert.ok(c.memories.some((m) => /Net Ball.*Virginia Beach.*4 turns/.test(m.text)));
  assert.equal(c.metPlace, 'Virginia Beach, Virginia');
});

test('on the water, the battle is on the water', () => {
  assert.equal(S.battlePlaceFor({ onWater: 'sea', hab: [] }), 'seafloor');
  assert.equal(S.battlePlaceFor({ onWater: 'lake', hab: [['f', 0.9]] }), 'shoreline');
  assert.equal(S.battlePlaceFor({ onWater: false, hab: [['f', 0.9]] }), 'forest');
});
