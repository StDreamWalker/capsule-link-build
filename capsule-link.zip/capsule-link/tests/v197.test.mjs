// 1.9.7: water depth and the ocean's zones in the PokéAtlas, places known for their creatures, following you.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { atlasCore } from '../shared/atlas/atlasCore.js';

const A = atlasCore();
function seaAt(depth) {
  const raw = { lat: 24.6, lon: -81.4, radiusKm: 1.5, elev: 0, elevSamples: Array(9).fill(0), climate: null, current: null, cond: null, geo: { ocean: true }, osm: null, poi: null, places: null, depth: depth == null ? null : { m: depth } };
  const env = A.deriveEnv(raw);
  const r = A.scoreAll(env, A.SPECIES, { includeLegendary: false, weather: 'none', time: 'any', useConditions: false });
  const p = (name) => r.list.filter((x) => x.s.name === name).reduce((a, x) => a + x.p, 0);
  return { env, p };
}

test('the sea floor’s depth and zone come from the reading, or an estimate from the distance to land', () => {
  assert.equal(seaAt(8).env.depth.zone, 'sunlight zone');
  assert.equal(seaAt(900).env.depth.zone, 'twilight zone');
  assert.equal(seaAt(2500).env.depth.zone, 'midnight zone');
  const est = seaAt(null).env.depth;
  assert.equal(est.est, true);
  assert.ok(est.m >= 1000);
});

test('deep-water Pokémon need deep water; reef and shallow-floor ones need a shallow floor; deeper is rarer', () => {
  const reef = seaAt(10), slope = seaAt(900);
  assert.ok(slope.p('Chinchou') > reef.p('Chinchou') * 5, 'lanternfish need the deep');
  assert.ok(reef.p('Luvdisc') > slope.p('Luvdisc') * 5, 'reef fish need the shallows');
  assert.ok(reef.p('Krabby') > slope.p('Krabby') * 3, 'crabs live on a reachable floor');
  // the sunlit zone is met far more often than the deep, but the deep is never impossible
  assert.ok(slope.p('Tentacool') > slope.p('Chinchou') * 3);
  assert.ok(slope.p('Lanturn') > 0);
});

test('the ERDDAP depth reading is parsed (nearest point, the range over the scan)', () => {
  const j = { table: { rows: [[24.59, -81.41, -12], [24.6, -81.4, -30], [24.61, -81.39, -900], [24.62, -81.38, 4]] } };
  const d = A.clParseDepth(j, 24.6, -81.4);
  assert.equal(d.m, 30); assert.equal(d.min, 12); assert.equal(d.max, 900);
  assert.equal(A.clParseDepth({ table: { rows: [[1, 1, 50]] } }, 1, 1), null);
  assert.match(A.clDepthUrl(24.6, -81.4, 1.5), /GEBCO_2020\.json\?elevation/);
});

test('a place known for its creatures names them first (New York: pigeons, rats, trash)', async () => {
  const { ATLAS_PAGE } = await import('../shared/atlas/atlasPage.js');
  assert.match(ATLAS_PAGE, /'519:2\.2 19:2 568:2'/);
  assert.match(ATLAS_PAGE, /is known for them/);
  assert.match(ATLAS_PAGE, /<span>Sea floor<\/span>/);
  assert.match(ATLAS_PAGE, /function clDepthFetch/);
});

test('the phone follows you while it’s open, with location on', () => {
  const m = readFileSync(new URL('../mobile/src/main.js', import.meta.url), 'utf8');
  assert.match(m, /navigator\.geolocation\.watchPosition/);
  assert.match(m, /clearWatch/);
  assert.match(m, /this\.emit\('position'\)/);
  assert.match(readFileSync(new URL('../mobile/src/atlas.js', import.meta.url), 'utf8'), /'position'/);
});
