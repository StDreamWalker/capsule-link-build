import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const idx = E.indexDataset(E.createDefaultDataset());

test('formula language', () => {
  assert.equal(E.evalFormula('1 + 2 * 3'), 7);
  assert.equal(E.evalFormula('2 ^ 3 ^ 2'), 512);
  assert.equal(E.evalFormula('a = 4\nb = a * 2\nb + 1'), 9);
  assert.equal(E.evalFormula('x > 3 ? "big" : "small"', { x: 5 }), 'big');
  assert.equal(E.evalFormula('[1/24, 1/8, 1/2][min(stage, 2)]', { stage: 5 }), 0.5);
  assert.equal(E.evalFormula('floor(10\n  + 5) // trailing comment'), 15);
  assert.equal(E.evalFormula('attacker.level * 2', { attacker: { level: 7 } }), 14);
  assert.equal(E.evalFormula('base = 10\n  * 3\nbase'), 30);
  assert.throws(() => E.evalFormula('foo + 1'), /Unknown name "foo"/);
  assert.throws(() => E.evalFormula('1 +'), /ends too early/);
  const r = E.checkFormula('constructor.constructor("return 1")()', {});
  assert.equal(r.ok, false);
});

test('dataset validates and builds exp tables', () => {
  assert.deepEqual(E.validateDataset(E.createDefaultDataset()), []);
  const t = E.expTable(idx, 'steady');
  assert.equal(t[100], 1000000);
  assert.equal(E.levelForExp(idx, 'steady', 125), 5);
  for (const g of idx.ds.growthRates) {
    const tb = E.expTable(idx, g.id);
    for (let i = 2; i < tb.length; i++) assert.ok(tb[i] > tb[i - 1], `${g.id} increasing at ${i}`);
  }
});

test('creatures level up, learn moves and evolve', () => {
  const c = E.createCreature(idx, 'sproutle', { level: 5, seed: 1 });
  assert.equal(c.level, 5);
  assert.ok(c.moves.length >= 2 && c.moves.length <= 4);
  const stats = E.calcStats(idx, c);
  assert.ok(stats.hp > 10 && stats.atk > 5);
  const events = E.gainExp(idx, c, 20000);
  assert.ok(c.level > 20, `level ${c.level}`);
  assert.ok(events.some((e) => e.type === 'level'));
  assert.ok(events.some((e) => e.type === 'canEvolve' && e.to === 'thornback'));
  const res = E.evolve(idx, c, 'thornback');
  assert.equal(c.speciesId, 'thornback');
  assert.equal(res.from, 'sproutle');
});

test('walking builds friendship deterministically', () => {
  const a = E.createCreature(idx, 'zapkit', { level: 10, seed: 2, friendship: 70 });
  const b = JSON.parse(JSON.stringify(a));
  const ra = E.applyWalk(idx, a, 5000, { seed: 'walk-1', at: 1_700_000_000_000 });
  const rb = E.applyWalk(idx, b, 5000, { seed: 'walk-1', at: 1_700_000_000_000 });
  assert.deepEqual(ra, rb);
  assert.ok(a.friendship > 70);
  assert.equal(a.walk.totalSteps, 5000);
  // friendship evolution
  a.friendship = 210;
  assert.equal(E.checkEvolution(idx, a)?.to, 'stormlynx');
});

test('care actions respect the daily friendship cap', () => {
  const c = E.createCreature(idx, 'mossling', { level: 5, seed: 3, friendship: 100 });
  for (let i = 0; i < 100; i++) E.applyCare(idx, c, 'pet');
  assert.ok(c.friendship <= 100 + idx.ds.rules.careFriendshipPerDay);
  c.needs.fullness = 20;
  const inv = { sweetroot: 1 };
  const r = E.applyCare(idx, c, 'feed', { item: 'sweetroot', inventory: inv });
  assert.equal(r.ok, true);
  assert.equal(inv.sweetroot, 0);
  assert.equal(E.applyCare(idx, c, 'feed', { item: 'sweetroot', inventory: inv }).ok, false);
});

test('Showdown team export and packed format', () => {
  const ds = E.createDefaultDataset();
  ds.species.find((s) => s.id === 'sproutle').abilities = ['Overgrowth', 'Sun Soak'];
  const idx2 = E.indexDataset(ds);
  const a = E.createCreature(idx2, 'sproutle', { level: 12, seed: 7, nickname: 'Leafy', friendship: 120 });
  a.effort = { hp: 0, atk: 4, def: 0, spa: 252, spd: 0, spe: 252 };
  a.genes = { hp: 31, atk: 0, def: 31, spa: 31, spd: 31, spe: 31 };
  a.temper = 'wise';
  const b = E.createCreature(idx2, 'cindrop', { level: 100, seed: 8 });
  b.genes = { hp: 31, atk: 31, def: 31, spa: 31, spd: 31, spe: 31 };
  b.friendship = 255;
  const c = E.createCreature(idx2, 'cindrop', { level: 9, seed: 9 });
  const team = E.buildTeam(idx2, [a, b, c]);
  assert.deepEqual(Object.keys(team.map), ['Leafy', 'Cindrop', 'Cindrop 2']);
  assert.equal(team.map.Leafy, a.uid);
  const lines = team.text.split('\n\n')[0].split('\n');
  assert.equal(lines[0], 'Leafy (Sproutle)');
  assert.equal(lines[1], 'Ability: Overgrowth');
  assert.equal(lines[2], 'Level: 12');
  assert.equal(lines[3], 'Happiness: 120');
  assert.equal(lines[4], 'EVs: 4 Atk / 252 SpA / 252 Spe');
  assert.equal(lines[5], 'Wise Nature');
  assert.equal(lines[6], 'IVs: 0 Atk');
  assert.ok(lines.slice(7).every((l) => l.startsWith('- ')));
  const packed = team.packed.split(']');
  assert.equal(packed.length, 3);
  const f = packed[0].split('|');
  assert.equal(f[0], 'Leafy');
  assert.equal(f[1], 'Sproutle');
  assert.equal(f[3], 'overgrowth');
  assert.equal(f[5], 'Wise');
  assert.equal(f[6], ',4,,252,,252');
  assert.equal(f[8], ',0,,,,');
  assert.equal(f[10], '12');
  assert.equal(f[11], '120');
  const g = packed[1].split('|');
  assert.equal(g[1], '', 'species blank when it matches the nickname');
  assert.equal(g[8], '', 'all-31 IVs omitted');
  assert.equal(g[10], '', 'level 100 blank');
  assert.equal(g[11], '', 'happiness 255 blank');
  assert.ok(!team.packed.includes('\n'));
});

test('Showdown battle log gives in-house rewards', () => {
  const save = E.createSave('Ash');
  const leafy = E.addCreature(save, E.createCreature(idx, 'sproutle', { level: 12, seed: 1, nickname: 'Leafy' }), { kind: 'party', slot: 0 });
  const cin = E.addCreature(save, E.createCreature(idx, 'cindrop', { level: 10, seed: 2 }), { kind: 'party', slot: 1 });
  const team = E.buildTeam(idx, [leafy, cin]);
  const log = [
    '|j|\u2606Ash', '|j|\u2606Gary', '|player|p1|Ash|1|', '|player|p2|Gary|2|', '|teamsize|p1|2', '|teamsize|p2|2',
    '|gametype|singles', '|gen|9', '|tier|[Gen 9] Custom Game', '|clearpoke', '|poke|p1|Sproutle, L12|', '|poke|p1|Cindrop, L10, M|',
    '|poke|p2|Zapkit, L11, F|', '|poke|p2|Mindle, L9|', '|teampreview', '|', '|start',
    '|switch|p1a: Leafy|Sproutle, L12|100/100', '|switch|p2a: Zapkit|Zapkit, L11, F|100/100', '|turn|1',
    '|move|p1a: Leafy|Vine Lash|p2a: Zapkit', '|-damage|p2a: Zapkit|40/100',
    '|switch|p1a: Cindrop|Cindrop, L10, M|100/100', '|turn|2',
    '|move|p1a: Cindrop|Cinder|p2a: Zapkit', '|-damage|p2a: Zapkit|0 fnt', '|faint|p2a: Zapkit', '|',
    '|switch|p2a: Mindle|Mindle, L9|100/100', '|turn|3',
    '|move|p2a: Mindle|Mind Poke|p1a: Cindrop', '|-damage|p1a: Cindrop|0 fnt', '|faint|p1a: Cindrop',
    '|switch|p1a: Leafy|Sproutle, L12|60/100', '|turn|4',
    '|move|p1a: Leafy|Vine Lash|p2a: Mindle', '|-damage|p2a: Mindle|0 fnt', '|faint|p2a: Mindle', '|', '|win|Ash',
  ].join('\n');
  const parsed = E.parseBattleLog(log, { id: 'battle-gen9customgame-42' });
  assert.equal(parsed.ok, true);
  assert.equal(parsed.winner, 'Ash');
  assert.equal(parsed.kos.length, 3);
  const mine = E.findMySide(parsed, [team], '');
  assert.equal(mine.side, 'p1');
  const r = E.battleRewards(idx, parsed, mine, save);
  assert.equal(r.won, true);
  assert.equal(r.opponent, 'Gary');
  assert.equal(r.eventId, 'showdown-battlegen9customgame42');
  const byUid = Object.fromEntries(r.results.map((x) => [x.uid, x]));
  // Zapkit (base exp 60, L11) was faced by both: floor(60*11/7*1.5/2) = 70 each
  // Mindle (base exp 120, L9) KO'd Cindrop, so only Leafy shares it: floor(120*9/7*1.5/1) = 231
  assert.equal(byUid[cin.uid].exp, 70);
  assert.equal(byUid[leafy.uid].exp, 70 + 231);
  assert.equal(byUid[leafy.uid].effort.spe, 1);
  assert.equal(byUid[leafy.uid].effort.spa, 1);
  assert.equal(byUid[cin.uid].fainted, true);
  assert.equal(byUid[cin.uid].friendship, 2);
  assert.equal(byUid[leafy.uid].friendship, 3);
  // applying it twice does nothing the second time
  const ev = E.makeEvent('battle', { results: r.results, won: r.won, opponent: r.opponent, linked: true });
  ev.id = r.eventId;
  const before = leafy.exp;
  E.applyEvent(idx, save, ev);
  assert.equal(leafy.exp, before + 301);
  const exp = leafy.exp;
  assert.equal(E.applyEvent(idx, save, ev).duplicate, true);
  assert.equal(leafy.exp, exp);
  // the other player sees the same battle as a loss
  const theirs = E.findMySide(parsed, [], 'Gary');
  assert.equal(theirs.side, 'p2');
  assert.equal(E.battleRewards(idx, parsed, theirs, save).won, false);
});

test('logs come out of replays and downloaded pages', () => {
  const log = '|player|p1|A|\n|win|A';
  assert.equal(E.extractLog(JSON.stringify({ id: 'x', log })), log);
  assert.equal(E.extractLog(`<html><script type="text/plain" class="battle-log-data">${log}</script></html>`), log);
  assert.equal(E.parseBattleLog('|player|p1|A|').ok, false);
  const u = E.replayUrls('https://replay.pokemonshowdown.com/gen9customgame-2245013645?p2');
  assert.equal(u.json, 'https://replay.pokemonshowdown.com/gen9customgame-2245013645.json');
  assert.equal(u.id, 'battle-gen9customgame-2245013645');
});

test('bridge script captures a battle and sends the team', () => {
  const posts = [];
  const sent = [];
  class FakeSocket {
    constructor(url) { this.url = url; this.readyState = 1; this.l = {}; FakeSocket.last = this; }
    addEventListener(t, f) { (this.l[t] ||= []).push(f); }
    send(x) { sent.push(x); }
    emit(t, e) { for (const f of this.l[t] || []) f(e); }
  }
  const win = { WebSocket: FakeSocket, CapsuleBridge: { post: (s) => posts.push(JSON.parse(s)) } };
  const run = new Function('window', 'document', E.bridgeScript({ action: 'accept', opponent: 'Gary', format: 'gen9customgame', packed: 'Leafy|Sproutle|||vinelash||||||12|' }));
  run(win, { readyState: 'complete', body: null, addEventListener() {}, getElementById() { return null; } });
  const ws = new win.WebSocket('wss://sim3.psim.us/showdown/123/abcdefgh/websocket');
  ws.emit('message', { data: 'o' });
  ws.emit('message', { data: 'a' + JSON.stringify(['|updateuser| Ash|1|1|{}']) });
  assert.equal(sent.length, 0, 'waits for the challenge');
  ws.emit('message', { data: 'a' + JSON.stringify(['|updatechallenges|{"challengesFrom":{"gary":"gen9customgame"},"challengeTo":null}']) });
  assert.deepEqual(sent.map((x) => JSON.parse(x)[0]), ['|/utm Leafy|Sproutle|||vinelash||||||12|', '|/accept Gary']);
  ws.emit('message', { data: 'a' + JSON.stringify(['>battle-gen9customgame-7\n|init|battle\n|player|p1|Gary|1|\n|player|p2|Ash|2|\n|request|{"x":1}\n|switch|p2a: Leafy|Sproutle, L12|33/33']) });
  ws.emit('message', { data: 'a' + JSON.stringify(['>battle-gen9customgame-7\n|faint|p1a: Zap\n|win|Ash']) });
  const b = posts.find((p) => p.type === 'battle');
  assert.equal(b.room, 'battle-gen9customgame-7');
  assert.equal(b.user, 'Ash');
  assert.ok(!b.log.includes('|request|'));
  assert.ok(b.log.endsWith('|win|Ash'));
  assert.ok(posts.some((p) => p.type === 'user' && p.name === 'Ash' && p.named));
});

test('capsule records round-trip and survive a half-finished sync', () => {
  const c = E.createCreature(idx, 'frostuft', { level: 12, seed: 9, nickname: 'Puffé' });
  c.walk.totalSteps = 1234;
  const main = E.encodeMain(idx, c, { mode: 'walk', syncId: 77, walkCounted: 0 });
  assert.equal(main.length, 128);
  const d = E.decodeMain(main);
  assert.equal(d.ok, true);
  assert.equal(d.rec.nickname, 'Puffé');
  assert.equal(d.rec.level, 12);
  assert.equal(d.rec.mode, 'walk');
  assert.equal(d.rec.totalSteps, 1234);
  assert.equal(d.rec.uid, c.uid);
  const back = E.recordToCreature(idx, d.rec);
  assert.equal(back.speciesId, 'frostuft');
  assert.deepEqual(back.moves.map((m) => m.id), c.moves.map((m) => m.id));

  const walk = E.encodeWalk({ syncId: 77, steps: 900, bumpCount: 2 });
  const img = E.buildTagImage(main, walk);
  assert.ok(img.length <= 496, 'fits NTAG215');
  const parsed = E.parseTagImage(img);
  assert.equal(parsed.ok, true);
  assert.equal(parsed.standardLayout, true);
  assert.equal(parsed.mainOffset, E.CAPSULE.USER_MAIN_OFFSET);
  assert.equal(parsed.walkOffset, E.CAPSULE.USER_WALK_OFFSET);
  assert.equal(E.pendingSteps(parsed.main.rec, parsed.walk.walk), 900);
  // main rewritten (sync 78, counted 900) but walk reset failed
  const main2 = E.encodeMain(idx, c, { syncId: 78, walkCounted: 900 });
  assert.equal(E.pendingSteps(E.decodeMain(main2).rec, { syncId: 77, steps: 1000 }), 100);
  // damaged data is detected
  const bad = main.slice(); bad[40] ^= 0xff;
  assert.equal(E.decodeMain(bad).ok, false);
  // NDEF has the Android app record
  const recs = E.decodeNdefMessage(E.findNdefTlv(img).message);
  assert.equal(recs[1].type, 'android.com:pkg');
});

test('importer reads tables, JSON and object literals', () => {
  const ds = E.createDefaultDataset();
  const table = 'No\tName\tType\tHP\tAtk\tDef\tSpA\tSpD\tSpe\n101\tTestmon\tFire/Flying\t60\t70\t50\t90\t55\t100\n102\tOtherling\tStone\t90\t95\t110\t40\t60\t30';
  const p = E.parsePaste(table);
  assert.equal(p.format, 'table');
  const map = E.guessMapping(p.columns, 'species');
  assert.equal(map.name, 'Name');
  assert.equal(map.spe, 'Spe');
  assert.equal(map.spd, 'SpD');
  const rep = E.applyImport(ds, 'species', p.rows, map, { mode: 'merge' });
  assert.equal(rep.added, 2);
  const t = ds.species.find((s) => s.id === 'testmon');
  assert.deepEqual(t.types, ['fire', 'flying']);
  assert.equal(t.baseStats.spe, 100);
  assert.equal(t.no, 101);

  const literal = `export const Things: {[k: string]: any} = {
    zapzap: { num: 7, name: "Zap Zap", types: ["Volt"], baseStats: {hp: 40, atk: 50, def: 40, spa: 60, spd: 45, spe: 90}, },
    // comment
    rockbro: { num: 8, name: 'Rock Bro', types: ['Stone', 'Brawl'], baseStats: {hp: 80, atk: 100, def: 90, spa: 30, spd: 50, spe: 40} },
  };`;
  const p2 = E.parsePaste(literal);
  assert.equal(p2.format, 'json');
  const m2 = E.guessMapping(p2.columns, 'species');
  E.applyImport(ds, 'species', p2.rows, m2, {});
  const rb = ds.species.find((s) => s.id === 'rock-bro');
  assert.deepEqual(rb.types, ['stone', 'brawl']);
  assert.equal(rb.baseStats.atk, 100);

  const moves = 'Name | Type | Cat. | Power | Acc. | PP\n---|---|---|---|---|---\nMega Zap | Volt | Special | 120 | 70% | 5\nPat | Plain | Status | — | — | 40';
  const p3 = E.parsePaste(moves);
  const m3 = E.guessMapping(p3.columns, 'moves');
  E.applyImport(ds, 'moves', p3.rows, m3, {});
  const mz = ds.moves.find((m) => m.id === 'mega-zap');
  assert.equal(mz.power, 120);
  assert.equal(mz.accuracy, 70);
  assert.equal(mz.category, 'special');
  assert.equal(ds.moves.find((m) => m.id === 'pat').accuracy, null);

  const learn = E.parsePaste('Lv. 1 Nudge\n5 - Mega Zap\nPat 12\nEvo Cheer');
  E.applyImport(ds, 'learnset', learn.rows, {}, { speciesId: 'testmon' });
  assert.deepEqual(ds.species.find((s) => s.id === 'testmon').learnset.map((l) => [l.level, l.move]),
    [[0, 'cheer'], [1, 'nudge'], [5, 'mega-zap'], [12, 'pat']]);

  const chart = 'Atk\\Def\tPlain\tEmber\nPlain\t1\t1\nEmber\t2\t½';
  const p4 = E.parsePaste(chart);
  E.applyImport(ds, 'typeChart', p4.rows, {}, {});
  assert.equal(ds.typeChart.ember.plain, 2);
  assert.equal(ds.typeChart.ember.ember, 0.5);

  assert.deepEqual(E.validateDataset(ds).filter((x) => !x.includes('placeholder')), []);
});

test('save events are idempotent', () => {
  const save = E.createSave('Ash');
  const c = E.addCreature(save, E.createCreature(idx, 'zapkit', { level: 5, seed: 4 }));
  const ev = E.makeEvent('walk', { uid: c.uid, steps: 3000 });
  E.applyEvent(idx, save, ev);
  const f1 = c.friendship;
  const r2 = E.applyEvent(idx, save, ev);
  assert.equal(r2.duplicate, true);
  assert.equal(c.friendship, f1);
  assert.equal(save.stats.totalSteps, 3000);
});

test('cries parse', () => {
  const n = E.parseCry('E5:2 G#5:1 r:1 Bb4:3');
  assert.deepEqual(n.map((x) => x.midi), [76, 80, 0, 70]);
  assert.equal(E.formatCry(n), 'E5:2 G#5:1 r:1 A#4:3');
  assert.ok(E.defaultCry('anything').length >= 3);
});

test('capsule sync through a virtual tag', async () => {
  const save = E.createSave('Dock');
  const c = E.addCreature(save, E.createCreature(idx, 'zapkit', { level: 8, seed: 11 }), { kind: 'party', slot: 0 });
  const tag = E.makeVirtualTag('04AABBCCDDEE01');
  // factory fresh NTAG: empty NDEF TLV
  tag.mem.set([0x03, 0x00, 0xfe], 0);
  let info = await E.readCapsule(idx, tag);
  assert.equal(info.state, 'blank');
  await E.sendToCapsule(idx, save, tag, info, c.uid, { mode: 'walk' });
  assert.equal(c.location.kind, 'capsule');
  info = await E.readCapsule(idx, tag);
  assert.equal(info.state, 'creature');
  assert.equal(info.rec.mode, 'walk');
  assert.equal(info.pending, 0);
  tag.addSteps(3000);
  tag.addSteps(1200, { bump: true, peer: 0x1234 });
  info = await E.readCapsule(idx, tag);
  assert.equal(info.pending, 4200);
  const f0 = c.friendship;
  const res = await E.syncCapsule(idx, save, tag, info);
  assert.equal(res.walk.steps, 4200);
  assert.ok(c.friendship > f0);
  assert.equal(save.capsules[tag.uid].bumps, 1);
  info = await E.readCapsule(idx, tag);
  assert.equal(info.pending, 0, 'walk reset after sync');
  assert.equal(info.rec.totalSteps, 4200);
  assert.equal(info.rec.friendship, c.friendship);
  // half-finished sync: main written but walk not reset
  tag.addSteps(500);
  info = await E.readCapsule(idx, tag);
  const main = E.encodeMain(idx, c, { mode: 'walk', syncId: 999, walkCounted: info.walk.steps });
  await tag.writePages(E.CAPSULE.MAIN_FIRST_PAGE, main);
  tag.addSteps(40);
  info = await E.readCapsule(idx, tag);
  assert.equal(info.pending, 40);
  // phone on another save adopts the creature from the capsule
  const save2 = E.createSave('Phone');
  const r2 = E.absorbCapsule(idx, save2, info);
  assert.equal(r2.isNew, true);
  assert.equal(save2.creatures[c.uid].speciesId, 'zapkit');
  // release empties it
  await E.releaseFromCapsule(idx, save, tag, info, { kind: 'ranch' });
  assert.equal(c.location.kind, 'ranch');
  info = await E.readCapsule(idx, tag);
  assert.equal(info.state, 'empty');
});

test('importer picks up abilities from Showdown-style data', () => {
  const ds = E.createDefaultDataset();
  const src = `export const Pokedex = {
    testmon: { num: 900, name: "Testmon", types: ["Ember"], baseStats: {hp: 50, atk: 60, def: 50, spa: 70, spd: 50, spe: 80}, abilities: {0: "Blaze Up", H: "Hot Head"} },
  };`;
  const p = E.parsePaste(src);
  const map = E.guessMapping(p.columns, 'species');
  E.applyImport(ds, 'species', p.rows, map, {});
  const t = ds.species.find((s) => s.id === 'testmon');
  assert.deepEqual(t.abilities, ['Blaze Up', 'Hot Head']);
  const idx2 = E.indexDataset(ds);
  assert.equal(E.createCreature(idx2, 'testmon', { level: 5, seed: 1 }).ability, 'Blaze Up');
  const table = E.parsePaste('Name\tAbilities\nTestmon\tA / B\nFoo\tC');
  const r = E.applyImport(ds, 'species', table.rows, E.guessMapping(table.columns, 'species'), {});
  assert.deepEqual(ds.species.find((s) => s.id === 'testmon').abilities, ['A', 'B']);
  // a table with no types or stats updates species but never invents new ones
  assert.equal(ds.species.find((s) => s.id === 'foo'), undefined);
  assert.equal(r.skipped, 1);
});

test('Showdown data files paste straight in', () => {
  const ds = E.createDefaultDataset();
  ds.species = []; ds.moves = []; ds.types = [];
  const dex = `export const Pokedex: import('../sim/dex-species').SpeciesDataTable = {
    budling: { num: 1, name: "Budling", types: ["Grass"], baseStats: {hp: 45, atk: 49, def: 49, spa: 65, spd: 65, spe: 45}, abilities: {0: "Overgrowth", H: "Sun Soak"}, heightm: 0.7, weightkg: 6.9, evos: ["Bloomer"] },
    bloomer: { num: 2, name: "Bloomer", types: ["Grass", "Fairy"], baseStats: {hp: 60, atk: 62, def: 63, spa: 80, spd: 80, spe: 60}, abilities: {0: "Overgrowth"}, prevo: "Budling", evoLevel: 16 },
    bloomermega: { num: 2, name: "Bloomer-Mega", baseSpecies: "Bloomer", forme: "Mega", types: ["Grass"], baseStats: {hp: 60, atk: 90, def: 90, spa: 110, spd: 100, spe: 60}, abilities: {0: "Thick Fat"} },
    pal: { num: 3, name: "Pal", types: ["Normal"], baseStats: {hp: 50, atk: 50, def: 50, spa: 50, spd: 50, spe: 50}, abilities: {0: "Run Away"}, prevo: "Budling", evoType: "levelFriendship" },
    fanmade: { num: -5, name: "Fanmade", types: ["Normal"], baseStats: {hp: 1, atk: 1, def: 1, spa: 1, spd: 1, spe: 1}, abilities: {0: "None"}, isNonstandard: "CAP" },
  };`;
  const p1 = E.parsePaste(dex);
  const m1 = E.guessMapping(p1.columns, 'species');
  const r1 = E.applyImport(ds, 'species', p1.rows, m1, { mainOnly: true });
  assert.equal(r1.added, 3);
  assert.deepEqual(ds.species.map((s) => s.name), ['Budling', 'Bloomer', 'Pal']);
  const bud = ds.species.find((s) => s.id === 'budling');
  assert.deepEqual(bud.evolutions, [{ to: 'bloomer', method: 'level', value: 16 }, { to: 'pal', method: 'friendship', value: 220 }]);
  assert.deepEqual(ds.species.find((s) => s.id === 'bloomer').types, ['grass', 'fairy']);
  // keeping forms gives them their own numbers
  const ds2 = E.createDefaultDataset(); ds2.species = [];
  E.applyImport(ds2, 'species', p1.rows, m1, { mainOnly: false });
  const mega = ds2.species.find((s) => s.name === 'Bloomer-Mega');
  assert.ok(mega.no >= 10001);
  assert.equal(ds2.species.find((s) => s.name === 'Bloomer').no, 2);

  const moves = `export const Moves: import('../sim/dex-moves').MoveDataTable = {
    vinelash: { num: 22, accuracy: 100, basePower: 45, category: "Physical", name: "Vine Lash", pp: 25, priority: 0, flags: {contact: 1, protect: 1}, secondary: null, target: "normal", type: "Grass" },
    growl: { num: 45, accuracy: 100, basePower: 0, category: "Status", name: "Growl", pp: 40, priority: 0, flags: {sound: 1},
      onTryHit(target, source) { if (target.boosts.atk <= -6) return false; },
      boosts: { atk: -1 }, secondary: null, target: "allAdjacentFoes", type: "Normal" },
    swift: { num: 129, accuracy: true, basePower: 60, category: "Special", name: "Swift", pp: 20, priority: 0, flags: {}, target: "allAdjacentFoes", type: "Normal" },
  };`;
  const p2 = E.parsePaste(moves);
  E.applyImport(ds, 'moves', p2.rows, E.guessMapping(p2.columns, 'moves'), {});
  assert.equal(ds.moves.length, 3);
  assert.equal(ds.moves.find((m) => m.id === 'swift').accuracy, null);
  assert.equal(ds.moves.find((m) => m.id === 'vine-lash').power, 45);
  assert.deepEqual(ds.moves.map((m) => m.category), ['physical', 'status', 'special']);

  const learn = `export const Learnsets = {
    budling: { learnset: { vinelash: ["9L3", "8L3", "7L7"], growl: ["9L1", "8L1"], swift: ["8M", "7L20"] }, eventData: [{ generation: 3, level: 10 }] },
    bloomer: { learnset: { vinelash: ["9L1", "9L0"], growl: ["9L1"] } },
  };`;
  const p3 = E.parsePaste(learn);
  assert.equal(p3.format, 'learnsets');
  E.applyImport(ds, 'learnset', p3.rows, E.guessMapping(p3.columns, 'learnset'), {});
  assert.deepEqual(bud.learnset.map((l) => [l.level, l.move]), [[1, 'growl'], [3, 'vine-lash']], 'newest generation only, ids without dashes match');
  assert.deepEqual(ds.species.find((s) => s.id === 'bloomer').learnset.map((l) => l.level), [0, 1, 1]);

  const natures = `export const Natures = {
    adamant: { name: "Adamant", plus: 'atk', minus: 'spa' },
    bashful: { name: "Bashful" },
    modest: { name: "Modest", plus: 'spa', minus: 'atk' },
  };`;
  const p4 = E.parsePaste(natures);
  assert.equal(p4.target, 'temperaments');
  E.applyImport(ds, 'temperaments', p4.rows, E.guessMapping(p4.columns, 'temperaments'), { mode: 'replace' });
  assert.deepEqual(ds.temperaments, [
    { id: 'adamant', name: 'Adamant', up: 'atk', down: 'spa' },
    { id: 'bashful', name: 'Bashful', up: null, down: null },
    { id: 'modest', name: 'Modest', up: 'spa', down: 'atk' },
  ]);

  // a second table fills in experience, growth and effort by name
  const extra = 'Name\tBase Exp\tGrowth Rate\tEV SpA\nBudling\t64\tMedium Slow\t1\nBloomer\t142\tmedium-slow\t2';
  const p5 = E.parsePaste(extra);
  E.applyImport(ds, 'species', p5.rows, E.guessMapping(p5.columns, 'species'), {});
  assert.equal(bud.baseExp, 64);
  assert.equal(bud.growthRate, 'wavy');
  assert.deepEqual(bud.effortYield, { spa: 1 });
  assert.equal(ds.species.length, 3, 'no duplicates from the second table');
  assert.deepEqual(E.validateDataset(ds), []);
});

test('sprite files are matched to species by id, name or number', async () => {
  const { spriteIndex, matchSpriteFile } = await import('../desktop/src/renderer/spriteImport.js');
  const species = [
    { id: 'budling', name: 'Budling', no: 1 },
    { id: 'mr-bristle', name: 'Mr. Bristle', no: 122 },
    { id: 'emberkit-blaze', name: 'Emberkit-Blaze', no: 10001 },
  ];
  const index = spriteIndex(species);
  const m = (f, o) => { const r = matchSpriteFile(f, index, o); return [r.species?.id ?? null, r.pose]; };
  assert.deepEqual(m('budling.png'), ['budling', '']);
  assert.deepEqual(m('Budling.PNG'), ['budling', '']);
  assert.deepEqual(m('0001.png'), ['budling', '']);
  assert.deepEqual(m('1.png'), ['budling', '']);
  assert.deepEqual(m('mrbristle.png'), ['mr-bristle', '']);
  assert.deepEqual(m('Mr. Bristle-walk.png'), ['mr-bristle', 'walk']);
  assert.deepEqual(m('emberkitblaze.png'), ['emberkit-blaze', '']);
  assert.deepEqual(m('budling.png', { pose: 'back' }), ['budling', 'back']);
  assert.deepEqual(m('nobody.png'), [null, '']);
});

test('an emptied data set still works', () => {
  const ds = E.createDefaultDataset();
  ds.species = []; ds.moves = []; ds.types = []; ds.temperaments = [];
  const i = E.indexDataset(ds);
  assert.deepEqual(E.validateDataset(i.ds), []);
});

test('data files with comments and imports at the top are still read as data', () => {
  const p = E.parsePaste('// Generated\n/* licence */\nimport {X} from "y";\n\nexport const Natures: import("../sim/dex-data").NatureDataTable = {\n  gruff: { name: "Gruff", plus: "atk", minus: "def" },\n};\n');
  assert.equal(p.target, 'temperaments');
  assert.equal(p.rows.length, 1);
});
