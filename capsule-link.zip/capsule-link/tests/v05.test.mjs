// 0.5.0: care limits, movement, walk finds and the market, building yards, personalities, activities,
// real sun times and getting about.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const base = () => {
  const idx = E.indexDataset(E.createDefaultDataset());
  const save = E.createSave('Kim', 2);
  E.tickAll(idx, save);
  return { idx, save };
};
const add = (idx, save, sp, loc = { kind: 'box', box: 0, slot: 0 }) => { const c = E.createCreature(idx, sp, { location: loc }); save.creatures[c.uid] = c; return c; };

test('care: overdoing it makes them upset; naps have a cooldown; tired ones are only bothered when you pick on them', () => {
  const { idx, save } = base();
  const c = add(idx, save, 'sproutle');
  const t0 = Date.now();
  let last;
  for (let i = 0; i < 12; i++) last = E.applyCare(idx, c, 'pet', { at: t0 + i * 1000 });
  assert.equal(last.reaction, 'annoyed');
  assert.equal(E.mood(c, t0 + 15000).id, 'upset');
  assert.equal(E.mood(c, t0 + 20 * 60000).id !== 'upset', true, 'they get over it');
  // naps
  c.needs.energy = 30;
  const n1 = E.applyCare(idx, c, 'rest', { at: t0 });
  assert.equal(n1.reaction, 'sleep');
  const n2 = E.applyCare(idx, c, 'rest', { at: t0 + 60000 });
  assert.equal(n2.reaction, 'awake');
  assert.ok(E.napWait(c, t0 + 60000) > 0);
  // tired: a toy in the yard (not direct) costs nothing; clicking them to play does
  const d = add(idx, save, 'zapkit', { kind: 'box', box: 0, slot: 1 });
  d.needs.energy = 12; d.needsAt = t0;
  const joy0 = d.needs.joy;
  assert.equal(E.applyCare(idx, d, 'play', { direct: false, at: t0 }).reaction, 'tired');
  assert.equal(d.needs.joy, joy0);
  E.applyCare(idx, d, 'play', { at: t0 });
  assert.ok(d.needs.joy < joy0);
});

test('fire types never get a bath, and stay out of the water', () => {
  const { idx, save } = base();
  const f = add(idx, save, 'cindrop');
  assert.equal(E.avoidsWater(idx, f), true);
  assert.equal(E.applyCare(idx, f, 'wash').ok, false);
  assert.equal(E.applyCare(idx, f, 'brush').ok, true);
  assert.equal(E.movementOf(idx, idx.species.get('cindrop')).water, false);
});

test('movement: per species, with sensible defaults', () => {
  const { idx } = base();
  assert.equal(E.movementOf(idx, idx.species.get('pyrewing')).float, true, 'flyers fly by default');
  assert.equal(E.movementOf(idx, idx.species.get('puddlop')).swim, true);
  const sp = { ...idx.species.get('sproutle'), movement: { fly: true, default: 'fly' } };
  assert.equal(E.movementOf(idx, sp).float, true);
  const sw = { ...idx.species.get('puddlop'), movement: { walk: false, default: 'swim' } };
  const m = E.movementOf(idx, sw);
  assert.equal(m.walk, false); assert.equal(m.def, 'swim');
});

test('walks turn up coins, berries and valuables; the market buys them back', () => {
  const { idx, save } = base();
  const c = add(idx, save, 'sproutle', { kind: 'party', slot: 0 });
  c.friendship = 255;
  let coins = 0, finds = [];
  for (let i = 0; i < 30; i++) { const r = E.applyEvent(idx, save, E.makeEvent('walk', { uid: c.uid, steps: 1500 })); coins += r.outcome.coins; finds.push(...r.outcome.finds); c.walk.todaySteps = 0; }
  assert.ok(coins > 0, 'found some coins');
  assert.ok(finds.some((id) => E.itemInfo(idx, id)?.kind === 'valuable'), 'found something shiny');
  const v = finds.find((id) => E.itemInfo(idx, id)?.kind === 'valuable');
  const before = save.wallet;
  assert.equal(E.sell(idx, save, v, 1).ok, true);
  assert.equal(save.wallet - before, E.itemInfo(idx, v).value);
  // one item, several uses: a berry can be eaten, planted and held; incense held or lit
  const berry = idx.items.get('bramble-berry');
  assert.deepEqual(E.itemUses(berry).filter((u) => u !== 'sell'), ['feed', 'plant', 'hold']);
  assert.match(E.itemDesc(berry), /Or when being held/);
  const inc = E.incenseItems(idx)[0];
  assert.ok(E.itemUses(inc).includes('hold') && E.itemUses(inc).includes('light'));
  assert.match(E.itemDesc(inc), /Or when paired with a capsule/);
});

test('building yards: blueprints, placing, expanding, feelings and the yard report', () => {
  const { idx, save } = base();
  save.wallet = 20000;
  const fish = add(idx, save, 'puddlop', { kind: 'box', box: 0, slot: 0 });
  const fire = add(idx, save, 'cindrop', { kind: 'box', box: 0, slot: 1 });
  assert.equal(E.buyBlueprint(save, 'pond').ok, true);
  assert.equal(E.placeFeature(save, 0, 'pond', 1, 4).ok, true);
  assert.equal(save.inventory['bp-pond'], 0);
  assert.ok(E.appeal(idx, fish, 'pond') > 0.3, 'water creatures love a pond');
  assert.ok(E.appeal(idx, fire, 'pond') < -0.3, 'fire creatures don’t');
  assert.ok(E.featureLife(idx, 'pond', [fish, fire]) > 0, 'the pond comes alive with water creatures');
  const rep = E.thriveReport(idx, save, 0, [fish, fire]);
  assert.equal(rep.rows[0].uid, fish.uid);
  // expansions
  assert.equal(E.expandYard(save, 0).ok, false);
  E.buyBlueprint(save, 'expand');
  assert.equal(E.expandYard(save, 0).size, 1);
  // take it down: back in the bag
  const fid = E.yardBuild(save, 0).features[0].id;
  E.removeFeature(save, 0, fid);
  assert.equal(save.inventory['bp-pond'], 1);
  // the Link gate: one only
  assert.equal(E.buyBlueprint(save, 'link-gate').ok, true);
  assert.equal(E.buyBlueprint(save, 'link-gate').ok, false);
  const snap = E.ranchSnapshot(idx, save, 0, [fish, fire]);
  const back = E.readSnapshot(idx, JSON.stringify(snap));
  assert.equal(back.ok, true); assert.equal(back.snap.creatures.length, 2); assert.deepEqual(back.missing, []);
});

test('personality: temperament style, habits and the journal', () => {
  const { idx, save } = base();
  const c = add(idx, save, 'gloomoth');
  const tr = E.traitsOf(idx, c);
  assert.equal(tr.night, true, 'shade types are night owls');
  assert.ok(['playful', 'lazy', 'shy', 'bold', 'calm'].includes(tr.temper));
  c.prefs = { 'food:bramble-berry': 6, 'place:park': 4, 'weather:rain': -5 };
  const j = E.journalOf(idx, save, c);
  assert.ok(j.likes.Foods?.length);
  assert.ok(j.dislikes.length);
  assert.ok(j.favourites.length >= 5);
});

test('playing together builds friendships', () => {
  const { idx, save } = base();
  const a = add(idx, save, 'sproutle'), b = add(idx, save, 'mossling', { kind: 'box', box: 0, slot: 1 });
  let r;
  for (let i = 0; i < 400 && !r?.friends; i++) r = E.playedTogether(idx, save, a.uid, b.uid);
  assert.equal(r.friends, true);
  assert.ok(a.memories.some((m) => /game in the yard/.test(m.text)));
});

test('activities: aptitude follows types; results land in the save', () => {
  const { idx, save } = base();
  const fish = add(idx, save, 'puddlop'), rock = add(idx, save, 'cogsy', { kind: 'box', box: 0, slot: 1 });
  assert.ok(E.aptitude(idx, fish, 'fishing').score > E.aptitude(idx, rock, 'fishing').score);
  assert.ok(E.aptitude(idx, rock, 'scavenging').score > E.aptitude(idx, fish, 'scavenging').score);
  const r = E.finishActivity(idx, save, fish.uid, 'fishing', 1);
  assert.equal(r.ok, true);
  assert.ok(r.items.length >= 2);
  // cooking turns ingredients into a dish you can feed
  save.inventory['bramble-berry'] = 2;
  const cook = add(idx, save, 'cindrop', { kind: 'box', box: 0, slot: 2 });
  const out = E.finishActivity(idx, save, cook.uid, 'cooking', 1, { ingredients: ['bramble-berry', 'sweetroot'] });
  assert.ok(out.items[0]?.startsWith('dish-'));
  const fed = E.applyCare(idx, fish, 'feed', { item: out.items[0], inventory: save.inventory });
  assert.equal(fed.ok, true);
  // worn out: no more today
  cook.needs.energy = 5;
  assert.equal(E.canDo(idx, save, cook, 'obstacle').ok, false);
});

test('time of day follows the real sun; clear nights aren’t sunny; transport from speed', () => {
  const day = new Date(2026, 0, 10, 0, 0, 0).getTime();
  const sun = { sunrise: day + 8 * 3600000, sunset: day + 16.5 * 3600000 };
  assert.equal(E.timeOfDay(day + 17.5 * 3600000, sun), 'night', 'a winter evening at 5:30 is dark');
  assert.equal(E.timeOfDay(day + 12 * 3600000, sun), 'day');
  assert.equal(E.timeOfDay(day + 8.3 * 3600000, sun), 'dawn');
  const { idx, save } = base();
  const c = add(idx, save, 'sproutle');
  for (let i = 0; i < 200; i++) {
    const line = E.thoughtFor(idx, c, { weather: 'sun', sun: { isDay: false }, t: day + 23 * 3600000, seed: i });
    assert.doesNotMatch(line, /sun|bright sky|basking/i, line);
  }
  assert.equal(E.transportOf({ speedKmh: 18 }), 'bike');
  assert.equal(E.transportOf({ speedKmh: 11 }), 'skate');
  assert.equal(E.transportOf({ speedKmh: 70 }), 'car');
  assert.equal(E.transportOf({ speedKmh: 700 }), 'plane');
  assert.equal(E.transportOf({ speedKmh: 25, places: ['harbour'] }), 'boat');
  assert.equal(E.transportOf({ speedKmh: 4 }), null);
  assert.equal(E.homeState({ lat: 51.5, lon: -0.12 }, { lat: 51.5005, lon: -0.1201 }).state, 'home');
  assert.equal(E.homeState({ lat: 51.5, lon: -0.12 }, { lat: 53.48, lon: -2.24 }).state, 'far');
});

test('older PKHeX files (Gen 3, 4/5, 6/7) come in with what they have, and questions for the rest', async () => {
  const P = await import('../shared/engine/pkhex.js');
  const { idx } = base();
  const w16 = (d, o, v) => { d[o] = v & 255; d[o + 1] = (v >> 8) & 255; };
  const w32 = (d, o, v) => { w16(d, o, v & 0xffff); w16(d, o + 2, v >>> 16); };
  // Gen 6/7: plain (decrypted) file
  const d6 = new Uint8Array(232);
  w32(d6, 0, 0x12345678); w16(d6, 0x08, 4); w16(d6, 0x0c, 12345); w32(d6, 0x10, 1000); w32(d6, 0x18, 0xabcdef01); d6[0x1c] = 3;
  'Blaze'.split('').forEach((ch, i) => w16(d6, 0x40 + i * 2, ch.charCodeAt(0)));
  w16(d6, 0x5a, 52); d6[0x62] = 25; w32(d6, 0x74, (31) | (1 << 31) >>> 0);
  'Ash'.split('').forEach((ch, i) => w16(d6, 0xb0 + i * 2, ch.charCodeAt(0)));
  d6[0xca] = 120; d6[0xd4] = 16; d6[0xd5] = 5; d6[0xd6] = 1; d6[0xdd] = 5; d6[0xdf] = 24;
  let sum = 0; for (let i = 8; i < 232; i += 2) sum = (sum + (d6[i] | (d6[i + 1] << 8))) & 0xffff; w16(d6, 6, sum);
  const p6 = P.readPkm(d6, 'blaze.pk6');
  assert.equal(p6.ok, true, p6.error);
  assert.equal(p6.gen, 6); assert.equal(p6.national, 4); assert.equal(p6.nickname, 'Blaze'); assert.equal(p6.otName, 'Ash'); assert.equal(p6.ivs.hp, 31); assert.equal(p6.metDate.y, 2016);
  // the same file encrypted (blocks shuffled, then scrambled) reads the same
  const e6 = new Uint8Array(d6); const sv = (0x12345678 >>> 13) & 31; const tmp = e6.slice(8, 232);
  const POS = [0, 1, 2, 3, 0, 1, 3, 2, 0, 2, 1, 3, 0, 3, 1, 2, 0, 2, 3, 1, 0, 3, 2, 1, 1, 0, 2, 3, 1, 0, 3, 2, 2, 0, 1, 3, 3, 0, 1, 2, 2, 0, 3, 1, 3, 0, 2, 1, 1, 2, 0, 3, 1, 3, 0, 2, 2, 1, 0, 3, 3, 1, 0, 2, 2, 3, 0, 1, 3, 2, 0, 1, 1, 2, 3, 0, 1, 3, 2, 0, 2, 1, 3, 0, 3, 1, 2, 0, 2, 3, 1, 0, 3, 2, 1, 0, 0, 1, 2, 3, 0, 1, 3, 2, 0, 2, 1, 3, 0, 3, 1, 2, 0, 2, 3, 1, 0, 3, 2, 1, 1, 0, 2, 3, 1, 0, 3, 2];
  for (let b = 0; b < 4; b++) { const at = POS.slice(sv * 4, sv * 4 + 4).indexOf(b); e6.set(tmp.subarray(b * 56, b * 56 + 56), 8 + at * 56); }
  let seed = 0x12345678; for (let i = 8; i < 232; i += 2) { seed = (Math.imul(0x41c64e6d, seed) + 0x6073) >>> 0; w16(e6, i, (e6[i] | (e6[i + 1] << 8)) ^ (seed >>> 16)); }
  const pe = P.readPkm(e6, 'blaze.ek6');
  assert.equal(pe.ok, true, pe.error); assert.equal(pe.nickname, 'Blaze');
  // Gen 3: encrypted substructures, its own letters
  const d3 = new Uint8Array(80);
  const pid = 0x0000002a, otid = 0x00010002; w32(d3, 0, pid); w32(d3, 4, otid);
  [0xbb, 0xbc, 0xbc, 0xc9].forEach((b, i) => { d3[8 + i] = b; }); d3[12] = 0xff; // "ABBO"
  [0xc3, 0xbb, 0xc8, 0xc9].forEach((b, i) => { d3[0x14 + i] = b; }); d3[0x18] = 0xff; // "IANO"
  const sub = { G: new Uint8Array(12), A: new Uint8Array(12), E: new Uint8Array(12), M: new Uint8Array(12) };
  w16(sub.G, 0, 25); w32(sub.G, 4, 500); sub.G[9] = 70; w16(sub.A, 0, 84); sub.A[8] = 30; w16(sub.M, 2, 5 | (3 << 7) | (4 << 11)); w32(sub.M, 4, 31 << 5);
  const order = ['GAEM', 'GAME', 'GEAM', 'GEMA', 'GMAE', 'GMEA', 'AGEM', 'AGME', 'AEGM', 'AEMG', 'AMGE', 'AMEG', 'EGAM', 'EGMA', 'EAGM', 'EAMG', 'EMGA', 'EMAG', 'MGAE', 'MGEA', 'MAGE', 'MAEG', 'MEGA', 'MEAG'][pid % 24];
  const plain = new Uint8Array(48); [...order].forEach((k, i) => plain.set(sub[k], i * 12));
  let cs = 0; for (let i = 0; i < 48; i += 2) cs = (cs + (plain[i] | (plain[i + 1] << 8))) & 0xffff; w16(d3, 0x1c, cs);
  const key = (pid ^ otid) >>> 0;
  for (let i = 0; i < 48; i += 4) { const v = ((plain[i] | (plain[i + 1] << 8) | (plain[i + 2] << 16) | (plain[i + 3] << 24)) ^ key) >>> 0; w32(d3, 32 + i, v); }
  const p3 = P.readPkm(d3, 'pika.pk3');
  assert.equal(p3.ok, true, p3.error);
  assert.equal(p3.national, 25); assert.equal(p3.moves[0], 84); assert.equal(p3.ivs.atk, 31); assert.equal(p3.version, 3); assert.equal(p3.ball, 4); assert.equal(p3.otName, 'IANO');
  assert.ok(p3.missing.includes('memories'));
  // in it comes, plus the questionnaire's answers
  const sp = idx.ds.species[0];
  const { creature } = P.pkhexToCreature(idx, p3, { species: sp, trainer: 'Kim' });
  const qs = P.missingQuestions(p3);
  assert.ok(qs.some((q) => q.id === 'memories') && qs.some((q) => q.id === 'when'));
  P.applyAnswers(creature, p3, { when: 'summer 2005', where: 'Route 101', memory: 'beat the Champion on the first try', style: 'bold', love: 'activity:battle' });
  assert.ok(creature.memories.some((m) => /Route 101/.test(m.text)));
  assert.ok(creature.memories.some((m) => /Champion/.test(m.text)));
  assert.equal(E.temperStyle(idx, creature), 'bold');
  assert.equal(new Date(creature.metAt).getFullYear(), 2005);
});
