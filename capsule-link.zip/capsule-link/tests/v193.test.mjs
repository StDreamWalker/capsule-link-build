import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as E from '../shared/engine/index.js';
import { atlasCore } from '../shared/atlas/atlasCore.js';
import * as S from '../shared/atlas/scan.js';

// 1.9.3: the PokéEco Atlas inside the app: its engine, real spots, walks and wild battles drawing from it.
let dexIdx = null;
function pokedex() {
  if (dexIdx) return dexIdx;
  const p = E.parsePaste(readFileSync(new URL('../vendor/showdown/data/pokedex.ts', import.meta.url), 'utf8'));
  const ds = E.createDefaultDataset();
  E.applyImport(ds, 'species', p.rows, E.guessMapping(p.columns, 'species'), { replace: true });
  return (dexIdx = E.indexDataset(ds));
}

// a pretend internet: the atlas's services answering for a coastal city or a hot desert
function fakeNet(kind) {
  const coast = kind === 'coast';
  const days = Array.from({ length: 365 }, (_, i) => new Date(Date.UTC(2025, 0, 1 + i)).toISOString().slice(0, 10));
  return async (url, init = {}) => {
    if (url.includes('/elevation')) return { elevation: coast ? [4, 3, 0, 0, 6, 9, 5, 2, 1] : [610, 640, 590, 700, 620, 600, 655, 615, 630] };
    if (url.includes('archive-api')) {
      return { daily: { time: days, temperature_2m_mean: days.map((d) => (coast ? 16 : 24) + (coast ? 10 : 9) * Math.sin(((+d.slice(5, 7) - 4) / 12) * 2 * Math.PI)),
        precipitation_sum: days.map(() => (coast ? 3.2 : 0.2)), snowfall_sum: days.map(() => 0) } };
    }
    if (url.includes('api.open-meteo.com/v1/forecast')) {
      return { timezone: 'X', current: { time: '2026-11-18T14:00', temperature_2m: coast ? 14 : 31, relative_humidity_2m: 60, weather_code: coast ? 61 : 0, cloud_cover: 80, wind_speed_10m: 12, wind_direction_10m: 90, wind_gusts_10m: 20, is_day: 1, pressure_msl: 1012 },
        hourly: { time: ['2026-11-18T13:00', '2026-11-18T14:00', '2026-11-18T15:00'], precipitation: [1, 1, 0], wind_speed_250hPa: [80, 80, 80] }, daily: { time: ['2026-11-18'], sunrise: ['2026-11-18T06:50'], sunset: ['2026-11-18T16:55'] } };
    }
    if (url.includes('marine-api') || url.includes('air-quality')) throw new Error('no');
    if (url.includes('nominatim')) return coast ? { address: { country_code: 'us', country: 'United States', state: 'Virginia', city: 'Virginia Beach', 'ISO3166-2-lvl4': 'US-VA' } } : { address: { country_code: 'us', country: 'United States', state: 'Arizona', town: 'Gila Bend', 'ISO3166-2-lvl4': 'US-AZ' } };
    if (url.includes('overpass') || url.includes('interpreter')) {
      const body = decodeURIComponent(String(init.body ?? '').replace(/^data=/, ''));
      const n = (body.match(/out count;/g) || []).length;
      const vals = coast ? [6, 4, 9, 5, 3, 2, 1, 0, 0, 0, 0, 0, 5, 30, 12, 4, 1, 1, 2, 0, 6, 0] : [0, 0, 0, 4, 0, 0, 1, 6, 0, 2, 0, 0, 0, 2, 1, 1, 0, 0, 1, 0, 1, 0];
      return { elements: Array.from({ length: n }, (_, i) => ({ type: 'count', tags: { total: String(n === 22 ? vals[i] : i % 3) } })) };
    }
    throw new Error(`unexpected ${url}`);
  };
}

test('the atlas engine runs inside the app as the atlas page does', () => {
  const A = atlasCore();
  assert.equal(A.SPECIES.length, 1026);
  for (const k of ['deriveEnv', 'scoreAll', 'evalLegends', 'excavation']) assert.equal(typeof A[k], 'function', k);
});

test('every atlas Pokémon, regional forms and variants included, finds its species in the Showdown Pokédex', () => {
  const idx = pokedex(), A = atlasCore();
  const miss = A.SPECIES.filter((s) => !S.gameSpeciesFor(idx, [s.dex, s.name]));
  assert.deepEqual(miss.map((s) => s.name), []);
  assert.equal(S.gameSpeciesFor(idx, [37, 'Alolan Vulpix']).id, 'vulpix-alola');
  assert.equal(S.gameSpeciesFor(idx, [128, 'Paldean Tauros (Aqua)']).id, 'tauros-paldea-aqua');
  assert.equal(S.gameSpeciesFor(idx, [741, "Oricorio (Pa'u)"]).id, 'oricorio-pau');
  assert.equal(S.gameSpeciesFor(idx, [422, 'Shellos (West Sea)']).id, 'shellos');
});

test('a scanned coast and a scanned desert are home to different Pokémon', async () => {
  const idx = pokedex();
  const coast = await S.atlasTableAt(36.85, -75.98, { radiusKm: 1, fetchJson: fakeNet('coast') });
  const desert = await S.atlasTableAt(32.95, -112.72, { radiusKm: 1, fetchJson: fakeNet('desert') });
  assert.match(coast.label, /Virginia Beach/);
  assert.equal(coast.src.osm, 'ok');
  const top = (t) => t.rows.slice(0, 15).map((r) => r[4]).join(' ');
  assert.match(top(coast), /water/);
  assert.ok((top(desert).match(/ground|rock|fire/g) ?? []).length > (top(coast).match(/ground|rock|fire/g) ?? []).length);
  assert.equal(coast.weather, 'rain');
  assert.notEqual(S.battlePlaceFor(desert), S.battlePlaceFor(coast));
  const w = S.atlasWeights(idx, coast);
  assert.ok(w && w.size > 40);
});

test('walks and wild battles draw from the atlas for where you are', async () => {
  const idx = pokedex();
  const t = await S.atlasTableAt(36.85, -75.98, { radiusKm: 1, fetchJson: fakeNet('coast') });
  const w = S.atlasWeights(idx, t);
  const met = new Set();
  for (let i = 0; i < 300; i++) { const e = E.rollEncounter(idx, { atlasWeights: w, seed: 1000 + i * 7919, walkMinutes: 30, t: Date.now() }); if (e) met.add(e.speciesId); }
  assert.ok(met.size > 10);
  for (const id of met) assert.ok(w.has(id), `${id} lives here`);
  const save = E.createSave('T', 1);
  for (let i = 0; i < 60; i++) { const r = E.rollWild(idx, save, { seed: 50 + i * 31, weights: w }); assert.ok(r.atlas); assert.ok(w.has(r.speciesId) || idx.species.get(r.speciesId)); }
});

test('a data set without real Pokémon numbers isn’t forced through the atlas', async () => {
  const idx = E.indexDataset(E.createDefaultDataset());
  const t = await S.atlasTableAt(36.85, -75.98, { radiusKm: 1, fetchJson: async () => { throw new Error('offline'); } });
  assert.ok(t.rows.length > 50, 'offline, the atlas still answers from its own estimates');
  assert.equal(S.atlasWeights(idx, t), null);
});
