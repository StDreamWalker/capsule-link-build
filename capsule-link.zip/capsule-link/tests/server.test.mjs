// The home server: accounts, friends, messages, gifts, trades, yards and shared creature data.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { makeServer } from '../server/core.mjs';
import { FriendsClient, fetchMissingSpecies } from '../shared/net/friends.js';

test('home server: two trainers become friends, chat, gift, trade and share a yard', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'clhs-'));
  const s = makeServer({ port: 0, dataDir: dir });
  await s.server.ready;
  const base = `http://127.0.0.1:${s.server.address().port}`;
  try {
    const a = new FriendsClient(base), b = new FriendsClient(base);
    const ra = await a.signup('ash', 'pikapika1', 'Ash');
    assert.match(ra.user.code, /^\d{4} \d{4} \d{4}$/);
    await assert.rejects(() => new FriendsClient(base).signup('ash', 'another12'), /taken/);
    await assert.rejects(() => new FriendsClient(base).signup('x', 'short'), /3–20/);
    await b.signup('misty', 'starmie12', 'Misty');
    await assert.rejects(() => new FriendsClient(base).login('misty', 'wrongpass'), /Wrong/);
    // friend request by trainer code, accepted
    await b.request(ra.user.code);
    assert.equal((await a.friends()).incoming[0].username, 'misty');
    await a.accept('misty');
    assert.equal((await b.friends()).friends[0].username, 'ash');
    // messages
    await a.say('misty', 'Hi Misty!');
    assert.equal((await b.messages('ash')).messages[0].text, 'Hi Misty!');
    // gifts wait in the inbox until claimed
    await a.gift('misty', { items: { 'val-pearl': 2 }, coins: 50, note: 'for you' });
    const inbox = (await b.inbox()).inbox;
    assert.equal(inbox.length, 1);
    const g = (await b.claimGift(inbox[0].id)).gift;
    assert.deepEqual(g.items, { 'val-pearl': 2 }); assert.equal(g.coins, 50);
    await assert.rejects(() => b.claimGift(inbox[0].id), /Already/);
    // a trade: ash offers, misty accepts with her own, both collect
    await a.offerTrade('misty', { creature: { uid: 'c1', speciesId: 'sproutle', level: 5 } }, 'something blue');
    const offer = (await b.inbox()).inbox.find((x) => x.kind === 'trade');
    await b.respondTrade(offer.id, true, { creature: { uid: 'c2', speciesId: 'puddlit', level: 6 } });
    const got = (await b.claimTrade(offer.id)).trade;
    assert.equal(got.give.creature.speciesId, 'sproutle');
    const back = (await a.inbox()).inbox.find((x) => x.creature?.speciesId === 'puddlit');
    assert.ok(back, 'ash gets misty’s creature back as a delivery');
    // yards
    await a.shareRanch({ kind: 'capsule-link-ranch', v: 1, trainer: { name: 'Ash' }, yard: { biome: 'meadow' }, creatures: [{ uid: 'c9', speciesId: 'newmon' }] });
    assert.equal((await b.visitRanch('ash')).trainer.name, 'Ash');
    // strangers can't message
    const c = new FriendsClient(base); await c.signup('brock', 'onixonix1');
    await assert.rejects(() => c.say('ash', 'hey'), /friends/);
    // shared creature data: misty is missing "newmon"; ash shares it with a picture
    const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47]), crypto.randomBytes(40)]);
    const hash = crypto.createHash('sha256').update(png).digest('hex');
    await a.putBlob(hash, png);
    await a.putSpecies('newmon', { id: 'newmon', name: 'Newmon', no: 9001, types: ['plain'] }, { idle: hash });
    const added = [], saved = [];
    const r = await fetchMissingSpecies(b, ['newmon', 'sproutle'], {
      haveSpecies: (id) => id === 'sproutle', haveSprite: () => false,
      addSpecies: (rec) => added.push(rec.id), saveSprite: (p, bytes) => saved.push([p, bytes.length]),
    });
    assert.deepEqual(r.added, ['newmon']);
    assert.deepEqual(added, ['newmon']);
    assert.deepEqual(saved, [['creatures/newmon.png', png.length]]);
    // a picture you already have isn't downloaded again
    const r2 = await fetchMissingSpecies(b, ['newmon'], { haveSpecies: () => false, haveSprite: () => true, addSpecies: () => {}, saveSprite: () => assert.fail('re-downloaded') });
    assert.equal(r2.sprites, 0);
  } finally {
    await s.close();
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
