import test from 'node:test';
import assert from 'node:assert/strict';
import { createDefaultDataset, indexDataset, createCreature, startWish, finishWish, addTask, musicTaste } from '../shared/engine/index.js';
import { modelFor } from '../shared/ui/m3d/catalog.js';
import { hitbox } from '../shared/ui/m3d/meshdata.js';
import { pickOv, MODS, LIST_KEYS, SET_KEYS } from '../shared/ui/labNotes.js';

const setup = () => {
  const ds = createDefaultDataset(), idx = indexDataset(ds);
  const c = createCreature(idx, ds.species[0].id, { level: 10, seed: 'wish-1' });
  const save = { creatures: { [c.uid]: c }, inventory: {}, tasks: [] };
  return { ds, idx, c, save };
};

test('a wish done straight away (“Let’s do it now”) is rewarded like a ticked-off task', () => {
  const { idx, c, save } = setup();
  const joy0 = c.needs?.joy ?? 60, fr0 = c.friendship ?? 0;
  startWish(save, { uid: c.uid, key: 'wish:fishing', act: 'fishing', text: 'Sproutle wants to go fishing.' }, 1000);
  assert.equal(finishWish(idx, save, c.uid, 'cooking', 2000), null); // (not what they asked for)
  const r = finishWish(idx, save, c.uid, 'fishing', 3000);
  assert.ok(r?.ok);
  assert.ok(c.needs.joy > joy0 || c.needs.joy === 100);
  assert.ok(c.friendship > fr0);
  assert.equal(finishWish(idx, save, c.uid, 'fishing', 4000), null); // (only once)
  // a battle they asked for, and a matching task on the list comes off with it
  addTask(save, { id: 't1', uid: c.uid, made: 0, due: 1e12, kind: 'wish', key: 'wish:battle', text: 'x' });
  startWish(save, { uid: c.uid, key: 'wish:battle', act: 'battle' }, 5000);
  assert.ok(finishWish(idx, save, c.uid, 'battle', 6000)?.ok);
  assert.equal(save.tasks.length, 0);
  // (kept for a while, not forever)
  startWish(save, { uid: c.uid, key: 'wish:puzzle', act: 'puzzle' }, 0);
  assert.equal(finishWish(idx, save, c.uid, 'puzzle', 7 * 3600000), null);
});

test('music taste: each creature has its own, within −1…1, and it grows on them', () => {
  const { idx, c } = setup();
  const v = musicTaste(idx, c, 'rock');
  assert.ok(v >= -1 && v <= 1);
  c.prefs = { 'music:rock': 6 };
  assert.ok(musicTaste(idx, c, 'rock') > v);
  assert.equal(musicTaste(idx, c, ''), 0);
});

test('the garden and kitchen models build (and the planter has a solid hitbox)', () => {
  for (const [k, o] of [['planter', {}], ['berryplant', {}], ['berryplant', { state: 'thirsty' }], ['berryplant', { state: 'wilt' }], ['weedvine', { stage: 1 }], ['weedvine', { stage: 4 }], ['basin', {}], ['spoon', {}], ['cookpot', { soup: '#3fb26a' }], ['jar', { fill: '#ff8fb6' }]]) {
    const m = modelFor(k, o);
    assert.ok(m && m.mesh.t.length > 50, `${k} built`);
  }
  // a thirsty plant droops lower than a healthy one
  assert.ok(modelFor('berryplant', { state: 'thirsty' }).h < modelFor('berryplant', {}).h);
  const hb = hitbox(modelFor('planter', {}));
  assert.ok(hb.nx > 10);
});

test('the Battle Lab’s modifiers are used together, and go into battles', () => {
  assert.ok(LIST_KEYS.includes('mods') && SET_KEYS.includes('mods'));
  assert.deepEqual(MODS.map(([k]) => k), ['self', 'sky', 'projectile', 'contact']);
  const p = pickOv({ kind: ['beam'], mods: ['self', 'sky'] });
  assert.deepEqual(p.mods, ['self', 'sky']);
  assert.equal(p.kind, 'beam');
});

test('the language model remembers what was just said to each of them, and is told what the game decided', async () => {
  const L = await import('../shared/ui/localLlm.js');
  let seen = null;
  const fake = { env: {}, pipeline: async () => async (msgs) => { seen = msgs; return [{ generated_text: [...msgs, { role: 'assistant', content: 'Mew perks up happily.' }] }]; } };
  await L.warmLlm({ importer: async () => fake });
  L.llmForget();
  assert.equal(await L.llmReact('Want to play?', { uid: 'u1', name: 'Mew', rule: 'Mew would love to play.' }), 'Mew perks up happily.');
  assert.match(seen[0].content, /would love to play/);
  await L.llmReact('Great, let’s go!', { uid: 'u1', name: 'Mew' });
  assert.ok(seen.some((m) => m.role === 'user' && /Want to play\?/.test(m.content)), 'the earlier exchange is part of the next prompt');
  // asleep: no waking up in words
  const fake2 = { env: {}, pipeline: async () => async (msgs) => [{ generated_text: [...msgs, { role: 'assistant', content: 'Mew wakes up and wants berries.' }] }] };
  void fake2;
  L.llmRemember('u2', 'hi', 'Mew snores.');
  L.llmForget('u2');
});
