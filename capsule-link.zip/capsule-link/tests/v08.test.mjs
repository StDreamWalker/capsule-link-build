// 0.8.0: naps that last, food that does things, kibble, recipes, training drills, friends' data.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const base = () => {
  const idx = E.indexDataset(E.createDefaultDataset());
  const save = E.createSave('Kim', 2);
  E.tickAll(idx, save);
  return { idx, save };
};
const add = (idx, save, loc = { kind: 'box', box: 0, slot: 0 }) => { const c = E.createCreature(idx, idx.ds.species[0].id, { level: 10, location: loc }); save.creatures[c.uid] = c; return c; };

test('a nap lasts until they wake (moving them keeps them asleep); waking them on purpose makes them grumpy; no training asleep', () => {
  const { idx, save } = base();
  const c = add(idx, save);
  const t0 = Date.now();
  c.needs.energy = 20; c.needsAt = t0;
  assert.equal(E.applyCare(idx, c, 'rest', { at: t0 }).reaction, 'sleep');
  assert.ok(E.isAsleep(c, t0 + 60000));
  assert.equal(E.mood(c, t0 + 60000).id, 'asleep');
  // moved to the party: still asleep
  c.location = { kind: 'party', slot: 0 };
  assert.ok(E.isAsleep(c, t0 + 120000));
  assert.equal(E.applyCare(idx, c, 'feed', { at: t0 + 120000 }).ok, false);
  assert.equal(E.canDo(idx, save, c, 'training').ok, false);
  // energy comes back while they sleep
  E.tickNeeds(idx, c, t0 + 25 * 60000);
  assert.ok(c.needs.energy > 40);
  // woken on purpose: awake, a bit upset
  const w = E.applyCare(idx, c, 'wake', { at: t0 + 26 * 60000 });
  assert.equal(w.reaction, 'grumpy');
  assert.ok(!E.isAsleep(c, t0 + 26 * 60000));
  assert.ok(c.upsetUntil > t0 + 26 * 60000);
  // left alone, a nap ends by itself
  const d = add(idx, save, { kind: 'box', box: 0, slot: 1 });
  d.needs.energy = 50; d.needsAt = t0;
  E.applyCare(idx, d, 'rest', { at: t0 });
  E.tickNeeds(idx, d, t0 + 3 * 3600000);
  assert.ok(!d.sleep);
});

test('food does things: Leppa brings energy back, Persim calms, Pomeg befriends; kibble only a little and gets old', () => {
  const { idx, save } = base();
  assert.ok(E.foodEffects({ name: 'Leppa Berry', kind: 'food' }).energy >= 30);
  assert.equal(E.foodEffects({ name: 'Persim Berry', kind: 'food' }).calm, true);
  assert.ok(E.foodEffects({ name: 'Pomeg Berry', kind: 'food' }).friendship >= 5);
  assert.match(E.foodBlurb({ name: 'Leppa Berry', kind: 'food' }), /energy/);
  const c = add(idx, save);
  const t0 = Date.now();
  c.needs.fullness = 10; c.needsAt = t0;
  const f0 = c.needs.fullness;
  E.applyCare(idx, c, 'feed', { at: t0, direct: false });
  assert.ok(c.needs.fullness - f0 <= E.KIBBLE_FULLNESS, 'kibble only fills a little');
  let last;
  for (let i = 1; i < 8; i++) { c.needs.fullness = 10; last = E.applyCare(idx, c, 'feed', { at: t0 + i * 1000, direct: false }); }
  assert.ok(['meh', 'annoyed'].includes(last.reaction));
  // a calming berry clears being upset
  c.upsetUntil = t0 + 600000; c.needs.fullness = 10;
  idx.items.set('persim-berry', { id: 'persim-berry', name: 'Persim Berry', kind: 'food', fullness: 10 });
  E.applyCare(idx, c, 'feed', { item: 'persim-berry', at: t0 + 20000, direct: false });
  assert.ok(c.upsetUntil <= t0 + 20000);
});

test('recipes: at least 16, each says what it needs, and the bag decides which you can make', () => {
  const { idx } = base();
  assert.ok(E.RECIPES.length >= 16);
  const foods = E.allFoods(idx);
  const jam = E.RECIPES.find((r) => r.id === 'jam');
  assert.equal(E.recipeStatus(foods, {}, jam).ok, false);
  assert.ok(E.recipeStatus(foods, {}, jam).missing.length);
  const sweet = foods.find((f) => E.flavorsOf(f).includes('sweet') && E.isBerry(f));
  assert.ok(sweet, 'a sweet berry in the starter set');
  const st = E.recipeStatus(foods, { [sweet.id]: 3 }, jam);
  assert.ok(st.ok); assert.equal(st.picks.length, 3);
  assert.ok(E.itemInfo(idx, 'dish-jam'));
  for (const r of E.RECIPES) assert.ok(E.recipeNeeds(r).length);
});

test('friends server: share a whole Data Lab; friends fetch it (with its pictures), strangers can’t', async () => {
  const fs = await import('node:fs'), os = await import('node:os'), path = await import('node:path'), crypto = await import('node:crypto');
  const { makeServer } = await import('../server/core.mjs');
  const { FriendsClient } = await import('../shared/net/friends.js');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'clhs8-'));
  const s = makeServer({ port: 0, dataDir: dir });
  await s.server.ready;
  const base = `http://127.0.0.1:${s.server.address().port}`;
  try {
    const a = new FriendsClient(base), b = new FriendsClient(base), c = new FriendsClient(base);
    const ra = await a.signup('ash', 'pikapika1', 'Ash');
    await b.signup('misty', 'starmie12', 'Misty'); await c.signup('brock', 'onixonix1');
    await b.request(ra.user.code); await a.accept('misty');
    const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47]), crypto.randomBytes(30)]);
    const hash = crypto.createHash('sha256').update(png).digest('hex');
    assert.deepEqual((await a.blobsHave([hash])).have, []);
    await a.putBlob(hash, png);
    assert.deepEqual((await a.blobsHave([hash])).have, [hash]);
    const ds = E.createDefaultDataset();
    const r = await a.shareDatalab(ds, { 'creatures/newmon.png': hash });
    assert.match(r.hash, /^[a-f0-9]{64}$/);
    const info = await b.datalabInfo('ash');
    assert.equal(info.hash, r.hash); assert.equal(info.counts.species, ds.species.length);
    const full = await b.datalabFull('ash');
    assert.equal(full.dataset.species.length, ds.species.length);
    assert.equal(full.textures['creatures/newmon.png'], hash);
    await assert.rejects(() => c.datalabInfo('ash'), /friends/);
    await assert.rejects(() => a.datalabInfo('misty'), /hasn’t shared/);
  } finally { await s.close(); }
});
