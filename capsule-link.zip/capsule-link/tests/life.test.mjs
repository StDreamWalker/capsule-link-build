import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';
import { encodeFullRecord, decodeFullRecord } from '../shared/engine/fullRecord.js';

const base = () => {
  const idx = E.indexDataset(E.createDefaultDataset());
  const save = E.createSave('Kim', 1);
  E.tickAll(idx, save);
  return { idx, save };
};
const add = (idx, save, sp, loc = { kind: 'box', box: 0, slot: 0 }) => { const c = E.createCreature(idx, sp, { location: loc }); save.creatures[c.uid] = c; return c; };

test('the shop: same stock all day, limited, paid with coins', () => {
  const { idx, save } = base();
  assert.equal(E.wallet(save), 300, 'a starting purse');
  const t = Date.UTC(2026, 9, 26, 12);
  const a = E.shopStock(idx, save, t), b = E.shopStock(idx, save, t + 3600000);
  assert.deepEqual(a.lines.map((l) => l.id), b.lines.map((l) => l.id));
  assert.ok(a.lines.some((l) => l.item.kind === 'clothes') && a.lines.some((l) => l.item.kind === 'held') && a.lines.some((l) => l.item.kind === 'incense'));
  const cheap = a.lines.find((l) => l.item.kind === 'food');
  const r = E.buy(idx, save, cheap.id, t);
  assert.equal(r.ok, true);
  assert.equal(save.inventory[cheap.id] >= 1, true);
  assert.equal(E.wallet(save), 300 - cheap.price);
  save.wallet = 0;
  assert.equal(E.buy(idx, save, cheap.id, t).ok, false);
});

test('coins come from walking and battles', () => {
  const { idx, save } = base();
  const c = add(idx, save, 'sproutle', { kind: 'party', slot: 0 });
  const before = save.wallet;
  E.applyEvent(idx, save, E.makeEvent('walk', { uid: c.uid, steps: 2500 }));
  assert.ok(save.wallet - before >= 99, `walk paid ${save.wallet - before}`);
  E.applyEvent(idx, save, E.makeEvent('battle', { won: true, results: [{ uid: c.uid, exp: 10, won: true }] }));
  assert.ok(save.wallet - before >= 139);
});

test('clothes: wear, move, only as many as you own, and they grow on you', () => {
  const { idx, save } = base();
  const a = add(idx, save, 'sproutle'), b = add(idx, save, 'cindrop');
  save.inventory['clothes-bow'] = 1;
  assert.equal(E.wear(save, a.uid, 'clothes-bow', 0.5, 0.1).ok, true);
  assert.equal(E.wear(save, b.uid, 'clothes-bow', 0.5, 0.1).ok, false, 'one bow, one wearer');
  assert.equal(E.wear(save, a.uid, 'clothes-bow', 0.3, 0.2).ok, true, 'moving it is fine');
  assert.equal(a.clothes.length, 1);
  const out = E.applyCare(idx, a, 'dress', { item: 'clothes-bow' });
  assert.equal(out.ok, true);
  for (let d = 0; d < 6; d++) E.tickAll(idx, save, Date.now() + d * 86400000);
  assert.ok((a.prefs?.['clothes:clothes-bow'] ?? 0) > 0, 'fond of the bow');
});

test('forms: found by name or base species, switchable, weather picks one, battles skip battle-only ones', () => {
  const ds = E.createDefaultDataset();
  const sp = ds.species[0];
  ds.species.push({ ...JSON.parse(JSON.stringify(sp)), id: `${sp.id}-sunny`, name: `${sp.name}-Sunny`, no: 10001, baseSpecies: sp.id, forme: 'Sunny' });
  ds.species.push({ ...JSON.parse(JSON.stringify(sp)), id: `${sp.id}-snowy`, name: `${sp.name}-Snowy`, no: 10002 });
  ds.species.push({ ...JSON.parse(JSON.stringify(sp)), id: `${sp.id}-mega`, name: `${sp.name}-Mega`, no: 10003, baseSpecies: sp.id, forme: 'Mega', battleOnly: true });
  const idx = E.indexDataset(ds);
  const forms = E.formsOf(idx, sp.id);
  assert.deepEqual(forms.map((f) => f.id), [sp.id, `${sp.id}-sunny`, `${sp.id}-snowy`, `${sp.id}-mega`]);
  const c = E.createCreature(idx, sp.id);
  assert.equal(E.weatherForm(idx, c, { weather: 'clouds', temp: 31 }), `${sp.id}-sunny`);
  assert.equal(E.weatherForm(idx, c, { weather: 'snow' }), `${sp.id}-snowy`);
  assert.equal(E.weatherForm(idx, c, { weather: 'clouds', temp: 15 }), sp.id);
  assert.equal(E.setForm(idx, c, `${sp.id}-mega`).ok, true);
  assert.equal(E.battleSpeciesOf(idx, c).id, sp.id, 'mega only exists mid-battle');
  E.setForm(idx, c, `${sp.id}-sunny`);
  assert.equal(E.showdownSet(idx, c).species, `${sp.name}-Sunny`);
  assert.equal(E.setForm(idx, c, 'zapkit').ok, false);
  const save = E.createSave('K', 1); save.creatures[c.uid] = c;
  E.applyEvent(idx, save, E.makeEvent('form', { uid: c.uid, form: `${sp.id}-snowy`, why: 'weather' }));
  assert.equal(c.formId, `${sp.id}-snowy`);
  assert.ok(c.memories.some((m) => /weather/.test(m.text)));
});

test('real places and the weather shape who turns up; incense pulls its type in', () => {
  const { idx } = base();
  const top = (ctx) => E.encounterTable(idx, { t: Date.UTC(2026, 5, 1, 12), ...ctx })[0].id;
  const pct = (ctx, id) => E.encounterTable(idx, { t: Date.UTC(2026, 5, 1, 12), ...ctx }).find((r) => r.id === id)?.p ?? 0;
  assert.equal(top({ places: ['power'] }), 'zapkit');
  assert.ok(pct({ places: ['park'], incense: 'ember' }, 'cindrop') > pct({ places: ['park'] }, 'cindrop') * 2);
  assert.deepEqual(E.contextEnv({ places: ['beach'], temp: -2 }).slice(0, 1), ['snow']);
  const c = E.createCreature(idx, 'sproutle');
  assert.ok(E.walkFirsts(c, ['plains'], Date.now(), ['cemetery']).some((f) => f.key === 'place:cemetery'));
});

test('incense lit on the phone uses one from the bag', () => {
  const { idx, save } = base();
  const id = E.incenseId('ember');
  save.inventory[id] = 1;
  const r = E.applyEvent(idx, save, E.makeEvent('incense', { item: id }));
  assert.equal(r.ok, true);
  assert.equal(save.inventory[id], 0);
  assert.equal(E.activeIncense(save).type, 'ember');
  assert.equal(E.applyEvent(idx, save, E.makeEvent('incense', { item: id })).ok, false);
});

test('desktop buddies: up to six, toggled on and off', () => {
  const { idx, save } = base();
  const list = Array.from({ length: 7 }, (_, i) => add(idx, save, 'sproutle', { kind: 'box', box: 0, slot: i }));
  for (let i = 0; i < 6; i++) assert.equal(E.toggleBuddy(save, list[i].uid, true).ok, true);
  assert.equal(E.toggleBuddy(save, list[6].uid, true).ok, false);
  assert.equal(E.desktopBuddies(save).length, 6);
  assert.equal(E.isDesktopBuddy(save, list[0].uid), true);
  E.toggleBuddy(save, list[0].uid);
  assert.equal(E.isDesktopBuddy(save, list[0].uid), false);
  assert.equal(save.settings.petUid, list[1].uid);
});

test('ID cards keep signatures, stamps and old numbers', () => {
  const card = E.normalizeCard({ signature: [[[0, 0], [500, 900], [1200, -5]]], stamps: [{ k: 'paw', x: 2, y: 0.5, r: 400 }, { k: 'nope' }], show: 'party', base: '#123456', title: 'Bug Catcher Supreme' });
  assert.deepEqual(card.signature, [[[0, 0], [500, 900], [1000, 0]]]);
  assert.equal(card.stamps.length, 1);
  assert.equal(card.stamps[0].x, 1);
  assert.equal(card.show, 'party');
  assert.equal(card.title.length <= 14, true);
  const next = E.reissueCard(card, 'abc');
  assert.equal(next.history[0].num, E.cardNumber('abc', card));
  assert.notEqual(E.cardNumber('abc', next), E.cardNumber('abc', card));
});

test('a full record holds a creature’s whole life and reads back', () => {
  const { idx } = base();
  const c = E.createCreature(idx, 'gloomoth', { level: 30, nickname: 'Moth' });
  c.shiny = true; c.shinyType = 'square'; c.cryPitch = -2.5; c.sizeScalar = 40; c.gender = 'female';
  c.memories = [{ t: 1700000000000, text: 'Saw snow.', core: true }];
  c.prefs = { 'place:river': 7, 'food:glow-berry': -3 };
  c.bonds = { '0011223344556677': 80 };
  c.clothes = [{ id: 'clothes-bow', fx: 0.5, fy: 0.25, s: 1 }];
  const bytes = encodeFullRecord(idx, c);
  const back = decodeFullRecord(bytes);
  assert.equal(back.ok, true);
  assert.equal(back.main.nickname, 'Moth');
  assert.equal(back.identity.pid, c.pid);
  assert.equal(back.identity.shinyType, 'square');
  assert.equal(back.identity.cryPitch, -2.5);
  assert.equal(back.identity.sizeScalar, 40);
  assert.deepEqual(back.memories, c.memories);
  assert.deepEqual(back.prefs, c.prefs);
  assert.equal(back.bonds['0011223344556677'], 80);
  assert.equal(back.clothes.length, 1);
  bytes[200] ^= 1;
  assert.equal(decodeFullRecord(bytes).ok, false, 'damage is noticed');
});

test('new creatures get identity numbers', () => {
  const { idx } = base();
  const c = E.createCreature(idx, 'sproutle', { seed: 9 });
  assert.ok(Number.isInteger(c.pid) && Number.isInteger(c.ec));
  const shiny = E.createCreature(idx, 'sproutle', { shiny: true });
  assert.equal(shiny.shiny, true);
});
