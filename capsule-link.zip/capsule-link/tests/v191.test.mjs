import test from 'node:test';
import assert from 'node:assert/strict';
import * as E from '../shared/engine/index.js';

const world = () => {
  const ds = E.createDefaultDataset(), idx = E.indexDataset(ds);
  const save = E.createSave('Kim', 2); E.tickAll(idx, save);
  const mk = (i, nick) => { const c = E.createCreature(idx, ds.species[i % ds.species.length].id, { level: 12 + i * 3, seed: `u${i}`, location: { kind: 'ranch' } }); c.nickname = nick; c.friendship = 160; c.needs = { energy: 70, fullness: 70, joy: 70, hygiene: 70 }; save.creatures[c.uid] = c; return c; };
  const A = mk(0, 'Musharna'), B = mk(1, 'Cogsy'), C = mk(4, 'Mindle');
  A.bonds = { [B.uid]: 70 };
  return { ds, idx, save, A, B, C, names: E.namesFor(idx, save) };
};
const T0 = (() => { const d = new Date(); d.setHours(14, 0, 0, 0); return d.getTime(); })();
const say = (w, c, text, dt = 0) => E.chatReply(w.idx, w.save, c, text, T0 + dt, {});

test('its own Pokémon world: type, weaknesses, moves, evolving, nature, ball, health — all from its real data', () => {
  const w = world(), { idx, A, C } = w;
  const types = E.typeNames(idx, A);
  assert.match(say(w, A, 'what type are you?').note, new RegExp(types[0]));
  const weak = E.weakTo(idx, A).weak[0];
  assert.match(say(w, A, `are you weak to ${weak.name}?`).note, /hit it hard|four times/);
  assert.match(say(w, A, 'what moves do you know?').note, new RegExp(E.movesOf(idx, A)[0].name));
  assert.match(say(w, A, 'show me your best move').note, new RegExp(E.bestMove(idx, A).name));
  assert.match(say(w, A, 'will you evolve?').note, /evolve into|fully evolved/);
  assert.match(say(w, A, "what's your nature?").note, /sort/);
  assert.match(say(w, A, 'do you like your ball?').note, /Ball/);
  assert.match(say(w, A, 'are you hurt?').note, /HP|fainted/);
  assert.match(say(w, A, 'do you know Mindle?').note, /Mindle/);
  assert.match(say(w, C, 'can you evolve?').note, /evolve|Tidecrest/i);
});

test('type questions for the group come from the type chart', () => {
  const w = world(), { idx, save, A, B, C, names } = w;
  const weak = E.weakTo(idx, A).weak[0];
  const rows = E.groupAnswers(idx, save, [A.uid, B.uid, C.uid], E.understand(`who is weak to ${weak.name}?`, { names }));
  assert.equal(rows[0].uid, A.uid);
  assert.ok(rows[0].v >= 2);
  const ev = E.groupAnswers(idx, save, [A.uid, B.uid, C.uid], E.understand('who can evolve?', { names }));
  assert.equal(ev.length, 3);
});

test('friend and pet talk: compliments, teasing, comfort, pep talks, jokes, thoughts and dreams', () => {
  const w = world(), { A, idx, save } = w;
  for (const [t, re] of [["you're so fluffy!", /pink|struts|wiggles|blink|pleased|compliment/], ["you're such a lazybones", /raspberry|offended|pounce|argue|right|huffs|hurt|pretends/], ["it's okay, don't be scared", /snuggles|leans|presses|better/], ['you can do it!', /determined|ready|fierce|fired/], ['I missed you', /missed|glad|curious/], ['tell me a joke', /\w/], ['what are you thinking about?', /thinking/], ['did you have a nice dream?', /dream/], ['bless you', /sniffles/]]) {
    const r = say(w, A, t);
    assert.ok(!r.generic, t); assert.match(r.note, re, `${t} → ${r.note}`);
  }
  // a pep talk is remembered (and makes it run a little faster in the next race)
  assert.ok(A.pepTalk > 0);
  // what it's thinking about is real: a walk it won comes first
  E.promise(idx, save, A, { kind: 'walk', label: 'a walk with you', icon: '🚶' }, Date.now(), 'because you promised');
  assert.match(E.thoughtsOf(idx, save, A)[0].text, /walk/);
  const mind = E.mindOf(idx, save, A);
  assert.ok(mind.thoughts.length && mind.owed && /trainer/.test(mind.bond));
});

test('tricks are learned with practice, and remembered', () => {
  const w = world(), { A } = w;
  A.friendship = 255;
  let learned = false;
  for (let i = 0; i < 20 && !learned; i++) { say(w, A, 'roll over', i * 61000); learned = !!A.tricks?.rollover?.learned; }
  assert.ok(learned, 'learns to roll over');
  const r = say(w, A, 'roll over', 30 * 61000);
  assert.match(r.note, /rolls/); assert.equal(r.act?.kind, 'spin');
  assert.ok([...(A.memories ?? []), ...(A.journal ?? [])].some((m) => /roll over/.test(m.text)));
});

test('every kind of remark the language model can pick has a real answer', () => {
  const w = world(), { A } = w;
  A.origin = { from: 'pkhex' }; A.level = 60; A.friendship = 220; // (one that follows what you say)
  let i = 0;
  for (const it of E.TALK_INTENTS) { const r = say(w, A, it.say, (i++) * 60000); assert.ok(r.note && !r.generic, `${it.id}: ${it.say} → ${r.note}`); }
  assert.ok(say(w, A, 'the quantum flux is unstable').generic, 'nonsense is marked so the model can be asked');
});
